/dev/shm/ownrt-portable-build-one-20261020/objects/9c704c943e8e4fed.o: \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/native.cpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/prepared_submission.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/owner_api.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/argument_block.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/native.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/kernels.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/detmath.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet17-detmath/detmath.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/rope.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/owner.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage1/packet3-prep/src/sycl_operation.hpp
