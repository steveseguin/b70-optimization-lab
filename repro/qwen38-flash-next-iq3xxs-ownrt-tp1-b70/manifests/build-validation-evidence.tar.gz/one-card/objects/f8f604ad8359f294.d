/dev/shm/ownrt-portable-build-one-20261020/objects/f8f604ad8359f294.o: \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58ag-onecard-ports/build/native/owner_retire.cpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58ag-onecard-ports/native/ordered_retirement.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58ag-onecard-ports/native/async_backend.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58ag-onecard-ports/frozen-inputs/repo/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/owner.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58ag-onecard-ports/frozen-inputs/repo/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58ag-onecard-ports/frozen-inputs/repo/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/owner_api.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58ag-onecard-ports/frozen-inputs/repo/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/argument_block.hpp
