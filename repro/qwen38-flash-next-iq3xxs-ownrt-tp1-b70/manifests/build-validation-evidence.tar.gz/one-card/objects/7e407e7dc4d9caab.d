/dev/shm/ownrt-portable-build-one-20261020/objects/7e407e7dc4d9caab.o: \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/build/device/own-rt-iq3-entry.cpp
