/dev/shm/ownrt-portable-build-one-20261020/objects/a2a956972dadf3ed.o: \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet7-kopt2/kernels.cpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/prepared_submission.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/owner_api.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/argument_block.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet7-kopt2/kernels.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet6-kopt/kernels.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/device.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/math.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/grids.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/owner.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet7-kopt2/reference.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet6-kopt/reference.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage1/packet3-prep/src/sycl_operation.hpp
