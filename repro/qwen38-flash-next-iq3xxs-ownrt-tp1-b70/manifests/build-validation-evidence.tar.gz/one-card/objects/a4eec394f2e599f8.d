/dev/shm/ownrt-portable-build-one-20261020/objects/a4eec394f2e599f8.o: \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/runtime_kernels.cpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/prepared_submission.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/owner_api.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/argument_block.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/runtime_kernels.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/device.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/math.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/grids.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/owner.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/core_v2.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/detmath.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet17-detmath/detmath.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/rope.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage2/packet3/kernels/api.hpp \
  /dev/shm/ownrt-portable-build-one-20261020/source/experiments/own-xpu-runtime/stage2/packet58j-onecard-port/build/checked/experiments/own-xpu-runtime/stage1/packet3-prep/src/sycl_operation.hpp
