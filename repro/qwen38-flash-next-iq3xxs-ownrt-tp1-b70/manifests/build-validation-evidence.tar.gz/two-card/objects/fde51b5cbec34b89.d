/dev/shm/ownrt-portable-build-two-20261020/objects/fde51b5cbec34b89.o: \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/build/checked/experiments/own-xpu-runtime/stage2/packet2/loader/gguf.cpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/build/checked/experiments/own-xpu-runtime/stage2/packet2/loader/gguf.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/math.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/grids.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/build/checked/experiments/own-xpu-runtime/stage2/packet35-hostpath/owner.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/build/checked/experiments/own-xpu-runtime/stage2/packet35-hostpath/owner_api.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet35-hostpath/build/checked/experiments/own-xpu-runtime/stage2/packet35-hostpath/argument_block.hpp
