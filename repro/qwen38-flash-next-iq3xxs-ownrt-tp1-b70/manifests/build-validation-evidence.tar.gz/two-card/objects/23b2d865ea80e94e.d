/dev/shm/ownrt-portable-build-two-20261020/objects/23b2d865ea80e94e.o: \
 /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet61x-spin-hcfusion-wait/host_wait_mode.cpp \
 /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet61x-spin-hcfusion-wait/host_spin.hpp
