/dev/shm/ownrt-portable-build-two-20261020/objects/0c532298d1d26b89.o: \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/native.cpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/prepared_submission.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/owner_api.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/argument_block.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/native.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/kernels.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/detmath.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet17-detmath/detmath.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/rope.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/owner.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage1/packet3-prep/src/sycl_operation.hpp
