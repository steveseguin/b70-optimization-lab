/dev/shm/ownrt-portable-build-two-20261020/objects/5d935a30ad9e105d.o: \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet40-suite/build/checked/experiments/own-xpu-runtime/stage2/packet40-suite/owner.cpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet40-suite/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet40-suite/build/checked/experiments/own-xpu-runtime/stage2/packet40-suite/owner.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet40-suite/build/checked/experiments/own-xpu-runtime/stage2/packet40-suite/owner_api.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet40-suite/build/checked/experiments/own-xpu-runtime/stage2/packet40-suite/argument_block.hpp
