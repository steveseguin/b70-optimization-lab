/dev/shm/ownrt-portable-build-two-20261020/objects/9a7ad07aedc2db3f.o: \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet80-record-bundle/single_device.cpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet80-record-bundle/owner.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet80-record-bundle/owner_api.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet80-record-bundle/argument_block.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet80-record-bundle/ordered_queue.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet80-record-bundle/prepared_submission.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage1/packet3-prep/src/sycl_operation.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet80-record-bundle/host_spin.hpp
