/dev/shm/ownrt-portable-build-two-20261020/objects/dccc906264e6b595.o: \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet6-kopt/kernels.cpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/prepared_submission.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/owner_api.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/argument_block.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet6-kopt/kernels.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/device.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/math.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/grids.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/owner.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet6-kopt/reference.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage1/packet3-prep/src/sycl_operation.hpp
