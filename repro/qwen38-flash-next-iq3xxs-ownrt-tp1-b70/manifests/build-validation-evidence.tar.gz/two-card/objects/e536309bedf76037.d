/dev/shm/ownrt-portable-build-two-20261020/objects/e536309bedf76037.o: \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/device.cpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/prepared_submission.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/owner_api.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/argument_block.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/device.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/math.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet2/kernels/grids.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/owner.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet56-draft-prefix/build/checked/experiments/own-xpu-runtime/stage1/packet3-prep/src/sycl_operation.hpp
