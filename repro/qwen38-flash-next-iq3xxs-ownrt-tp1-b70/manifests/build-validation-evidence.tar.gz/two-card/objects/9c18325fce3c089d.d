/dev/shm/ownrt-portable-build-two-20261020/objects/9c18325fce3c089d.o: \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet76-rank1-host/build/checked/experiments/own-xpu-runtime/stage2/packet76-rank1-host/owner_retire.cpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet76-rank1-host/kernel_guard.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet76-rank1-host/build/checked/experiments/own-xpu-runtime/stage2/packet76-rank1-host/owner.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet76-rank1-host/build/checked/experiments/own-xpu-runtime/stage2/packet76-rank1-host/owner_api.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet76-rank1-host/build/checked/experiments/own-xpu-runtime/stage2/packet76-rank1-host/argument_block.hpp \
  /dev/shm/ownrt-portable-build-two-20261020/source/experiments/own-xpu-runtime/stage2/packet76-rank1-host/build/checked/experiments/own-xpu-runtime/stage2/packet76-rank1-host/ordered_queue.hpp
