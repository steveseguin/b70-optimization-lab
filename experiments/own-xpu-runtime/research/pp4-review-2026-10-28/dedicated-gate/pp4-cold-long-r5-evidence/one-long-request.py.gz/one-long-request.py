"""Exactly one cold-control request. No retry or service action."""
import gzip
import hashlib
import json
from pathlib import Path
import time
import urllib.request

root = Path(__file__).resolve().parent
source = Path('/home/steve/llm-optimizations/experiments/own-xpu-runtime/research/pp4-review-2026-10-28/inputs/long-body.json.gz')
body = gzip.decompress(source.read_bytes())
assert json.loads(body)['max_tokens'] == 8
headers = {'Content-Type': 'application/json'}
key = Path('/home/steve/.config/sc117-lan/api_key')
if key.exists():
    headers['Authorization'] = 'Bearer ' + key.read_text().strip()
request = urllib.request.Request('http://127.0.0.1:18161/v1/chat/completions', data=body, headers=headers)
started = time.monotonic()
record = dict(body_sha256=hashlib.sha256(body).hexdigest(), started_monotonic_s=started, requests=1)
with (root / 'client-start.json').open('x') as f:
    json.dump(record, f, indent=2)
try:
    with urllib.request.urlopen(request, timeout=1700) as response:
        raw = response.read()
    with (root / 'client-response.json').open('xb') as f:
        f.write(raw)
    result = json.loads(raw)
    record.update(passed=True, wall_seconds=time.monotonic()-started, usage=result.get('usage'))
except Exception as error:
    record.update(passed=False, wall_seconds=time.monotonic()-started, error=repr(error))
    raise
finally:
    with (root / 'client-finished.json').open('x') as f:
        json.dump(record, f, indent=2)
    print(json.dumps(record))
