from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/dev/shm/sc117-dedicated-pipeline-long-20261028-r1')
out=root/'output'
terminal=json.loads((out/'terminal.json').read_text())
assert terminal['passed'] and not terminal['live_pids'] and all(v==0 for v in terminal['returncodes'].values())
files=sorted(out.rglob('state.bundle'))
assert len(files)==5 and all(f.is_file() and not f.is_symlink() for f in files)
archive=Path('/mnt/raid-models/ownrt-experiment-archives/2026-10-28/dedicated-pipeline-long-r1-state-bundles.tar.zst')
assert not archive.exists() and shutil.disk_usage(archive.parent).free>2*sum(f.stat().st_size for f in files)
rel=[str(f.relative_to(root)) for f in files]
listing=root/'dedicated-bundle-files.txt';listing.write_text('\n'.join(rel)+'\n')
with archive.open('xb') as sink:
 subprocess.run(['tar','-C',str(root),'-I','zstd -T2 -1','-cf','-','-T',str(listing)],stdout=sink,check=True)
subprocess.run(['tar','-C',str(root),'-I','zstd -T2','-df',str(archive)],check=True)
h=hashlib.sha256()
with archive.open('rb') as stream:
 for block in iter(lambda:stream.read(8*1024**2),b''):h.update(block)
receipt=dict(archive=str(archive),sha256=h.hexdigest(),archive_bytes=archive.stat().st_size,paths_relative_to=str(root),exact_bundle_paths=rel,original_bytes=sum(f.stat().st_size for f in files),full_tar_compare_passed=True,deleted_precisely_compared_bundle_files=False)
p=root/'dedicated-archive.json';p.write_text(json.dumps(receipt,indent=2)+'\n')
for f in files:f.unlink()
receipt['deleted_precisely_compared_bundle_files']=True;p.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
