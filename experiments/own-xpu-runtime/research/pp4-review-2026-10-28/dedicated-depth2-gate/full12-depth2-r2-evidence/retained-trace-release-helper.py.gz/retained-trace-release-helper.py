from pathlib import Path
import json,gzip,hashlib,os,subprocess
repo=Path('/home/steve/llm-optimizations/experiments/own-xpu-runtime/research/pp4-review-2026-10-28')
groups=[('dedicated-depth2-gate/full12-depth3-r2-evidence','/dev/shm/sc117-dedicated-depth-suites-64k-20261028-r2/depth3'),('dedicated-depth2-gate/full12-depth2-r2-evidence','/dev/shm/sc117-dedicated-depth-suites-64k-20261028-r2/depth2'),('dedicated-depth2-gate/depth2-aba64k-r1-evidence','/dev/shm/sc117-dedicated-reset-depth2-aba64k-20261028-r1'),('dedicated-depth2-gate/full12-depth3-r1-incident','/dev/shm/sc117-dedicated-depth-suites-64k-20261028-r1/depth3'),('dedicated-reset-candidate/all-owner-integration/aba64k-r1-evidence','/dev/shm/sc117-dedicated-reset-aba64k-20261028-r1')]
def sha(b):return hashlib.sha256(b).hexdigest()
def stamp(p):
 s=p.stat();return[s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
assert subprocess.run(['pgrep','-x','sc117-engine'],stdout=subprocess.DEVNULL).returncode==1
rows=[];seen=set()
for folder,source in groups:
 root=Path(source);terminal=json.loads((root/'output/terminal.json').read_text());post=json.loads((root/'postflight.json').read_text());assert terminal['live_pids']==[] and post['known_fault_baseline_matches']and not post['holders']
 if source.endswith('r1/depth3'):assert not terminal['passed']and terminal['error']=="ValueError('reset reply channel closed')"and all(v==1 for v in terminal['returncodes'].values())
 else:assert terminal['passed']and terminal['error']is None and all(v==0 for v in terminal['returncodes'].values())
 index=repo/folder/'index.json';data=index.read_bytes()
 for row in json.loads(data)['files']:
  p=Path(row['source'])
  if not p.is_relative_to(root)or p.name not in ('driver-result.json','commands.jsonl','result.json'):continue
  assert str(p)not in seen and p.is_file()and not p.is_symlink();seen.add(str(p));old=stamp(p)
  retained=repo/folder/row['retained'];packed=retained.read_bytes();assert sha(packed)==row['retained_sha256']
  original=p.read_bytes();assert len(original)==row['bytes']and sha(original)==row['sha256']and gzip.decompress(packed)==original and stamp(p)==old
  with retained.open('rb')as f:os.fsync(f.fileno())
  rows.append(dict(path=str(p),bytes=row['bytes'],sha256=row['sha256'],stat=old,retained=str(retained),retained_sha256=row['retained_sha256'],index=str(index),index_sha256=sha(data)))
 with index.open('rb')as f:os.fsync(f.fileno())
 fd=os.open(index.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
receipt=dict(schema='ownrt.retained-completed-trace-release.v1',scope='Only completed uncompressed driver/request result and command trace duplicates. Every raw byte compared with retained gzip and both hashes; all summaries/plans/state metadata, CPU reference and binaries retained. Failed run remains failed.',members=rows,freed_bytes=sum(x['bytes']for x in rows),removed=False)
out=repo/'retained-dedicated-trace-release-r1.json';assert not out.exists()
def save():
 tmp=out.with_suffix('.tmp')
 with tmp.open('w')as f:json.dump(receipt,f,indent=2,ensure_ascii=False);f.write('\n');f.flush();os.fsync(f.fileno())
 tmp.replace(out);fd=os.open(out.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
save()
for row in rows:
 p=Path(row['path']);assert stamp(p)==row['stat'];p.unlink()
receipt['removed']=True;save();print(json.dumps(dict(files=len(rows),freed_bytes=receipt['freed_bytes'],removed=True)))
