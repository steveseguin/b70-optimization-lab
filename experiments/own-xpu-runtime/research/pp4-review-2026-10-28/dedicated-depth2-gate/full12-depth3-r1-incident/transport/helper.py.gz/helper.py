from pathlib import Path
import subprocess,json,hashlib,os
roots=[Path('/dev/shm/sc117-dedicated-depth-suites-64k-20261028-r1/depth3/output')]
paths=[]
for root in roots:
 receipt=root/('terminal.json' if (root/'terminal.json').exists()else 'result.json');x=json.loads(receipt.read_text());assert x['passed'] is False and x['error']=="ValueError('reset reply channel closed')" and x['live_pids']==[] and x['returncodes']=={'0':1,'1':1,'2':1,'provider':1}
 post=json.loads((root.parent/'postflight.json').read_text());assert post['known_fault_baseline_matches']and not post['holders']
 paths+=list(root.glob('stage*/prefill.bin'))+list(root.glob('stage*/shared.bin'))
assert paths and all(p.is_file()and not p.is_symlink()and p.name in ('prefill.bin','shared.bin')for p in paths)
def stamp(p):
 s=p.stat();return(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
before={str(p):stamp(p)for p in paths}
out=Path('/mnt/raid-models/ownrt-experiment-archives/2026-10-28/dedicated-depth3-full12-r1-incident-transport.tar.zst');assert not out.exists()
subprocess.run(['nice','-n','19','taskset','-c','8-15','tar','-I','zstd -1 -T2','-cf',str(out),'-C','/dev/shm',*[str(p.relative_to('/dev/shm')) for p in paths]],check=True)
subprocess.run(['nice','-n','19','taskset','-c','8-15','tar','-I','zstd -T2','-df',str(out),'-C','/dev/shm'],check=True)
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
rec=dict(schema='ownrt.failed-suite-transport-archive.v1',run_passed=False,archive=str(out),archive_sha256=digest(out),archive_bytes=out.stat().st_size,full_tar_compare_passed=True,source_roots=[str(p) for p in roots],members=[dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p)) for p in paths],released_bytes=sum(p.stat().st_size for p in paths))
record=Path('/home/steve/llm-optimizations/experiments/own-xpu-runtime/research/pp4-review-2026-10-28/dedicated-depth3-full12-r1-incident-transport-archive.json');record.write_text(json.dumps(rec,indent=2)+'\n')
with out.open('rb')as f:os.fsync(f.fileno())
with record.open('rb')as f:os.fsync(f.fileno())
fd=os.open(record.parent,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
for p in paths:
 assert stamp(p)==before[str(p)];p.unlink()
rec['removed_files_absent']=all(not p.exists()for p in paths);rec['removal_completed']=True;record.write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({k:v for k,v in rec.items() if k!='members'}))
