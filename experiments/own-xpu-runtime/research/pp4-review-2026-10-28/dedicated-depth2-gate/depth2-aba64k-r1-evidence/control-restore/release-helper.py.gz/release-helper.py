from pathlib import Path
import hashlib,json,os
root=Path('/dev/shm/sc117-depth3-firstA-restored-20261028-r1')
proof=Path('/dev/shm/sc117-depth2-vs3-firstA-proof-20261028-r2.json')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def stamp(p):
 s=p.stat();return [s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns]
q=json.loads(proof.read_text());assert q['passed'] and q['full_payload_bytes_compared']==4091763958
r=json.loads((root/'restoration.json').read_text());a=Path(r['archive_receipt']);assert sha(a)==r['archive_receipt_sha256']
a=json.loads(a.read_text());assert a['full_tar_bytes_compared']and Path(a['archive']).stat().st_size==a['archive_bytes']
rows=[]
for x in r['members']:
 p=Path(x['path']);assert p.parent.parent==root and not p.is_symlink();old=stamp(p)
 assert old[2]==x['bytes'] and sha(p)==x['sha256']and stamp(p)==old
 rows.append(dict(path=str(p),sha256=x['sha256'],stat=old))
receipt=dict(passed=True,proof=str(proof),proof_sha256=sha(proof),restoration_sha256=sha(root/'restoration.json'),freed_bytes=sum(x['stat'][2]for x in rows),members=rows,removed=False)
out=root/'release.json';assert not out.exists()
def save():
 with out.open('w')as f:json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
 fd=os.open(root,os.O_DIRECTORY);os.fsync(fd);os.close(fd)
save()
for x in rows:
 p=Path(x['path']);assert stamp(p)==x['stat'];p.unlink()
receipt['removed']=True;save();print(json.dumps(dict(freed_bytes=receipt['freed_bytes'],removed=True)))
