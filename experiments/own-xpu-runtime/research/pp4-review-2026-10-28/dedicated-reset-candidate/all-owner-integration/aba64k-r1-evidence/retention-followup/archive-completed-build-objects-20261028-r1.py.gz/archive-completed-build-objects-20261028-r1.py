from pathlib import Path
import json,hashlib,subprocess,tarfile,os
names=['reference-route-mtp','reference-route-gpu-addressed','reference-route-gpu','router-tie-diagnostic','lookup-view','l4-prepared-history','aot-bmg-g31','l4-history']
suffixes=['r1','r1','r1','r2','r1','r1','r1','r2']
rows=[]
stamp=lambda p:tuple(getattr(p.stat(),k)for k in ['st_dev','st_ino','st_size','st_mtime_ns','st_ctime_ns'])
for name,suffix in zip(names,suffixes):
 root=Path('/dev/shm')/f'engine-build-{name}-20261028-{suffix}'
 receipt=json.loads((root/'build-receipt.json').read_text())
 assert all(x['rc']==0 for x in receipt['commands'].values())
 for name,sha in receipt['objects'].items():
  p=root/name;assert p.suffix=='.o'and p.is_file()and not p.is_symlink()
  rows.append(dict(path=str(p),member=str(p.relative_to('/dev/shm')),bytes=p.stat().st_size,sha256=sha,stamp=stamp(p)))
dst=Path('/mnt/raid-models/ownrt-experiment-archives/2026-10-28/completed-build-objects-r1.tar.zst')
assert not dst.exists()and len(rows)==320
subprocess.run(['tar','-I','zstd -1 -T2','-cf',str(dst),'-C','/dev/shm',*[r['member']for r in rows]],check=True)
with dst.open('rb')as f:os.fsync(f.fileno())
proc=subprocess.Popen(['zstd','-dc',str(dst)],stdout=subprocess.PIPE)
with tarfile.open(fileobj=proc.stdout,mode='r|')as tar:
 for row in rows:
  m=tar.next();assert m.isfile()and m.name==row['member']and m.size==row['bytes']
  p=Path(row['path']);assert stamp(p)==row['stamp'];h=hashlib.sha256()
  with p.open('rb')as original:
   f=tar.extractfile(m)
   for b in iter(lambda:f.read(1024**2),b''):assert original.read(len(b))==b;h.update(b)
   assert not original.read(1)
  assert h.hexdigest()==row['sha256']and stamp(p)==row['stamp']
 assert tar.next()is None
proc.stdout.close();assert proc.wait()==0
rec=dict(schema='ownrt.completed-build-intermediates-archive.v1',archive=str(dst),archive_sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),full_archive_bytes_compared=True,all_object_hashes_match_build_receipts=True,members=rows,released_bytes=sum(r['bytes']for r in rows),scope='Only completed eight builds object intermediates; binaries, receipts, dependency files and runtime assets retained. Current reset build untouched.')
record=Path('/dev/shm/completed-build-objects-archive-20261028-r1.json');record.write_text(json.dumps(rec,indent=2)+'\n')
for row in rows:
 p=Path(row['path']);assert stamp(p)==row['stamp'];p.unlink()
rec['removal_completed']=True;record.write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({k:v for k,v in rec.items()if k!='members'}))
