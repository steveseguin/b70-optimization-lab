//.kernel _ZTSN4sycl3_V16detail19__pf_kernel_wrapperIZ5probeRNS0_5queueEPfPKfE20Packet115ModuleProbeEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1434157911 3610564493 -hashmovs1 0 1 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1434157911 3610564493 -hashmovs1 0 1 -GRFBumpUpNumber 2 "
//.instCount 69
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r4.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.12)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r4.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r4.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r3.4)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0046 (56)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0047 (57)  rf=r size=8 type=d alias=V0043+0 align=4 words (r2.6)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0049 (59)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.3)
//.declare V0050 (60)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r4.0)
//.declare V0051 (61)  rf=r size=8 type=ud alias=V0048+0 align=4 words (r2.10)
//.declare V0052 (62)  rf=r size=8 type=d alias=V0048+0 align=4 words (r2.10)
//.declare V0053 (63)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0056 (66)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0059 (69)  rf=r size=12 type=ud alias=V0036+0 align=2 words (r2.0)
//.declare V0063 (73)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0064 (74)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P01 (75)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0065 (76)  rf=r size=128 type=ud alias=V0063+0 align=32 words (r6.0)
//.declare V0066 (77)  rf=r size=8 type=ud alias=V0046+0 align=2 words (r2.8)
//.declare P02 (78)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P03 (79)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0067 (80)  rf=r size=128 type=ud alias=V0064+0 align=32 words (r8.0)
//.declare V0068 (81)  rf=r size=8 type=q align=4 words (r2.6)
//.declare V0069 (82)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r3.4)
//.declare V0073 (86)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0074 (87)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0076 (89)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0079 (92)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare V0083 (96)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0084 (97)  rf=r size=128 type=d align=32 words (r24.0)
//.declare P04 (98)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0085 (99)  rf=r size=128 type=ud alias=V0083+0 align=32 words (r22.0)
//.declare P05 (100)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P06 (101)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0086 (102)  rf=r size=128 type=ud alias=V0084+0 align=32 words (r24.0)
//.declare  (106)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (107)  rf=r size=4 type=ud align=32 words (r26.0)
//.declare  (108)  rf=r size=128 type=uw align=32 words (r27.0)
//.declare  (109)  rf=r size=128 type=uw align=32 words (r29.0)
//.declare  (112)  rf=r size=128 type=q align=32 words (r31.0)
//.declare  (113)  rf=r size=128 type=q align=32 words (r33.0)
//.declare  (114)  rf=r size=128 type=q align=32 words (r35.0)
//.declare  (115)  rf=r size=128 type=q align=32 words (r37.0)
//.declare  (118)  rf=r size=128 type=q align=32 words (r39.0)
//.declare  (119)  rf=r size=128 type=q align=32 words (r41.0)
//.declare  (124)  rf=r size=128 type=q align=32 words (r43.0)
//.declare  (125)  rf=r size=128 type=q align=32 words (r45.0)
//.declare  (128)  rf=r size=128 type=d align=32 words (r47.0)
//.declare  (129)  rf=r size=128 type=d align=32 words (r49.0)
//.declare  (130)  rf=r size=128 type=d alias=+0 align=32 words (r35.0)
//.declare  (131)  rf=r size=128 type=d alias=+0 align=32 words (r37.0)
//.declare  (132)  rf=r size=128 type=d alias=+0 align=32 words (r43.0)
//.declare  (133)  rf=r size=128 type=d alias=+0 align=32 words (r45.0)
//.declare r0 (134)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (135)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (136)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (137)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (138)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (139)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0045    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0037    | :d x 3   |    0xC | r3+0x10  | cti+0x30         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x20:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B006}
// _main:
(W)     mov (16|M0)              r4.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r4.2<0;1,0>:uw   {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r26.0<1>:ud   r2.3<0;1,0>:ud    r4.1<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r4.2<0;1,0>:uw                      //  ALU pipe: int; $4
(W)     mach (1|M0)              r5.0<1>:d     r2.3<0;1,0>:ud    r4.1<0;1,0>:ud                      //  ALU pipe: int; 
        mov (16|M0)              r27.0<4>:uw   r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r29.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.10<2>:ud   r26.0<0;1,0>:ud                  {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.11<2>:d    r5.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r2.8<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r31.0<1>:q    r2.5<0;1,0>:q     r27.0<4;1,0>:uw  {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r33.0<1>:q    r2.5<0;1,0>:q     r29.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r35.0<1>:q    r31.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r37.0<1>:q    r33.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r6.0<1>:d     r35.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r7.0<1>:d     r37.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r6.0<1;1,0>:ud    r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r8.0<1>:d     r35.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r9.0<1>:d     r37.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f1.0)  cmp (32|M0)   (eq)f1.0   null<1>:d     r8.0<1;1,0>:d     r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $18
(~f1.0) cmp (32|M0)   (lt)f1.0   null<1>:ud    r8.0<1;1,0>:ud    r2.9<0;1,0>:ud                      //  ALU pipe: int; $20
(~f1.0) goto (32|M0)                         _0_007            _0_007                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_008:
(W)     mov (1|M0)               r2.6<1>:q     r3.4<0;1,0>:ud                   {$1.dst}             //  ALU pipe: int; $24
// B004: [inDivergent],  Preds:{B005, B003},  Succs:{B005, B006}
_0_009:
        shl (16|M0)              r39.0<1>:q    r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $26
        shl (16|M16)             r41.0<1>:q    r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $26
        add (16|M0)              r10.0<1>:q    r39.0<1;1,0>:q    r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $27
        add (16|M16)             r12.0<1>:q    r41.0<1;1,0>:q    r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $27
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200580 // $29
        add (16|M0)              r43.0<1>:q    r35.0<1;1,0>:q    r2.6<0;1,0>:q                       //  ALU pipe: int; $35
        add (16|M16)             r45.0<1>:q    r37.0<1;1,0>:q    r2.6<0;1,0>:q                       //  ALU pipe: int; $35
        mov (16|M0)              r22.0<1>:d    r43.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $36
        mov (16|M16)             r23.0<1>:d    r45.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $37
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r22.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $40
        mov (16|M0)              r24.0<1>:d    r43.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $38
        mov (16|M16)             r25.0<1>:d    r45.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $39
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r24.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $41
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r24.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $43
        add (16|M0)              r18.0<1>:q    r39.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,$2.src} //  ALU pipe: int; $32
        add (16|M16)             r20.0<1>:q    r41.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted}        //  ALU pipe: int; $32
        mul (32|M0)              acc0.0<1>:f   r14.0<1;1,0>:f    0x3F900000:f               {Compacted,$3.dst} //  ALU pipe: float; $30
        add (32|M0)              r16.0<1>:f    acc0.0<1;1,0>:f   0x3E800000:f               {Compacted} //  ALU pipe: float; $31
        store.ugm.d32.a64 (32|M0)  [r18:4]      r16:2              {A@1,$2} // ex_desc:0x0; desc:0x8000584 // $34
(~f0.0) goto (32|M0)                         _0_007            _0_007                                //  ALU pipe: int; $45
// B005: [inDivergent],  Preds:{B004},  Succs:{B004}
_0_010:
(f0.0)  sel (32|M0)              r47.0<1>:d    r22.0<1;1,0>:d    r6.0<1;1,0>:d                       //  ALU pipe: int; $47 R{} IR{}{E:3,E:3,},  R{} IR{}{O:11,O:3,},  {BC=1}
(f0.0)  sel (32|M0)              r49.0<1>:d    r24.0<1;1,0>:d    r8.0<1;1,0>:d                       //  ALU pipe: int; $48 R{} IR{}{E:4,E:4,},  R{} IR{}{O:12,O:4,},  {BC=1}
        mov (16|M0)              r35.0<2>:d    r47.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $51
        mov (16|M16)             r37.0<2>:d    r48.0<1;1,0>:d                                        //  ALU pipe: int; $52
        mov (16|M0)              r35.1<2>:d    r49.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $53
        mov (16|M16)             r37.1<2>:d    r50.0<1;1,0>:d                                        //  ALU pipe: int; $54
(W)     jmpi                                 _0_009                                                  // $55
// B006: Preds:{B004, B002},  Succs:{}
_0_007:
        join (32|M0)                         L864                                                    // 
L864:
(W)     mov (16|M0)              r127.0<1>:f   r4.0<1;1,0>:f                    {Compacted,$1.src}   //  ALU pipe: float; $57
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$4} // wr:1+0, rd:0; end of thread // $57
L888:
(W)     mov (16|M0)              null<1>:ud    0x557B8357:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xD734D78D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1:ud                                                // 


//.BankConflicts: 2
//.ByteRMWs: 0
//


//.numALUInst: 60
//.accSubDef: 1
//.accSubUse: 1
//.accSubCandidateDef: 1
//.accSubCandidateUse: 1
//
//
//.singlePipeAtOneDistNum: 10
//.allAtOneDistNum: 4
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 3
//.AfterReadTokenDepCount: 3
