//.kernel _ZTSZZNK3p5111RouteKernelILj1EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1244745294 1452948054 -hashmovs1 0 19 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1244745294 1452948054 -hashmovs1 0 19 -GRFBumpUpNumber 2 "
//.instCount 1279
//.RA type	GRAPH_COLORING_FF_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill size 64

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r125.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=384 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=128 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r125.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r125.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r4.0)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r2.0)
//.declare V0040 (50)  rf=r size=64 type=w align=32 words (r3.0)
//.declare V0041 (51)  rf=r size=8 type=uq align=4 words (r6.4)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r6.5)
//.declare V0043 (53)  rf=r size=8 type=uq align=4 words (r6.6)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r5.14)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r5.15)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r6.0)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r6.1)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0057 (67)  rf=r size=4 type=d align=2 words (r6.3)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r6.4)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r6.5)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r6.6)
//.declare V0061 (71)  rf=r size=4 type=d align=2 words (r6.7)
//.declare V0065 (75)  rf=r size=768 type=d alias=%arg+0 align=32 words (r26.0)
//.declare V0067 (77)  rf=r size=512 type=d alias=%retval+0 align=32 words (r26.0)
//.declare V0069 (79)  rf=r size=8 type=uq alias=%sp+0 align=32 words (r127.3)
//.declare V0071 (81)  rf=r size=8 type=uq alias=%fp+0 align=32 words (r127.2)
//.declare V0072 (82)  rf=r size=4 type=ud align=2 words (r4.4)
//.declare V0074 (84)  rf=r size=4 type=ud align=2 words (r4.5)
//.declare V0076 (86)  rf=r size=4 type=ud align=2 words (r4.9)
//.declare V0077 (87)  rf=r size=4 type=ud align=2 words (r4.8)
//.declare V0078 (88)  rf=r size=4 type=ud align=32 words (r5.0)
//.declare V0080 (90)  rf=r size=8 type=uq align=32 words (r5.0)
//.declare V0081 (91)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0082 (92)  rf=r size=4 type=ud align=2 words (r4.4)
//.declare V0083 (93)  rf=r size=8 type=uq align=4 words (r74.0)
//.declare V0084 (94)  rf=r size=8 type=uq alias=V0051+0 align=4 words (r5.6)
//.declare V0085 (95)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0086 (96)  rf=r size=4 type=d align=32 words (r5.0)
//.declare P01 (97)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0087 (98)  rf=r size=8 type=uq alias=V0050+0 align=4 words (r5.5)
//.declare V0088 (99)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0090 (101)  rf=r size=256 type=uq align=32 words (r8.0)
//.declare V0091 (102)  rf=r size=256 type=ud alias=V0090+0 align=32 words (r8.0)
//.declare V0092 (103)  rf=r size=8 type=ud alias=V0088+0 align=32 words (r2.0)
//.declare V0093 (104)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0094 (105)  rf=r size=128 type=ud align=32 words (r2.0)
//.declare P02 (107)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0096 (108)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0097 (109)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r4.0)
//.declare V0098 (110)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r125.0)
//.declare V0099 (111)  rf=r size=8 type=ud alias=V0096+0 align=4 words (r4.4)
//.declare V0100 (112)  rf=r size=8 type=d alias=V0096+0 align=4 words (r4.4)
//.declare V0101 (113)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0104 (116)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare P03 (118)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0106 (119)  rf=r size=8 type=uq alias=V0049+0 align=4 words (r5.4)
//.declare V0107 (120)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0108 (121)  rf=r size=32 type=f align=32 words (r5.0)
//.declare P04 (122)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0109 (123)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P05 (124)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0110 (125)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P06 (126)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0111 (127)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P07 (128)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0112 (129)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P08 (130)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0113 (131)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P09 (132)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0114 (133)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P10 (134)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0115 (135)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P11 (136)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0116 (137)  rf=r size=4 type=f align=2 words (r1.8)
//.declare V0119 (140)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0120 (141)  rf=r size=32 type=f align=32 words (r1.0)
//.declare P12 (142)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0121 (143)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P13 (144)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0122 (145)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P14 (146)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0123 (147)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P15 (148)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0124 (149)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P16 (150)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0125 (151)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P17 (152)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0126 (153)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P18 (154)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0127 (155)  rf=r size=4 type=f align=2 words (r1.8)
//.declare P19 (156)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0128 (157)  rf=r size=4 type=f align=2 words (r2.8)
//.declare V0131 (160)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0132 (161)  rf=r size=32 type=f align=32 words (r2.0)
//.declare P20 (162)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0133 (163)  rf=r size=4 type=f align=2 words (r2.8)
//.declare P21 (164)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0134 (165)  rf=r size=4 type=f align=2 words (r2.8)
//.declare P22 (166)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0135 (167)  rf=r size=4 type=f align=2 words (r2.8)
//.declare P23 (168)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0136 (169)  rf=r size=4 type=f align=2 words (r2.8)
//.declare P24 (170)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0137 (171)  rf=r size=4 type=f align=2 words (r2.8)
//.declare P25 (172)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0138 (173)  rf=r size=4 type=f align=2 words (r2.8)
//.declare P26 (174)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0139 (175)  rf=r size=4 type=f align=2 words (r2.8)
//.declare P27 (176)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0140 (177)  rf=r size=4 type=f align=2 words (r3.8)
//.declare V0143 (180)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0144 (181)  rf=r size=32 type=f align=32 words (r3.0)
//.declare P28 (182)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0145 (183)  rf=r size=4 type=f align=2 words (r3.8)
//.declare P29 (184)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0146 (185)  rf=r size=4 type=f align=2 words (r3.8)
//.declare P30 (186)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0147 (187)  rf=r size=4 type=f align=2 words (r3.8)
//.declare P31 (188)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0148 (189)  rf=r size=4 type=f align=2 words (r3.8)
//.declare P32 (190)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0149 (191)  rf=r size=4 type=f align=2 words (r3.8)
//.declare P33 (192)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0150 (193)  rf=r size=4 type=f align=2 words (r3.8)
//.declare P34 (194)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0151 (195)  rf=r size=4 type=f align=2 words (r3.8)
//.declare P35 (196)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0152 (197)  rf=r size=4 type=f align=32 words (r4.0)
//.declare V0153 (198)  rf=r size=4 type=ud align=32 words (r7.0)
//.declare  (199)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (200)  rf=r size=32 type=ud align=32 words (r5.0)
//.declare P36 (201)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P37 (202)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P38 (203)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0154 (204)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r5.14)
//.declare P39 (205)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0158 (209)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0159 (210)  rf=r size=256 type=q align=32 words (r10.0)
//.declare V0160 (211)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0164 (215)  rf=r size=256 type=uq align=32 words (r8.0)
//.declare V0165 (216)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0166 (217)  rf=r size=128 type=ud alias=V0165+0 align=32 words (r6.0)
//.declare V0170 (221)  rf=r size=256 type=uq align=32 words (r8.0)
//.declare V0171 (222)  rf=r size=128 type=d align=32 words (r6.0)
//.declare P40 (223)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0175 (227)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare P41 (228)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0179 (232)  rf=r size=256 type=uq align=32 words (r8.0)
//.declare V0181 (234)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare V0182 (235)  rf=r size=128 type=w alias=V0181+0 align=32 words (r6.0)
//.declare V0184 (237)  rf=r size=128 type=d alias=V0160+0 align=32 words (r2.0)
//.declare V0185 (238)  rf=r size=4 type=f align=32 words (r5.0)
//.declare V0186 (239)  rf=r size=4 type=ud align=32 words (r5.0)
//.declare V0187 (240)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0188 (241)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0189 (242)  rf=r size=128 type=d alias=V0187+0 align=32 words (r60.0)
//.declare P42 (243)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0190 (244)  rf=r size=128 type=ud alias=V0188+0 align=32 words (r2.0)
//.declare P43 (245)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P44 (246)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P45 (247)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0191 (248)  rf=r size=128 type=f align=32 words (r6.0)
//.declare P46 (249)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0193 (251)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0194 (252)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0195 (253)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0196 (254)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0199 (257)  rf=r size=768 type=f alias=V0065+0 align=32 words (r26.0)
//.declare V0200 (258)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0201 (259)  rf=r size=512 type=f alias=V0067+0 align=32 words (r26.0)
//.declare V0203 (261)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0205 (263)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0208 (266)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0209 (267)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0211 (269)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0213 (271)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0214 (272)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0215 (273)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0219 (277)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0220 (278)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0222 (280)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0225 (283)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0226 (284)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0229 (287)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0231 (289)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0233 (291)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0236 (294)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0237 (295)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0239 (297)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0241 (299)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0242 (300)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0243 (301)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0247 (305)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0248 (306)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0250 (308)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0253 (311)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0254 (312)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0257 (315)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0259 (317)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0261 (319)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0264 (322)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0265 (323)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0267 (325)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0269 (327)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0270 (328)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0271 (329)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0275 (333)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0276 (334)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0278 (336)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0281 (339)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0282 (340)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0285 (343)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0287 (345)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0289 (347)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0292 (350)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0293 (351)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0295 (353)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0297 (355)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0298 (356)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0299 (357)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0303 (361)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0304 (362)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0306 (364)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0309 (367)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0310 (368)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0313 (371)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0315 (373)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0317 (375)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0320 (378)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0321 (379)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0323 (381)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0325 (383)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0326 (384)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0327 (385)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0331 (389)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0332 (390)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0334 (392)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0337 (395)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0338 (396)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0341 (399)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0343 (401)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0345 (403)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0348 (406)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0349 (407)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0351 (409)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0353 (411)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0354 (412)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0355 (413)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0359 (417)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0360 (418)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0362 (420)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0365 (423)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0366 (424)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0369 (427)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0371 (429)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0373 (431)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0376 (434)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0377 (435)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0379 (437)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0381 (439)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0382 (440)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0383 (441)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0387 (445)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0388 (446)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0390 (448)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0393 (451)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0394 (452)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0397 (455)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0399 (457)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0401 (459)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0404 (462)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0405 (463)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0407 (465)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0409 (467)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0410 (468)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0411 (469)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0415 (473)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0416 (474)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0418 (476)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0421 (479)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0422 (480)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0425 (483)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0427 (485)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0429 (487)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0432 (490)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0433 (491)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0435 (493)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0437 (495)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0438 (496)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0439 (497)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0443 (501)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0444 (502)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0446 (504)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0449 (507)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0450 (508)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0453 (511)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0455 (513)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0457 (515)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0460 (518)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0461 (519)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0463 (521)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0465 (523)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0466 (524)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0467 (525)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0471 (529)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0472 (530)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0474 (532)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0477 (535)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0478 (536)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0481 (539)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0483 (541)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0485 (543)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0488 (546)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0489 (547)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0491 (549)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0493 (551)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0494 (552)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0495 (553)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0498 (556)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0499 (557)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0501 (559)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0504 (562)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0505 (563)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0508 (566)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0510 (568)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0512 (570)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0515 (573)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0516 (574)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0518 (576)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0520 (578)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0521 (579)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0522 (580)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0525 (583)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0526 (584)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0528 (586)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0531 (589)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0532 (590)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0535 (593)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0537 (595)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0539 (597)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0542 (600)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0543 (601)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0545 (603)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0547 (605)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0548 (606)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0549 (607)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0552 (610)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0553 (611)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0555 (613)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0558 (616)  rf=r size=128 type=f align=32 words (r66.0)
//.declare P47 (617)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P48 (618)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0559 (619)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0560 (620)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0561 (621)  rf=r size=128 type=f alias=V0560+0 align=32 words (r64.0)
//.declare V0562 (622)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0565 (625)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0567 (627)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0569 (629)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0575 (635)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0576 (636)  rf=r size=128 type=d alias=V0575+0 align=32 words (r62.0)
//.declare V0577 (637)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0578 (638)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0579 (639)  rf=r size=128 type=f alias=V0578+0 align=32 words (r68.0)
//.declare V0580 (640)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0583 (643)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0585 (645)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0587 (647)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0588 (648)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0593 (653)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0594 (654)  rf=r size=128 type=ud alias=V0575+0 align=32 words (r62.0)
//.declare V0595 (655)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0596 (656)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0603 (663)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0604 (664)  rf=r size=128 type=f align=32 words (r2.0)
//.declare P49 (665)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P50 (666)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0609 (671)  rf=r size=128 type=f align=32 words (r2.0)
//.declare P51 (672)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P52 (673)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P53 (675)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0615 (680)  rf=r size=256 type=uq align=32 words (r1.0)
//.declare V0616 (681)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0618 (683)  rf=r size=64 type=uw alias=V0616+0 align=32 words (r1.0)
//.declare V0619 (684)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0620 (685)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0621 (686)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0622 (687)  rf=r size=128 type=uw alias=V0620+0 align=32 words (r2.0)
//.declare V0623 (688)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare A00 (689)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P54 (690)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0626 (693)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0627 (694)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0628 (695)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0629 (696)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0630 (697)  rf=r size=128 type=uw alias=V0628+0 align=32 words (r2.0)
//.declare V0631 (698)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare A01 (699)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P55 (700)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0634 (703)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0635 (704)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0636 (705)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0637 (706)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0638 (707)  rf=r size=128 type=uw alias=V0636+0 align=32 words (r2.0)
//.declare V0639 (708)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare A02 (709)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P56 (710)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0642 (713)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0643 (714)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0644 (715)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0645 (716)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0646 (717)  rf=r size=128 type=uw alias=V0644+0 align=32 words (r2.0)
//.declare V0647 (718)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare A03 (719)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P57 (720)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0650 (723)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0660 (733)  rf=r size=256 type=uq align=32 words (r1.0)
//.declare  (734)  rf=r size=4 type=ud alias=SR+28 align=2 words (r126.7) Output
//.declare  (735)  rf=r size=64 type=ud align=32 words (r112.0)
//.declare  (736)  rf=r size=4 type=d align=2 words (r4.3)
//.declare  (737)  rf=r size=4 type=ud align=32 words (r5.0)
//.declare  (738)  rf=r size=128 type=uw align=32 words (r2.0)
//.declare  (739)  rf=r size=128 type=uw align=32 words (r2.0)
//.declare  (740)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (741)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (742)  rf=r size=4 type=f align=2 words (r5.0)
//.declare  (745)  rf=r size=128 type=q align=32 words (r72.0)
//.declare  (746)  rf=r size=128 type=q align=32 words (r70.0)
//.declare  (747)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (748)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (751)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (752)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (755)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (756)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (759)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (760)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (763)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (764)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (767)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (768)  rf=r size=128 type=q align=32 words (r3.0)
//.declare  (769)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (770)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (773)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (774)  rf=r size=128 type=q align=32 words (r3.0)
//.declare  (775)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (776)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (777)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (778)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (781)  rf=r size=128 type=uq alias=+0 align=32 words (r8.0)
//.declare  (782)  rf=r size=128 type=uq alias=+0 align=32 words (r72.0)
//.declare  (783)  rf=r size=128 type=uq alias=+0 align=32 words (r3.0)
//.declare  (784)  rf=r size=128 type=uq alias=+0 align=32 words (r70.0)
//.declare  (785)  rf=r size=128 type=d alias=+0 align=32 words (r1.0)
//.declare  (786)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (787)  rf=r size=128 type=d alias=+0 align=32 words (r6.0)
//.declare  (788)  rf=r size=128 type=d alias=+0 align=32 words (r3.0)
//.declare  (789)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (790)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (791)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (792)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (793)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (794)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (795)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (796)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (797)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (798)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (799)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (800)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (801)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (802)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (803)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (804)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (805)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (806)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (807)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (808)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (809)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (810)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (811)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (812)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (813)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (814)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (815)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (816)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (817)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (818)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (819)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (820)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (821)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (822)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (823)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (824)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (825)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (826)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (827)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (828)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (829)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (830)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (831)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (832)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (833)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare be_fp (834)  rf=r size=4 type=ud align=2 words (r127.3)
//.declare be_sp (835)  rf=r size=4 type=ud align=2 words (r127.2)
//.declare SR (836)  rf=r size=64 type=ud align=32 words (r126.0)
//.declare VCE_SAVE (837)  rf=r size=4160 type=ud align=32 words (r60.0)
//.declare  (838)  rf=r size=3776 type=ud align=32 words
//.declare  (839)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (840)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (841)  rf=r size=3776 type=ud align=32 words
//.declare  (842)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (843)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (844)  rf=r size=3776 type=ud align=32 words
//.declare  (845)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (846)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (847)  rf=r size=3776 type=ud align=32 words
//.declare  (848)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (849)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (850)  rf=r size=3776 type=ud align=32 words
//.declare  (851)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (852)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (853)  rf=r size=3776 type=ud align=32 words
//.declare  (854)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (855)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (856)  rf=r size=3776 type=ud align=32 words
//.declare  (857)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (858)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (859)  rf=r size=3776 type=ud align=32 words
//.declare  (860)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (861)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (862)  rf=r size=3776 type=ud align=32 words
//.declare  (863)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (864)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (865)  rf=r size=3776 type=ud align=32 words
//.declare  (866)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (867)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (868)  rf=r size=3776 type=ud align=32 words
//.declare  (869)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (870)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (871)  rf=r size=3776 type=ud align=32 words
//.declare  (872)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (873)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (874)  rf=r size=3776 type=ud align=32 words
//.declare  (875)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (876)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (877)  rf=r size=3776 type=ud align=32 words
//.declare  (878)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (879)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (880)  rf=r size=3776 type=ud align=32 words
//.declare  (881)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (882)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (883)  rf=r size=3776 type=ud align=32 words
//.declare  (884)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (885)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (886)  rf=r size=3776 type=ud align=32 words
//.declare  (887)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (888)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (889)  rf=r size=3776 type=ud align=32 words
//.declare  (890)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (891)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (892)  rf=r size=3776 type=ud align=32 words
//.declare  (893)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (894)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (895)  rf=r size=3776 type=ud align=32 words
//.declare  (896)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (897)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (898)  rf=r size=3776 type=ud align=32 words
//.declare  (899)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (900)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (901)  rf=r size=3776 type=ud align=32 words
//.declare  (902)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (903)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (904)  rf=r size=3776 type=ud align=32 words
//.declare  (905)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (906)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (907)  rf=r size=3776 type=ud align=32 words
//.declare  (908)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (909)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (910)  rf=r size=3776 type=ud align=32 words
//.declare  (911)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (912)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (913)  rf=r size=3776 type=ud align=32 words
//.declare  (914)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (915)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (916)  rf=r size=3776 type=ud align=32 words
//.declare  (917)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (918)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (919)  rf=r size=3776 type=ud align=32 words
//.declare  (920)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (921)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (922)  rf=r size=3776 type=ud align=32 words
//.declare  (923)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (924)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (925)  rf=r size=3776 type=ud align=32 words
//.declare  (926)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (927)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (928)  rf=r size=3776 type=ud align=32 words
//.declare  (929)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (930)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (931)  rf=r size=3776 type=ud align=32 words
//.declare  (932)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (933)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (934)  rf=r size=3776 type=ud align=32 words
//.declare  (935)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (936)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (937)  rf=r size=3776 type=ud align=32 words
//.declare  (938)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (939)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (940)  rf=r size=3776 type=ud align=32 words
//.declare  (941)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (942)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (943)  rf=r size=3776 type=ud align=32 words
//.declare  (944)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (945)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (946)  rf=r size=3776 type=ud align=32 words
//.declare  (947)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (948)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (949)  rf=r size=3776 type=ud align=32 words
//.declare  (950)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (951)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (952)  rf=r size=3776 type=ud align=32 words
//.declare  (953)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (954)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (955)  rf=r size=3776 type=ud align=32 words
//.declare  (956)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (957)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (958)  rf=r size=3776 type=ud align=32 words
//.declare  (959)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (960)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (961)  rf=r size=3776 type=ud align=32 words
//.declare  (962)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (963)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (964)  rf=r size=3776 type=ud align=32 words
//.declare  (965)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (966)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (967)  rf=r size=3776 type=ud align=32 words
//.declare  (968)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (969)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (970)  rf=r size=3776 type=ud align=32 words
//.declare  (971)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (972)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (973)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (974)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (975)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (976)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (977)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (978)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (979)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (980)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (981)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (982)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (983)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (984)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (985)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (986)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (987)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (988)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (989)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (990)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (991)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (992)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (993)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (994)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (995)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (996)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (997)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (998)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (999)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1000)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1001)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1002)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1003)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1004)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1005)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1006)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1007)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1008)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1009)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1010)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1011)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1012)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1013)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1014)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1015)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1016)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1017)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1018)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1019)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1020)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1021)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (1038)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1039)  rf=r size=4 type=ud align=32 words NoSpill Input_Output
//.declare  (1040)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1041)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1042)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1043)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1044)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1045)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1046)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1047)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1048)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1049)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1050)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1051)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1052)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1053)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1054)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1055)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1056)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1057)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1058)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1059)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1060)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1061)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1062)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1063)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1064)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1065)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1066)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1067)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1068)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1069)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1070)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1071)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1072)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1073)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1074)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1075)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1076)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1077)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1078)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1079)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1080)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1081)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1082)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1083)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1084)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1085)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1086)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1087)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1088)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1089)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1090)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1091)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1092)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1093)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1094)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1095)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1096)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1097)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1098)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1099)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1100)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1101)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1102)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1103)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1104)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1105)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1106)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1107)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1108)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1109)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1110)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1111)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1112)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1113)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1114)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1115)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1116)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1117)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1118)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1119)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1120)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1121)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1122)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1123)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1124)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1125)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1126)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1127)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (1128)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare r0 (1129)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (1130)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (1131)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (1132)  rf=r size=32 type=ud align=2 words (r4.0)
//.declare  (1133)  rf=r size=128 type=ud align=32 words (r1.0)
//.declare  (1134)  rf=r size=64 type=ud align=32 words (r3.0)
//.declare  (1135)  rf=r size=128 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0039    | :w x 32  |   0x40 | r2       | pti[tid]+0x40    |
// | V0040    | :w x 32  |   0x40 | r3       | pti[tid]+0x80    |
// | V0037    | :d x 3   |    0xC | r4       | inline+0x0       |
// | V0082    | :ud      |    0x4 | r4+0x10  | inline+0x10      |
// | V0044    | :q       |    0x8 | r4+0x18  | inline+0x18      |
// | V0045    | :q       |    0x8 | r5       | cti+0x20         |
// | V0046    | :q       |    0x8 | r5+0x8   | cti+0x28         |
// | V0047    | :q       |    0x8 | r5+0x10  | cti+0x30         |
// | V0048    | :q       |    0x8 | r5+0x18  | cti+0x38         |
// | V0049    | :q       |    0x8 | r5+0x20  | cti+0x40         |
// | V0050    | :q       |    0x8 | r5+0x28  | cti+0x48         |
// | V0051    | :q       |    0x8 | r5+0x30  | cti+0x50         |
// | V0052    | :d       |    0x4 | r5+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r5+0x3C  | cti+0x5C         |
// | V0054    | :d       |    0x4 | r6       | cti+0x60         |
// | V0055    | :d       |    0x4 | r6+0x4   | cti+0x64         |
// | V0056    | :d       |    0x4 | r6+0x8   | cti+0x68         |
// | V0057    | :d       |    0x4 | r6+0xC   | cti+0x6C         |
// | V0058    | :d       |    0x4 | r6+0x10  | cti+0x70         |
// | V0059    | :d       |    0x4 | r6+0x14  | cti+0x74         |
// | V0060    | :d       |    0x4 | r6+0x18  | cti+0x78         |
// | V0061    | :d       |    0x4 | r6+0x1C  | cti+0x7C         |
// | V0041    | :uq      |    0x8 | r6+0x20  | cti+0x80         |
// | V0042    | :uq      |    0x8 | r6+0x28  | cti+0x88         |
// | V0043    | :uq      |    0x8 | r6+0x30  | cti+0x90         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0xC0:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r4.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r1:2 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r3:1 bti[255][r127:1+0x80]  {$1} // ex_desc:0xFF080000; desc:0x6219D500 // 
        nop                                                                                          // 
        nop                                                                                          // 
        nop                                                                                          // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
        sync.nop                             null                             {Compacted,$1.src}     // 
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r5:2 bti[255][r127:1]   {I@1,$2} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B085}
// _main:
(W)     mov (16|M0)              r125.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; 
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; 
(W)     mov (1|M0)               r127.3<1>:f   0x0:f                               {$2.src}          //  (0x00000000:f); ALU pipe: float; 
(W)     mov (16|M0)              r126.0<1>:f   r125.0<1;1,0>:f                  {Compacted,I@2}      //  ALU pipe: float; 
(W)     mov (1|M0)               r127.2<1>:f   0x40:f                                                //  (0x00000040:f); ALU pipe: float; 
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud              {F@2}       //  ALU pipe: int; 
(W)     and (1|M0)               r126.7<1>:ud  r125.5<0;1,0>:ud  0xFFFFFC00:ud                       //  ALU pipe: int; 
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     and (1|M0)               r4.4<1>:ud    msg0.0<0;1,0>:ud  0xFF:uw              {A@1}          //  ALU pipe: int; $2
(W)     and (1|M0)               r4.5<1>:ud    sr0.0<0;1,0>:ud   0x7F:uw              {A@1}          //  ALU pipe: int; $3
(W)     and (1|M0)               r4.8<1>:ud    r4.5<0;1,0>:ud    7:w               {A@1}             //  ALU pipe: int; $5
(W)     asr (1|M0)               r4.9<1>:ud    r4.5<0;1,0>:ud    1:w                                 //  ALU pipe: int; $6
(W)     mov (1|M0)               r4.3<1>:d     -8:w                                                  //  ALU pipe: int; $7
(W)     shl (1|M0)               r4.4<1>:ud    r4.4<0;1,0>:ud    0x6:uw                              //  ALU pipe: int; $4
(W)     bfn.(s0&s1|s2) (1|M0)    r4.5<1>:ud    r4.9<0;0>:ud      r4.3<0;0>:ud      r4.8<0>:ud       {I@2} //  ALU pipe: int; $7
(W)     mov (1|M0)               r2.0<1>:uq    0x0:uw                              {$0.dst}          //  ALU pipe: int; $13
(W)     or (1|M0)                r4.4<1>:ud    r4.4<0;1,0>:ud    r4.5<0;1,0>:ud   {I@2}              //  ALU pipe: int; $8
(W)     mov (1|M0)               r74.0<1>:ud   0x6E10CA2E:ud                                         //  R_SYM_ADDR_32: fmaf; ALU pipe: int; $17
(W)     mul (1|M0)               acc0.0<1>:ud  r4.4<0;1,0>:ud    0x1400:uw              {I@2}        //  ALU pipe: int; $9
(W)     macl (1|M0)              r5.0<1>:ud    r4.4<0;1,0>:ud    0x21400:ud              {$2.dst}    //  ALU pipe: int; $10
(W)     mov (1|M0)               r74.1<1>:ud   0x6E10CA2E:ud                                         //  R_SYM_ADDR_32_HI: fmaf; ALU pipe: int; $17
(W)     add (1|M0)               r127.3<1>:uq  r6.6<0;1,0>:uq    r5.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $10
(W)     mov (1|M0)               r127.2<1>:uq  r127.3<0;1,0>:uq                 {I@1}                //  ALU pipe: int; $11
(W)     add (1|M0)               r127.3<1>:uq  r127.3<0;1,0>:uq  0x10:uw                             //  ALU pipe: int; $12
(W)     mov (1|M0)               r5.0<1>:uq    r127.2<0;1,0>:uq                 {Compacted,I@2}      //  ALU pipe: int; $14
(W)     store.ugm.d64x1t.a64 (1|M0)  [r5:1]     r2:1               {I@1,$3} // ex_desc:0x0; desc:0x2008784 // $16
(W)     mov (1|M0)               r2.0<1>:uq    r5.6<0;1,0>:uq                   {Compacted,$3.src}   //  ALU pipe: int; $18
(W)     load.ugm.d32x1t.a64 (1|M0)  r5:1        [r2:1]             {I@1,$4} // ex_desc:0x0; desc:0x2108580 // $19
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r5.0<0;1,0>:d     0:w               {$4.dst}          //  ALU pipe: int; $20
(W&f3.0) jmpi                                _0_049                                                  //  ALU pipe: int; $21
// B003: Preds:{B002},  Succs:{B004, B085}
_0_050:
(W)     mov (1|M0)               r2.0<1>:uq    r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $23
        mov (32|M0)              r6.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $26
        mov (16|M0)              r8.0<2>:f     r2.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $24
        mov (16|M16)             r10.0<2>:f    r2.0<0;1,0>:f                                         //  ALU pipe: float; $24
        mov (16|M0)              r8.1<2>:f     r2.1<0;1,0>:f                                         //  ALU pipe: float; $25
        mov (16|M16)             r10.1<2>:ud   r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $25
        atomic_or.ugm.d32.a64 (32|M0)  r2:2     [r8:4]            r6:2               {A@1,$1} // ex_desc:0x0; desc:0x8200599 // $27
        cmp (32|M0)   (eq)f2.0   null<1>:d     r2.0<1;1,0>:d     0:w               {$1.dst}          //  ALU pipe: int; $29
(~f2.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $30
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B006}
_0_051:
(W)     mul (1|M0)               acc0.0<1>:ud  r4.0<0;1,0>:ud    r125.2<0;1,0>:uw                    //  ALU pipe: int; $32
(W)     macl (1|M0)              r5.0<1>:ud    r4.0<0;1,0>:ud    r125.1<0;1,0>:ud {Compacted}        //  ALU pipe: int; $33
(W)     mul (1|M0)               acc0.0<1>:ud  r4.0<0;1,0>:ud    r125.2<0;1,0>:uw                    //  ALU pipe: int; $33
(W)     mach (1|M0)              r4.0<1>:d     r4.0<0;1,0>:ud    r125.1<0;1,0>:ud                    //  ALU pipe: int; 
        mov (16|M0)              r2.0<4>:uw    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $39
        cmp (32|M0)   (eq)f1.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $40
(W)     mov (1|M0)               r4.4<2>:ud    r5.0<0;1,0>:ud                   {Compacted,I@5}      //  ALU pipe: int; $33
(W)     mov (1|M0)               r4.5<2>:d     r4.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $37
        add (16|M0)              r72.0<1>:q    r4.2<0;1,0>:q     r2.0<4;1,0>:uw   {I@1}              //  ALU pipe: int; $39
        mov (16|M16)             r2.0<4>:uw    r1.16<1;1,0>:uw                                       //  ALU pipe: int; $39
        add (16|M16)             r70.0<1>:q    r4.2<0;1,0>:q     r2.0<4;1,0>:uw   {I@1}              //  ALU pipe: int; $39
(~f1.0) goto (32|M0)                         _0_052            _0_052                                //  ALU pipe: int; $41
// B005: [inDivergent],  Preds:{B004},  Succs:{B006}
_0_053:
(W)     mov (1|M0)               r4.0<1>:uq    r5.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $43
(W)     add (1|M0)               r2.0<1>:q     r5.4<0;1,0>:q     32:w               {Compacted}      //  ALU pipe: int; $61
(W)     load.ugm.d32x8t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$5} // ex_desc:0x0; desc:0x210C580 // $44
(W)     load.ugm.d32x8t.a64 (1|M0)  r1:1        [r2:1]             {$6} // ex_desc:0x0; desc:0x210C580 // $63
(W)     add (1|M0)               r6.0<1>:q     r5.4<0;1,0>:q     64:w               {Compacted,$5.dst} //  ALU pipe: int; $80
(W)     add (1|M0)               r8.0<1>:q     r5.4<0;1,0>:q     96:w               {Compacted}      //  ALU pipe: int; $99
        sync.nop                             null                             {Compacted,$6.src}     // $82
(W)     load.ugm.d32x8t.a64 (1|M0)  r2:1        [r6:1]             {I@2,$7} // ex_desc:0x0; desc:0x210C580 // $82
(W)     load.ugm.d32x8t.a64 (1|M0)  r3:1        [r8:1]             {I@1,$8} // ex_desc:0x0; desc:0x210C580 // $101
(W)     mov (1|M0)               r7.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $118
(W)     sel (1|M0)    (gt)f0.0   r1.8<1>:f     r5.0<0;1,0>:f     0xFF800000:f               {$6.dst} //  ALU pipe: float; $46
(W)     cmp (1|M0)    (lt)f0.0   null<1>:f     r1.8<0;1,0>:f     r5.1<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $47
(W&f0.0) sel (1|M0)              r1.8<1>:f     r5.1<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $48
(W)     cmp (1|M0)    (lt)f3.0   null<1>:f     r1.8<0;1,0>:f     r5.2<0;1,0>:f    {F@1}              //  ALU pipe: float; $49
(W&f3.0) sel (1|M0)              r1.8<1>:f     r5.2<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $50
(W)     cmp (1|M0)    (lt)f2.0   null<1>:f     r1.8<0;1,0>:f     r5.3<0;1,0>:f    {F@1}              //  ALU pipe: float; $51
(W&f2.0) sel (1|M0)              r1.8<1>:f     r5.3<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $52
(W)     cmp (1|M0)    (lt)f1.0   null<1>:f     r1.8<0;1,0>:f     r5.4<0;1,0>:f    {F@1}              //  ALU pipe: float; $53
(W&f1.0) sel (1|M0)              r1.8<1>:f     r5.4<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $54
(W)     cmp (1|M0)    (lt)f0.0   null<1>:f     r1.8<0;1,0>:f     r5.5<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $55
(W&f0.0) sel (1|M0)              r1.8<1>:f     r5.5<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $56
(W)     cmp (1|M0)    (lt)f3.0   null<1>:f     r1.8<0;1,0>:f     r5.6<0;1,0>:f    {F@1}              //  ALU pipe: float; $57
(W&f3.0) sel (1|M0)              r1.8<1>:f     r5.6<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $58
(W)     cmp (1|M0)    (lt)f2.0   null<1>:f     r1.8<0;1,0>:f     r5.7<0;1,0>:f    {F@1}              //  ALU pipe: float; $59
(W&f2.0) sel (1|M0)              r1.8<1>:f     r5.7<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $60
(W)     cmp (1|M0)    (lt)f1.0   null<1>:f     r1.8<0;1,0>:f     r1.0<0;1,0>:f    {F@1}              //  ALU pipe: float; $64
(W&f1.0) sel (1|M0)              r1.8<1>:f     r1.0<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $65
(W)     cmp (1|M0)    (lt)f0.0   null<1>:f     r1.8<0;1,0>:f     r1.1<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $66
(W&f0.0) sel (1|M0)              r1.8<1>:f     r1.1<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $67
(W)     cmp (1|M0)    (lt)f3.0   null<1>:f     r1.8<0;1,0>:f     r1.2<0;1,0>:f    {F@1}              //  ALU pipe: float; $68
(W&f3.0) sel (1|M0)              r1.8<1>:f     r1.2<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $69
(W)     cmp (1|M0)    (lt)f2.0   null<1>:f     r1.8<0;1,0>:f     r1.3<0;1,0>:f    {F@1}              //  ALU pipe: float; $70
(W&f2.0) sel (1|M0)              r1.8<1>:f     r1.3<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $71
(W)     cmp (1|M0)    (lt)f1.0   null<1>:f     r1.8<0;1,0>:f     r1.4<0;1,0>:f    {F@1}              //  ALU pipe: float; $72
(W&f1.0) sel (1|M0)              r1.8<1>:f     r1.4<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $73
(W)     cmp (1|M0)    (lt)f0.0   null<1>:f     r1.8<0;1,0>:f     r1.5<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $74
(W&f0.0) sel (1|M0)              r1.8<1>:f     r1.5<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $75
(W)     cmp (1|M0)    (lt)f3.0   null<1>:f     r1.8<0;1,0>:f     r1.6<0;1,0>:f    {F@1}              //  ALU pipe: float; $76
(W&f3.0) sel (1|M0)              r1.8<1>:f     r1.6<0;1,0>:f     r1.8<0;1,0>:f                       //  ALU pipe: float; $77
(W)     cmp (1|M0)    (lt)f2.0   null<1>:f     r1.8<0;1,0>:f     r1.7<0;1,0>:f    {F@1}              //  ALU pipe: float; $78
(W&f2.0) sel (1|M0)              r2.8<1>:f     r1.7<0;1,0>:f     r1.8<0;1,0>:f    {$7.dst}           //  ALU pipe: float; $79
(W)     cmp (1|M0)    (lt)f1.0   null<1>:f     r2.8<0;1,0>:f     r2.0<0;1,0>:f    {F@1}              //  ALU pipe: float; $83
(W&f1.0) sel (1|M0)              r2.8<1>:f     r2.0<0;1,0>:f     r2.8<0;1,0>:f                       //  ALU pipe: float; $84
(W)     cmp (1|M0)    (lt)f0.0   null<1>:f     r2.8<0;1,0>:f     r2.1<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $85
(W&f0.0) sel (1|M0)              r2.8<1>:f     r2.1<0;1,0>:f     r2.8<0;1,0>:f                       //  ALU pipe: float; $86
(W)     cmp (1|M0)    (lt)f3.0   null<1>:f     r2.8<0;1,0>:f     r2.2<0;1,0>:f    {F@1}              //  ALU pipe: float; $87
(W&f3.0) sel (1|M0)              r2.8<1>:f     r2.2<0;1,0>:f     r2.8<0;1,0>:f                       //  ALU pipe: float; $88
(W)     cmp (1|M0)    (lt)f2.0   null<1>:f     r2.8<0;1,0>:f     r2.3<0;1,0>:f    {F@1}              //  ALU pipe: float; $89
(W&f2.0) sel (1|M0)              r2.8<1>:f     r2.3<0;1,0>:f     r2.8<0;1,0>:f                       //  ALU pipe: float; $90
(W)     cmp (1|M0)    (lt)f1.0   null<1>:f     r2.8<0;1,0>:f     r2.4<0;1,0>:f    {F@1}              //  ALU pipe: float; $91
(W&f1.0) sel (1|M0)              r2.8<1>:f     r2.4<0;1,0>:f     r2.8<0;1,0>:f                       //  ALU pipe: float; $92
(W)     cmp (1|M0)    (lt)f0.0   null<1>:f     r2.8<0;1,0>:f     r2.5<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $93
(W&f0.0) sel (1|M0)              r2.8<1>:f     r2.5<0;1,0>:f     r2.8<0;1,0>:f                       //  ALU pipe: float; $94
(W)     cmp (1|M0)    (lt)f3.0   null<1>:f     r2.8<0;1,0>:f     r2.6<0;1,0>:f    {F@1}              //  ALU pipe: float; $95
(W&f3.0) sel (1|M0)              r2.8<1>:f     r2.6<0;1,0>:f     r2.8<0;1,0>:f                       //  ALU pipe: float; $96
(W)     cmp (1|M0)    (lt)f2.0   null<1>:f     r2.8<0;1,0>:f     r2.7<0;1,0>:f    {F@1}              //  ALU pipe: float; $97
(W&f2.0) sel (1|M0)              r3.8<1>:f     r2.7<0;1,0>:f     r2.8<0;1,0>:f    {$8.dst}           //  ALU pipe: float; $98
(W)     cmp (1|M0)    (lt)f1.0   null<1>:f     r3.8<0;1,0>:f     r3.0<0;1,0>:f    {F@1}              //  ALU pipe: float; $102
(W&f1.0) sel (1|M0)              r3.8<1>:f     r3.0<0;1,0>:f     r3.8<0;1,0>:f                       //  ALU pipe: float; $103
(W)     cmp (1|M0)    (lt)f0.0   null<1>:f     r3.8<0;1,0>:f     r3.1<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $104
(W&f0.0) sel (1|M0)              r3.8<1>:f     r3.1<0;1,0>:f     r3.8<0;1,0>:f                       //  ALU pipe: float; $105
(W)     cmp (1|M0)    (lt)f3.0   null<1>:f     r3.8<0;1,0>:f     r3.2<0;1,0>:f    {F@1}              //  ALU pipe: float; $106
(W&f3.0) sel (1|M0)              r3.8<1>:f     r3.2<0;1,0>:f     r3.8<0;1,0>:f                       //  ALU pipe: float; $107
(W)     cmp (1|M0)    (lt)f2.0   null<1>:f     r3.8<0;1,0>:f     r3.3<0;1,0>:f    {F@1}              //  ALU pipe: float; $108
(W&f2.0) sel (1|M0)              r3.8<1>:f     r3.3<0;1,0>:f     r3.8<0;1,0>:f                       //  ALU pipe: float; $109
(W)     cmp (1|M0)    (lt)f1.0   null<1>:f     r3.8<0;1,0>:f     r3.4<0;1,0>:f    {F@1}              //  ALU pipe: float; $110
(W&f1.0) sel (1|M0)              r3.8<1>:f     r3.4<0;1,0>:f     r3.8<0;1,0>:f                       //  ALU pipe: float; $111
(W)     cmp (1|M0)    (lt)f0.0   null<1>:f     r3.8<0;1,0>:f     r3.5<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $112
(W&f0.0) sel (1|M0)              r3.8<1>:f     r3.5<0;1,0>:f     r3.8<0;1,0>:f                       //  ALU pipe: float; $113
(W)     cmp (1|M0)    (lt)f3.0   null<1>:f     r3.8<0;1,0>:f     r3.6<0;1,0>:f    {F@1}              //  ALU pipe: float; $114
(W&f3.0) sel (1|M0)              r3.8<1>:f     r3.6<0;1,0>:f     r3.8<0;1,0>:f                       //  ALU pipe: float; $115
(W)     cmp (1|M0)    (lt)f2.0   null<1>:f     r3.8<0;1,0>:f     r3.7<0;1,0>:f    {F@1}              //  ALU pipe: float; $116
(W&f2.0) sel (1|M0)              r4.0<1>:f     r3.7<0;1,0>:f     r3.8<0;1,0>:f                       //  ALU pipe: float; $117
(W)     store.slm.d32x1t.a32 (1|M0)  [r7:1]     r4:1               {A@1,$9} // ex_desc:0x0; desc:0x2008504 // $119
// B006: [inDivergent],  Preds:{B005, B004},  Succs:{B007, B014}
_0_052:
        join (32|M0)                         _0_049                                                  // 
L2096:
(W)     send.slm (1|M0)          r1       r125  null:0  0x0            0x0210001F           {$10} // wr:1+0, rd:1; fence.slm.none.group // $121
(W)     mov (1|M0)               r5.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $122
(W)     mov (2|M0)               r5.10<1>:ub   r125.11<0;1,0>:ub                {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $122
(W)     mov (8|M0)               null<1>:ud    r1.0<1;1,0>:ud                   {Compacted,$10.dst}  //  memory fence commit; ALU pipe: int; $122
(W)     send.gtwy (1|M0)         null     r5  null:0  0x0            0x02000004           {I@2,$11} // wr:1+0, rd:0; signal barrier // $122
(W)     sync.bar                             0x0                                                     // $122
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r5.14<0;1,0>:d    2:w                                 //  ALU pipe: int; $123
(W&f1.0) jmpi                                _0_054                                                  //  ALU pipe: int; $124
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B013}
_0_055:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r5.14<0;1,0>:d    2:w                                 //  ALU pipe: int; $126
(W&f0.0) jmpi                                _0_056                                                  //  ALU pipe: int; $127
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B012}
_0_057:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r5.14<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $129
(W&f3.0) jmpi                                _0_058                                                  //  ALU pipe: int; $130
// B009: [inDivergent],  Preds:{B008},  Succs:{B010, B011}
_0_059:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r5.14<0;1,0>:d    4:w                                 //  ALU pipe: int; $132
(W&~f2.0) jmpi                               _0_060                                                  //  ALU pipe: int; $133
// B010: [inDivergent],  Preds:{B009},  Succs:{B019}
_0_061:
        shl (16|M0)              r10.0<1>:q    r72.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $135
        shl (16|M16)             r1.0<1>:q     r70.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $135
        add (16|M0)              r6.0<1>:q     r10.0<1;1,0>:q    r4.3<0;1,0>:q    {Compacted,@2,$9.src} //  ALU pipe: int; $136
        add (16|M16)             r8.0<1>:q     r1.0<1;1,0>:q     r4.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $136
        load.ugm.d64.a64 (32|M0)  r10:4         [r6:4]             {I@1,$12} // ex_desc:0x0; desc:0x8400780 // $138
        mov (16|M0)              r6.0<2>:f     r10.0<1;1,0>:q                   {$12.dst}            //  ALU pipe: float; $139
        mov (16|M0)              r2.0<1>:ud    r6.0<2;1,0>:ud                   {Compacted,F@1}      //  ALU pipe: int; $139
        mov (16|M16)             r6.0<2>:f     r12.0<1;1,0>:q                   {I@1}                //  ALU pipe: float; $139
        mov (16|M16)             r3.0<1>:ud    r6.0<2;1,0>:ud                   {Compacted,F@1}      //  ALU pipe: int; $139
(W)     jmpi                                 _0_062                                                  // $140
// B011: [inDivergent],  Preds:{B009},  Succs:{B019}
_0_060:
        mov (32|M0)              r2.0<1>:ud    0x0:ud                              {Compacted}       //  ALU pipe: int; $142
(W)     jmpi                                 _0_062                                                  // $143
// B012: [inDivergent],  Preds:{B008},  Succs:{B019}
_0_058:
        shl (16|M0)              r12.0<1>:q    r72.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $145
        shl (16|M16)             r6.0<1>:q     r70.0<1;1,0>:q    2:w               {Compacted,$9.src} //  ALU pipe: int; $145
        add (16|M0)              r8.0<1>:q     r12.0<1;1,0>:q    r4.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $146
        add (16|M16)             r10.0<1>:q    r6.0<1;1,0>:q     r4.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $146
        load.ugm.d32.a64 (32|M0)  r6:2          [r8:4]             {I@1,$13} // ex_desc:0x0; desc:0x8200580 // $148
        mov (32|M0)              r2.0<1>:f     r6.0<1;1,0>:ud                   {$13.dst}            //  ALU pipe: float; $149
(W)     jmpi                                 _0_062                                                  // $150
// B013: [inDivergent],  Preds:{B007},  Succs:{B019}
_0_056:
        shl (16|M0)              r12.0<1>:q    r72.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $152
        sync.nop                             null                             {Compacted,F@1}        // $152
        shl (16|M16)             r6.0<1>:q     r70.0<1;1,0>:q    2:w               {Compacted,$9.src} //  ALU pipe: int; $152
        add (16|M0)              r8.0<1>:q     r12.0<1;1,0>:q    r4.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $153
        add (16|M16)             r10.0<1>:q    r6.0<1;1,0>:q     r4.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $153
        load.ugm.d32.a64 (32|M0)  r6:2          [r8:4]             {I@1,$14} // ex_desc:0x0; desc:0x8200580 // $155
        mov (32|M0)              r2.0<1>:f     r6.0<1;1,0>:d                    {$14.dst}            //  ALU pipe: float; $156
(W)     jmpi                                 _0_062                                                  // $157
// B014: [inDivergent],  Preds:{B006},  Succs:{B015, B016}
_0_054:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r5.14<0;1,0>:d    1:w                                 //  ALU pipe: int; $159
(W&f1.0) jmpi                                _0_063                                                  //  ALU pipe: int; $160
// B015: [inDivergent],  Preds:{B014},  Succs:{B019}
_0_064:
        shl (16|M0)              r12.0<1>:q    r72.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $162
        shl (16|M16)             r10.0<1>:q    r70.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $162
        sync.nop                             null                             {Compacted,A@1}        // $163
        add (16|M0)              r6.0<1>:q     r12.0<1;1,0>:q    r4.3<0;1,0>:q    {Compacted,$9.src} //  ALU pipe: int; $163
        add (16|M16)             r8.0<1>:q     r10.0<1;1,0>:q    r4.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $163
        load.ugm.d32.a64 (32|M0)  r2:2          [r6:4]             {I@1,$15} // ex_desc:0x0; desc:0x8200580 // $165
(W)     jmpi                                 _0_062                                                  // $166
// B016: [inDivergent],  Preds:{B014},  Succs:{B017, B018}
_0_063:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r5.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $168
(W&~f0.0) jmpi                               _0_065                                                  //  ALU pipe: int; $169
// B017: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_066:
        shl (16|M0)              r12.0<1>:q    r72.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $171
        shl (16|M16)             r6.0<1>:q     r70.0<1;1,0>:q    1:w               {Compacted,$9.src} //  ALU pipe: int; $171
        add (16|M0)              r8.0<1>:q     r12.0<1;1,0>:q    r4.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $172
        add (16|M16)             r10.0<1>:q    r6.0<1;1,0>:q     r4.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $172
        load.ugm.d16u32.a64 (32|M0)  r6:2       [r8:4]             {I@1,$0} // ex_desc:0x0; desc:0x8200B80 // $174
        shl (32|M0)              r2.0<1>:d     r6.0<1;1,0>:ud    16:w               {$0.dst}         //  ALU pipe: int; $175
(W)     jmpi                                 _0_062                                                  // $176
// B018: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_065:
        mov (32|M0)              r2.0<1>:ud    0x0:ud                              {Compacted}       //  ALU pipe: int; $178
// B019: [inDivergent],  Preds:{B018, B017, B015, B013, B012, B011, B010},  Succs:{B020, B082}
_0_062:
(W)     mov (1|M0)               r5.0<1>:ud    0x0:uw                              {$11.src}         //  ALU pipe: int; $180
(W)     load.slm.d32x1t.a32 (1|M0)  r5:1        [r5:1]             {I@1,$1} // ex_desc:0x0; desc:0x2108500 // $181
        sync.nop                             null                             {Compacted,$1.dst}     // $182
        add (32|M0)              r60.0<1>:f    r2.0<1;1,0>:f     -r5.0<0;1,0>:f   {$15.dst}          //  ALU pipe: float; $182
        and (32|M0)              r2.0<1>:d     r60.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $183
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r2.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $184
(f3.0)  goto (32|M0)                         _0_067            _0_067                                //  ALU pipe: int; $185
// B020: [inDivergent],  Preds:{B019},  Succs:{B021, B081}
_0_068:
        cmp (32|M0)   (ge)f2.0   null<1>:f     r60.0<1;1,0>:f    0x42B17218:f                        //  ALU pipe: float; $187
(f2.0)  goto (32|M0)                         _0_069            _0_069                                //  ALU pipe: int; $188
// B021: [inDivergent],  Preds:{B020},  Succs:{B022, B080}
_0_070:
        cmp (32|M0)   (le)f1.0   null<1>:f     r60.0<1;1,0>:f    0xC2CFF1B5:f                        //  ALU pipe: float; $190
(f1.0)  goto (32|M0)                         _0_071            _0_071                                //  ALU pipe: int; $191
// B022: [inDivergent],  Preds:{B021},  Succs:{B023, B079}
_0_072:
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r2.0<1;1,0>:ud    0x33000000:ud                       //  ALU pipe: int; $193
(f0.0)  goto (32|M0)                         _0_073            _0_073                                //  ALU pipe: int; $194
// B023: [FCALL],  [inDivergent],  Preds:{B022},  Succs:{B024}
_0_074:
        sync.nop                             null                             {Compacted,I@4}        // $196
        mul (32|M0)   (ge)f2.0   r6.0<1>:f     r60.0<1;1,0>:f    0x3FB8AA3B:f               {$9.src} //  ALU pipe: float; $196
(W)     mov (1|M0)               r5.0<1>:ud    0x3F000000:ud                                         //  ALU pipe: int; $198
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $208
(f2.0)  sel (32|M0)              acc0.0<1>:f   r5.0<0;1,0>:f     0xBF000000:f               {I@2}    //  ALU pipe: float; $198
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $199
        mov (32|M0)              r68.0<1>:d    r2.0<1;1,0>:f                    {F@1}                //  ALU pipe: int; $200
        mov (32|M0)              r64.0<1>:f    r68.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $201
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $208
        mul (32|M0)              r62.0<1>:f    r64.0<1;1,0>:f    0x3F317218:f               {F@1}    //  ALU pipe: float; $202
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $207
        mov (32|M0)              r28.0<1>:ud   0x3F317218:ud                                         //  ALU pipe: int; $205
        mov (32|M0)              r26.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $204
        mov (32|M0)              r30.0<1>:f    -r62.0<1;1,0>:f                  {Compacted,F@1}      //  ALU pipe: float; $203
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$2} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $208
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$2.src}             //  ALU pipe: int; $208
        sync.allrd                           null                             {A@1}                  // $208
        sync.allwr                           null                                                    // $208
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $208
// B024: [FCALL],  [inDivergent],  Preds:{B023},  Succs:{B025}
_L_k0_0_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $208
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $208
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $208
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@6}      //  ALU pipe: float; $209
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$3} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $208
        sync.nop                             null                             {Compacted,$3.dst}     // $213
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $213
        mov (32|M0)              r28.0<1>:f    0xB102E308:f                                          //  ALU pipe: float; $211
        mov (32|M0)              r26.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $210
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$3} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $214
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$3.src}             //  ALU pipe: int; $214
        sync.allrd                           null                             {A@1}                  // $214
        sync.allwr                           null                                                    // $214
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $214
// B025: [FCALL],  [inDivergent],  Preds:{B024},  Succs:{B026}
_L_k0_1_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $214
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $214
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $214
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $215
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$4} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $214
        sync.nop                             null                             {Compacted,$4.dst}     // $219
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $219
        mov (32|M0)              r28.0<1>:f    0x3F317218:f                                          //  ALU pipe: float; $217
        mov (32|M0)              r26.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $216
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$4} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $220
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$4.src}             //  ALU pipe: int; $220
        sync.allrd                           null                             {A@1}                  // $220
        sync.allwr                           null                                                    // $220
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $220
// B026: [FCALL],  [inDivergent],  Preds:{B025},  Succs:{B027}
_L_k0_2_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $220
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $220
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $220
        add (32|M0)              acc0.0<1>:f   r62.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $222
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$5} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $220
        sync.nop                             null                             {Compacted,$5.dst}     // $223
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $223
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $224
        add (32|M0)              r6.0<1>:f     r62.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $225
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $226
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $227
        add (32|M0)              acc2.0<1>:f   r60.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $228
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   -r60.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $229
        add (32|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $230
        add (32|M0)              r8.0<1>:f     r60.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $231
        add (32|M0)              acc0.0<1>:f   -acc0.0<1;1,0>:f  -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $232
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $233
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0x0:f               {Compacted}     //  ALU pipe: float; $234
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   -r10.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $235
        add (32|M0)              r60.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $236
        add (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $237
        add (32|M0)              r2.0<1>:f     r60.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $238
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $239
        mul (32|M0)              r64.0<1>:f    r60.0<1;1,0>:f    0x310F76C7:f                        //  ALU pipe: float; $242
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $240
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $247
        mov (32|M0)              r28.0<1>:ud   0x310F76C7:ud                                         //  ALU pipe: int; $245
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $244
        mov (32|M0)              r30.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $243
        add (32|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $241
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$5} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $248
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$5.src}             //  ALU pipe: int; $248
        sync.allrd                           null                             {A@1}                  // $248
        sync.allwr                           null                                                    // $248
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $248
// B027: [FCALL],  [inDivergent],  Preds:{B026},  Succs:{B028}
_L_k0_3_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $248
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $248
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $248
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@6}      //  ALU pipe: float; $249
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$6} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $248
        sync.nop                             null                             {Compacted,$6.dst}     // $253
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $253
        mov (32|M0)              r28.0<1>:f    0x24FF8D89:f                                          //  ALU pipe: float; $251
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $250
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $254
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $254
        sync.allrd                           null                             {A@1}                  // $254
        sync.allwr                           null                                                    // $254
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $254
// B028: [FCALL],  [inDivergent],  Preds:{B027},  Succs:{B029}
_L_k0_4_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $254
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $254
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $254
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $255
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$7} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $254
        sync.nop                             null                             {Compacted,$7.dst}     // $259
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $259
        mov (32|M0)              r28.0<1>:f    0x310F76C7:f                                          //  ALU pipe: float; $257
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $256
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$7} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $260
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$7.src}             //  ALU pipe: int; $260
        sync.allrd                           null                             {A@1}                  // $260
        sync.allwr                           null                                                    // $260
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $260
// B029: [FCALL],  [inDivergent],  Preds:{B028},  Succs:{B030}
_L_k0_5_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $260
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $260
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $260
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $262
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$8} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $260
        sync.nop                             null                             {Compacted,$8.dst}     // $263
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $263
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $264
        add (32|M0)              r6.0<1>:f     r64.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $265
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $266
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $267
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x32D7322B:f                        //  ALU pipe: float; $268
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xB2D7322B:f                        //  ALU pipe: float; $269
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $270
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x32D7322B:f               {F@1}    //  ALU pipe: float; $271
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $272
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $273
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0x25FEA89C:f                        //  ALU pipe: float; $274
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $275
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $276
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $277
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $278
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $279
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $282
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $280
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $287
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $284
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $285
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $283
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $281
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $288
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $288
        sync.allrd                           null                             {A@1}                  // $288
        sync.allwr                           null                                                    // $288
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $288
// B030: [FCALL],  [inDivergent],  Preds:{B029},  Succs:{B031}
_L_k0_6_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $288
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $288
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $288
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $289
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $288
        sync.nop                             null                             {Compacted,$10.dst}    // $293
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $293
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $291
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $290
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $294
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $294
        sync.allrd                           null                             {A@1}                  // $294
        sync.allwr                           null                                                    // $294
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $294
// B031: [FCALL],  [inDivergent],  Preds:{B030},  Succs:{B032}
_L_k0_7_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $294
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $294
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $294
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $295
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$11} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $294
        sync.nop                             null                             {Compacted,$11.dst}    // $299
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $299
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $297
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $296
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$11} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $300
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$11.src}            //  ALU pipe: int; $300
        sync.allrd                           null                             {A@1}                  // $300
        sync.allwr                           null                                                    // $300
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $300
// B032: [FCALL],  [inDivergent],  Preds:{B031},  Succs:{B033}
_L_k0_8_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $300
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $300
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $300
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $302
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $300
        sync.nop                             null                             {Compacted,$12.dst}    // $303
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $303
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $304
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $305 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $306
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $307
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3493F27E:f                        //  ALU pipe: float; $308
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xB493F27E:f                        //  ALU pipe: float; $309
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $310
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3493F27E:f               {F@1}    //  ALU pipe: float; $311
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $312
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $313
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xA808760A:f                        //  ALU pipe: float; $314
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $315
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $316
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $317
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $318
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $319
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $322
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $320
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $327
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $324
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $325
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $323
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $321
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $328
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $328
        sync.allrd                           null                             {A@1}                  // $328
        sync.allwr                           null                                                    // $328
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $328
// B033: [FCALL],  [inDivergent],  Preds:{B032},  Succs:{B034}
_L_k0_9_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $328
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $328
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $328
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $329
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$13} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $328
        sync.nop                             null                             {Compacted,$13.dst}    // $333
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $333
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $331
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $330
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$13} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $334
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$13.src}            //  ALU pipe: int; $334
        sync.allrd                           null                             {A@1}                  // $334
        sync.allwr                           null                                                    // $334
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $334
// B034: [FCALL],  [inDivergent],  Preds:{B033},  Succs:{B035}
_L_k0_10_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $334
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $334
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $334
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $335
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $334
        sync.nop                             null                             {Compacted,$14.dst}    // $339
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $339
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $337
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $336
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $340
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $340
        sync.allrd                           null                             {A@1}                  // $340
        sync.allwr                           null                                                    // $340
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $340
// B035: [FCALL],  [inDivergent],  Preds:{B034},  Succs:{B036}
_L_k0_11_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $340
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $340
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $340
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $342
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$15} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $340
        sync.nop                             null                             {Compacted,$15.dst}    // $343
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $343
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $344
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $345 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $346
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $347
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3638EF1D:f                        //  ALU pipe: float; $348
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xB638EF1D:f                        //  ALU pipe: float; $349
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $350
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3638EF1D:f               {F@1}    //  ALU pipe: float; $351
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $352
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $353
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0x292AD8E6:f                        //  ALU pipe: float; $354
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $355
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $356
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $357
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $358
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $359
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $362
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $360
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $367
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $364
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $365
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $363
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $361
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$15} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $368
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$15.src}            //  ALU pipe: int; $368
        sync.allrd                           null                             {A@1}                  // $368
        sync.allwr                           null                                                    // $368
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $368
// B036: [FCALL],  [inDivergent],  Preds:{B035},  Succs:{B037}
_L_k0_12_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $368
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $368
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $368
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $369
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $368
        sync.nop                             null                             {Compacted,$0.dst}     // $373
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $373
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $371
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $370
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$0} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $374
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $374
        sync.allrd                           null                             {A@1}                  // $374
        sync.allwr                           null                                                    // $374
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $374
// B037: [FCALL],  [inDivergent],  Preds:{B036},  Succs:{B038}
_L_k0_13_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $374
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $374
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $374
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $375
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$1} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $374
        sync.nop                             null                             {Compacted,$1.dst}     // $379
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $379
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $377
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $376
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$1} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $380
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$1.src}             //  ALU pipe: int; $380
        sync.allrd                           null                             {A@1}                  // $380
        sync.allwr                           null                                                    // $380
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $380
// B038: [FCALL],  [inDivergent],  Preds:{B037},  Succs:{B039}
_L_k0_14_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $380
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $380
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $380
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $382
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$2} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $380
        sync.nop                             null                             {Compacted,$2.dst}     // $383
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $383
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $384
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $385 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $386
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $387
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x37D00D01:f                        //  ALU pipe: float; $388
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xB7D00D01:f                        //  ALU pipe: float; $389
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $390
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x37D00D01:f               {F@1}    //  ALU pipe: float; $391
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $392
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $393
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xAABFCBFD:f                        //  ALU pipe: float; $394
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $395
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $396
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $397
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $398
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $399
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $402
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $400
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $407
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $404
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $405
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $403
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $401
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$2} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $408
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$2.src}             //  ALU pipe: int; $408
        sync.allrd                           null                             {A@1}                  // $408
        sync.allwr                           null                                                    // $408
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $408
// B039: [FCALL],  [inDivergent],  Preds:{B038},  Succs:{B040}
_L_k0_15_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $408
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $408
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $408
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $409
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$3} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $408
        sync.nop                             null                             {Compacted,$3.dst}     // $413
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $413
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $411
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $410
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$3} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $414
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$3.src}             //  ALU pipe: int; $414
        sync.allrd                           null                             {A@1}                  // $414
        sync.allwr                           null                                                    // $414
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $414
// B040: [FCALL],  [inDivergent],  Preds:{B039},  Succs:{B041}
_L_k0_16_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $414
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $414
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $414
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $415
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$4} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $414
        sync.nop                             null                             {Compacted,$4.dst}     // $419
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $419
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $417
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $416
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$4} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $420
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$4.src}             //  ALU pipe: int; $420
        sync.allrd                           null                             {A@1}                  // $420
        sync.allwr                           null                                                    // $420
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $420
// B041: [FCALL],  [inDivergent],  Preds:{B040},  Succs:{B042}
_L_k0_17_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $420
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $420
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $420
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $422
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$5} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $420
        sync.nop                             null                             {Compacted,$5.dst}     // $423
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $423
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $424
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $425 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $426
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $427
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x39500D01:f                        //  ALU pipe: float; $428
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xB9500D01:f                        //  ALU pipe: float; $429
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $430
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x39500D01:f               {F@1}    //  ALU pipe: float; $431
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $432
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $433
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xAC3FCBFD:f                        //  ALU pipe: float; $434
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $435
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $436
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $437
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $438
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $439
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $442
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $440
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $447
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $444
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $445
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $443
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $441
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$5} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $448
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$5.src}             //  ALU pipe: int; $448
        sync.allrd                           null                             {A@1}                  // $448
        sync.allwr                           null                                                    // $448
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $448
// B042: [FCALL],  [inDivergent],  Preds:{B041},  Succs:{B043}
_L_k0_18_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $448
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $448
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $448
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $449
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$6} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $448
        sync.nop                             null                             {Compacted,$6.dst}     // $453
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $453
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $451
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $450
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $454
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $454
        sync.allrd                           null                             {A@1}                  // $454
        sync.allwr                           null                                                    // $454
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $454
// B043: [FCALL],  [inDivergent],  Preds:{B042},  Succs:{B044}
_L_k0_19_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $454
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $454
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $454
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $455
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$7} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $454
        sync.nop                             null                             {Compacted,$7.dst}     // $459
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $459
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $457
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $456
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$7} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $460
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$7.src}             //  ALU pipe: int; $460
        sync.allrd                           null                             {A@1}                  // $460
        sync.allwr                           null                                                    // $460
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $460
// B044: [FCALL],  [inDivergent],  Preds:{B043},  Succs:{B045}
_L_k0_20_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $460
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $460
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $460
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $462
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$8} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $460
        sync.nop                             null                             {Compacted,$8.dst}     // $463
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $463
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $464
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $465 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $466
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $467
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3AB60B61:f                        //  ALU pipe: float; $468
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xBAB60B61:f                        //  ALU pipe: float; $469
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $470
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3AB60B61:f               {F@1}    //  ALU pipe: float; $471
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $472
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $473
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xAE13E93F:f                        //  ALU pipe: float; $474
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $475
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $476
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $477
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $478
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $479
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $482
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $480
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $487
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $484
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $485
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $483
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $481
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $488
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $488
        sync.allrd                           null                             {A@1}                  // $488
        sync.allwr                           null                                                    // $488
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $488
// B045: [FCALL],  [inDivergent],  Preds:{B044},  Succs:{B046}
_L_k0_21_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $488
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $488
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $488
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $489
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $488
        sync.nop                             null                             {Compacted,$10.dst}    // $493
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $493
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $491
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $490
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $494
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $494
        sync.allrd                           null                             {A@1}                  // $494
        sync.allwr                           null                                                    // $494
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $494
// B046: [FCALL],  [inDivergent],  Preds:{B045},  Succs:{B047}
_L_k0_22_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $494
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $494
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $494
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $495
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$11} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $494
        sync.nop                             null                             {Compacted,$11.dst}    // $499
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $499
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $497
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $496
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$11} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $500
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$11.src}            //  ALU pipe: int; $500
        sync.allrd                           null                             {A@1}                  // $500
        sync.allwr                           null                                                    // $500
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $500
// B047: [FCALL],  [inDivergent],  Preds:{B046},  Succs:{B048}
_L_k0_23_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $500
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $500
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $500
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $502
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $500
        sync.nop                             null                             {Compacted,$12.dst}    // $503
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $503
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $504
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $505 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $506
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $507
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3C088889:f                        //  ALU pipe: float; $508
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xBC088889:f                        //  ALU pipe: float; $509
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $510
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3C088889:f               {F@1}    //  ALU pipe: float; $511
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $512
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $513
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xAFEEEEEF:f                        //  ALU pipe: float; $514
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $515
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $516
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $517
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $518
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $519
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $522
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $520
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $527
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $524
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $525
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $523
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $521
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $528
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $528
        sync.allrd                           null                             {A@1}                  // $528
        sync.allwr                           null                                                    // $528
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $528
// B048: [FCALL],  [inDivergent],  Preds:{B047},  Succs:{B049}
_L_k0_24_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $528
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $528
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $528
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $529
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$13} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $528
        sync.nop                             null                             {Compacted,$13.dst}    // $533
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $533
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $531
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $530
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$13} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $534
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$13.src}            //  ALU pipe: int; $534
        sync.allrd                           null                             {A@1}                  // $534
        sync.allwr                           null                                                    // $534
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $534
// B049: [FCALL],  [inDivergent],  Preds:{B048},  Succs:{B050}
_L_k0_25_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $534
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $534
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $534
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $535
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $534
        sync.nop                             null                             {Compacted,$14.dst}    // $539
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $539
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $537
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $536
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $540
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $540
        sync.allrd                           null                             {A@1}                  // $540
        sync.allwr                           null                                                    // $540
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $540
// B050: [FCALL],  [inDivergent],  Preds:{B049},  Succs:{B051}
_L_k0_26_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $540
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $540
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $540
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $542
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$15} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $540
        sync.nop                             null                             {Compacted,$15.dst}    // $543
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $543
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $544
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $545 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $546
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $547
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3D2AAAAB:f                        //  ALU pipe: float; $548
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xBD2AAAAB:f                        //  ALU pipe: float; $549
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $550
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3D2AAAAB:f               {F@1}    //  ALU pipe: float; $551
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $552
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $553
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xB0AAAAAB:f                        //  ALU pipe: float; $554
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $555
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $556
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $557
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $558
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $559
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $562
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $560
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $567
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $564
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $565
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $563
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $561
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$15} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $568
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$15.src}            //  ALU pipe: int; $568
        sync.allrd                           null                             {A@1}                  // $568
        sync.allwr                           null                                                    // $568
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $568
// B051: [FCALL],  [inDivergent],  Preds:{B050},  Succs:{B052}
_L_k0_27_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $568
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $568
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $568
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $569
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $568
        sync.nop                             null                             {Compacted,$0.dst}     // $573
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $573
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $571
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $570
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$0} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $574
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $574
        sync.allrd                           null                             {A@1}                  // $574
        sync.allwr                           null                                                    // $574
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $574
// B052: [FCALL],  [inDivergent],  Preds:{B051},  Succs:{B053}
_L_k0_28_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $574
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $574
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $574
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $575
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$1} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $574
        sync.nop                             null                             {Compacted,$1.dst}     // $579
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $579
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $577
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $576
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$1} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $580
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$1.src}             //  ALU pipe: int; $580
        sync.allrd                           null                             {A@1}                  // $580
        sync.allwr                           null                                                    // $580
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $580
// B053: [FCALL],  [inDivergent],  Preds:{B052},  Succs:{B054}
_L_k0_29_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $580
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $580
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $580
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $582
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$2} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $580
        sync.nop                             null                             {Compacted,$2.dst}     // $583
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $583
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $584
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $585 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $586
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $587
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3E2AAAAB:f                        //  ALU pipe: float; $588
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xBE2AAAAB:f                        //  ALU pipe: float; $589
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $590
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3E2AAAAB:f               {F@1}    //  ALU pipe: float; $591
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $592
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $593
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xB1AAAAAB:f                        //  ALU pipe: float; $594
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $595
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $596
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $597
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $598
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $599
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $602
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $600
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $607
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $604
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $605
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $603
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $601
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$2} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $608
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$2.src}             //  ALU pipe: int; $608
        sync.allrd                           null                             {A@1}                  // $608
        sync.allwr                           null                                                    // $608
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $608
// B054: [FCALL],  [inDivergent],  Preds:{B053},  Succs:{B055}
_L_k0_30_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $608
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $608
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $608
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $609
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$3} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $608
        sync.nop                             null                             {Compacted,$3.dst}     // $613
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $613
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $611
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $610
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$3} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $614
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$3.src}             //  ALU pipe: int; $614
        sync.allrd                           null                             {A@1}                  // $614
        sync.allwr                           null                                                    // $614
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $614
// B055: [FCALL],  [inDivergent],  Preds:{B054},  Succs:{B056}
_L_k0_31_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $614
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $614
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $614
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $615
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$4} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $614
        sync.nop                             null                             {Compacted,$4.dst}     // $619
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $619
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $617
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $616
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$4} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $620
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$4.src}             //  ALU pipe: int; $620
        sync.allrd                           null                             {A@1}                  // $620
        sync.allwr                           null                                                    // $620
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $620
// B056: [FCALL],  [inDivergent],  Preds:{B055},  Succs:{B057}
_L_k0_32_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $620
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $620
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $620
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $622
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$5} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $620
        sync.nop                             null                             {Compacted,$5.dst}     // $623
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $623
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $624
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $625 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $626
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $627
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3F000000:f               {Compacted} //  ALU pipe: float; $628
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xBF000000:f               {Compacted} //  ALU pipe: float; $629
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $630
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3F000000:f               {Compacted,F@1} //  ALU pipe: float; $631
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $632
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $633
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $634
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $635
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $636
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $637
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $638
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $641
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $639
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $646
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $643
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $644
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $642
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $640
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$5} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $647
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$5.src}             //  ALU pipe: int; $647
        sync.allrd                           null                             {A@1}                  // $647
        sync.allwr                           null                                                    // $647
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $647
// B057: [FCALL],  [inDivergent],  Preds:{B056},  Succs:{B058}
_L_k0_33_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $647
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $647
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $647
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $648
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$6} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $647
        sync.nop                             null                             {Compacted,$6.dst}     // $652
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $652
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $650
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $649
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $653
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $653
        sync.allrd                           null                             {A@1}                  // $653
        sync.allwr                           null                                                    // $653
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $653
// B058: [FCALL],  [inDivergent],  Preds:{B057},  Succs:{B059}
_L_k0_34_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $653
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $653
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $653
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $654
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$7} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $653
        sync.nop                             null                             {Compacted,$7.dst}     // $658
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $658
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $656
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $655
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$7} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $659
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$7.src}             //  ALU pipe: int; $659
        sync.allrd                           null                             {A@1}                  // $659
        sync.allwr                           null                                                    // $659
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $659
// B059: [FCALL],  [inDivergent],  Preds:{B058},  Succs:{B060}
_L_k0_35_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $659
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $659
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $659
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $661
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$8} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $659
        sync.nop                             null                             {Compacted,$8.dst}     // $662
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $662
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $663
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $664 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $665
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $666
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3F800000:f               {Compacted} //  ALU pipe: float; $667
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xBF800000:f               {Compacted} //  ALU pipe: float; $668
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $669
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3F800000:f               {Compacted,F@1} //  ALU pipe: float; $670
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $671
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $672
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $673
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $674
        add (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $675
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $676
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $677
        mul (32|M0)              r66.0<1>:f    r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $680
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $678
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $685
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $682
        mov (32|M0)              r28.0<1>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $683
        mov (32|M0)              r30.0<1>:f    -r66.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $681
        add (32|M0)              r76.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $679
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $686
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $686
        sync.allrd                           null                             {A@1}                  // $686
        sync.allwr                           null                                                    // $686
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $686
// B060: [FCALL],  [inDivergent],  Preds:{B059},  Succs:{B061}
_L_k0_36_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $686
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $686
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $686
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $687
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $686
        sync.nop                             null                             {Compacted,$10.dst}    // $691
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $691
        mov (32|M0)              r28.0<1>:f    r76.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $689
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $688
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $692
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $692
        sync.allrd                           null                             {A@1}                  // $692
        sync.allwr                           null                                                    // $692
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $692
// B061: [FCALL],  [inDivergent],  Preds:{B060},  Succs:{B062}
_L_k0_37_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $692
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $692
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $692
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $693
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$11} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $692
        sync.nop                             null                             {Compacted,$11.dst}    // $697
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $697
        mov (32|M0)              r28.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $695
        mov (32|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $694
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$11} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $698
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$11.src}            //  ALU pipe: int; $698
        sync.allrd                           null                             {A@1}                  // $698
        sync.allwr                           null                                                    // $698
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $698
// B062: [inDivergent],  Preds:{B061},  Succs:{B063, B070}
_L_k0_38_:
        add (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $700
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -r66.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $701
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $702
        add (32|M0)              r6.0<1>:f     r66.0<1;1,0>:f    -r2.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $703 R{} IR{}{E:1,E:1,},  R{} IR{}{O:1,O:1,},  {BC=2}
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $704
        add (32|M0)              r10.0<1>:f    r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $705
        add (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3F800000:f               {Compacted} //  ALU pipe: float; $706
        add (32|M0)              r6.0<1>:f     acc2.0<1;1,0>:f   0xBF800000:f               {Compacted} //  ALU pipe: float; $707
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $708
        add (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     0x3F800000:f               {Compacted,F@1} //  ALU pipe: float; $709
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $710
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $711
        add (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $712
        add (32|M0)              r60.0<1>:f    acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $713
        add (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $714
        add (32|M0)              r2.0<1>:f     acc0.0<1;1,0>:f   -r60.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $715
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $716
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $698
        cmp (32|M0)   (lt)f3.0   null<1>:d     r68.0<1;1,0>:d    -125:w                              //  ALU pipe: int; $719
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $698
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $717
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $698
        add (32|M0)              r66.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $718
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $698
        sync.nop                             null                             {Compacted,$12.dst}    // $720
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $720
(f3.0)  goto (32|M0)                         _0_075            _0_075                                //  ALU pipe: int; $720
// B063: [inDivergent],  Preds:{B062},  Succs:{B064, B065}
_0_076:
        cmp (32|M0)   (eq)f2.0   null<1>:d     r68.0<1;1,0>:d    128:w                               //  ALU pipe: int; $722
(f2.0)  goto (32|M0)                         _0_077            _0_077                                //  ALU pipe: int; $723
// B064: [inDivergent],  Preds:{B063},  Succs:{B069}
_0_078:
        shl (32|M0)              r2.0<1>:d     r68.0<1;1,0>:d    23:w               {Compacted,F@3}  //  ALU pipe: int; $725
        add (32|M0)              r64.0<1>:d    r2.0<1;1,0>:d     1065353216:d               {I@1}    //  ALU pipe: int; $726
        goto (32|M0)                         _0_077            _0_079                                // $727
// B065: [FCALL],  [inDivergent],  Preds:{B063},  Succs:{B066}
_0_077:
        join (32|M0)                         _0_079                                                  // 
L13304:
        mul (32|M0)              r62.0<1>:f    r60.0<1;1,0>:f    0x40000000:f               {Compacted} //  ALU pipe: float; $729
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $735
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $735
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $734
        mov (32|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $731
        mov (32|M0)              r28.0<1>:f    0x40000000:f                               {Compacted} //  ALU pipe: float; $732
        mov (32|M0)              r30.0<1>:f    -r62.0<1;1,0>:f                  {Compacted,F@2}      //  ALU pipe: float; $730
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {I@4,$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $735
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $735
        sync.allrd                           null                             {A@1}                  // $735
        sync.allwr                           null                                                    // $735
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $735
// B066: [FCALL],  [inDivergent],  Preds:{B065},  Succs:{B067}
_L_k0_39_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $735
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $735
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $735
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@6}      //  ALU pipe: float; $736
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$13} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $735
        sync.nop                             null                             {Compacted,$13.dst}    // $740
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $740
        mov (32|M0)              r28.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $738
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $737
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$13} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $741
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$13.src}            //  ALU pipe: int; $741
        sync.allrd                           null                             {A@1}                  // $741
        sync.allwr                           null                                                    // $741
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $741
// B067: [FCALL],  [inDivergent],  Preds:{B066},  Succs:{B068}
_L_k0_40_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $741
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $741
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $741
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $742
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $741
        sync.nop                             null                             {Compacted,$14.dst}    // $746
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $746
        mov (32|M0)              r28.0<1>:f    0x40000000:f                               {Compacted} //  ALU pipe: float; $744
        mov (32|M0)              r26.0<1>:f    r66.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $743
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $747
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $747
        sync.allrd                           null                             {A@1}                  // $747
        sync.allwr                           null                                                    // $747
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $747
// B068: [inDivergent],  Preds:{B067},  Succs:{B069}
_L_k0_41_:
        add (32|M0)              r60.0<1>:f    r62.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $749
        add (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    -r62.0<1;1,0>:f  {Compacted,F@1}    //  ALU pipe: float; $750
        add (32|M0)              acc2.0<1>:f   r60.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $751
        add (32|M0)              acc2.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $752
        add (32|M0)              acc0.0<1>:f   r26.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $753
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $747
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $747
        mov (32|M0)              r64.0<1>:ud   0x7F000000:ud                                         //  ALU pipe: int; $755
        add (32|M0)              r66.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $754
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $747
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$15} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $747
        sync.nop                             null                             {Compacted,$15.dst}    // 
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$15.src}            //  ALU pipe: int; 
// B069: [inDivergent],  Preds:{B068, B064},  Succs:{B083}
_0_079:
        join (32|M0)                         _0_075                                                  // 
L14016:
        add (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    r66.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $757
        mul (32|M0)              r62.0<1>:f    acc0.0<1;1,0>:f   r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $758
        goto (32|M0)                         _0_075            _0_080                                // $759
// B070: [FCALL],  [inDivergent],  Preds:{B062},  Succs:{B071}
_0_075:
        join (32|M0)                         _0_073                                                  // 
L14064:
        shl (32|M0)              r2.0<1>:d     r68.0<1;1,0>:d    23:w               {Compacted}      //  ALU pipe: int; $761
        add (32|M0)              r68.0<1>:d    r2.0<1;1,0>:d     -1979711488:d               {I@1}   //  ALU pipe: int; $762
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $769
        mul (32|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $763
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $769
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $768
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $765
        mov (32|M0)              r28.0<1>:f    r68.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $766
        mov (32|M0)              r30.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $764
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {I@3,$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $769
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $769
        sync.allrd                           null                             {A@1}                  // $769
        sync.allwr                           null                                                    // $769
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $769
// B071: [FCALL],  [inDivergent],  Preds:{B070},  Succs:{B072}
_L_k0_42_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $769
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $769
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $769
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@3}      //  ALU pipe: float; $770
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$15} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $769
        sync.nop                             null                             {Compacted,$15.dst}    // $774
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $774
        mov (32|M0)              r28.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $772
        mov (32|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $771
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$15} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $775
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$15.src}            //  ALU pipe: int; $775
        sync.allrd                           null                             {A@1}                  // $775
        sync.allwr                           null                                                    // $775
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $775
// B072: [FCALL],  [inDivergent],  Preds:{B071},  Succs:{B073}
_L_k0_43_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $775
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $775
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $775
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $776
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $775
        sync.nop                             null                             {Compacted,$0.dst}     // $780
(W)     mov (1|M0)               r127.0<2>:ud  r74.0<0;1,0>:uq                                       //  ALU pipe: int; $780
        mov (32|M0)              r28.0<1>:f    r68.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $778
        mov (32|M0)              r26.0<1>:f    r66.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $777
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r5:1  {$0} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $781
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $781
        sync.allrd                           null                             {A@1}                  // $781
        sync.allwr                           null                                                    // $781
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $781
// B073: [inDivergent],  Preds:{B072},  Succs:{B074, B077}
_L_k0_44_:
        add (32|M0)              r2.0<1>:f     r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $783
        add (32|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     -r64.0<1;1,0>:f  {Compacted,F@1}    //  ALU pipe: float; $784
        mov (32|M0)              r62.0<1>:ud   r2.0<1;1,0>:f                                         //  ALU pipe: int; $789
        add (32|M0)              acc2.0<1>:f   r2.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $785
        mov (32|M0)              r8.0<1>:f     r62.0<1;1,0>:ud                  {I@1}                //  ALU pipe: float; $790
        add (32|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $786
        add (32|M0)              r6.0<1>:f     r2.0<1;1,0>:f     -r8.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $791
        add (32|M0)              acc0.0<1>:f   r26.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $787
        add (32|M0)              r10.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $788
        add (32|M0)              acc2.0<1>:f   r6.0<1;1,0>:f     -r2.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $792
        add (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $793
        add (32|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $794
        add (32|M0)              acc2.0<1>:f   -r8.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $795
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $796
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $797
        add (32|M0)              r8.0<1>:f     acc0.0<1;1,0>:f   0x0:f               {Compacted}     //  ALU pipe: float; $798
        add (32|M0)              r2.0<1>:f     r6.0<1;1,0>:f     r8.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $799
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $781
        cmp (32|M0)   (gt)f1.0   null<1>:f     r2.0<1;1,0>:f     0x3F000000:f               {F@1}    //  ALU pipe: float; $800
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $781
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $781
(W)     load.ugm.d32x16t.a32 (1|M0)  r5:1       ss[a0.2][r126:1-0x10000]  {I@1,$1} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $781
        sync.nop                             null                             {Compacted,$1.dst}     // $801
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$1.src}             //  ALU pipe: int; $801
(f1.0)  goto (32|M0)                         _0_081            _0_081                                //  ALU pipe: int; $801
// B074: [inDivergent],  Preds:{B073},  Succs:{B075, B078}
_0_082:
        cmp (32|M0)   (eq)f0.0   null<1>:f     r2.0<1;1,0>:f     0x3F000000:f                        //  ALU pipe: float; $803
(~f0.0) goto (32|M0)                         _0_081            _0_083                                //  ALU pipe: int; $804
// B075: [inDivergent],  Preds:{B074},  Succs:{B076, B077}
_0_084:
        add (32|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     -r6.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $806
        add (32|M0)              acc2.0<1>:f   r2.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $807
        add (32|M0)              acc2.0<1>:f   r6.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $808
        add (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $809
        add (32|M0)   (gt)f3.0   r2.0<1>:f     acc2.0<1;1,0>:f   acc0.0<1;1,0>:f                     //  ALU pipe: float; $810
(f3.0)  goto (32|M0)                         _0_081            _0_081                                //  ALU pipe: int; $812
// B076: [inDivergent],  Preds:{B075},  Succs:{B077, B078}
_0_085:
        and (32|M0)   (eq)f0.0   null<1>:d     r62.0<1;1,0>:d    1:w               {F@6}             //  ALU pipe: int; $814
(~f0.0) cmp (32|M0)   (ne)f0.0   null<1>:f     r2.0<1;1,0>:f     0x0:f               {A@1}           //  ALU pipe: float; $816
(f0.0)  goto (32|M0)                         _0_081            _0_083                                //  ALU pipe: int; $818
// B077: [inDivergent],  Preds:{B076, B075, B073},  Succs:{B078}
_0_081:
        join (32|M0)                         _0_083                                                  // 
L15064:
        add (32|M0)              r62.0<1>:d    r62.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $820
// B078: [inDivergent],  Preds:{B077, B076, B074},  Succs:{B083}
_0_083:
        join (32|M0)                         _0_073                                                  // 
L15088:
        goto (32|M0)                         _0_073            _0_080                                // $822
// B079: [inDivergent],  Preds:{B022},  Succs:{B083}
_0_073:
        join (32|M0)                         _0_071                                                  // 
L15120:
        mov (32|M0)              r62.0<1>:ud   0x3F800000:ud                                         //  ALU pipe: int; $824
        goto (32|M0)                         _0_071            _0_080                                // $825
// B080: [inDivergent],  Preds:{B021},  Succs:{B083}
_0_071:
        join (32|M0)                         _0_069                                                  // 
L15168:
        mov (32|M0)              r62.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $827
        goto (32|M0)                         _0_069            _0_080                                // $828
// B081: [inDivergent],  Preds:{B020},  Succs:{B083}
_0_069:
        join (32|M0)                         _0_067                                                  // 
L15208:
        mov (32|M0)              r62.0<1>:ud   0x7F800000:ud                                         //  ALU pipe: int; $830
        goto (32|M0)                         _0_067            _0_080                                // $831
// B082: [inDivergent],  Preds:{B019},  Succs:{B083}
_0_067:
        join (32|M0)                         _0_080                                                  // 
L15256:
        mov (32|M0)              r62.0<1>:ud   0x7FC00000:ud                                         //  ALU pipe: int; $833
// B083: [inDivergent],  Preds:{B082, B081, B080, B079, B078, B069},  Succs:{B084, B085}
_0_080:
        join (32|M0)                         _0_049                                                  // 
L15288:
        shl (16|M0)              r1.0<1>:q     r72.0<1;1,0>:q    2:w               {Compacted,F@1}   //  ALU pipe: int; $835
        shl (16|M16)             r3.0<1>:q     r70.0<1;1,0>:q    2:w               {Compacted,$9.src} //  ALU pipe: int; $835
        sync.allwr                           ($1,$15)                                                // $836
        add (16|M0)              r8.0<1>:q     r1.0<1;1,0>:q     r5.4<0;1,0>:q    {Compacted,@2,$12.dst} //  ALU pipe: int; $836
        add (16|M16)             r6.0<1>:q     r3.0<1;1,0>:q     r5.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $836
        add (16|M0)              r1.0<1>:q     r8.0<1;1,0>:q     256:w               {Compacted,I@2} //  ALU pipe: int; $837
        add (16|M16)             r3.0<1>:q     r6.0<1;1,0>:q     256:w               {Compacted,I@2} //  ALU pipe: int; $837
        store.ugm.d32.a64 (32|M0)  [r1:4]       r62:2              {I@1,$2} // ex_desc:0x0; desc:0x8000584 // $839
(W)     mov (8|M0)               r1.0<1>:w     0x76543210:v                               {$2.src}   //  ALU pipe: int; $840
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $847
(W)     add (8|M0)               r1.8<1>:w     r1.0<1;1,0>:w     8:w               {I@2}             //  ALU pipe: int; $841
(W)     add (16|M0)              r1.16<1>:w    r1.0<1;1,0>:w     16:w               {I@1}            //  ALU pipe: int; $842
        add (32|M0)              r6.0<1>:d     r1.0<1;1,0>:uw    1:w               {I@1}             //  ALU pipe: int; $844
        and (32|M0)              r2.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $845
        shl (32|M0)              r4.0<1>:uw    r2.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $846
        add (16|M0)              a0.0<1>:uw    r4.0<1;1,0>:uw    0xF80:uw              {I@1}         //  ALU pipe: int; src1 is addr of V0575(r62.0:f); $848
        and (32|M0)   (eq)f2.0   null<1>:d     r1.0<1;1,0>:uw    1:w                                 //  ALU pipe: int; $853
        mov (16|M0)              r2.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $849
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $850
        add (16|M16)             a0.0<1>:uw    r4.16<1;1,0>:uw   0xF80:uw                            //  ALU pipe: int; src1 is addr of V0575(r62.0:f); $851
        add (32|M0)              r6.0<1>:d     r1.0<1;1,0>:uw    2:w                                 //  ALU pipe: int; $857
        mov (16|M16)             r3.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $852
(f2.0)  sel (32|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $855
        and (32|M0)              r2.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,F@1}  //  ALU pipe: int; $858
        shl (32|M0)              r4.0<1>:uw    r2.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $859
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $860
        add (16|M0)              a0.0<1>:uw    r4.0<1;1,0>:uw    0x200:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0626(r8.0:f); $861
        add (32|M0)              r8.0<1>:f     r62.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $856
        mov (16|M0)              r2.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $862
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $863
        add (16|M16)             a0.0<1>:uw    r4.16<1;1,0>:uw   0x200:uw                            //  ALU pipe: int; src1 is addr of V0626(r8.0:f); $864
        and (32|M0)   (eq)f1.0   null<1>:d     r1.0<1;1,0>:uw    3:w                                 //  ALU pipe: int; $866
        add (32|M0)              r6.0<1>:d     r1.0<1;1,0>:uw    4:w                                 //  ALU pipe: int; $870
        mov (16|M16)             r3.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $865
(f1.0)  sel (32|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $868
        and (32|M0)              r2.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,F@1}  //  ALU pipe: int; $871
        shl (32|M0)              r4.0<1>:uw    r2.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $872
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $873
        add (16|M0)              a0.0<1>:uw    r4.0<1;1,0>:uw    0x280:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0634(r10.0:f); $874
        add (32|M0)              r10.0<1>:f    r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $869
        mov (16|M0)              r2.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $875
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $876
        add (16|M16)             a0.0<1>:uw    r4.16<1;1,0>:uw   0x280:uw                            //  ALU pipe: int; src1 is addr of V0634(r10.0:f); $877
        and (32|M0)   (eq)f0.0   null<1>:d     r1.0<1;1,0>:uw    7:w                                 //  ALU pipe: int; $879
        add (32|M0)              r6.0<1>:d     r1.0<1;1,0>:uw    8:w                                 //  ALU pipe: int; $883
        mov (16|M16)             r3.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $878
(f0.0)  sel (32|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $881
        and (32|M0)              r2.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,F@1}  //  ALU pipe: int; $884
        shl (32|M0)              r4.0<1>:uw    r2.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $885
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $886
        add (16|M0)              a0.0<1>:uw    r4.0<1;1,0>:uw    0x200:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0642(r8.0:f); $887
        add (32|M0)              r8.0<1>:f     r10.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $882
        and (32|M0)   (eq)f1.0   null<1>:d     r1.0<1;1,0>:uw    15:w                                //  ALU pipe: int; $892
        mov (16|M0)              r2.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $888
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $889
        add (16|M16)             a0.0<1>:uw    r4.16<1;1,0>:uw   0x200:uw                            //  ALU pipe: int; src1 is addr of V0642(r8.0:f); $890
        mov (16|M16)             r3.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $891
(~f1.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $894
// B084: [inDivergent],  Preds:{B083},  Succs:{B085}
_0_086:
(f1.0)  sel (32|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $896
        add (32|M0)              r12.0<1>:f    r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $897
        shr (16|M16)             r3.0<1>:uq    r70.0<1;1,0>:uq   2:w               {F@2}             //  ALU pipe: int; $898
        shr (16|M0)              r8.0<1>:uq    r72.0<1;1,0>:uq   2:w               {F@1}             //  ALU pipe: int; $898
        and (16|M16)             r6.0<2>:d     r3.0<2;1,0>:d     -4:w               {I@2}            //  ALU pipe: int; $900
        and (16|M0)              r1.0<2>:d     r8.0<2;1,0>:d     -4:w               {I@2}            //  ALU pipe: int; $899
        and (16|M16)             r6.1<2>:d     r3.1<2;1,0>:d     1073741823:d                        //  ALU pipe: int; $902
        and (16|M0)              r1.1<2>:d     r8.1<2;1,0>:d     1073741823:d                        //  ALU pipe: int; $901
        add (16|M0)              r10.0<1>:q    r1.0<1;1,0>:q     r5.4<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $903
        add (16|M16)             r8.0<1>:q     r6.0<1;1,0>:q     r5.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $903
        add (16|M0)              r1.0<1>:q     r10.0<1;1,0>:q    128:w               {Compacted,I@2} //  ALU pipe: int; $904
        add (16|M16)             r3.0<1>:q     r8.0<1;1,0>:q     128:w               {Compacted,I@2} //  ALU pipe: int; $904
        store.ugm.d32.a64 (32|M0)  [r1:4]       r12:2              {I@1,$3} // ex_desc:0x0; desc:0x8000584 // $906
// B085: Preds:{B084, B083, B003, B002},  Succs:{}
_0_049:
        join (32|M0)                         L16296                                                  // 
L16296:
(W)     mov (16|M0)              r112.0<1>:f   r125.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $908
(W)     send.gtwy (1|M0)         null     r112  null:0  0x0            0x02000010           {EOT,F@1,$4} // wr:1+0, rd:0; end of thread // $908
L16320:
(W)     mov (16|M0)              null<1>:ud    0x4A314E4E:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x569A3A56:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x13:ud                                               // 


//.BankConflicts: 22
//.ByteRMWs: 0
//


//.numALUInst: 1075
//.accSubDef: 151
//.accSubUse: 272
//.accSubCandidateDef: 256
//.accSubCandidateUse: 403
//
//
//.singlePipeAtOneDistNum: 244
//.allAtOneDistNum: 54
//.syncInstCount: 51
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 18
//.AfterReadTokenDepCount: 62
