//.kernel _ZTSN4sycl3_V16detail18RoundedRangeKernelINS0_4itemILi1ELb1EEELi1EZZNK3p5111RouteKernelILj0EE6submitERNS0_5queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS0_5eventESaISF_EEENKUlRNS0_7handlerEE_clESL_EUlNS0_2idILi1EEEE_EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1244745294 1452948054 -hashmovs1 0 17 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1244745294 1452948054 -hashmovs1 0 17 -GRFBumpUpNumber 2 "
//.instCount 171
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 3
//.spill flag load 3

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r22.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.7)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.8)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.4)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.6)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r22.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r22.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r5.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r4.5)
//.declare V0043 (53)  rf=r size=8 type=uq align=4 words (r4.6)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r4.1)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0057 (67)  rf=r size=4 type=d align=2 words (r4.3)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r4.4)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.5)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.6)
//.declare V0061 (71)  rf=r size=4 type=d align=2 words (r4.7)
//.declare V0062 (72)  rf=r size=4 type=d align=2 words (r4.8)
//.declare V0063 (73)  rf=r size=4 type=d align=2 words (r4.9)
//.declare V0066 (76)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0067 (77)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.6)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0069 (79)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.3)
//.declare V0070 (80)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r22.0)
//.declare V0071 (81)  rf=r size=8 type=ud alias=V0068+0 align=4 words (r7.0)
//.declare V0072 (82)  rf=r size=8 type=d alias=V0068+0 align=4 words (r7.0)
//.declare V0073 (83)  rf=r size=4 type=d align=32 words (r8.0)
//.declare V0076 (86)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0079 (89)  rf=r size=12 type=ud alias=V0036+0 align=2 words (r2.0)
//.declare V0083 (93)  rf=r size=128 type=d align=32 words (r23.0)
//.declare V0084 (94)  rf=r size=128 type=d align=32 words (r25.0)
//.declare P01 (95)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0085 (96)  rf=r size=128 type=ud alias=V0083+0 align=32 words (r23.0)
//.declare V0086 (97)  rf=r size=8 type=ud alias=V0066+0 align=2 words (r2.8)
//.declare P02 (98)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P03 (99)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0087 (100)  rf=r size=128 type=ud alias=V0084+0 align=32 words (r25.0)
//.declare V0088 (101)  rf=r size=8 type=uq alias=V0052+0 align=4 words (r3.6)
//.declare V0089 (102)  rf=r size=8 type=uq alias=V0053+0 align=4 words (r3.7)
//.declare V0090 (103)  rf=r size=8 type=uq align=32 words (r28.0)
//.declare V0091 (104)  rf=r size=8 type=uq align=32 words (r30.0)
//.declare P04 (105)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P05 (106)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P06 (107)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0092 (108)  rf=r size=4 type=ud alias=V0054+0 align=2 words (r4.0)
//.declare P07 (109)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P08 (110)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P09 (111)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0093 (112)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0094 (113)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r5.0)
//.declare V0095 (114)  rf=r size=4 type=d align=32 words (r6.0)
//.declare P10 (115)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0097 (117)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0098 (118)  rf=r size=256 type=ud alias=V0097+0 align=32 words (r6.0)
//.declare V0099 (119)  rf=r size=8 type=ud alias=V0091+0 align=32 words (r30.0)
//.declare V0100 (120)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0101 (121)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P11 (123)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0103 (124)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0104 (125)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0105 (126)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0106 (127)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0107 (128)  rf=r size=128 type=ud alias=V0105+0 align=32 words (r8.0)
//.declare V0108 (129)  rf=r size=128 type=ud alias=V0106+0 align=32 words (r33.0)
//.declare P12 (130)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0109 (131)  rf=r size=128 type=ud alias=V0104+0 align=32 words (r31.0)
//.declare V0110 (132)  rf=r size=128 type=f align=32 words (r35.0)
//.declare V0112 (134)  rf=r size=128 type=f align=32 words (r37.0)
//.declare V0116 (138)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0117 (139)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0121 (143)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0122 (144)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0123 (145)  rf=r size=128 type=ud alias=V0122+0 align=32 words (r14.0)
//.declare V0127 (149)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0128 (150)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0132 (154)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0134 (156)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0135 (157)  rf=r size=128 type=w alias=V0134+0 align=32 words (r14.0)
//.declare V0137 (159)  rf=r size=128 type=d alias=V0112+0 align=32 words (r37.0)
//.declare V0141 (163)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0142 (164)  rf=r size=128 type=d align=32 words (r6.0)
//.declare P13 (165)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0143 (166)  rf=r size=128 type=f alias=V0142+0 align=32 words (r6.0)
//.declare P14 (167)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0145 (169)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0146 (170)  rf=r size=256 type=ud alias=V0145+0 align=32 words (r6.0)
//.declare V0147 (171)  rf=r size=128 type=d align=32 words (r10.0)
//.declare P15 (172)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P16 (173)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0151 (177)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0155 (181)  rf=r size=128 type=d align=32 words (r39.0)
//.declare V0156 (182)  rf=r size=128 type=d align=32 words (r41.0)
//.declare P17 (183)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0157 (184)  rf=r size=128 type=ud alias=V0155+0 align=32 words (r39.0)
//.declare P18 (185)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P19 (186)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0158 (187)  rf=r size=128 type=ud alias=V0156+0 align=32 words (r41.0)
//.declare  (191)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (192)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare  (193)  rf=r size=128 type=uw align=32 words (r9.0)
//.declare  (194)  rf=r size=128 type=uw align=32 words (r13.0)
//.declare  (197)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (198)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (199)  rf=r size=128 type=f align=32 words (r18.0)
//.declare  (200)  rf=r size=128 type=f align=32 words (r20.0)
//.declare  (203)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (204)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (205)  rf=r size=128 type=q align=32 words (r43.0)
//.declare  (206)  rf=r size=128 type=q align=32 words (r45.0)
//.declare  (209)  rf=r size=128 type=q align=32 words (r47.0)
//.declare  (210)  rf=r size=128 type=q align=32 words (r49.0)
//.declare  (211)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (212)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (215)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (216)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (219)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (220)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (223)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (224)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (227)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (228)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (231)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (232)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (235)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (236)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (239)  rf=r size=128 type=d align=32 words (r6.0)
//.declare  (240)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (241)  rf=r size=128 type=d alias=+0 align=32 words (r43.0)
//.declare  (242)  rf=r size=128 type=d alias=+0 align=32 words (r45.0)
//.declare  (243)  rf=r size=128 type=d alias=+0 align=32 words (r6.0)
//.declare  (244)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (245)  rf=r size=4 type=uw align=2 words (r2.24)
//.declare  (246)  rf=r size=4 type=uw align=2 words (r2.26)
//.declare  (247)  rf=r size=4 type=uw align=2 words (r2.28)
//.declare  (248)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (249)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (250)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (251)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (252)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (253)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare r0 (254)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (255)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (256)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (257)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (258)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (259)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (260)  rf=r size=32 type=ud align=2 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0045    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0046    | :q       |    0x8 | r3       | cti+0x20         |
// | V0047    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0048    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0049    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0050    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0051    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0052    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0053    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0054    | :d       |    0x4 | r4       | cti+0x60         |
// | V0055    | :d       |    0x4 | r4+0x4   | cti+0x64         |
// | V0056    | :d       |    0x4 | r4+0x8   | cti+0x68         |
// | V0057    | :d       |    0x4 | r4+0xC   | cti+0x6C         |
// | V0058    | :d       |    0x4 | r4+0x10  | cti+0x70         |
// | V0059    | :d       |    0x4 | r4+0x14  | cti+0x74         |
// | V0060    | :d       |    0x4 | r4+0x18  | cti+0x78         |
// | V0061    | :d       |    0x4 | r4+0x1C  | cti+0x7C         |
// | V0062    | :d       |    0x4 | r4+0x20  | cti+0x80         |
// | V0063    | :d       |    0x4 | r4+0x24  | cti+0x84         |
// | V0042    | :uq      |    0x8 | r4+0x28  | cti+0x88         |
// | V0043    | :uq      |    0x8 | r4+0x30  | cti+0x90         |
// | V0037    | :d x 3   |    0xC | r5       | cti+0xA0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xA0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r5:1  bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B028}
// _main:
(W)     mov (16|M0)              r22.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r22.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r6.0<1>:ud    r2.3<0;1,0>:ud    r22.1<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r22.2<0;1,0>:uw                     //  ALU pipe: int; $4
(W)     mach (1|M0)              r8.0<1>:d     r2.3<0;1,0>:ud    r22.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r9.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r13.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r7.0<2>:f     r6.0<0;1,0>:f                    {I@5}                //  ALU pipe: float; $4
(W)     mov (1|M0)               r7.1<2>:d     r8.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r2.8<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r11.0<1>:q    r7.0<0;1,0>:q     r9.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $10
        add (16|M16)             r15.0<1>:q    r7.0<0;1,0>:q     r13.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r43.0<1>:q    r11.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r45.0<1>:q    r15.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r23.0<1>:d    r43.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r24.0<1>:d    r45.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r23.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r25.0<1>:d    r43.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r26.0<1>:d    r45.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r25.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $18
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r25.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $20
(~f0.0) goto (32|M0)                         _0_034            _0_034                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_035:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.0<0;1,0>:d     2:w               {$1.dst}          //  ALU pipe: int; $26
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $27
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r4.0<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $28
(W)     mov (1|M0)               r2.14<1>:ud   f2.0<0;1,0>:ud                                        //  ALU pipe: int; $26
(W)     mov (1|M0)               r2.13<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $27
(W)     mov (1|M0)               r2.12<1>:ud   f0.0<0;1,0>:ud                                        //  ALU pipe: int; $28
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r4.0<0;1,0>:d     4:w                                 //  ALU pipe: int; $29
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r4.0<0;1,0>:d     1:w                                 //  ALU pipe: int; $30
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r4.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $31
(W)     mov (1|M0)               r28.0<1>:uq   r3.7<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $24
(W)     mov (1|M0)               r30.0<1>:uq   r3.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $25
(W)     mov (1|M0)               r2.5<1>:q     r5.0<0;1,0>:ud                   {$2.dst}             //  ALU pipe: int; $32
// B004: [inDivergent],  Preds:{B027, B003},  Succs:{B005, B026}
_0_036:
(W)     load.ugm.d32x1t.a64 (1|M0)  r6:1        [r28:1]            {I@3,$3} // ex_desc:0x0; desc:0x2108580 // $34
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r6.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $35
(W&f3.0) jmpi                                _0_037                                                  //  ALU pipe: int; $36
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B026}
_0_038:
        mov (16|M0)              r6.0<2>:f     r30.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $38
        mov (16|M16)             r8.0<2>:f     r30.0<0;1,0>:f                                        //  ALU pipe: float; $38
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted,$4.src}  //  ALU pipe: int; $40
        mov (16|M0)              r6.1<2>:f     r30.1<0;1,0>:f                                        //  ALU pipe: float; $39
        mov (16|M16)             r8.1<2>:ud    r30.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $39
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$5} // ex_desc:0x0; desc:0x8200599 // $41
        cmp (32|M0)   (eq)f3.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$5.dst}          //  ALU pipe: int; $43
(~f3.0) goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $44
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_039:
        mov (16|M0)              r6.0<1>:d     r43.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $46
        mov (16|M16)             r7.0<1>:d     r45.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $46
        shl (32|M0)              r31.0<1>:d    r6.0<1;1,0>:d     4:w               {Compacted,I@1}   //  ALU pipe: int; $47
        add (32|M0)              r8.0<1>:d     r31.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $48
        sel (32|M0)   (lt)f0.0   r33.0<1>:ud   r8.0<1;1,0>:ud    0x200:uw              {I@1}         //  ALU pipe: int; $49
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r31.0<1;1,0>:ud   r33.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $50
(f3.0)  goto (32|M0)                         _0_040            _0_040                                //  ALU pipe: int; $51
// B007: [inDivergent],  Preds:{B006},  Succs:{B025}
_0_041:
        mov (32|M0)              r35.0<1>:ud   0xFF800000:ud                                         //  ALU pipe: int; $53
        goto (32|M0)                         _0_040            _0_042                                // $54
// B008: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_040:
        join (32|M0)                         _0_042                                                  // 
L984:
        mov (32|M0)              r35.0<1>:ud   0xFF800000:ud                                         //  ALU pipe: int; $56
// B009: [inDivergent],  Preds:{B024, B008},  Succs:{B010, B017}
_0_043:
(W)     mov (1|M0)               f3.0<1>:ud    r2.14<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $59
        mov (16|M0)              r6.0<2>:ud    r31.0<1;1,0>:ud                  {Compacted,$6.src}   //  ALU pipe: int; $58
        mov (16|M16)             r8.0<2>:ud    r32.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $58
        mov (16|M0)              r47.0<1>:q    r6.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $58
        mov (16|M16)             r49.0<1>:q    r8.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $58
(W&f3.0) jmpi                                _0_044                                                  //  ALU pipe: int; $59
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B016}
_0_045:
(W)     mov (1|M0)               f3.0<1>:ud    r2.13<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $61
(W&f3.0) jmpi                                _0_046                                                  //  ALU pipe: int; $61
// B011: [inDivergent],  Preds:{B010},  Succs:{B012, B015}
_0_047:
(W)     mov (1|M0)               f3.0<1>:ud    r2.12<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $63
(W&f3.0) jmpi                                _0_048                                                  //  ALU pipe: int; $63
// B012: [inDivergent],  Preds:{B011},  Succs:{B013, B014}
_0_049:
(W&f2.0) jmpi                                _0_050                                                  //  ALU pipe: int; $65
// B013: [inDivergent],  Preds:{B012},  Succs:{B022}
_0_051:
        mov (32|M0)              r37.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $67
(W)     jmpi                                 _0_052                                                  // $68
// B014: [inDivergent],  Preds:{B012},  Succs:{B022}
_0_050:
        shl (16|M0)              r6.0<1>:q     r47.0<1;1,0>:q    3:w               {Compacted,I@7}   //  ALU pipe: int; $70
        shl (16|M16)             r8.0<1>:q     r49.0<1;1,0>:q    3:w               {Compacted,I@7}   //  ALU pipe: int; $70
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $71
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $71
        load.ugm.d64.a64 (32|M0)  r14:4         [r10:4]            {I@1,$7} // ex_desc:0x0; desc:0x8400780 // $73
        mov (16|M0)              r18.0<2>:f    r14.0<1;1,0>:q                   {$7.dst}             //  ALU pipe: float; $74
        mov (16|M16)             r20.0<2>:f    r16.0<1;1,0>:q                                        //  ALU pipe: float; $74
        mov (16|M0)              r37.0<1>:ud   r18.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $74
        mov (16|M16)             r38.0<1>:ud   r20.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $74
(W)     jmpi                                 _0_052                                                  // $75
// B015: [inDivergent],  Preds:{B011},  Succs:{B022}
_0_048:
        shl (16|M0)              r6.0<1>:q     r47.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $77
        shl (16|M16)             r8.0<1>:q     r49.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $77
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $78
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $78
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $80
        mov (32|M0)              r37.0<1>:f    r14.0<1;1,0>:ud                  {$8.dst}             //  ALU pipe: float; $81
(W)     jmpi                                 _0_052                                                  // $82
// B016: [inDivergent],  Preds:{B010},  Succs:{B022}
_0_046:
        shl (16|M0)              r6.0<1>:q     r47.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $84
        shl (16|M16)             r8.0<1>:q     r49.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $84
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $85
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $85
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {A@1,$9} // ex_desc:0x0; desc:0x8200580 // $87
        mov (32|M0)              r37.0<1>:f    r14.0<1;1,0>:d                   {$9.dst}             //  ALU pipe: float; $88
(W)     jmpi                                 _0_052                                                  // $89
// B017: [inDivergent],  Preds:{B009},  Succs:{B018, B021}
_0_044:
(W&~f1.0) jmpi                               _0_053                                                  //  ALU pipe: int; $91
// B018: [inDivergent],  Preds:{B017},  Succs:{B019, B020}
_0_054:
(W&f0.0) jmpi                                _0_055                                                  //  ALU pipe: int; $93
// B019: [inDivergent],  Preds:{B018},  Succs:{B022}
_0_056:
        mov (32|M0)              r37.0<1>:ud   0x0:ud                              {Compacted,F@1}   //  ALU pipe: int; $95
(W)     jmpi                                 _0_052                                                  // $96
// B020: [inDivergent],  Preds:{B018},  Succs:{B022}
_0_055:
        shl (16|M0)              r6.0<1>:q     r47.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $98
        shl (16|M16)             r8.0<1>:q     r49.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $98
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $99
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $99
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r10:4]            {I@1,$10} // ex_desc:0x0; desc:0x8200B80 // $101
        shl (32|M0)              r37.0<1>:d    r14.0<1;1,0>:ud   16:w               {$10.dst}        //  ALU pipe: int; $102
(W)     jmpi                                 _0_052                                                  // $103
// B021: [inDivergent],  Preds:{B017},  Succs:{B022}
_0_053:
        shl (16|M0)              r6.0<1>:q     r47.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $105
        shl (16|M16)             r8.0<1>:q     r49.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $105
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $106
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $106
        load.ugm.d32.a64 (32|M0)  r37:2         [r10:4]            {I@1,$11} // ex_desc:0x0; desc:0x8200580 // $108
// B022: [inDivergent],  Preds:{B021, B020, B019, B016, B015, B014, B013},  Succs:{B023, B024}
_0_052:
        and (32|M0)              r6.0<1>:d     r37.0<1;1,0>:d    2147483647:d               {$11.dst} //  ALU pipe: int; $110
        cmp (32|M0)   (eq)f3.0   null<1>:f     r6.0<1;1,0>:f     0x7F800000:f               {I@1}    //  ALU pipe: float; $111
(~f3.0) cmp (32|M0)   (ne)f3.0   null<1>:f     r6.0<1;1,0>:f     r6.0<1;1,0>:f                       //  ALU pipe: float; $112
(~f3.0) goto (32|M0)                         _0_057            _0_057                                //  ALU pipe: int; $114
// B023: [inDivergent],  Preds:{B022},  Succs:{B026}
_0_058:
        mov (16|M0)              r6.0<2>:f     r30.0<0;1,0>:f                                        //  ALU pipe: float; $116
        mov (16|M16)             r8.0<2>:f     r30.0<0;1,0>:f                                        //  ALU pipe: float; $116
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $118
        mov (16|M0)              r6.1<2>:f     r30.1<0;1,0>:f                                        //  ALU pipe: float; $117
        mov (16|M16)             r8.1<2>:ud    r30.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $117
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$6} // ex_desc:0x0; desc:0x800058B // $119
        goto (32|M0)                         _0_057            _0_037                                // $120
// B024: [inDivergent],  Preds:{B022},  Succs:{B025, B009}
_0_057:
        join (32|M0)                         _0_042                                                  // 
L1800:
        cmp (32|M0)   (lt)f3.0   null<1>:f     r35.0<1;1,0>:f    r37.0<1;1,0>:f                      //  ALU pipe: float; $122
        add (32|M0)              r31.0<1>:d    r31.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $124
(f3.0)  mov (32|M0)              r35.0<1>:f    r37.0<1;1,0>:f                                        //  ALU pipe: float; $123
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r31.0<1;1,0>:ud   r33.0<1;1,0>:ud  {A@1}              //  ALU pipe: int; $125
(f3.0)  goto.b (32|M0)                       _0_042            _0_043                                //  ALU pipe: int; $126
// B025: [inDivergent],  Preds:{B024, B007},  Succs:{B026}
_0_042:
        join (32|M0)                         _0_037                                                  // 
L1888:
        shl (16|M0)              r6.0<1>:q     r43.0<1;1,0>:q    2:w               {Compacted,$6.src} //  ALU pipe: int; $128
        shl (16|M16)             r8.0<1>:q     r45.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $128
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $129
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $129
        store.ugm.d32.a64 (32|M0)  [r10:4]      r35:2              {I@1,$4} // ex_desc:0x0; desc:0x8000584 // $131
// B026: [inDivergent],  Preds:{B025, B023, B005, B004},  Succs:{B027, B028}
_0_037:
        join (32|M0)                         _0_034                                                  // 
L1952:
        add (16|M0)              r6.0<1>:q     r43.0<1;1,0>:q    r2.5<0;1,0>:q    {Compacted,$6.src} //  ALU pipe: int; $133
        add (16|M16)             r8.0<1>:q     r45.0<1;1,0>:q    r2.5<0;1,0>:q    {Compacted}        //  ALU pipe: int; $133
        mov (16|M0)              r39.0<1>:d    r6.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $134
        mov (16|M16)             r40.0<1>:d    r8.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $135
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r39.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $138
        mov (16|M0)              r41.0<1>:d    r6.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $136
        mov (16|M16)             r42.0<1>:d    r8.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $137
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r41.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $139
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r41.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $141
(~f3.0) goto (32|M0)                         _0_034            _0_034                                //  ALU pipe: int; $143
// B027: [inDivergent],  Preds:{B026},  Succs:{B004}
_0_059:
(f3.0)  sel (32|M0)              r6.0<1>:d     r39.0<1;1,0>:d    r23.0<1;1,0>:d                      //  ALU pipe: int; $145 R{} IR{}{O:3,O:3,},  R{} IR{}{E:4,E:12,},  {BC=1}
(f3.0)  sel (32|M0)              r8.0<1>:d     r41.0<1;1,0>:d    r25.0<1;1,0>:d                      //  ALU pipe: int; $146 R{} IR{}{O:4,O:4,},  R{} IR{}{E:5,E:13,},  {BC=1}
        mov (16|M0)              r43.0<2>:d    r6.0<1;1,0>:d                    {I@2}                //  ALU pipe: int; $149
        mov (16|M16)             r45.0<2>:d    r7.0<1;1,0>:d                                         //  ALU pipe: int; $150
        mov (16|M0)              r43.1<2>:d    r8.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $151
        mov (16|M16)             r45.1<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $152
(W)     jmpi                                 _0_036                                                  // $153
// B028: Preds:{B026, B002},  Succs:{}
_0_034:
        join (32|M0)                         L2192                                                   // 
L2192:
        sync.nop                             null                             {Compacted,$2.src}     // $155
(W)     mov (16|M0)              r127.0<1>:f   r22.0<1;1,0>:f                   {Compacted,$1.src}   //  ALU pipe: float; $155
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$12} // wr:1+0, rd:0; end of thread // $155
L2224:
(W)     mov (16|M0)              null<1>:ud    0x4A314E4E:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x569A3A56:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x11:ud                                               // 


//.BankConflicts: 2
//.ByteRMWs: 0
//


//.numALUInst: 131
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 21
//.allAtOneDistNum: 8
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 10
//.AfterReadTokenDepCount: 7
