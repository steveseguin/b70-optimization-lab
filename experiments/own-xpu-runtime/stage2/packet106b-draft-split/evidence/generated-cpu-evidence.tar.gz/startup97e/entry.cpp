#include <cxxabi.h>
#define main unexecuted_model_main
#include "main.cpp"
#undef main
int main(int argc,char**argv){std::unique_ptr<Engine> e;std::unique_ptr<mtp36::DraftRuntime> draft;try{
 Options a=parse(argc,argv);fs::create_directories(a.output);
 if(a.pipeline_canary){require(a.mini&&a.pipeline_mini&&a.rank>=0,"canary startup flags");save(a.output/"result.json","{\"passed\":true,\"canary_pre_engine\":true}");return 0;}
 packet26::dispatch.load(a.dispatch.string());Weights w(a);
 auto p=pipeline::split(plan(w,a),a.rank,false,a.draft_rank,a.target_split);
 require(p.g.h==2560&&p.g.context==4096&&p.g.vocab==248320,"real production dimensions");
 e=std::make_unique<Engine>(w,a,p);e->initialize();
 std::unique_ptr<p105::Runtime> head;if(e->split_head())head=std::make_unique<p105::Runtime>(*e);
 std::unique_ptr<p106::Runtime> suffix;if(e->split_draft()&&a.rank==0&&a.draft_capture.empty())suffix=std::make_unique<p106::Runtime>(*e);
 if(!a.draft_capture.empty()){e->prepare_plan();draft=std::make_unique<mtp36::DraftRuntime>(*e);}
 else{if(a.rank==0)pipeline::banks(*e);else{e->prepare_plan();e->prepare_commands();}
  {pipeline::SpeculativeImage image(*e);if(a.mtp)draft=std::make_unique<mtp36::DraftRuntime>(*e);}}
 save(a.output/"census.json",e->dev(0).arena.census());
 save(a.output/"result.json","{\"passed\":true,\"device_executed\":false,\"context\":4096,\"hidden\":2560,\"vocab\":248320,\"prepared\":"+std::string(e->prepared_path?"true":"false")+"}");
 draft.reset();e->shutdown();e.reset();return 0;
 }catch(const std::exception& x){std::cerr<<x.what()<<'\n';draft.reset();if(e){try{e->shutdown();}catch(...){}e.reset();}return 1;}}
