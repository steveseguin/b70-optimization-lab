/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106b-draft-split/build/controller/Intel: \
  /home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106b-draft-split/p106_controller_test.cpp \
  /home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106b-draft-split/native_controller.hpp \
  /home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106b-draft-split/host_spin.hpp \
  /home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106b-draft-split/p106_common.hpp
