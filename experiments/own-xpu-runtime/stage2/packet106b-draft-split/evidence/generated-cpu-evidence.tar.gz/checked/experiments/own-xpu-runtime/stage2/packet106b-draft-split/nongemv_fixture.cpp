#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106b-draft-split/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106b-draft-split/nongemv_fixture.cpp"
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106b-draft-split/build/checked/experiments/own-xpu-runtime/stage2/packet106b-draft-split/fixture_driver.cpp"
