//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE30ELj6144ELj1ELj1ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 60 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 60 -GRFBumpUpNumber 2 "
//.instCount 385
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r92.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r92.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r92.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.1)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.13)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r93.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.2)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r94.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=16 words (r92.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r1.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0067 (77)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r1.8)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r93.1)
//.declare V0069 (79)  rf=r size=8 type=d align=2 words (r93.4)
//.declare V0070 (80)  rf=r size=8 type=d alias=V0068+0 align=4 words (r93.2)
//.declare P01 (81)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0071 (82)  rf=r size=4 type=d align=2 words (r93.6)
//.declare V0072 (83)  rf=r size=4 type=d align=4 words (r1.2)
//.declare V0073 (84)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0074 (85)  rf=r size=4 type=ud alias=V0050+0 align=2 words (r2.12)
//.declare V0075 (86)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0076 (87)  rf=r size=4 type=ud alias=V0075+0 align=2 words (r3.0)
//.declare V0077 (88)  rf=r size=4 type=d alias=+0 align=2 words (r4.0)
//.declare V0078 (89)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0079 (90)  rf=r size=4 type=ud alias=V0072+0 align=2 words (r1.2)
//.declare V0080 (91)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0081 (92)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0082 (93)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0083 (94)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0084 (95)  rf=r size=4 type=ud alias=V0083+0 align=2 words (r10.0)
//.declare V0085 (96)  rf=r size=4 type=d alias=+4 align=2 words (r4.1)
//.declare V0086 (97)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0087 (98)  rf=r size=4 type=ud alias=V0086+0 align=2 words (r11.0)
//.declare V0088 (99)  rf=r size=4 type=f alias=+0 align=2 words (r12.0)
//.declare V0089 (100)  rf=r size=4 type=ud alias=V0077+0 align=2 words (r4.0)
//.declare V0090 (101)  rf=r size=4 type=f alias=+4 align=2 words (r12.1)
//.declare V0091 (102)  rf=r size=4 type=ud alias=V0085+0 align=2 words (r4.1)
//.declare V0092 (103)  rf=r size=4 type=f align=2 words (r13.0)
//.declare V0094 (105)  rf=r size=4 type=f align=2 words (r14.0)
//.declare V0096 (107)  rf=r size=4 type=f align=2 words (r15.0)
//.declare V0097 (108)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0098 (109)  rf=r size=4 type=f align=2 words (r17.0)
//.declare V0099 (110)  rf=r size=4 type=d align=2 words (r18.0)
//.declare V0100 (111)  rf=r size=4 type=ud alias=V0099+0 align=2 words (r18.0)
//.declare V0101 (112)  rf=r size=4 type=d align=2 words (r19.0)
//.declare V0102 (113)  rf=r size=4 type=d align=32 words (r20.0)
//.declare V0103 (114)  rf=r size=4 type=d align=2 words (r21.0)
//.declare V0104 (115)  rf=r size=4 type=d align=2 words (r22.0)
//.declare V0105 (116)  rf=r size=4 type=ud alias=V0103+0 align=2 words (r21.0)
//.declare V0106 (117)  rf=r size=4 type=ud alias=V0104+0 align=2 words (r22.0)
//.declare  (118)  rf=f16  size=2 type=uw align=1 words (f0.0)
//.declare V0107 (119)  rf=r size=4 type=d align=32 words (r95.0)
//.declare V0108 (120)  rf=r size=4 type=d align=2 words (r93.7)
//.declare V0109 (121)  rf=r size=4 type=ud alias=V0107+0 align=2 words (r95.0)
//.declare V0110 (122)  rf=r size=4 type=ud alias=V0071+0 align=2 words (r93.6)
//.declare V0111 (123)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0114 (126)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0116 (128)  rf=r size=4 type=ud alias=V0114+0 align=2 words (r3.0)
//.declare V0117 (129)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r2.13)
//.declare V0118 (130)  rf=r size=4 type=d align=32 words (r4.0)
//.declare P02 (133)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0121 (134)  rf=r size=8 type=ud alias=V0069+0 align=2 words (r93.4)
//.declare P03 (135)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P04 (136)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0123 (138)  rf=r size=128 type=d align=32 words (r96.0)
//.declare V0124 (139)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r94.0)
//.declare P05 (140)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P06 (141)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P07 (142)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0125 (143)  rf=r size=4 type=d align=2 words (r93.8)
//.declare V0126 (144)  rf=r size=2 type=w align=1 words (r93.18)
//.declare V0127 (145)  rf=r size=128 type=f align=32 words (r98.0)
//.declare P08 (146)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P09 (147)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0128 (148)  rf=r size=4 type=d alias=+0 align=2 words (r95.4)
//.declare V0129 (149)  rf=r size=4 type=d alias=+4 align=2 words (r95.5)
//.declare V0130 (150)  rf=r size=4 type=d align=2 words (r93.10)
//.declare V0131 (151)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0132 (152)  rf=r size=8 type=ud alias=V0131+0 align=4 words (r1.2)
//.declare V0133 (153)  rf=r size=8 type=d alias=V0131+0 align=4 words (r1.2)
//.declare V0134 (154)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0138 (158)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0139 (159)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P10 (160)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0140 (161)  rf=r size=4 type=ud alias=V0129+0 align=2 words (r95.5)
//.declare P11 (162)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0141 (163)  rf=r size=4 type=ud alias=V0128+0 align=2 words (r95.4)
//.declare V0142 (164)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r2.14)
//.declare V0144 (166)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0145 (167)  rf=r size=8 type=d alias=V0144+0 align=4 words (r1.2)
//.declare V0146 (168)  rf=r size=8 type=q align=4 words (r93.6)
//.declare V0148 (170)  rf=r size=4 type=d align=2 words (r2.0)
//.declare P12 (171)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0149 (172)  rf=r size=4 type=ud alias=V0130+0 align=2 words (r93.10)
//.declare P13 (173)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0150 (174)  rf=r size=4 type=ud alias=V0148+0 align=2 words (r2.0)
//.declare P14 (175)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P15 (177)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0152 (178)  rf=r size=8 type=d align=2 words (r1.2)
//.declare V0153 (179)  rf=r size=8 type=d alias=V0049+0 align=4 words (r2.10)
//.declare V0154 (180)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0155 (181)  rf=r size=8 type=ud alias=V0154+0 align=4 words (r3.0)
//.declare V0156 (182)  rf=r size=8 type=d alias=V0154+0 align=4 words (r3.0)
//.declare V0157 (183)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0160 (186)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0161 (187)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0162 (188)  rf=r size=8 type=d align=2 words (r7.0)
//.declare V0163 (189)  rf=r size=8 type=d alias=V0161+0 align=4 words (r6.0)
//.declare V0164 (190)  rf=r size=8 type=q align=4 words (r9.0)
//.declare V0165 (191)  rf=r size=8 type=ud alias=V0162+0 align=2 words (r7.0)
//.declare V0166 (192)  rf=r size=8 type=ud alias=V0152+0 align=2 words (r1.2)
//.declare V0167 (193)  rf=r size=8 type=ud alias=V0164+0 align=4 words (r9.0)
//.declare V0168 (194)  rf=r size=8 type=d alias=V0164+0 align=4 words (r9.0)
//.declare V0169 (195)  rf=r size=4 type=d align=32 words (r10.0)
//.declare V0170 (196)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0171 (197)  rf=r size=8 type=q align=4 words (r93.7)
//.declare V0172 (198)  rf=r size=8 type=q align=4 words (r12.0)
//.declare V0173 (199)  rf=r size=8 type=ud alias=V0172+0 align=4 words (r12.0)
//.declare V0174 (200)  rf=r size=8 type=d alias=V0172+0 align=4 words (r12.0)
//.declare V0175 (201)  rf=r size=4 type=d align=32 words (r13.0)
//.declare V0177 (203)  rf=r size=8 type=q align=4 words (r95.1)
//.declare V0178 (204)  rf=r size=128 type=d align=32 words (r100.0)
//.declare V0179 (205)  rf=r size=4 type=d align=2 words (r93.11)
//.declare V0180 (206)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0182 (208)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r3.0)
//.declare V0185 (211)  rf=r size=256 type=uq align=32 words (r17.0)
//.declare V0186 (212)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0187 (213)  rf=r size=256 type=q alias=V0185+0 align=32 words (r17.0)
//.declare V0188 (214)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0191 (217)  rf=r size=256 type=uq align=32 words (r21.0)
//.declare V0192 (218)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0193 (219)  rf=r size=256 type=q alias=V0191+0 align=32 words (r21.0)
//.declare V0194 (220)  rf=r size=128 type=d align=32 words (r37.0)
//.declare V0195 (221)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0196 (222)  rf=r size=128 type=ub alias=V0186+0 align=32 words (r29.0)
//.declare V0197 (223)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0198 (224)  rf=r size=128 type=ud alias=V0197+0 align=32 words (r52.0)
//.declare V0199 (225)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0200 (226)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0201 (227)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0202 (228)  rf=r size=128 type=d align=32 words (r81.0)
//.declare V0203 (229)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0204 (230)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0205 (231)  rf=r size=128 type=ud alias=V0201+0 align=32 words (r62.0)
//.declare V0206 (232)  rf=r size=128 type=ud alias=V0204+0 align=32 words (r74.0)
//.declare  (233)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0208 (235)  rf=r size=128 type=w alias=V0192+0 align=32 words (r33.0)
//.declare V0212 (239)  rf=r size=128 type=w alias=V0194+0 align=32 words (r37.0)
//.declare V0215 (242)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0217 (244)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0219 (246)  rf=r size=128 type=f alias=V0203+0 align=32 words (r10.0)
//.declare V0220 (247)  rf=r size=128 type=f alias=V0217+0 align=32 words (r6.0)
//.declare V0222 (249)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0223 (250)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0224 (251)  rf=r size=128 type=ud alias=V0223+0 align=32 words (r58.0)
//.declare V0225 (252)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0226 (253)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0227 (254)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0228 (255)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0229 (256)  rf=r size=128 type=d align=32 words (r39.0)
//.declare V0230 (257)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0231 (258)  rf=r size=128 type=ud alias=V0227+0 align=32 words (r78.0)
//.declare V0232 (259)  rf=r size=128 type=ud alias=V0230+0 align=32 words (r8.0)
//.declare  (260)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0233 (261)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0235 (263)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0237 (265)  rf=r size=128 type=f alias=V0229+0 align=32 words (r39.0)
//.declare V0238 (266)  rf=r size=128 type=f alias=V0235+0 align=32 words (r30.0)
//.declare V0240 (268)  rf=r size=128 type=d align=32 words (r69.0)
//.declare V0241 (269)  rf=r size=128 type=ub alias=V0188+0 align=32 words (r31.0)
//.declare V0242 (270)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0243 (271)  rf=r size=128 type=ud alias=V0242+0 align=32 words (r72.0)
//.declare V0244 (272)  rf=r size=128 type=d align=32 words (r86.0)
//.declare V0245 (273)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0246 (274)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0247 (275)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0248 (276)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0249 (277)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0250 (278)  rf=r size=128 type=ud alias=V0246+0 align=32 words (r14.0)
//.declare V0251 (279)  rf=r size=128 type=ud alias=V0249+0 align=32 words (r32.0)
//.declare  (280)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0252 (281)  rf=r size=128 type=d align=32 words (r41.0)
//.declare V0254 (283)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0256 (285)  rf=r size=128 type=f alias=V0248+0 align=32 words (r72.0)
//.declare V0257 (286)  rf=r size=128 type=f alias=V0254+0 align=32 words (r68.0)
//.declare V0259 (288)  rf=r size=128 type=d align=32 words (r89.0)
//.declare V0260 (289)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0261 (290)  rf=r size=128 type=ud alias=V0260+0 align=32 words (r4.0)
//.declare V0262 (291)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0263 (292)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0264 (293)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0265 (294)  rf=r size=128 type=d align=32 words (r79.0)
//.declare V0266 (295)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0267 (296)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0268 (297)  rf=r size=128 type=ud alias=V0264+0 align=32 words (r49.0)
//.declare V0269 (298)  rf=r size=128 type=ud alias=V0267+0 align=32 words (r70.0)
//.declare  (299)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0270 (300)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0272 (302)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0274 (304)  rf=r size=128 type=f alias=V0266+0 align=32 words (r7.0)
//.declare V0275 (305)  rf=r size=128 type=f alias=V0272+0 align=32 words (r3.0)
//.declare V0279 (309)  rf=r size=256 type=uq align=32 words (r25.0)
//.declare V0280 (310)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0281 (311)  rf=r size=256 type=q alias=V0279+0 align=32 words (r25.0)
//.declare V0282 (312)  rf=r size=128 type=d align=32 words (r43.0)
//.declare V0285 (315)  rf=r size=256 type=uq align=32 words (r39.0)
//.declare V0286 (316)  rf=r size=128 type=d align=32 words (r45.0)
//.declare V0287 (317)  rf=r size=256 type=q alias=V0285+0 align=32 words (r39.0)
//.declare V0288 (318)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0289 (319)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0290 (320)  rf=r size=128 type=ub alias=V0280+0 align=32 words (r35.0)
//.declare V0291 (321)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0292 (322)  rf=r size=128 type=ud alias=V0291+0 align=32 words (r28.0)
//.declare V0293 (323)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0294 (324)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0295 (325)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0296 (326)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0297 (327)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0298 (328)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0299 (329)  rf=r size=128 type=ud alias=V0295+0 align=32 words (r76.0)
//.declare V0300 (330)  rf=r size=128 type=ud alias=V0298+0 align=32 words (r5.0)
//.declare  (331)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0302 (333)  rf=r size=128 type=w alias=V0286+0 align=32 words (r45.0)
//.declare V0306 (337)  rf=r size=128 type=w alias=V0288+0 align=32 words (r47.0)
//.declare V0309 (340)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0311 (342)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0313 (344)  rf=r size=128 type=f alias=V0297+0 align=32 words (r30.0)
//.declare V0314 (345)  rf=r size=128 type=f alias=V0311+0 align=32 words (r26.0)
//.declare V0316 (347)  rf=r size=128 type=d align=32 words (r63.0)
//.declare V0317 (348)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0318 (349)  rf=r size=128 type=ud alias=V0317+0 align=32 words (r66.0)
//.declare V0319 (350)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0320 (351)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0321 (352)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0322 (353)  rf=r size=128 type=d align=32 words (r37.0)
//.declare V0323 (354)  rf=r size=128 type=d align=32 words (r51.0)
//.declare V0324 (355)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0325 (356)  rf=r size=128 type=ud alias=V0321+0 align=32 words (r11.0)
//.declare V0326 (357)  rf=r size=128 type=ud alias=V0324+0 align=32 words (r28.0)
//.declare  (358)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0327 (359)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0329 (361)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0331 (363)  rf=r size=128 type=f alias=V0323+0 align=32 words (r51.0)
//.declare V0332 (364)  rf=r size=128 type=f alias=V0329+0 align=32 words (r44.0)
//.declare V0334 (366)  rf=r size=128 type=d align=32 words (r87.0)
//.declare V0335 (367)  rf=r size=128 type=ub alias=V0282+0 align=32 words (r43.0)
//.declare V0336 (368)  rf=r size=128 type=d align=32 words (r90.0)
//.declare V0337 (369)  rf=r size=128 type=ud alias=V0336+0 align=32 words (r90.0)
//.declare V0338 (370)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0339 (371)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0340 (372)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0341 (373)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0342 (374)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0343 (375)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0344 (376)  rf=r size=128 type=ud alias=V0340+0 align=32 words (r34.0)
//.declare V0345 (377)  rf=r size=128 type=ud alias=V0343+0 align=32 words (r49.0)
//.declare  (378)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0346 (379)  rf=r size=128 type=d align=32 words (r53.0)
//.declare V0348 (381)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0350 (383)  rf=r size=128 type=f alias=V0342+0 align=32 words (r66.0)
//.declare V0351 (384)  rf=r size=128 type=f alias=V0348+0 align=32 words (r62.0)
//.declare V0353 (386)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0354 (387)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0355 (388)  rf=r size=128 type=ud alias=V0354+0 align=32 words (r24.0)
//.declare V0356 (389)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0357 (390)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0358 (391)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0359 (392)  rf=r size=128 type=d align=32 words (r71.0)
//.declare V0360 (393)  rf=r size=128 type=d align=32 words (r75.0)
//.declare V0361 (394)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0362 (395)  rf=r size=128 type=ud alias=V0358+0 align=32 words (r55.0)
//.declare V0363 (396)  rf=r size=128 type=ud alias=V0361+0 align=32 words (r64.0)
//.declare  (397)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0364 (398)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0366 (400)  rf=r size=128 type=d align=32 words (r73.0)
//.declare V0368 (402)  rf=r size=128 type=f alias=V0360+0 align=32 words (r75.0)
//.declare V0369 (403)  rf=r size=128 type=f alias=V0366+0 align=32 words (r73.0)
//.declare P16 (404)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0370 (405)  rf=r size=128 type=ud alias=V0178+0 align=32 words (r100.0)
//.declare V0371 (406)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0372 (407)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0373 (408)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0374 (409)  rf=r size=128 type=uw alias=V0372+0 align=32 words (r5.0)
//.declare V0375 (410)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (411)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P17 (412)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0378 (415)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0379 (416)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0380 (417)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0381 (418)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0382 (419)  rf=r size=128 type=uw alias=V0380+0 align=32 words (r12.0)
//.declare V0383 (420)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (421)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P18 (422)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0386 (425)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0387 (426)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0388 (427)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0389 (428)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0390 (429)  rf=r size=128 type=uw alias=V0388+0 align=32 words (r19.0)
//.declare V0391 (430)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (431)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P19 (432)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0394 (435)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0395 (436)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0396 (437)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0397 (438)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0398 (439)  rf=r size=128 type=uw alias=V0396+0 align=32 words (r26.0)
//.declare V0399 (440)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (441)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P20 (442)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0402 (445)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0403 (446)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0404 (447)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0405 (448)  rf=r size=128 type=f align=32 words (r110.0)
//.declare V0406 (449)  rf=r size=128 type=uw alias=V0404+0 align=32 words (r33.0)
//.declare V0407 (450)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (451)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P21 (452)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P22 (453)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P23 (454)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0409 (456)  rf=r size=128 type=f align=32 words (r3.0)
//.declare P24 (457)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0410 (458)  rf=r size=128 type=d align=32 words (r113.0)
//.declare V0411 (459)  rf=r size=128 type=d alias=V0409+0 align=32 words (r3.0)
//.declare V0412 (460)  rf=r size=128 type=d align=32 words (r5.0)
//.declare P25 (461)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0413 (462)  rf=r size=128 type=ud alias=V0412+0 align=32 words (r5.0)
//.declare V0414 (463)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0415 (464)  rf=r size=128 type=ud alias=V0410+0 align=32 words (r113.0)
//.declare V0416 (465)  rf=r size=128 type=ud alias=V0414+0 align=32 words (r3.0)
//.declare V0417 (466)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0418 (467)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0419 (468)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0420 (469)  rf=r size=128 type=ud alias=V0418+0 align=32 words (r8.0)
//.declare V0421 (470)  rf=r size=128 type=ud alias=V0419+0 align=32 words (r10.0)
//.declare V0422 (471)  rf=r size=64 type=w align=32 words (r112.0)
//.declare V0423 (472)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0424 (473)  rf=r size=128 type=ud alias=V0423+0 align=32 words (r3.0)
//.declare V0426 (475)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0429 (478)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare P26 (479)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0430 (480)  rf=r size=2 type=uw align=1 words (r93.19)
//.declare V0432 (482)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare V0433 (483)  rf=r size=4 type=uw alias=V0432+0 align=2 words (r3.0)
//.declare A05 (484)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0435 (486)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare P27 (488)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P28 (489)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P29 (490)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P30 (491)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P31 (492)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P32 (493)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P33 (494)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0437 (495)  rf=r size=2 type=b align=1 words (r1.8)
//.declare V0438 (496)  rf=r size=2 type=w align=1 words (r2.0)
//.declare V0439 (497)  rf=r size=2 type=ub alias=V0437+0 align=1 words (r1.8)
//.declare P34 (498)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0440 (499)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0441 (500)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0443 (502)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0446 (505)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare  (506)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (507)  rf=r size=4 type=d alias=V0146+0 align=2 words (r93.12)
//.declare  (508)  rf=r size=128 type=w alias=V0423+0 align=32 words (r3.0)
//.declare  (509)  rf=r size=8 type=f align=8 words (r12.0)
//.declare  (510)  rf=r size=8 type=ud align=8 words (r4.0)
//.declare  (511)  rf=r size=8 type=d align=8 words (r95.4)
//.declare  (512)  rf=r size=64 type=uw align=32 words (r37.0)
//.declare  (513)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (514)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare  (515)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (516)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (517)  rf=r size=4 type=f align=2 words (r7.0)
//.declare  (518)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare  (519)  rf=r size=2 type=w align=1 words (r1.4)
//.declare  (520)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare  (521)  rf=r size=4 type=ud align=32 words (r8.0)
//.declare  (522)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (523)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (526)  rf=r size=2 type=uw align=1 words (r36.0)
//.declare  (528)  rf=r size=128 type=w alias=V0419+0 align=32 words (r10.0)
//.declare  (529)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare  (530)  rf=r size=2 type=uw align=1 words (r2.0)
//.declare  (532)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (535)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (536)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (537)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (538)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (543)  rf=r size=128 type=uq alias=+0 align=32 words (r9.0)
//.declare  (544)  rf=r size=128 type=uq alias=+0 align=32 words (r11.0)
//.declare  (545)  rf=r size=128 type=uq alias=+0 align=32 words (r13.0)
//.declare  (546)  rf=r size=128 type=uq alias=+0 align=32 words (r15.0)
//.declare r0 (547)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (548)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (549)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (550)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :q       |    0x8 | r1       | inline+0x0       |
// | V0041    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0042    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r2       | cti+0x20         |
// | V0045    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0050    | :d       |    0x4 | r2+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r2+0x34  | cti+0x54         |
// | V0052    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0054    | :b       |    0x1 | r3       | cti+0x60         |
// | V0055    | :b       |    0x1 | r3+0x4   | cti+0x64         |
// | V0037    | :uq      |    0x8 | r3+0x8   | cti+0x68         |
// | V0038    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r92.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r1.8<2>:b     r92.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     mov (8|M0)               r94.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {@2,$0.dst}          //  ALU pipe: int; $9
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $12
(W)     mov (1|M0)               r3.0<1>:q     r2.0<0;1,0>:w                    {@2,$1.dst}          //  ALU pipe: int; $9
(W)     add (8|M0)               r94.8<1>:w    r94.0<1;1,0>:w    8:w                                 //  ALU pipe: int; $5
(W)     add (1|M0)               r93.1<1>:q    r92.1<0;1,0>:ud   r3.0<0;1,0>:q    {I@2}              //  ALU pipe: int; $10
(W)     add (16|M0)              r94.16<1>:w   r94.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $6
(W)     mov (2|M0)               r93.0<1>:d    r2.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     mov (2|M0)               r93.4<1>:d    r93.2<1;1,0>:d                   {I@3}                //  ALU pipe: int; $11
(W&~f0.0) jmpi                               _0_026                                                  //  ALU pipe: int; $13
// B002: Preds:{B001},  Succs:{B004}
_0_027:
(W)     mov (1|M0)               r93.6<1>:d    -1:w                                                  //  ALU pipe: int; $15
(W)     jmpi                                 _0_028                                                  // $16
// B003: Preds:{B001},  Succs:{B004}
_0_026:
(W)     mov (1|M0)               r1.2<2>:d     r93.1<0;1,0>:q                                        //  ALU pipe: int; $18
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $19
(W)     mov (1|M0)               r2.0<1>:f     r2.12<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $20
(W)     mov (1|M0)               r7.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $25
(W)     math.inv (1|M0)          r6.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $24
(W)     mov (1|M0)               r5.0<1>:f     r1.2<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $23
(W)     mad (1|M0)               r8.0<1>:f     r6.0<0;0>:f       r7.0<0;0>:f       r6.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $25
(W)     mov (1|M0)               r3.0<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $21
(W)     mov (1|M0)               r10.0<1>:ud   r5.0<0;1,0>:f                    {F@2}                //  ALU pipe: int; $27
(W)     mul (1|M0)               r9.0<1>:f     r5.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $26
(W)     add (1|M0)               r4.0<1>:d     r2.12<0;1,0>:d    -r3.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $22
(W)     add (1|M0)               r4.1<1>:d     r1.2<0;1,0>:d     -r10.0<0;1,0>:d  {I@2}              //  ALU pipe: int; $28
(W)     mov (1|M0)               r11.0<1>:ud   r9.0<0;1,0>:f                    {F@1}                //  ALU pipe: int; $29
(W)     mov (1|M0)               r12.0<1>:f    r4.0<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $30
(W)     mov (1|M0)               r12.1<1>:f    r4.1<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $30
(W)     mov (1|M0)               r13.0<1>:f    r11.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $32
(W)     mad (1|M0)               r14.0<1>:f    r5.0<0;0>:f       r13.0<0;0>:f      -r2.0<0>:f       {F@1} //  ALU pipe: float; $34
(W)     mad (1|M0)               r15.0<1>:f    r12.1<0;0>:f      r13.0<0;0>:f      -r12.0<0>:f       //  ALU pipe: float; $36
(W)     add (1|M0)               r16.0<1>:f    r14.0<0;1,0>:f    r15.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $37
(W)     mul (1|M0)               r17.0<1>:f    r8.0<0;1,0>:f     r16.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $38
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $39
(W)     mov (1|M0)               r18.0<1>:ud   r17.0<0;1,0>:f                   {A@1}                //  ALU pipe: int; $40
(W)     add (1|M0)               r19.0<1>:d    r18.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $41
(W)     mul (1|M0)               acc0.0<1>:d   r19.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $42
(W)     macl (1|M0)              r20.0<1>:d    r19.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $43
(W)     add (1|M0)               r21.0<1>:d    r1.2<0;1,0>:d     -r20.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $43
(W)     cmp (1|M0)    (ge)f0.0   r22.0<1>:ud   r21.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@1}              //  ALU pipe: int; $44
(W)     add3 (1|M0)              r93.6<1>:d    r18.0<0;0>:d      r11.0<0;0>:d      -r22.0<0>:d      {I@1} //  ALU pipe: int; $45
// B004: Preds:{B003, B002},  Succs:{B005, B006}
_0_028:
(W)     mul (1|M0)               acc0.0<1>:ud  r93.6<0;1,0>:ud   r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $47
(W)     macl (1|M0)              r95.0<1>:ud   r93.6<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $48
(W)     mul (1|M0)               acc0.0<1>:ud  r93.6<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $48
(W)     mach (1|M0)              r2.0<1>:d     r93.6<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $54
(W)     macl (1|M0)              r3.0<1>:ud    r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; $55
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $55
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r93.4<0;1,0>:ud   r3.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $67
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r93.4<0;1,0>:ud   r3.0<0;1,0>:ud                      //  ALU pipe: int; $61
(W)     mach (1|M0)              r4.0<1>:d     r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; 
        mov (32|M0)              r96.0<1>:d    r94.0<1;1,0>:uw                                       //  ALU pipe: int; $66
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r93.5<0;1,0>:d    r4.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $68
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r93.5<0;1,0>:d    r4.0<0;1,0>:d                       //  ALU pipe: int; $62
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:ud    r93.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $70
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r93.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $64
(W)     mov (1|M0)               r93.7<1>:d    r2.0<0;1,0>:d                                         //  ALU pipe: int; $53
(W&f1.0) jmpi                                _0_029                                                  //  ALU pipe: int; $72
// B005: Preds:{B004},  Succs:{B017}
_0_030:
        mov (32|M0)              r98.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $76
(W)     mov (1|M0)               r93.8<1>:d    0:w                                                   //  ALU pipe: int; $74
(W)     mov (1|M0)               r93.18<1>:w   0:w                                                   //  ALU pipe: int; $75
(W)     jmpi                                 _0_031                                                  // $77
// B006: Preds:{B004},  Succs:{B007, B008}
_0_029:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r93.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $79
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r93.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $80
(W&~f1.0) jmpi                               _0_032                                                  //  ALU pipe: int; $82
// B007: Preds:{B006},  Succs:{B009}
_0_033:
(W)     mov (2|M0)               r95.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $84
(W)     mov (1|M0)               r93.10<1>:d   r2.12<0;1,0>:d                                        //  ALU pipe: int; $86
(W)     jmpi                                 _0_034                                                  // $87
// B008: Preds:{B006},  Succs:{B009}
_0_032:
(W)     mul (1|M0)               acc0.0<1>:ud  r93.6<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $90
(W)     mach (1|M0)              r2.0<1>:d     r93.6<0;1,0>:ud   0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.2<2>:ud    r93.6<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $89
(W)     mov (1|M0)               r1.3<2>:d     r2.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $94
(W)     add (1|M0)               r4.0<1>:q     r1.1<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $95
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $97
(W)     mov (1|M0)               r95.4<1>:d    r5.0<0;1,0>:d                    {Compacted,$2.dst}   //  ALU pipe: int; $98
(W)     mov (1|M0)               r95.5<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $99
(W)     mov (1|M0)               r93.10<1>:d   r5.2<0;1,0>:d                                         //  ALU pipe: int; $100
// B009: Preds:{B008, B007},  Succs:{B010, B011}
_0_034:
(W)     cmp (32|M0)   (gt)f3.0   null<1>:ud    r95.5<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $102
(W&~f3.0) cmp (32|M0) (ge)f3.0   null<1>:ud    r95.4<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; $103
(W&~f3.0) jmpi                               _0_035                                                  //  ALU pipe: int; $105
// B010: Preds:{B009},  Succs:{B017}
_0_036:
        mov (32|M0)              r98.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $109
(W)     mov (1|M0)               r93.8<1>:d    0:w                                                   //  ALU pipe: int; $107
(W)     mov (1|M0)               r93.18<1>:w   0:w                                                   //  ALU pipe: int; $108
(W)     jmpi                                 _0_031                                                  // $110
// B011: Preds:{B009},  Succs:{B012, B013}
_0_035:
(W)     mov (1|M0)               r1.2<1>:d     r95.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $112
(W)     mov (1|M0)               r1.3<1>:d     r93.7<0;1,0>:d                                        //  ALU pipe: int; $113
(W)     cmp (32|M0)   (le)f1.0   null<1>:ud    r93.10<0;1,0>:ud  r2.12<0;1,0>:ud  {I@7}              //  ALU pipe: int; $119
(W)     add (1|M0)               r93.6<1>:q    r93.1<0;1,0>:q    -r1.1<0;1,0>:q   {I@2}              //  ALU pipe: int; $116
(W)     add (1|M0)               r2.0<1>:d     r2.12<0;1,0>:d    -r95.5<0;1,0>:d                     //  ALU pipe: int; $118
(W)     cmp (32|M0)   (gt)f3.0   null<1>:ud    r93.10<0;1,0>:ud  r93.12<0;1,0>:ud {I@2}              //  ALU pipe: int; $122
(W&f1.0) cmp (32|M0)  (le)f1.0   null<1>:ud    r93.10<0;1,0>:ud  r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $120
(W)     mov (1|M0)               r3.0<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $123
(W)     and (1|M0)               f2.0<1>:ud    f1.0<0;1,0>:ud    r3.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $123
(W&f2.0) jmpi                                _0_037                                                  //  ALU pipe: int; $124
// B012: Preds:{B011},  Succs:{B017}
_0_038:
        mov (32|M0)              r98.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $128
(W)     mov (1|M0)               r1.4<1>:w     1:w                                                   //  ALU pipe: int; $126
(W)     mov (1|M0)               r93.8<1>:d    0:w                                                   //  ALU pipe: int; $127
(W&f1.0) sel (1|M0)              r93.18<1>:w   r1.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $126
(W)     jmpi                                 _0_031                                                  // $129
// B013: Preds:{B011},  Succs:{B014}
_0_037:
(W)     mul (1|M0)               acc0.0<1>:ud  r95.4<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $132
(W)     macl (1|M0)              r2.0<1>:ud    r95.4<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $133
(W)     mul (1|M0)               acc0.0<1>:ud  r95.4<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $133
(W)     mach (1|M0)              r4.0<1>:d     r95.4<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r3.0<2>:f     r2.0<0;1,0>:f                    {I@3}                //  ALU pipe: float; $133
(W)     mov (1|M0)               r3.1<2>:d     r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $137
(W)     mov (2|M0)               r1.2<1>:d     r2.10<1;1,0>:d                                        //  ALU pipe: int; $131
(W)     add (1|M0)               r5.0<1>:q     r3.0<0;1,0>:q     r95.5<0;1,0>:ud  {A@1}              //  ALU pipe: int; $139
        shl (32|M0)              r100.0<1>:d   r96.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $156
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r93.6<0;1,0>:q   {I@2}              //  ALU pipe: int; $140
        mov (32|M0)              r98.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $158
(W)     mov (2|M0)               r7.0<1>:f     r6.0<1;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $141
(W)     mul (1|M0)               r12.0<2>:ud   r93.6<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $149
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw   {F@1}              //  ALU pipe: int; $142
(W)     macl (1|M0)              r8.0<1>:ud    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $143
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw                      //  ALU pipe: int; $143
(W)     mach (1|M0)              r10.0<1>:d    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r7.0<0;1,0>:ud    r1.6<0;1,0>:uw                      //  ALU pipe: int; $144
(W)     macl (1|M0)              r11.0<1>:d    r7.0<0;1,0>:ud    r1.3<0;1,0>:d                       //  ALU pipe: int; $145
(W)     mul (1|M0)               acc0.0<1>:d   r1.2<0;1,0>:ud    r7.2<0;1,0>:uw                      //  ALU pipe: int; $146
(W)     add (1|M0)               r10.0<1>:d    r10.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $145
(W)     macl (1|M0)              r11.0<1>:d    r1.2<0;1,0>:ud    r7.1<0;1,0>:d                       //  ALU pipe: int; $147
(W)     mul (1|M0)               acc0.0<1>:ud  r93.6<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $150
(W)     mach (1|M0)              r13.0<1>:d    r93.6<0;1,0>:ud   0x3000:ud                           //  ALU pipe: int; 
(W)     mov (1|M0)               r9.0<2>:f     r8.0<0;1,0>:f                                         //  ALU pipe: float; $143
(W)     add (1|M0)               r9.1<2>:d     r10.0<0;1,0>:d    r11.0<0;1,0>:d   {I@3}              //  ALU pipe: int; $147
(W)     mov (1|M0)               r12.1<2>:d    r13.0<0;1,0>:d                   {I@2}                //  ALU pipe: int; $154
(W)     mov (1|M0)               r93.11<1>:d   32767:w                                               //  ALU pipe: int; $157
(W)     add (1|M0)               r93.7<1>:q    r9.0<0;1,0>:q     r1.0<0;1,0>:q    {A@1}              //  ALU pipe: int; $148
(W)     add (1|M0)               r95.1<1>:q    r12.0<0;1,0>:q    r1.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $155
// B014: [inDivergent],  Preds:{B016, B013},  Succs:{B015, B016}
_0_039:
        shl (32|M0)              r3.0<1>:d     r100.0<1;1,0>:d   1:w               {Compacted}       //  ALU pipe: int; $160
        mov (16|M0)              r5.0<2>:ud    r3.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $162
        mov (16|M16)             r7.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $162
        add (16|M0)              r9.0<1>:q     r93.7<0;1,0>:q    r5.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $162
        add (16|M16)             r11.0<1>:q    r93.7<0;1,0>:q    r7.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $162
        mov (16|M0)              r17.0<1>:uq   r9.0<1;1,0>:uq                   {Compacted,I@2}      //  ALU pipe: int; $163
        mov (16|M16)             r19.0<1>:uq   r11.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $163
        load.ugm.d32.a64 (32|M0)  r29:2         [r17:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200580 // $164
        add (16|M0)              r13.0<1>:q    r95.1<0;1,0>:q    r5.0<2;1,0>:ud                      //  ALU pipe: int; $166
        add (16|M16)             r15.0<1>:q    r95.1<0;1,0>:q    r7.0<2;1,0>:ud                      //  ALU pipe: int; $166
        mov (16|M0)              r21.0<1>:uq   r13.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $167
        mov (16|M16)             r23.0<1>:uq   r15.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $167
        load.ugm.d32.a64 (32|M0)  r31:2         [r17:4+0x4]        {$4} // ex_desc:0x4000; desc:0x8200580 // $165
        load.ugm.d32.a64 (32|M0)  r33:2         [r21:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $168
        add (16|M0)              r25.0<1>:q    r9.0<1;1,0>:q     8:w               {Compacted}       //  ALU pipe: int; $222
        add (16|M16)             r27.0<1>:q    r11.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $222
        load.ugm.d32.a64 (32|M0)  r35:2         [r25:4]            {I@1,$6} // ex_desc:0x0; desc:0x8200580 // $224
        load.ugm.d32.a64 (32|M0)  r37:2         [r21:4+0x4]        {$7} // ex_desc:0x4000; desc:0x8200580 // $169
        add (16|M0)              r39.0<1>:q    r13.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $226
        add (16|M16)             r41.0<1>:q    r15.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $226
        load.ugm.d32.a64 (32|M0)  r43:2         [r25:4+0x4]        {$8} // ex_desc:0x4000; desc:0x8200580 // $225
        load.ugm.d32.a64 (32|M0)  r45:2         [r39:4]            {I@1,$9} // ex_desc:0x0; desc:0x8200580 // $228
        load.ugm.d32.a64 (32|M0)  r47:2         [r39:4+0x4]        {$10} // ex_desc:0x4000; desc:0x8200580 // $229
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r100.0<1;1,0>:ud  0x1700:uw                           //  ALU pipe: int; $282
        shl (32|M0)              r49.0<1>:d    r29.1<4;1,0>:ub   8:w               {$3.dst}          //  ALU pipe: int; $170
        mov (32|M0)              r52.0<1>:ud   r29.0<4;1,0>:ub                                       //  ALU pipe: int; $171
        shl (32|M0)              r55.0<1>:d    r29.3<4;1,0>:ub   8:w                                 //  ALU pipe: int; $186
        or (32|M0)               r60.0<1>:d    r49.0<1;1,0>:d    r52.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $172
        mov (32|M0)              r58.0<1>:ud   r29.2<4;1,0>:ub                                       //  ALU pipe: int; $187
        bfn.((s0|s1)&s2) (32|M0)   r62.0<1>:ud  r49.0<1;0>:ud    r52.0<1;0>:ud     r93.11<0>:ud      //  ALU pipe: int; $174
        shl (32|M0)              r66.0<1>:d    r60.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $173
        shl (32|M0)              r69.0<1>:d    r31.1<4;1,0>:ub   8:w               {$4.dst}          //  ALU pipe: int; $198
        or (32|M0)               r64.0<1>:d    r55.0<1;1,0>:d    r58.0<1;1,0>:d   {Compacted,I@4}    //  ALU pipe: int; $188
        cmp (32|M0)   (gt)f3.0   r74.0<1>:ud   r62.0<1;1,0>:ud   0x7F80:uw              {I@4}        //  ALU pipe: int; $176
        mov (32|M0)              r72.0<1>:ud   r31.0<4;1,0>:ub                                       //  ALU pipe: int; $199
        mov (32|M0)              r76.0<1>:d    r33.0<2;1,0>:uw                  {$5.dst}             //  ALU pipe: int; $182
        bfn.((s0|s1)&s2) (32|M0)   r78.0<1>:ud  r55.0<1;0>:ud    r58.0<1;0>:ud     r93.11<0>:ud      //  ALU pipe: int; $190
        or (32|M0)               r81.0<1>:d    r66.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $175
        shl (32|M0)              r84.0<1>:d    r64.0<1;1,0>:d    16:w               {Compacted,I@6}  //  ALU pipe: int; $189
        shl (32|M0)              r89.0<1>:d    r31.3<4;1,0>:ub   8:w                                 //  ALU pipe: int; $210
        or (32|M0)               r86.0<1>:d    r69.0<1;1,0>:d    r72.0<1;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $200
        shl (32|M0)              r6.0<1>:d     r76.0<1;1,0>:d    16:w               {Compacted,I@6}  //  ALU pipe: int; $183
        cmp (32|M0)   (gt)f2.0   r8.0<1>:ud    r78.0<1;1,0>:ud   0x7F80:uw              {I@6}        //  ALU pipe: int; $192
        mov (32|M0)              r4.0<1>:ud    r31.2<4;1,0>:ub                                       //  ALU pipe: int; $211
        mov (32|M0)              r12.0<1>:d    r33.1<2;1,0>:uw                                       //  ALU pipe: int; $194
        bfn.((s0|s1)&s2) (32|M0)   r14.0<1>:ud  r69.0<1;0>:ud    r72.0<1;0>:ud     r93.11<0>:ud      //  ALU pipe: int; $202
        bfn.(s0&s1|~s0&s2) (32|M0)   r10.0<1>:ud  r74.0<1;0>:ud  r81.0<1;0>:ud     r66.0<1>:ud      {I@7} //  ALU pipe: int; $177
        or (32|M0)               r17.0<1>:d    r84.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $191
        shl (32|M0)              r20.0<1>:d    r86.0<1;1,0>:d    16:w               {Compacted,@7,$7.src} //  ALU pipe: int; $201
        sync.nop                             null                             {Compacted,$8.src}     // $230
        shl (32|M0)              r25.0<1>:d    r35.1<4;1,0>:ub   8:w               {$6.dst}          //  ALU pipe: int; $230
        or (32|M0)               r22.0<1>:d    r89.0<1;1,0>:d    r4.0<1;1,0>:d    {Compacted,I@7}    //  ALU pipe: int; $212
        shl (32|M0)              r30.0<1>:d    r12.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $195
        cmp (32|M0)   (gt)f3.0   r32.0<1>:ud   r14.0<1;1,0>:ud   0x7F80:uw              {I@7}        //  ALU pipe: int; $204
        mul (32|M0)              acc0.0<1>:f   r10.0<1;1,0>:f    r6.0<1;1,0>:f    {Compacted,I@7}    //  ALU pipe: float; $184
        mov (32|M0)              r28.0<1>:ud   r35.0<4;1,0>:ub                                       //  ALU pipe: int; $231
        sync.nop                             null                             {Compacted,$10.src}    // $206
        mov (32|M0)              r41.0<1>:d    r37.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $206
        bfn.((s0|s1)&s2) (32|M0)   r49.0<1>:ud  r89.0<1;0>:ud    r4.0<1;0>:ud      r93.11<0>:ud      //  ALU pipe: int; $214
        bfn.(s0&s1|~s0&s2) (32|M0)   r39.0<1>:ud  r8.0<1;0>:ud   r17.0<1;0>:ud     r84.0<1>:ud      {I@7} //  ALU pipe: int; $193
        or (32|M0)               r55.0<1>:d    r20.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $203
        shl (32|M0)              r58.0<1>:d    r22.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $213
        add (32|M0)              acc0.0<1>:f   r98.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $185
        shl (32|M0)              r63.0<1>:d    r35.3<4;1,0>:ub   8:w                                 //  ALU pipe: int; $246
        or (32|M0)               r60.0<1>:d    r25.0<1;1,0>:d    r28.0<1;1,0>:d   {Compacted,I@7}    //  ALU pipe: int; $232
        shl (32|M0)              r68.0<1>:d    r41.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $207
        cmp (32|M0)   (gt)f2.0   r70.0<1>:ud   r49.0<1;1,0>:ud   0x7F80:uw              {I@7}        //  ALU pipe: int; $216
        mul (32|M0)              acc2.0<1>:f   r39.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $196
        mov (32|M0)              r66.0<1>:ud   r35.2<4;1,0>:ub                                       //  ALU pipe: int; $247
        mov (32|M0)              r74.0<1>:d    r37.1<2;1,0>:uw                                       //  ALU pipe: int; $218
        bfn.((s0|s1)&s2) (32|M0)   r76.0<1>:ud  r25.0<1;0>:ud    r28.0<1;0>:ud     r93.11<0>:ud      //  ALU pipe: int; $234
        bfn.(s0&s1|~s0&s2) (32|M0)   r72.0<1>:ud  r32.0<1;0>:ud  r55.0<1;0>:ud     r20.0<1>:ud      {I@7} //  ALU pipe: int; $205
        or (32|M0)               r79.0<1>:d    r58.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $215
        shl (32|M0)              r82.0<1>:d    r60.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $233
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $197
        shl (32|M0)              r87.0<1>:d    r43.1<4;1,0>:ub   8:w               {$8.dst}          //  ALU pipe: int; $258
        or (32|M0)               r84.0<1>:d    r63.0<1;1,0>:d    r66.0<1;1,0>:d   {Compacted,I@7}    //  ALU pipe: int; $248
        shl (32|M0)              r3.0<1>:d     r74.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $219
        cmp (32|M0)   (gt)f3.0   r5.0<1>:ud    r76.0<1;1,0>:ud   0x7F80:uw              {A@4}        //  ALU pipe: int; $236
        mul (32|M0)              acc2.0<1>:f   r72.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $208
        mov (32|M0)              r90.0<1>:ud   r43.0<4;1,0>:ub                                       //  ALU pipe: int; $259
        mov (32|M0)              r9.0<1>:d     r45.0<2;1,0>:uw                  {$9.dst}             //  ALU pipe: int; $242
        bfn.((s0|s1)&s2) (32|M0)   r11.0<1>:ud  r63.0<1;0>:ud    r66.0<1;0>:ud     r93.11<0>:ud      //  ALU pipe: int; $250
        bfn.(s0&s1|~s0&s2) (32|M0)   r7.0<1>:ud  r70.0<1;0>:ud   r79.0<1;0>:ud     r58.0<1>:ud      {I@7} //  ALU pipe: int; $217
        or (32|M0)               r13.0<1>:d    r82.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $235
        shl (32|M0)              r16.0<1>:d    r84.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $249
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $209
        shl (32|M0)              r21.0<1>:d    r43.3<4;1,0>:ub   8:w                                 //  ALU pipe: int; $270
        or (32|M0)               r18.0<1>:d    r87.0<1;1,0>:d    r90.0<1;1,0>:d   {Compacted,I@7}    //  ALU pipe: int; $260
        shl (32|M0)              r26.0<1>:d    r9.0<1;1,0>:d     16:w               {Compacted,I@7}  //  ALU pipe: int; $243
        cmp (32|M0)   (gt)f2.0   r28.0<1>:ud   r11.0<1;1,0>:ud   0x7F80:uw              {I@7}        //  ALU pipe: int; $252
        mul (32|M0)              acc2.0<1>:f   r7.0<1;1,0>:f     r3.0<1;1,0>:f    {Compacted,I@7}    //  ALU pipe: float; $220
        mov (32|M0)              r24.0<1>:ud   r43.2<4;1,0>:ub                                       //  ALU pipe: int; $271
        mov (32|M0)              r32.0<1>:d    r45.1<2;1,0>:uw                                       //  ALU pipe: int; $254
        bfn.((s0|s1)&s2) (32|M0)   r34.0<1>:ud  r87.0<1;0>:ud    r90.0<1;0>:ud     r93.11<0>:ud      //  ALU pipe: int; $262
        bfn.(s0&s1|~s0&s2) (32|M0)   r30.0<1>:ud  r5.0<1;0>:ud   r13.0<1;0>:ud     r82.0<1>:ud      {A@5} //  ALU pipe: int; $237
        or (32|M0)               r37.0<1>:d    r16.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $251
        shl (32|M0)              r40.0<1>:d    r18.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $261
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $221
        or (32|M0)               r42.0<1>:d    r21.0<1;1,0>:d    r24.0<1;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $272
        shl (32|M0)              r44.0<1>:d    r32.0<1;1,0>:d    16:w               {Compacted,I@6}  //  ALU pipe: int; $255
        cmp (32|M0)   (gt)f3.0   r49.0<1>:ud   r34.0<1;1,0>:ud   0x7F80:uw              {I@6}        //  ALU pipe: int; $264
        mul (32|M0)              acc2.0<1>:f   r30.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,I@6}    //  ALU pipe: float; $244
        mov (32|M0)              r53.0<1>:d    r47.0<2;1,0>:uw                  {$10.dst}            //  ALU pipe: int; $266
        bfn.((s0|s1)&s2) (32|M0)   r55.0<1>:ud  r21.0<1;0>:ud    r24.0<1;0>:ud     r93.11<0>:ud      //  ALU pipe: int; $274
        bfn.(s0&s1|~s0&s2) (32|M0)   r51.0<1>:ud  r28.0<1;0>:ud  r37.0<1;0>:ud     r16.0<1>:ud      {I@7} //  ALU pipe: int; $253
        or (32|M0)               r57.0<1>:d    r40.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $263
        shl (32|M0)              r60.0<1>:d    r42.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $273
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $245
        shl (32|M0)              r62.0<1>:d    r53.0<1;1,0>:d    16:w               {Compacted,I@5}  //  ALU pipe: int; $267
        cmp (32|M0)   (gt)f2.0   r64.0<1>:ud   r55.0<1;1,0>:ud   0x7F80:uw              {I@5}        //  ALU pipe: int; $276
        mul (32|M0)              acc2.0<1>:f   r51.0<1;1,0>:f    r44.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $256
        mov (32|M0)              r68.0<1>:d    r47.1<2;1,0>:uw                  {F@7}                //  ALU pipe: int; $278
        bfn.(s0&s1|~s0&s2) (32|M0)   r66.0<1>:ud  r49.0<1;0>:ud  r57.0<1;0>:ud     r40.0<1>:ud      {I@5} //  ALU pipe: int; $265
        or (32|M0)               r71.0<1>:d    r60.0<1;1,0>:d    4194304:d               {I@5}       //  ALU pipe: int; $275
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $257
        shl (32|M0)              r73.0<1>:d    r68.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $279
        mul (32|M0)              acc2.0<1>:f   r66.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $268
        bfn.(s0&s1|~s0&s2) (32|M0)   r75.0<1>:ud  r64.0<1;0>:ud  r71.0<1;0>:ud     r60.0<1>:ud      {I@2} //  ALU pipe: int; $277
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $269
        mul (32|M0)              acc2.0<1>:f   r75.0<1;1,0>:f    r73.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $280
        add (32|M0)              r98.0<1>:f    acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $281
(f1.0)  goto (32|M0)                         _0_040            _0_040                                //  ALU pipe: int; $283
// B015: [inDivergent],  Preds:{B014},  Succs:{B017}
_0_041:
(W)     mov (1|M0)               r93.8<1>:d    -1:w                                                  //  ALU pipe: int; $285
(W)     mov (1|M0)               r93.18<1>:hf  0x1:hf                                                //  ALU pipe: float; $286
        goto (32|M0)                         _0_040            _0_031                                // $287
// B016: [inDivergent],  Preds:{B014},  Succs:{B014}
_0_040:
        join (32|M0)                         _0_031                                                  // 
L3608:
        add (32|M0)              r100.0<1>:d   r100.0<1;1,0>:d   256:w               {Compacted}     //  ALU pipe: int; $289
(W)     jmpi                                 _0_039                                                  // $290
// B017: Preds:{B015, B012, B010, B005},  Succs:{B018, B022}
_0_031:
        join (32|M0)                         L3648                                                   // 
L3648:
        add (32|M0)              r3.0<1>:d     r96.0<1;1,0>:d    1:w               {Compacted,F@7}   //  ALU pipe: int; $292
        and (32|M0)              r5.0<1>:d     r3.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $293
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $294
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $295
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0x1880:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0127(r98.0:f); $296
        add (32|M0)              r10.0<1>:d    r96.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $305
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@2}                //  ALU pipe: int; $297
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $298
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0x1880:uw                           //  ALU pipe: int; src1 is addr of V0127(r98.0:f); $299
        and (32|M0)   (eq)f1.0   null<1>:d     r96.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $301
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $306
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $300
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $307
(f1.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $303
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $308
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0x1980:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0378(r102.0:f); $309
        add (32|M0)              r102.0<1>:f   r98.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $304
        add (32|M0)              r17.0<1>:d    r96.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $318
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $310
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $311
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0x1980:uw                           //  ALU pipe: int; src1 is addr of V0378(r102.0:f); $312
        and (32|M0)   (eq)f3.0   null<1>:d     r96.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $314
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $319
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $313
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $320
(f3.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $316
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $321
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0x1A00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0386(r104.0:f); $322
        add (32|M0)              r104.0<1>:f   r102.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $317
        add (32|M0)              r24.0<1>:d    r96.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $331
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $323
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $324
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0x1A00:uw                           //  ALU pipe: int; src1 is addr of V0386(r104.0:f); $325
        and (32|M0)   (eq)f2.0   null<1>:d     r96.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $327
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $332
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $326
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $333
(f2.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $329
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $334
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0x1A80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0394(r106.0:f); $335
        add (32|M0)              r106.0<1>:f   r104.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $330
        add (32|M0)              r31.0<1>:d    r96.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $344
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $336
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $337
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0x1A80:uw                           //  ALU pipe: int; src1 is addr of V0394(r106.0:f); $338
        and (32|M0)   (eq)f1.0   null<1>:d     r96.0<1;1,0>:d    15:w                                //  ALU pipe: int; $340
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $345
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $339
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $346
        cmp (32|M0)   (eq)f3.0   null<2>:w     r94.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $353
(f1.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $342
(W)     mov (1|M0)               r36.0<1>:hf   0x1:hf                                                //  ALU pipe: float; $354
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $347
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0x1B00:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0402(r108.0:f); $348
        add (32|M0)              r108.0<1>:f   r106.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $343
(f0.0)  sel (32|M0)              r37.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw              {F@2}           //  ALU pipe: int; $354
(f3.0)  sel (32|M0)              r38.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw                              //  ALU pipe: int; $354
        mov (16|M0)              r110.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $349
        and (32|M0)   (ne)f3.0   null<2>:uw    r37.0<1;1,0>:uw   r38.0<1;1,0>:uw  {I@2}              //  ALU pipe: int; $354
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $350
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0x1B00:uw                           //  ALU pipe: int; src1 is addr of V0402(r108.0:f); $351
        mov (16|M16)             r111.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $352
(~f3.0) goto (32|M0)                         _0_042            _0_042                                //  ALU pipe: int; $355
// B018: [inDivergent],  Preds:{B017},  Succs:{B019, B020}
_0_043:
        cmp (32|M0)   (eq)f2.0   null<2>:w     r94.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $357
(f2.0)  sel (32|M0)              acc0.0<1>:f   r110.0<1;1,0>:f   0x80000000:f               {I@3}    //  ALU pipe: float; $358
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r93.8<0;1,0>:d    0:w                                 //  ALU pipe: int; $360
        add (32|M0)              r3.0<1>:f     r108.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $359
(f1.0)  sel (32|M0)              r113.0<1>:d   r3.0<1;1,0>:d     2143289344:d               {F@1}    //  ALU pipe: int; $361
        and (32|M0)              r5.0<1>:d     r113.0<1;1,0>:d   2147483647:d               {I@1}    //  ALU pipe: int; $362
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r5.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $363
(f3.0)  goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $364
// B019: [inDivergent],  Preds:{B018},  Succs:{B021}
_0_045:
        shr (32|M0)              r3.0<1>:ud    r113.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $366
        and (32|M0)              r6.0<1>:d     r3.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $367
        add3 (32|M0)             r8.0<1>:d     r113.0<1;0>:d     r6.0<1;0>:d       32767:w               {I@1} //  ALU pipe: int; $368
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $369
        mov (32|M0)              r112.0<1>:w   r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $370
        goto (32|M0)                         _0_044            _0_046                                // $371
// B020: [inDivergent],  Preds:{B018},  Succs:{B021}
_0_044:
        join (32|M0)                         _0_046                                                  // 
L4768:
        shr (32|M0)              r3.0<1>:ud    r113.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $373
        or (32|M0)               r112.0<1>:w   r3.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $375
// B021: [inDivergent],  Preds:{B020, B019},  Succs:{B022}
_0_046:
        join (32|M0)                         _0_042                                                  // 
L4816:
(W)     mov (1|M0)               f1.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $380
        cmp (32|M0)   (eq)f1.0   null<2>:uw    r93.19<0;1,0>:uw  r93.19<0;1,0>:uw                    //  ALU pipe: int; $381
(W)     fbl (1|M0)               r3.0<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $383
(W)     shl (1|M0)               r1.1<1>:q     r93.1<0;1,0>:q    1:w                                 //  ALU pipe: int; $377
(W)     shl (1|M0)               r3.0<1>:ud    r3.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $384
(W)     add (1|M0)               r2.0<1>:q     r1.1<0;1,0>:q     r1.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $378
(W)     add (1|M0)               a0.0<1>:uw    r3.0<0;1,0>:uw    0x1C00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0422(r112.0:w); $385
(W)     mov (1|M0)               r4.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $387
(W)     store.ugm.d16u32.a64 (1|M0)  [r2:2]     r4:1               {I@1,$11} // ex_desc:0x0; desc:0x4000B84 // $388
// B022: Preds:{B021, B017},  Succs:{B023, B024}
_0_042:
        join (32|M0)                         L4960                                                   // 
L4960:
(W)     cmp (32|M0)   (ne)f2.0   null<1>:d     r93.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $393
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r93.4<0;1,0>:d    r95.0<0;1,0>:d                      //  ALU pipe: int; $390
(W&~f2.0) cmp (32|M0) (ne)f2.0   null<1>:d     r93.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $394
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r93.5<0;1,0>:d    r93.7<0;1,0>:d                      //  ALU pipe: int; $391
(W)     mov (1|M0)               r1.2<1>:ud    f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $396
(W)     mov (1|M0)               r2.0<1>:hf    0x1:hf                              {$11.src}         //  ALU pipe: float; $399
(W)     and (1|M0)               f2.0<1>:ud    f3.0<0;1,0>:ud    r1.2<0;1,0>:ud   {I@1}              //  ALU pipe: int; $396
(f0.0)  sel (32|M0)              r4.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $399
(f2.0)  cmp (32|M0)   (eq)f2.0   null<2>:w     r94.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $397
(f2.0)  sel (32|M0)              r3.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $399
        and (32|M0)   (ne)f2.0   null<2>:uw    r3.0<1;1,0>:uw    r4.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $399
(~f2.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $400
// B023: [inDivergent],  Preds:{B022},  Succs:{B024}
_0_048:
(W)     mov (1|M0)               r1.8<2>:b     r93.18<0;1,0>:w                                       //  ALU pipe: int; $402
(W)     mov (1|M0)               r3.0<1>:hf    0xFFFF:hf                              {I@3}          //  ALU pipe: float; $405
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $403
(W)     shl (1|M0)               r7.0<1>:q     r93.6<0;1,0>:ud   2:w                                 //  ALU pipe: int; $408
(W)     cmp (32|M0)   (eq)f2.0   null<2>:w     r2.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $404
(W&f2.0) sel (1|M0)              r4.0<1>:d     r3.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $405
(W)     add (1|M0)               r8.0<1>:q     r7.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $409
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $406
(W)     store.ugm.d32x1t.a64 (1|M0)  [r8:1]     r6:1               {I@1,$12} // ex_desc:0x0; desc:0x2008584 // $411
// B024: Preds:{B023, B022},  Succs:{}
_0_047:
        join (32|M0)                         L5288                                                   // 
L5288:
(W)     mov (16|M0)              r127.0<1>:f   r92.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $413
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$13} // wr:1+0, rd:0; end of thread // $413
L5312:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x3C:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 2
//


//.numALUInst: 348
//.accSubDef: 20
//.accSubUse: 20
//.accSubCandidateDef: 20
//.accSubCandidateUse: 20
//
//
//.singlePipeAtOneDistNum: 48
//.allAtOneDistNum: 10
//.syncInstCount: 2
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 11
//.AfterReadTokenDepCount: 4
