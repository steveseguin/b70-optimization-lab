//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE0ELj6144ELj4ELj1ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 38 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 38 -GRFBumpUpNumber 2 "
//.instCount 283
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r39.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r39.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r39.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.1)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.13)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r40.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.2)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r41.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=16 words (r39.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r1.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0067 (77)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r1.8)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r40.1)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0070 (80)  rf=r size=8 type=uq alias=V0068+0 align=4 words (r40.1)
//.declare V0071 (81)  rf=r size=8 type=uq alias=V0069+0 align=4 words (r4.0)
//.declare V0072 (82)  rf=r size=8 type=d align=2 words (r40.4)
//.declare V0073 (83)  rf=r size=8 type=d alias=V0069+0 align=4 words (r4.0)
//.declare V0075 (85)  rf=r size=4 type=d align=2 words (r40.6)
//.declare V0076 (86)  rf=r size=4 type=d align=4 words (r40.8)
//.declare P01 (87)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0077 (88)  rf=r size=4 type=d align=2 words (r40.7)
//.declare V0078 (89)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0079 (90)  rf=r size=4 type=ud alias=V0050+0 align=2 words (r2.12)
//.declare V0080 (91)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0081 (92)  rf=r size=4 type=ud alias=V0080+0 align=2 words (r3.0)
//.declare V0082 (93)  rf=r size=4 type=d alias=+0 align=2 words (r4.0)
//.declare V0083 (94)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0084 (95)  rf=r size=4 type=ud alias=V0076+0 align=2 words (r40.8)
//.declare V0085 (96)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0086 (97)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0087 (98)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0088 (99)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0089 (100)  rf=r size=4 type=ud alias=V0088+0 align=2 words (r10.0)
//.declare V0090 (101)  rf=r size=4 type=d alias=+4 align=2 words (r4.1)
//.declare V0091 (102)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0092 (103)  rf=r size=4 type=ud alias=V0091+0 align=2 words (r11.0)
//.declare V0093 (104)  rf=r size=4 type=f alias=+0 align=2 words (r12.0)
//.declare V0094 (105)  rf=r size=4 type=ud alias=V0082+0 align=2 words (r4.0)
//.declare V0095 (106)  rf=r size=4 type=f alias=+4 align=2 words (r12.1)
//.declare V0096 (107)  rf=r size=4 type=ud alias=V0090+0 align=2 words (r4.1)
//.declare V0097 (108)  rf=r size=4 type=f align=2 words (r13.0)
//.declare V0099 (110)  rf=r size=4 type=f align=2 words (r14.0)
//.declare V0101 (112)  rf=r size=4 type=f align=2 words (r15.0)
//.declare V0102 (113)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0103 (114)  rf=r size=4 type=f align=2 words (r17.0)
//.declare V0104 (115)  rf=r size=4 type=d align=2 words (r18.0)
//.declare V0105 (116)  rf=r size=4 type=ud alias=V0104+0 align=2 words (r18.0)
//.declare V0106 (117)  rf=r size=4 type=d align=2 words (r19.0)
//.declare V0107 (118)  rf=r size=4 type=d align=32 words (r20.0)
//.declare V0108 (119)  rf=r size=4 type=d align=2 words (r21.0)
//.declare V0109 (120)  rf=r size=4 type=d align=2 words (r22.0)
//.declare V0110 (121)  rf=r size=4 type=ud alias=V0108+0 align=2 words (r21.0)
//.declare V0111 (122)  rf=r size=4 type=ud alias=V0109+0 align=2 words (r22.0)
//.declare  (123)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0112 (124)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0113 (125)  rf=r size=4 type=d align=2 words (r40.9)
//.declare V0114 (126)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0116 (128)  rf=r size=4 type=ud alias=V0114+0 align=2 words (r3.0)
//.declare V0117 (129)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r2.13)
//.declare V0118 (130)  rf=r size=4 type=d align=32 words (r4.0)
//.declare P02 (133)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0121 (134)  rf=r size=8 type=ud alias=V0072+0 align=2 words (r40.4)
//.declare P03 (135)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P04 (136)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0123 (138)  rf=r size=128 type=d align=32 words (r43.0)
//.declare V0124 (139)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r41.0)
//.declare P05 (140)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P06 (141)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P07 (142)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0125 (143)  rf=r size=4 type=d align=2 words (r40.10)
//.declare V0126 (144)  rf=r size=2 type=w align=1 words (r40.22)
//.declare V0127 (145)  rf=r size=128 type=f align=32 words (r45.0)
//.declare P08 (146)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P09 (147)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0128 (148)  rf=r size=4 type=d alias=+0 align=2 words (r42.8)
//.declare V0129 (149)  rf=r size=4 type=d alias=+4 align=2 words (r42.9)
//.declare V0130 (150)  rf=r size=4 type=d align=2 words (r40.12)
//.declare V0131 (151)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0132 (152)  rf=r size=4 type=ud alias=V0077+0 align=2 words (r40.7)
//.declare V0133 (153)  rf=r size=8 type=ud alias=V0131+0 align=4 words (r1.2)
//.declare V0134 (154)  rf=r size=8 type=d alias=V0131+0 align=4 words (r1.2)
//.declare V0135 (155)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0139 (159)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0140 (160)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P10 (161)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0141 (162)  rf=r size=4 type=ud alias=V0129+0 align=2 words (r42.9)
//.declare P11 (163)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0142 (164)  rf=r size=4 type=ud alias=V0128+0 align=2 words (r42.8)
//.declare V0143 (165)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r2.14)
//.declare V0144 (166)  rf=r size=4 type=d align=2 words (r1.2)
//.declare P12 (167)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0145 (168)  rf=r size=4 type=ud alias=V0130+0 align=2 words (r40.12)
//.declare P13 (169)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0146 (170)  rf=r size=4 type=ud alias=V0144+0 align=2 words (r1.2)
//.declare P14 (171)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0147 (172)  rf=r size=4 type=ud alias=V0113+0 align=2 words (r40.9)
//.declare P15 (173)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0148 (174)  rf=r size=8 type=d align=2 words (r1.2)
//.declare V0149 (175)  rf=r size=8 type=d alias=V0049+0 align=4 words (r2.10)
//.declare V0150 (176)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0151 (177)  rf=r size=8 type=ud alias=V0150+0 align=4 words (r3.0)
//.declare V0152 (178)  rf=r size=8 type=d alias=V0150+0 align=4 words (r3.0)
//.declare V0153 (179)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0156 (182)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0158 (184)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0159 (185)  rf=r size=8 type=d align=2 words (r7.0)
//.declare V0160 (186)  rf=r size=8 type=d alias=V0158+0 align=4 words (r6.0)
//.declare V0161 (187)  rf=r size=4 type=d align=32 words (r42.0)
//.declare V0162 (188)  rf=r size=4 type=d align=2 words (r40.13)
//.declare V0163 (189)  rf=r size=4 type=ud alias=V0161+0 align=2 words (r42.0)
//.declare V0164 (190)  rf=r size=8 type=ud alias=V0159+0 align=2 words (r7.0)
//.declare V0165 (191)  rf=r size=8 type=ud alias=V0148+0 align=2 words (r1.2)
//.declare V0166 (192)  rf=r size=4 type=d align=32 words (r8.0)
//.declare V0168 (194)  rf=r size=4 type=d align=32 words (r9.0)
//.declare V0169 (195)  rf=r size=4 type=d align=2 words (r40.14)
//.declare V0170 (196)  rf=r size=4 type=d align=2 words (r40.15)
//.declare V0171 (197)  rf=r size=4 type=ud alias=V0169+0 align=2 words (r40.14)
//.declare V0172 (198)  rf=r size=4 type=d align=32 words (r10.0)
//.declare V0175 (201)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0176 (202)  rf=r size=4 type=d align=2 words (r42.1)
//.declare V0177 (203)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0178 (204)  rf=r size=128 type=d align=32 words (r47.0)
//.declare P16 (205)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0179 (206)  rf=r size=128 type=ud alias=V0178+0 align=32 words (r47.0)
//.declare V0180 (207)  rf=r size=4 type=ud alias=V0176+0 align=2 words (r42.1)
//.declare V0182 (209)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0183 (210)  rf=r size=8 type=d alias=V0182+0 align=4 words (r1.2)
//.declare V0184 (211)  rf=r size=8 type=q align=4 words (r42.1)
//.declare V0186 (213)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0187 (214)  rf=r size=8 type=d alias=V0186+0 align=4 words (r2.0)
//.declare V0188 (215)  rf=r size=8 type=q align=4 words (r42.2)
//.declare V0189 (216)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0190 (217)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0191 (218)  rf=r size=128 type=ud alias=V0189+0 align=32 words (r3.0)
//.declare V0192 (219)  rf=r size=128 type=ud alias=V0190+0 align=32 words (r49.0)
//.declare P17 (220)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0193 (221)  rf=r size=128 type=d align=32 words (r51.0)
//.declare V0194 (222)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0196 (224)  rf=r size=128 type=ud alias=V0194+0 align=32 words (r5.0)
//.declare V0199 (227)  rf=r size=256 type=uq align=32 words (r19.0)
//.declare V0200 (228)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0201 (229)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0203 (231)  rf=r size=128 type=ud alias=V0201+0 align=32 words (r3.0)
//.declare V0206 (234)  rf=r size=256 type=uq align=32 words (r15.0)
//.declare V0208 (236)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0209 (237)  rf=r size=128 type=w alias=V0208+0 align=32 words (r24.0)
//.declare V0211 (239)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0213 (241)  rf=r size=128 type=f alias=V0211+0 align=32 words (r28.0)
//.declare V0214 (242)  rf=r size=128 type=d align=32 words (r53.0)
//.declare P18 (243)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0215 (244)  rf=r size=128 type=ud alias=V0214+0 align=32 words (r53.0)
//.declare P19 (245)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0216 (246)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0217 (247)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0218 (248)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0219 (249)  rf=r size=128 type=uw alias=V0217+0 align=32 words (r5.0)
//.declare V0220 (250)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (251)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P20 (252)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0223 (255)  rf=r size=128 type=f align=32 words (r55.0)
//.declare V0224 (256)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0225 (257)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0226 (258)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0227 (259)  rf=r size=128 type=uw alias=V0225+0 align=32 words (r12.0)
//.declare V0228 (260)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (261)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P21 (262)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0231 (265)  rf=r size=128 type=f align=32 words (r57.0)
//.declare V0232 (266)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0233 (267)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0234 (268)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0235 (269)  rf=r size=128 type=uw alias=V0233+0 align=32 words (r19.0)
//.declare V0236 (270)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (271)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P22 (272)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0239 (275)  rf=r size=128 type=f align=32 words (r59.0)
//.declare V0240 (276)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0241 (277)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0242 (278)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0243 (279)  rf=r size=128 type=uw alias=V0241+0 align=32 words (r26.0)
//.declare V0244 (280)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (281)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P23 (282)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0247 (285)  rf=r size=128 type=f align=32 words (r61.0)
//.declare V0248 (286)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0249 (287)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0250 (288)  rf=r size=128 type=f align=32 words (r63.0)
//.declare V0251 (289)  rf=r size=128 type=uw alias=V0249+0 align=32 words (r33.0)
//.declare V0252 (290)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (291)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P24 (292)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P25 (293)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P26 (294)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P27 (297)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0255 (298)  rf=r size=128 type=f align=32 words (r3.0)
//.declare V0256 (299)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0257 (300)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0258 (301)  rf=r size=8 type=d alias=V0257+0 align=4 words (r6.0)
//.declare V0259 (302)  rf=r size=8 type=d alias=V0256+0 align=4 words (r5.0)
//.declare V0260 (303)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0263 (306)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0264 (307)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0265 (308)  rf=r size=256 type=ud alias=V0264+0 align=32 words (r9.0)
//.declare V0266 (309)  rf=r size=8 type=ud alias=V0263+0 align=32 words (r8.0)
//.declare P28 (310)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P29 (311)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P30 (312)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0267 (313)  rf=r size=128 type=d align=32 words (r3.0)
//.declare P31 (314)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0268 (315)  rf=r size=2 type=b align=1 words (r1.8)
//.declare V0269 (316)  rf=r size=2 type=w align=1 words (r2.0)
//.declare V0270 (317)  rf=r size=2 type=ub alias=V0268+0 align=1 words (r1.8)
//.declare P32 (318)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0271 (319)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0272 (320)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0274 (322)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0277 (325)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare  (326)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (327)  rf=r size=4 type=d alias=V0068+0 align=2 words (r40.2)
//.declare  (328)  rf=r size=8 type=f align=8 words (r12.0)
//.declare  (329)  rf=r size=8 type=ud align=8 words (r4.0)
//.declare  (330)  rf=r size=8 type=d align=8 words (r42.8)
//.declare  (331)  rf=r size=64 type=uw align=32 words (r37.0)
//.declare  (332)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (333)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (334)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare  (335)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (336)  rf=r size=4 type=f align=2 words (r7.0)
//.declare  (337)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare  (338)  rf=r size=2 type=w align=1 words (r1.4)
//.declare  (339)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare  (340)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (341)  rf=r size=128 type=ud align=32 words (r13.0)
//.declare  (342)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (343)  rf=r size=128 type=ud align=32 words (r9.0)
//.declare  (344)  rf=r size=2 type=uw align=1 words (r36.0)
//.declare  (346)  rf=r size=2 type=uw align=1 words (r5.0)
//.declare  (348)  rf=r size=2 type=w align=1 words (r3.0)
//.declare r0 (357)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (358)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (359)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (360)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :q       |    0x8 | r1       | inline+0x0       |
// | V0041    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0042    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r2       | cti+0x20         |
// | V0045    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0050    | :d       |    0x4 | r2+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r2+0x34  | cti+0x54         |
// | V0052    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0054    | :b       |    0x1 | r3       | cti+0x60         |
// | V0055    | :b       |    0x1 | r3+0x4   | cti+0x64         |
// | V0037    | :uq      |    0x8 | r3+0x8   | cti+0x68         |
// | V0038    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r39.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r1.8<2>:b     r39.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     mov (8|M0)               r41.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {@2,$0.dst}          //  ALU pipe: int; $9
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $16
(W)     mov (1|M0)               r3.0<1>:q     r2.0<0;1,0>:w                    {@2,$1.dst}          //  ALU pipe: int; $9
(W)     add (8|M0)               r41.8<1>:w    r41.0<1;1,0>:w    8:w                                 //  ALU pipe: int; $5
(W)     add (1|M0)               r40.1<1>:q    r39.1<0;1,0>:ud   r3.0<0;1,0>:q    {I@2}              //  ALU pipe: int; $10
(W)     add (16|M0)              r41.16<1>:w   r41.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $6
(W)     shr (1|M0)               r4.0<1>:uq    r40.1<0;1,0>:uq   2:w               {I@2}             //  ALU pipe: int; $11
(W)     mov (2|M0)               r40.0<1>:d    r2.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     and (1|M0)               r40.6<1>:d    r40.2<0;1,0>:d    3:w                                 //  ALU pipe: int; $14
(W)     mov (2|M0)               r40.4<1>:d    r4.0<1;1,0>:d                    {Compacted,I@3}      //  ALU pipe: int; $12
(W)     mov (1|M0)               r40.8<2>:d    r4.0<0;1,0>:q                                         //  ALU pipe: int; $15
(W&~f3.0) jmpi                               _0_031                                                  //  ALU pipe: int; $17
// B002: Preds:{B001},  Succs:{B004}
_0_032:
(W)     mov (1|M0)               r40.7<1>:d    -1:w                                                  //  ALU pipe: int; $19
(W)     jmpi                                 _0_033                                                  // $20
// B003: Preds:{B001},  Succs:{B004}
_0_031:
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $22
(W)     mov (1|M0)               r2.0<1>:f     r2.12<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $23
(W)     mov (1|M0)               r7.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $28
(W)     math.inv (1|M0)          r6.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $27
(W)     mov (1|M0)               r5.0<1>:f     r40.8<0;1,0>:ud                  {I@5}                //  ALU pipe: float; $26
(W)     mad (1|M0)               r8.0<1>:f     r6.0<0;0>:f       r7.0<0;0>:f       r6.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $28
(W)     mov (1|M0)               r3.0<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $24
(W)     mov (1|M0)               r10.0<1>:ud   r5.0<0;1,0>:f                    {F@2}                //  ALU pipe: int; $30
(W)     mul (1|M0)               r9.0<1>:f     r5.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $29
(W)     add (1|M0)               r4.0<1>:d     r2.12<0;1,0>:d    -r3.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $25
(W)     add (1|M0)               r4.1<1>:d     r40.8<0;1,0>:d    -r10.0<0;1,0>:d  {I@2}              //  ALU pipe: int; $31
(W)     mov (1|M0)               r11.0<1>:ud   r9.0<0;1,0>:f                    {F@1}                //  ALU pipe: int; $32
(W)     mov (1|M0)               r12.0<1>:f    r4.0<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $33
(W)     mov (1|M0)               r12.1<1>:f    r4.1<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $33
(W)     mov (1|M0)               r13.0<1>:f    r11.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $35
(W)     mad (1|M0)               r14.0<1>:f    r5.0<0;0>:f       r13.0<0;0>:f      -r2.0<0>:f       {F@1} //  ALU pipe: float; $37
(W)     mad (1|M0)               r15.0<1>:f    r12.1<0;0>:f      r13.0<0;0>:f      -r12.0<0>:f       //  ALU pipe: float; $39
(W)     add (1|M0)               r16.0<1>:f    r14.0<0;1,0>:f    r15.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $40
(W)     mul (1|M0)               r17.0<1>:f    r8.0<0;1,0>:f     r16.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $41
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $42
(W)     mov (1|M0)               r18.0<1>:ud   r17.0<0;1,0>:f                   {A@1}                //  ALU pipe: int; $43
(W)     add (1|M0)               r19.0<1>:d    r18.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $44
(W)     mul (1|M0)               acc0.0<1>:d   r19.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $45
(W)     macl (1|M0)              r20.0<1>:d    r19.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $46
(W)     add (1|M0)               r21.0<1>:d    r40.8<0;1,0>:d    -r20.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $46
(W)     cmp (1|M0)    (ge)f2.0   r22.0<1>:ud   r21.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@1}              //  ALU pipe: int; $47
(W)     add3 (1|M0)              r40.7<1>:d    r18.0<0;0>:d      r11.0<0;0>:d      -r22.0<0>:d      {I@1} //  ALU pipe: int; $48
// B004: Preds:{B003, B002},  Succs:{B005, B006}
_0_033:
(W)     mul (1|M0)               acc0.0<1>:d   r40.7<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $50
(W)     macl (1|M0)              r2.0<1>:d     r40.7<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $51
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $52
(W)     macl (1|M0)              r3.0<1>:ud    r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; $53
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $53
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r40.4<0;1,0>:ud   r3.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $65
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r40.4<0;1,0>:ud   r3.0<0;1,0>:ud                      //  ALU pipe: int; $59
(W)     mach (1|M0)              r4.0<1>:d     r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; 
        mov (32|M0)              r43.0<1>:d    r41.0<1;1,0>:uw                                       //  ALU pipe: int; $64
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r40.5<0;1,0>:d    r4.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $66
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r40.5<0;1,0>:d    r4.0<0;1,0>:d                       //  ALU pipe: int; $60
(W&~f2.0) cmp (32|M0) (lt)f2.0   null<1>:ud    r40.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $68
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r40.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $62
(W)     add (1|M0)               r40.9<1>:d    r40.8<0;1,0>:d    -r2.0<0;1,0>:d                      //  ALU pipe: int; $51
(W&f2.0) jmpi                                _0_034                                                  //  ALU pipe: int; $70
// B005: Preds:{B004},  Succs:{B022}
_0_035:
        mov (32|M0)              r45.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $74
(W)     mov (1|M0)               r40.10<1>:d   0:w                                                   //  ALU pipe: int; $72
(W)     mov (1|M0)               r40.22<1>:w   0:w                                                   //  ALU pipe: int; $73
(W)     jmpi                                 _0_036                                                  // $75
// B006: Preds:{B004},  Succs:{B007, B008}
_0_034:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r40.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $77
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r40.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $78
(W&~f2.0) jmpi                               _0_037                                                  //  ALU pipe: int; $80
// B007: Preds:{B006},  Succs:{B009}
_0_038:
(W)     mov (2|M0)               r42.8<1>:d    0:w                                                   //  ALU pipe: int; $82
(W)     mov (1|M0)               r40.12<1>:f   r2.12<0;1,0>:f                                        //  ALU pipe: float; $84
(W)     jmpi                                 _0_039                                                  // $85
// B008: Preds:{B006},  Succs:{B009}
_0_037:
(W)     mul (1|M0)               acc0.0<1>:ud  r40.7<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $88
(W)     mach (1|M0)              r2.0<1>:d     r40.7<0;1,0>:ud   0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.2<2>:ud    r40.7<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $87
(W)     mov (1|M0)               r1.3<2>:d     r2.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $92
(W)     add (1|M0)               r4.0<1>:q     r1.1<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $93
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $95
(W)     mov (1|M0)               r42.8<1>:d    r5.0<0;1,0>:d                    {$2.dst}             //  ALU pipe: int; $96
(W)     mov (1|M0)               r42.9<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $97
(W)     mov (1|M0)               r40.12<1>:d   r5.2<0;1,0>:d                    {F@1}                //  ALU pipe: int; $98
// B009: Preds:{B008, B007},  Succs:{B010, B011}
_0_039:
(W)     cmp (32|M0)   (gt)f1.0   null<1>:ud    r42.9<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $100
(W&~f1.0) cmp (32|M0) (ge)f1.0   null<1>:ud    r42.8<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; $101
(W&~f1.0) jmpi                               _0_040                                                  //  ALU pipe: int; $103
// B010: Preds:{B009},  Succs:{B022}
_0_041:
        mov (32|M0)              r45.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $107
(W)     mov (1|M0)               r40.10<1>:d   0:w                                                   //  ALU pipe: int; $105
(W)     mov (1|M0)               r40.22<1>:w   0:w                                                   //  ALU pipe: int; $106
(W)     jmpi                                 _0_036                                                  // $108
// B011: Preds:{B009},  Succs:{B012, B013}
_0_040:
(W)     cmp (32|M0)   (le)f3.0   null<1>:ud    r40.12<0;1,0>:ud  r2.12<0;1,0>:ud  {I@7}              //  ALU pipe: int; $111
(W)     add (1|M0)               r1.2<1>:d     r2.12<0;1,0>:d    -r42.9<0;1,0>:d                     //  ALU pipe: int; $110
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r40.12<0;1,0>:ud  r40.9<0;1,0>:ud                     //  ALU pipe: int; $114
(W&f3.0) cmp (32|M0)  (le)f3.0   null<1>:ud    r40.12<0;1,0>:ud  r1.2<0;1,0>:ud   {I@2}              //  ALU pipe: int; $112
(W)     mov (1|M0)               r2.0<1>:ud    f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $115
(W)     and (1|M0)               f1.0<1>:ud    f3.0<0;1,0>:ud    r2.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $115
(W&f1.0) jmpi                                _0_042                                                  //  ALU pipe: int; $116
// B012: Preds:{B011},  Succs:{B022}
_0_043:
        mov (32|M0)              r45.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $120
(W)     mov (1|M0)               r1.4<1>:w     1:w                                                   //  ALU pipe: int; $118
(W)     mov (1|M0)               r40.10<1>:d   0:w                                                   //  ALU pipe: int; $119
(W&f3.0) sel (1|M0)              r40.22<1>:w   r1.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $118
(W)     jmpi                                 _0_036                                                  // $121
// B013: Preds:{B011},  Succs:{B014, B015}
_0_042:
(W)     mul (1|M0)               acc0.0<1>:ud  r42.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $124
(W)     macl (1|M0)              r2.0<1>:ud    r42.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $125
(W)     mul (1|M0)               acc0.0<1>:ud  r42.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $125
(W)     mach (1|M0)              r4.0<1>:d     r42.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r3.0<2>:f     r2.0<0;1,0>:f                    {I@3}                //  ALU pipe: float; $125
(W)     mov (1|M0)               r3.1<2>:d     r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $129
(W)     mov (2|M0)               r1.2<1>:d     r2.10<1;1,0>:d                                        //  ALU pipe: int; $123
(W)     add (1|M0)               r5.0<1>:q     r3.0<0;1,0>:q     r42.9<0;1,0>:ud  {A@1}              //  ALU pipe: int; $131
        shl (32|M0)              r12.0<1>:d    r43.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $151
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r40.9<0;1,0>:ud  {I@2}              //  ALU pipe: int; $133
(W)     mul (1|M0)               r11.0<1>:d    r40.6<0;1,0>:d    1536:w               {Compacted}    //  ALU pipe: int; $149
(W)     mov (2|M0)               r7.0<1>:f     r6.0<1;1,0>:f                    {Compacted,I@2}      //  ALU pipe: float; $134
(W)     add (1|M0)               r42.1<1>:d    r11.0<0;1,0>:d    1536:w               {Compacted,I@1} //  ALU pipe: int; $150
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw   {F@1}              //  ALU pipe: int; $135
(W)     macl (1|M0)              r42.0<1>:ud   r7.0<0;1,0>:ud    r1.2<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $136
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw                      //  ALU pipe: int; $136
        or (32|M0)               r47.0<1>:d    r12.0<1;1,0>:d    r11.0<0;1,0>:d   {Compacted}        //  ALU pipe: int; $152
(W)     mach (1|M0)              r8.0<1>:d     r7.0<0;1,0>:ud    r1.2<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r7.0<0;1,0>:ud    r1.6<0;1,0>:uw                      //  ALU pipe: int; $137
(W)     macl (1|M0)              r9.0<1>:d     r7.0<0;1,0>:ud    r1.3<0;1,0>:d                       //  ALU pipe: int; $138
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r47.0<1;1,0>:ud   r42.1<0;1,0>:ud  {I@4}              //  ALU pipe: int; $153
(W)     mul (1|M0)               acc0.0<1>:d   r1.2<0;1,0>:ud    r7.2<0;1,0>:uw                      //  ALU pipe: int; $139
(W)     add (1|M0)               r8.0<1>:d     r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@3}    //  ALU pipe: int; $138
(W)     macl (1|M0)              r9.0<1>:d     r1.2<0;1,0>:ud    r7.1<0;1,0>:d                       //  ALU pipe: int; $141
(W)     mul (1|M0)               acc0.0<1>:ud  r40.7<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $143
(W)     mach (1|M0)              r10.0<1>:d    r40.7<0;1,0>:ud   0x3000:ud                           //  ALU pipe: int; 
(W)     mul (1|M0)               r40.14<1>:ud  r40.7<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $142
(W)     add (1|M0)               r40.13<1>:d   r8.0<0;1,0>:d     r9.0<0;1,0>:d    {I@4}              //  ALU pipe: int; $141
(W)     mov (1|M0)               r40.15<1>:d   r10.0<0;1,0>:d                   {I@3}                //  ALU pipe: int; $148
(f3.0)  goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $154
// B014: [inDivergent],  Preds:{B013},  Succs:{B022}
_0_045:
        mov (32|M0)              r45.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $158
(W)     mov (1|M0)               r40.10<1>:d   -1:w                                                  //  ALU pipe: int; $156
(W)     mov (1|M0)               r40.22<1>:w   1:w                                                   //  ALU pipe: int; $157
        goto (32|M0)                         _0_044            _0_036                                // $159
// B015: [inDivergent],  Preds:{B013},  Succs:{B016}
_0_044:
        join (32|M0)                         _0_036                                                  // 
L2032:
        mov (32|M0)              r45.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $171
(W)     mov (1|M0)               r1.2<1>:d     r42.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $161
(W)     mov (1|M0)               r1.3<1>:d     r40.13<0;1,0>:d                  {I@7}                //  ALU pipe: int; $162
(W)     mov (1|M0)               r2.0<1>:d     r40.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $166
(W)     mov (1|M0)               r2.1<1>:d     r40.15<0;1,0>:d                  {I@7}                //  ALU pipe: int; $167
(W)     add (1|M0)               r42.1<1>:q    r1.1<0;1,0>:q     r1.0<0;1,0>:q    {I@3}              //  ALU pipe: int; $165
(W)     add (1|M0)               r42.2<1>:q    r2.0<0;1,0>:q     r1.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $170
// B016: [inDivergent],  Preds:{B020, B015},  Succs:{B017, B020}
_0_046:
        add (32|M0)              r3.0<1>:d     r47.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $173
        sel (32|M0)   (lt)f0.0   r49.0<1>:ud   r3.0<1;1,0>:ud    r42.1<0;1,0>:ud  {I@1}              //  ALU pipe: int; $174
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r47.0<1;1,0>:ud   r49.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $175
(~f3.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $176
// B017: [inDivergent],  Preds:{B016},  Succs:{B018}
_0_048:
        mov (32|M0)              r51.0<1>:f    r47.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $178
// B018: [inDivergent],  Preds:{B019, B017},  Succs:{B019, B020}
_0_049:
        shl (32|M0)              r3.0<1>:d     r51.0<1;1,0>:d    1:w               {Compacted,F@1}   //  ALU pipe: int; $185
        shl (32|M0)              r5.0<1>:d     r51.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $180
        mov (16|M0)              r7.0<2>:ud    r3.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $187
        mov (16|M16)             r9.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $187
        add (16|M0)              r15.0<1>:q    r42.2<0;1,0>:q    r7.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $187
        add (16|M16)             r17.0<1>:q    r42.2<0;1,0>:q    r9.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $187
        mov (16|M0)              r11.0<2>:ud   r5.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $182
        mov (16|M16)             r13.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $182
        load.ugm.d16u32.a64 (32|M0)  r24:2      [r15:4]            {I@3,$3} // ex_desc:0x0; desc:0x8200B80 // $189
        add (16|M0)              r19.0<1>:q    r42.1<0;1,0>:q    r11.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $182
        add (16|M16)             r21.0<1>:q    r42.1<0;1,0>:q    r13.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $182
        load.ugm.d32.a64 (32|M0)  r26:2         [r19:4]            {I@1,$4} // ex_desc:0x0; desc:0x8200580 // $184
        add (32|M0)              r53.0<1>:d    r51.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $193
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r53.0<1;1,0>:ud   r49.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $194
        shl (32|M0)              r28.0<1>:d    r24.0<1;1,0>:ud   16:w               {$3.dst}         //  ALU pipe: int; $190
        sync.nop                             null                             {Compacted,I@1}        // $191
        mul (32|M0)              acc0.0<1>:f   r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,$4.dst} //  ALU pipe: float; $191
        add (32|M0)              r45.0<1>:f    r45.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $192
(~f1.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $195
// B019: [inDivergent],  Preds:{B018},  Succs:{B018}
_0_050:
        mov (32|M0)              r51.0<1>:f    r53.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $197
(W)     jmpi                                 _0_049                                                  // $198
// B020: [inDivergent],  Preds:{B018, B016},  Succs:{B021, B016}
_0_047:
        join (32|M0)                         _0_051                                                  // 
L2440:
        add (32|M0)              r47.0<1>:d    r47.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $200
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r47.0<1;1,0>:ud   r42.1<0;1,0>:ud  {I@1}              //  ALU pipe: int; $201
(f2.0)  goto.b (32|M0)                       _0_051            _0_046                                //  ALU pipe: int; $202
// B021: [inDivergent],  Preds:{B020},  Succs:{B022}
_0_051:
        join (32|M0)                         _0_036                                                  // 
L2496:
(W)     mov (1|M0)               r40.10<1>:d   -1:w                                                  //  ALU pipe: int; $204
(W)     mov (1|M0)               r40.22<1>:hf  0x1:hf                                                //  ALU pipe: float; $205
// B022: Preds:{B021, B014, B012, B010, B005},  Succs:{B023, B024}
_0_036:
        join (32|M0)                         L2544                                                   // 
L2544:
        add (32|M0)              r3.0<1>:d     r43.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $207
        and (32|M0)              r5.0<1>:d     r3.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $208
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $209
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $210
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0xB40:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0127(r45.0:f); $211
        add (32|M0)              r10.0<1>:d    r43.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $220
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@3}                //  ALU pipe: int; $212
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $213
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0xB40:uw                            //  ALU pipe: int; src1 is addr of V0127(r45.0:f); $214
        and (32|M0)   (eq)f2.0   null<1>:d     r43.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $216
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $221
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $215
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $222
(f2.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $218
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $223
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0xDC0:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0223(r55.0:f); $224
        add (32|M0)              r55.0<1>:f    r45.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $219
        add (32|M0)              r17.0<1>:d    r43.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $233
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $225
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $226
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0xDC0:uw                            //  ALU pipe: int; src1 is addr of V0223(r55.0:f); $227
        and (32|M0)   (eq)f1.0   null<1>:d     r43.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $229
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $234
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $228
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $235
(f1.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $231
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $236
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0xE40:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0231(r57.0:f); $237
        add (32|M0)              r57.0<1>:f    r55.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $232
        add (32|M0)              r24.0<1>:d    r43.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $246
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $238
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $239
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0xE40:uw                            //  ALU pipe: int; src1 is addr of V0231(r57.0:f); $240
        and (32|M0)   (eq)f3.0   null<1>:d     r43.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $242
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $247
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $241
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $248
(f3.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $244
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $249
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0xEC0:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0239(r59.0:f); $250
        add (32|M0)              r59.0<1>:f    r57.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $245
        add (32|M0)              r31.0<1>:d    r43.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $259
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $251
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $252
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0xEC0:uw                            //  ALU pipe: int; src1 is addr of V0239(r59.0:f); $253
        and (32|M0)   (eq)f2.0   null<1>:d     r43.0<1;1,0>:d    15:w                                //  ALU pipe: int; $255
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $260
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $254
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $261
        cmp (32|M0)   (eq)f1.0   null<2>:w     r41.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $268
(f2.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $257
(W)     mov (1|M0)               r36.0<1>:hf   0x1:hf                                                //  ALU pipe: float; $269
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $262
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0xF40:uw              {I@3}         //  ALU pipe: int; src1 is addr of V0247(r61.0:f); $263
        add (32|M0)              r61.0<1>:f    r59.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $258
(f0.0)  sel (32|M0)              r37.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw              {F@2}           //  ALU pipe: int; $269
(f1.0)  sel (32|M0)              r38.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw                              //  ALU pipe: int; $269
        mov (16|M0)              r63.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $264
        and (32|M0)   (ne)f1.0   null<2>:uw    r37.0<1;1,0>:uw   r38.0<1;1,0>:uw  {I@2}              //  ALU pipe: int; $269
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $265
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0xF40:uw                            //  ALU pipe: int; src1 is addr of V0247(r61.0:f); $266
        mov (16|M16)             r64.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $267
(~f1.0) goto (32|M0)                         _0_052            _0_052                                //  ALU pipe: int; $270
// B023: [inDivergent],  Preds:{B022},  Succs:{B024}
_0_053:
        cmp (32|M0)   (eq)f3.0   null<2>:w     r41.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $272
(W)     shl (1|M0)               r5.0<1>:q     r40.1<0;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $277
(W)     cmp (32|M0)   (ne)f2.0   null<1>:d     r40.10<0;1,0>:d   0:w                                 //  ALU pipe: int; $275
(W)     and (1|M0)               r6.0<1>:d     r5.0<0;1,0>:d     -16:w               {Compacted,I@2} //  ALU pipe: int; $278
(W)     and (1|M0)               r6.1<1>:d     r5.1<0;1,0>:d     7:w                                 //  ALU pipe: int; $279
(f3.0)  sel (32|M0)              acc0.0<1>:f   r63.0<1;1,0>:f    0x80000000:f                        //  ALU pipe: float; $273
(W)     add (1|M0)               r7.0<1>:q     r6.0<0;1,0>:q     r2.4<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $280
        add (32|M0)              acc0.0<1>:f   r61.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $274
(W)     add (1|M0)               r8.0<1>:q     r7.0<0;1,0>:q     r5.0<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $281
(f2.0)  sel (32|M0)              r3.0<1>:f     acc0.0<1;1,0>:f   0x7FC00000:f                        //  ALU pipe: float; $276
        mov (16|M0)              r9.0<2>:f     r8.0<0;1,0>:f                    {I@1}                //  ALU pipe: float; $283
        mov (16|M16)             r11.0<2>:ud   r8.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $283
        mov (16|M0)              r9.1<2>:ud    r8.1<0;1,0>:ud                   {F@1}                //  ALU pipe: int; $284
        mov (16|M16)             r11.1<2>:ud   r8.1<0;1,0>:ud                                        //  ALU pipe: int; $284
        store.ugm.d32.a64 (32|M0)  [r9:4]       r3:2               {I@1,$5} // ex_desc:0x0; desc:0x8000584 // $285
// B024: Preds:{B023, B022},  Succs:{B025, B026}
_0_052:
        join (32|M0)                         L3648                                                   // 
L3648:
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r40.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $287
(W&~f1.0) cmp (32|M0) (ne)f1.0   null<1>:d     r40.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $288
        bfn.(s0|s1|s2) (32|M0)   r3.0<1>:ud    r40.6<0;0>:ud     r43.0<1;0>:ud     r40.9<0>:ud      {$5.src} //  ALU pipe: int; $290
(f1.0)  cmp (32|M0)   (eq)f1.0   null<1>:d     r3.0<1;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $291
(W)     mov (1|M0)               r5.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $293
(f1.0)  sel (32|M0)              r6.0<1>:uw    r5.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $293
(f0.0)  sel (32|M0)              r7.0<1>:uw    r5.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $293
        and (32|M0)   (ne)f1.0   null<2>:uw    r6.0<1;1,0>:uw    r7.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $293
(~f1.0) goto (32|M0)                         _0_054            _0_054                                //  ALU pipe: int; $294
// B025: [inDivergent],  Preds:{B024},  Succs:{B026}
_0_055:
(W)     mov (1|M0)               r1.8<2>:b     r40.22<0;1,0>:w                                       //  ALU pipe: int; $296
(W)     mov (1|M0)               r3.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $299
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $297
(W)     shl (1|M0)               r7.0<1>:q     r40.7<0;1,0>:ud   2:w                                 //  ALU pipe: int; $302
(W)     cmp (32|M0)   (eq)f3.0   null<2>:w     r2.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $298
(W&f3.0) sel (1|M0)              r4.0<1>:d     r3.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $299
(W)     add (1|M0)               r8.0<1>:q     r7.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $303
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $300
(W)     store.ugm.d32x1t.a64 (1|M0)  [r8:1]     r6:1               {I@1,$6} // ex_desc:0x0; desc:0x2008584 // $305
// B026: Preds:{B025, B024},  Succs:{}
_0_054:
        join (32|M0)                         L3936                                                   // 
L3936:
(W)     mov (16|M0)              r127.0<1>:f   r39.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $307
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$7} // wr:1+0, rd:0; end of thread // $307
L3960:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x26:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 2
//


//.numALUInst: 251
//.accSubDef: 7
//.accSubUse: 7
//.accSubCandidateDef: 7
//.accSubCandidateUse: 7
//
//
//.singlePipeAtOneDistNum: 46
//.allAtOneDistNum: 9
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 5
//.AfterReadTokenDepCount: 1
