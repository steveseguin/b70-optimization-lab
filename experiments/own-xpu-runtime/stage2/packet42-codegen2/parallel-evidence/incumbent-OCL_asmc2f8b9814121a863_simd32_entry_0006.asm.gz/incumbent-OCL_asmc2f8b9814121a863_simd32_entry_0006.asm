//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE14ELj6144ELj4ELj1ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 6 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 6 -GRFBumpUpNumber 2 "
//.instCount 351
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r53.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r53.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r53.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.1)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.13)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r54.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.2)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r55.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=16 words (r53.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r1.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0067 (77)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r1.8)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r54.1)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0070 (80)  rf=r size=8 type=uq alias=V0068+0 align=4 words (r54.1)
//.declare V0071 (81)  rf=r size=8 type=uq alias=V0069+0 align=4 words (r4.0)
//.declare V0072 (82)  rf=r size=8 type=d align=2 words (r54.4)
//.declare V0073 (83)  rf=r size=8 type=d alias=V0069+0 align=4 words (r4.0)
//.declare V0075 (85)  rf=r size=4 type=d align=2 words (r54.6)
//.declare V0076 (86)  rf=r size=4 type=d align=4 words (r54.8)
//.declare P01 (87)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0077 (88)  rf=r size=4 type=d align=2 words (r54.7)
//.declare V0078 (89)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0079 (90)  rf=r size=4 type=ud alias=V0050+0 align=2 words (r2.12)
//.declare V0080 (91)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0081 (92)  rf=r size=4 type=ud alias=V0080+0 align=2 words (r3.0)
//.declare V0082 (93)  rf=r size=4 type=d alias=+0 align=2 words (r4.0)
//.declare V0083 (94)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0084 (95)  rf=r size=4 type=ud alias=V0076+0 align=2 words (r54.8)
//.declare V0085 (96)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0086 (97)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0087 (98)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0088 (99)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0089 (100)  rf=r size=4 type=ud alias=V0088+0 align=2 words (r10.0)
//.declare V0090 (101)  rf=r size=4 type=d alias=+4 align=2 words (r4.1)
//.declare V0091 (102)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0092 (103)  rf=r size=4 type=ud alias=V0091+0 align=2 words (r11.0)
//.declare V0093 (104)  rf=r size=4 type=f alias=+0 align=2 words (r12.0)
//.declare V0094 (105)  rf=r size=4 type=ud alias=V0082+0 align=2 words (r4.0)
//.declare V0095 (106)  rf=r size=4 type=f alias=+4 align=2 words (r12.1)
//.declare V0096 (107)  rf=r size=4 type=ud alias=V0090+0 align=2 words (r4.1)
//.declare V0097 (108)  rf=r size=4 type=f align=2 words (r13.0)
//.declare V0099 (110)  rf=r size=4 type=f align=2 words (r14.0)
//.declare V0101 (112)  rf=r size=4 type=f align=2 words (r15.0)
//.declare V0102 (113)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0103 (114)  rf=r size=4 type=f align=2 words (r17.0)
//.declare V0104 (115)  rf=r size=4 type=d align=2 words (r18.0)
//.declare V0105 (116)  rf=r size=4 type=ud alias=V0104+0 align=2 words (r18.0)
//.declare V0106 (117)  rf=r size=4 type=d align=2 words (r19.0)
//.declare V0107 (118)  rf=r size=4 type=d align=32 words (r20.0)
//.declare V0108 (119)  rf=r size=4 type=d align=2 words (r21.0)
//.declare V0109 (120)  rf=r size=4 type=d align=2 words (r22.0)
//.declare V0110 (121)  rf=r size=4 type=ud alias=V0108+0 align=2 words (r21.0)
//.declare V0111 (122)  rf=r size=4 type=ud alias=V0109+0 align=2 words (r22.0)
//.declare  (123)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0112 (124)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0113 (125)  rf=r size=4 type=d align=2 words (r54.9)
//.declare V0114 (126)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0116 (128)  rf=r size=4 type=ud alias=V0114+0 align=2 words (r3.0)
//.declare V0117 (129)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r2.13)
//.declare V0118 (130)  rf=r size=4 type=d align=32 words (r4.0)
//.declare P02 (133)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0121 (134)  rf=r size=8 type=ud alias=V0072+0 align=2 words (r54.4)
//.declare P03 (135)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P04 (136)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0123 (138)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0124 (139)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r55.0)
//.declare P05 (140)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P06 (141)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P07 (142)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0125 (143)  rf=r size=4 type=d align=2 words (r54.10)
//.declare V0126 (144)  rf=r size=2 type=w align=1 words (r54.22)
//.declare V0127 (145)  rf=r size=128 type=f align=32 words (r59.0)
//.declare P08 (146)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P09 (147)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0128 (148)  rf=r size=4 type=d alias=+0 align=2 words (r56.8)
//.declare V0129 (149)  rf=r size=4 type=d alias=+4 align=2 words (r56.9)
//.declare V0130 (150)  rf=r size=4 type=d align=2 words (r54.12)
//.declare V0131 (151)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0132 (152)  rf=r size=4 type=ud alias=V0077+0 align=2 words (r54.7)
//.declare V0133 (153)  rf=r size=8 type=ud alias=V0131+0 align=4 words (r1.2)
//.declare V0134 (154)  rf=r size=8 type=d alias=V0131+0 align=4 words (r1.2)
//.declare V0135 (155)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0139 (159)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0140 (160)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P10 (161)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0141 (162)  rf=r size=4 type=ud alias=V0129+0 align=2 words (r56.9)
//.declare P11 (163)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0142 (164)  rf=r size=4 type=ud alias=V0128+0 align=2 words (r56.8)
//.declare V0143 (165)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r2.14)
//.declare V0144 (166)  rf=r size=4 type=d align=2 words (r1.2)
//.declare P12 (167)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0145 (168)  rf=r size=4 type=ud alias=V0130+0 align=2 words (r54.12)
//.declare P13 (169)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0146 (170)  rf=r size=4 type=ud alias=V0144+0 align=2 words (r1.2)
//.declare P14 (171)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0147 (172)  rf=r size=4 type=ud alias=V0113+0 align=2 words (r54.9)
//.declare P15 (173)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0148 (174)  rf=r size=8 type=d align=2 words (r1.2)
//.declare V0149 (175)  rf=r size=8 type=d alias=V0049+0 align=4 words (r2.10)
//.declare V0150 (176)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0151 (177)  rf=r size=8 type=ud alias=V0150+0 align=4 words (r3.0)
//.declare V0152 (178)  rf=r size=8 type=d alias=V0150+0 align=4 words (r3.0)
//.declare V0153 (179)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0156 (182)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0158 (184)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0159 (185)  rf=r size=8 type=d align=2 words (r7.0)
//.declare V0160 (186)  rf=r size=8 type=d alias=V0158+0 align=4 words (r6.0)
//.declare V0161 (187)  rf=r size=4 type=d align=32 words (r56.0)
//.declare V0162 (188)  rf=r size=4 type=d align=2 words (r54.13)
//.declare V0163 (189)  rf=r size=4 type=ud alias=V0161+0 align=2 words (r56.0)
//.declare V0164 (190)  rf=r size=8 type=ud alias=V0159+0 align=2 words (r7.0)
//.declare V0165 (191)  rf=r size=8 type=ud alias=V0148+0 align=2 words (r1.2)
//.declare V0166 (192)  rf=r size=4 type=d align=32 words (r8.0)
//.declare V0168 (194)  rf=r size=4 type=d align=32 words (r9.0)
//.declare V0169 (195)  rf=r size=4 type=d align=2 words (r54.14)
//.declare V0170 (196)  rf=r size=4 type=d align=2 words (r54.15)
//.declare V0171 (197)  rf=r size=4 type=ud alias=V0169+0 align=2 words (r54.14)
//.declare V0172 (198)  rf=r size=4 type=d align=32 words (r10.0)
//.declare V0175 (201)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0176 (202)  rf=r size=4 type=d align=2 words (r56.1)
//.declare V0177 (203)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0178 (204)  rf=r size=128 type=d align=32 words (r61.0)
//.declare P16 (205)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0179 (206)  rf=r size=128 type=ud alias=V0178+0 align=32 words (r61.0)
//.declare V0180 (207)  rf=r size=4 type=ud alias=V0176+0 align=2 words (r56.1)
//.declare V0182 (209)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0183 (210)  rf=r size=8 type=d alias=V0182+0 align=4 words (r1.2)
//.declare V0184 (211)  rf=r size=8 type=q align=4 words (r56.1)
//.declare V0186 (213)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0187 (214)  rf=r size=8 type=d alias=V0186+0 align=4 words (r2.0)
//.declare V0188 (215)  rf=r size=8 type=q align=4 words (r56.2)
//.declare V0189 (216)  rf=r size=8 type=q align=4 words (r56.3)
//.declare V0190 (217)  rf=r size=128 type=d align=32 words (r63.0)
//.declare V0191 (218)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0192 (219)  rf=r size=128 type=d align=32 words (r65.0)
//.declare V0193 (220)  rf=r size=128 type=ud alias=V0191+0 align=32 words (r3.0)
//.declare V0194 (221)  rf=r size=128 type=ud alias=V0192+0 align=32 words (r65.0)
//.declare P17 (222)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0195 (223)  rf=r size=128 type=ud alias=V0190+0 align=32 words (r63.0)
//.declare V0196 (224)  rf=r size=128 type=d align=32 words (r67.0)
//.declare V0197 (225)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0198 (226)  rf=r size=128 type=d align=32 words (r69.0)
//.declare V0199 (227)  rf=r size=128 type=d align=32 words (r71.0)
//.declare V0200 (228)  rf=r size=128 type=ud alias=V0198+0 align=32 words (r69.0)
//.declare V0201 (229)  rf=r size=128 type=ud alias=V0199+0 align=32 words (r71.0)
//.declare V0202 (230)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0203 (231)  rf=r size=128 type=ud alias=V0196+0 align=32 words (r67.0)
//.declare V0204 (232)  rf=r size=128 type=ud alias=V0202+0 align=32 words (r5.0)
//.declare V0205 (233)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0207 (235)  rf=r size=128 type=ud alias=V0205+0 align=32 words (r7.0)
//.declare V0210 (238)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0211 (239)  rf=r size=128 type=d align=32 words (r73.0)
//.declare V0212 (240)  rf=r size=128 type=d align=32 words (r17.0)
//.declare P18 (241)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P19 (242)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0216 (246)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0217 (247)  rf=r size=32 type=b align=32 words (r24.0)
//.declare V0218 (248)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0219 (249)  rf=r size=128 type=b alias=V0218+0 align=32 words (r16.0)
//.declare V0223 (253)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare V0225 (255)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare V0226 (256)  rf=r size=128 type=w alias=V0225+0 align=32 words (r22.0)
//.declare V0228 (258)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0229 (259)  rf=r size=128 type=d align=32 words (r25.0)
//.declare P20 (261)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0231 (262)  rf=r size=128 type=f align=32 words (r31.0)
//.declare V0233 (264)  rf=r size=128 type=f alias=V0211+0 align=32 words (r73.0)
//.declare V0235 (266)  rf=r size=128 type=d align=32 words (r27.0)
//.declare V0237 (268)  rf=r size=128 type=f alias=V0235+0 align=32 words (r27.0)
//.declare P21 (269)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P22 (270)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0241 (274)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0242 (275)  rf=r size=32 type=b align=32 words (r44.0)
//.declare V0243 (276)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0244 (277)  rf=r size=128 type=b alias=V0243+0 align=32 words (r24.0)
//.declare V0248 (281)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0255 (288)  rf=r size=256 type=uq align=32 words (r38.0)
//.declare V0256 (289)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0260 (293)  rf=r size=256 type=uq align=32 words (r30.0)
//.declare V0262 (295)  rf=r size=128 type=ud align=32 words (r36.0)
//.declare V0263 (296)  rf=r size=128 type=w alias=V0262+0 align=32 words (r36.0)
//.declare V0265 (298)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0266 (299)  rf=r size=128 type=d align=32 words (r45.0)
//.declare P23 (301)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0268 (302)  rf=r size=128 type=f align=32 words (r51.0)
//.declare V0271 (305)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0273 (307)  rf=r size=128 type=f alias=V0271+0 align=32 words (r47.0)
//.declare P24 (308)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P25 (309)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P26 (310)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0274 (311)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0275 (312)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0276 (313)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0277 (314)  rf=r size=128 type=uw alias=V0275+0 align=32 words (r5.0)
//.declare V0278 (315)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (316)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P27 (317)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0281 (320)  rf=r size=128 type=f align=32 words (r75.0)
//.declare V0282 (321)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0283 (322)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0284 (323)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0285 (324)  rf=r size=128 type=uw alias=V0283+0 align=32 words (r12.0)
//.declare V0286 (325)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (326)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P28 (327)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0289 (330)  rf=r size=128 type=f align=32 words (r77.0)
//.declare V0290 (331)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0291 (332)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0292 (333)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0293 (334)  rf=r size=128 type=uw alias=V0291+0 align=32 words (r19.0)
//.declare V0294 (335)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (336)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P29 (337)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0297 (340)  rf=r size=128 type=f align=32 words (r79.0)
//.declare V0298 (341)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0299 (342)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0300 (343)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0301 (344)  rf=r size=128 type=uw alias=V0299+0 align=32 words (r26.0)
//.declare V0302 (345)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (346)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P30 (347)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0305 (350)  rf=r size=128 type=f align=32 words (r81.0)
//.declare V0306 (351)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0307 (352)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0308 (353)  rf=r size=128 type=f align=32 words (r83.0)
//.declare V0309 (354)  rf=r size=128 type=uw alias=V0307+0 align=32 words (r33.0)
//.declare V0310 (355)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (356)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P31 (357)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P32 (358)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P33 (359)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P34 (362)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0313 (363)  rf=r size=128 type=f align=32 words (r3.0)
//.declare V0314 (364)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0315 (365)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0316 (366)  rf=r size=8 type=d alias=V0315+0 align=4 words (r6.0)
//.declare V0317 (367)  rf=r size=8 type=d alias=V0314+0 align=4 words (r5.0)
//.declare V0318 (368)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0321 (371)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0322 (372)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0323 (373)  rf=r size=256 type=ud alias=V0322+0 align=32 words (r9.0)
//.declare V0324 (374)  rf=r size=8 type=ud alias=V0321+0 align=32 words (r8.0)
//.declare P35 (375)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P36 (376)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P37 (377)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0325 (378)  rf=r size=128 type=d align=32 words (r3.0)
//.declare P38 (379)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0326 (380)  rf=r size=2 type=b align=1 words (r1.8)
//.declare V0327 (381)  rf=r size=2 type=w align=1 words (r2.0)
//.declare V0328 (382)  rf=r size=2 type=ub alias=V0326+0 align=1 words (r1.8)
//.declare P39 (383)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0329 (384)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0330 (385)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0332 (387)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0335 (390)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare  (391)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (392)  rf=r size=4 type=d alias=V0068+0 align=2 words (r54.2)
//.declare  (393)  rf=r size=8 type=f align=8 words (r12.0)
//.declare  (394)  rf=r size=8 type=ud align=8 words (r4.0)
//.declare  (395)  rf=r size=8 type=d align=8 words (r56.8)
//.declare  (396)  rf=r size=64 type=uw align=32 words (r37.0)
//.declare  (397)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (398)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (399)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare  (400)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (401)  rf=r size=4 type=f align=2 words (r7.0)
//.declare  (402)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare  (403)  rf=r size=2 type=w align=1 words (r1.4)
//.declare  (404)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare  (405)  rf=r size=128 type=ud align=32 words (r9.0)
//.declare  (406)  rf=r size=128 type=ud align=32 words (r15.0)
//.declare  (407)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (408)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (411)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (412)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (417)  rf=r size=2 type=uw align=1 words (r36.0)
//.declare  (419)  rf=r size=2 type=uw align=1 words (r5.0)
//.declare  (421)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (430)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (431)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (438)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (439)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (440)  rf=r size=128 type=d align=32 words (r34.0)
//.declare  (441)  rf=r size=128 type=d align=32 words (r7.0)
//.declare  (442)  rf=r size=128 type=q align=32 words (r21.0)
//.declare  (443)  rf=r size=128 type=q align=32 words (r28.0)
//.declare  (446)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (447)  rf=r size=128 type=q align=32 words (r19.0)
//.declare  (450)  rf=r size=128 type=uq alias=+0 align=32 words (r13.0)
//.declare  (451)  rf=r size=128 type=uq alias=+0 align=32 words (r15.0)
//.declare  (452)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare  (453)  rf=r size=128 type=d alias=+0 align=32 words (r15.0)
//.declare  (454)  rf=r size=128 type=d alias=+0 align=32 words (r21.0)
//.declare  (455)  rf=r size=128 type=d alias=+0 align=32 words (r28.0)
//.declare r0 (456)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (457)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (458)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (459)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :q       |    0x8 | r1       | inline+0x0       |
// | V0041    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0042    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r2       | cti+0x20         |
// | V0045    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0050    | :d       |    0x4 | r2+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r2+0x34  | cti+0x54         |
// | V0052    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0054    | :b       |    0x1 | r3       | cti+0x60         |
// | V0055    | :b       |    0x1 | r3+0x4   | cti+0x64         |
// | V0037    | :uq      |    0x8 | r3+0x8   | cti+0x68         |
// | V0038    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r53.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r1.8<2>:b     r53.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     mov (8|M0)               r55.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {@2,$0.dst}          //  ALU pipe: int; $9
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $16
(W)     mov (1|M0)               r3.0<1>:q     r2.0<0;1,0>:w                    {@2,$1.dst}          //  ALU pipe: int; $9
(W)     add (8|M0)               r55.8<1>:w    r55.0<1;1,0>:w    8:w                                 //  ALU pipe: int; $5
(W)     add (1|M0)               r54.1<1>:q    r53.1<0;1,0>:ud   r3.0<0;1,0>:q    {I@2}              //  ALU pipe: int; $10
(W)     add (16|M0)              r55.16<1>:w   r55.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $6
(W)     shr (1|M0)               r4.0<1>:uq    r54.1<0;1,0>:uq   2:w               {I@2}             //  ALU pipe: int; $11
(W)     mov (2|M0)               r54.0<1>:d    r2.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     and (1|M0)               r54.6<1>:d    r54.2<0;1,0>:d    3:w                                 //  ALU pipe: int; $14
(W)     mov (2|M0)               r54.4<1>:d    r4.0<1;1,0>:d                    {Compacted,I@3}      //  ALU pipe: int; $12
(W)     mov (1|M0)               r54.8<2>:d    r4.0<0;1,0>:q                                         //  ALU pipe: int; $15
(W&~f3.0) jmpi                               _0_044                                                  //  ALU pipe: int; $17
// B002: Preds:{B001},  Succs:{B004}
_0_045:
(W)     mov (1|M0)               r54.7<1>:d    -1:w                                                  //  ALU pipe: int; $19
(W)     jmpi                                 _0_046                                                  // $20
// B003: Preds:{B001},  Succs:{B004}
_0_044:
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $22
(W)     mov (1|M0)               r2.0<1>:f     r2.12<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $23
(W)     mov (1|M0)               r7.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $28
(W)     math.inv (1|M0)          r6.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $27
(W)     mov (1|M0)               r5.0<1>:f     r54.8<0;1,0>:ud                  {I@5}                //  ALU pipe: float; $26
(W)     mad (1|M0)               r8.0<1>:f     r6.0<0;0>:f       r7.0<0;0>:f       r6.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $28
(W)     mov (1|M0)               r3.0<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $24
(W)     mov (1|M0)               r10.0<1>:ud   r5.0<0;1,0>:f                    {F@2}                //  ALU pipe: int; $30
(W)     mul (1|M0)               r9.0<1>:f     r5.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $29
(W)     add (1|M0)               r4.0<1>:d     r2.12<0;1,0>:d    -r3.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $25
(W)     add (1|M0)               r4.1<1>:d     r54.8<0;1,0>:d    -r10.0<0;1,0>:d  {I@2}              //  ALU pipe: int; $31
(W)     mov (1|M0)               r11.0<1>:ud   r9.0<0;1,0>:f                    {F@1}                //  ALU pipe: int; $32
(W)     mov (1|M0)               r12.0<1>:f    r4.0<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $33
(W)     mov (1|M0)               r12.1<1>:f    r4.1<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $33
(W)     mov (1|M0)               r13.0<1>:f    r11.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $35
(W)     mad (1|M0)               r14.0<1>:f    r5.0<0;0>:f       r13.0<0;0>:f      -r2.0<0>:f       {F@1} //  ALU pipe: float; $37
(W)     mad (1|M0)               r15.0<1>:f    r12.1<0;0>:f      r13.0<0;0>:f      -r12.0<0>:f       //  ALU pipe: float; $39
(W)     add (1|M0)               r16.0<1>:f    r14.0<0;1,0>:f    r15.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $40
(W)     mul (1|M0)               r17.0<1>:f    r8.0<0;1,0>:f     r16.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $41
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $42
(W)     mov (1|M0)               r18.0<1>:ud   r17.0<0;1,0>:f                   {A@1}                //  ALU pipe: int; $43
(W)     add (1|M0)               r19.0<1>:d    r18.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $44
(W)     mul (1|M0)               acc0.0<1>:d   r19.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $45
(W)     macl (1|M0)              r20.0<1>:d    r19.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $46
(W)     add (1|M0)               r21.0<1>:d    r54.8<0;1,0>:d    -r20.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $46
(W)     cmp (1|M0)    (ge)f2.0   r22.0<1>:ud   r21.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@1}              //  ALU pipe: int; $47
(W)     add3 (1|M0)              r54.7<1>:d    r18.0<0;0>:d      r11.0<0;0>:d      -r22.0<0>:d      {I@1} //  ALU pipe: int; $48
// B004: Preds:{B003, B002},  Succs:{B005, B006}
_0_046:
(W)     mul (1|M0)               acc0.0<1>:d   r54.7<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $50
(W)     macl (1|M0)              r2.0<1>:d     r54.7<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $51
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $52
(W)     macl (1|M0)              r3.0<1>:ud    r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; $53
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $53
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r54.4<0;1,0>:ud   r3.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $65
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r54.4<0;1,0>:ud   r3.0<0;1,0>:ud                      //  ALU pipe: int; $59
(W)     mach (1|M0)              r4.0<1>:d     r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; 
        mov (32|M0)              r57.0<1>:d    r55.0<1;1,0>:uw                                       //  ALU pipe: int; $64
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r54.5<0;1,0>:d    r4.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $66
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r54.5<0;1,0>:d    r4.0<0;1,0>:d                       //  ALU pipe: int; $60
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:ud    r54.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $68
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r54.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $62
(W)     add (1|M0)               r54.9<1>:d    r54.8<0;1,0>:d    -r2.0<0;1,0>:d                      //  ALU pipe: int; $51
(W&f3.0) jmpi                                _0_047                                                  //  ALU pipe: int; $70
// B005: Preds:{B004},  Succs:{B031}
_0_048:
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $74
(W)     mov (1|M0)               r54.10<1>:d   0:w                                                   //  ALU pipe: int; $72
(W)     mov (1|M0)               r54.22<1>:w   0:w                                                   //  ALU pipe: int; $73
(W)     jmpi                                 _0_049                                                  // $75
// B006: Preds:{B004},  Succs:{B007, B008}
_0_047:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r54.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $77
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r54.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $78
(W&~f2.0) jmpi                               _0_050                                                  //  ALU pipe: int; $80
// B007: Preds:{B006},  Succs:{B009}
_0_051:
(W)     mov (2|M0)               r56.8<1>:d    0:w                                                   //  ALU pipe: int; $82
(W)     mov (1|M0)               r54.12<1>:f   r2.12<0;1,0>:f                                        //  ALU pipe: float; $84
(W)     jmpi                                 _0_052                                                  // $85
// B008: Preds:{B006},  Succs:{B009}
_0_050:
(W)     mul (1|M0)               acc0.0<1>:ud  r54.7<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $88
(W)     mach (1|M0)              r2.0<1>:d     r54.7<0;1,0>:ud   0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.2<2>:ud    r54.7<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $87
(W)     mov (1|M0)               r1.3<2>:d     r2.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $92
(W)     add (1|M0)               r4.0<1>:q     r1.1<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $93
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $95
(W)     mov (1|M0)               r56.8<1>:d    r5.0<0;1,0>:d                    {$2.dst}             //  ALU pipe: int; $96
(W)     mov (1|M0)               r56.9<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $97
(W)     mov (1|M0)               r54.12<1>:d   r5.2<0;1,0>:d                    {F@1}                //  ALU pipe: int; $98
// B009: Preds:{B008, B007},  Succs:{B010, B011}
_0_052:
(W)     cmp (32|M0)   (gt)f1.0   null<1>:ud    r56.9<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $100
(W&~f1.0) cmp (32|M0) (ge)f1.0   null<1>:ud    r56.8<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; $101
(W&~f1.0) jmpi                               _0_053                                                  //  ALU pipe: int; $103
// B010: Preds:{B009},  Succs:{B031}
_0_054:
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $107
(W)     mov (1|M0)               r54.10<1>:d   0:w                                                   //  ALU pipe: int; $105
(W)     mov (1|M0)               r54.22<1>:w   0:w                                                   //  ALU pipe: int; $106
(W)     jmpi                                 _0_049                                                  // $108
// B011: Preds:{B009},  Succs:{B012, B013}
_0_053:
(W)     cmp (32|M0)   (le)f3.0   null<1>:ud    r54.12<0;1,0>:ud  r2.12<0;1,0>:ud  {I@7}              //  ALU pipe: int; $111
(W)     add (1|M0)               r1.2<1>:d     r2.12<0;1,0>:d    -r56.9<0;1,0>:d                     //  ALU pipe: int; $110
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r54.12<0;1,0>:ud  r54.9<0;1,0>:ud                     //  ALU pipe: int; $114
(W&f3.0) cmp (32|M0)  (le)f3.0   null<1>:ud    r54.12<0;1,0>:ud  r1.2<0;1,0>:ud   {I@2}              //  ALU pipe: int; $112
(W)     mov (1|M0)               r2.0<1>:ud    f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $115
(W)     and (1|M0)               f1.0<1>:ud    f3.0<0;1,0>:ud    r2.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $115
(W&f1.0) jmpi                                _0_055                                                  //  ALU pipe: int; $116
// B012: Preds:{B011},  Succs:{B031}
_0_056:
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $120
(W)     mov (1|M0)               r1.4<1>:w     1:w                                                   //  ALU pipe: int; $118
(W)     mov (1|M0)               r54.10<1>:d   0:w                                                   //  ALU pipe: int; $119
(W&f3.0) sel (1|M0)              r54.22<1>:w   r1.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $118
(W)     jmpi                                 _0_049                                                  // $121
// B013: Preds:{B011},  Succs:{B014, B015}
_0_055:
(W)     mul (1|M0)               acc0.0<1>:ud  r56.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $124
(W)     macl (1|M0)              r2.0<1>:ud    r56.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $125
(W)     mul (1|M0)               acc0.0<1>:ud  r56.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $125
(W)     mach (1|M0)              r4.0<1>:d     r56.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r3.0<2>:f     r2.0<0;1,0>:f                    {I@3}                //  ALU pipe: float; $125
(W)     mov (1|M0)               r3.1<2>:d     r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $129
(W)     mov (2|M0)               r1.2<1>:d     r2.10<1;1,0>:d                                        //  ALU pipe: int; $123
(W)     add (1|M0)               r5.0<1>:q     r3.0<0;1,0>:q     r56.9<0;1,0>:ud  {A@1}              //  ALU pipe: int; $131
        shl (32|M0)              r12.0<1>:d    r57.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $151
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r54.9<0;1,0>:ud  {I@2}              //  ALU pipe: int; $133
(W)     mul (1|M0)               r11.0<1>:d    r54.6<0;1,0>:d    1536:w               {Compacted}    //  ALU pipe: int; $149
(W)     mov (2|M0)               r7.0<1>:f     r6.0<1;1,0>:f                    {Compacted,I@2}      //  ALU pipe: float; $134
(W)     add (1|M0)               r56.1<1>:d    r11.0<0;1,0>:d    1536:w               {Compacted,I@1} //  ALU pipe: int; $150
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw   {F@1}              //  ALU pipe: int; $135
(W)     macl (1|M0)              r56.0<1>:ud   r7.0<0;1,0>:ud    r1.2<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $136
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw                      //  ALU pipe: int; $136
        or (32|M0)               r61.0<1>:d    r12.0<1;1,0>:d    r11.0<0;1,0>:d   {Compacted}        //  ALU pipe: int; $152
(W)     mach (1|M0)              r8.0<1>:d     r7.0<0;1,0>:ud    r1.2<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r7.0<0;1,0>:ud    r1.6<0;1,0>:uw                      //  ALU pipe: int; $137
(W)     macl (1|M0)              r9.0<1>:d     r7.0<0;1,0>:ud    r1.3<0;1,0>:d                       //  ALU pipe: int; $138
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r61.0<1;1,0>:ud   r56.1<0;1,0>:ud  {I@4}              //  ALU pipe: int; $153
(W)     mul (1|M0)               acc0.0<1>:d   r1.2<0;1,0>:ud    r7.2<0;1,0>:uw                      //  ALU pipe: int; $139
(W)     add (1|M0)               r8.0<1>:d     r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@3}    //  ALU pipe: int; $138
(W)     macl (1|M0)              r9.0<1>:d     r1.2<0;1,0>:ud    r7.1<0;1,0>:d                       //  ALU pipe: int; $141
(W)     mul (1|M0)               acc0.0<1>:ud  r54.7<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $143
(W)     mach (1|M0)              r10.0<1>:d    r54.7<0;1,0>:ud   0x3000:ud                           //  ALU pipe: int; 
(W)     mul (1|M0)               r54.14<1>:ud  r54.7<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $142
(W)     add (1|M0)               r54.13<1>:d   r8.0<0;1,0>:d     r9.0<0;1,0>:d    {I@4}              //  ALU pipe: int; $141
(W)     mov (1|M0)               r54.15<1>:d   r10.0<0;1,0>:d                   {I@3}                //  ALU pipe: int; $148
(f3.0)  goto (32|M0)                         _0_057            _0_057                                //  ALU pipe: int; $154
// B014: [inDivergent],  Preds:{B013},  Succs:{B031}
_0_058:
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $158
(W)     mov (1|M0)               r54.10<1>:d   -1:w                                                  //  ALU pipe: int; $156
(W)     mov (1|M0)               r54.22<1>:w   1:w                                                   //  ALU pipe: int; $157
        goto (32|M0)                         _0_057            _0_049                                // $159
// B015: [inDivergent],  Preds:{B013},  Succs:{B016}
_0_057:
        join (32|M0)                         _0_049                                                  // 
L2032:
(W)     mov (1|M0)               r1.2<1>:d     r56.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $161
(W)     mov (1|M0)               r1.3<1>:d     r54.13<0;1,0>:d                  {I@7}                //  ALU pipe: int; $162
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $172
        mov (32|M0)              r63.0<1>:d    r61.0<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $173
(W)     mov (1|M0)               r2.0<1>:d     r54.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $166
(W)     mov (1|M0)               r2.1<1>:d     r54.15<0;1,0>:d                  {I@7}                //  ALU pipe: int; $167
(W)     add (1|M0)               r56.1<1>:q    r1.1<0;1,0>:q     r1.0<0;1,0>:q    {I@4}              //  ALU pipe: int; $165
(W)     add (1|M0)               r56.2<1>:q    r2.0<0;1,0>:q     r1.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $170
(W)     add (1|M0)               r56.3<1>:q    r56.1<0;1,0>:q    6144:w               {I@2}          //  ALU pipe: int; $171
// B016: [inDivergent],  Preds:{B030, B015},  Succs:{B017, B028}
_0_059:
        add (32|M0)              r3.0<1>:d     r63.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $175
        sel (32|M0)   (lt)f0.0   r65.0<1>:ud   r3.0<1;1,0>:ud    r56.1<0;1,0>:ud  {I@1}              //  ALU pipe: int; $176
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r63.0<1;1,0>:ud   r65.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $177
(~f1.0) goto (32|M0)                         _0_060            _0_060                                //  ALU pipe: int; $178
// B017: [inDivergent],  Preds:{B016},  Succs:{B018}
_0_061:
        mov (32|M0)              r67.0<1>:f    r63.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $180
// B018: [inDivergent],  Preds:{B027, B017},  Succs:{B019, B023}
_0_062:
        shr (32|M0)              r5.0<1>:ud    r67.0<1;1,0>:ud   2:w               {F@1}             //  ALU pipe: int; $185
        and (32|M0)              r7.0<1>:d     r5.0<1;1,0>:d     1073741820:d               {I@1}    //  ALU pipe: int; $186
        mov (16|M0)              r9.0<2>:ud    r7.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $188
        mov (16|M16)             r15.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $188
        add (16|M0)              r11.0<1>:q    r56.3<0;1,0>:q    r9.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $188
        add (16|M16)             r13.0<1>:q    r56.3<0;1,0>:q    r15.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $188
        load.ugm.d32.a64 (32|M0)  r73:2         [r11:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200580 // $190
        and (32|M0)              r3.0<1>:d     r67.0<1;1,0>:d    -16:w               {Compacted}     //  ALU pipe: int; $182
        add (32|M0)              r69.0<1>:d    r3.0<1;1,0>:d     16:w               {Compacted,I@1}  //  ALU pipe: int; $183
        sel (32|M0)   (lt)f0.0   r71.0<1>:ud   r69.0<1;1,0>:ud   r65.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $184
        and (32|M0)              r17.0<1>:d    r73.0<1;1,0>:d    2139095040:d               {$3.dst} //  ALU pipe: int; $191
        cmp (32|M0)   (eq)f2.0   null<1>:d     r17.0<1;1,0>:d    2139095040:d               {I@1}    //  ALU pipe: int; $192
(f2.0)  goto (32|M0)                         _0_063            _0_063                                //  ALU pipe: int; $193
// B019: [inDivergent],  Preds:{B018},  Succs:{B020, B026}
_0_064:
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r67.0<1;1,0>:ud   r71.0<1;1,0>:ud                     //  ALU pipe: int; $195
(~f1.0) goto (32|M0)                         _0_063            _0_065                                //  ALU pipe: int; $196
// B020: [inDivergent],  Preds:{B019},  Succs:{B021}
_0_066:
        mov (32|M0)              r61.0<1>:f    r67.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $198
// B021: [inDivergent],  Preds:{B021, B020},  Succs:{B022, B021}
_0_067:
        mov (16|M0)              r3.0<2>:ud    r61.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $201
        mov (16|M16)             r5.0<2>:ud    r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $201
        add (16|M0)              r7.0<1>:q     r56.1<0;1,0>:q    r3.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $201
        add (16|M16)             r9.0<1>:q     r56.1<0;1,0>:q    r5.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $201
        load.ugm.d8u32.a64 (32|M0)  r16:2       [r7:4]             {I@1,$4} // ex_desc:0x0; desc:0x8200980 // $203
        shl (16|M0)              r11.0<1>:q    r3.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $205
        shl (16|M16)             r13.0<1>:q    r5.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $205
        add (16|M0)              r18.0<1>:q    r56.2<0;1,0>:q    r11.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $206
        add (16|M16)             r20.0<1>:q    r56.2<0;1,0>:q    r13.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $206
        load.ugm.d16u32.a64 (32|M0)  r22:2      [r18:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200B80 // $208
        add (32|M0)              r61.0<1>:d    r61.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $218
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r61.0<1;1,0>:ud   r71.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $219
        mov (32|M0)              r24.0<1>:b    r16.0<4;1,0>:b                   {$4.dst}             //  ALU pipe: int; $204
        mov (32|M0)   (lt)f1.0   null<2>:w     r24.0<1;1,0>:b                   {I@1}                //  ALU pipe: int; $210
        or (32|M0)               r25.0<1>:d    r16.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $209
(f1.0)  sel (32|M0)              r29.0<1>:d    r25.0<1;1,0>:d    r16.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $212
        mov (32|M0)              r31.0<1>:f    r29.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $213
        shl (32|M0)              r27.0<1>:d    r22.0<1;1,0>:ud   16:w               {$5.dst}         //  ALU pipe: int; $215
        mul (32|M0)              acc0.0<1>:f   r73.0<1;1,0>:f    r31.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $214
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r27.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $216
        add (32|M0)              r59.0<1>:f    r59.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $217
(f3.0)  goto.b (32|M0)                       _L_k0_0_          _0_067                                //  ALU pipe: int; $220
// B022: [inDivergent],  Preds:{B021},  Succs:{B026}
_L_k0_0_:
        join (32|M0)                         _0_063                                                  // 
L2720:
        goto (32|M0)                         _0_063            _0_065                                // $221
// B023: [inDivergent],  Preds:{B018},  Succs:{B024, B026}
_0_063:
        join (32|M0)                         _0_065                                                  // 
L2752:
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r67.0<1;1,0>:ud   r71.0<1;1,0>:ud                     //  ALU pipe: int; $223
(~f3.0) goto (32|M0)                         _0_065            _0_065                                //  ALU pipe: int; $224
// B024: [inDivergent],  Preds:{B023},  Succs:{B025}
_0_068:
        mov (32|M0)              r61.0<1>:f    r67.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $226
// B025: [inDivergent],  Preds:{B025, B024},  Succs:{B026, B025}
_0_069:
        mov (16|M0)              r3.0<2>:ud    r61.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $229
        mov (16|M16)             r5.0<2>:ud    r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $229
        add (16|M0)              r9.0<1>:q     r56.1<0;1,0>:q    r3.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $229
        add (16|M16)             r11.0<1>:q    r56.1<0;1,0>:q    r5.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $229
        load.ugm.d8u32.a64 (32|M0)  r24:2       [r9:4]             {I@1,$6} // ex_desc:0x0; desc:0x8200980 // $231
        shr (16|M0)              r13.0<1>:uq   r3.0<2;1,0>:ud    2:w                                 //  ALU pipe: int; $233
        shr (16|M16)             r15.0<1>:uq   r5.0<2;1,0>:ud    2:w                                 //  ALU pipe: int; $233
        and (16|M0)              r26.0<1>:d    r13.0<2;1,0>:d    1073741820:d               {I@2}    //  ALU pipe: int; $234
        and (16|M16)             r27.0<1>:d    r15.0<2;1,0>:d    1073741820:d               {I@2}    //  ALU pipe: int; $235
        mov (32|M0)              r7.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $237
        mov (32|M0)              r34.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@2}      //  ALU pipe: float; $236
        shl (16|M0)              r17.0<1>:q    r3.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $245
        shl (16|M16)             r19.0<1>:q    r5.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $245
        mov (16|M0)              r21.1<2>:d    r7.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $240
        mov (16|M16)             r28.1<2>:d    r8.0<1;1,0>:d                                         //  ALU pipe: int; $241
        mov (16|M0)              r21.0<2>:d    r34.0<1;1,0>:d                   {F@1}                //  ALU pipe: int; $238
        mov (16|M16)             r28.0<2>:d    r35.0<1;1,0>:d                                        //  ALU pipe: int; $239
        add (16|M0)              r30.0<1>:q    r56.2<0;1,0>:q    r17.0<1;1,0>:q   {Compacted,I@6}    //  ALU pipe: int; $246
        add (16|M16)             r32.0<1>:q    r56.2<0;1,0>:q    r19.0<1;1,0>:q   {Compacted,I@6}    //  ALU pipe: int; $246
        add (16|M0)              r38.0<1>:q    r56.3<0;1,0>:q    r21.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $242
        add (16|M16)             r40.0<1>:q    r56.3<0;1,0>:q    r28.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $242
        load.ugm.d16u32.a64 (32|M0)  r36:2      [r30:4]            {I@3,$7} // ex_desc:0x0; desc:0x8200B80 // $248
        load.ugm.d32.a64 (32|M0)  r42:2         [r38:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $244
        add (32|M0)              r61.0<1>:d    r61.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $258
        mov (32|M0)              r44.0<1>:b    r24.0<4;1,0>:b                   {$6.dst}             //  ALU pipe: int; $232
        mov (32|M0)   (lt)f2.0   null<2>:w     r44.0<1;1,0>:b                   {I@1}                //  ALU pipe: int; $250
        or (32|M0)               r45.0<1>:d    r24.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $249
(f2.0)  sel (32|M0)              r49.0<1>:d    r45.0<1;1,0>:d    r24.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $252
        mov (32|M0)              r51.0<1>:f    r49.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $253
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r61.0<1;1,0>:ud   r71.0<1;1,0>:ud                     //  ALU pipe: int; $259
        shl (32|M0)              r47.0<1>:d    r36.0<1;1,0>:ud   16:w               {$7.dst}         //  ALU pipe: int; $255
        mul (32|M0)              acc0.0<1>:f   r42.0<1;1,0>:f    r51.0<1;1,0>:f   {Compacted,@1,$8.dst} //  ALU pipe: float; $254
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r47.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $256
        add (32|M0)              r59.0<1>:f    r59.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $257
(f1.0)  goto.b (32|M0)                       _0_065            _0_069                                //  ALU pipe: int; $260
// B026: [inDivergent],  Preds:{B025, B023, B022, B019},  Succs:{B027, B028}
_0_065:
        join (32|M0)                         _0_060                                                  // 
L3272:
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r65.0<1;1,0>:ud   r69.0<1;1,0>:ud                     //  ALU pipe: int; $262
(~f2.0) goto (32|M0)                         _0_060            _0_060                                //  ALU pipe: int; $263
// B027: [inDivergent],  Preds:{B026},  Succs:{B018}
_0_070:
        mov (32|M0)              r67.0<1>:f    r71.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $265
(W)     jmpi                                 _0_062                                                  // $266
// B028: [inDivergent],  Preds:{B026, B016},  Succs:{B029, B030}
_0_060:
        join (32|M0)                         _0_049                                                  // 
L3344:
        add (32|M0)              r61.0<1>:d    r63.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $268
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r61.0<1;1,0>:ud   r56.1<0;1,0>:ud  {I@1}              //  ALU pipe: int; $269
(f3.0)  goto (32|M0)                         _0_071            _0_071                                //  ALU pipe: int; $270
// B029: [inDivergent],  Preds:{B028},  Succs:{B031}
_0_072:
(W)     mov (1|M0)               r54.10<1>:d   -1:w                                                  //  ALU pipe: int; $272
(W)     mov (1|M0)               r54.22<1>:hf  0x1:hf                                                //  ALU pipe: float; $273
        goto (32|M0)                         _0_071            _0_049                                // $274
// B030: [inDivergent],  Preds:{B028},  Succs:{B016}
_0_071:
        join (32|M0)                         _0_049                                                  // 
L3448:
        mov (32|M0)              r63.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $276
(W)     jmpi                                 _0_059                                                  // $277
// B031: Preds:{B029, B014, B012, B010, B005},  Succs:{B032, B033}
_0_049:
        join (32|M0)                         L3488                                                   // 
L3488:
        add (32|M0)              r3.0<1>:d     r57.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $279
        and (32|M0)              r5.0<1>:d     r3.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $280
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $281
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $282
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0xEC0:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0127(r59.0:f); $283
        add (32|M0)              r10.0<1>:d    r57.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $292
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@4}                //  ALU pipe: int; $284
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $285
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0xEC0:uw                            //  ALU pipe: int; src1 is addr of V0127(r59.0:f); $286
        and (32|M0)   (eq)f2.0   null<1>:d     r57.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $288
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $293
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $287
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $294
(f2.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $290
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $295
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0x12C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0281(r75.0:f); $296
        add (32|M0)              r75.0<1>:f    r59.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $291
        add (32|M0)              r17.0<1>:d    r57.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $305
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $297
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $298
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0x12C0:uw                           //  ALU pipe: int; src1 is addr of V0281(r75.0:f); $299
        and (32|M0)   (eq)f1.0   null<1>:d     r57.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $301
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $306
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $300
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $307
(f1.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $303
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $308
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0x1340:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0289(r77.0:f); $309
        add (32|M0)              r77.0<1>:f    r75.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $304
        add (32|M0)              r24.0<1>:d    r57.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $318
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $310
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $311
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0x1340:uw                           //  ALU pipe: int; src1 is addr of V0289(r77.0:f); $312
        and (32|M0)   (eq)f3.0   null<1>:d     r57.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $314
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $319
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $313
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $320
(f3.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $316
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $321
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0x13C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0297(r79.0:f); $322
        add (32|M0)              r79.0<1>:f    r77.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $317
        add (32|M0)              r31.0<1>:d    r57.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $331
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $323
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $324
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0x13C0:uw                           //  ALU pipe: int; src1 is addr of V0297(r79.0:f); $325
        and (32|M0)   (eq)f2.0   null<1>:d     r57.0<1;1,0>:d    15:w                                //  ALU pipe: int; $327
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $332
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $326
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $333
        cmp (32|M0)   (eq)f1.0   null<2>:w     r55.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $340
(f2.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $329
(W)     mov (1|M0)               r36.0<1>:hf   0x1:hf                                                //  ALU pipe: float; $341
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $334
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0x1440:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0305(r81.0:f); $335
        add (32|M0)              r81.0<1>:f    r79.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $330
(f0.0)  sel (32|M0)              r37.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw              {F@2}           //  ALU pipe: int; $341
(f1.0)  sel (32|M0)              r38.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw                              //  ALU pipe: int; $341
        mov (16|M0)              r83.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $336
        and (32|M0)   (ne)f1.0   null<2>:uw    r37.0<1;1,0>:uw   r38.0<1;1,0>:uw  {I@2}              //  ALU pipe: int; $341
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $337
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0x1440:uw                           //  ALU pipe: int; src1 is addr of V0305(r81.0:f); $338
        mov (16|M16)             r84.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $339
(~f1.0) goto (32|M0)                         _0_073            _0_073                                //  ALU pipe: int; $342
// B032: [inDivergent],  Preds:{B031},  Succs:{B033}
_0_074:
        cmp (32|M0)   (eq)f3.0   null<2>:w     r55.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $344
(W)     shl (1|M0)               r5.0<1>:q     r54.1<0;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $349
(W)     cmp (32|M0)   (ne)f2.0   null<1>:d     r54.10<0;1,0>:d   0:w                                 //  ALU pipe: int; $347
(W)     and (1|M0)               r6.0<1>:d     r5.0<0;1,0>:d     -16:w               {Compacted,I@2} //  ALU pipe: int; $350
(W)     and (1|M0)               r6.1<1>:d     r5.1<0;1,0>:d     7:w                                 //  ALU pipe: int; $351
(f3.0)  sel (32|M0)              acc0.0<1>:f   r83.0<1;1,0>:f    0x80000000:f                        //  ALU pipe: float; $345
(W)     add (1|M0)               r7.0<1>:q     r6.0<0;1,0>:q     r2.4<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $352
        add (32|M0)              acc0.0<1>:f   r81.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $346
(W)     add (1|M0)               r8.0<1>:q     r7.0<0;1,0>:q     r5.0<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $353
(f2.0)  sel (32|M0)              r3.0<1>:f     acc0.0<1;1,0>:f   0x7FC00000:f                        //  ALU pipe: float; $348
        mov (16|M0)              r9.0<2>:f     r8.0<0;1,0>:f                    {I@1}                //  ALU pipe: float; $355
        mov (16|M16)             r11.0<2>:ud   r8.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $355
        mov (16|M0)              r9.1<2>:ud    r8.1<0;1,0>:ud                   {F@1}                //  ALU pipe: int; $356
        mov (16|M16)             r11.1<2>:ud   r8.1<0;1,0>:ud                                        //  ALU pipe: int; $356
        store.ugm.d32.a64 (32|M0)  [r9:4]       r3:2               {I@1,$9} // ex_desc:0x0; desc:0x8000584 // $357
// B033: Preds:{B032, B031},  Succs:{B034, B035}
_0_073:
        join (32|M0)                         L4592                                                   // 
L4592:
(W)     cmp (32|M0)   (ne)f2.0   null<1>:d     r54.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $359
(W&~f2.0) cmp (32|M0) (ne)f2.0   null<1>:d     r54.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $360
        bfn.(s0|s1|s2) (32|M0)   r3.0<1>:ud    r54.6<0;0>:ud     r57.0<1;0>:ud     r54.9<0>:ud      {$9.src} //  ALU pipe: int; $362
(f2.0)  cmp (32|M0)   (eq)f2.0   null<1>:d     r3.0<1;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $363
(W)     mov (1|M0)               r5.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $365
(f2.0)  sel (32|M0)              r6.0<1>:uw    r5.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $365
(f0.0)  sel (32|M0)              r7.0<1>:uw    r5.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $365
        and (32|M0)   (ne)f1.0   null<2>:uw    r6.0<1;1,0>:uw    r7.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $365
(~f1.0) goto (32|M0)                         _0_075            _0_075                                //  ALU pipe: int; $366
// B034: [inDivergent],  Preds:{B033},  Succs:{B035}
_0_076:
(W)     mov (1|M0)               r1.8<2>:b     r54.22<0;1,0>:w                                       //  ALU pipe: int; $368
(W)     mov (1|M0)               r3.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $371
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $369
(W)     shl (1|M0)               r7.0<1>:q     r54.7<0;1,0>:ud   2:w                                 //  ALU pipe: int; $374
(W)     cmp (32|M0)   (eq)f3.0   null<2>:w     r2.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $370
(W&f3.0) sel (1|M0)              r4.0<1>:d     r3.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $371
(W)     add (1|M0)               r8.0<1>:q     r7.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $375
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $372
(W)     store.ugm.d32x1t.a64 (1|M0)  [r8:1]     r6:1               {I@1,$10} // ex_desc:0x0; desc:0x2008584 // $377
// B035: Preds:{B034, B033},  Succs:{}
_0_075:
        join (32|M0)                         L4880                                                   // 
L4880:
(W)     mov (16|M0)              r127.0<1>:f   r53.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $379
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$11} // wr:1+0, rd:0; end of thread // $379
L4904:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x6:ud                                                // 


//.BankConflicts: 0
//.ByteRMWs: 2
//


//.numALUInst: 304
//.accSubDef: 10
//.accSubUse: 10
//.accSubCandidateDef: 10
//.accSubCandidateUse: 10
//
//
//.singlePipeAtOneDistNum: 67
//.allAtOneDistNum: 9
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 9
//.AfterReadTokenDepCount: 1
