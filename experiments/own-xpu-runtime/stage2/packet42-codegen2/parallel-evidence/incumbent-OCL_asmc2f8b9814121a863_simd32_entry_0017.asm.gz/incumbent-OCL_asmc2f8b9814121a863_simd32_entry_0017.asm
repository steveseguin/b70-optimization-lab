//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE8ELj6144ELj4ELj4ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 17 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 17 -GRFBumpUpNumber 2 "
//.instCount 465
//.RA type	LOCAL_FIRST_FIT_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r38.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.12)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.13)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r38.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r38.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.3)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.6)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.8)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.12)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r39.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=32 words (r2.4)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r40.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=32 words (r38.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r39.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0068 (78)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r39.8)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r39.2)
//.declare V0071 (81)  rf=r size=8 type=d alias=V0069+0 align=4 words (r39.4)
//.declare V0072 (82)  rf=r size=8 type=q align=4 words (r39.3)
//.declare V0073 (83)  rf=r size=8 type=uq alias=V0069+0 align=4 words (r39.2)
//.declare V0074 (84)  rf=r size=8 type=uq alias=V0072+0 align=4 words (r39.3)
//.declare V0075 (85)  rf=r size=8 type=d align=2 words (r39.8)
//.declare V0076 (86)  rf=r size=8 type=d alias=V0072+0 align=4 words (r39.6)
//.declare V0077 (87)  rf=r size=2 type=w align=1 words (r3.2)
//.declare V0078 (88)  rf=r size=2 type=w align=1 words (r39.5)
//.declare P01 (89)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0080 (91)  rf=r size=4 type=f align=2 words (r1.0)
//.declare V0081 (92)  rf=r size=4 type=ud alias=V0050+0 align=32 words (r2.14)
//.declare V0082 (93)  rf=r size=4 type=f align=2 words (r2.2)
//.declare V0083 (94)  rf=r size=8 type=df align=4 words (r3.1)
//.declare V0084 (95)  rf=r size=8 type=df align=4 words (r4.0)
//.declare V0085 (96)  rf=r size=8 type=df align=4 words (r4.1)
//.declare V0086 (97)  rf=r size=8 type=df align=4 words (r3.2)
//.declare V0087 (98)  rf=r size=8 type=df align=4 words (r5.0)
//.declare V0089 (100)  rf=r size=8 type=df align=4 words (r6.0)
//.declare V0091 (102)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0093 (104)  rf=r size=4 type=ud alias=V0091+0 align=2 words (r6.2)
//.declare V0094 (105)  rf=r size=8 type=df align=4 words (r6.2)
//.declare V0095 (106)  rf=r size=8 type=df align=4 words (r7.0)
//.declare V0096 (107)  rf=r size=4 type=d align=4 words (r8.0)
//.declare V0097 (108)  rf=r size=4 type=ud alias=V0096+0 align=2 words (r8.0)
//.declare V0098 (109)  rf=r size=4 type=d align=32 words (r1.0)
//.declare V0099 (110)  rf=r size=4 type=d align=2 words (r1.1)
//.declare V0101 (112)  rf=r size=8 type=df align=4 words (r2.1)
//.declare V0102 (113)  rf=r size=4 type=ud alias=V0099+0 align=2 words (r1.1)
//.declare V0103 (114)  rf=r size=8 type=df align=4 words (r2.4)
//.declare V0105 (116)  rf=r size=8 type=df align=4 words (r8.1)
//.declare V0106 (117)  rf=r size=8 type=df align=4 words (r3.1)
//.declare V0107 (118)  rf=r size=8 type=df align=4 words (r4.0)
//.declare V0108 (119)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0109 (120)  rf=r size=8 type=uq alias=V0108+0 align=4 words (r5.0)
//.declare V0110 (121)  rf=r size=4 type=d align=2 words (r5.2)
//.declare V0111 (122)  rf=r size=8 type=d alias=V0108+0 align=4 words (r5.0)
//.declare P02 (124)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0113 (125)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0114 (126)  rf=r size=4 type=d align=2 words (r5.3)
//.declare V0115 (127)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0117 (129)  rf=r size=8 type=q align=4 words (r7.1)
//.declare V0118 (130)  rf=r size=8 type=d alias=V0117+0 align=4 words (r7.2)
//.declare V0119 (131)  rf=r size=8 type=q align=4 words (r9.0)
//.declare V0121 (133)  rf=r size=8 type=q align=4 words (r9.1)
//.declare V0122 (134)  rf=r size=8 type=d alias=V0121+0 align=4 words (r9.2)
//.declare V0123 (135)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0124 (136)  rf=r size=4 type=ud alias=V0110+0 align=2 words (r5.2)
//.declare V0125 (137)  rf=r size=8 type=ud alias=V0123+0 align=4 words (r2.2)
//.declare V0126 (138)  rf=r size=8 type=d alias=V0123+0 align=4 words (r2.2)
//.declare V0127 (139)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0129 (141)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0130 (142)  rf=r size=8 type=d align=2 words (r3.1)
//.declare V0131 (143)  rf=r size=8 type=d alias=V0129+0 align=4 words (r1.0)
//.declare V0132 (144)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0133 (145)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0134 (146)  rf=r size=8 type=q align=4 words (r7.0)
//.declare P03 (147)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0135 (148)  rf=r size=8 type=ud alias=V0130+0 align=2 words (r3.1)
//.declare P04 (149)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P05 (150)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0136 (151)  rf=r size=8 type=q align=4 words (r10.0)
//.declare V0137 (152)  rf=r size=8 type=q align=4 words (r7.1)
//.declare V0138 (153)  rf=r size=8 type=d alias=V0137+0 align=4 words (r7.2)
//.declare V0139 (154)  rf=r size=8 type=q align=4 words (r39.5)
//.declare P06 (155)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0140 (156)  rf=r size=4 type=d align=2 words (r39.3)
//.declare V0141 (157)  rf=r size=4 type=d align=4 words (r1.0)
//.declare V0142 (158)  rf=r size=4 type=f align=2 words (r2.2)
//.declare V0143 (159)  rf=r size=4 type=d align=2 words (r1.1)
//.declare V0144 (160)  rf=r size=4 type=ud alias=V0143+0 align=2 words (r1.1)
//.declare V0145 (161)  rf=r size=4 type=d alias=+0 align=2 words (r2.8)
//.declare V0146 (162)  rf=r size=4 type=f align=2 words (r2.3)
//.declare V0147 (163)  rf=r size=4 type=ud alias=V0141+0 align=2 words (r1.0)
//.declare V0148 (164)  rf=r size=4 type=f align=2 words (r2.10)
//.declare V0149 (165)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0150 (166)  rf=r size=4 type=f align=2 words (r4.1)
//.declare V0151 (167)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0152 (168)  rf=r size=4 type=ud alias=V0151+0 align=2 words (r4.2)
//.declare V0153 (169)  rf=r size=4 type=d alias=+4 align=2 words (r2.9)
//.declare V0154 (170)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0155 (171)  rf=r size=4 type=ud alias=V0154+0 align=2 words (r5.0)
//.declare V0156 (172)  rf=r size=4 type=f alias=+0 align=2 words (r6.0)
//.declare V0157 (173)  rf=r size=4 type=ud alias=V0145+0 align=2 words (r2.8)
//.declare V0158 (174)  rf=r size=4 type=f alias=+4 align=2 words (r6.1)
//.declare V0159 (175)  rf=r size=4 type=ud alias=V0153+0 align=2 words (r2.9)
//.declare V0160 (176)  rf=r size=4 type=f align=2 words (r5.1)
//.declare V0162 (178)  rf=r size=4 type=f align=2 words (r1.1)
//.declare V0164 (180)  rf=r size=4 type=f align=2 words (r1.4)
//.declare V0165 (181)  rf=r size=4 type=f align=2 words (r7.0)
//.declare V0166 (182)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0167 (183)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0168 (184)  rf=r size=4 type=ud alias=V0167+0 align=2 words (r3.1)
//.declare V0169 (185)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0170 (186)  rf=r size=4 type=d align=32 words (r9.0)
//.declare V0171 (187)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0172 (188)  rf=r size=4 type=d align=2 words (r12.0)
//.declare V0173 (189)  rf=r size=4 type=ud alias=V0171+0 align=2 words (r10.0)
//.declare V0174 (190)  rf=r size=4 type=ud alias=V0172+0 align=2 words (r12.0)
//.declare  (191)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare V0175 (192)  rf=r size=4 type=ud alias=V0140+0 align=2 words (r39.3)
//.declare V0176 (193)  rf=r size=8 type=d align=2 words (r39.12)
//.declare V0177 (194)  rf=r size=8 type=d alias=V0139+0 align=4 words (r39.10)
//.declare V0178 (195)  rf=r size=4 type=d align=32 words (r41.0)
//.declare V0179 (196)  rf=r size=4 type=d align=2 words (r39.14)
//.declare V0180 (197)  rf=r size=4 type=ud alias=V0178+0 align=2 words (r41.0)
//.declare V0181 (198)  rf=r size=8 type=ud alias=V0176+0 align=2 words (r39.12)
//.declare V0182 (199)  rf=r size=4 type=d align=32 words (r1.0)
//.declare V0184 (201)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0185 (202)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0187 (204)  rf=r size=4 type=ud alias=V0185+0 align=2 words (r5.0)
//.declare V0188 (205)  rf=r size=4 type=ud alias=V0051+0 align=32 words (r2.15)
//.declare V0189 (206)  rf=r size=4 type=d align=32 words (r6.0)
//.declare P07 (209)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0192 (210)  rf=r size=8 type=ud alias=V0075+0 align=2 words (r39.8)
//.declare P08 (211)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P09 (212)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0194 (214)  rf=r size=2 type=b align=1 words (r2.8)
//.declare V0195 (215)  rf=r size=4 type=d align=2 words (r39.15)
//.declare V0196 (216)  rf=r size=2 type=ub alias=V0194+0 align=1 words (r2.8)
//.declare V0197 (217)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0198 (218)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r40.0)
//.declare P10 (219)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P11 (220)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P12 (221)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0199 (222)  rf=r size=4 type=d align=2 words (r41.1)
//.declare V0200 (223)  rf=r size=2 type=w align=1 words (r41.4)
//.declare V0201 (224)  rf=r size=128 type=f align=32 words (r44.0)
//.declare P13 (225)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P14 (226)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0202 (227)  rf=r size=4 type=d alias=+0 align=2 words (r46.4)
//.declare V0203 (228)  rf=r size=4 type=d alias=+4 align=2 words (r46.5)
//.declare V0204 (229)  rf=r size=4 type=d align=2 words (r41.3)
//.declare V0205 (230)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0206 (231)  rf=r size=8 type=ud alias=V0205+0 align=4 words (r1.0)
//.declare V0207 (232)  rf=r size=8 type=d alias=V0205+0 align=4 words (r1.0)
//.declare V0208 (233)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0212 (237)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0213 (238)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P15 (239)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0214 (240)  rf=r size=4 type=ud alias=V0203+0 align=2 words (r46.5)
//.declare P16 (241)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0215 (242)  rf=r size=4 type=ud alias=V0202+0 align=2 words (r46.4)
//.declare V0216 (243)  rf=r size=4 type=ud alias=V0052+0 align=32 words (r3.0)
//.declare V0218 (245)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0219 (246)  rf=r size=8 type=d alias=V0218+0 align=4 words (r1.0)
//.declare V0220 (247)  rf=r size=8 type=q align=4 words (r41.2)
//.declare V0222 (249)  rf=r size=4 type=d align=2 words (r2.2)
//.declare P17 (250)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0223 (251)  rf=r size=4 type=ud alias=V0204+0 align=2 words (r41.3)
//.declare P18 (252)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0224 (253)  rf=r size=4 type=ud alias=V0222+0 align=2 words (r2.2)
//.declare P19 (254)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P20 (256)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0226 (257)  rf=r size=8 type=d align=2 words (r1.0)
//.declare V0227 (258)  rf=r size=8 type=d alias=V0049+0 align=32 words (r2.12)
//.declare V0228 (259)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0229 (260)  rf=r size=8 type=ud alias=V0228+0 align=4 words (r1.4)
//.declare V0230 (261)  rf=r size=8 type=d alias=V0228+0 align=4 words (r1.4)
//.declare V0231 (262)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0234 (265)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0235 (266)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0236 (267)  rf=r size=8 type=d align=2 words (r6.0)
//.declare V0237 (268)  rf=r size=8 type=d alias=V0235+0 align=4 words (r3.2)
//.declare V0238 (269)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0239 (270)  rf=r size=4 type=d align=2 words (r41.6)
//.declare V0240 (271)  rf=r size=4 type=d align=32 words (r46.0)
//.declare V0241 (272)  rf=r size=4 type=d align=2 words (r41.7)
//.declare V0242 (273)  rf=r size=4 type=ud alias=V0240+0 align=2 words (r46.0)
//.declare V0243 (274)  rf=r size=8 type=ud alias=V0236+0 align=2 words (r6.0)
//.declare V0244 (275)  rf=r size=8 type=ud alias=V0226+0 align=2 words (r1.0)
//.declare V0245 (276)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0247 (278)  rf=r size=4 type=d align=32 words (r7.0)
//.declare V0248 (279)  rf=r size=4 type=d align=2 words (r41.8)
//.declare V0249 (280)  rf=r size=4 type=d align=2 words (r41.9)
//.declare V0250 (281)  rf=r size=4 type=ud alias=V0248+0 align=2 words (r41.8)
//.declare V0251 (282)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0254 (285)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0255 (286)  rf=r size=128 type=d align=32 words (r48.0)
//.declare P21 (287)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0256 (288)  rf=r size=128 type=ud alias=V0255+0 align=32 words (r48.0)
//.declare V0257 (289)  rf=r size=4 type=ud alias=V0239+0 align=2 words (r41.6)
//.declare V0259 (291)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0260 (292)  rf=r size=8 type=d alias=V0259+0 align=4 words (r1.0)
//.declare V0261 (293)  rf=r size=8 type=q align=4 words (r41.5)
//.declare V0263 (295)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0264 (296)  rf=r size=8 type=d alias=V0263+0 align=4 words (r2.2)
//.declare V0265 (297)  rf=r size=8 type=q align=4 words (r41.6)
//.declare V0266 (298)  rf=r size=8 type=q align=4 words (r41.7)
//.declare V0267 (299)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0268 (300)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0269 (301)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0270 (302)  rf=r size=128 type=ud alias=V0268+0 align=32 words (r4.0)
//.declare V0271 (303)  rf=r size=128 type=ud alias=V0269+0 align=32 words (r52.0)
//.declare P22 (304)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0272 (305)  rf=r size=128 type=ud alias=V0267+0 align=32 words (r50.0)
//.declare V0273 (306)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0274 (307)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0275 (308)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0276 (309)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0277 (310)  rf=r size=128 type=ud alias=V0275+0 align=32 words (r56.0)
//.declare V0278 (311)  rf=r size=128 type=ud alias=V0276+0 align=32 words (r58.0)
//.declare V0279 (312)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0280 (313)  rf=r size=128 type=ud alias=V0273+0 align=32 words (r54.0)
//.declare V0281 (314)  rf=r size=128 type=ud alias=V0279+0 align=32 words (r6.0)
//.declare V0282 (315)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0284 (317)  rf=r size=128 type=ud alias=V0282+0 align=32 words (r8.0)
//.declare V0287 (320)  rf=r size=256 type=uq align=32 words (r12.0)
//.declare V0288 (321)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0289 (322)  rf=r size=128 type=d align=32 words (r18.0)
//.declare P23 (323)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P24 (324)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0293 (328)  rf=r size=256 type=uq align=32 words (r8.0)
//.declare V0294 (329)  rf=r size=32 type=b align=32 words (r24.0)
//.declare V0295 (330)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0296 (331)  rf=r size=128 type=b alias=V0295+0 align=32 words (r16.0)
//.declare V0300 (335)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare V0302 (337)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare V0303 (338)  rf=r size=128 type=w alias=V0302+0 align=32 words (r22.0)
//.declare V0305 (340)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0306 (341)  rf=r size=128 type=d align=32 words (r26.0)
//.declare P25 (343)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0308 (344)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0310 (346)  rf=r size=128 type=f alias=V0288+0 align=32 words (r60.0)
//.declare V0312 (348)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0314 (350)  rf=r size=128 type=f alias=V0312+0 align=32 words (r28.0)
//.declare P26 (351)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P27 (352)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0318 (356)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0319 (357)  rf=r size=32 type=b align=32 words (r12.0)
//.declare V0320 (358)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0321 (359)  rf=r size=128 type=b alias=V0320+0 align=32 words (r24.0)
//.declare V0325 (363)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0332 (370)  rf=r size=256 type=uq align=32 words (r4.0)
//.declare V0333 (371)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0337 (375)  rf=r size=256 type=uq align=32 words (r30.0)
//.declare V0339 (377)  rf=r size=128 type=ud align=32 words (r36.0)
//.declare V0340 (378)  rf=r size=128 type=w alias=V0339+0 align=32 words (r36.0)
//.declare V0342 (380)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0343 (381)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P28 (383)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0345 (384)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0348 (387)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0350 (389)  rf=r size=128 type=f alias=V0348+0 align=32 words (r8.0)
//.declare P29 (390)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P30 (391)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P31 (392)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0351 (393)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0352 (394)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0353 (395)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0354 (396)  rf=r size=128 type=uw alias=V0352+0 align=32 words (r6.0)
//.declare V0355 (397)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare A00 (398)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P32 (399)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0358 (402)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0359 (403)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0360 (404)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0361 (405)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0362 (406)  rf=r size=128 type=uw alias=V0360+0 align=32 words (r4.0)
//.declare V0363 (407)  rf=r size=64 type=uw align=32 words (r9.0)
//.declare A01 (408)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P33 (409)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0366 (412)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0367 (413)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0368 (414)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0369 (415)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0370 (416)  rf=r size=128 type=uw alias=V0368+0 align=32 words (r12.0)
//.declare V0371 (417)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare A02 (418)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P34 (419)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0374 (422)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0375 (423)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0376 (424)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0377 (425)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0378 (426)  rf=r size=128 type=uw alias=V0376+0 align=32 words (r10.0)
//.declare V0379 (427)  rf=r size=64 type=uw align=32 words (r9.0)
//.declare A03 (428)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P35 (429)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0382 (432)  rf=r size=128 type=f align=32 words (r68.0)
//.declare V0383 (433)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0384 (434)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0385 (435)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0386 (436)  rf=r size=128 type=uw alias=V0384+0 align=32 words (r6.0)
//.declare V0387 (437)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare A04 (438)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P36 (439)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P37 (440)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0388 (441)  rf=r size=4 type=d align=2 words (r46.1)
//.declare P38 (442)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P39 (443)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P40 (444)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P41 (447)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0391 (448)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0392 (449)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0393 (450)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0394 (451)  rf=r size=4 type=d align=2 words (r2.2)
//.declare V0395 (452)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0396 (453)  rf=r size=4 type=ud alias=V0395+0 align=32 words (r6.0)
//.declare V0397 (454)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (455)  rf=r size=64 type=ud align=32 words (r4.0)
//.declare  (456)  rf=r size=32 type=ud align=32 words (r5.0)
//.declare P42 (457)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P43 (458)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0398 (459)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0399 (460)  rf=r size=4 type=ud alias=V0398+0 align=2 words (r1.0)
//.declare V0400 (461)  rf=r size=8 type=f align=32 words (r7.0)
//.declare V0401 (462)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare V0402 (463)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0403 (464)  rf=r size=4 type=ud alias=V0402+0 align=32 words (r5.0)
//.declare V0404 (465)  rf=r size=4 type=f align=32 words (r8.0)
//.declare V0405 (466)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0406 (467)  rf=r size=4 type=ud alias=V0405+0 align=32 words (r6.0)
//.declare V0407 (468)  rf=r size=4 type=f align=32 words (r9.0)
//.declare V0408 (469)  rf=r size=4 type=f align=2 words (r2.2)
//.declare V0409 (470)  rf=r size=4 type=f align=2 words (r2.3)
//.declare V0410 (471)  rf=r size=4 type=f align=2 words (r47.0)
//.declare V0411 (472)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0412 (473)  rf=r size=4 type=d alias=V0410+0 align=2 words (r47.0)
//.declare P44 (474)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0413 (475)  rf=r size=4 type=ud alias=V0411+0 align=2 words (r3.1)
//.declare V0414 (476)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0415 (477)  rf=r size=4 type=ud alias=V0410+0 align=2 words (r47.0)
//.declare V0416 (478)  rf=r size=4 type=ud alias=V0414+0 align=2 words (r1.0)
//.declare V0417 (479)  rf=r size=4 type=d align=2 words (r2.2)
//.declare V0418 (480)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0419 (481)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0420 (482)  rf=r size=4 type=ud alias=V0418+0 align=2 words (r3.1)
//.declare V0421 (483)  rf=r size=4 type=ud alias=V0419+0 align=2 words (r4.0)
//.declare V0422 (484)  rf=r size=2 type=w align=32 words (r72.0)
//.declare V0423 (485)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0424 (486)  rf=r size=4 type=ud alias=V0423+0 align=2 words (r1.0)
//.declare V0426 (488)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0429 (491)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0430 (492)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare V0431 (493)  rf=r size=2 type=uw alias=V0422+0 align=32 words (r72.0)
//.declare P45 (494)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P46 (495)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P47 (496)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P48 (497)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P49 (498)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P50 (499)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P51 (500)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0432 (501)  rf=r size=2 type=b align=1 words (r1.0)
//.declare V0433 (502)  rf=r size=2 type=w align=1 words (r2.4)
//.declare V0434 (503)  rf=r size=2 type=ub alias=V0432+0 align=1 words (r1.0)
//.declare P52 (504)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0435 (505)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0436 (506)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0437 (507)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0438 (508)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0439 (509)  rf=r size=8 type=d alias=V0438+0 align=4 words (r5.2)
//.declare V0440 (510)  rf=r size=8 type=d alias=V0437+0 align=4 words (r5.0)
//.declare V0443 (513)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0444 (514)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare  (515)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (516)  rf=r size=4 type=d alias=V0072+0 align=2 words (r39.6)
//.declare  (517)  rf=r size=4 type=d alias=V0220+0 align=2 words (r41.4)
//.declare  (518)  rf=r size=2 type=w alias=V0423+0 align=1 words (r1.0)
//.declare  (519)  rf=r size=8 type=f align=8 words (r6.0)
//.declare  (520)  rf=r size=8 type=ud align=8 words (r2.8)
//.declare  (521)  rf=r size=8 type=d align=8 words (r46.4)
//.declare  (522)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (523)  rf=r size=64 type=uw align=32 words (r5.0)
//.declare  (524)  rf=r size=64 type=uw align=32 words (r9.0)
//.declare  (525)  rf=r size=64 type=uw align=32 words (r10.0)
//.declare  (526)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (527)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare  (528)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (529)  rf=r size=64 type=uw align=32 words (r5.0)
//.declare  (530)  rf=r size=2 type=w align=1 words (r1.8)
//.declare  (531)  rf=r size=2 type=w align=1 words (r4.0)
//.declare  (532)  rf=r size=8 type=df align=4 words (r4.2)
//.declare  (533)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (534)  rf=r size=4 type=f align=2 words (r3.1)
//.declare  (535)  rf=r size=4 type=ud align=2 words (r3.1)
//.declare  (536)  rf=r size=2 type=w align=1 words (r1.0)
//.declare  (537)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (538)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (539)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (540)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (541)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (544)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (545)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (550)  rf=r size=2 type=uw align=1 words (r1.0)
//.declare  (554)  rf=r size=2 type=uw align=1 words (r1.0)
//.declare  (556)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare  (557)  rf=r size=2 type=uw align=1 words (r2.4)
//.declare  (559)  rf=r size=2 type=w align=1 words (r3.2)
//.declare  (568)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (569)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (576)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (577)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (578)  rf=r size=128 type=d align=32 words (r34.0)
//.declare  (579)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (580)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (581)  rf=r size=128 type=q align=32 words (r28.0)
//.declare  (584)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (585)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (588)  rf=r size=128 type=uq alias=+0 align=32 words (r14.0)
//.declare  (589)  rf=r size=128 type=uq alias=+0 align=32 words (r16.0)
//.declare  (590)  rf=r size=128 type=d alias=+0 align=32 words (r14.0)
//.declare  (591)  rf=r size=128 type=d alias=+0 align=32 words (r16.0)
//.declare  (592)  rf=r size=128 type=d alias=+0 align=32 words (r22.0)
//.declare  (593)  rf=r size=128 type=d alias=+0 align=32 words (r28.0)
//.declare r0 (594)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (595)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (596)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (597)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0444    | :ud      |    0x4 | r1       | inline+0x0       |
// | V0040    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0041    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0042    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0043    | :q       |    0x8 | r2       | cti+0x20         |
// | V0044    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0045    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0046    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0047    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0048    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0049    | :q       |    0x8 | r2+0x30  | cti+0x50         |
// | V0050    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0051    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0052    | :d       |    0x4 | r3       | cti+0x60         |
// | V0053    | :d       |    0x4 | r3+0x4   | cti+0x64         |
// | V0054    | :b       |    0x1 | r3+0x8   | cti+0x68         |
// | V0055    | :b       |    0x1 | r3+0xC   | cti+0x6C         |
// | V0037    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// | V0038    | :uq      |    0x8 | r3+0x18  | cti+0x78         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r38.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r39.8<2>:b    r38.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     shl (1|M0)               r1.0<1>:q     r38.1<0;1,0>:ud   4:w                                 //  ALU pipe: int; $9
(W)     mov (1|M0)               r1.8<1>:w     r39.8<0;1,0>:ub                  {I@2}                //  ALU pipe: int; $10
(W)     mov (8|M0)               r40.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.1<1>:q     r1.8<0;1,0>:w                    {@2,$0.dst}          //  ALU pipe: int; $10
(W)     add (8|M0)               r40.8<1>:w    r40.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $5
(W)     add (1|M0)               r39.2<1>:q    r1.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $11
(W)     mov (1|M0)               r3.2<1>:w     r39.8<0;1,0>:b                   {$1.dst}             //  ALU pipe: int; $15
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r39.5<0;1,0>:ud   0x4:uw              {I@2}           //  ALU pipe: int; $17
(W)     shr (1|M0)               r39.3<1>:uq   r39.2<0;1,0>:uq   2:w                                 //  ALU pipe: int; $13
(W)     add (16|M0)              r40.16<1>:w   r40.0<1;1,0>:w    16:w                                //  ALU pipe: int; $6
(W)     mov (2|M0)               r39.0<1>:d    r2.4<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     and (1|M0)               r39.5<1>:w    r3.2<0;1,0>:w     3:w               {I@5}             //  ALU pipe: int; $16
(W)     mov (2|M0)               r39.8<1>:d    r39.6<1;1,0>:d                   {I@4}                //  ALU pipe: int; $14
(W&f3.0) jmpi                                _0_053                                                  //  ALU pipe: int; $18
// B002: Preds:{B001},  Succs:{B007}
_0_054:
(W)     mov (1|M0)               r1.0<1>:f     r2.14<0;1,0>:ud                                       //  ALU pipe: float; $20
(W)     mov (1|M0)               r3.1<1>:df    r2.14<0;1,0>:ud                                       //  ALU pipe: long; $22
(W)     math.inv (1|M0)          r2.2<1>:f     r1.0<0;1,0>:f                    {F@1}                //  ALU pipe: math; $21
(W)     mov (1|M0)               r3.2<1>:df    0x3FF0000000000000:df                                 //  ALU pipe: long; $24
(W)     mov (1|M0)               r4.0<1>:df    r2.2<0;1,0>:f                    {M@1}                //  ALU pipe: long; $23
(W)     mov (1|M0)               r4.2<1>:df    0xBCF0000000000000:df                                 //  ALU pipe: long; $27
(W)     mad (1|M0)               r4.1<1>:df    r3.2<0;0>:df      r4.0<0;0>:df      -r3.1<0>:df      {L@2} //  ALU pipe: long; $25
(W)     shr (1|M0)               r6.2<1>:ud    r39.5<0;1,0>:ud   2:w                                 //  ALU pipe: int; $30
(W)     add (1|M0)               r5.0<1>:df    r4.1<0;1,0>:df    r4.2<0;1,0>:df   {Compacted,L@1}    //  ALU pipe: long; $27
(W)     mov (1|M0)               r6.2<1>:df    r6.2<0;1,0>:ud                   {I@1}                //  ALU pipe: long; $31
(W)     mad (1|M0)               r6.0<1>:df    r4.0<0;0>:df      r5.0<0;0>:df      r4.0<0>:df       {L@2} //  ALU pipe: long; $28
(W)     mov (1|M0)               r2.4<1>:df    r39.6<0;1,0>:ud                                       //  ALU pipe: long; $38
(W)     mul (1|M0)               r7.0<1>:df    r6.0<0;1,0>:df    r6.2<0;1,0>:df   {Compacted,L@2}    //  ALU pipe: long; $32
(W)     mov (1|M0)               r3.1<1>:df    0x41F0000000000000:df                                 //  ALU pipe: long; $39
(W)     mov (1|M0)               r8.0<2>:ud    r7.0<0;1,0>:df                   {L@2}                //  ALU pipe: int; $33
(W)     mov (1|M0)               r7.2<1>:d     r39.8<0;1,0>:d                                        //  ALU pipe: int; $49
(W)     mul (1|M0)               acc0.0<1>:d   r8.0<0;1,0>:d     r2.28<0;1,0>:uw  {I@2}              //  ALU pipe: int; $34
(W)     macl (1|M0)              r1.0<1>:d     r8.0<0;1,0>:d     r2.14<0;1,0>:d   {Compacted}        //  ALU pipe: int; $35
(W)     mov (1|M0)               r7.3<1>:d     0:w                                                   //  ALU pipe: int; $50
(W)     add (1|M0)               r1.1<1>:d     r6.2<0;1,0>:d     -r1.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $35
(W)     mov (1|M0)               r9.3<1>:d     0:w                                                   //  ALU pipe: int; $55
(W)     mov (1|M0)               r2.1<1>:df    r1.1<0;1,0>:ud                   {I@2}                //  ALU pipe: long; $37
(W)     mad (1|M0)               r8.1<1>:df    r2.4<0;0>:df      r3.1<0;0>:df      r2.1<0>:df       {L@1} //  ALU pipe: long; $40
(W)     mul (1|M0)               r4.0<1>:df    r6.0<0;1,0>:df    r8.1<0;1,0>:df   {Compacted,L@1}    //  ALU pipe: long; $41
(W)     mov (1|M0)               r5.0<1>:uq    r4.0<0;1,0>:df                   {L@1}                //  ALU pipe: int; $42
(W)     cmp (1|M0)    (eq)f2.0   null<1>:d     r5.1<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $45
(W)     mov (1|M0)               r5.2<1>:d     r5.0<0;1,0>:d                    {Compacted}          //  ALU pipe: int; $43
(W)     add (1|M0)               r3.3<1>:d     r5.1<0;1,0>:d     r8.0<0;1,0>:d                       //  ALU pipe: int; $66
(W)     mul (1|M0)               acc0.0<1>:ud  r5.2<0;1,0>:ud    r2.28<0;1,0>:uw  {I@2}              //  ALU pipe: int; $58
(W&~f2.0) sel (1|M0)             r10.0<1>:d    r2.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $46
(W)     macl (1|M0)              r4.0<1>:ud    r5.2<0;1,0>:ud    r2.14<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $59
(W)     add3 (1|M0)              r5.3<1>:d     r6.2<0;0>:d       -r1.0<0;0>:d      -r10.0<0>:d      {I@2} //  ALU pipe: int; $47
(W)     mul (1|M0)               acc0.0<1>:ud  r5.2<0;1,0>:ud    r2.28<0;1,0>:uw                     //  ALU pipe: int; $59
(W)     shl (1|M0)               r7.0<1>:q     r5.3<0;1,0>:d     32:w               {I@2}            //  ALU pipe: int; $48
(W)     mach (1|M0)              r11.0<1>:d    r5.2<0;1,0>:ud    r2.14<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r2.2<2>:ud    r4.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $59
(W)     add (1|M0)               r9.0<1>:q     r7.0<0;1,0>:q     r7.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $53
(W)     mov (1|M0)               r2.3<2>:d     r11.0<0;1,0>:d                   {I@3}                //  ALU pipe: int; $63
(W)     mov (1|M0)               r4.0<1>:hf    0xFFFF:hf                              {I@3}          //  ALU pipe: float; $74
(W)     add (1|M0)               r1.0<1>:q     r9.0<0;1,0>:q     -r2.1<0;1,0>:q   {I@1}              //  ALU pipe: int; $64
(W)     mov (1|M0)               r9.2<1>:d     r5.2<0;1,0>:d                                         //  ALU pipe: int; $54
(W)     mov (2|M0)               r3.1<1>:d     r1.0<1;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $65
(W)     shl (1|M0)               r6.0<1>:q     r3.3<0;1,0>:d     32:w                                //  ALU pipe: int; $67
(W)     cmp (32|M0)   (ge)f1.0   null<1>:ud    r3.1<0;1,0>:ud    r2.14<0;1,0>:ud  {I@2}              //  ALU pipe: int; $69
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $70
(W&~f1.0) cmp (32|M0) (gt)f1.0   null<1>:ud    r3.2<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $72
(W&f1.0) sel (1|M0)              r7.2<1>:d     r4.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $74
(W)     add (1|M0)               r7.0<1>:q     r6.0<0;1,0>:q     r9.1<0;1,0>:q    {Compacted,I@5}    //  ALU pipe: int; $68
(W)     mov (1|M0)               r10.0<1>:q    r7.2<0;1,0>:d                    {I@2}                //  ALU pipe: int; $75
(W)     add (1|M0)               r39.5<1>:q    r7.0<0;1,0>:q     -r10.0<0;1,0>:q  {I@1}              //  ALU pipe: int; $76
(W)     jmpi                                 _0_055                                                  // $77
// B003: Preds:{B001},  Succs:{B004, B005}
_0_053:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r2.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $79
(W&~f1.0) jmpi                               _0_056                                                  //  ALU pipe: int; $80
// B004: Preds:{B003},  Succs:{B006}
_0_057:
(W)     mov (1|M0)               r39.3<1>:d    -1:w                                                  //  ALU pipe: int; $82
(W)     jmpi                                 _0_058                                                  // $83
// B005: Preds:{B003},  Succs:{B006}
_0_056:
(W)     mov (1|M0)               r1.0<2>:d     r39.3<0;1,0>:q                                        //  ALU pipe: int; $85
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $86
(W)     mov (1|M0)               r2.2<1>:f     r2.14<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $87
(W)     mov (1|M0)               r3.1<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $92
(W)     math.inv (1|M0)          r2.10<1>:f    r2.2<0;1,0>:f                    {F@2}                //  ALU pipe: math; $91
(W)     mov (1|M0)               r2.3<1>:f     r1.0<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $90
(W)     mad (1|M0)               r4.0<1>:f     r2.10<0;0>:f      r3.1<0;0>:f       r2.10<0>:f       {A@1} //  ALU pipe: float; $92
(W)     mov (1|M0)               r1.1<1>:ud    r2.2<0;1,0>:f                                         //  ALU pipe: int; $88
(W)     mov (1|M0)               r4.2<1>:ud    r2.3<0;1,0>:f                    {F@2}                //  ALU pipe: int; $94
(W)     mul (1|M0)               r4.1<1>:f     r2.3<0;1,0>:f     r4.0<0;1,0>:f    {F@1}              //  ALU pipe: float; $93
(W)     add (1|M0)               r2.8<1>:d     r2.14<0;1,0>:d    -r1.1<0;1,0>:d   {I@2}              //  ALU pipe: int; $89
(W)     add (1|M0)               r2.9<1>:d     r1.0<0;1,0>:d     -r4.2<0;1,0>:d   {I@2}              //  ALU pipe: int; $95
(W)     mov (1|M0)               r5.0<1>:ud    r4.1<0;1,0>:f                    {F@1}                //  ALU pipe: int; $96
(W)     mov (1|M0)               r6.0<1>:f     r2.8<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $97
(W)     mov (1|M0)               r6.1<1>:f     r2.9<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $97
(W)     mov (1|M0)               r5.1<1>:f     r5.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $99
(W)     mad (1|M0)               r1.1<1>:f     r2.3<0;0>:f       r5.1<0;0>:f       -r2.2<0>:f       {F@1} //  ALU pipe: float; $101
(W)     mad (1|M0)               r1.4<1>:f     r6.1<0;0>:f       r5.1<0;0>:f       -r6.0<0>:f        //  ALU pipe: float; $103
(W)     add (1|M0)               r7.0<1>:f     r1.1<0;1,0>:f     r1.4<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $104
(W)     mul (1|M0)               r8.0<1>:f     r4.0<0;1,0>:f     r7.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $105
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $106
(W)     mov (1|M0)               r3.1<1>:ud    r8.0<0;1,0>:f                    {A@1}                //  ALU pipe: int; $107
(W)     add (1|M0)               r3.2<1>:d     r3.1<0;1,0>:d     r5.0<0;1,0>:d    {I@1}              //  ALU pipe: int; $108
(W)     mul (1|M0)               acc0.0<1>:d   r3.2<0;1,0>:d     r2.28<0;1,0>:uw  {I@1}              //  ALU pipe: int; $109
(W)     macl (1|M0)              r9.0<1>:d     r3.2<0;1,0>:d     r2.14<0;1,0>:d   {Compacted}        //  ALU pipe: int; $110
(W)     add (1|M0)               r10.0<1>:d    r1.0<0;1,0>:d     -r9.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $110
(W)     cmp (1|M0)    (ge)f3.0   r12.0<1>:ud   r10.0<0;1,0>:ud   r2.14<0;1,0>:ud  {I@1}              //  ALU pipe: int; $111
(W)     add3 (1|M0)              r39.3<1>:d    r3.1<0;0>:d       r5.0<0;0>:d       -r12.0<0>:d      {I@1} //  ALU pipe: int; $112
// B006: Preds:{B005, B004},  Succs:{B007}
_0_058:
(W)     mov (1|M0)               r39.5<1>:q    r39.3<0;1,0>:ud                  {I@1}                //  ALU pipe: int; $114
// B007: Preds:{B006, B002},  Succs:{B008, B009}
_0_055:
(W)     mov (2|M0)               r39.12<1>:d   r39.10<1;1,0>:d                  {I@1}                //  ALU pipe: int; $116
        mov (32|M0)              r42.0<1>:d    r40.0<1;1,0>:uw                                       //  ALU pipe: int; $138
(W)     mul (1|M0)               acc0.0<1>:ud  r39.12<0;1,0>:ud  r2.28<0;1,0>:uw  {I@2}              //  ALU pipe: int; $117
(W)     macl (1|M0)              r41.0<1>:ud   r39.12<0;1,0>:ud  r2.14<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $118
(W)     mul (1|M0)               acc0.0<1>:ud  r39.12<0;1,0>:ud  r2.28<0;1,0>:uw                     //  ALU pipe: int; $118
(W)     mach (1|M0)              r1.0<1>:d     r39.12<0;1,0>:ud  r2.14<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r2.14<0;1,0>:ud   r39.26<0;1,0>:uw                    //  ALU pipe: int; $121
(W)     macl (1|M0)              r4.0<1>:d     r2.14<0;1,0>:ud   r39.13<0;1,0>:d                     //  ALU pipe: int; $123
(W)     mul (1|M0)               acc0.0<1>:ud  r2.14<0;1,0>:ud   r2.30<0;1,0>:uw                     //  ALU pipe: int; $124
(W)     macl (1|M0)              r5.0<1>:ud    r2.14<0;1,0>:ud   r2.15<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $125
(W)     mul (1|M0)               acc0.0<1>:ud  r2.14<0;1,0>:ud   r2.30<0;1,0>:uw                     //  ALU pipe: int; $125
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r39.8<0;1,0>:ud   r5.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $139
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r39.8<0;1,0>:ud   r5.0<0;1,0>:ud                      //  ALU pipe: int; $131
(W)     mach (1|M0)              r6.0<1>:d     r2.14<0;1,0>:ud   r2.15<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r2.8<2>:b     r39.5<0;1,0>:w                                        //  ALU pipe: int; $136
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r39.9<0;1,0>:d    r6.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $140
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r39.9<0;1,0>:d    r6.0<0;1,0>:d                       //  ALU pipe: int; $132
(W&~f2.0) cmp (32|M0) (lt)f2.0   null<1>:ud    r39.9<0;1,0>:ud   r6.0<0;1,0>:ud                      //  ALU pipe: int; $142
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:ud    r39.9<0;1,0>:ud   r6.0<0;1,0>:ud                      //  ALU pipe: int; $134
(W)     add (1|M0)               r39.14<1>:d   r1.0<0;1,0>:d     r4.0<0;1,0>:d                       //  ALU pipe: int; $123
(W)     mov (1|M0)               r39.15<1>:d   r2.8<0;1,0>:ub                   {I@6}                //  ALU pipe: int; $137
(W&f2.0) jmpi                                _0_059                                                  //  ALU pipe: int; $144
// B008: Preds:{B007},  Succs:{B034}
_0_060:
        mov (32|M0)              r44.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $148
(W)     mov (1|M0)               r41.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $146
(W)     mov (1|M0)               r41.4<1>:w    0:w                                                   //  ALU pipe: int; $147
(W)     jmpi                                 _0_061                                                  // $149
// B009: Preds:{B007},  Succs:{B010, B011}
_0_059:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r39.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $151
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r39.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $152
(W&~f0.0) jmpi                               _0_062                                                  //  ALU pipe: int; $154
// B010: Preds:{B009},  Succs:{B012}
_0_063:
(W)     mov (2|M0)               r46.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $156
(W)     mov (1|M0)               r41.3<1>:d    r2.14<0;1,0>:d                                        //  ALU pipe: int; $158
(W)     jmpi                                 _0_064                                                  // $159
// B011: Preds:{B009},  Succs:{B012}
_0_062:
(W)     mul (1|M0)               acc0.0<1>:ud  r39.12<0;1,0>:ud  0xC:uw                              //  ALU pipe: int; $162
(W)     mach (1|M0)              r4.0<1>:d     r39.12<0;1,0>:ud  0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.0<2>:ud    r39.12<0;1,0>:ud  0xC:uw                              //  ALU pipe: int; $161
(W)     mov (1|M0)               r1.1<2>:d     r4.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $166
(W)     add (1|M0)               r6.0<1>:q     r1.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $167
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r6:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $169
(W)     mov (1|M0)               r46.4<1>:d    r5.0<0;1,0>:d                    {Compacted,$2.dst}   //  ALU pipe: int; $170
(W)     mov (1|M0)               r46.5<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $171
(W)     mov (1|M0)               r41.3<1>:d    r5.2<0;1,0>:d                                         //  ALU pipe: int; $172
// B012: Preds:{B011, B010},  Succs:{B013, B014}
_0_064:
(W)     cmp (32|M0)   (gt)f3.0   null<1>:ud    r46.5<0;1,0>:ud   r2.14<0;1,0>:ud  {I@2}              //  ALU pipe: int; $174
(W&~f3.0) cmp (32|M0) (ge)f3.0   null<1>:ud    r46.4<0;1,0>:ud   r3.0<0;1,0>:ud                      //  ALU pipe: int; $175
(W&~f3.0) jmpi                               _0_065                                                  //  ALU pipe: int; $177
// B013: Preds:{B012},  Succs:{B034}
_0_066:
        mov (32|M0)              r44.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $181
(W)     mov (1|M0)               r41.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $179
(W)     mov (1|M0)               r41.4<1>:w    0:w                                                   //  ALU pipe: int; $180
(W)     jmpi                                 _0_061                                                  // $182
// B014: Preds:{B012},  Succs:{B015, B016}
_0_065:
(W)     mov (1|M0)               r1.0<1>:f     r41.0<0;1,0>:f                   {Compacted}          //  ALU pipe: float; $184
(W)     mov (1|M0)               r1.1<1>:d     r39.14<0;1,0>:d                                       //  ALU pipe: int; $185
(W)     cmp (32|M0)   (le)f2.0   null<1>:ud    r41.3<0;1,0>:ud   r2.14<0;1,0>:ud  {I@7}              //  ALU pipe: int; $191
(W)     add (1|M0)               r41.2<1>:q    r39.3<0;1,0>:q    -r1.0<0;1,0>:q   {A@1}              //  ALU pipe: int; $188
(W)     add (1|M0)               r2.2<1>:d     r2.14<0;1,0>:d    -r46.5<0;1,0>:d                     //  ALU pipe: int; $190
(W)     cmp (32|M0)   (gt)f0.0   null<1>:ud    r41.3<0;1,0>:ud   r41.4<0;1,0>:ud  {I@2}              //  ALU pipe: int; $194
(W&f2.0) cmp (32|M0)  (le)f2.0   null<1>:ud    r41.3<0;1,0>:ud   r2.2<0;1,0>:ud   {I@2}              //  ALU pipe: int; $192
(W)     mov (1|M0)               r3.1<1>:ud    f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $195
(W)     and (1|M0)               f3.0<1>:ud    f2.0<0;1,0>:ud    r3.1<0;1,0>:ud   {I@1}              //  ALU pipe: int; $195
(W&f3.0) jmpi                                _0_067                                                  //  ALU pipe: int; $196
// B015: Preds:{B014},  Succs:{B034}
_0_068:
        mov (32|M0)              r44.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $200
(W)     mov (1|M0)               r1.0<1>:w     1:w                                                   //  ALU pipe: int; $198
(W)     mov (1|M0)               r41.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $199
(W&f2.0) sel (1|M0)              r41.4<1>:w    r1.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $198
(W)     jmpi                                 _0_061                                                  // $201
// B016: Preds:{B014},  Succs:{B017, B018}
_0_067:
(W)     mul (1|M0)               acc0.0<1>:ud  r46.4<0;1,0>:ud   r2.28<0;1,0>:uw                     //  ALU pipe: int; $204
(W)     macl (1|M0)              r4.0<1>:ud    r46.4<0;1,0>:ud   r2.14<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $205
(W)     mul (1|M0)               acc0.0<1>:ud  r46.4<0;1,0>:ud   r2.28<0;1,0>:uw                     //  ALU pipe: int; $205
(W)     mach (1|M0)              r5.0<1>:d     r46.4<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r1.4<2>:ud    r4.0<0;1,0>:ud                   {Compacted,I@3}      //  ALU pipe: int; $205
(W)     mov (1|M0)               r1.5<2>:d     r5.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $209
(W)     mov (2|M0)               r1.0<1>:d     r2.12<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $203
(W)     add (1|M0)               r2.1<1>:q     r1.2<0;1,0>:q     r46.5<0;1,0>:ud  {I@2}              //  ALU pipe: int; $211
        shl (32|M0)              r8.0<1>:d     r42.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $230
(W)     add (1|M0)               r3.1<1>:q     r2.1<0;1,0>:q     r41.2<0;1,0>:q   {I@2}              //  ALU pipe: int; $212
(W)     mul (1|M0)               r6.2<1>:d     r39.15<0;1,0>:d   1536:w                              //  ALU pipe: int; $214
(W)     mov (2|M0)               r6.0<1>:d     r3.2<1;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $213
(W)     add (1|M0)               r41.6<1>:d    r6.2<0;1,0>:d     1536:w               {I@2}          //  ALU pipe: int; $215
(W)     mul (1|M0)               acc0.0<1>:ud  r6.0<0;1,0>:ud    r1.0<0;1,0>:uw   {I@2}              //  ALU pipe: int; $216
(W)     macl (1|M0)              r46.0<1>:ud   r6.0<0;1,0>:ud    r1.0<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $217
(W)     mul (1|M0)               acc0.0<1>:ud  r6.0<0;1,0>:ud    r1.0<0;1,0>:uw                      //  ALU pipe: int; $217
        or (32|M0)               r48.0<1>:d    r8.0<1;1,0>:d     r6.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $231
(W)     mach (1|M0)              r4.0<1>:d     r6.0<0;1,0>:ud    r1.0<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r6.0<0;1,0>:ud    r1.2<0;1,0>:uw                      //  ALU pipe: int; $218
(W)     macl (1|M0)              r7.0<1>:d     r6.0<0;1,0>:ud    r1.1<0;1,0>:d                       //  ALU pipe: int; $219
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r48.0<1;1,0>:ud   r41.6<0;1,0>:ud  {I@4}              //  ALU pipe: int; $232
(W)     mul (1|M0)               acc0.0<1>:d   r1.0<0;1,0>:ud    r6.2<0;1,0>:uw                      //  ALU pipe: int; $220
(W)     add (1|M0)               r4.0<1>:d     r4.0<0;1,0>:d     r7.0<0;1,0>:d    {Compacted,I@3}    //  ALU pipe: int; $219
(W)     macl (1|M0)              r7.0<1>:d     r1.0<0;1,0>:ud    r6.1<0;1,0>:d                       //  ALU pipe: int; $222
(W)     mul (1|M0)               acc0.0<1>:ud  r39.12<0;1,0>:ud  0x3000:uw                           //  ALU pipe: int; $224
(W)     mach (1|M0)              r5.0<1>:d     r39.12<0;1,0>:ud  0x3000:ud                           //  ALU pipe: int; 
(W)     mul (1|M0)               r41.8<1>:ud   r39.12<0;1,0>:ud  0x3000:uw                           //  ALU pipe: int; $223
(W)     add (1|M0)               r41.7<1>:d    r4.0<0;1,0>:d     r7.0<0;1,0>:d    {I@4}              //  ALU pipe: int; $222
(W)     mov (1|M0)               r41.9<1>:d    r5.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $229
(f2.0)  goto (32|M0)                         _0_069            _0_069                                //  ALU pipe: int; $233
// B017: [inDivergent],  Preds:{B016},  Succs:{B034}
_0_070:
        mov (32|M0)              r44.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $237
(W)     mov (1|M0)               r41.1<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $235
(W)     mov (1|M0)               r41.4<1>:w    1:w                                                   //  ALU pipe: int; $236
        goto (32|M0)                         _0_069            _0_061                                // $238
// B018: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_069:
        join (32|M0)                         _0_061                                                  // 
L2944:
(W)     mov (1|M0)               r1.0<1>:d     r46.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $240
(W)     mov (1|M0)               r1.1<1>:d     r41.7<0;1,0>:d                   {I@7}                //  ALU pipe: int; $241
        mov (32|M0)              r44.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $251
        mov (32|M0)              r50.0<1>:d    r48.0<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $252
(W)     mov (1|M0)               r2.2<1>:d     r41.8<0;1,0>:d                                        //  ALU pipe: int; $245
(W)     mov (1|M0)               r2.3<1>:d     r41.9<0;1,0>:d                   {I@7}                //  ALU pipe: int; $246
(W)     add (1|M0)               r41.5<1>:q    r1.0<0;1,0>:q     r1.1<0;1,0>:q    {I@4}              //  ALU pipe: int; $244
(W)     add (1|M0)               r41.6<1>:q    r2.1<0;1,0>:q     r1.3<0;1,0>:q    {I@2}              //  ALU pipe: int; $249
(W)     add (1|M0)               r41.7<1>:q    r41.5<0;1,0>:q    6144:w               {I@2}          //  ALU pipe: int; $250
// B019: [inDivergent],  Preds:{B033, B018},  Succs:{B020, B031}
_0_071:
        add (32|M0)              r4.0<1>:d     r50.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $254
        sel (32|M0)   (lt)f0.0   r52.0<1>:ud   r4.0<1;1,0>:ud    r41.6<0;1,0>:ud  {I@1}              //  ALU pipe: int; $255
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r50.0<1;1,0>:ud   r52.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $256
(~f0.0) goto (32|M0)                         _0_072            _0_072                                //  ALU pipe: int; $257
// B020: [inDivergent],  Preds:{B019},  Succs:{B021}
_0_073:
        mov (32|M0)              r54.0<1>:f    r50.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $259
// B021: [inDivergent],  Preds:{B030, B020},  Succs:{B022, B026}
_0_074:
        shr (32|M0)              r6.0<1>:ud    r54.0<1;1,0>:ud   3:w               {F@1}             //  ALU pipe: int; $264
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     536870908:d               {I@1}     //  ALU pipe: int; $265
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $267
        mov (16|M16)             r16.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $267
        add (16|M0)              r12.0<1>:q    r41.7<0;1,0>:q    r10.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $267
        add (16|M16)             r14.0<1>:q    r41.7<0;1,0>:q    r16.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $267
        load.ugm.d32.a64 (32|M0)  r60:2         [r12:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200580 // $269
        and (32|M0)              r4.0<1>:d     r54.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $261
        add (32|M0)              r56.0<1>:d    r4.0<1;1,0>:d     32:w               {Compacted,I@1}  //  ALU pipe: int; $262
        sel (32|M0)   (lt)f0.0   r58.0<1>:ud   r56.0<1;1,0>:ud   r52.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $263
        and (32|M0)              r18.0<1>:d    r60.0<1;1,0>:d    2139095040:d               {$3.dst} //  ALU pipe: int; $270
        cmp (32|M0)   (eq)f2.0   null<1>:d     r18.0<1;1,0>:d    2139095040:d               {I@1}    //  ALU pipe: int; $271
(f2.0)  goto (32|M0)                         _0_075            _0_075                                //  ALU pipe: int; $272
// B022: [inDivergent],  Preds:{B021},  Succs:{B023, B029}
_0_076:
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r54.0<1;1,0>:ud   r58.0<1;1,0>:ud                     //  ALU pipe: int; $274
(~f0.0) goto (32|M0)                         _0_075            _0_077                                //  ALU pipe: int; $275
// B023: [inDivergent],  Preds:{B022},  Succs:{B024}
_0_078:
        mov (32|M0)              r48.0<1>:f    r54.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $277
// B024: [inDivergent],  Preds:{B024, B023},  Succs:{B025, B024}
_0_079:
        mov (16|M0)              r4.0<2>:ud    r48.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $280
        mov (16|M16)             r6.0<2>:ud    r49.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $280
        add (16|M0)              r8.0<1>:q     r41.5<0;1,0>:q    r4.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $280
        add (16|M16)             r10.0<1>:q    r41.5<0;1,0>:q    r6.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $280
        load.ugm.d8u32.a64 (32|M0)  r16:2       [r8:4]             {I@1,$4} // ex_desc:0x0; desc:0x8200980 // $282
        shl (16|M0)              r12.0<1>:q    r4.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $284
        shl (16|M16)             r14.0<1>:q    r6.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $284
        add (16|M0)              r18.0<1>:q    r41.6<0;1,0>:q    r12.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $285
        add (16|M16)             r20.0<1>:q    r41.6<0;1,0>:q    r14.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $285
        load.ugm.d16u32.a64 (32|M0)  r22:2      [r18:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200B80 // $287
        add (32|M0)              r48.0<1>:d    r48.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $297
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r48.0<1;1,0>:ud   r58.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $298
        mov (32|M0)              r24.0<1>:b    r16.0<4;1,0>:b                   {$4.dst}             //  ALU pipe: int; $283
        mov (32|M0)   (lt)f0.0   null<2>:w     r24.0<1;1,0>:b                   {I@1}                //  ALU pipe: int; $289
        or (32|M0)               r26.0<1>:d    r16.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $288
(f0.0)  sel (32|M0)              r30.0<1>:d    r26.0<1;1,0>:d    r16.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $291
        mov (32|M0)              r32.0<1>:f    r30.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $292
        shl (32|M0)              r28.0<1>:d    r22.0<1;1,0>:ud   16:w               {$5.dst}         //  ALU pipe: int; $294
        mul (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    r32.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $293
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r28.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $295
        add (32|M0)              r44.0<1>:f    r44.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $296
(f3.0)  goto.b (32|M0)                       _L_k0_0_          _0_079                                //  ALU pipe: int; $299
// B025: [inDivergent],  Preds:{B024},  Succs:{B029}
_L_k0_0_:
        join (32|M0)                         _0_075                                                  // 
L3648:
        goto (32|M0)                         _0_075            _0_077                                // $300
// B026: [inDivergent],  Preds:{B021},  Succs:{B027, B029}
_0_075:
        join (32|M0)                         _0_077                                                  // 
L3680:
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r54.0<1;1,0>:ud   r58.0<1;1,0>:ud                     //  ALU pipe: int; $302
(~f3.0) goto (32|M0)                         _0_077            _0_077                                //  ALU pipe: int; $303
// B027: [inDivergent],  Preds:{B026},  Succs:{B028}
_0_080:
        mov (32|M0)              r48.0<1>:f    r54.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $305
// B028: [inDivergent],  Preds:{B028, B027},  Succs:{B029, B028}
_0_081:
        mov (16|M0)              r4.0<2>:ud    r48.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $308
        mov (16|M16)             r6.0<2>:ud    r49.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $308
        add (16|M0)              r10.0<1>:q    r41.5<0;1,0>:q    r4.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $308
        add (16|M16)             r12.0<1>:q    r41.5<0;1,0>:q    r6.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $308
        load.ugm.d8u32.a64 (32|M0)  r24:2       [r10:4]            {I@1,$6} // ex_desc:0x0; desc:0x8200980 // $310
        shr (16|M0)              r14.0<1>:uq   r4.0<2;1,0>:ud    3:w                                 //  ALU pipe: int; $312
        shr (16|M16)             r16.0<1>:uq   r6.0<2;1,0>:ud    3:w                                 //  ALU pipe: int; $312
        and (16|M0)              r26.0<1>:d    r14.0<2;1,0>:d    536870908:d               {I@2}     //  ALU pipe: int; $313
        and (16|M16)             r27.0<1>:d    r16.0<2;1,0>:d    536870908:d               {I@2}     //  ALU pipe: int; $314
        mov (32|M0)              r8.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $316
        mov (32|M0)              r34.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@2}      //  ALU pipe: float; $315
        shl (16|M0)              r18.0<1>:q    r4.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $324
        shl (16|M16)             r20.0<1>:q    r6.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $324
        mov (16|M0)              r22.1<2>:d    r8.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $319
        mov (16|M16)             r28.1<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $320
        mov (16|M0)              r22.0<2>:d    r34.0<1;1,0>:d                   {F@1}                //  ALU pipe: int; $317
        mov (16|M16)             r28.0<2>:d    r35.0<1;1,0>:d                                        //  ALU pipe: int; $318
        add (16|M0)              r30.0<1>:q    r41.6<0;1,0>:q    r18.0<1;1,0>:q   {Compacted,I@6}    //  ALU pipe: int; $325
        add (16|M16)             r32.0<1>:q    r41.6<0;1,0>:q    r20.0<1;1,0>:q   {Compacted,I@6}    //  ALU pipe: int; $325
        add (16|M0)              r4.0<1>:q     r41.7<0;1,0>:q    r22.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $321
        add (16|M16)             r6.0<1>:q     r41.7<0;1,0>:q    r28.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $321
        load.ugm.d16u32.a64 (32|M0)  r36:2      [r30:4]            {I@3,$7} // ex_desc:0x0; desc:0x8200B80 // $327
        load.ugm.d32.a64 (32|M0)  r10:2         [r4:4]             {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $323
        add (32|M0)              r48.0<1>:d    r48.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $337
        mov (32|M0)              r12.0<1>:b    r24.0<4;1,0>:b                   {$6.dst}             //  ALU pipe: int; $311
        mov (32|M0)   (lt)f2.0   null<2>:w     r12.0<1;1,0>:b                   {I@1}                //  ALU pipe: int; $329
        or (32|M0)               r14.0<1>:d    r24.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $328
(f2.0)  sel (32|M0)              r16.0<1>:d    r14.0<1;1,0>:d    r24.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $331
        mov (32|M0)              r18.0<1>:f    r16.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $332
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r48.0<1;1,0>:ud   r58.0<1;1,0>:ud                     //  ALU pipe: int; $338
        shl (32|M0)              r8.0<1>:d     r36.0<1;1,0>:ud   16:w               {$7.dst}         //  ALU pipe: int; $334
        mul (32|M0)              acc0.0<1>:f   r10.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,@1,$8.dst} //  ALU pipe: float; $333
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r8.0<1;1,0>:f    {Compacted,I@1}    //  ALU pipe: float; $335
        add (32|M0)              r44.0<1>:f    r44.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $336
(f0.0)  goto.b (32|M0)                       _0_077            _0_081                                //  ALU pipe: int; $339
// B029: [inDivergent],  Preds:{B028, B026, B025, B022},  Succs:{B030, B031}
_0_077:
        join (32|M0)                         _0_072                                                  // 
L4200:
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r52.0<1;1,0>:ud   r56.0<1;1,0>:ud                     //  ALU pipe: int; $341
(~f2.0) goto (32|M0)                         _0_072            _0_072                                //  ALU pipe: int; $342
// B030: [inDivergent],  Preds:{B029},  Succs:{B021}
_0_082:
        mov (32|M0)              r54.0<1>:f    r58.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $344
(W)     jmpi                                 _0_074                                                  // $345
// B031: [inDivergent],  Preds:{B029, B019},  Succs:{B032, B033}
_0_072:
        join (32|M0)                         _0_061                                                  // 
L4272:
        add (32|M0)              r48.0<1>:d    r50.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $347
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r48.0<1;1,0>:ud   r41.6<0;1,0>:ud  {I@1}              //  ALU pipe: int; $348
(f3.0)  goto (32|M0)                         _0_083            _0_083                                //  ALU pipe: int; $349
// B032: [inDivergent],  Preds:{B031},  Succs:{B034}
_0_084:
(W)     mov (1|M0)               r41.1<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $351
(W)     mov (1|M0)               r41.4<1>:hf   0x1:hf                                                //  ALU pipe: float; $352
        goto (32|M0)                         _0_083            _0_061                                // $353
// B033: [inDivergent],  Preds:{B031},  Succs:{B019}
_0_083:
        join (32|M0)                         _0_061                                                  // 
L4368:
        mov (32|M0)              r50.0<1>:f    r48.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $355
(W)     jmpi                                 _0_071                                                  // $356
// B034: Preds:{B032, B017, B015, B013, B008},  Succs:{B035, B036}
_0_061:
        join (32|M0)                         L4408                                                   // 
L4408:
        add (32|M0)              r4.0<1>:d     r42.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $358
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $359
        shl (32|M0)              r8.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {A@1}           //  ALU pipe: int; $360
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $361
        add (16|M0)              a0.0<1>:uw    r8.0<1;1,0>:uw    0xB00:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0201(r44.0:f); $362
        add (32|M0)              r12.0<1>:d    r42.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $371
        mov (16|M0)              r10.0<1>:ud   r[a0.0]<1,0>:ud                  {F@4}                //  ALU pipe: int; $363
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $364
        add (16|M16)             a0.0<1>:uw    r8.16<1;1,0>:uw   0xB00:uw                            //  ALU pipe: int; src1 is addr of V0201(r44.0:f); $365
        and (32|M0)   (eq)f0.0   null<1>:d     r42.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $367
        and (32|M0)              r4.0<1>:d     r12.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $372
        mov (16|M16)             r11.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $366
        shl (32|M0)              r9.0<1>:uw    r4.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $373
(f0.0)  sel (32|M0)              acc0.0<1>:f   r10.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $369
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $374
        add (16|M0)              a0.0<1>:uw    r9.0<1;1,0>:uw    0xF80:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0358(r62.0:f); $375
        add (32|M0)              r62.0<1>:f    r44.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $370
        add (32|M0)              r10.0<1>:d    r42.0<1;1,0>:d    4:w               {Compacted,F@2}   //  ALU pipe: int; $384
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $376
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $377
        add (16|M16)             a0.0<1>:uw    r9.16<1;1,0>:uw   0xF80:uw                            //  ALU pipe: int; src1 is addr of V0358(r62.0:f); $378
        and (32|M0)   (eq)f3.0   null<1>:d     r42.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $380
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $385
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $379
        shl (32|M0)              r8.0<1>:uw    r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $386
(f3.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $382
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $387
        add (16|M0)              a0.0<1>:uw    r8.0<1;1,0>:uw    0x1000:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0366(r64.0:f); $388
        add (32|M0)              r64.0<1>:f    r62.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $383
        add (32|M0)              r6.0<1>:d     r42.0<1;1,0>:d    8:w               {Compacted,F@2}   //  ALU pipe: int; $397
        mov (16|M0)              r4.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $389
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $390
        add (16|M16)             a0.0<1>:uw    r8.16<1;1,0>:uw   0x1000:uw                           //  ALU pipe: int; src1 is addr of V0366(r64.0:f); $391
        and (32|M0)   (eq)f2.0   null<1>:d     r42.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $393
        and (32|M0)              r10.0<1>:d    r6.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $398
        mov (16|M16)             r5.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $392
        shl (32|M0)              r9.0<1>:uw    r10.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $399
(f2.0)  sel (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $395
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $400
        add (16|M0)              a0.0<1>:uw    r9.0<1;1,0>:uw    0x1080:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0374(r66.0:f); $401
        add (32|M0)              r66.0<1>:f    r64.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $396
        add (32|M0)              r4.0<1>:d     r42.0<1;1,0>:d    16:w               {Compacted,F@2}  //  ALU pipe: int; $410
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $402
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $403
        add (16|M16)             a0.0<1>:uw    r9.16<1;1,0>:uw   0x1080:uw                           //  ALU pipe: int; src1 is addr of V0374(r66.0:f); $404
        and (32|M0)   (eq)f0.0   null<1>:d     r42.0<1;1,0>:d    15:w                                //  ALU pipe: int; $406
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $411
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $405
        shl (32|M0)              r8.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $412
        cmp (32|M0)   (eq)f2.0   null<2>:w     r40.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $422
        cmp (32|M0)   (eq)f3.0   null<2>:w     r40.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $419
(f0.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@4}    //  ALU pipe: float; $408
(W)     mov (1|M0)               r1.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $420
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $413
        add (16|M0)              a0.0<1>:uw    r8.0<1;1,0>:uw    0x1100:uw              {I@4}        //  ALU pipe: int; src1 is addr of V0382(r68.0:f); $414
        add (32|M0)              r68.0<1>:f    r66.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $409
(f1.0)  sel (32|M0)              r4.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw              {F@2}           //  ALU pipe: int; $423
(f2.0)  sel (32|M0)              r5.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $423
(f3.0)  sel (32|M0)              r10.0<1>:uw   r1.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $420
        mov (16|M0)              r70.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $415
        and (32|M0)   (ne)f3.0   null<2>:uw    r4.0<1;1,0>:uw    r5.0<1;1,0>:uw   {I@3}              //  ALU pipe: int; $423
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $416
        add (16|M16)             a0.0<1>:uw    r8.16<1;1,0>:uw   0x1100:uw                           //  ALU pipe: int; src1 is addr of V0382(r68.0:f); $417
(f1.0)  sel (32|M0)              r9.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $420
        and (32|M0)   (ne)f0.0   null<2>:uw    r9.0<1;1,0>:uw    r10.0<1;1,0>:uw  {I@1}              //  ALU pipe: int; $420
(W)     mov (1|M0)               r46.1<1>:d    r39.8<0;1,0>:ub                                       //  ALU pipe: int; $421
        mov (16|M16)             r71.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $418
(~f3.0) goto (32|M0)                         _0_085            _0_085                                //  ALU pipe: int; $424
// B035: [inDivergent],  Preds:{B034},  Succs:{B036}
_0_086:
        cmp (32|M0)   (eq)f2.0   null<2>:w     r40.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $426
(W)     shl (1|M0)               r1.0<1>:d     r46.1<0;1,0>:d    1:w               {Compacted,I@4}   //  ALU pipe: int; $431
(W)     mov (1|M0)               r2.2<1>:d     504:w                               {Compacted}       //  ALU pipe: int; $432
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r41.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $429
(f2.0)  sel (32|M0)              acc0.0<1>:f   r70.0<1;1,0>:f    0x80000000:f               {I@6}    //  ALU pipe: float; $427
(W)     bfn.(s0&s1|s2) (1|M0)    r3.1<1>:ud    r1.0<0;0>:ud      r2.2<0;0>:ud      r39.15<0>:ud     {I@2} //  ALU pipe: int; $433
        add (32|M0)              acc0.0<1>:f   r68.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $428
(W)     shl (1|M0)               r6.0<1>:d     r3.1<0;1,0>:d     2:w               {Compacted,I@1}   //  ALU pipe: int; $434
(f1.0)  sel (32|M0)              r4.0<1>:f     acc0.0<1;1,0>:f   0x7FC00000:f                        //  ALU pipe: float; $430
        mov (32|M0)              r8.0<1>:f     r6.0<0;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $435
        store.slm.d32.a32 (32|M0)  [r8:2]       r4:2               {F@1,$9} // ex_desc:0x0; desc:0x4000504 // $436
// B036: Preds:{B035, B034},  Succs:{B037, B041}
_0_085:
        join (32|M0)                         L5536                                                   // 
L5536:
        sync.nop                             null                             {Compacted,$9.src}     // $438
(W)     send.slm (1|M0)          r4       r38  null:0  0x0            0x0210001F           {$10} // wr:1+0, rd:1; fence.slm.none.group // $438
(W)     mov (1|M0)               r5.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $439
(W)     mov (2|M0)               r5.10<1>:ub   r38.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $439
(W)     mov (8|M0)               null<1>:ud    r4.0<1;1,0>:ud                   {Compacted,$10.dst}  //  memory fence commit; ALU pipe: int; $439
(W)     send.gtwy (1|M0)         null     r5  null:0  0x0            0x02000004           {I@2,$11} // wr:1+0, rd:0; signal barrier // $439
(W)     sync.bar                             0x0                                                     // $439
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r39.15<0;1,0>:d   0:w                                 //  ALU pipe: int; $440
(W)     mov (1|M0)               r1.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $441
(f0.0)  sel (32|M0)              r6.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $441
(f2.0)  sel (32|M0)              r7.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $441
        and (32|M0)   (ne)f3.0   null<2>:uw    r6.0<1;1,0>:uw    r7.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $441
(~f3.0) goto (32|M0)                         _0_087            _0_087                                //  ALU pipe: int; $442
// B037: [inDivergent],  Preds:{B036},  Succs:{B038, B039}
_0_088:
(W)     shl (1|M0)               r1.0<1>:d     r46.1<0;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $444
(W)     mov (1|M0)               r4.0<1>:f     r1.0<0;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $445
(W)     or (1|M0)                r5.0<1>:d     r1.0<0;1,0>:d     8:w               {Compacted,$11.src} //  ALU pipe: int; $447
(W)     or (1|M0)                r6.0<1>:d     r1.0<0;1,0>:d     12:w               {Compacted}      //  ALU pipe: int; $449
(W)     load.slm.d32x2t.a32 (1|M0)  r7:1        [r4:1]             {F@1,$12} // ex_desc:0x0; desc:0x2109500 // $446
(W)     load.slm.d32x1t.a32 (1|M0)  r8:1        [r5:1]             {I@2,$13} // ex_desc:0x0; desc:0x2108500 // $448
(W)     load.slm.d32x1t.a32 (1|M0)  r9:1        [r6:1]             {I@1,$14} // ex_desc:0x0; desc:0x2108500 // $450
(W)     add (1|M0)               r2.2<1>:f     r7.0<0;1,0>:f     r7.1<0;1,0>:f    {Compacted,$12.dst} //  ALU pipe: float; $451
        sync.nop                             null                             {Compacted,$14.dst}    // $452
(W)     add (1|M0)               r2.3<1>:f     r8.0<0;1,0>:f     r9.0<0;1,0>:f    {$13.dst}          //  ALU pipe: float; $452
(W)     add (1|M0)               r47.0<1>:f    r2.2<0;1,0>:f     r2.3<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $453
(W)     and (1|M0)               r3.1<1>:d     r47.0<0;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $454
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r3.1<0;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $455
(W&f2.0) jmpi                                _0_089                                                  //  ALU pipe: int; $456
// B038: [inDivergent],  Preds:{B037},  Succs:{B040}
_0_090:
(W)     shr (1|M0)               r1.0<1>:ud    r47.0<0;1,0>:ud   16:w                                //  ALU pipe: int; $458
(W)     and (1|M0)               r2.2<1>:d     r1.0<0;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $459
(W)     add3 (1|M0)              r3.1<1>:d     r2.2<0;0>:d       r47.0<0;0>:d      32767:w               {I@1} //  ALU pipe: int; $460
(W)     shr (1|M0)               r4.0<1>:ud    r3.1<0;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $461
(W)     mov (1|M0)               r72.0<2>:w    r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $462
(W)     jmpi                                 _0_091                                                  // $463
// B039: [inDivergent],  Preds:{B037},  Succs:{B040}
_0_089:
(W)     shr (1|M0)               r1.0<1>:ud    r47.0<0;1,0>:ud   16:w                                //  ALU pipe: int; $465
(W)     or (1|M0)                r72.0<1>:w    r1.0<0;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $467
// B040: [inDivergent],  Preds:{B039, B038},  Succs:{B041}
_0_091:
(W)     shl (1|M0)               r1.0<1>:q     r39.3<0;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $469
(W)     mov (1|M0)               r6.0<1>:ud    r72.0<0;1,0>:uw                  {I@2}                //  ALU pipe: int; $472
(W)     add (1|M0)               r4.0<1>:q     r1.0<0;1,0>:q     r2.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $470
(W)     store.ugm.d16u32.a64 (1|M0)  [r4:2]     r6:1               {I@1,$15} // ex_desc:0x0; desc:0x4000B84 // $473
// B041: Preds:{B040, B036},  Succs:{B042, B043}
_0_087:
        join (32|M0)                         L6080                                                   // 
L6080:
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r39.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $478
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r39.8<0;1,0>:d    r41.0<0;1,0>:d                      //  ALU pipe: int; $475
(W&~f1.0) cmp (32|M0) (ne)f1.0   null<1>:d     r39.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $479
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r39.9<0;1,0>:d    r39.14<0;1,0>:d                     //  ALU pipe: int; $476
(W)     mov (1|M0)               r1.0<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $481
(W)     mov (1|M0)               r2.4<1>:hf    0x1:hf                                                //  ALU pipe: float; $482
(W)     and (1|M0)               f1.0<1>:ud    f2.0<0;1,0>:ud    r1.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $481
        sync.nop                             null                             {Compacted,F@1}        // $482
        sync.nop                             null                             {Compacted,$15.src}    // $482
(f0.0)  sel (32|M0)              r5.0<1>:uw    r2.4<0;1,0>:uw    0x0:uw              {$11.src}       //  ALU pipe: int; $482
(f1.0)  sel (32|M0)              r4.0<1>:uw    r2.4<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $482
        and (32|M0)   (ne)f3.0   null<2>:uw    r4.0<1;1,0>:uw    r5.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $482
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r39.15<0;1,0>:d   0:w                                 //  ALU pipe: int; $483
(~f3.0) goto (32|M0)                         _0_092            _0_092                                //  ALU pipe: int; $485
// B042: [inDivergent],  Preds:{B041},  Succs:{B043}
_0_093:
(W)     mov (1|M0)               r1.0<2>:b     r41.4<0;1,0>:w                                        //  ALU pipe: int; $487
(W)     mov (1|M0)               r3.2<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $490
(W)     mov (1|M0)               r2.4<1>:w     r1.0<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $488
(W)     shl (1|M0)               r5.0<1>:q     r39.5<0;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $492
(W)     cmp (32|M0)   (eq)f3.0   null<2>:w     r2.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $489
(W)     and (1|M0)               r5.2<1>:d     r5.0<0;1,0>:d     -4:w               {Compacted,I@2}  //  ALU pipe: int; $493
(W)     and (1|M0)               r5.3<1>:d     r5.1<0;1,0>:d     3:w                                 //  ALU pipe: int; $494
(W&f3.0) sel (1|M0)              r4.0<1>:d     r3.2<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $490
(W)     add (1|M0)               r8.0<1>:q     r5.1<0;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $495
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $491
(W)     store.ugm.d32x1t.a64 (1|M0)  [r8:1]     r6:1               {I@1,$0} // ex_desc:0x0; desc:0x2008584 // $497
// B043: Preds:{B042, B041},  Succs:{}
_0_092:
        join (32|M0)                         L6440                                                   // 
L6440:
(W)     mov (16|M0)              r127.0<1>:f   r38.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $499
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$1} // wr:1+0, rd:0; end of thread // $499
L6464:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x11:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 3
//


//.numALUInst: 406
//.accSubDef: 10
//.accSubUse: 10
//.accSubCandidateDef: 10
//.accSubCandidateUse: 10
//
//
//.singlePipeAtOneDistNum: 88
//.allAtOneDistNum: 10
//.syncInstCount: 4
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 13
//.AfterReadTokenDepCount: 4
