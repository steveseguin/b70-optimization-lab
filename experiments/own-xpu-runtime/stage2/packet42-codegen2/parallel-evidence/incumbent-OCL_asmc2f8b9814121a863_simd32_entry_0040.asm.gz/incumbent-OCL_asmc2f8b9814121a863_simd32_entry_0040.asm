//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE0ELj6144ELj1ELj1ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 40 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 40 -GRFBumpUpNumber 2 "
//.instCount 336
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r93.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r93.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r93.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.1)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.13)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r94.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.2)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r95.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=16 words (r93.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r1.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0067 (77)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r1.8)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r94.1)
//.declare V0069 (79)  rf=r size=8 type=d align=2 words (r94.4)
//.declare V0070 (80)  rf=r size=8 type=d alias=V0068+0 align=4 words (r94.2)
//.declare P01 (81)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0071 (82)  rf=r size=4 type=d align=2 words (r94.6)
//.declare V0072 (83)  rf=r size=4 type=d align=4 words (r1.2)
//.declare V0073 (84)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0074 (85)  rf=r size=4 type=ud alias=V0050+0 align=2 words (r2.12)
//.declare V0075 (86)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0076 (87)  rf=r size=4 type=ud alias=V0075+0 align=2 words (r3.0)
//.declare V0077 (88)  rf=r size=4 type=d alias=+0 align=2 words (r4.0)
//.declare V0078 (89)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0079 (90)  rf=r size=4 type=ud alias=V0072+0 align=2 words (r1.2)
//.declare V0080 (91)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0081 (92)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0082 (93)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0083 (94)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0084 (95)  rf=r size=4 type=ud alias=V0083+0 align=2 words (r10.0)
//.declare V0085 (96)  rf=r size=4 type=d alias=+4 align=2 words (r4.1)
//.declare V0086 (97)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0087 (98)  rf=r size=4 type=ud alias=V0086+0 align=2 words (r11.0)
//.declare V0088 (99)  rf=r size=4 type=f alias=+0 align=2 words (r12.0)
//.declare V0089 (100)  rf=r size=4 type=ud alias=V0077+0 align=2 words (r4.0)
//.declare V0090 (101)  rf=r size=4 type=f alias=+4 align=2 words (r12.1)
//.declare V0091 (102)  rf=r size=4 type=ud alias=V0085+0 align=2 words (r4.1)
//.declare V0092 (103)  rf=r size=4 type=f align=2 words (r13.0)
//.declare V0094 (105)  rf=r size=4 type=f align=2 words (r14.0)
//.declare V0096 (107)  rf=r size=4 type=f align=2 words (r15.0)
//.declare V0097 (108)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0098 (109)  rf=r size=4 type=f align=2 words (r17.0)
//.declare V0099 (110)  rf=r size=4 type=d align=2 words (r18.0)
//.declare V0100 (111)  rf=r size=4 type=ud alias=V0099+0 align=2 words (r18.0)
//.declare V0101 (112)  rf=r size=4 type=d align=2 words (r19.0)
//.declare V0102 (113)  rf=r size=4 type=d align=32 words (r20.0)
//.declare V0103 (114)  rf=r size=4 type=d align=2 words (r21.0)
//.declare V0104 (115)  rf=r size=4 type=d align=2 words (r22.0)
//.declare V0105 (116)  rf=r size=4 type=ud alias=V0103+0 align=2 words (r21.0)
//.declare V0106 (117)  rf=r size=4 type=ud alias=V0104+0 align=2 words (r22.0)
//.declare  (118)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0107 (119)  rf=r size=4 type=d align=32 words (r96.0)
//.declare V0108 (120)  rf=r size=4 type=d align=2 words (r94.7)
//.declare V0109 (121)  rf=r size=4 type=ud alias=V0107+0 align=2 words (r96.0)
//.declare V0110 (122)  rf=r size=4 type=ud alias=V0071+0 align=2 words (r94.6)
//.declare V0111 (123)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0114 (126)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0116 (128)  rf=r size=4 type=ud alias=V0114+0 align=2 words (r3.0)
//.declare V0117 (129)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r2.13)
//.declare V0118 (130)  rf=r size=4 type=d align=32 words (r4.0)
//.declare P02 (133)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0121 (134)  rf=r size=8 type=ud alias=V0069+0 align=2 words (r94.4)
//.declare P03 (135)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P04 (136)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0123 (138)  rf=r size=128 type=d align=32 words (r97.0)
//.declare V0124 (139)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r95.0)
//.declare P05 (140)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P06 (141)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P07 (142)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0125 (143)  rf=r size=4 type=d align=2 words (r94.8)
//.declare V0126 (144)  rf=r size=2 type=w align=1 words (r94.18)
//.declare V0127 (145)  rf=r size=128 type=f align=32 words (r99.0)
//.declare P08 (146)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P09 (147)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0128 (148)  rf=r size=4 type=d alias=+0 align=2 words (r96.4)
//.declare V0129 (149)  rf=r size=4 type=d alias=+4 align=2 words (r96.5)
//.declare V0130 (150)  rf=r size=4 type=d align=2 words (r94.10)
//.declare V0131 (151)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0132 (152)  rf=r size=8 type=ud alias=V0131+0 align=4 words (r1.2)
//.declare V0133 (153)  rf=r size=8 type=d alias=V0131+0 align=4 words (r1.2)
//.declare V0134 (154)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0138 (158)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0139 (159)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P10 (160)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0140 (161)  rf=r size=4 type=ud alias=V0129+0 align=2 words (r96.5)
//.declare P11 (162)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0141 (163)  rf=r size=4 type=ud alias=V0128+0 align=2 words (r96.4)
//.declare V0142 (164)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r2.14)
//.declare V0144 (166)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0145 (167)  rf=r size=8 type=d alias=V0144+0 align=4 words (r1.2)
//.declare V0146 (168)  rf=r size=8 type=q align=4 words (r94.6)
//.declare V0148 (170)  rf=r size=4 type=d align=2 words (r2.0)
//.declare P12 (171)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0149 (172)  rf=r size=4 type=ud alias=V0130+0 align=2 words (r94.10)
//.declare P13 (173)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0150 (174)  rf=r size=4 type=ud alias=V0148+0 align=2 words (r2.0)
//.declare P14 (175)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P15 (177)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0152 (178)  rf=r size=8 type=d align=2 words (r1.2)
//.declare V0153 (179)  rf=r size=8 type=d alias=V0049+0 align=4 words (r2.10)
//.declare V0154 (180)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0155 (181)  rf=r size=8 type=ud alias=V0154+0 align=4 words (r3.0)
//.declare V0156 (182)  rf=r size=8 type=d alias=V0154+0 align=4 words (r3.0)
//.declare V0157 (183)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0160 (186)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0161 (187)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0162 (188)  rf=r size=8 type=d align=2 words (r7.0)
//.declare V0163 (189)  rf=r size=8 type=d alias=V0161+0 align=4 words (r6.0)
//.declare V0164 (190)  rf=r size=8 type=q align=4 words (r9.0)
//.declare V0165 (191)  rf=r size=8 type=ud alias=V0162+0 align=2 words (r7.0)
//.declare V0166 (192)  rf=r size=8 type=ud alias=V0152+0 align=2 words (r1.2)
//.declare V0167 (193)  rf=r size=8 type=ud alias=V0164+0 align=4 words (r9.0)
//.declare V0168 (194)  rf=r size=8 type=d alias=V0164+0 align=4 words (r9.0)
//.declare V0169 (195)  rf=r size=4 type=d align=32 words (r10.0)
//.declare V0170 (196)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0171 (197)  rf=r size=8 type=q align=4 words (r94.7)
//.declare V0172 (198)  rf=r size=8 type=q align=4 words (r12.0)
//.declare V0173 (199)  rf=r size=8 type=ud alias=V0172+0 align=4 words (r12.0)
//.declare V0174 (200)  rf=r size=8 type=d alias=V0172+0 align=4 words (r12.0)
//.declare V0175 (201)  rf=r size=4 type=d align=32 words (r13.0)
//.declare V0177 (203)  rf=r size=8 type=q align=4 words (r96.1)
//.declare V0178 (204)  rf=r size=128 type=d align=32 words (r101.0)
//.declare V0179 (205)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0181 (207)  rf=r size=128 type=ud alias=V0179+0 align=32 words (r5.0)
//.declare V0184 (210)  rf=r size=256 type=uq align=32 words (r27.0)
//.declare V0185 (211)  rf=r size=128 type=f align=32 words (r37.0)
//.declare V0186 (212)  rf=r size=256 type=q alias=V0184+0 align=32 words (r27.0)
//.declare V0187 (213)  rf=r size=128 type=f align=32 words (r41.0)
//.declare V0188 (214)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0190 (216)  rf=r size=128 type=ud alias=V0188+0 align=32 words (r3.0)
//.declare V0193 (219)  rf=r size=256 type=uq align=32 words (r23.0)
//.declare V0194 (220)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0195 (221)  rf=r size=256 type=q alias=V0193+0 align=32 words (r23.0)
//.declare V0196 (222)  rf=r size=128 type=d align=32 words (r39.0)
//.declare V0198 (224)  rf=r size=128 type=w alias=V0194+0 align=32 words (r35.0)
//.declare V0202 (228)  rf=r size=128 type=w alias=V0196+0 align=32 words (r39.0)
//.declare V0205 (231)  rf=r size=128 type=d align=32 words (r71.0)
//.declare V0207 (233)  rf=r size=128 type=d align=32 words (r77.0)
//.declare V0209 (235)  rf=r size=128 type=f alias=V0207+0 align=32 words (r77.0)
//.declare V0211 (237)  rf=r size=128 type=d align=32 words (r73.0)
//.declare V0213 (239)  rf=r size=128 type=d align=32 words (r79.0)
//.declare V0215 (241)  rf=r size=128 type=f alias=V0213+0 align=32 words (r79.0)
//.declare V0219 (245)  rf=r size=256 type=uq align=32 words (r31.0)
//.declare V0220 (246)  rf=r size=128 type=f align=32 words (r47.0)
//.declare V0221 (247)  rf=r size=256 type=q alias=V0219+0 align=32 words (r31.0)
//.declare V0222 (248)  rf=r size=128 type=f align=32 words (r49.0)
//.declare V0225 (251)  rf=r size=256 type=uq align=32 words (r51.0)
//.declare V0226 (252)  rf=r size=128 type=f align=32 words (r63.0)
//.declare V0227 (253)  rf=r size=256 type=q alias=V0225+0 align=32 words (r51.0)
//.declare V0228 (254)  rf=r size=128 type=f align=32 words (r65.0)
//.declare V0229 (255)  rf=r size=128 type=d align=32 words (r75.0)
//.declare V0231 (257)  rf=r size=128 type=d align=32 words (r81.0)
//.declare V0232 (258)  rf=r size=128 type=f align=32 words (r85.0)
//.declare V0233 (259)  rf=r size=128 type=f alias=V0231+0 align=32 words (r81.0)
//.declare V0235 (261)  rf=r size=128 type=d align=32 words (r83.0)
//.declare V0237 (263)  rf=r size=128 type=d align=32 words (r87.0)
//.declare V0238 (264)  rf=r size=128 type=f align=32 words (r3.0)
//.declare V0239 (265)  rf=r size=128 type=f alias=V0237+0 align=32 words (r87.0)
//.declare V0243 (269)  rf=r size=256 type=uq align=32 words (r43.0)
//.declare V0244 (270)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0245 (271)  rf=r size=256 type=q alias=V0243+0 align=32 words (r43.0)
//.declare V0246 (272)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0249 (275)  rf=r size=256 type=uq align=32 words (r59.0)
//.declare V0250 (276)  rf=r size=128 type=f align=32 words (r67.0)
//.declare V0251 (277)  rf=r size=256 type=q alias=V0249+0 align=32 words (r59.0)
//.declare V0252 (278)  rf=r size=128 type=f align=32 words (r69.0)
//.declare V0254 (280)  rf=r size=128 type=w alias=V0244+0 align=32 words (r55.0)
//.declare V0258 (284)  rf=r size=128 type=w alias=V0246+0 align=32 words (r57.0)
//.declare V0261 (287)  rf=r size=128 type=d align=32 words (r89.0)
//.declare V0263 (289)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0264 (290)  rf=r size=128 type=f align=32 words (r11.0)
//.declare V0265 (291)  rf=r size=128 type=f alias=V0263+0 align=32 words (r5.0)
//.declare V0267 (293)  rf=r size=128 type=d align=32 words (r91.0)
//.declare V0269 (295)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0270 (296)  rf=r size=128 type=f align=32 words (r13.0)
//.declare V0271 (297)  rf=r size=128 type=f alias=V0269+0 align=32 words (r7.0)
//.declare V0273 (299)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0275 (301)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0276 (302)  rf=r size=128 type=f align=32 words (r19.0)
//.declare V0277 (303)  rf=r size=128 type=f alias=V0275+0 align=32 words (r15.0)
//.declare V0279 (305)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0281 (307)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0283 (309)  rf=r size=128 type=f alias=V0281+0 align=32 words (r21.0)
//.declare P16 (310)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0284 (311)  rf=r size=128 type=ud alias=V0178+0 align=32 words (r101.0)
//.declare V0285 (312)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0286 (313)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0287 (314)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0288 (315)  rf=r size=128 type=uw alias=V0286+0 align=32 words (r5.0)
//.declare V0289 (316)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (317)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P17 (318)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0292 (321)  rf=r size=128 type=f align=32 words (r103.0)
//.declare V0293 (322)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0294 (323)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0295 (324)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0296 (325)  rf=r size=128 type=uw alias=V0294+0 align=32 words (r12.0)
//.declare V0297 (326)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (327)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P18 (328)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0300 (331)  rf=r size=128 type=f align=32 words (r105.0)
//.declare V0301 (332)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0302 (333)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0303 (334)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0304 (335)  rf=r size=128 type=uw alias=V0302+0 align=32 words (r19.0)
//.declare V0305 (336)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (337)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P19 (338)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0308 (341)  rf=r size=128 type=f align=32 words (r107.0)
//.declare V0309 (342)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0310 (343)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0311 (344)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0312 (345)  rf=r size=128 type=uw alias=V0310+0 align=32 words (r26.0)
//.declare V0313 (346)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (347)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P20 (348)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0316 (351)  rf=r size=128 type=f align=32 words (r109.0)
//.declare V0317 (352)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0318 (353)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0319 (354)  rf=r size=128 type=f align=32 words (r111.0)
//.declare V0320 (355)  rf=r size=128 type=uw alias=V0318+0 align=32 words (r33.0)
//.declare V0321 (356)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (357)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P21 (358)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P22 (359)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P23 (360)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0323 (362)  rf=r size=128 type=f align=32 words (r3.0)
//.declare P24 (363)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0324 (364)  rf=r size=128 type=d align=32 words (r113.0)
//.declare V0325 (365)  rf=r size=128 type=d alias=V0323+0 align=32 words (r3.0)
//.declare V0326 (366)  rf=r size=128 type=d align=32 words (r5.0)
//.declare P25 (367)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0327 (368)  rf=r size=128 type=ud alias=V0326+0 align=32 words (r5.0)
//.declare V0328 (369)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0329 (370)  rf=r size=128 type=ud alias=V0324+0 align=32 words (r113.0)
//.declare V0330 (371)  rf=r size=128 type=ud alias=V0328+0 align=32 words (r3.0)
//.declare V0331 (372)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0332 (373)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0333 (374)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0334 (375)  rf=r size=128 type=ud alias=V0332+0 align=32 words (r8.0)
//.declare V0335 (376)  rf=r size=128 type=ud alias=V0333+0 align=32 words (r10.0)
//.declare V0336 (377)  rf=r size=64 type=w align=32 words (r115.0)
//.declare V0337 (378)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0338 (379)  rf=r size=128 type=ud alias=V0337+0 align=32 words (r3.0)
//.declare V0340 (381)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0343 (384)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare P26 (385)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0344 (386)  rf=r size=2 type=uw align=1 words (r94.19)
//.declare V0346 (388)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare V0347 (389)  rf=r size=4 type=uw alias=V0346+0 align=2 words (r3.0)
//.declare A05 (390)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0349 (392)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare P27 (394)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P28 (395)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P29 (396)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P30 (397)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P31 (398)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P32 (399)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P33 (400)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0351 (401)  rf=r size=2 type=b align=1 words (r1.8)
//.declare V0352 (402)  rf=r size=2 type=w align=1 words (r2.0)
//.declare V0353 (403)  rf=r size=2 type=ub alias=V0351+0 align=1 words (r1.8)
//.declare P34 (404)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0354 (405)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0355 (406)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0357 (408)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0360 (411)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare  (412)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (413)  rf=r size=4 type=d alias=V0146+0 align=2 words (r94.12)
//.declare  (414)  rf=r size=128 type=w alias=V0337+0 align=32 words (r3.0)
//.declare  (415)  rf=r size=8 type=f align=8 words (r12.0)
//.declare  (416)  rf=r size=8 type=ud align=8 words (r4.0)
//.declare  (417)  rf=r size=8 type=d align=8 words (r96.4)
//.declare  (418)  rf=r size=64 type=uw align=32 words (r37.0)
//.declare  (419)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (420)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare  (421)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (422)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (423)  rf=r size=4 type=f align=2 words (r7.0)
//.declare  (424)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare  (425)  rf=r size=2 type=w align=1 words (r1.4)
//.declare  (426)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare  (427)  rf=r size=4 type=ud align=32 words (r8.0)
//.declare  (428)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (429)  rf=r size=128 type=ud align=32 words (r13.0)
//.declare  (430)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (431)  rf=r size=128 type=ud align=32 words (r9.0)
//.declare  (432)  rf=r size=2 type=uw align=1 words (r36.0)
//.declare  (434)  rf=r size=128 type=w alias=V0333+0 align=32 words (r10.0)
//.declare  (435)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare  (436)  rf=r size=2 type=uw align=1 words (r2.0)
//.declare  (438)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (441)  rf=r size=128 type=q align=32 words (r19.0)
//.declare  (442)  rf=r size=128 type=q align=32 words (r21.0)
//.declare  (445)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (446)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (455)  rf=r size=128 type=uq alias=+0 align=32 words (r19.0)
//.declare  (456)  rf=r size=128 type=uq alias=+0 align=32 words (r21.0)
//.declare  (457)  rf=r size=128 type=uq alias=+0 align=32 words (r15.0)
//.declare  (458)  rf=r size=128 type=uq alias=+0 align=32 words (r17.0)
//.declare r0 (459)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (460)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (461)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (462)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :q       |    0x8 | r1       | inline+0x0       |
// | V0041    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0042    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r2       | cti+0x20         |
// | V0045    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0050    | :d       |    0x4 | r2+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r2+0x34  | cti+0x54         |
// | V0052    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0054    | :b       |    0x1 | r3       | cti+0x60         |
// | V0055    | :b       |    0x1 | r3+0x4   | cti+0x64         |
// | V0037    | :uq      |    0x8 | r3+0x8   | cti+0x68         |
// | V0038    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r93.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r1.8<2>:b     r93.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     mov (8|M0)               r95.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {@2,$0.dst}          //  ALU pipe: int; $9
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $12
(W)     mov (1|M0)               r3.0<1>:q     r2.0<0;1,0>:w                    {@2,$1.dst}          //  ALU pipe: int; $9
(W)     add (8|M0)               r95.8<1>:w    r95.0<1;1,0>:w    8:w                                 //  ALU pipe: int; $5
(W)     add (1|M0)               r94.1<1>:q    r93.1<0;1,0>:ud   r3.0<0;1,0>:q    {I@2}              //  ALU pipe: int; $10
(W)     add (16|M0)              r95.16<1>:w   r95.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $6
(W)     mov (2|M0)               r94.0<1>:d    r2.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     mov (2|M0)               r94.4<1>:d    r94.2<1;1,0>:d                   {I@3}                //  ALU pipe: int; $11
(W&~f3.0) jmpi                               _0_026                                                  //  ALU pipe: int; $13
// B002: Preds:{B001},  Succs:{B004}
_0_027:
(W)     mov (1|M0)               r94.6<1>:d    -1:w                                                  //  ALU pipe: int; $15
(W)     jmpi                                 _0_028                                                  // $16
// B003: Preds:{B001},  Succs:{B004}
_0_026:
(W)     mov (1|M0)               r1.2<2>:d     r94.1<0;1,0>:q                                        //  ALU pipe: int; $18
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $19
(W)     mov (1|M0)               r2.0<1>:f     r2.12<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $20
(W)     mov (1|M0)               r7.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $25
(W)     math.inv (1|M0)          r6.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $24
(W)     mov (1|M0)               r5.0<1>:f     r1.2<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $23
(W)     mad (1|M0)               r8.0<1>:f     r6.0<0;0>:f       r7.0<0;0>:f       r6.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $25
(W)     mov (1|M0)               r3.0<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $21
(W)     mov (1|M0)               r10.0<1>:ud   r5.0<0;1,0>:f                    {F@2}                //  ALU pipe: int; $27
(W)     mul (1|M0)               r9.0<1>:f     r5.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $26
(W)     add (1|M0)               r4.0<1>:d     r2.12<0;1,0>:d    -r3.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $22
(W)     add (1|M0)               r4.1<1>:d     r1.2<0;1,0>:d     -r10.0<0;1,0>:d  {I@2}              //  ALU pipe: int; $28
(W)     mov (1|M0)               r11.0<1>:ud   r9.0<0;1,0>:f                    {F@1}                //  ALU pipe: int; $29
(W)     mov (1|M0)               r12.0<1>:f    r4.0<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $30
(W)     mov (1|M0)               r12.1<1>:f    r4.1<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $30
(W)     mov (1|M0)               r13.0<1>:f    r11.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $32
(W)     mad (1|M0)               r14.0<1>:f    r5.0<0;0>:f       r13.0<0;0>:f      -r2.0<0>:f       {F@1} //  ALU pipe: float; $34
(W)     mad (1|M0)               r15.0<1>:f    r12.1<0;0>:f      r13.0<0;0>:f      -r12.0<0>:f       //  ALU pipe: float; $36
(W)     add (1|M0)               r16.0<1>:f    r14.0<0;1,0>:f    r15.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $37
(W)     mul (1|M0)               r17.0<1>:f    r8.0<0;1,0>:f     r16.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $38
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $39
(W)     mov (1|M0)               r18.0<1>:ud   r17.0<0;1,0>:f                   {A@1}                //  ALU pipe: int; $40
(W)     add (1|M0)               r19.0<1>:d    r18.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $41
(W)     mul (1|M0)               acc0.0<1>:d   r19.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $42
(W)     macl (1|M0)              r20.0<1>:d    r19.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $43
(W)     add (1|M0)               r21.0<1>:d    r1.2<0;1,0>:d     -r20.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $43
(W)     cmp (1|M0)    (ge)f2.0   r22.0<1>:ud   r21.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@1}              //  ALU pipe: int; $44
(W)     add3 (1|M0)              r94.6<1>:d    r18.0<0;0>:d      r11.0<0;0>:d      -r22.0<0>:d      {I@1} //  ALU pipe: int; $45
// B004: Preds:{B003, B002},  Succs:{B005, B006}
_0_028:
(W)     mul (1|M0)               acc0.0<1>:ud  r94.6<0;1,0>:ud   r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $47
(W)     macl (1|M0)              r96.0<1>:ud   r94.6<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $48
(W)     mul (1|M0)               acc0.0<1>:ud  r94.6<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $48
(W)     mach (1|M0)              r2.0<1>:d     r94.6<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $54
(W)     macl (1|M0)              r3.0<1>:ud    r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; $55
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $55
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r94.4<0;1,0>:ud   r3.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $67
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r94.4<0;1,0>:ud   r3.0<0;1,0>:ud                      //  ALU pipe: int; $61
(W)     mach (1|M0)              r4.0<1>:d     r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; 
        mov (32|M0)              r97.0<1>:d    r95.0<1;1,0>:uw                                       //  ALU pipe: int; $66
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r94.5<0;1,0>:d    r4.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $68
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r94.5<0;1,0>:d    r4.0<0;1,0>:d                       //  ALU pipe: int; $62
(W&~f2.0) cmp (32|M0) (lt)f2.0   null<1>:ud    r94.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $70
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r94.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $64
(W)     mov (1|M0)               r94.7<1>:d    r2.0<0;1,0>:d                                         //  ALU pipe: int; $53
(W&f2.0) jmpi                                _0_029                                                  //  ALU pipe: int; $72
// B005: Preds:{B004},  Succs:{B017}
_0_030:
        mov (32|M0)              r99.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $76
(W)     mov (1|M0)               r94.8<1>:d    0:w                                                   //  ALU pipe: int; $74
(W)     mov (1|M0)               r94.18<1>:w   0:w                                                   //  ALU pipe: int; $75
(W)     jmpi                                 _0_031                                                  // $77
// B006: Preds:{B004},  Succs:{B007, B008}
_0_029:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r94.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $79
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r94.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $80
(W&~f3.0) jmpi                               _0_032                                                  //  ALU pipe: int; $82
// B007: Preds:{B006},  Succs:{B009}
_0_033:
(W)     mov (2|M0)               r96.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $84
(W)     mov (1|M0)               r94.10<1>:d   r2.12<0;1,0>:d                                        //  ALU pipe: int; $86
(W)     jmpi                                 _0_034                                                  // $87
// B008: Preds:{B006},  Succs:{B009}
_0_032:
(W)     mul (1|M0)               acc0.0<1>:ud  r94.6<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $90
(W)     mach (1|M0)              r2.0<1>:d     r94.6<0;1,0>:ud   0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.2<2>:ud    r94.6<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $89
(W)     mov (1|M0)               r1.3<2>:d     r2.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $94
(W)     add (1|M0)               r4.0<1>:q     r1.1<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $95
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $97
(W)     mov (1|M0)               r96.4<1>:d    r5.0<0;1,0>:d                    {Compacted,$2.dst}   //  ALU pipe: int; $98
(W)     mov (1|M0)               r96.5<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $99
(W)     mov (1|M0)               r94.10<1>:d   r5.2<0;1,0>:d                                         //  ALU pipe: int; $100
// B009: Preds:{B008, B007},  Succs:{B010, B011}
_0_034:
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r96.5<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $102
(W&~f2.0) cmp (32|M0) (ge)f2.0   null<1>:ud    r96.4<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; $103
(W&~f2.0) jmpi                               _0_035                                                  //  ALU pipe: int; $105
// B010: Preds:{B009},  Succs:{B017}
_0_036:
        mov (32|M0)              r99.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $109
(W)     mov (1|M0)               r94.8<1>:d    0:w                                                   //  ALU pipe: int; $107
(W)     mov (1|M0)               r94.18<1>:w   0:w                                                   //  ALU pipe: int; $108
(W)     jmpi                                 _0_031                                                  // $110
// B011: Preds:{B009},  Succs:{B012, B013}
_0_035:
(W)     mov (1|M0)               r1.2<1>:d     r96.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $112
(W)     mov (1|M0)               r1.3<1>:d     r94.7<0;1,0>:d                                        //  ALU pipe: int; $113
(W)     cmp (32|M0)   (le)f3.0   null<1>:ud    r94.10<0;1,0>:ud  r2.12<0;1,0>:ud  {I@7}              //  ALU pipe: int; $119
(W)     add (1|M0)               r94.6<1>:q    r94.1<0;1,0>:q    -r1.1<0;1,0>:q   {I@2}              //  ALU pipe: int; $116
(W)     add (1|M0)               r2.0<1>:d     r2.12<0;1,0>:d    -r96.5<0;1,0>:d                     //  ALU pipe: int; $118
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r94.10<0;1,0>:ud  r94.12<0;1,0>:ud {I@2}              //  ALU pipe: int; $122
(W&f3.0) cmp (32|M0)  (le)f3.0   null<1>:ud    r94.10<0;1,0>:ud  r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $120
(W)     mov (1|M0)               r3.0<1>:ud    f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $123
(W)     and (1|M0)               f1.0<1>:ud    f3.0<0;1,0>:ud    r3.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $123
(W&f1.0) jmpi                                _0_037                                                  //  ALU pipe: int; $124
// B012: Preds:{B011},  Succs:{B017}
_0_038:
        mov (32|M0)              r99.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $128
(W)     mov (1|M0)               r1.4<1>:w     1:w                                                   //  ALU pipe: int; $126
(W)     mov (1|M0)               r94.8<1>:d    0:w                                                   //  ALU pipe: int; $127
(W&f3.0) sel (1|M0)              r94.18<1>:w   r1.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $126
(W)     jmpi                                 _0_031                                                  // $129
// B013: Preds:{B011},  Succs:{B014}
_0_037:
(W)     mul (1|M0)               acc0.0<1>:ud  r96.4<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $132
(W)     macl (1|M0)              r2.0<1>:ud    r96.4<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $133
(W)     mul (1|M0)               acc0.0<1>:ud  r96.4<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $133
(W)     mach (1|M0)              r4.0<1>:d     r96.4<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r3.0<2>:f     r2.0<0;1,0>:f                    {I@3}                //  ALU pipe: float; $133
(W)     mov (1|M0)               r3.1<2>:d     r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $137
(W)     mov (2|M0)               r1.2<1>:d     r2.10<1;1,0>:d                                        //  ALU pipe: int; $131
(W)     add (1|M0)               r5.0<1>:q     r3.0<0;1,0>:q     r96.5<0;1,0>:ud  {A@1}              //  ALU pipe: int; $139
        shl (32|M0)              r101.0<1>:d   r97.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $156
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r94.6<0;1,0>:q   {I@2}              //  ALU pipe: int; $140
        mov (32|M0)              r99.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $157
(W)     mov (2|M0)               r7.0<1>:f     r6.0<1;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $141
(W)     mul (1|M0)               r12.0<2>:ud   r94.6<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $149
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw   {F@1}              //  ALU pipe: int; $142
(W)     macl (1|M0)              r8.0<1>:ud    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $143
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw                      //  ALU pipe: int; $143
(W)     mach (1|M0)              r10.0<1>:d    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r7.0<0;1,0>:ud    r1.6<0;1,0>:uw                      //  ALU pipe: int; $144
(W)     macl (1|M0)              r11.0<1>:d    r7.0<0;1,0>:ud    r1.3<0;1,0>:d                       //  ALU pipe: int; $145
(W)     mul (1|M0)               acc0.0<1>:d   r1.2<0;1,0>:ud    r7.2<0;1,0>:uw                      //  ALU pipe: int; $146
(W)     add (1|M0)               r10.0<1>:d    r10.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $145
(W)     macl (1|M0)              r11.0<1>:d    r1.2<0;1,0>:ud    r7.1<0;1,0>:d                       //  ALU pipe: int; $147
(W)     mul (1|M0)               acc0.0<1>:ud  r94.6<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $150
(W)     mach (1|M0)              r13.0<1>:d    r94.6<0;1,0>:ud   0x3000:ud                           //  ALU pipe: int; 
(W)     mov (1|M0)               r9.0<2>:f     r8.0<0;1,0>:f                                         //  ALU pipe: float; $143
(W)     add (1|M0)               r9.1<2>:d     r10.0<0;1,0>:d    r11.0<0;1,0>:d   {I@3}              //  ALU pipe: int; $147
(W)     mov (1|M0)               r12.1<2>:d    r13.0<0;1,0>:d                   {I@2}                //  ALU pipe: int; $154
(W)     add (1|M0)               r94.7<1>:q    r9.0<0;1,0>:q     r1.0<0;1,0>:q    {A@1}              //  ALU pipe: int; $148
(W)     add (1|M0)               r96.1<1>:q    r12.0<0;1,0>:q    r1.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $155
// B014: [inDivergent],  Preds:{B016, B013},  Succs:{B015, B016}
_0_039:
        shl (32|M0)              r3.0<1>:d     r101.0<1;1,0>:d   1:w               {Compacted}       //  ALU pipe: int; $165
        mov (16|M0)              r7.0<2>:ud    r3.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $167
        mov (16|M16)             r9.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $167
        shl (32|M0)              r5.0<1>:d     r101.0<1;1,0>:d   2:w               {Compacted}       //  ALU pipe: int; $159
        add (16|M0)              r15.0<1>:q    r96.1<0;1,0>:q    r7.0<2;1,0>:ud   {I@3}              //  ALU pipe: int; $167
        add (16|M16)             r17.0<1>:q    r96.1<0;1,0>:q    r9.0<2;1,0>:ud   {I@3}              //  ALU pipe: int; $167
        mov (16|M0)              r23.0<1>:uq   r15.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $168
        mov (16|M16)             r25.0<1>:uq   r17.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $168
        mov (16|M0)              r11.0<2>:ud   r5.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $161
        mov (16|M16)             r13.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $161
        load.ugm.d32.a64 (32|M0)  r35:2         [r23:4]            {I@3,$3} // ex_desc:0x0; desc:0x8200580 // $169
        add (16|M0)              r19.0<1>:q    r94.7<0;1,0>:q    r11.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $161
        add (16|M16)             r21.0<1>:q    r94.7<0;1,0>:q    r13.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $161
        mov (16|M0)              r27.0<1>:uq   r19.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $162
        mov (16|M16)             r29.0<1>:uq   r21.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $162
        load.ugm.d32.a64 (32|M0)  r39:2         [r23:4+0x4]        {$4} // ex_desc:0x4000; desc:0x8200580 // $170
        load.ugm.d32.a64 (32|M0)  r37:2         [r27:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $163
        load.ugm.d32.a64 (32|M0)  r41:2         [r27:4+0x4]        {$6} // ex_desc:0x4000; desc:0x8200580 // $164
        add (16|M0)              r43.0<1>:q    r15.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $199
        add (16|M16)             r45.0<1>:q    r17.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $199
        add (16|M0)              r31.0<1>:q    r19.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $183
        add (16|M16)             r33.0<1>:q    r21.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $183
        load.ugm.d32.a64 (32|M0)  r55:2         [r43:4]            {I@3,$7} // ex_desc:0x0; desc:0x8200580 // $201
        load.ugm.d32.a64 (32|M0)  r47:2         [r31:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $185
        load.ugm.d32.a64 (32|M0)  r49:2         [r31:4+0x4]        {$9} // ex_desc:0x4000; desc:0x8200580 // $186
        add (16|M0)              r51.0<1>:q    r19.0<1;1,0>:q    16:w               {Compacted}      //  ALU pipe: int; $187
        add (16|M16)             r53.0<1>:q    r21.0<1;1,0>:q    16:w               {Compacted}      //  ALU pipe: int; $187
        load.ugm.d32.a64 (32|M0)  r57:2         [r43:4+0x4]        {$10} // ex_desc:0x4000; desc:0x8200580 // $202
        load.ugm.d32.a64 (32|M0)  r63:2         [r51:4]            {I@1,$11} // ex_desc:0x0; desc:0x8200580 // $189
        load.ugm.d32.a64 (32|M0)  r65:2         [r51:4+0x4]        {$12} // ex_desc:0x4000; desc:0x8200580 // $190
        add (16|M0)              r59.0<1>:q    r19.0<1;1,0>:q    24:w               {Compacted}      //  ALU pipe: int; $203
        add (16|M16)             r61.0<1>:q    r21.0<1;1,0>:q    24:w               {Compacted}      //  ALU pipe: int; $203
        load.ugm.d32.a64 (32|M0)  r67:2         [r59:4]            {I@1,$13} // ex_desc:0x0; desc:0x8200580 // $205
        load.ugm.d32.a64 (32|M0)  r69:2         [r59:4+0x4]        {$14} // ex_desc:0x4000; desc:0x8200580 // $206
        mov (32|M0)              r71.0<1>:d    r35.0<2;1,0>:uw                  {$3.dst}             //  ALU pipe: int; $175
        mov (32|M0)              r73.0<1>:d    r35.1<2;1,0>:uw                                       //  ALU pipe: int; $179
        shl (32|M0)              r77.0<1>:d    r71.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $176
        shl (32|M0)              r79.0<1>:d    r73.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $180
        mov (32|M0)              r75.0<1>:d    r39.0<2;1,0>:uw                  {$4.dst}             //  ALU pipe: int; $191
        sync.nop                             null                             {Compacted,I@3}        // $177
        mul (32|M0)              acc0.0<1>:f   r37.0<1;1,0>:f    r77.0<1;1,0>:f   {Compacted,$5.dst} //  ALU pipe: float; $177
        mov (32|M0)              r83.0<1>:d    r39.1<2;1,0>:uw                                       //  ALU pipe: int; $195
        shl (32|M0)              r81.0<1>:d    r75.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $192
        mul (32|M0)              acc2.0<1>:f   r41.0<1;1,0>:f    r79.0<1;1,0>:f   {Compacted,$6.dst} //  ALU pipe: float; $181
        mov (32|M0)              r89.0<1>:d    r55.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $211
        shl (32|M0)              r87.0<1>:d    r83.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $196
        add (32|M0)              acc0.0<1>:f   r99.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $178
        sync.nop                             null                             {Compacted,I@3}        // $193
        mul (32|M0)              r85.0<1>:f    r47.0<1;1,0>:f    r81.0<1;1,0>:f   {Compacted,$8.dst} //  ALU pipe: float; $193
        mov (32|M0)              r91.0<1>:d    r55.1<2;1,0>:uw                                       //  ALU pipe: int; $215
        shl (32|M0)              r5.0<1>:d     r89.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $212
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $182
        sync.nop                             null                             {Compacted,I@3}        // $197
        mul (32|M0)              r3.0<1>:f     r49.0<1;1,0>:f    r87.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $197
        shl (32|M0)              r7.0<1>:d     r91.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $216
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r85.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $194
        mov (32|M0)              r9.0<1>:d     r57.0<2;1,0>:uw                  {$10.dst}            //  ALU pipe: int; $219
        sync.nop                             null                             {Compacted,I@3}        // $213
        mul (32|M0)              r11.0<1>:f    r63.0<1;1,0>:f    r5.0<1;1,0>:f    {Compacted,$11.dst} //  ALU pipe: float; $213
        mov (32|M0)              r17.0<1>:d    r57.1<2;1,0>:uw                                       //  ALU pipe: int; $223
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r3.0<1;1,0>:f    {Compacted,F@3}    //  ALU pipe: float; $198
        sync.nop                             null                             {Compacted,I@3}        // $217
        mul (32|M0)              r13.0<1>:f    r65.0<1;1,0>:f    r7.0<1;1,0>:f    {Compacted,$12.dst} //  ALU pipe: float; $217
        shl (32|M0)              r15.0<1>:d    r9.0<1;1,0>:d     16:w               {Compacted,I@2}  //  ALU pipe: int; $220
        shl (32|M0)              r21.0<1>:d    r17.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $224
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r11.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $214
        sync.nop                             null                             {Compacted,I@2}        // $221
        mul (32|M0)              r19.0<1>:f    r67.0<1;1,0>:f    r15.0<1;1,0>:f   {Compacted,$13.dst} //  ALU pipe: float; $221
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r13.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $218
        sync.nop                             null                             {Compacted,I@1}        // $225
        mul (32|M0)              acc2.0<1>:f   r69.0<1;1,0>:f    r21.0<1;1,0>:f   {Compacted,$14.dst} //  ALU pipe: float; $225 R{} IR{}{O:2,O:2,},  R{} IR{}{E:3,E:11,},  {BC=1}
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r101.0<1;1,0>:ud  0x1700:uw                           //  ALU pipe: int; $227
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r19.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $222
        add (32|M0)              r99.0<1>:f    acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $226
(f1.0)  goto (32|M0)                         _0_040            _0_040                                //  ALU pipe: int; $228
// B015: [inDivergent],  Preds:{B014},  Succs:{B017}
_0_041:
(W)     mov (1|M0)               r94.8<1>:d    -1:w                                                  //  ALU pipe: int; $230
(W)     mov (1|M0)               r94.18<1>:hf  0x1:hf                                                //  ALU pipe: float; $231
        goto (32|M0)                         _0_040            _0_031                                // $232
// B016: [inDivergent],  Preds:{B014},  Succs:{B014}
_0_040:
        join (32|M0)                         _0_031                                                  // 
L2856:
        add (32|M0)              r101.0<1>:d   r101.0<1;1,0>:d   256:w               {Compacted}     //  ALU pipe: int; $234
(W)     jmpi                                 _0_039                                                  // $235
// B017: Preds:{B015, B012, B010, B005},  Succs:{B018, B022}
_0_031:
        join (32|M0)                         L2896                                                   // 
L2896:
        add (32|M0)              r3.0<1>:d     r97.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $237
        and (32|M0)              r5.0<1>:d     r3.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $238
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $239
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $240
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0x18C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0127(r99.0:f); $241
        add (32|M0)              r10.0<1>:d    r97.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $250
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@2}                //  ALU pipe: int; $242
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $243
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0x18C0:uw                           //  ALU pipe: int; src1 is addr of V0127(r99.0:f); $244
        and (32|M0)   (eq)f3.0   null<1>:d     r97.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $246
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $251
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $245
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $252
(f3.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $248
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $253
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0x19C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0292(r103.0:f); $254
        add (32|M0)              r103.0<1>:f   r99.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $249
        add (32|M0)              r17.0<1>:d    r97.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $263
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $255
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $256
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0x19C0:uw                           //  ALU pipe: int; src1 is addr of V0292(r103.0:f); $257
        and (32|M0)   (eq)f2.0   null<1>:d     r97.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $259
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $264
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $258
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $265
(f2.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $261
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $266
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0x1A40:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0300(r105.0:f); $267
        add (32|M0)              r105.0<1>:f   r103.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $262
        add (32|M0)              r24.0<1>:d    r97.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $276
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $268
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $269
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0x1A40:uw                           //  ALU pipe: int; src1 is addr of V0300(r105.0:f); $270
        and (32|M0)   (eq)f1.0   null<1>:d     r97.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $272
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $277
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $271
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $278
(f1.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $274
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $279
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0x1AC0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0308(r107.0:f); $280
        add (32|M0)              r107.0<1>:f   r105.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $275
        add (32|M0)              r31.0<1>:d    r97.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $289
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $281
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $282
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0x1AC0:uw                           //  ALU pipe: int; src1 is addr of V0308(r107.0:f); $283
        and (32|M0)   (eq)f3.0   null<1>:d     r97.0<1;1,0>:d    15:w                                //  ALU pipe: int; $285
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $290
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $284
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $291
        cmp (32|M0)   (eq)f1.0   null<2>:w     r95.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $298
(f3.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $287
(W)     mov (1|M0)               r36.0<1>:hf   0x1:hf                                                //  ALU pipe: float; $299
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $292
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0x1B40:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0316(r109.0:f); $293
        add (32|M0)              r109.0<1>:f   r107.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $288
(f0.0)  sel (32|M0)              r37.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw              {F@2}           //  ALU pipe: int; $299
(f1.0)  sel (32|M0)              r38.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw                              //  ALU pipe: int; $299
        mov (16|M0)              r111.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $294
        and (32|M0)   (ne)f2.0   null<2>:uw    r37.0<1;1,0>:uw   r38.0<1;1,0>:uw  {I@2}              //  ALU pipe: int; $299
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $295
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0x1B40:uw                           //  ALU pipe: int; src1 is addr of V0316(r109.0:f); $296
        mov (16|M16)             r112.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $297
(~f2.0) goto (32|M0)                         _0_042            _0_042                                //  ALU pipe: int; $300
// B018: [inDivergent],  Preds:{B017},  Succs:{B019, B020}
_0_043:
        cmp (32|M0)   (eq)f1.0   null<2>:w     r95.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $302
(f1.0)  sel (32|M0)              acc0.0<1>:f   r111.0<1;1,0>:f   0x80000000:f               {I@3}    //  ALU pipe: float; $303
(W)     cmp (32|M0)   (ne)f3.0   null<1>:d     r94.8<0;1,0>:d    0:w                                 //  ALU pipe: int; $305
        add (32|M0)              r3.0<1>:f     r109.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $304
(f3.0)  sel (32|M0)              r113.0<1>:d   r3.0<1;1,0>:d     2143289344:d               {F@1}    //  ALU pipe: int; $306
        and (32|M0)              r5.0<1>:d     r113.0<1;1,0>:d   2147483647:d               {I@1}    //  ALU pipe: int; $307
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r5.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $308
(f2.0)  goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $309
// B019: [inDivergent],  Preds:{B018},  Succs:{B021}
_0_045:
        shr (32|M0)              r3.0<1>:ud    r113.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $311
        and (32|M0)              r6.0<1>:d     r3.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $312
        add3 (32|M0)             r8.0<1>:d     r113.0<1;0>:d     r6.0<1;0>:d       32767:w               {I@1} //  ALU pipe: int; $313
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $314
        mov (32|M0)              r115.0<1>:w   r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $315
        goto (32|M0)                         _0_044            _0_046                                // $316
// B020: [inDivergent],  Preds:{B018},  Succs:{B021}
_0_044:
        join (32|M0)                         _0_046                                                  // 
L4016:
        shr (32|M0)              r3.0<1>:ud    r113.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $318
        or (32|M0)               r115.0<1>:w   r3.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $320
// B021: [inDivergent],  Preds:{B020, B019},  Succs:{B022}
_0_046:
        join (32|M0)                         _0_042                                                  // 
L4064:
(W)     mov (1|M0)               f3.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $325
        cmp (32|M0)   (eq)f3.0   null<2>:uw    r94.19<0;1,0>:uw  r94.19<0;1,0>:uw                    //  ALU pipe: int; $326
(W)     fbl (1|M0)               r3.0<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $328
(W)     shl (1|M0)               r1.1<1>:q     r94.1<0;1,0>:q    1:w                                 //  ALU pipe: int; $322
(W)     shl (1|M0)               r3.0<1>:ud    r3.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $329
(W)     add (1|M0)               r2.0<1>:q     r1.1<0;1,0>:q     r1.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $323
(W)     add (1|M0)               a0.0<1>:uw    r3.0<0;1,0>:uw    0x1CC0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0336(r115.0:w); $330
(W)     mov (1|M0)               r4.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $332
(W)     store.ugm.d16u32.a64 (1|M0)  [r2:2]     r4:1               {I@1,$15} // ex_desc:0x0; desc:0x4000B84 // $333
// B022: Preds:{B021, B017},  Succs:{B023, B024}
_0_042:
        join (32|M0)                         L4208                                                   // 
L4208:
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r94.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $338
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r94.4<0;1,0>:d    r96.0<0;1,0>:d                      //  ALU pipe: int; $335
(W&~f1.0) cmp (32|M0) (ne)f1.0   null<1>:d     r94.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $339
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r94.5<0;1,0>:d    r94.7<0;1,0>:d                      //  ALU pipe: int; $336
(W)     mov (1|M0)               r1.2<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $341
(W)     mov (1|M0)               r2.0<1>:hf    0x1:hf                              {$15.src}         //  ALU pipe: float; $344
(W)     and (1|M0)               f1.0<1>:ud    f2.0<0;1,0>:ud    r1.2<0;1,0>:ud   {I@1}              //  ALU pipe: int; $341
(f0.0)  sel (32|M0)              r4.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $344
(f1.0)  cmp (32|M0)   (eq)f1.0   null<2>:w     r95.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $342
(f1.0)  sel (32|M0)              r3.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $344
        and (32|M0)   (ne)f1.0   null<2>:uw    r3.0<1;1,0>:uw    r4.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $344
(~f1.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $345
// B023: [inDivergent],  Preds:{B022},  Succs:{B024}
_0_048:
(W)     mov (1|M0)               r1.8<2>:b     r94.18<0;1,0>:w                                       //  ALU pipe: int; $347
(W)     mov (1|M0)               r3.0<1>:hf    0xFFFF:hf                              {I@3}          //  ALU pipe: float; $350
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $348
(W)     shl (1|M0)               r7.0<1>:q     r94.6<0;1,0>:ud   2:w                                 //  ALU pipe: int; $353
(W)     cmp (32|M0)   (eq)f0.0   null<2>:w     r2.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $349
(W&f0.0) sel (1|M0)              r4.0<1>:d     r3.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $350
(W)     add (1|M0)               r8.0<1>:q     r7.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $354
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $351
(W)     store.ugm.d32x1t.a64 (1|M0)  [r8:1]     r6:1               {I@1,$0} // ex_desc:0x0; desc:0x2008584 // $356
// B024: Preds:{B023, B022},  Succs:{}
_0_047:
        join (32|M0)                         L4536                                                   // 
L4536:
(W)     mov (16|M0)              r127.0<1>:f   r93.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $358
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$1} // wr:1+0, rd:0; end of thread // $358
L4560:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x28:ud                                               // 


//.BankConflicts: 1
//.ByteRMWs: 2
//


//.numALUInst: 295
//.accSubDef: 15
//.accSubUse: 15
//.accSubCandidateDef: 20
//.accSubCandidateUse: 20
//
//
//.singlePipeAtOneDistNum: 48
//.allAtOneDistNum: 10
//.syncInstCount: 7
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 15
//.AfterReadTokenDepCount: 1
