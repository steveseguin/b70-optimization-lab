//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE0ELj6144ELj4ELj4ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 37 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 37 -GRFBumpUpNumber 2 "
//.instCount 397
//.RA type	LOCAL_FIRST_FIT_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r30.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.12)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.13)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r30.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r30.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.3)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.6)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.8)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.12)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r31.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=32 words (r2.4)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r32.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=32 words (r30.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r31.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0068 (78)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r31.8)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r31.2)
//.declare V0071 (81)  rf=r size=8 type=d alias=V0069+0 align=4 words (r31.4)
//.declare V0072 (82)  rf=r size=8 type=q align=4 words (r31.3)
//.declare V0073 (83)  rf=r size=8 type=uq alias=V0069+0 align=4 words (r31.2)
//.declare V0074 (84)  rf=r size=8 type=uq alias=V0072+0 align=4 words (r31.3)
//.declare V0075 (85)  rf=r size=8 type=d align=2 words (r31.8)
//.declare V0076 (86)  rf=r size=8 type=d alias=V0072+0 align=4 words (r31.6)
//.declare V0077 (87)  rf=r size=2 type=w align=1 words (r3.2)
//.declare V0078 (88)  rf=r size=2 type=w align=1 words (r31.5)
//.declare P01 (89)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0080 (91)  rf=r size=4 type=f align=2 words (r1.0)
//.declare V0081 (92)  rf=r size=4 type=ud alias=V0050+0 align=32 words (r2.14)
//.declare V0082 (93)  rf=r size=4 type=f align=2 words (r2.2)
//.declare V0083 (94)  rf=r size=8 type=df align=4 words (r3.1)
//.declare V0084 (95)  rf=r size=8 type=df align=4 words (r4.0)
//.declare V0085 (96)  rf=r size=8 type=df align=4 words (r4.1)
//.declare V0086 (97)  rf=r size=8 type=df align=4 words (r3.2)
//.declare V0087 (98)  rf=r size=8 type=df align=4 words (r5.0)
//.declare V0089 (100)  rf=r size=8 type=df align=4 words (r6.0)
//.declare V0091 (102)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0093 (104)  rf=r size=4 type=ud alias=V0091+0 align=2 words (r6.2)
//.declare V0094 (105)  rf=r size=8 type=df align=4 words (r6.2)
//.declare V0095 (106)  rf=r size=8 type=df align=4 words (r7.0)
//.declare V0096 (107)  rf=r size=4 type=d align=4 words (r8.0)
//.declare V0097 (108)  rf=r size=4 type=ud alias=V0096+0 align=2 words (r8.0)
//.declare V0098 (109)  rf=r size=4 type=d align=32 words (r1.0)
//.declare V0099 (110)  rf=r size=4 type=d align=2 words (r1.1)
//.declare V0101 (112)  rf=r size=8 type=df align=4 words (r2.1)
//.declare V0102 (113)  rf=r size=4 type=ud alias=V0099+0 align=2 words (r1.1)
//.declare V0103 (114)  rf=r size=8 type=df align=4 words (r2.4)
//.declare V0105 (116)  rf=r size=8 type=df align=4 words (r8.1)
//.declare V0106 (117)  rf=r size=8 type=df align=4 words (r3.1)
//.declare V0107 (118)  rf=r size=8 type=df align=4 words (r4.0)
//.declare V0108 (119)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0109 (120)  rf=r size=8 type=uq alias=V0108+0 align=4 words (r5.0)
//.declare V0110 (121)  rf=r size=4 type=d align=2 words (r5.2)
//.declare V0111 (122)  rf=r size=8 type=d alias=V0108+0 align=4 words (r5.0)
//.declare P02 (124)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0113 (125)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0114 (126)  rf=r size=4 type=d align=2 words (r5.3)
//.declare V0115 (127)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0117 (129)  rf=r size=8 type=q align=4 words (r7.1)
//.declare V0118 (130)  rf=r size=8 type=d alias=V0117+0 align=4 words (r7.2)
//.declare V0119 (131)  rf=r size=8 type=q align=4 words (r9.0)
//.declare V0121 (133)  rf=r size=8 type=q align=4 words (r9.1)
//.declare V0122 (134)  rf=r size=8 type=d alias=V0121+0 align=4 words (r9.2)
//.declare V0123 (135)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0124 (136)  rf=r size=4 type=ud alias=V0110+0 align=2 words (r5.2)
//.declare V0125 (137)  rf=r size=8 type=ud alias=V0123+0 align=4 words (r2.2)
//.declare V0126 (138)  rf=r size=8 type=d alias=V0123+0 align=4 words (r2.2)
//.declare V0127 (139)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0129 (141)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0130 (142)  rf=r size=8 type=d align=2 words (r3.1)
//.declare V0131 (143)  rf=r size=8 type=d alias=V0129+0 align=4 words (r1.0)
//.declare V0132 (144)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0133 (145)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0134 (146)  rf=r size=8 type=q align=4 words (r7.0)
//.declare P03 (147)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0135 (148)  rf=r size=8 type=ud alias=V0130+0 align=2 words (r3.1)
//.declare P04 (149)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P05 (150)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0136 (151)  rf=r size=8 type=q align=4 words (r10.0)
//.declare V0137 (152)  rf=r size=8 type=q align=4 words (r7.1)
//.declare V0138 (153)  rf=r size=8 type=d alias=V0137+0 align=4 words (r7.2)
//.declare V0139 (154)  rf=r size=8 type=q align=4 words (r31.5)
//.declare P06 (155)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0140 (156)  rf=r size=4 type=d align=2 words (r31.3)
//.declare V0141 (157)  rf=r size=4 type=d align=4 words (r1.0)
//.declare V0142 (158)  rf=r size=4 type=f align=2 words (r2.2)
//.declare V0143 (159)  rf=r size=4 type=d align=2 words (r1.1)
//.declare V0144 (160)  rf=r size=4 type=ud alias=V0143+0 align=2 words (r1.1)
//.declare V0145 (161)  rf=r size=4 type=d alias=+0 align=2 words (r2.8)
//.declare V0146 (162)  rf=r size=4 type=f align=2 words (r2.3)
//.declare V0147 (163)  rf=r size=4 type=ud alias=V0141+0 align=2 words (r1.0)
//.declare V0148 (164)  rf=r size=4 type=f align=2 words (r2.10)
//.declare V0149 (165)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0150 (166)  rf=r size=4 type=f align=2 words (r4.1)
//.declare V0151 (167)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0152 (168)  rf=r size=4 type=ud alias=V0151+0 align=2 words (r4.2)
//.declare V0153 (169)  rf=r size=4 type=d alias=+4 align=2 words (r2.9)
//.declare V0154 (170)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0155 (171)  rf=r size=4 type=ud alias=V0154+0 align=2 words (r5.0)
//.declare V0156 (172)  rf=r size=4 type=f alias=+0 align=2 words (r6.0)
//.declare V0157 (173)  rf=r size=4 type=ud alias=V0145+0 align=2 words (r2.8)
//.declare V0158 (174)  rf=r size=4 type=f alias=+4 align=2 words (r6.1)
//.declare V0159 (175)  rf=r size=4 type=ud alias=V0153+0 align=2 words (r2.9)
//.declare V0160 (176)  rf=r size=4 type=f align=2 words (r5.1)
//.declare V0162 (178)  rf=r size=4 type=f align=2 words (r1.1)
//.declare V0164 (180)  rf=r size=4 type=f align=2 words (r1.4)
//.declare V0165 (181)  rf=r size=4 type=f align=2 words (r7.0)
//.declare V0166 (182)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0167 (183)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0168 (184)  rf=r size=4 type=ud alias=V0167+0 align=2 words (r3.1)
//.declare V0169 (185)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0170 (186)  rf=r size=4 type=d align=32 words (r9.0)
//.declare V0171 (187)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0172 (188)  rf=r size=4 type=d align=2 words (r12.0)
//.declare V0173 (189)  rf=r size=4 type=ud alias=V0171+0 align=2 words (r10.0)
//.declare V0174 (190)  rf=r size=4 type=ud alias=V0172+0 align=2 words (r12.0)
//.declare  (191)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare V0175 (192)  rf=r size=4 type=ud alias=V0140+0 align=2 words (r31.3)
//.declare V0176 (193)  rf=r size=8 type=d align=2 words (r31.12)
//.declare V0177 (194)  rf=r size=8 type=d alias=V0139+0 align=4 words (r31.10)
//.declare V0178 (195)  rf=r size=4 type=d align=32 words (r33.0)
//.declare V0179 (196)  rf=r size=4 type=d align=2 words (r31.14)
//.declare V0180 (197)  rf=r size=4 type=ud alias=V0178+0 align=2 words (r33.0)
//.declare V0181 (198)  rf=r size=8 type=ud alias=V0176+0 align=2 words (r31.12)
//.declare V0182 (199)  rf=r size=4 type=d align=32 words (r1.0)
//.declare V0184 (201)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0185 (202)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0187 (204)  rf=r size=4 type=ud alias=V0185+0 align=2 words (r5.0)
//.declare V0188 (205)  rf=r size=4 type=ud alias=V0051+0 align=32 words (r2.15)
//.declare V0189 (206)  rf=r size=4 type=d align=32 words (r6.0)
//.declare P07 (209)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0192 (210)  rf=r size=8 type=ud alias=V0075+0 align=2 words (r31.8)
//.declare P08 (211)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P09 (212)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0194 (214)  rf=r size=2 type=b align=1 words (r2.8)
//.declare V0195 (215)  rf=r size=4 type=d align=2 words (r31.15)
//.declare V0196 (216)  rf=r size=2 type=ub alias=V0194+0 align=1 words (r2.8)
//.declare V0197 (217)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0198 (218)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r32.0)
//.declare P10 (219)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P11 (220)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P12 (221)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0199 (222)  rf=r size=4 type=d align=2 words (r33.1)
//.declare V0200 (223)  rf=r size=2 type=w align=1 words (r33.4)
//.declare V0201 (224)  rf=r size=128 type=f align=32 words (r36.0)
//.declare P13 (225)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P14 (226)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0202 (227)  rf=r size=4 type=d alias=+0 align=2 words (r38.4)
//.declare V0203 (228)  rf=r size=4 type=d alias=+4 align=2 words (r38.5)
//.declare V0204 (229)  rf=r size=4 type=d align=2 words (r33.3)
//.declare V0205 (230)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0206 (231)  rf=r size=8 type=ud alias=V0205+0 align=4 words (r1.0)
//.declare V0207 (232)  rf=r size=8 type=d alias=V0205+0 align=4 words (r1.0)
//.declare V0208 (233)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0212 (237)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0213 (238)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P15 (239)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0214 (240)  rf=r size=4 type=ud alias=V0203+0 align=2 words (r38.5)
//.declare P16 (241)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0215 (242)  rf=r size=4 type=ud alias=V0202+0 align=2 words (r38.4)
//.declare V0216 (243)  rf=r size=4 type=ud alias=V0052+0 align=32 words (r3.0)
//.declare V0218 (245)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0219 (246)  rf=r size=8 type=d alias=V0218+0 align=4 words (r1.0)
//.declare V0220 (247)  rf=r size=8 type=q align=4 words (r33.2)
//.declare V0222 (249)  rf=r size=4 type=d align=2 words (r2.2)
//.declare P17 (250)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0223 (251)  rf=r size=4 type=ud alias=V0204+0 align=2 words (r33.3)
//.declare P18 (252)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0224 (253)  rf=r size=4 type=ud alias=V0222+0 align=2 words (r2.2)
//.declare P19 (254)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P20 (256)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0226 (257)  rf=r size=8 type=d align=2 words (r1.0)
//.declare V0227 (258)  rf=r size=8 type=d alias=V0049+0 align=32 words (r2.12)
//.declare V0228 (259)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0229 (260)  rf=r size=8 type=ud alias=V0228+0 align=4 words (r1.4)
//.declare V0230 (261)  rf=r size=8 type=d alias=V0228+0 align=4 words (r1.4)
//.declare V0231 (262)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0234 (265)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0235 (266)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0236 (267)  rf=r size=8 type=d align=2 words (r6.0)
//.declare V0237 (268)  rf=r size=8 type=d alias=V0235+0 align=4 words (r3.2)
//.declare V0238 (269)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0239 (270)  rf=r size=4 type=d align=2 words (r33.6)
//.declare V0240 (271)  rf=r size=4 type=d align=32 words (r38.0)
//.declare V0241 (272)  rf=r size=4 type=d align=2 words (r33.7)
//.declare V0242 (273)  rf=r size=4 type=ud alias=V0240+0 align=2 words (r38.0)
//.declare V0243 (274)  rf=r size=8 type=ud alias=V0236+0 align=2 words (r6.0)
//.declare V0244 (275)  rf=r size=8 type=ud alias=V0226+0 align=2 words (r1.0)
//.declare V0245 (276)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0247 (278)  rf=r size=4 type=d align=32 words (r7.0)
//.declare V0248 (279)  rf=r size=4 type=d align=2 words (r33.8)
//.declare V0249 (280)  rf=r size=4 type=d align=2 words (r33.9)
//.declare V0250 (281)  rf=r size=4 type=ud alias=V0248+0 align=2 words (r33.8)
//.declare V0251 (282)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0254 (285)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0255 (286)  rf=r size=128 type=d align=32 words (r40.0)
//.declare P21 (287)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0256 (288)  rf=r size=128 type=ud alias=V0255+0 align=32 words (r40.0)
//.declare V0257 (289)  rf=r size=4 type=ud alias=V0239+0 align=2 words (r33.6)
//.declare V0259 (291)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0260 (292)  rf=r size=8 type=d alias=V0259+0 align=4 words (r1.0)
//.declare V0261 (293)  rf=r size=8 type=q align=4 words (r33.5)
//.declare V0263 (295)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0264 (296)  rf=r size=8 type=d alias=V0263+0 align=4 words (r2.2)
//.declare V0265 (297)  rf=r size=8 type=q align=4 words (r33.6)
//.declare V0266 (298)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0267 (299)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0268 (300)  rf=r size=128 type=ud alias=V0266+0 align=32 words (r4.0)
//.declare V0269 (301)  rf=r size=128 type=ud alias=V0267+0 align=32 words (r42.0)
//.declare P22 (302)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0270 (303)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0271 (304)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0273 (306)  rf=r size=128 type=ud alias=V0271+0 align=32 words (r6.0)
//.declare V0276 (309)  rf=r size=256 type=uq align=32 words (r20.0)
//.declare V0277 (310)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0278 (311)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0280 (313)  rf=r size=128 type=ud alias=V0278+0 align=32 words (r4.0)
//.declare V0283 (316)  rf=r size=256 type=uq align=32 words (r16.0)
//.declare V0285 (318)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0286 (319)  rf=r size=128 type=w alias=V0285+0 align=32 words (r24.0)
//.declare V0288 (321)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0290 (323)  rf=r size=128 type=f alias=V0288+0 align=32 words (r28.0)
//.declare V0291 (324)  rf=r size=128 type=d align=32 words (r46.0)
//.declare P23 (325)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0292 (326)  rf=r size=128 type=ud alias=V0291+0 align=32 words (r46.0)
//.declare P24 (327)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0293 (328)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0294 (329)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0295 (330)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0296 (331)  rf=r size=128 type=uw alias=V0294+0 align=32 words (r6.0)
//.declare V0297 (332)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare A00 (333)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P25 (334)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0300 (337)  rf=r size=128 type=f align=32 words (r48.0)
//.declare V0301 (338)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0302 (339)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0303 (340)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0304 (341)  rf=r size=128 type=uw alias=V0302+0 align=32 words (r4.0)
//.declare V0305 (342)  rf=r size=64 type=uw align=32 words (r9.0)
//.declare A01 (343)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P26 (344)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0308 (347)  rf=r size=128 type=f align=32 words (r50.0)
//.declare V0309 (348)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0310 (349)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0311 (350)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0312 (351)  rf=r size=128 type=uw alias=V0310+0 align=32 words (r12.0)
//.declare V0313 (352)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare A02 (353)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P27 (354)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0316 (357)  rf=r size=128 type=f align=32 words (r52.0)
//.declare V0317 (358)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0318 (359)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0319 (360)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0320 (361)  rf=r size=128 type=uw alias=V0318+0 align=32 words (r10.0)
//.declare V0321 (362)  rf=r size=64 type=uw align=32 words (r9.0)
//.declare A03 (363)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P28 (364)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0324 (367)  rf=r size=128 type=f align=32 words (r54.0)
//.declare V0325 (368)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0326 (369)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0327 (370)  rf=r size=128 type=f align=32 words (r56.0)
//.declare V0328 (371)  rf=r size=128 type=uw alias=V0326+0 align=32 words (r6.0)
//.declare V0329 (372)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare A04 (373)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P29 (374)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P30 (375)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0330 (376)  rf=r size=4 type=d align=2 words (r33.14)
//.declare P31 (377)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P32 (378)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P33 (379)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P34 (382)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0333 (383)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0334 (384)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0335 (385)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0336 (386)  rf=r size=4 type=d align=2 words (r2.2)
//.declare V0337 (387)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0338 (388)  rf=r size=4 type=ud alias=V0337+0 align=32 words (r6.0)
//.declare V0339 (389)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (390)  rf=r size=64 type=ud align=32 words (r4.0)
//.declare  (391)  rf=r size=32 type=ud align=32 words (r5.0)
//.declare P35 (392)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P36 (393)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0340 (394)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0341 (395)  rf=r size=4 type=ud alias=V0340+0 align=2 words (r1.0)
//.declare V0342 (396)  rf=r size=8 type=f align=32 words (r7.0)
//.declare V0343 (397)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare V0344 (398)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0345 (399)  rf=r size=4 type=ud alias=V0344+0 align=32 words (r5.0)
//.declare V0346 (400)  rf=r size=4 type=f align=32 words (r8.0)
//.declare V0347 (401)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0348 (402)  rf=r size=4 type=ud alias=V0347+0 align=32 words (r6.0)
//.declare V0349 (403)  rf=r size=4 type=f align=32 words (r9.0)
//.declare V0350 (404)  rf=r size=4 type=f align=2 words (r2.2)
//.declare V0351 (405)  rf=r size=4 type=f align=2 words (r2.3)
//.declare V0352 (406)  rf=r size=4 type=f align=2 words (r33.15)
//.declare V0353 (407)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0354 (408)  rf=r size=4 type=d alias=V0352+0 align=2 words (r33.15)
//.declare P37 (409)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0355 (410)  rf=r size=4 type=ud alias=V0353+0 align=2 words (r3.1)
//.declare V0356 (411)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0357 (412)  rf=r size=4 type=ud alias=V0352+0 align=2 words (r33.15)
//.declare V0358 (413)  rf=r size=4 type=ud alias=V0356+0 align=2 words (r1.0)
//.declare V0359 (414)  rf=r size=4 type=d align=2 words (r2.2)
//.declare V0360 (415)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0361 (416)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0362 (417)  rf=r size=4 type=ud alias=V0360+0 align=2 words (r3.1)
//.declare V0363 (418)  rf=r size=4 type=ud alias=V0361+0 align=2 words (r4.0)
//.declare V0364 (419)  rf=r size=2 type=w align=32 words (r58.0)
//.declare V0365 (420)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0366 (421)  rf=r size=4 type=ud alias=V0365+0 align=2 words (r1.0)
//.declare V0368 (423)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0371 (426)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0372 (427)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare V0373 (428)  rf=r size=2 type=uw alias=V0364+0 align=32 words (r58.0)
//.declare P38 (429)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P39 (430)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P40 (431)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P41 (432)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P42 (433)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P43 (434)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P44 (435)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0374 (436)  rf=r size=2 type=b align=1 words (r1.0)
//.declare V0375 (437)  rf=r size=2 type=w align=1 words (r2.4)
//.declare V0376 (438)  rf=r size=2 type=ub alias=V0374+0 align=1 words (r1.0)
//.declare P45 (439)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0377 (440)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0378 (441)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0379 (442)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0380 (443)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0381 (444)  rf=r size=8 type=d alias=V0380+0 align=4 words (r5.2)
//.declare V0382 (445)  rf=r size=8 type=d alias=V0379+0 align=4 words (r5.0)
//.declare V0385 (448)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0386 (449)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare  (450)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (451)  rf=r size=4 type=d alias=V0072+0 align=2 words (r31.6)
//.declare  (452)  rf=r size=4 type=d alias=V0220+0 align=2 words (r33.4)
//.declare  (453)  rf=r size=2 type=w alias=V0365+0 align=1 words (r1.0)
//.declare  (454)  rf=r size=8 type=f align=8 words (r6.0)
//.declare  (455)  rf=r size=8 type=ud align=8 words (r2.8)
//.declare  (456)  rf=r size=8 type=d align=8 words (r38.4)
//.declare  (457)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (458)  rf=r size=64 type=uw align=32 words (r5.0)
//.declare  (459)  rf=r size=64 type=uw align=32 words (r9.0)
//.declare  (460)  rf=r size=64 type=uw align=32 words (r10.0)
//.declare  (461)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (462)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare  (463)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (464)  rf=r size=64 type=uw align=32 words (r5.0)
//.declare  (465)  rf=r size=2 type=w align=1 words (r1.8)
//.declare  (466)  rf=r size=2 type=w align=1 words (r4.0)
//.declare  (467)  rf=r size=8 type=df align=4 words (r4.2)
//.declare  (468)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (469)  rf=r size=4 type=f align=2 words (r3.1)
//.declare  (470)  rf=r size=4 type=ud align=2 words (r3.1)
//.declare  (471)  rf=r size=2 type=w align=1 words (r1.0)
//.declare  (472)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (473)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (474)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (475)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (476)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (477)  rf=r size=2 type=uw align=1 words (r1.0)
//.declare  (481)  rf=r size=2 type=uw align=1 words (r1.0)
//.declare  (483)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare  (484)  rf=r size=2 type=uw align=1 words (r2.4)
//.declare  (486)  rf=r size=2 type=w align=1 words (r3.2)
//.declare r0 (495)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (496)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (497)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (498)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0386    | :ud      |    0x4 | r1       | inline+0x0       |
// | V0040    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0041    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0042    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0043    | :q       |    0x8 | r2       | cti+0x20         |
// | V0044    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0045    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0046    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0047    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0048    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0049    | :q       |    0x8 | r2+0x30  | cti+0x50         |
// | V0050    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0051    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0052    | :d       |    0x4 | r3       | cti+0x60         |
// | V0053    | :d       |    0x4 | r3+0x4   | cti+0x64         |
// | V0054    | :b       |    0x1 | r3+0x8   | cti+0x68         |
// | V0055    | :b       |    0x1 | r3+0xC   | cti+0x6C         |
// | V0037    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// | V0038    | :uq      |    0x8 | r3+0x18  | cti+0x78         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r30.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r31.8<2>:b    r30.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     shl (1|M0)               r1.0<1>:q     r30.1<0;1,0>:ud   4:w                                 //  ALU pipe: int; $9
(W)     mov (1|M0)               r1.8<1>:w     r31.8<0;1,0>:ub                  {I@2}                //  ALU pipe: int; $10
(W)     mov (8|M0)               r32.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.1<1>:q     r1.8<0;1,0>:w                    {@2,$0.dst}          //  ALU pipe: int; $10
(W)     add (8|M0)               r32.8<1>:w    r32.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $5
(W)     add (1|M0)               r31.2<1>:q    r1.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $11
(W)     mov (1|M0)               r3.2<1>:w     r31.8<0;1,0>:b                   {$1.dst}             //  ALU pipe: int; $15
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r31.5<0;1,0>:ud   0x4:uw              {I@2}           //  ALU pipe: int; $17
(W)     shr (1|M0)               r31.3<1>:uq   r31.2<0;1,0>:uq   2:w                                 //  ALU pipe: int; $13
(W)     add (16|M0)              r32.16<1>:w   r32.0<1;1,0>:w    16:w                                //  ALU pipe: int; $6
(W)     mov (2|M0)               r31.0<1>:d    r2.4<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     and (1|M0)               r31.5<1>:w    r3.2<0;1,0>:w     3:w               {I@5}             //  ALU pipe: int; $16
(W)     mov (2|M0)               r31.8<1>:d    r31.6<1;1,0>:d                   {I@4}                //  ALU pipe: int; $14
(W&f3.0) jmpi                                _0_040                                                  //  ALU pipe: int; $18
// B002: Preds:{B001},  Succs:{B007}
_0_041:
(W)     mov (1|M0)               r1.0<1>:f     r2.14<0;1,0>:ud                                       //  ALU pipe: float; $20
(W)     mov (1|M0)               r3.1<1>:df    r2.14<0;1,0>:ud                                       //  ALU pipe: long; $22
(W)     math.inv (1|M0)          r2.2<1>:f     r1.0<0;1,0>:f                    {F@1}                //  ALU pipe: math; $21
(W)     mov (1|M0)               r3.2<1>:df    0x3FF0000000000000:df                                 //  ALU pipe: long; $24
(W)     mov (1|M0)               r4.0<1>:df    r2.2<0;1,0>:f                    {M@1}                //  ALU pipe: long; $23
(W)     mov (1|M0)               r4.2<1>:df    0xBCF0000000000000:df                                 //  ALU pipe: long; $27
(W)     mad (1|M0)               r4.1<1>:df    r3.2<0;0>:df      r4.0<0;0>:df      -r3.1<0>:df      {L@2} //  ALU pipe: long; $25
(W)     shr (1|M0)               r6.2<1>:ud    r31.5<0;1,0>:ud   2:w                                 //  ALU pipe: int; $30
(W)     add (1|M0)               r5.0<1>:df    r4.1<0;1,0>:df    r4.2<0;1,0>:df   {Compacted,L@1}    //  ALU pipe: long; $27
(W)     mov (1|M0)               r6.2<1>:df    r6.2<0;1,0>:ud                   {I@1}                //  ALU pipe: long; $31
(W)     mad (1|M0)               r6.0<1>:df    r4.0<0;0>:df      r5.0<0;0>:df      r4.0<0>:df       {L@2} //  ALU pipe: long; $28
(W)     mov (1|M0)               r2.4<1>:df    r31.6<0;1,0>:ud                                       //  ALU pipe: long; $38
(W)     mul (1|M0)               r7.0<1>:df    r6.0<0;1,0>:df    r6.2<0;1,0>:df   {Compacted,L@2}    //  ALU pipe: long; $32
(W)     mov (1|M0)               r3.1<1>:df    0x41F0000000000000:df                                 //  ALU pipe: long; $39
(W)     mov (1|M0)               r8.0<2>:ud    r7.0<0;1,0>:df                   {L@2}                //  ALU pipe: int; $33
(W)     mov (1|M0)               r7.2<1>:d     r31.8<0;1,0>:d                                        //  ALU pipe: int; $49
(W)     mul (1|M0)               acc0.0<1>:d   r8.0<0;1,0>:d     r2.28<0;1,0>:uw  {I@2}              //  ALU pipe: int; $34
(W)     macl (1|M0)              r1.0<1>:d     r8.0<0;1,0>:d     r2.14<0;1,0>:d   {Compacted}        //  ALU pipe: int; $35
(W)     mov (1|M0)               r7.3<1>:d     0:w                                                   //  ALU pipe: int; $50
(W)     add (1|M0)               r1.1<1>:d     r6.2<0;1,0>:d     -r1.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $35
(W)     mov (1|M0)               r9.3<1>:d     0:w                                                   //  ALU pipe: int; $55
(W)     mov (1|M0)               r2.1<1>:df    r1.1<0;1,0>:ud                   {I@2}                //  ALU pipe: long; $37
(W)     mad (1|M0)               r8.1<1>:df    r2.4<0;0>:df      r3.1<0;0>:df      r2.1<0>:df       {L@1} //  ALU pipe: long; $40
(W)     mul (1|M0)               r4.0<1>:df    r6.0<0;1,0>:df    r8.1<0;1,0>:df   {Compacted,L@1}    //  ALU pipe: long; $41
(W)     mov (1|M0)               r5.0<1>:uq    r4.0<0;1,0>:df                   {L@1}                //  ALU pipe: int; $42
(W)     cmp (1|M0)    (eq)f2.0   null<1>:d     r5.1<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $45
(W)     mov (1|M0)               r5.2<1>:d     r5.0<0;1,0>:d                    {Compacted}          //  ALU pipe: int; $43
(W)     add (1|M0)               r3.3<1>:d     r5.1<0;1,0>:d     r8.0<0;1,0>:d                       //  ALU pipe: int; $66
(W)     mul (1|M0)               acc0.0<1>:ud  r5.2<0;1,0>:ud    r2.28<0;1,0>:uw  {I@2}              //  ALU pipe: int; $58
(W&~f2.0) sel (1|M0)             r10.0<1>:d    r2.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $46
(W)     macl (1|M0)              r4.0<1>:ud    r5.2<0;1,0>:ud    r2.14<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $59
(W)     add3 (1|M0)              r5.3<1>:d     r6.2<0;0>:d       -r1.0<0;0>:d      -r10.0<0>:d      {I@2} //  ALU pipe: int; $47
(W)     mul (1|M0)               acc0.0<1>:ud  r5.2<0;1,0>:ud    r2.28<0;1,0>:uw                     //  ALU pipe: int; $59
(W)     shl (1|M0)               r7.0<1>:q     r5.3<0;1,0>:d     32:w               {I@2}            //  ALU pipe: int; $48
(W)     mach (1|M0)              r11.0<1>:d    r5.2<0;1,0>:ud    r2.14<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r2.2<2>:ud    r4.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $59
(W)     add (1|M0)               r9.0<1>:q     r7.0<0;1,0>:q     r7.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $53
(W)     mov (1|M0)               r2.3<2>:d     r11.0<0;1,0>:d                   {I@3}                //  ALU pipe: int; $63
(W)     mov (1|M0)               r4.0<1>:hf    0xFFFF:hf                              {I@3}          //  ALU pipe: float; $74
(W)     add (1|M0)               r1.0<1>:q     r9.0<0;1,0>:q     -r2.1<0;1,0>:q   {I@1}              //  ALU pipe: int; $64
(W)     mov (1|M0)               r9.2<1>:d     r5.2<0;1,0>:d                                         //  ALU pipe: int; $54
(W)     mov (2|M0)               r3.1<1>:d     r1.0<1;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $65
(W)     shl (1|M0)               r6.0<1>:q     r3.3<0;1,0>:d     32:w                                //  ALU pipe: int; $67
(W)     cmp (32|M0)   (ge)f0.0   null<1>:ud    r3.1<0;1,0>:ud    r2.14<0;1,0>:ud  {I@2}              //  ALU pipe: int; $69
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $70
(W&~f0.0) cmp (32|M0) (gt)f0.0   null<1>:ud    r3.2<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $72
(W&f0.0) sel (1|M0)              r7.2<1>:d     r4.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $74
(W)     add (1|M0)               r7.0<1>:q     r6.0<0;1,0>:q     r9.1<0;1,0>:q    {Compacted,I@5}    //  ALU pipe: int; $68
(W)     mov (1|M0)               r10.0<1>:q    r7.2<0;1,0>:d                    {I@2}                //  ALU pipe: int; $75
(W)     add (1|M0)               r31.5<1>:q    r7.0<0;1,0>:q     -r10.0<0;1,0>:q  {I@1}              //  ALU pipe: int; $76
(W)     jmpi                                 _0_042                                                  // $77
// B003: Preds:{B001},  Succs:{B004, B005}
_0_040:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r2.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $79
(W&~f1.0) jmpi                               _0_043                                                  //  ALU pipe: int; $80
// B004: Preds:{B003},  Succs:{B006}
_0_044:
(W)     mov (1|M0)               r31.3<1>:d    -1:w                                                  //  ALU pipe: int; $82
(W)     jmpi                                 _0_045                                                  // $83
// B005: Preds:{B003},  Succs:{B006}
_0_043:
(W)     mov (1|M0)               r1.0<2>:d     r31.3<0;1,0>:q                                        //  ALU pipe: int; $85
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $86
(W)     mov (1|M0)               r2.2<1>:f     r2.14<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $87
(W)     mov (1|M0)               r3.1<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $92
(W)     math.inv (1|M0)          r2.10<1>:f    r2.2<0;1,0>:f                    {F@2}                //  ALU pipe: math; $91
(W)     mov (1|M0)               r2.3<1>:f     r1.0<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $90
(W)     mad (1|M0)               r4.0<1>:f     r2.10<0;0>:f      r3.1<0;0>:f       r2.10<0>:f       {A@1} //  ALU pipe: float; $92
(W)     mov (1|M0)               r1.1<1>:ud    r2.2<0;1,0>:f                                         //  ALU pipe: int; $88
(W)     mov (1|M0)               r4.2<1>:ud    r2.3<0;1,0>:f                    {F@2}                //  ALU pipe: int; $94
(W)     mul (1|M0)               r4.1<1>:f     r2.3<0;1,0>:f     r4.0<0;1,0>:f    {F@1}              //  ALU pipe: float; $93
(W)     add (1|M0)               r2.8<1>:d     r2.14<0;1,0>:d    -r1.1<0;1,0>:d   {I@2}              //  ALU pipe: int; $89
(W)     add (1|M0)               r2.9<1>:d     r1.0<0;1,0>:d     -r4.2<0;1,0>:d   {I@2}              //  ALU pipe: int; $95
(W)     mov (1|M0)               r5.0<1>:ud    r4.1<0;1,0>:f                    {F@1}                //  ALU pipe: int; $96
(W)     mov (1|M0)               r6.0<1>:f     r2.8<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $97
(W)     mov (1|M0)               r6.1<1>:f     r2.9<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $97
(W)     mov (1|M0)               r5.1<1>:f     r5.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $99
(W)     mad (1|M0)               r1.1<1>:f     r2.3<0;0>:f       r5.1<0;0>:f       -r2.2<0>:f       {F@1} //  ALU pipe: float; $101
(W)     mad (1|M0)               r1.4<1>:f     r6.1<0;0>:f       r5.1<0;0>:f       -r6.0<0>:f        //  ALU pipe: float; $103
(W)     add (1|M0)               r7.0<1>:f     r1.1<0;1,0>:f     r1.4<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $104
(W)     mul (1|M0)               r8.0<1>:f     r4.0<0;1,0>:f     r7.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $105
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $106
(W)     mov (1|M0)               r3.1<1>:ud    r8.0<0;1,0>:f                    {A@1}                //  ALU pipe: int; $107
(W)     add (1|M0)               r3.2<1>:d     r3.1<0;1,0>:d     r5.0<0;1,0>:d    {I@1}              //  ALU pipe: int; $108
(W)     mul (1|M0)               acc0.0<1>:d   r3.2<0;1,0>:d     r2.28<0;1,0>:uw  {I@1}              //  ALU pipe: int; $109
(W)     macl (1|M0)              r9.0<1>:d     r3.2<0;1,0>:d     r2.14<0;1,0>:d   {Compacted}        //  ALU pipe: int; $110
(W)     add (1|M0)               r10.0<1>:d    r1.0<0;1,0>:d     -r9.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $110
(W)     cmp (1|M0)    (ge)f3.0   r12.0<1>:ud   r10.0<0;1,0>:ud   r2.14<0;1,0>:ud  {I@1}              //  ALU pipe: int; $111
(W)     add3 (1|M0)              r31.3<1>:d    r3.1<0;0>:d       r5.0<0;0>:d       -r12.0<0>:d      {I@1} //  ALU pipe: int; $112
// B006: Preds:{B005, B004},  Succs:{B007}
_0_045:
(W)     mov (1|M0)               r31.5<1>:q    r31.3<0;1,0>:ud                  {I@1}                //  ALU pipe: int; $114
// B007: Preds:{B006, B002},  Succs:{B008, B009}
_0_042:
(W)     mov (2|M0)               r31.12<1>:d   r31.10<1;1,0>:d                  {I@1}                //  ALU pipe: int; $116
        mov (32|M0)              r34.0<1>:d    r32.0<1;1,0>:uw                                       //  ALU pipe: int; $138
(W)     mul (1|M0)               acc0.0<1>:ud  r31.12<0;1,0>:ud  r2.28<0;1,0>:uw  {I@2}              //  ALU pipe: int; $117
(W)     macl (1|M0)              r33.0<1>:ud   r31.12<0;1,0>:ud  r2.14<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $118
(W)     mul (1|M0)               acc0.0<1>:ud  r31.12<0;1,0>:ud  r2.28<0;1,0>:uw                     //  ALU pipe: int; $118
(W)     mach (1|M0)              r1.0<1>:d     r31.12<0;1,0>:ud  r2.14<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r2.14<0;1,0>:ud   r31.26<0;1,0>:uw                    //  ALU pipe: int; $121
(W)     macl (1|M0)              r4.0<1>:d     r2.14<0;1,0>:ud   r31.13<0;1,0>:d                     //  ALU pipe: int; $123
(W)     mul (1|M0)               acc0.0<1>:ud  r2.14<0;1,0>:ud   r2.30<0;1,0>:uw                     //  ALU pipe: int; $124
(W)     macl (1|M0)              r5.0<1>:ud    r2.14<0;1,0>:ud   r2.15<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $125
(W)     mul (1|M0)               acc0.0<1>:ud  r2.14<0;1,0>:ud   r2.30<0;1,0>:uw                     //  ALU pipe: int; $125
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r31.8<0;1,0>:ud   r5.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $139
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r31.8<0;1,0>:ud   r5.0<0;1,0>:ud                      //  ALU pipe: int; $131
(W)     mach (1|M0)              r6.0<1>:d     r2.14<0;1,0>:ud   r2.15<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r2.8<2>:b     r31.5<0;1,0>:w                                        //  ALU pipe: int; $136
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r31.9<0;1,0>:d    r6.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $140
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r31.9<0;1,0>:d    r6.0<0;1,0>:d                       //  ALU pipe: int; $132
(W&~f2.0) cmp (32|M0) (lt)f2.0   null<1>:ud    r31.9<0;1,0>:ud   r6.0<0;1,0>:ud                      //  ALU pipe: int; $142
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:ud    r31.9<0;1,0>:ud   r6.0<0;1,0>:ud                      //  ALU pipe: int; $134
(W)     add (1|M0)               r31.14<1>:d   r1.0<0;1,0>:d     r4.0<0;1,0>:d                       //  ALU pipe: int; $123
(W)     mov (1|M0)               r31.15<1>:d   r2.8<0;1,0>:ub                   {I@6}                //  ALU pipe: int; $137
(W&f2.0) jmpi                                _0_046                                                  //  ALU pipe: int; $144
// B008: Preds:{B007},  Succs:{B025}
_0_047:
        mov (32|M0)              r36.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $148
(W)     mov (1|M0)               r33.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $146
(W)     mov (1|M0)               r33.4<1>:w    0:w                                                   //  ALU pipe: int; $147
(W)     jmpi                                 _0_048                                                  // $149
// B009: Preds:{B007},  Succs:{B010, B011}
_0_046:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r31.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $151
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r31.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $152
(W&~f0.0) jmpi                               _0_049                                                  //  ALU pipe: int; $154
// B010: Preds:{B009},  Succs:{B012}
_0_050:
(W)     mov (2|M0)               r38.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $156
(W)     mov (1|M0)               r33.3<1>:d    r2.14<0;1,0>:d                                        //  ALU pipe: int; $158
(W)     jmpi                                 _0_051                                                  // $159
// B011: Preds:{B009},  Succs:{B012}
_0_049:
(W)     mul (1|M0)               acc0.0<1>:ud  r31.12<0;1,0>:ud  0xC:uw                              //  ALU pipe: int; $162
(W)     mach (1|M0)              r4.0<1>:d     r31.12<0;1,0>:ud  0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.0<2>:ud    r31.12<0;1,0>:ud  0xC:uw                              //  ALU pipe: int; $161
(W)     mov (1|M0)               r1.1<2>:d     r4.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $166
(W)     add (1|M0)               r6.0<1>:q     r1.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $167
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r6:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $169
(W)     mov (1|M0)               r38.4<1>:d    r5.0<0;1,0>:d                    {Compacted,$2.dst}   //  ALU pipe: int; $170
(W)     mov (1|M0)               r38.5<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $171
(W)     mov (1|M0)               r33.3<1>:d    r5.2<0;1,0>:d                                         //  ALU pipe: int; $172
// B012: Preds:{B011, B010},  Succs:{B013, B014}
_0_051:
(W)     cmp (32|M0)   (gt)f3.0   null<1>:ud    r38.5<0;1,0>:ud   r2.14<0;1,0>:ud  {I@2}              //  ALU pipe: int; $174
(W&~f3.0) cmp (32|M0) (ge)f3.0   null<1>:ud    r38.4<0;1,0>:ud   r3.0<0;1,0>:ud                      //  ALU pipe: int; $175
(W&~f3.0) jmpi                               _0_052                                                  //  ALU pipe: int; $177
// B013: Preds:{B012},  Succs:{B025}
_0_053:
        mov (32|M0)              r36.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $181
(W)     mov (1|M0)               r33.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $179
(W)     mov (1|M0)               r33.4<1>:w    0:w                                                   //  ALU pipe: int; $180
(W)     jmpi                                 _0_048                                                  // $182
// B014: Preds:{B012},  Succs:{B015, B016}
_0_052:
(W)     mov (1|M0)               r1.0<1>:f     r33.0<0;1,0>:f                   {Compacted}          //  ALU pipe: float; $184
(W)     mov (1|M0)               r1.1<1>:d     r31.14<0;1,0>:d                                       //  ALU pipe: int; $185
(W)     cmp (32|M0)   (le)f2.0   null<1>:ud    r33.3<0;1,0>:ud   r2.14<0;1,0>:ud  {I@7}              //  ALU pipe: int; $191
(W)     add (1|M0)               r33.2<1>:q    r31.3<0;1,0>:q    -r1.0<0;1,0>:q   {A@1}              //  ALU pipe: int; $188
(W)     add (1|M0)               r2.2<1>:d     r2.14<0;1,0>:d    -r38.5<0;1,0>:d                     //  ALU pipe: int; $190
(W)     cmp (32|M0)   (gt)f0.0   null<1>:ud    r33.3<0;1,0>:ud   r33.4<0;1,0>:ud  {I@2}              //  ALU pipe: int; $194
(W&f2.0) cmp (32|M0)  (le)f2.0   null<1>:ud    r33.3<0;1,0>:ud   r2.2<0;1,0>:ud   {I@2}              //  ALU pipe: int; $192
(W)     mov (1|M0)               r3.1<1>:ud    f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $195
(W)     and (1|M0)               f3.0<1>:ud    f2.0<0;1,0>:ud    r3.1<0;1,0>:ud   {I@1}              //  ALU pipe: int; $195
(W&f3.0) jmpi                                _0_054                                                  //  ALU pipe: int; $196
// B015: Preds:{B014},  Succs:{B025}
_0_055:
        mov (32|M0)              r36.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $200
(W)     mov (1|M0)               r1.0<1>:w     1:w                                                   //  ALU pipe: int; $198
(W)     mov (1|M0)               r33.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $199
(W&f2.0) sel (1|M0)              r33.4<1>:w    r1.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $198
(W)     jmpi                                 _0_048                                                  // $201
// B016: Preds:{B014},  Succs:{B017, B018}
_0_054:
(W)     mul (1|M0)               acc0.0<1>:ud  r38.4<0;1,0>:ud   r2.28<0;1,0>:uw                     //  ALU pipe: int; $204
(W)     macl (1|M0)              r4.0<1>:ud    r38.4<0;1,0>:ud   r2.14<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $205
(W)     mul (1|M0)               acc0.0<1>:ud  r38.4<0;1,0>:ud   r2.28<0;1,0>:uw                     //  ALU pipe: int; $205
(W)     mach (1|M0)              r5.0<1>:d     r38.4<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r1.4<2>:ud    r4.0<0;1,0>:ud                   {Compacted,I@3}      //  ALU pipe: int; $205
(W)     mov (1|M0)               r1.5<2>:d     r5.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $209
(W)     mov (2|M0)               r1.0<1>:d     r2.12<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $203
(W)     add (1|M0)               r2.1<1>:q     r1.2<0;1,0>:q     r38.5<0;1,0>:ud  {I@2}              //  ALU pipe: int; $211
        shl (32|M0)              r8.0<1>:d     r34.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $230
(W)     add (1|M0)               r3.1<1>:q     r2.1<0;1,0>:q     r33.2<0;1,0>:q   {I@2}              //  ALU pipe: int; $212
(W)     mul (1|M0)               r6.2<1>:d     r31.15<0;1,0>:d   1536:w                              //  ALU pipe: int; $214
(W)     mov (2|M0)               r6.0<1>:d     r3.2<1;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $213
(W)     add (1|M0)               r33.6<1>:d    r6.2<0;1,0>:d     1536:w               {I@2}          //  ALU pipe: int; $215
(W)     mul (1|M0)               acc0.0<1>:ud  r6.0<0;1,0>:ud    r1.0<0;1,0>:uw   {I@2}              //  ALU pipe: int; $216
(W)     macl (1|M0)              r38.0<1>:ud   r6.0<0;1,0>:ud    r1.0<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $217
(W)     mul (1|M0)               acc0.0<1>:ud  r6.0<0;1,0>:ud    r1.0<0;1,0>:uw                      //  ALU pipe: int; $217
        or (32|M0)               r40.0<1>:d    r8.0<1;1,0>:d     r6.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $231
(W)     mach (1|M0)              r4.0<1>:d     r6.0<0;1,0>:ud    r1.0<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r6.0<0;1,0>:ud    r1.2<0;1,0>:uw                      //  ALU pipe: int; $218
(W)     macl (1|M0)              r7.0<1>:d     r6.0<0;1,0>:ud    r1.1<0;1,0>:d                       //  ALU pipe: int; $219
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r40.0<1;1,0>:ud   r33.6<0;1,0>:ud  {I@4}              //  ALU pipe: int; $232
(W)     mul (1|M0)               acc0.0<1>:d   r1.0<0;1,0>:ud    r6.2<0;1,0>:uw                      //  ALU pipe: int; $220
(W)     add (1|M0)               r4.0<1>:d     r4.0<0;1,0>:d     r7.0<0;1,0>:d    {Compacted,I@3}    //  ALU pipe: int; $219
(W)     macl (1|M0)              r7.0<1>:d     r1.0<0;1,0>:ud    r6.1<0;1,0>:d                       //  ALU pipe: int; $222
(W)     mul (1|M0)               acc0.0<1>:ud  r31.12<0;1,0>:ud  0x3000:uw                           //  ALU pipe: int; $224
(W)     mach (1|M0)              r5.0<1>:d     r31.12<0;1,0>:ud  0x3000:ud                           //  ALU pipe: int; 
(W)     mul (1|M0)               r33.8<1>:ud   r31.12<0;1,0>:ud  0x3000:uw                           //  ALU pipe: int; $223
(W)     add (1|M0)               r33.7<1>:d    r4.0<0;1,0>:d     r7.0<0;1,0>:d    {I@4}              //  ALU pipe: int; $222
(W)     mov (1|M0)               r33.9<1>:d    r5.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $229
(f2.0)  goto (32|M0)                         _0_056            _0_056                                //  ALU pipe: int; $233
// B017: [inDivergent],  Preds:{B016},  Succs:{B025}
_0_057:
        mov (32|M0)              r36.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $237
(W)     mov (1|M0)               r33.1<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $235
(W)     mov (1|M0)               r33.4<1>:w    1:w                                                   //  ALU pipe: int; $236
        goto (32|M0)                         _0_056            _0_048                                // $238
// B018: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_056:
        join (32|M0)                         _0_048                                                  // 
L2944:
        mov (32|M0)              r36.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $250
(W)     mov (1|M0)               r1.0<1>:d     r38.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $240
(W)     mov (1|M0)               r1.1<1>:d     r33.7<0;1,0>:d                   {I@7}                //  ALU pipe: int; $241
(W)     mov (1|M0)               r2.2<1>:d     r33.8<0;1,0>:d                                        //  ALU pipe: int; $245
(W)     mov (1|M0)               r2.3<1>:d     r33.9<0;1,0>:d                   {I@7}                //  ALU pipe: int; $246
(W)     add (1|M0)               r33.5<1>:q    r1.0<0;1,0>:q     r1.1<0;1,0>:q    {I@3}              //  ALU pipe: int; $244
(W)     add (1|M0)               r33.6<1>:q    r2.1<0;1,0>:q     r1.3<0;1,0>:q    {I@2}              //  ALU pipe: int; $249
// B019: [inDivergent],  Preds:{B023, B018},  Succs:{B020, B023}
_0_058:
        add (32|M0)              r4.0<1>:d     r40.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $252
        sel (32|M0)   (lt)f0.0   r42.0<1>:ud   r4.0<1;1,0>:ud    r33.6<0;1,0>:ud  {I@1}              //  ALU pipe: int; $253
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r40.0<1;1,0>:ud   r42.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $254
(~f3.0) goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $255
// B020: [inDivergent],  Preds:{B019},  Succs:{B021}
_0_060:
        mov (32|M0)              r44.0<1>:f    r40.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $257
// B021: [inDivergent],  Preds:{B022, B020},  Succs:{B022, B023}
_0_061:
        shl (32|M0)              r4.0<1>:d     r44.0<1;1,0>:d    1:w               {Compacted,F@1}   //  ALU pipe: int; $264
        shl (32|M0)              r6.0<1>:d     r44.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $259
        mov (16|M0)              r8.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $266
        mov (16|M16)             r10.0<2>:ud   r5.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $266
        add (16|M0)              r16.0<1>:q    r33.6<0;1,0>:q    r8.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $266
        add (16|M16)             r18.0<1>:q    r33.6<0;1,0>:q    r10.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $266
        mov (16|M0)              r12.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $261
        mov (16|M16)             r14.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $261
        load.ugm.d16u32.a64 (32|M0)  r24:2      [r16:4]            {I@3,$3} // ex_desc:0x0; desc:0x8200B80 // $268
        add (16|M0)              r20.0<1>:q    r33.5<0;1,0>:q    r12.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $261
        add (16|M16)             r22.0<1>:q    r33.5<0;1,0>:q    r14.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $261
        load.ugm.d32.a64 (32|M0)  r26:2         [r20:4]            {I@1,$4} // ex_desc:0x0; desc:0x8200580 // $263
        add (32|M0)              r46.0<1>:d    r44.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $272
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r46.0<1;1,0>:ud   r42.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $273
        shl (32|M0)              r28.0<1>:d    r24.0<1;1,0>:ud   16:w               {$3.dst}         //  ALU pipe: int; $269
        sync.nop                             null                             {Compacted,I@1}        // $270
        mul (32|M0)              acc0.0<1>:f   r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,$4.dst} //  ALU pipe: float; $270
        add (32|M0)              r36.0<1>:f    r36.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $271
(~f0.0) goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $274
// B022: [inDivergent],  Preds:{B021},  Succs:{B021}
_0_062:
        mov (32|M0)              r44.0<1>:f    r46.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $276
(W)     jmpi                                 _0_061                                                  // $277
// B023: [inDivergent],  Preds:{B021, B019},  Succs:{B024, B019}
_0_059:
        join (32|M0)                         _0_063                                                  // 
L3368:
        add (32|M0)              r40.0<1>:d    r40.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $279
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r40.0<1;1,0>:ud   r33.6<0;1,0>:ud  {I@1}              //  ALU pipe: int; $280
(f2.0)  goto.b (32|M0)                       _0_063            _0_058                                //  ALU pipe: int; $281
// B024: [inDivergent],  Preds:{B023},  Succs:{B025}
_0_063:
        join (32|M0)                         _0_048                                                  // 
L3424:
(W)     mov (1|M0)               r33.1<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $283
(W)     mov (1|M0)               r33.4<1>:hf   0x1:hf                                                //  ALU pipe: float; $284
// B025: Preds:{B024, B017, B015, B013, B008},  Succs:{B026, B027}
_0_048:
        join (32|M0)                         L3464                                                   // 
L3464:
        add (32|M0)              r4.0<1>:d     r34.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $286
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $287
        shl (32|M0)              r8.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $288
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $289
        add (16|M0)              a0.0<1>:uw    r8.0<1;1,0>:uw    0x900:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0201(r36.0:f); $290
        add (32|M0)              r12.0<1>:d    r34.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $299
        mov (16|M0)              r10.0<1>:ud   r[a0.0]<1,0>:ud                  {F@3}                //  ALU pipe: int; $291
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $292
        add (16|M16)             a0.0<1>:uw    r8.16<1;1,0>:uw   0x900:uw                            //  ALU pipe: int; src1 is addr of V0201(r36.0:f); $293
        and (32|M0)   (eq)f0.0   null<1>:d     r34.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $295
        and (32|M0)              r4.0<1>:d     r12.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $300
        mov (16|M16)             r11.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $294
        shl (32|M0)              r9.0<1>:uw    r4.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $301
(f0.0)  sel (32|M0)              acc0.0<1>:f   r10.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $297
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $302
        add (16|M0)              a0.0<1>:uw    r9.0<1;1,0>:uw    0xC00:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0300(r48.0:f); $303
        add (32|M0)              r48.0<1>:f    r36.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $298
        add (32|M0)              r10.0<1>:d    r34.0<1;1,0>:d    4:w               {Compacted,F@2}   //  ALU pipe: int; $312
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $304
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $305
        add (16|M16)             a0.0<1>:uw    r9.16<1;1,0>:uw   0xC00:uw                            //  ALU pipe: int; src1 is addr of V0300(r48.0:f); $306
        and (32|M0)   (eq)f3.0   null<1>:d     r34.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $308
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $313
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $307
        shl (32|M0)              r8.0<1>:uw    r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $314
(f3.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $310
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $315
        add (16|M0)              a0.0<1>:uw    r8.0<1;1,0>:uw    0xC80:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0308(r50.0:f); $316
        add (32|M0)              r50.0<1>:f    r48.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $311
        add (32|M0)              r6.0<1>:d     r34.0<1;1,0>:d    8:w               {Compacted,F@2}   //  ALU pipe: int; $325
        mov (16|M0)              r4.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $317
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $318
        add (16|M16)             a0.0<1>:uw    r8.16<1;1,0>:uw   0xC80:uw                            //  ALU pipe: int; src1 is addr of V0308(r50.0:f); $319
        and (32|M0)   (eq)f2.0   null<1>:d     r34.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $321
        and (32|M0)              r10.0<1>:d    r6.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $326
        mov (16|M16)             r5.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $320
        shl (32|M0)              r9.0<1>:uw    r10.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $327
(f2.0)  sel (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $323
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $328
        add (16|M0)              a0.0<1>:uw    r9.0<1;1,0>:uw    0xD00:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0316(r52.0:f); $329
        add (32|M0)              r52.0<1>:f    r50.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $324
        add (32|M0)              r4.0<1>:d     r34.0<1;1,0>:d    16:w               {Compacted,F@2}  //  ALU pipe: int; $338
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $330
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $331
        add (16|M16)             a0.0<1>:uw    r9.16<1;1,0>:uw   0xD00:uw                            //  ALU pipe: int; src1 is addr of V0316(r52.0:f); $332
        and (32|M0)   (eq)f0.0   null<1>:d     r34.0<1;1,0>:d    15:w                                //  ALU pipe: int; $334
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $339
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $333
        shl (32|M0)              r8.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $340
        cmp (32|M0)   (eq)f2.0   null<2>:w     r32.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $350
        cmp (32|M0)   (eq)f3.0   null<2>:w     r32.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $347
(f0.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@4}    //  ALU pipe: float; $336
(W)     mov (1|M0)               r1.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $348
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $341
        add (16|M0)              a0.0<1>:uw    r8.0<1;1,0>:uw    0xD80:uw              {I@4}         //  ALU pipe: int; src1 is addr of V0324(r54.0:f); $342
        add (32|M0)              r54.0<1>:f    r52.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $337
(f1.0)  sel (32|M0)              r4.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw              {F@2}           //  ALU pipe: int; $351
(f2.0)  sel (32|M0)              r5.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $351
(f3.0)  sel (32|M0)              r10.0<1>:uw   r1.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $348
        mov (16|M0)              r56.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $343
        and (32|M0)   (ne)f3.0   null<2>:uw    r4.0<1;1,0>:uw    r5.0<1;1,0>:uw   {I@3}              //  ALU pipe: int; $351
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $344
        add (16|M16)             a0.0<1>:uw    r8.16<1;1,0>:uw   0xD80:uw                            //  ALU pipe: int; src1 is addr of V0324(r54.0:f); $345
(f1.0)  sel (32|M0)              r9.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $348
        and (32|M0)   (ne)f0.0   null<2>:uw    r9.0<1;1,0>:uw    r10.0<1;1,0>:uw  {I@1}              //  ALU pipe: int; $348
(W)     mov (1|M0)               r33.14<1>:d   r31.8<0;1,0>:ub                                       //  ALU pipe: int; $349
        mov (16|M16)             r57.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $346
(~f3.0) goto (32|M0)                         _0_064            _0_064                                //  ALU pipe: int; $352
// B026: [inDivergent],  Preds:{B025},  Succs:{B027}
_0_065:
        cmp (32|M0)   (eq)f2.0   null<2>:w     r32.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $354
(W)     shl (1|M0)               r1.0<1>:d     r33.14<0;1,0>:d   1:w               {Compacted,I@4}   //  ALU pipe: int; $359
(W)     mov (1|M0)               r2.2<1>:d     504:w                               {Compacted}       //  ALU pipe: int; $360
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r33.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $357
(f2.0)  sel (32|M0)              acc0.0<1>:f   r56.0<1;1,0>:f    0x80000000:f               {I@6}    //  ALU pipe: float; $355
(W)     bfn.(s0&s1|s2) (1|M0)    r3.1<1>:ud    r1.0<0;0>:ud      r2.2<0;0>:ud      r31.15<0>:ud     {I@2} //  ALU pipe: int; $361
        add (32|M0)              acc0.0<1>:f   r54.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $356
(W)     shl (1|M0)               r6.0<1>:d     r3.1<0;1,0>:d     2:w               {Compacted,I@1}   //  ALU pipe: int; $362
(f1.0)  sel (32|M0)              r4.0<1>:f     acc0.0<1;1,0>:f   0x7FC00000:f                        //  ALU pipe: float; $358
        mov (32|M0)              r8.0<1>:f     r6.0<0;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $363
        store.slm.d32.a32 (32|M0)  [r8:2]       r4:2               {F@1,$5} // ex_desc:0x0; desc:0x4000504 // $364
// B027: Preds:{B026, B025},  Succs:{B028, B032}
_0_064:
        join (32|M0)                         L4592                                                   // 
L4592:
        sync.nop                             null                             {Compacted,$5.src}     // $366
(W)     send.slm (1|M0)          r4       r30  null:0  0x0            0x0210001F           {$6} // wr:1+0, rd:1; fence.slm.none.group // $366
(W)     mov (1|M0)               r5.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $367
(W)     mov (2|M0)               r5.10<1>:ub   r30.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $367
(W)     mov (8|M0)               null<1>:ud    r4.0<1;1,0>:ud                   {Compacted,$6.dst}   //  memory fence commit; ALU pipe: int; $367
(W)     send.gtwy (1|M0)         null     r5  null:0  0x0            0x02000004           {I@2,$7} // wr:1+0, rd:0; signal barrier // $367
(W)     sync.bar                             0x0                                                     // $367
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r31.15<0;1,0>:d   0:w                                 //  ALU pipe: int; $368
(W)     mov (1|M0)               r1.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $369
(f0.0)  sel (32|M0)              r6.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $369
(f2.0)  sel (32|M0)              r7.0<1>:uw    r1.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $369
        and (32|M0)   (ne)f3.0   null<2>:uw    r6.0<1;1,0>:uw    r7.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $369
(~f3.0) goto (32|M0)                         _0_066            _0_066                                //  ALU pipe: int; $370
// B028: [inDivergent],  Preds:{B027},  Succs:{B029, B030}
_0_067:
(W)     shl (1|M0)               r1.0<1>:d     r33.14<0;1,0>:d   3:w               {Compacted}       //  ALU pipe: int; $372
(W)     mov (1|M0)               r4.0<1>:f     r1.0<0;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $373
(W)     or (1|M0)                r5.0<1>:d     r1.0<0;1,0>:d     8:w               {Compacted,$7.src} //  ALU pipe: int; $375
(W)     or (1|M0)                r6.0<1>:d     r1.0<0;1,0>:d     12:w               {Compacted}      //  ALU pipe: int; $377
(W)     load.slm.d32x2t.a32 (1|M0)  r7:1        [r4:1]             {F@1,$8} // ex_desc:0x0; desc:0x2109500 // $374
(W)     load.slm.d32x1t.a32 (1|M0)  r8:1        [r5:1]             {I@2,$9} // ex_desc:0x0; desc:0x2108500 // $376
(W)     load.slm.d32x1t.a32 (1|M0)  r9:1        [r6:1]             {I@1,$10} // ex_desc:0x0; desc:0x2108500 // $378
(W)     add (1|M0)               r2.2<1>:f     r7.0<0;1,0>:f     r7.1<0;1,0>:f    {Compacted,$8.dst} //  ALU pipe: float; $379
        sync.nop                             null                             {Compacted,$10.dst}    // $380
(W)     add (1|M0)               r2.3<1>:f     r8.0<0;1,0>:f     r9.0<0;1,0>:f    {$9.dst}           //  ALU pipe: float; $380
(W)     add (1|M0)               r33.15<1>:f   r2.2<0;1,0>:f     r2.3<0;1,0>:f    {F@1}              //  ALU pipe: float; $381
(W)     and (1|M0)               r3.1<1>:d     r33.15<0;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $382
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r3.1<0;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $383
(W&f2.0) jmpi                                _0_068                                                  //  ALU pipe: int; $384
// B029: [inDivergent],  Preds:{B028},  Succs:{B031}
_0_069:
(W)     shr (1|M0)               r1.0<1>:ud    r33.15<0;1,0>:ud  16:w                                //  ALU pipe: int; $386
(W)     and (1|M0)               r2.2<1>:d     r1.0<0;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $387
(W)     add3 (1|M0)              r3.1<1>:d     r2.2<0;0>:d       r33.15<0;0>:d     32767:w               {I@1} //  ALU pipe: int; $388
(W)     shr (1|M0)               r4.0<1>:ud    r3.1<0;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $389
(W)     mov (1|M0)               r58.0<2>:w    r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $390
(W)     jmpi                                 _0_070                                                  // $391
// B030: [inDivergent],  Preds:{B028},  Succs:{B031}
_0_068:
(W)     shr (1|M0)               r1.0<1>:ud    r33.15<0;1,0>:ud  16:w                                //  ALU pipe: int; $393
(W)     or (1|M0)                r58.0<1>:w    r1.0<0;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $395
// B031: [inDivergent],  Preds:{B030, B029},  Succs:{B032}
_0_070:
(W)     shl (1|M0)               r1.0<1>:q     r31.3<0;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $397
(W)     mov (1|M0)               r6.0<1>:ud    r58.0<0;1,0>:uw                  {I@2}                //  ALU pipe: int; $400
(W)     add (1|M0)               r4.0<1>:q     r1.0<0;1,0>:q     r2.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $398
(W)     store.ugm.d16u32.a64 (1|M0)  [r4:2]     r6:1               {I@1,$11} // ex_desc:0x0; desc:0x4000B84 // $401
// B032: Preds:{B031, B027},  Succs:{B033, B034}
_0_066:
        join (32|M0)                         L5144                                                   // 
L5144:
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r31.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $406
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r31.8<0;1,0>:d    r33.0<0;1,0>:d                      //  ALU pipe: int; $403
(W&~f1.0) cmp (32|M0) (ne)f1.0   null<1>:d     r31.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $407
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r31.9<0;1,0>:d    r31.14<0;1,0>:d                     //  ALU pipe: int; $404
(W)     mov (1|M0)               r1.0<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $409
(W)     mov (1|M0)               r2.4<1>:hf    0x1:hf                                                //  ALU pipe: float; $410
(W)     and (1|M0)               f1.0<1>:ud    f2.0<0;1,0>:ud    r1.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $409
        sync.nop                             null                             {Compacted,F@1}        // $410
        sync.nop                             null                             {Compacted,$11.src}    // $410
(f0.0)  sel (32|M0)              r5.0<1>:uw    r2.4<0;1,0>:uw    0x0:uw              {$7.src}        //  ALU pipe: int; $410
(f1.0)  sel (32|M0)              r4.0<1>:uw    r2.4<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $410
        and (32|M0)   (ne)f3.0   null<2>:uw    r4.0<1;1,0>:uw    r5.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $410
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r31.15<0;1,0>:d   0:w                                 //  ALU pipe: int; $411
(~f3.0) goto (32|M0)                         _0_071            _0_071                                //  ALU pipe: int; $413
// B033: [inDivergent],  Preds:{B032},  Succs:{B034}
_0_072:
(W)     mov (1|M0)               r1.0<2>:b     r33.4<0;1,0>:w                                        //  ALU pipe: int; $415
(W)     mov (1|M0)               r3.2<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $418
(W)     mov (1|M0)               r2.4<1>:w     r1.0<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $416
(W)     shl (1|M0)               r5.0<1>:q     r31.5<0;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $420
(W)     cmp (32|M0)   (eq)f3.0   null<2>:w     r2.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $417
(W)     and (1|M0)               r5.2<1>:d     r5.0<0;1,0>:d     -4:w               {Compacted,I@2}  //  ALU pipe: int; $421
(W)     and (1|M0)               r5.3<1>:d     r5.1<0;1,0>:d     3:w                                 //  ALU pipe: int; $422
(W&f3.0) sel (1|M0)              r4.0<1>:d     r3.2<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $418
(W)     add (1|M0)               r8.0<1>:q     r5.1<0;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $423
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $419
(W)     store.ugm.d32x1t.a64 (1|M0)  [r8:1]     r6:1               {I@1,$12} // ex_desc:0x0; desc:0x2008584 // $425
// B034: Preds:{B033, B032},  Succs:{}
_0_071:
        join (32|M0)                         L5504                                                   // 
L5504:
(W)     mov (16|M0)              r127.0<1>:f   r30.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $427
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$13} // wr:1+0, rd:0; end of thread // $427
L5528:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x25:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 3
//


//.numALUInst: 353
//.accSubDef: 7
//.accSubUse: 7
//.accSubCandidateDef: 7
//.accSubCandidateUse: 7
//
//
//.singlePipeAtOneDistNum: 68
//.allAtOneDistNum: 9
//.syncInstCount: 5
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 9
//.AfterReadTokenDepCount: 4
