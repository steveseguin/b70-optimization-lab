//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE0ELj6144ELj1ELj4ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 39 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 39 -GRFBumpUpNumber 2 "
//.instCount 403
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r91.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r91.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r91.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.1)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.13)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r92.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.2)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r93.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=16 words (r91.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r1.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0068 (78)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r1.8)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r92.1)
//.declare V0070 (80)  rf=r size=8 type=d align=2 words (r92.4)
//.declare V0071 (81)  rf=r size=8 type=d alias=V0069+0 align=4 words (r92.2)
//.declare P01 (82)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0072 (83)  rf=r size=8 type=ud alias=V0070+0 align=2 words (r92.4)
//.declare V0073 (84)  rf=r size=4 type=f align=2 words (r1.2)
//.declare V0074 (85)  rf=r size=4 type=ud alias=V0050+0 align=2 words (r2.12)
//.declare V0075 (86)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0076 (87)  rf=r size=8 type=df align=4 words (r3.0)
//.declare V0077 (88)  rf=r size=8 type=df align=4 words (r4.0)
//.declare V0078 (89)  rf=r size=8 type=df align=4 words (r6.0)
//.declare V0079 (90)  rf=r size=8 type=df align=4 words (r5.0)
//.declare V0080 (91)  rf=r size=8 type=df align=4 words (r9.0)
//.declare V0082 (93)  rf=r size=8 type=df align=4 words (r10.0)
//.declare V0084 (95)  rf=r size=8 type=df align=4 words (r11.0)
//.declare V0086 (97)  rf=r size=8 type=df align=4 words (r12.0)
//.declare V0087 (98)  rf=r size=4 type=d align=4 words (r13.0)
//.declare V0088 (99)  rf=r size=4 type=ud alias=V0087+0 align=2 words (r13.0)
//.declare V0089 (100)  rf=r size=4 type=d align=32 words (r15.0)
//.declare V0090 (101)  rf=r size=4 type=d align=2 words (r16.0)
//.declare V0092 (103)  rf=r size=8 type=df align=4 words (r18.0)
//.declare V0093 (104)  rf=r size=4 type=ud alias=V0090+0 align=2 words (r16.0)
//.declare V0094 (105)  rf=r size=8 type=df align=4 words (r19.0)
//.declare V0096 (107)  rf=r size=8 type=df align=4 words (r22.0)
//.declare V0097 (108)  rf=r size=8 type=df align=4 words (r21.0)
//.declare V0098 (109)  rf=r size=8 type=df align=4 words (r23.0)
//.declare V0099 (110)  rf=r size=8 type=q align=4 words (r24.0)
//.declare V0100 (111)  rf=r size=8 type=uq alias=V0099+0 align=4 words (r24.0)
//.declare V0101 (112)  rf=r size=4 type=d align=2 words (r25.0)
//.declare V0102 (113)  rf=r size=8 type=d alias=V0099+0 align=4 words (r24.0)
//.declare P02 (115)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0104 (116)  rf=r size=4 type=d align=2 words (r26.0)
//.declare V0105 (117)  rf=r size=4 type=d align=2 words (r27.0)
//.declare V0106 (118)  rf=r size=8 type=q align=4 words (r28.0)
//.declare V0108 (120)  rf=r size=8 type=q align=4 words (r29.0)
//.declare V0109 (121)  rf=r size=8 type=d alias=V0108+0 align=4 words (r29.0)
//.declare V0110 (122)  rf=r size=8 type=q align=4 words (r30.0)
//.declare V0112 (124)  rf=r size=8 type=q align=4 words (r31.0)
//.declare V0113 (125)  rf=r size=8 type=d alias=V0112+0 align=4 words (r31.0)
//.declare V0114 (126)  rf=r size=8 type=q align=4 words (r33.0)
//.declare V0115 (127)  rf=r size=4 type=ud alias=V0101+0 align=2 words (r25.0)
//.declare V0116 (128)  rf=r size=8 type=ud alias=V0114+0 align=4 words (r33.0)
//.declare V0117 (129)  rf=r size=8 type=d alias=V0114+0 align=4 words (r33.0)
//.declare V0118 (130)  rf=r size=4 type=d align=32 words (r34.0)
//.declare V0120 (132)  rf=r size=8 type=q align=4 words (r35.0)
//.declare V0121 (133)  rf=r size=8 type=d align=2 words (r36.0)
//.declare V0122 (134)  rf=r size=8 type=d alias=V0120+0 align=4 words (r35.0)
//.declare V0123 (135)  rf=r size=4 type=d align=2 words (r37.0)
//.declare V0124 (136)  rf=r size=8 type=q align=4 words (r38.0)
//.declare V0125 (137)  rf=r size=8 type=q align=4 words (r39.0)
//.declare P03 (138)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0126 (139)  rf=r size=8 type=ud alias=V0121+0 align=2 words (r36.0)
//.declare P04 (140)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P05 (141)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0127 (142)  rf=r size=8 type=q align=4 words (r42.0)
//.declare V0128 (143)  rf=r size=8 type=q align=4 words (r41.0)
//.declare V0129 (144)  rf=r size=8 type=d alias=V0128+0 align=4 words (r41.0)
//.declare V0130 (145)  rf=r size=8 type=q align=4 words (r92.3)
//.declare P06 (146)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0131 (147)  rf=r size=4 type=d align=2 words (r92.8)
//.declare V0132 (148)  rf=r size=4 type=d align=4 words (r1.2)
//.declare V0133 (149)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0134 (150)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0135 (151)  rf=r size=4 type=ud alias=V0134+0 align=2 words (r3.0)
//.declare V0136 (152)  rf=r size=4 type=d alias=+0 align=2 words (r4.0)
//.declare V0137 (153)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0138 (154)  rf=r size=4 type=ud alias=V0132+0 align=2 words (r1.2)
//.declare V0139 (155)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0140 (156)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0141 (157)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0142 (158)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0143 (159)  rf=r size=4 type=ud alias=V0142+0 align=2 words (r10.0)
//.declare V0144 (160)  rf=r size=4 type=d alias=+4 align=2 words (r4.1)
//.declare V0145 (161)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0146 (162)  rf=r size=4 type=ud alias=V0145+0 align=2 words (r11.0)
//.declare V0147 (163)  rf=r size=4 type=f alias=+0 align=2 words (r12.0)
//.declare V0148 (164)  rf=r size=4 type=ud alias=V0136+0 align=2 words (r4.0)
//.declare V0149 (165)  rf=r size=4 type=f alias=+4 align=2 words (r12.1)
//.declare V0150 (166)  rf=r size=4 type=ud alias=V0144+0 align=2 words (r4.1)
//.declare V0151 (167)  rf=r size=4 type=f align=2 words (r13.0)
//.declare V0153 (169)  rf=r size=4 type=f align=2 words (r14.0)
//.declare V0155 (171)  rf=r size=4 type=f align=2 words (r15.0)
//.declare V0156 (172)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0157 (173)  rf=r size=4 type=f align=2 words (r17.0)
//.declare V0158 (174)  rf=r size=4 type=d align=2 words (r18.0)
//.declare V0159 (175)  rf=r size=4 type=ud alias=V0158+0 align=2 words (r18.0)
//.declare V0160 (176)  rf=r size=4 type=d align=2 words (r19.0)
//.declare V0161 (177)  rf=r size=4 type=d align=32 words (r20.0)
//.declare V0162 (178)  rf=r size=4 type=d align=2 words (r21.0)
//.declare V0163 (179)  rf=r size=4 type=d align=2 words (r22.0)
//.declare V0164 (180)  rf=r size=4 type=ud alias=V0162+0 align=2 words (r21.0)
//.declare V0165 (181)  rf=r size=4 type=ud alias=V0163+0 align=2 words (r22.0)
//.declare  (182)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0166 (183)  rf=r size=4 type=ud alias=V0131+0 align=2 words (r92.8)
//.declare V0167 (184)  rf=r size=8 type=d align=2 words (r92.9)
//.declare V0168 (185)  rf=r size=8 type=d alias=V0130+0 align=4 words (r92.6)
//.declare V0169 (186)  rf=r size=4 type=d align=32 words (r94.0)
//.declare V0170 (187)  rf=r size=4 type=d align=2 words (r92.11)
//.declare V0171 (188)  rf=r size=4 type=ud alias=V0169+0 align=2 words (r94.0)
//.declare V0172 (189)  rf=r size=8 type=ud alias=V0167+0 align=2 words (r92.9)
//.declare V0173 (190)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0175 (192)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0176 (193)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0178 (195)  rf=r size=4 type=ud alias=V0176+0 align=2 words (r4.0)
//.declare V0179 (196)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r2.13)
//.declare V0180 (197)  rf=r size=4 type=d align=32 words (r5.0)
//.declare P07 (200)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P08 (201)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P09 (202)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0184 (204)  rf=r size=128 type=d align=32 words (r95.0)
//.declare V0185 (205)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r93.0)
//.declare P10 (206)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P11 (207)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P12 (208)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0186 (209)  rf=r size=4 type=d align=2 words (r92.12)
//.declare V0187 (210)  rf=r size=2 type=w align=1 words (r92.26)
//.declare V0188 (211)  rf=r size=128 type=f align=32 words (r97.0)
//.declare P13 (212)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P14 (213)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0189 (214)  rf=r size=4 type=d alias=+0 align=2 words (r94.8)
//.declare V0190 (215)  rf=r size=4 type=d alias=+4 align=2 words (r94.9)
//.declare V0191 (216)  rf=r size=4 type=d align=2 words (r92.14)
//.declare V0192 (217)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0193 (218)  rf=r size=8 type=ud alias=V0192+0 align=4 words (r1.2)
//.declare V0194 (219)  rf=r size=8 type=d alias=V0192+0 align=4 words (r1.2)
//.declare V0195 (220)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0199 (224)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0200 (225)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P15 (226)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0201 (227)  rf=r size=4 type=ud alias=V0190+0 align=2 words (r94.9)
//.declare P16 (228)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0202 (229)  rf=r size=4 type=ud alias=V0189+0 align=2 words (r94.8)
//.declare V0203 (230)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r2.14)
//.declare V0205 (232)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0206 (233)  rf=r size=8 type=d alias=V0205+0 align=4 words (r1.2)
//.declare V0207 (234)  rf=r size=8 type=q align=4 words (r94.1)
//.declare V0209 (236)  rf=r size=4 type=d align=2 words (r2.0)
//.declare P17 (237)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0210 (238)  rf=r size=4 type=ud alias=V0191+0 align=2 words (r92.14)
//.declare P18 (239)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0211 (240)  rf=r size=4 type=ud alias=V0209+0 align=2 words (r2.0)
//.declare P19 (241)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P20 (243)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0213 (244)  rf=r size=8 type=d align=2 words (r1.2)
//.declare V0214 (245)  rf=r size=8 type=d alias=V0049+0 align=4 words (r2.10)
//.declare V0215 (246)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0216 (247)  rf=r size=8 type=ud alias=V0215+0 align=4 words (r3.0)
//.declare V0217 (248)  rf=r size=8 type=d alias=V0215+0 align=4 words (r3.0)
//.declare V0218 (249)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0221 (252)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0222 (253)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0223 (254)  rf=r size=8 type=d align=2 words (r7.0)
//.declare V0224 (255)  rf=r size=8 type=d alias=V0222+0 align=4 words (r6.0)
//.declare V0225 (256)  rf=r size=8 type=q align=4 words (r9.0)
//.declare V0226 (257)  rf=r size=8 type=ud alias=V0223+0 align=2 words (r7.0)
//.declare V0227 (258)  rf=r size=8 type=ud alias=V0213+0 align=2 words (r1.2)
//.declare V0228 (259)  rf=r size=8 type=ud alias=V0225+0 align=4 words (r9.0)
//.declare V0229 (260)  rf=r size=8 type=d alias=V0225+0 align=4 words (r9.0)
//.declare V0230 (261)  rf=r size=4 type=d align=32 words (r10.0)
//.declare V0231 (262)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0232 (263)  rf=r size=8 type=q align=4 words (r94.2)
//.declare V0233 (264)  rf=r size=8 type=q align=4 words (r12.0)
//.declare V0234 (265)  rf=r size=8 type=ud alias=V0233+0 align=4 words (r12.0)
//.declare V0235 (266)  rf=r size=8 type=d alias=V0233+0 align=4 words (r12.0)
//.declare V0236 (267)  rf=r size=4 type=d align=32 words (r13.0)
//.declare V0238 (269)  rf=r size=8 type=q align=4 words (r94.3)
//.declare V0239 (270)  rf=r size=128 type=d align=32 words (r99.0)
//.declare V0240 (271)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0242 (273)  rf=r size=128 type=ud alias=V0240+0 align=32 words (r5.0)
//.declare V0245 (276)  rf=r size=256 type=uq align=32 words (r27.0)
//.declare V0246 (277)  rf=r size=128 type=f align=32 words (r37.0)
//.declare V0247 (278)  rf=r size=256 type=q alias=V0245+0 align=32 words (r27.0)
//.declare V0248 (279)  rf=r size=128 type=f align=32 words (r41.0)
//.declare V0249 (280)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0251 (282)  rf=r size=128 type=ud alias=V0249+0 align=32 words (r3.0)
//.declare V0254 (285)  rf=r size=256 type=uq align=32 words (r23.0)
//.declare V0255 (286)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0256 (287)  rf=r size=256 type=q alias=V0254+0 align=32 words (r23.0)
//.declare V0257 (288)  rf=r size=128 type=d align=32 words (r39.0)
//.declare V0259 (290)  rf=r size=128 type=w alias=V0255+0 align=32 words (r35.0)
//.declare V0263 (294)  rf=r size=128 type=w alias=V0257+0 align=32 words (r39.0)
//.declare V0266 (297)  rf=r size=128 type=d align=32 words (r71.0)
//.declare V0268 (299)  rf=r size=128 type=d align=32 words (r77.0)
//.declare V0270 (301)  rf=r size=128 type=f alias=V0268+0 align=32 words (r77.0)
//.declare V0272 (303)  rf=r size=128 type=d align=32 words (r73.0)
//.declare V0274 (305)  rf=r size=128 type=d align=32 words (r79.0)
//.declare V0276 (307)  rf=r size=128 type=f alias=V0274+0 align=32 words (r79.0)
//.declare V0280 (311)  rf=r size=256 type=uq align=32 words (r31.0)
//.declare V0281 (312)  rf=r size=128 type=f align=32 words (r47.0)
//.declare V0282 (313)  rf=r size=256 type=q alias=V0280+0 align=32 words (r31.0)
//.declare V0283 (314)  rf=r size=128 type=f align=32 words (r49.0)
//.declare V0286 (317)  rf=r size=256 type=uq align=32 words (r51.0)
//.declare V0287 (318)  rf=r size=128 type=f align=32 words (r63.0)
//.declare V0288 (319)  rf=r size=256 type=q alias=V0286+0 align=32 words (r51.0)
//.declare V0289 (320)  rf=r size=128 type=f align=32 words (r65.0)
//.declare V0290 (321)  rf=r size=128 type=d align=32 words (r75.0)
//.declare V0292 (323)  rf=r size=128 type=d align=32 words (r81.0)
//.declare V0293 (324)  rf=r size=128 type=f align=32 words (r85.0)
//.declare V0294 (325)  rf=r size=128 type=f alias=V0292+0 align=32 words (r81.0)
//.declare V0296 (327)  rf=r size=128 type=d align=32 words (r83.0)
//.declare V0298 (329)  rf=r size=128 type=d align=32 words (r87.0)
//.declare V0299 (330)  rf=r size=128 type=f align=32 words (r5.0)
//.declare V0300 (331)  rf=r size=128 type=f alias=V0298+0 align=32 words (r87.0)
//.declare V0304 (335)  rf=r size=256 type=uq align=32 words (r43.0)
//.declare V0305 (336)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0306 (337)  rf=r size=256 type=q alias=V0304+0 align=32 words (r43.0)
//.declare V0307 (338)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0310 (341)  rf=r size=256 type=uq align=32 words (r59.0)
//.declare V0311 (342)  rf=r size=128 type=f align=32 words (r67.0)
//.declare V0312 (343)  rf=r size=256 type=q alias=V0310+0 align=32 words (r59.0)
//.declare V0313 (344)  rf=r size=128 type=f align=32 words (r69.0)
//.declare V0315 (346)  rf=r size=128 type=w alias=V0305+0 align=32 words (r55.0)
//.declare V0319 (350)  rf=r size=128 type=w alias=V0307+0 align=32 words (r57.0)
//.declare V0322 (353)  rf=r size=128 type=d align=32 words (r89.0)
//.declare V0324 (355)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0325 (356)  rf=r size=128 type=f align=32 words (r13.0)
//.declare V0326 (357)  rf=r size=128 type=f alias=V0324+0 align=32 words (r7.0)
//.declare V0328 (359)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0330 (361)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0331 (362)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0332 (363)  rf=r size=128 type=f alias=V0330+0 align=32 words (r9.0)
//.declare V0334 (365)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0336 (367)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0337 (368)  rf=r size=128 type=f align=32 words (r21.0)
//.declare V0338 (369)  rf=r size=128 type=f alias=V0336+0 align=32 words (r17.0)
//.declare V0340 (371)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0342 (373)  rf=r size=128 type=d align=32 words (r23.0)
//.declare V0344 (375)  rf=r size=128 type=f alias=V0342+0 align=32 words (r23.0)
//.declare P21 (376)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0345 (377)  rf=r size=128 type=ud alias=V0239+0 align=32 words (r99.0)
//.declare V0346 (378)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0347 (379)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0348 (380)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0349 (381)  rf=r size=128 type=uw alias=V0347+0 align=32 words (r5.0)
//.declare V0350 (382)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (383)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P22 (384)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0353 (387)  rf=r size=128 type=f align=32 words (r101.0)
//.declare V0354 (388)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0355 (389)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0356 (390)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0357 (391)  rf=r size=128 type=uw alias=V0355+0 align=32 words (r12.0)
//.declare V0358 (392)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (393)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P23 (394)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0361 (397)  rf=r size=128 type=f align=32 words (r103.0)
//.declare V0362 (398)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0363 (399)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0364 (400)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0365 (401)  rf=r size=128 type=uw alias=V0363+0 align=32 words (r19.0)
//.declare V0366 (402)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (403)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P24 (404)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0369 (407)  rf=r size=128 type=f align=32 words (r105.0)
//.declare V0370 (408)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0371 (409)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0372 (410)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0373 (411)  rf=r size=128 type=uw alias=V0371+0 align=32 words (r26.0)
//.declare V0374 (412)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (413)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P25 (414)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0377 (417)  rf=r size=128 type=f align=32 words (r107.0)
//.declare V0378 (418)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0379 (419)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0380 (420)  rf=r size=128 type=f align=32 words (r109.0)
//.declare V0381 (421)  rf=r size=128 type=uw alias=V0379+0 align=32 words (r33.0)
//.declare V0382 (422)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (423)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P26 (424)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P27 (425)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P28 (426)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0384 (428)  rf=r size=128 type=f align=32 words (r3.0)
//.declare P29 (429)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0385 (430)  rf=r size=128 type=d align=32 words (r111.0)
//.declare V0386 (431)  rf=r size=128 type=d alias=V0384+0 align=32 words (r3.0)
//.declare V0387 (432)  rf=r size=128 type=d align=32 words (r5.0)
//.declare P30 (433)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0388 (434)  rf=r size=128 type=ud alias=V0387+0 align=32 words (r5.0)
//.declare V0389 (435)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0390 (436)  rf=r size=128 type=ud alias=V0385+0 align=32 words (r111.0)
//.declare V0391 (437)  rf=r size=128 type=ud alias=V0389+0 align=32 words (r3.0)
//.declare V0392 (438)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0393 (439)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0394 (440)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0395 (441)  rf=r size=128 type=ud alias=V0393+0 align=32 words (r8.0)
//.declare V0396 (442)  rf=r size=128 type=ud alias=V0394+0 align=32 words (r10.0)
//.declare V0397 (443)  rf=r size=64 type=w align=32 words (r113.0)
//.declare V0398 (444)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0399 (445)  rf=r size=128 type=ud alias=V0398+0 align=32 words (r3.0)
//.declare V0401 (447)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0404 (450)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare P31 (451)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0405 (452)  rf=r size=2 type=uw align=1 words (r92.27)
//.declare V0407 (454)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare V0408 (455)  rf=r size=4 type=uw alias=V0407+0 align=2 words (r3.0)
//.declare A05 (456)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0410 (458)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (460)  rf=r size=64 type=ud align=32 words (r3.0)
//.declare  (461)  rf=r size=32 type=ud align=32 words (r4.0)
//.declare P32 (462)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P33 (463)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P34 (464)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P35 (465)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P36 (466)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P37 (467)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P38 (468)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0412 (469)  rf=r size=2 type=b align=1 words (r1.8)
//.declare V0413 (470)  rf=r size=2 type=w align=1 words (r2.0)
//.declare V0414 (471)  rf=r size=2 type=ub alias=V0412+0 align=1 words (r1.8)
//.declare P39 (472)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0415 (473)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0416 (474)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0417 (475)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0418 (476)  rf=r size=8 type=q align=4 words (r8.0)
//.declare V0419 (477)  rf=r size=8 type=d alias=V0418+0 align=4 words (r8.0)
//.declare V0420 (478)  rf=r size=8 type=d alias=V0417+0 align=4 words (r7.0)
//.declare V0423 (481)  rf=r size=8 type=uq align=32 words (r10.0)
//.declare  (482)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (483)  rf=r size=4 type=d alias=V0069+0 align=2 words (r92.2)
//.declare  (484)  rf=r size=4 type=d alias=V0207+0 align=2 words (r94.2)
//.declare  (485)  rf=r size=128 type=w alias=V0398+0 align=32 words (r3.0)
//.declare  (486)  rf=r size=8 type=f align=8 words (r12.0)
//.declare  (487)  rf=r size=8 type=ud align=8 words (r4.0)
//.declare  (488)  rf=r size=8 type=d align=8 words (r94.8)
//.declare  (489)  rf=r size=64 type=uw align=32 words (r37.0)
//.declare  (490)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (491)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare  (492)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (493)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (494)  rf=r size=2 type=w align=1 words (r40.0)
//.declare  (495)  rf=r size=8 type=df align=4 words (r7.0)
//.declare  (496)  rf=r size=4 type=ud align=32 words (r32.0)
//.declare  (497)  rf=r size=4 type=f align=2 words (r7.0)
//.declare  (498)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare  (499)  rf=r size=2 type=w align=1 words (r1.4)
//.declare  (500)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare  (501)  rf=r size=4 type=ud align=32 words (r8.0)
//.declare  (502)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (503)  rf=r size=128 type=ud align=32 words (r13.0)
//.declare  (504)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (505)  rf=r size=128 type=ud align=32 words (r9.0)
//.declare  (506)  rf=r size=2 type=uw align=1 words (r36.0)
//.declare  (508)  rf=r size=128 type=w alias=V0394+0 align=32 words (r10.0)
//.declare  (509)  rf=r size=4 type=ud align=2 words (r7.0)
//.declare  (510)  rf=r size=2 type=uw align=1 words (r5.0)
//.declare  (512)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (515)  rf=r size=128 type=q align=32 words (r19.0)
//.declare  (516)  rf=r size=128 type=q align=32 words (r21.0)
//.declare  (519)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (520)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (529)  rf=r size=128 type=uq alias=+0 align=32 words (r19.0)
//.declare  (530)  rf=r size=128 type=uq alias=+0 align=32 words (r21.0)
//.declare  (531)  rf=r size=128 type=uq alias=+0 align=32 words (r15.0)
//.declare  (532)  rf=r size=128 type=uq alias=+0 align=32 words (r17.0)
//.declare r0 (533)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (534)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (535)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (536)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :q       |    0x8 | r1       | inline+0x0       |
// | V0041    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0042    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r2       | cti+0x20         |
// | V0045    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0050    | :d       |    0x4 | r2+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r2+0x34  | cti+0x54         |
// | V0052    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0054    | :b       |    0x1 | r3       | cti+0x60         |
// | V0055    | :b       |    0x1 | r3+0x4   | cti+0x64         |
// | V0037    | :uq      |    0x8 | r3+0x8   | cti+0x68         |
// | V0038    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r91.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r1.8<2>:b     r91.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     shl (1|M0)               r2.0<1>:q     r91.1<0;1,0>:ud   2:w               {$0.dst}          //  ALU pipe: int; $9
(W)     mov (1|M0)               r3.0<1>:w     r1.8<0;1,0>:ub                   {@2,$1.dst}          //  ALU pipe: int; $10
(W)     mov (8|M0)               r93.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r4.0<1>:q     r3.0<0;1,0>:w                    {I@2}                //  ALU pipe: int; $10
(W)     add (8|M0)               r93.8<1>:w    r93.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $5
(W)     add (1|M0)               r92.1<1>:q    r2.0<0;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $11
(W)     add (16|M0)              r93.16<1>:w   r93.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $6
(W)     mov (2|M0)               r92.4<1>:d    r92.2<1;1,0>:d                   {I@2}                //  ALU pipe: int; $12
(W)     mov (2|M0)               r92.0<1>:d    r2.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r92.5<0;1,0>:ud   0x1:uw              {I@2}           //  ALU pipe: int; $13
(W&f1.0) jmpi                                _0_029                                                  //  ALU pipe: int; $14
// B002: Preds:{B001},  Succs:{B007}
_0_030:
(W)     mov (1|M0)               r1.2<1>:f     r2.12<0;1,0>:ud                                       //  ALU pipe: float; $16
(W)     mov (1|M0)               r3.0<1>:df    r2.12<0;1,0>:ud                                       //  ALU pipe: long; $18
(W)     math.inv (1|M0)          r2.0<1>:f     r1.2<0;1,0>:f                    {F@1}                //  ALU pipe: math; $17
(W)     mov (1|M0)               r5.0<1>:df    0x3FF0000000000000:df                                 //  ALU pipe: long; $20
(W)     mov (1|M0)               r4.0<1>:df    r2.0<0;1,0>:f                    {M@1}                //  ALU pipe: long; $19
(W)     mov (1|M0)               r7.0<1>:df    0xBCF0000000000000:df                                 //  ALU pipe: long; $23
(W)     mad (1|M0)               r6.0<1>:df    r5.0<0;0>:df      r4.0<0;0>:df      -r3.0<0>:df      {L@2} //  ALU pipe: long; $21
(W)     mov (1|M0)               r11.0<1>:df   r92.3<0;1,0>:ud                                       //  ALU pipe: long; $26
(W)     add (1|M0)               r9.0<1>:df    r6.0<0;1,0>:df    r7.0<0;1,0>:df   {Compacted,L@2}    //  ALU pipe: long; $23
(W)     mov (1|M0)               r19.0<1>:df   r92.2<0;1,0>:ud                                       //  ALU pipe: long; $33
(W)     mad (1|M0)               r10.0<1>:df   r4.0<0;0>:df      r9.0<0;0>:df      r4.0<0>:df       {L@2} //  ALU pipe: long; $24
(W)     mov (1|M0)               r21.0<1>:df   0x41F0000000000000:df                                 //  ALU pipe: long; $34
(W)     mul (1|M0)               r12.0<1>:df   r10.0<0;1,0>:df   r11.0<0;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $27
(W)     mov (1|M0)               r29.0<1>:d    r92.4<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $44
(W)     mov (1|M0)               r13.0<2>:ud   r12.0<0;1,0>:df                  {L@1}                //  ALU pipe: int; $28
(W)     mov (1|M0)               r29.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $45
(W)     mul (1|M0)               acc0.0<1>:d   r13.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@2}              //  ALU pipe: int; $29
(W)     macl (1|M0)              r15.0<1>:d    r13.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $30
(W)     mov (1|M0)               r40.0<1>:hf   0xFFFF:hf                                             //  ALU pipe: float; $69
(W)     add (1|M0)               r16.0<1>:d    r92.3<0;1,0>:d    -r15.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $30
(W)     mov (1|M0)               r31.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $50
(W)     mov (1|M0)               r18.0<1>:df   r16.0<0;1,0>:ud                  {I@2}                //  ALU pipe: long; $32
(W)     mad (1|M0)               r22.0<1>:df   r19.0<0;0>:df     r21.0<0;0>:df     r18.0<0>:df      {L@1} //  ALU pipe: long; $35
(W)     mul (1|M0)               r23.0<1>:df   r10.0<0;1,0>:df   r22.0<0;1,0>:df  {Compacted,L@1}    //  ALU pipe: long; $36
(W)     mov (1|M0)               r24.0<1>:uq   r23.0<0;1,0>:df                  {L@1}                //  ALU pipe: int; $37
(W)     cmp (1|M0)    (eq)f0.0   null<1>:d     r24.1<0;1,0>:d    0:w               {Compacted,I@1}   //  ALU pipe: int; $40
(W)     mov (1|M0)               r25.0<1>:d    r24.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $38
(W)     add (1|M0)               r37.0<1>:d    r24.1<0;1,0>:d    r13.0<0;1,0>:d   {Compacted}        //  ALU pipe: int; $61
(W)     mul (1|M0)               acc0.0<1>:ud  r25.0<0;1,0>:ud   r2.24<0;1,0>:uw  {I@2}              //  ALU pipe: int; $53
(W&~f0.0) sel (1|M0)             r26.0<1>:d    r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $41
(W)     macl (1|M0)              r32.0<1>:ud   r25.0<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $54
(W)     add3 (1|M0)              r27.0<1>:d    r92.3<0;0>:d      -r15.0<0;0>:d     -r26.0<0>:d      {I@2} //  ALU pipe: int; $42
(W)     mul (1|M0)               acc0.0<1>:ud  r25.0<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $54
(W)     shl (1|M0)               r28.0<1>:q    r27.0<0;1,0>:d    32:w               {I@2}            //  ALU pipe: int; $43
(W)     mach (1|M0)              r34.0<1>:d    r25.0<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r33.0<2>:ud   r32.0<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $54
(W)     add (1|M0)               r30.0<1>:q    r28.0<0;1,0>:q    r29.0<0;1,0>:q   {Compacted,I@3}    //  ALU pipe: int; $48
(W)     mov (1|M0)               r33.1<2>:d    r34.0<0;1,0>:d                   {I@3}                //  ALU pipe: int; $58
(W)     mov (1|M0)               r31.0<1>:d    r25.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $49
(W)     add (1|M0)               r35.0<1>:q    r30.0<0;1,0>:q    -r33.0<0;1,0>:q  {I@2}              //  ALU pipe: int; $59
(W)     shl (1|M0)               r38.0<1>:q    r37.0<0;1,0>:d    32:w                                //  ALU pipe: int; $62
(W)     mov (2|M0)               r36.0<1>:d    r35.0<1;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $60
(W)     add (1|M0)               r39.0<1>:q    r38.0<0;1,0>:q    r31.0<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $63
(W)     cmp (32|M0)   (ge)f3.0   null<1>:ud    r36.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $64
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r36.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $65
(W&~f3.0) cmp (32|M0) (gt)f3.0   null<1>:ud    r36.1<0;1,0>:ud   0x0:uw                              //  ALU pipe: int; $67
(W&f3.0) sel (1|M0)              r41.0<1>:d    r40.0<0;1,0>:w    0:w               {F@1}             //  ALU pipe: int; $69
(W)     mov (1|M0)               r42.0<1>:q    r41.0<0;1,0>:d                   {I@1}                //  ALU pipe: int; $70
(W)     add (1|M0)               r92.3<1>:q    r39.0<0;1,0>:q    -r42.0<0;1,0>:q  {I@1}              //  ALU pipe: int; $71
(W)     jmpi                                 _0_031                                                  // $72
// B003: Preds:{B001},  Succs:{B004, B005}
_0_029:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $74
(W&~f3.0) jmpi                               _0_032                                                  //  ALU pipe: int; $75
// B004: Preds:{B003},  Succs:{B006}
_0_033:
(W)     mov (1|M0)               r92.8<1>:d    -1:w                                                  //  ALU pipe: int; $77
(W)     jmpi                                 _0_034                                                  // $78
// B005: Preds:{B003},  Succs:{B006}
_0_032:
(W)     mov (1|M0)               r1.2<2>:d     r92.1<0;1,0>:q                                        //  ALU pipe: int; $80
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $81
(W)     mov (1|M0)               r2.0<1>:f     r2.12<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $82
(W)     mov (1|M0)               r7.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $87
(W)     math.inv (1|M0)          r6.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $86
(W)     mov (1|M0)               r5.0<1>:f     r1.2<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $85
(W)     mad (1|M0)               r8.0<1>:f     r6.0<0;0>:f       r7.0<0;0>:f       r6.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $87
(W)     mov (1|M0)               r3.0<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $83
(W)     mov (1|M0)               r10.0<1>:ud   r5.0<0;1,0>:f                    {F@2}                //  ALU pipe: int; $89
(W)     mul (1|M0)               r9.0<1>:f     r5.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $88
(W)     add (1|M0)               r4.0<1>:d     r2.12<0;1,0>:d    -r3.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $84
(W)     add (1|M0)               r4.1<1>:d     r1.2<0;1,0>:d     -r10.0<0;1,0>:d  {I@2}              //  ALU pipe: int; $90
(W)     mov (1|M0)               r11.0<1>:ud   r9.0<0;1,0>:f                    {F@1}                //  ALU pipe: int; $91
(W)     mov (1|M0)               r12.0<1>:f    r4.0<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $92
(W)     mov (1|M0)               r12.1<1>:f    r4.1<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $92
(W)     mov (1|M0)               r13.0<1>:f    r11.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $94
(W)     mad (1|M0)               r14.0<1>:f    r5.0<0;0>:f       r13.0<0;0>:f      -r2.0<0>:f       {F@1} //  ALU pipe: float; $96
(W)     mad (1|M0)               r15.0<1>:f    r12.1<0;0>:f      r13.0<0;0>:f      -r12.0<0>:f       //  ALU pipe: float; $98
(W)     add (1|M0)               r16.0<1>:f    r14.0<0;1,0>:f    r15.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $99
(W)     mul (1|M0)               r17.0<1>:f    r8.0<0;1,0>:f     r16.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $100
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $101
(W)     mov (1|M0)               r18.0<1>:ud   r17.0<0;1,0>:f                   {A@1}                //  ALU pipe: int; $102
(W)     add (1|M0)               r19.0<1>:d    r18.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $103
(W)     mul (1|M0)               acc0.0<1>:d   r19.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $104
(W)     macl (1|M0)              r20.0<1>:d    r19.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $105
(W)     add (1|M0)               r21.0<1>:d    r1.2<0;1,0>:d     -r20.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $105
(W)     cmp (1|M0)    (ge)f2.0   r22.0<1>:ud   r21.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@1}              //  ALU pipe: int; $106
(W)     add3 (1|M0)              r92.8<1>:d    r18.0<0;0>:d      r11.0<0;0>:d      -r22.0<0>:d      {I@1} //  ALU pipe: int; $107
// B006: Preds:{B005, B004},  Succs:{B007}
_0_034:
(W)     mov (1|M0)               r92.3<1>:q    r92.8<0;1,0>:ud                  {I@1}                //  ALU pipe: int; $109
// B007: Preds:{B006, B002},  Succs:{B008, B009}
_0_031:
(W)     mov (2|M0)               r92.9<1>:d    r92.6<1;1,0>:d                   {I@1}                //  ALU pipe: int; $111
        mov (32|M0)              r95.0<1>:d    r93.0<1;1,0>:uw                                       //  ALU pipe: int; $131
(W)     mul (1|M0)               acc0.0<1>:ud  r92.9<0;1,0>:ud   r2.24<0;1,0>:uw  {I@2}              //  ALU pipe: int; $112
(W)     macl (1|M0)              r94.0<1>:ud   r92.9<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $113
(W)     mul (1|M0)               acc0.0<1>:ud  r92.9<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $113
(W)     mach (1|M0)              r2.0<1>:d     r92.9<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r2.12<0;1,0>:ud   r92.20<0;1,0>:uw                    //  ALU pipe: int; $116
(W)     macl (1|M0)              r3.0<1>:d     r2.12<0;1,0>:ud   r92.10<0;1,0>:d                     //  ALU pipe: int; $118
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $119
(W)     macl (1|M0)              r4.0<1>:ud    r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; $120
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $120
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r92.4<0;1,0>:ud   r4.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $132
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r92.4<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $126
(W)     mach (1|M0)              r5.0<1>:d     r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; 
(W)     add (1|M0)               r92.11<1>:d   r2.0<0;1,0>:d     r3.0<0;1,0>:d                       //  ALU pipe: int; $118
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r92.5<0;1,0>:d    r5.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $133
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r92.5<0;1,0>:d    r5.0<0;1,0>:d                       //  ALU pipe: int; $127
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:ud    r92.5<0;1,0>:ud   r5.0<0;1,0>:ud                      //  ALU pipe: int; $135
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r92.5<0;1,0>:ud   r5.0<0;1,0>:ud                      //  ALU pipe: int; $129
(W&f1.0) jmpi                                _0_035                                                  //  ALU pipe: int; $137
// B008: Preds:{B007},  Succs:{B020}
_0_036:
        mov (32|M0)              r97.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $141
(W)     mov (1|M0)               r92.12<1>:d   0:w                                                   //  ALU pipe: int; $139
(W)     mov (1|M0)               r92.26<1>:w   0:w                                                   //  ALU pipe: int; $140
(W)     jmpi                                 _0_037                                                  // $142
// B009: Preds:{B007},  Succs:{B010, B011}
_0_035:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r92.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $144
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r92.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $145
(W&~f2.0) jmpi                               _0_038                                                  //  ALU pipe: int; $147
// B010: Preds:{B009},  Succs:{B012}
_0_039:
(W)     mov (2|M0)               r94.8<1>:d    0:w                                                   //  ALU pipe: int; $149
(W)     mov (1|M0)               r92.14<1>:d   r2.12<0;1,0>:d                                        //  ALU pipe: int; $151
(W)     jmpi                                 _0_040                                                  // $152
// B011: Preds:{B009},  Succs:{B012}
_0_038:
(W)     mul (1|M0)               acc0.0<1>:ud  r92.9<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $155
(W)     mach (1|M0)              r2.0<1>:d     r92.9<0;1,0>:ud   0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.2<2>:ud    r92.9<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $154
(W)     mov (1|M0)               r1.3<2>:d     r2.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $159
(W)     add (1|M0)               r4.0<1>:q     r1.1<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $160
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $162
(W)     mov (1|M0)               r94.8<1>:d    r5.0<0;1,0>:d                    {$2.dst}             //  ALU pipe: int; $163
(W)     mov (1|M0)               r94.9<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $164
(W)     mov (1|M0)               r92.14<1>:d   r5.2<0;1,0>:d                                         //  ALU pipe: int; $165
// B012: Preds:{B011, B010},  Succs:{B013, B014}
_0_040:
(W)     cmp (32|M0)   (gt)f1.0   null<1>:ud    r94.9<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $167
(W&~f1.0) cmp (32|M0) (ge)f1.0   null<1>:ud    r94.8<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; $168
(W&~f1.0) jmpi                               _0_041                                                  //  ALU pipe: int; $170
// B013: Preds:{B012},  Succs:{B020}
_0_042:
        mov (32|M0)              r97.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $174
(W)     mov (1|M0)               r92.12<1>:d   0:w                                                   //  ALU pipe: int; $172
(W)     mov (1|M0)               r92.26<1>:w   0:w                                                   //  ALU pipe: int; $173
(W)     jmpi                                 _0_037                                                  // $175
// B014: Preds:{B012},  Succs:{B015, B016}
_0_041:
(W)     mov (1|M0)               r1.2<1>:d     r94.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $177
(W)     mov (1|M0)               r1.3<1>:d     r92.11<0;1,0>:d                                       //  ALU pipe: int; $178
(W)     cmp (32|M0)   (le)f3.0   null<1>:ud    r92.14<0;1,0>:ud  r2.12<0;1,0>:ud  {I@7}              //  ALU pipe: int; $184
(W)     add (1|M0)               r94.1<1>:q    r92.1<0;1,0>:q    -r1.1<0;1,0>:q   {I@2}              //  ALU pipe: int; $181
(W)     add (1|M0)               r2.0<1>:d     r2.12<0;1,0>:d    -r94.9<0;1,0>:d                     //  ALU pipe: int; $183
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r92.14<0;1,0>:ud  r94.2<0;1,0>:ud  {I@2}              //  ALU pipe: int; $187
(W&f3.0) cmp (32|M0)  (le)f3.0   null<1>:ud    r92.14<0;1,0>:ud  r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $185
(W)     mov (1|M0)               r3.0<1>:ud    f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $188
(W)     and (1|M0)               f1.0<1>:ud    f3.0<0;1,0>:ud    r3.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $188
(W&f1.0) jmpi                                _0_043                                                  //  ALU pipe: int; $189
// B015: Preds:{B014},  Succs:{B020}
_0_044:
        mov (32|M0)              r97.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $193
(W)     mov (1|M0)               r1.4<1>:w     1:w                                                   //  ALU pipe: int; $191
(W)     mov (1|M0)               r92.12<1>:d   0:w                                                   //  ALU pipe: int; $192
(W&f3.0) sel (1|M0)              r92.26<1>:w   r1.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $191
(W)     jmpi                                 _0_037                                                  // $194
// B016: Preds:{B014},  Succs:{B017}
_0_043:
(W)     mul (1|M0)               acc0.0<1>:ud  r94.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $197
(W)     macl (1|M0)              r2.0<1>:ud    r94.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $198
(W)     mul (1|M0)               acc0.0<1>:ud  r94.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $198
(W)     mach (1|M0)              r4.0<1>:d     r94.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r3.0<2>:f     r2.0<0;1,0>:f                    {I@3}                //  ALU pipe: float; $198
(W)     mov (1|M0)               r3.1<2>:d     r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $202
(W)     mov (2|M0)               r1.2<1>:d     r2.10<1;1,0>:d                                        //  ALU pipe: int; $196
(W)     add (1|M0)               r5.0<1>:q     r3.0<0;1,0>:q     r94.9<0;1,0>:ud  {A@1}              //  ALU pipe: int; $204
        shl (32|M0)              r99.0<1>:d    r95.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $221
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r94.1<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $205
        mov (32|M0)              r97.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $222
(W)     mov (2|M0)               r7.0<1>:f     r6.0<1;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $206
(W)     mul (1|M0)               r12.0<2>:ud   r92.9<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $214
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw   {F@1}              //  ALU pipe: int; $207
(W)     macl (1|M0)              r8.0<1>:ud    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $208
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw                      //  ALU pipe: int; $208
(W)     mach (1|M0)              r10.0<1>:d    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r7.0<0;1,0>:ud    r1.6<0;1,0>:uw                      //  ALU pipe: int; $209
(W)     macl (1|M0)              r11.0<1>:d    r7.0<0;1,0>:ud    r1.3<0;1,0>:d                       //  ALU pipe: int; $210
(W)     mul (1|M0)               acc0.0<1>:d   r1.2<0;1,0>:ud    r7.2<0;1,0>:uw                      //  ALU pipe: int; $211
(W)     add (1|M0)               r10.0<1>:d    r10.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $210
(W)     macl (1|M0)              r11.0<1>:d    r1.2<0;1,0>:ud    r7.1<0;1,0>:d                       //  ALU pipe: int; $212
(W)     mul (1|M0)               acc0.0<1>:ud  r92.9<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $215
(W)     mach (1|M0)              r13.0<1>:d    r92.9<0;1,0>:ud   0x3000:ud                           //  ALU pipe: int; 
(W)     mov (1|M0)               r9.0<2>:f     r8.0<0;1,0>:f                                         //  ALU pipe: float; $208
(W)     add (1|M0)               r9.1<2>:d     r10.0<0;1,0>:d    r11.0<0;1,0>:d   {I@3}              //  ALU pipe: int; $212
(W)     mov (1|M0)               r12.1<2>:d    r13.0<0;1,0>:d                   {I@2}                //  ALU pipe: int; $219
(W)     add (1|M0)               r94.2<1>:q    r9.0<0;1,0>:q     r1.0<0;1,0>:q    {Compacted,A@1}    //  ALU pipe: int; $213
(W)     add (1|M0)               r94.3<1>:q    r12.0<0;1,0>:q    r1.2<0;1,0>:q    {I@2}              //  ALU pipe: int; $220
// B017: [inDivergent],  Preds:{B019, B016},  Succs:{B018, B019}
_0_045:
        shl (32|M0)              r3.0<1>:d     r99.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $230
        mov (16|M0)              r7.0<2>:ud    r3.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $232
        mov (16|M16)             r9.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $232
        shl (32|M0)              r5.0<1>:d     r99.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $224
        add (16|M0)              r15.0<1>:q    r94.3<0;1,0>:q    r7.0<2;1,0>:ud   {I@3}              //  ALU pipe: int; $232
        add (16|M16)             r17.0<1>:q    r94.3<0;1,0>:q    r9.0<2;1,0>:ud   {I@3}              //  ALU pipe: int; $232
        mov (16|M0)              r23.0<1>:uq   r15.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $233
        mov (16|M16)             r25.0<1>:uq   r17.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $233
        mov (16|M0)              r11.0<2>:ud   r5.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $226
        mov (16|M16)             r13.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $226
        load.ugm.d32.a64 (32|M0)  r35:2         [r23:4]            {I@3,$3} // ex_desc:0x0; desc:0x8200580 // $234
        add (16|M0)              r19.0<1>:q    r94.2<0;1,0>:q    r11.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $226
        add (16|M16)             r21.0<1>:q    r94.2<0;1,0>:q    r13.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $226
        mov (16|M0)              r27.0<1>:uq   r19.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $227
        mov (16|M16)             r29.0<1>:uq   r21.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $227
        load.ugm.d32.a64 (32|M0)  r39:2         [r23:4+0x4]        {$4} // ex_desc:0x4000; desc:0x8200580 // $235
        load.ugm.d32.a64 (32|M0)  r37:2         [r27:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $228
        load.ugm.d32.a64 (32|M0)  r41:2         [r27:4+0x4]        {$6} // ex_desc:0x4000; desc:0x8200580 // $229
        add (16|M0)              r43.0<1>:q    r15.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $264
        add (16|M16)             r45.0<1>:q    r17.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $264
        add (16|M0)              r31.0<1>:q    r19.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $248
        add (16|M16)             r33.0<1>:q    r21.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $248
        load.ugm.d32.a64 (32|M0)  r55:2         [r43:4]            {I@3,$7} // ex_desc:0x0; desc:0x8200580 // $266
        load.ugm.d32.a64 (32|M0)  r47:2         [r31:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $250
        load.ugm.d32.a64 (32|M0)  r49:2         [r31:4+0x4]        {$9} // ex_desc:0x4000; desc:0x8200580 // $251
        add (16|M0)              r51.0<1>:q    r19.0<1;1,0>:q    16:w               {Compacted}      //  ALU pipe: int; $252
        add (16|M16)             r53.0<1>:q    r21.0<1;1,0>:q    16:w               {Compacted}      //  ALU pipe: int; $252
        load.ugm.d32.a64 (32|M0)  r57:2         [r43:4+0x4]        {$10} // ex_desc:0x4000; desc:0x8200580 // $267
        load.ugm.d32.a64 (32|M0)  r63:2         [r51:4]            {I@1,$11} // ex_desc:0x0; desc:0x8200580 // $254
        load.ugm.d32.a64 (32|M0)  r65:2         [r51:4+0x4]        {$12} // ex_desc:0x4000; desc:0x8200580 // $255
        add (16|M0)              r59.0<1>:q    r19.0<1;1,0>:q    24:w               {Compacted}      //  ALU pipe: int; $268
        add (16|M16)             r61.0<1>:q    r21.0<1;1,0>:q    24:w               {Compacted}      //  ALU pipe: int; $268
        load.ugm.d32.a64 (32|M0)  r67:2         [r59:4]            {I@1,$13} // ex_desc:0x0; desc:0x8200580 // $270
        load.ugm.d32.a64 (32|M0)  r69:2         [r59:4+0x4]        {$14} // ex_desc:0x4000; desc:0x8200580 // $271
        mov (32|M0)              r71.0<1>:d    r35.0<2;1,0>:uw                  {$3.dst}             //  ALU pipe: int; $240
        mov (32|M0)              r73.0<1>:d    r35.1<2;1,0>:uw                                       //  ALU pipe: int; $244
        shl (32|M0)              r77.0<1>:d    r71.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $241
        shl (32|M0)              r79.0<1>:d    r73.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $245
        mov (32|M0)              r75.0<1>:d    r39.0<2;1,0>:uw                  {$4.dst}             //  ALU pipe: int; $256
        sync.nop                             null                             {Compacted,I@3}        // $242
        mul (32|M0)              acc0.0<1>:f   r37.0<1;1,0>:f    r77.0<1;1,0>:f   {Compacted,$5.dst} //  ALU pipe: float; $242
        mov (32|M0)              r83.0<1>:d    r39.1<2;1,0>:uw                                       //  ALU pipe: int; $260
        shl (32|M0)              r81.0<1>:d    r75.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $257
        mul (32|M0)              acc2.0<1>:f   r41.0<1;1,0>:f    r79.0<1;1,0>:f   {Compacted,$6.dst} //  ALU pipe: float; $246
        mov (32|M0)              r89.0<1>:d    r55.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $276
        shl (32|M0)              r87.0<1>:d    r83.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $261
        add (32|M0)              acc0.0<1>:f   r97.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $243
        sync.nop                             null                             {Compacted,I@3}        // $258
        mul (32|M0)              r85.0<1>:f    r47.0<1;1,0>:f    r81.0<1;1,0>:f   {Compacted,$8.dst} //  ALU pipe: float; $258
        mov (32|M0)              r3.0<1>:d     r55.1<2;1,0>:uw                                       //  ALU pipe: int; $280
        shl (32|M0)              r7.0<1>:d     r89.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $277
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $247
        sync.nop                             null                             {Compacted,I@3}        // $262
        mul (32|M0)              r5.0<1>:f     r49.0<1;1,0>:f    r87.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $262
        shl (32|M0)              r9.0<1>:d     r3.0<1;1,0>:d     16:w               {Compacted,I@2}  //  ALU pipe: int; $281
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r85.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $259
        mov (32|M0)              r11.0<1>:d    r57.0<2;1,0>:uw                  {$10.dst}            //  ALU pipe: int; $284
        sync.nop                             null                             {Compacted,I@3}        // $278
        mul (32|M0)              r13.0<1>:f    r63.0<1;1,0>:f    r7.0<1;1,0>:f    {Compacted,$11.dst} //  ALU pipe: float; $278
        mov (32|M0)              r19.0<1>:d    r57.1<2;1,0>:uw                                       //  ALU pipe: int; $288
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r5.0<1;1,0>:f    {Compacted,F@3}    //  ALU pipe: float; $263
        sync.nop                             null                             {Compacted,I@3}        // $282
        mul (32|M0)              r15.0<1>:f    r65.0<1;1,0>:f    r9.0<1;1,0>:f    {Compacted,$12.dst} //  ALU pipe: float; $282
        shl (32|M0)              r17.0<1>:d    r11.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $285
        shl (32|M0)              r23.0<1>:d    r19.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $289
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r13.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $279
        sync.nop                             null                             {Compacted,I@2}        // $286
        mul (32|M0)              r21.0<1>:f    r67.0<1;1,0>:f    r17.0<1;1,0>:f   {Compacted,$13.dst} //  ALU pipe: float; $286
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r15.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $283
        sync.nop                             null                             {Compacted,I@1}        // $290
        mul (32|M0)              acc2.0<1>:f   r69.0<1;1,0>:f    r23.0<1;1,0>:f   {Compacted,$14.dst} //  ALU pipe: float; $290
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r99.0<1;1,0>:ud   0x1700:uw                           //  ALU pipe: int; $292
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r21.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $287
        add (32|M0)              r97.0<1>:f    acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $291
(f2.0)  goto (32|M0)                         _0_046            _0_046                                //  ALU pipe: int; $293
// B018: [inDivergent],  Preds:{B017},  Succs:{B020}
_0_047:
(W)     mov (1|M0)               r92.12<1>:d   -1:w                                                  //  ALU pipe: int; $295
(W)     mov (1|M0)               r92.26<1>:hf  0x1:hf                                                //  ALU pipe: float; $296
        goto (32|M0)                         _0_046            _0_037                                // $297
// B019: [inDivergent],  Preds:{B017},  Succs:{B017}
_0_046:
        join (32|M0)                         _0_037                                                  // 
L3656:
        add (32|M0)              r99.0<1>:d    r99.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $299
(W)     jmpi                                 _0_045                                                  // $300
// B020: Preds:{B018, B015, B013, B008},  Succs:{B021, B025}
_0_037:
        join (32|M0)                         L3696                                                   // 
L3696:
        add (32|M0)              r3.0<1>:d     r95.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $302
        and (32|M0)              r5.0<1>:d     r3.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $303
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $304
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $305
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0x1840:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0188(r97.0:f); $306
        add (32|M0)              r10.0<1>:d    r95.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $315
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@2}                //  ALU pipe: int; $307
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $308
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0x1840:uw                           //  ALU pipe: int; src1 is addr of V0188(r97.0:f); $309
        and (32|M0)   (eq)f3.0   null<1>:d     r95.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $311
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $316
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $310
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $317
(f3.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $313
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $318
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0x1940:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0353(r101.0:f); $319
        add (32|M0)              r101.0<1>:f   r97.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $314
        add (32|M0)              r17.0<1>:d    r95.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $328
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $320
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $321
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0x1940:uw                           //  ALU pipe: int; src1 is addr of V0353(r101.0:f); $322
        and (32|M0)   (eq)f2.0   null<1>:d     r95.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $324
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $329
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $323
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $330
(f2.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $326
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $331
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0x19C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0361(r103.0:f); $332
        add (32|M0)              r103.0<1>:f   r101.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $327
        add (32|M0)              r24.0<1>:d    r95.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $341
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $333
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $334
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0x19C0:uw                           //  ALU pipe: int; src1 is addr of V0361(r103.0:f); $335
        and (32|M0)   (eq)f1.0   null<1>:d     r95.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $337
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $342
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $336
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $343
(f1.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $339
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $344
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0x1A40:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0369(r105.0:f); $345
        add (32|M0)              r105.0<1>:f   r103.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $340
        add (32|M0)              r31.0<1>:d    r95.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $354
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $346
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $347
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0x1A40:uw                           //  ALU pipe: int; src1 is addr of V0369(r105.0:f); $348
        and (32|M0)   (eq)f3.0   null<1>:d     r95.0<1;1,0>:d    15:w                                //  ALU pipe: int; $350
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $355
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $349
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $356
        cmp (32|M0)   (eq)f1.0   null<2>:w     r93.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $363
(f3.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $352
(W)     mov (1|M0)               r36.0<1>:hf   0x1:hf                                                //  ALU pipe: float; $364
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $357
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0x1AC0:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0377(r107.0:f); $358
        add (32|M0)              r107.0<1>:f   r105.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $353
(f0.0)  sel (32|M0)              r37.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw              {F@2}           //  ALU pipe: int; $364
(f1.0)  sel (32|M0)              r38.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw                              //  ALU pipe: int; $364
        mov (16|M0)              r109.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $359
        and (32|M0)   (ne)f2.0   null<2>:uw    r37.0<1;1,0>:uw   r38.0<1;1,0>:uw  {I@2}              //  ALU pipe: int; $364
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $360
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0x1AC0:uw                           //  ALU pipe: int; src1 is addr of V0377(r107.0:f); $361
        mov (16|M16)             r110.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $362
(~f2.0) goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $365
// B021: [inDivergent],  Preds:{B020},  Succs:{B022, B023}
_0_049:
        cmp (32|M0)   (eq)f1.0   null<2>:w     r93.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $367
(f1.0)  sel (32|M0)              acc0.0<1>:f   r109.0<1;1,0>:f   0x80000000:f               {I@3}    //  ALU pipe: float; $368
(W)     cmp (32|M0)   (ne)f3.0   null<1>:d     r92.12<0;1,0>:d   0:w                                 //  ALU pipe: int; $370
        add (32|M0)              r3.0<1>:f     r107.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $369
(f3.0)  sel (32|M0)              r111.0<1>:d   r3.0<1;1,0>:d     2143289344:d               {F@1}    //  ALU pipe: int; $371
        and (32|M0)              r5.0<1>:d     r111.0<1;1,0>:d   2147483647:d               {I@1}    //  ALU pipe: int; $372
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r5.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $373
(f2.0)  goto (32|M0)                         _0_050            _0_050                                //  ALU pipe: int; $374
// B022: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_051:
        shr (32|M0)              r3.0<1>:ud    r111.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $376
        and (32|M0)              r6.0<1>:d     r3.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $377
        add3 (32|M0)             r8.0<1>:d     r111.0<1;0>:d     r6.0<1;0>:d       32767:w               {I@1} //  ALU pipe: int; $378
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $379
        mov (32|M0)              r113.0<1>:w   r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $380
        goto (32|M0)                         _0_050            _0_052                                // $381
// B023: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_050:
        join (32|M0)                         _0_052                                                  // 
L4816:
        shr (32|M0)              r3.0<1>:ud    r111.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $383
        or (32|M0)               r113.0<1>:w   r3.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $385
// B024: [inDivergent],  Preds:{B023, B022},  Succs:{B025}
_0_052:
        join (32|M0)                         _0_048                                                  // 
L4864:
(W)     mov (1|M0)               f2.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $390
        cmp (32|M0)   (eq)f2.0   null<2>:uw    r92.27<0;1,0>:uw  r92.27<0;1,0>:uw                    //  ALU pipe: int; $391
(W)     fbl (1|M0)               r3.0<1>:ud    f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $393
(W)     shl (1|M0)               r1.1<1>:q     r92.1<0;1,0>:q    1:w                                 //  ALU pipe: int; $387
(W)     shl (1|M0)               r3.0<1>:ud    r3.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $394
(W)     add (1|M0)               r2.0<1>:q     r1.1<0;1,0>:q     r1.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $388
(W)     add (1|M0)               a0.0<1>:uw    r3.0<0;1,0>:uw    0x1C40:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0397(r113.0:w); $395
(W)     mov (1|M0)               r4.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $397
(W)     store.ugm.d16u32.a64 (1|M0)  [r2:2]     r4:1               {I@1,$15} // ex_desc:0x0; desc:0x4000B84 // $398
// B025: Preds:{B024, B020},  Succs:{B026, B027}
_0_048:
        join (32|M0)                         L5008                                                   // 
L5008:
        sync.nop                             null                             {Compacted,$15.src}    // $400
(W)     send.slm (1|M0)          r3       r91  null:0  0x0            0x0210001F           {$0} // wr:1+0, rd:1; fence.slm.none.group // $400
(W)     mov (1|M0)               r4.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $401
(W)     mov (2|M0)               r4.10<1>:ub   r91.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $401
(W)     mov (8|M0)               null<1>:ud    r3.0<1;1,0>:ud                   {Compacted,$0.dst}   //  memory fence commit; ALU pipe: int; $401
(W)     send.gtwy (1|M0)         null     r4  null:0  0x0            0x02000004           {I@2,$1} // wr:1+0, rd:0; signal barrier // $401
(W)     sync.bar                             0x0                                                     // $401
(W)     cmp (32|M0)   (ne)f3.0   null<1>:d     r92.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $405
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r92.4<0;1,0>:d    r94.0<0;1,0>:d                      //  ALU pipe: int; $402
(W&~f3.0) cmp (32|M0) (ne)f3.0   null<1>:d     r92.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $406
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r92.5<0;1,0>:d    r92.11<0;1,0>:d                     //  ALU pipe: int; $403
(W)     mov (1|M0)               r7.0<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $408
(W)     mov (1|M0)               r5.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $411
(W)     and (1|M0)               f2.0<1>:ud    f1.0<0;1,0>:ud    r7.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $408
(f0.0)  sel (32|M0)              r6.0<1>:uw    r5.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $411
(f2.0)  cmp (32|M0)   (eq)f2.0   null<2>:w     r93.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $409
(f2.0)  sel (32|M0)              r8.0<1>:uw    r5.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $411
        and (32|M0)   (ne)f1.0   null<2>:uw    r8.0<1;1,0>:uw    r6.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $411
(~f1.0) goto (32|M0)                         _0_053            _0_053                                //  ALU pipe: int; $412
// B026: [inDivergent],  Preds:{B025},  Succs:{B027}
_0_054:
(W)     mov (1|M0)               r1.8<2>:b     r92.26<0;1,0>:w                                       //  ALU pipe: int; $414
(W)     mov (1|M0)               r3.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $417
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $415
(W)     shl (1|M0)               r7.0<1>:q     r92.3<0;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $419
(W)     cmp (32|M0)   (eq)f3.0   null<2>:w     r2.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $416
(W)     and (1|M0)               r8.0<1>:d     r7.0<0;1,0>:d     -4:w               {Compacted,I@2}  //  ALU pipe: int; $420
(W)     and (1|M0)               r8.1<1>:d     r7.1<0;1,0>:d     3:w                                 //  ALU pipe: int; $421
        sync.nop                             null                             {Compacted,F@1}        // $417
(W&f3.0) sel (1|M0)              r4.0<1>:d     r3.0<0;1,0>:w     0:w               {$1.src}          //  ALU pipe: int; $417
(W)     add (1|M0)               r10.0<1>:q    r8.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $422
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $418
(W)     store.ugm.d32x1t.a64 (1|M0)  [r10:1]    r6:1               {I@1,$2} // ex_desc:0x0; desc:0x2008584 // $424
// B027: Preds:{B026, B025},  Succs:{}
_0_053:
        join (32|M0)                         L5456                                                   // 
L5456:
(W)     mov (16|M0)              r127.0<1>:f   r91.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $426
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$3} // wr:1+0, rd:0; end of thread // $426
L5480:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x27:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 2
//


//.numALUInst: 358
//.accSubDef: 15
//.accSubUse: 15
//.accSubCandidateDef: 20
//.accSubCandidateUse: 20
//
//
//.singlePipeAtOneDistNum: 61
//.allAtOneDistNum: 10
//.syncInstCount: 9
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 16
//.AfterReadTokenDepCount: 2
