//.kernel _ZTSZZNK11specialised6KernelILN2ng2OpE6ELi2ELi512ELi0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_2idILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 137417456 3927483612 -hashmovs1 0 14 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 137417456 3927483612 -hashmovs1 0 14 -GRFBumpUpNumber 2 "
//.instCount 156
//.RA type	LOCAL_FIRST_FIT_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r64.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r64.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r64.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0072 (82)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0074 (84)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0075 (85)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0077 (87)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0078 (88)  rf=r size=8 type=d align=2 words (r5.0)
//.declare V0079 (89)  rf=r size=8 type=d alias=V0077+0 align=4 words (r4.0)
//.declare P01 (90)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0080 (91)  rf=r size=8 type=ud alias=V0078+0 align=2 words (r5.0)
//.declare V0081 (92)  rf=r size=128 type=ud alias=V0075+0 align=32 words (r66.0)
//.declare P02 (93)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P03 (94)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0082 (95)  rf=r size=8 type=uq alias=V0069+0 align=32 words (r5.6)
//.declare V0083 (96)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0084 (97)  rf=r size=4 type=d align=32 words (r1.0)
//.declare P04 (98)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0085 (99)  rf=r size=8 type=uq alias=V0066+0 align=32 words (r5.3)
//.declare V0086 (100)  rf=r size=8 type=uq align=32 words (r68.0)
//.declare V0088 (102)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0089 (103)  rf=r size=256 type=ud alias=V0088+0 align=32 words (r6.0)
//.declare V0090 (104)  rf=r size=8 type=ud alias=V0086+0 align=32 words (r68.0)
//.declare V0091 (105)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0092 (106)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P05 (108)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0094 (109)  rf=r size=8 type=uq alias=V0068+0 align=32 words (r5.5)
//.declare V0095 (110)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0096 (111)  rf=r size=4 type=d align=32 words (r1.0)
//.declare V0097 (112)  rf=r size=4 type=d align=2 words (r1.1)
//.declare P06 (113)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P07 (114)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0104 (121)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0105 (122)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0110 (127)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0111 (128)  rf=r size=4 type=d align=2 words (r1.1)
//.declare V0113 (130)  rf=r size=128 type=ud alias=V0104+0 align=32 words (r20.0)
//.declare V0114 (131)  rf=r size=4 type=ud alias=V0110+0 align=2 words (r1.0)
//.declare V0117 (134)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0118 (135)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0119 (136)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.3)
//.declare V0121 (138)  rf=r size=256 type=q align=32 words (r16.0)
//.declare V0124 (141)  rf=r size=256 type=q align=32 words (r56.0)
//.declare V0125 (142)  rf=r size=256 type=uq alias=V0124+0 align=32 words (r56.0)
//.declare V0126 (143)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0127 (144)  rf=r size=512 type=f align=32 words (r24.0)
//.declare V0128 (145)  rf=r size=512 type=f align=32 words (r32.0)
//.declare V0129 (146)  rf=r size=512 type=f align=32 words (r40.0)
//.declare V0130 (147)  rf=r size=512 type=f align=32 words (r48.0)
//.declare V0131 (148)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0132 (149)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0133 (150)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0134 (151)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0135 (152)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0136 (153)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0137 (154)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0138 (155)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0139 (156)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0140 (157)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0141 (158)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0145 (162)  rf=r size=128 type=f align=32 words (r72.0)
//.declare V0147 (164)  rf=r size=128 type=f align=32 words (r2.0)
//.declare  (165)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (166)  rf=r size=128 type=f align=32 words (r74.0)
//.declare  (167)  rf=r size=128 type=f align=32 words (r76.0)
//.declare  (168)  rf=r size=128 type=f align=32 words (r78.0)
//.declare  (169)  rf=r size=128 type=f align=32 words (r80.0)
//.declare  (170)  rf=r size=128 type=f align=32 words (r82.0)
//.declare  (171)  rf=r size=128 type=f align=32 words (r84.0)
//.declare  (172)  rf=r size=128 type=f align=32 words (r86.0)
//.declare  (173)  rf=r size=64 type=f align=32 words (r65.0)
//.declare  (174)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0148 (177)  rf=r size=256 type=q align=32 words (r4.0)
//.declare V0149 (178)  rf=r size=256 type=uq alias=V0148+0 align=32 words (r4.0)
//.declare P08 (179)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0151 (181)  rf=r size=256 type=uq align=32 words (r1.0)
//.declare V0152 (182)  rf=r size=256 type=ud alias=V0151+0 align=32 words (r1.0)
//.declare V0153 (183)  rf=r size=128 type=d align=32 words (r6.0)
//.declare  (184)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (185)  rf=r size=64 type=ud align=32 words (r4.0)
//.declare  (186)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (187)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (188)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (191)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (192)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (195)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (196)  rf=r size=128 type=d align=32 words (r10.0)
//.declare  (197)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (198)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (199)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (200)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (201)  rf=r size=128 type=q align=32 words (r3.0)
//.declare  (202)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (203)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (204)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (205)  rf=r size=128 type=q align=32 words (r88.0)
//.declare  (206)  rf=r size=128 type=q align=32 words (r90.0)
//.declare  (207)  rf=r size=128 type=q align=32 words (r92.0)
//.declare  (208)  rf=r size=128 type=q align=32 words (r94.0)
//.declare  (209)  rf=r size=128 type=uq alias=+0 align=32 words (r12.0)
//.declare  (210)  rf=r size=128 type=uq alias=+0 align=32 words (r14.0)
//.declare  (211)  rf=r size=128 type=d alias=+0 align=32 words (r12.0)
//.declare  (212)  rf=r size=128 type=d alias=+0 align=32 words (r14.0)
//.declare  (213)  rf=r size=128 type=d alias=+0 align=32 words (r16.0)
//.declare  (214)  rf=r size=128 type=d alias=+0 align=32 words (r18.0)
//.declare  (215)  rf=r size=128 type=ud alias=+0 align=32 words (r7.0)
//.declare  (216)  rf=r size=128 type=ud alias=+0 align=32 words (r14.0)
//.declare  (217)  rf=r size=128 type=d alias=+0 align=32 words (r7.0)
//.declare  (218)  rf=r size=128 type=d alias=+0 align=32 words (r14.0)
//.declare r0 (219)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (220)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (221)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (222)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (223)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (224)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (225)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0034    | :uq      |    0x8 | r2+0x18  | inline+0x18      |
// | V0043    | :d       |    0x4 | r3       | cti+0x20         |
// | V0044    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0051    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0052    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0053    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0054    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0055    | :q       |    0x8 | r4       | cti+0x60         |
// | V0056    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0057    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0058    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0059    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0060    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0061    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0062    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0063    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0064    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0065    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0066    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0067    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0068    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0069    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B013}
// _main:
(W)     mov (16|M0)              r64.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r69.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r65.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r64.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r3.0<1>:d     r2.3<0;1,0>:d     r64.1<0;1,0>:d   {Compacted,$1.dst} //  ALU pipe: int; $4
(W)     shl (1|M0)               r4.0<1>:q     r3.1<0;1,0>:d     9:w                                 //  ALU pipe: int; $6
        add3 (32|M0)             r66.0<1>:d    r3.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {@2,$0.dst} //  ALU pipe: int; $4
        sync.nop                             null                             {Compacted,I@2}        // $7
(W)     mov (2|M0)               r5.0<1>:f     r4.0<1;1,0>:f                    {Compacted,$2.dst}   //  ALU pipe: float; $7
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r5.0<0;1,0>:ud    r66.0<1;1,0>:ud  {A@1}              //  ALU pipe: int; $8
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r5.1<0;1,0>:d     0:w                                 //  ALU pipe: int; $9
(~f0.0) cmp (32|M0)   (gt)f0.0   null<1>:ud    r5.1<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $11
(~f0.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $13
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B013}
_0_013:
(W)     mov (1|M0)               r2.0<1>:uq    r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $15
(W)     load.ugm.d32x1t.a64 (1|M0)  r1:1        [r2:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $16
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r1.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $17
(f2.0)  goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $18
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B013}
_0_014:
(W)     mov (1|M0)               r68.0<1>:uq   r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $20
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $23
        mov (16|M0)              r6.0<2>:f     r68.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $21
        mov (16|M16)             r8.0<2>:f     r68.0<0;1,0>:f                                        //  ALU pipe: float; $21
        mov (16|M0)              r6.1<2>:f     r68.1<0;1,0>:f                                        //  ALU pipe: float; $22
        mov (16|M16)             r8.1<2>:ud    r68.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $22
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$4} // ex_desc:0x0; desc:0x8200599 // $24
        cmp (32|M0)   (eq)f1.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$4.dst}          //  ALU pipe: int; $26
(~f1.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $27
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B011}
_0_015:
(W)     mov (1|M0)               r2.0<1>:uq    r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $29
(W)     add (1|M0)               r1.1<1>:d     r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $31
(W)     load.ugm.d32x1t.a64 (1|M0)  r1:1        [r2:1]             {I@1,$5} // ex_desc:0x0; desc:0x2108580 // $30
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r1.0<0;1,0>:d     r1.1<0;1,0>:d    {$5.dst}           //  ALU pipe: int; $32
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:d     r1.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $33
(W&f1.0) jmpi                                _0_016                                                  //  ALU pipe: int; $35
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_017:
        mov (16|M0)              r4.0<2>:ud    r66.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $38
        mov (16|M16)             r6.0<2>:ud    r67.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $38
        shr (16|M0)              r12.0<1>:uq   r4.0<2;1,0>:ud    9:w               {I@2}             //  ALU pipe: int; $38
        shr (16|M16)             r14.0<1>:uq   r6.0<2;1,0>:ud    9:w               {I@2}             //  ALU pipe: int; $38
(W)     add (1|M0)               r1.0<1>:d     r3.4<0;1,0>:d     1056:w               {Compacted}    //  ALU pipe: int; $50
        mov (16|M0)              r20.0<1>:d    r12.0<2;1,0>:d                   {Compacted,I@3}      //  ALU pipe: int; $39
        mov (16|M16)             r21.0<1>:d    r14.0<2;1,0>:d                   {Compacted,I@3}      //  ALU pipe: int; $40
(W)     mul (16|M0)              acc0.0<1>:ud  r20.0<1;1,0>:ud   r1.0<0;1,0>:uw   {I@2}              //  ALU pipe: int; $52
        macl (16|M0)             r4.0<1>:ud    r20.0<1;1,0>:ud   r1.0<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $53
(W)     mul (16|M16)             acc0.0<1>:ud  r21.0<1;1,0>:ud   r1.0<0;1,0>:uw   {I@3}              //  ALU pipe: int; $53
(W)     asr (1|M0)               r1.1<1>:d     r1.0<0;1,0>:d     31:w               {Compacted}      //  ALU pipe: int; $51
        macl (16|M16)            r6.0<1>:ud    r21.0<1;1,0>:ud   r1.0<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $54
(W)     mul (16|M0)              acc0.0<1>:ud  r20.0<1;1,0>:ud   r1.0<0;1,0>:uw                      //  ALU pipe: int; $54
        and (32|M0)              r8.0<1>:d     r66.0<1;1,0>:d    511:w               {Compacted}     //  ALU pipe: int; $43
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $45
        mov (16|M0)              r22.0<1>:d    r12.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $41
        mach (16|M0)             r12.0<1>:d    r20.0<1;1,0>:ud   r1.0<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r21.0<1;1,0>:ud   r1.0<0;1,0>:uw                      //  ALU pipe: int; $54
        mach (16|M16)            r13.0<1>:d    r21.0<1;1,0>:ud   r1.0<0;1,0>:ud                      //  ALU pipe: int; $55
(W)     mul (16|M0)              acc0.0<1>:d   r20.0<1;1,0>:ud   r1.2<0;1,0>:uw   {I@7}              //  ALU pipe: int; $55
        mov (16|M0)              r16.0<2>:d    r8.0<1;1,0>:d                    {I@7}                //  ALU pipe: int; $46
        mov (16|M0)              r16.1<2>:d    r10.0<1;1,0>:d                   {I@7}                //  ALU pipe: int; $48
        macl (16|M0)             r10.0<1>:d    r20.0<1;1,0>:ud   r1.1<0;1,0>:d                       //  ALU pipe: int; $55
(W)     mul (16|M16)             acc0.0<1>:d   r21.0<1;1,0>:ud   r1.2<0;1,0>:uw                      //  ALU pipe: int; $55
        mov (16|M16)             r18.0<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $47
        mov (16|M16)             r18.1<2>:d    r11.0<1;1,0>:d                                        //  ALU pipe: int; $49
        macl (16|M16)            r11.0<1>:d    r21.0<1;1,0>:ud   r1.1<0;1,0>:d                       //  ALU pipe: int; $56
        mov (16|M16)             r23.0<1>:d    r14.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $42
(W)     mul (16|M0)              acc0.0<1>:d   r1.0<0;1,0>:ud    r22.0<2;1,0>:uw                     //  ALU pipe: int; $57
        add (32|M0)              r12.0<1>:d    r12.0<1;1,0>:d    r10.0<1;1,0>:d   {Compacted,I@3}    //  ALU pipe: int; $56
        macl (16|M0)             r10.0<1>:d    r1.0<0;1,0>:ud    r22.0<1;1,0>:d                      //  ALU pipe: int; $57
(W)     mul (16|M16)             acc0.0<1>:d   r1.0<0;1,0>:ud    r23.0<2;1,0>:uw  {I@4}              //  ALU pipe: int; $57
        macl (16|M16)            r11.0<1>:d    r1.0<0;1,0>:ud    r23.0<1;1,0>:d                      //  ALU pipe: int; $58
        mov (16|M0)              r7.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $53
        mov (16|M16)             r14.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $54
        add (16|M0)              r7.1<2>:d     r12.0<1;1,0>:d    r10.0<1;1,0>:d   {I@5}              //  ALU pipe: int; $58
        add (16|M16)             r14.1<2>:d    r13.0<1;1,0>:d    r11.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $59
        shl (16|M0)              r3.0<1>:q     r7.0<1;1,0>:q     2:w               {Compacted,I@2}   //  ALU pipe: int; $60
        shl (16|M16)             r5.0<1>:q     r14.0<1;1,0>:q    2:w               {Compacted,I@2}   //  ALU pipe: int; $60
        shl (16|M0)              r88.0<1>:q    r16.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $63
        shl (16|M16)             r90.0<1>:q    r18.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $63
        add (16|M0)              r16.0<1>:q    r3.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $61
        add (16|M16)             r18.0<1>:q    r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $61
        load.ugm.d32x4.a64 (32|M0)  r24:8       [r16:4+0x40]       {I@1,$6} // ex_desc:0x40000; desc:0x8803580 // $66
        load.ugm.d32x4.a64 (32|M0)  r32:8       [r16:4+0x50]       {$7} // ex_desc:0x50000; desc:0x8803580 // $67
        load.ugm.d32x4.a64 (32|M0)  r40:8       [r16:4+0x60]       {$8} // ex_desc:0x60000; desc:0x8803580 // $68
        load.ugm.d32x4.a64 (32|M0)  r48:8       [r16:4+0x70]       {$9} // ex_desc:0x70000; desc:0x8803580 // $69
        add (16|M0)              r20.0<1>:q    r16.0<1;1,0>:q    128:w               {Compacted}     //  ALU pipe: int; $62
        add (16|M16)             r22.0<1>:q    r18.0<1;1,0>:q    128:w               {Compacted}     //  ALU pipe: int; $62
        add (16|M0)              r56.0<1>:q    r20.0<1;1,0>:q    r88.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $64
        add (16|M16)             r58.0<1>:q    r22.0<1;1,0>:q    r90.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $64
        load.ugm.d32.a64 (32|M0)  r70:2         [r56:4]            {I@1,$10} // ex_desc:0x0; desc:0x8200580 // $65
        add (16|M0)              r92.0<1>:q    r16.0<1;1,0>:q    2176:w                              //  ALU pipe: int; $85
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $86
        add (16|M16)             r94.0<1>:q    r18.0<1;1,0>:q    2176:w                              //  ALU pipe: int; $85
        add (32|M0)              r8.0<1>:f     r24.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,$6.dst} //  ALU pipe: float; $70
        add (32|M0)              r2.0<1>:f     r28.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $71
        add (32|M0)              r4.0<1>:f     r32.0<1;1,0>:f    r34.0<1;1,0>:f   {Compacted,$7.dst} //  ALU pipe: float; $72
        add (32|M0)              r6.0<1>:f     r36.0<1;1,0>:f    r38.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $73
        add (32|M0)              r10.0<1>:f    r40.0<1;1,0>:f    r42.0<1;1,0>:f   {Compacted,$8.dst} //  ALU pipe: float; $74
        add (32|M0)              r12.0<1>:f    r44.0<1;1,0>:f    r46.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $75
        add (32|M0)              r14.0<1>:f    r48.0<1;1,0>:f    r50.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $76
        add (32|M0)              r60.0<1>:f    r52.0<1;1,0>:f    r54.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $77
        add (32|M0)              r62.0<1>:f    r8.0<1;1,0>:f     r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $78
        add (32|M0)              r20.0<1>:f    r4.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted,F@6}    //  ALU pipe: float; $79
        add (32|M0)              r16.0<1>:f    r10.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,A@3}    //  ALU pipe: float; $80
        add (32|M0)              acc2.0<1>:f   r14.0<1;1,0>:f    r60.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $81
        add (32|M0)              acc0.0<1>:f   r62.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $82
        add (32|M0)              acc2.0<1>:f   r16.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $83
        add (32|M0)              r72.0<1>:f    acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $84
        math.invm (16|M0) (eo)f3.0  r80.mme0:f  r70.nomme<1;1,0>:f  r72.nomme<1;1,0>:f {A@1,$10.dst} //  ALU pipe: math; $86
(f3.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $86
// B007: [inDivergent],  Preds:{B006},  Succs:{B008}
_L_k0_2_:
        madm (16|M0)             r82.mme1:f    r65.nomme:f       r70.nomme:f       r80.mme0:f       {M@1} //  ALU pipe: float; $86
        madm (16|M0)             r84.mme2:f    r69.nomme:f       -r72.nomme:f      r80.mme0:f        //  ALU pipe: float; $86
        madm (16|M0)             r74.mme3:f    r80.mme0:f        r84.mme2:f        r80.mme0:f       {F@1} //  ALU pipe: float; $86
        madm (16|M0)             r86.mme4:f    r70.nomme:f       -r72.nomme:f      r82.mme1:f        //  ALU pipe: float; $86 R{} IR{}{E:3,E:4,E:1,},  {BC=1}
        madm (16|M0)             r82.mme5:f    r82.mme1:f        r86.mme4:f        r74.mme3:f       {F@1} //  ALU pipe: float; $86 R{} IR{}{E:1,E:3,E:5,},  {BC=1}
        madm (16|M0)             r78.mme6:f    r70.nomme:f       -r72.nomme:f      r82.mme5:f       {F@1} //  ALU pipe: float; $86 R{} IR{}{E:3,E:4,E:1,},  {BC=1}
        madm (16|M0)             r80.nomme:f   r82.mme5:f        r78.mme6:f        r74.mme3:f       {F@1} //  ALU pipe: float; $86 R{} IR{}{E:1,E:7,E:5,},  {BC=1}
// B008: [inDivergent],  Preds:{B007, B006},  Succs:{B009, B010}
_L_k0_0_macro:
        join (32|M0)                         _0_012                                                  // 
L1600:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $86
        math.invm (16|M16) (eo)f3.0  r81.mme0:f  r71.nomme<1;1,0>:f  r73.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $86
(f3.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $86
// B009: [inDivergent],  Preds:{B008},  Succs:{B010}
_L_k0_3_:
        madm (16|M16)            r83.mme1:f    r65.nomme:f       r71.nomme:f       r81.mme0:f       {M@1} //  ALU pipe: float; $86 R{} IR{}{O:0,O:3,O:0,},  {BC=1}
        madm (16|M16)            r85.mme2:f    r69.nomme:f       -r73.nomme:f      r81.mme0:f        //  ALU pipe: float; $86
        madm (16|M16)            r75.mme3:f    r81.mme0:f        r85.mme2:f        r81.mme0:f       {F@1} //  ALU pipe: float; $86
        madm (16|M16)            r87.mme4:f    r71.nomme:f       -r73.nomme:f      r83.mme1:f        //  ALU pipe: float; $86 R{} IR{}{O:3,O:4,O:1,},  {BC=1}
        madm (16|M16)            r83.mme5:f    r83.mme1:f        r87.mme4:f        r75.mme3:f       {F@1} //  ALU pipe: float; $86 R{} IR{}{O:1,O:3,O:5,},  {BC=1}
        madm (16|M16)            r79.mme6:f    r71.nomme:f       -r73.nomme:f      r83.mme5:f       {F@1} //  ALU pipe: float; $86 R{} IR{}{O:3,O:4,O:1,},  {BC=1}
        madm (16|M16)            r81.nomme:f   r83.mme5:f        r79.mme6:f        r75.mme3:f       {F@1} //  ALU pipe: float; $86 R{} IR{}{O:1,O:7,O:5,},  {BC=1}
// B010: [inDivergent],  Preds:{B009, B008},  Succs:{B013}
_L_k0_1_macro:
        join (32|M0)                         _0_012                                                  // 
L1776:
        mov (32|M0)              r2.0<1>:ud    r80.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $86
        add (16|M0)              r4.0<1>:q     r92.0<1;1,0>:q    r88.0<1;1,0>:q   {Compacted}        //  ALU pipe: int; $87
        add (16|M16)             r6.0<1>:q     r94.0<1;1,0>:q    r90.0<1;1,0>:q   {Compacted}        //  ALU pipe: int; $87
        store.ugm.d32.a64 (32|M0)  [r4:4]       r2:2               {I@1,$11} // ex_desc:0x0; desc:0x8000584 // $88
        goto (32|M0)                         _0_012            _0_012                                // $89
// B011: [inDivergent],  Preds:{B005},  Succs:{B012, B013}
_0_016:
        cmp (32|M0)   (eq)f0.0   null<1>:d     r66.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $91
(~f0.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $92
// B012: [inDivergent],  Preds:{B011},  Succs:{B013}
_0_018:
        mov (16|M0)              r1.0<2>:f     r68.0<0;1,0>:f                   {$11.src}            //  ALU pipe: float; $94
        mov (16|M16)             r3.0<2>:f     r68.0<0;1,0>:f                                        //  ALU pipe: float; $94
        mov (32|M0)              r6.0<1>:d     1:w                               {Compacted}         //  ALU pipe: int; $96
        mov (16|M0)              r1.1<2>:f     r68.1<0;1,0>:f                                        //  ALU pipe: float; $95
        mov (16|M16)             r3.1<2>:ud    r68.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $95
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r1:4]           r6:2               {A@1,$12} // ex_desc:0x0; desc:0x800058B // $97
// B013: Preds:{B012, B011, B010, B004, B003, B002},  Succs:{}
_0_012:
        join (32|M0)                         L1968                                                   // 
L1968:
(W)     mov (16|M0)              r127.0<1>:f   r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $99
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$13} // wr:1+0, rd:0; end of thread // $99
L1992:
(W)     mov (16|M0)              null<1>:ud    0x830D2F0:ud                                          // 
(W)     mov (16|M0)              null<1>:ud    0xEA18A4DC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0xE:ud                                                // 


//.BankConflicts: 9
//.ByteRMWs: 0
//


//.numALUInst: 131
//.accSubDef: 3
//.accSubUse: 3
//.accSubCandidateDef: 14
//.accSubCandidateUse: 14
//
//
//.singlePipeAtOneDistNum: 22
//.allAtOneDistNum: 7
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 11
//.AfterReadTokenDepCount: 2
