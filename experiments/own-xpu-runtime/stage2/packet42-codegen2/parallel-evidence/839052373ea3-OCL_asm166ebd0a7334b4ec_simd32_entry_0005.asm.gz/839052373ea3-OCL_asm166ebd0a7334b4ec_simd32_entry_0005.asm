//.kernel _ZTSN4sycl3_V16detail18RoundedRangeKernelINS0_4itemILi1ELb1EEELi1EZZNK11p42parallel5RouteILi4EE6submitERNS0_5queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS0_5eventESaISF_EEENKUlRNS0_7handlerEE_clESL_EUlNS0_2idILi1EEEE_EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 376356106 1932834028 -hashmovs1 0 5 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 376356106 1932834028 -hashmovs1 0 5 -GRFBumpUpNumber 2 "
//.instCount 316
//.RA type	LOCAL_FIRST_FIT_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.private memory size 65536

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r40.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.4)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.5)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.6)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r40.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r40.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r6.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0070 (80)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0071 (81)  rf=r size=8 type=q align=4 words (r5.7)
//.declare V0072 (82)  rf=r size=8 type=d align=2 words (r41.0)
//.declare V0073 (83)  rf=r size=8 type=d alias=V0043+0 align=32 words (r2.6)
//.declare V0074 (84)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0075 (85)  rf=r size=12 type=ud alias=V0038+0 align=32 words (r2.3)
//.declare V0076 (86)  rf=r size=32 type=ud alias=V0035+0 align=32 words (r40.0)
//.declare V0077 (87)  rf=r size=8 type=ud alias=V0074+0 align=4 words (r2.8)
//.declare V0078 (88)  rf=r size=8 type=d alias=V0074+0 align=4 words (r2.8)
//.declare V0079 (89)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0082 (92)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0085 (95)  rf=r size=12 type=ud alias=V0036+0 align=32 words (r2.0)
//.declare V0089 (99)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0090 (100)  rf=r size=128 type=d align=32 words (r44.0)
//.declare P01 (101)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0091 (102)  rf=r size=128 type=ud alias=V0089+0 align=32 words (r42.0)
//.declare V0092 (103)  rf=r size=8 type=ud alias=V0072+0 align=2 words (r41.0)
//.declare P02 (104)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P03 (105)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0093 (106)  rf=r size=128 type=ud alias=V0090+0 align=32 words (r44.0)
//.declare V0094 (107)  rf=r size=64 type=w align=32 words (r7.0)
//.declare V0095 (108)  rf=r size=8 type=uq alias=V0067+0 align=32 words (r5.3)
//.declare V0096 (109)  rf=r size=8 type=uq alias=V0069+0 align=32 words (r5.5)
//.declare V0097 (110)  rf=r size=8 type=uq alias=V0070+0 align=32 words (r5.6)
//.declare V0098 (111)  rf=r size=8 type=uq align=32 words (r46.0)
//.declare V0099 (112)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0100 (113)  rf=r size=4 type=d align=2 words (r41.2)
//.declare V0101 (114)  rf=r size=4 type=d align=2 words (r2.9)
//.declare V0102 (115)  rf=r size=4 type=d align=32 words (r47.0)
//.declare V0103 (116)  rf=r size=4 type=d align=2 words (r41.3)
//.declare V0104 (117)  rf=r size=4 type=ud alias=V0102+0 align=2 words (r47.0)
//.declare V0105 (118)  rf=r size=4 type=ud alias=V0045+0 align=32 words (r3.1)
//.declare V0106 (119)  rf=r size=4 type=ud alias=V0100+0 align=2 words (r41.2)
//.declare V0107 (120)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0109 (122)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0110 (123)  rf=r size=8 type=uq align=32 words (r48.0)
//.declare V0111 (124)  rf=r size=8 type=uq align=32 words (r50.0)
//.declare V0112 (125)  rf=r size=4 type=d align=2 words (r41.4)
//.declare V0113 (126)  rf=r size=4 type=d align=2 words (r41.5)
//.declare V0114 (127)  rf=r size=8 type=q align=4 words (r41.3)
//.declare P04 (128)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P05 (129)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0116 (131)  rf=r size=64 type=uw alias=V0094+0 align=32 words (r7.0)
//.declare V0117 (132)  rf=r size=128 type=d align=32 words (r52.0)
//.declare P06 (133)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0118 (134)  rf=r size=4 type=d align=2 words (r41.8)
//.declare V0119 (135)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0120 (136)  rf=r size=4 type=d align=2 words (r41.9)
//.declare V0121 (137)  rf=r size=128 type=ud alias=V0117+0 align=32 words (r52.0)
//.declare V0122 (138)  rf=r size=8 type=q align=4 words (r41.5)
//.declare V0123 (139)  rf=r size=12 type=ud alias=V0037+0 align=32 words (r6.0)
//.declare V0125 (141)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0126 (142)  rf=r size=128 type=d align=32 words (r56.0)
//.declare P07 (143)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0127 (144)  rf=r size=128 type=ud alias=V0125+0 align=32 words (r54.0)
//.declare P08 (145)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P09 (146)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0128 (147)  rf=r size=128 type=ud alias=V0126+0 align=32 words (r56.0)
//.declare V0129 (148)  rf=r size=4 type=ud alias=V0103+0 align=2 words (r41.3)
//.declare V0130 (149)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P10 (150)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0132 (152)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0133 (153)  rf=r size=256 type=ud alias=V0132+0 align=32 words (r7.0)
//.declare V0134 (154)  rf=r size=8 type=ud alias=V0098+0 align=32 words (r46.0)
//.declare V0135 (155)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0136 (156)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare P11 (158)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0138 (159)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P12 (160)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P13 (161)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0139 (162)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0140 (163)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0141 (164)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0142 (165)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0143 (166)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0144 (167)  rf=r size=4 type=f align=2 words (r2.8)
//.declare V0145 (168)  rf=r size=4 type=ud alias=V0120+0 align=2 words (r41.9)
//.declare V0146 (169)  rf=r size=4 type=d align=2 words (r2.9)
//.declare V0147 (170)  rf=r size=4 type=ud alias=V0146+0 align=2 words (r2.9)
//.declare V0148 (171)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0149 (172)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0150 (173)  rf=r size=128 type=ud alias=V0143+0 align=32 words (r12.0)
//.declare V0151 (174)  rf=r size=4 type=f align=2 words (r4.2)
//.declare V0152 (175)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0153 (176)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0154 (177)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0155 (178)  rf=r size=128 type=ud alias=V0154+0 align=32 words (r18.0)
//.declare V0156 (179)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0157 (180)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0158 (181)  rf=r size=128 type=ud alias=V0157+0 align=32 words (r10.0)
//.declare V0159 (182)  rf=r size=4 type=f align=2 words (r6.3)
//.declare V0160 (183)  rf=r size=4 type=ud alias=V0148+0 align=2 words (r3.0)
//.declare V0161 (184)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0162 (185)  rf=r size=128 type=ud alias=V0156+0 align=32 words (r20.0)
//.declare V0163 (186)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0169 (192)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0170 (193)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0171 (194)  rf=r size=128 type=ud alias=V0170+0 align=32 words (r28.0)
//.declare V0172 (195)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0173 (196)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0174 (197)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0175 (198)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0176 (199)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0177 (200)  rf=r size=128 type=ud alias=V0175+0 align=32 words (r14.0)
//.declare V0178 (201)  rf=r size=128 type=ud alias=V0176+0 align=32 words (r20.0)
//.declare  (202)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0179 (203)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0180 (204)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0181 (205)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0182 (206)  rf=r size=128 type=d align=32 words (r64.0)
//.declare P14 (207)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0183 (208)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0185 (210)  rf=r size=128 type=ud alias=V0140+0 align=32 words (r60.0)
//.declare V0186 (211)  rf=r size=4 type=ud alias=V0113+0 align=2 words (r41.5)
//.declare V0189 (214)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0190 (215)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0194 (219)  rf=r size=128 type=ud alias=V0182+0 align=32 words (r64.0)
//.declare V0198 (223)  rf=r size=256 type=uq align=32 words (r32.0)
//.declare V0199 (224)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0200 (225)  rf=r size=4 type=d align=2 words (r41.12)
//.declare V0202 (227)  rf=r size=4 type=ud alias=V0200+0 align=2 words (r41.12)
//.declare V0203 (228)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0206 (231)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0207 (232)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0208 (233)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0209 (234)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0210 (235)  rf=r size=128 type=ud alias=V0209+0 align=32 words (r14.0)
//.declare  (237)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare P15 (238)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0212 (239)  rf=r size=4 type=d align=2 words (r41.13)
//.declare V0213 (240)  rf=r size=4 type=d align=2 words (r41.14)
//.declare V0214 (241)  rf=r size=4 type=d align=2 words (r41.15)
//.declare V0215 (242)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0216 (243)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0217 (244)  rf=r size=128 type=ud alias=V0216+0 align=32 words (r68.0)
//.declare V0218 (245)  rf=r size=128 type=f align=32 words (r70.0)
//.declare  (247)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0220 (248)  rf=r size=4 type=d align=2 words (r46.2)
//.declare P16 (249)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0221 (250)  rf=r size=128 type=f align=32 words (r72.0)
//.declare V0222 (251)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0223 (252)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0224 (253)  rf=r size=128 type=ud alias=V0223+0 align=32 words (r8.0)
//.declare  (255)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0226 (256)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (258)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare P17 (259)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P18 (260)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0228 (261)  rf=r size=128 type=f align=32 words (r74.0)
//.declare  (263)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0230 (264)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (265)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (266)  rf=r size=128 type=f align=32 words (r76.0)
//.declare  (267)  rf=r size=128 type=f align=32 words (r78.0)
//.declare  (268)  rf=r size=128 type=f align=32 words (r80.0)
//.declare  (269)  rf=r size=128 type=f align=32 words (r82.0)
//.declare  (270)  rf=r size=128 type=f align=32 words (r84.0)
//.declare  (271)  rf=r size=128 type=f align=32 words (r86.0)
//.declare  (272)  rf=r size=128 type=f align=32 words (r88.0)
//.declare  (273)  rf=r size=64 type=f align=32 words (r49.0)
//.declare  (274)  rf=r size=64 type=f align=32 words (r51.0)
//.declare V0231 (277)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0236 (282)  rf=r size=256 type=uq align=32 words (r20.0)
//.declare V0237 (283)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0238 (284)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0239 (285)  rf=r size=128 type=ud alias=V0238+0 align=32 words (r10.0)
//.declare V0240 (286)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0241 (287)  rf=r size=128 type=ud alias=V0240+0 align=32 words (r12.0)
//.declare V0242 (288)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0243 (289)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0248 (294)  rf=r size=256 type=uq align=32 words (r26.0)
//.declare V0250 (296)  rf=r size=128 type=ud align=32 words (r30.0)
//.declare V0251 (297)  rf=r size=128 type=w alias=V0250+0 align=32 words (r30.0)
//.declare V0252 (298)  rf=r size=64 type=w align=32 words (r7.0)
//.declare V0253 (299)  rf=r size=64 type=w align=32 words (r33.0)
//.declare V0254 (300)  rf=r size=64 type=w align=32 words (r11.0)
//.declare V0255 (301)  rf=r size=64 type=w align=32 words (r10.0)
//.declare V0256 (302)  rf=r size=64 type=uw alias=V0252+0 align=32 words (r7.0)
//.declare V0257 (303)  rf=r size=64 type=uw alias=V0255+0 align=32 words (r10.0)
//.declare  (304)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0262 (309)  rf=r size=256 type=uq align=32 words (r36.0)
//.declare V0263 (310)  rf=r size=64 type=uw alias=V0254+0 align=32 words (r11.0)
//.declare V0264 (311)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare P19 (312)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P20 (313)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0266 (315)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0267 (316)  rf=r size=256 type=ud alias=V0266+0 align=32 words (r7.0)
//.declare V0268 (317)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0272 (321)  rf=r size=128 type=d align=32 words (r90.0)
//.declare V0273 (322)  rf=r size=128 type=d align=32 words (r92.0)
//.declare P21 (323)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0274 (324)  rf=r size=128 type=ud alias=V0272+0 align=32 words (r90.0)
//.declare P22 (325)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P23 (326)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0275 (327)  rf=r size=128 type=ud alias=V0273+0 align=32 words (r92.0)
//.declare  (331)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (332)  rf=r size=4 type=ud align=32 words (r3.0)
//.declare  (333)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (334)  rf=r size=128 type=uw align=32 words (r11.0)
//.declare  (337)  rf=r size=4 type=f align=2 words (r3.2)
//.declare  (338)  rf=r size=64 type=ud align=32 words (r10.0)
//.declare  (339)  rf=r size=64 type=ud align=32 words (r14.0)
//.declare  (340)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (341)  rf=r size=128 type=ud align=32 words (r28.0)
//.declare  (342)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (343)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (344)  rf=r size=64 type=uw align=32 words (r12.0)
//.declare  (345)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (346)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare  (347)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (348)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (351)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (352)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (353)  rf=r size=128 type=q align=32 words (r94.0)
//.declare  (354)  rf=r size=128 type=q align=32 words (r96.0)
//.declare  (359)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (360)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (361)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (362)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (363)  rf=r size=128 type=q align=32 words (r98.0)
//.declare  (364)  rf=r size=128 type=q align=32 words (r100.0)
//.declare  (367)  rf=r size=128 type=q align=32 words (r26.0)
//.declare  (368)  rf=r size=128 type=q align=32 words (r30.0)
//.declare  (375)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (376)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (381)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (382)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (387)  rf=r size=128 type=q align=32 words (r34.0)
//.declare  (388)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (391)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (392)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (395)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (396)  rf=r size=128 type=d align=32 words (r10.0)
//.declare  (397)  rf=r size=128 type=d alias=+0 align=32 words (r94.0)
//.declare  (398)  rf=r size=128 type=d alias=+0 align=32 words (r96.0)
//.declare  (399)  rf=r size=128 type=ud alias=+0 align=32 words (r11.0)
//.declare  (400)  rf=r size=128 type=ud alias=+0 align=32 words (r15.0)
//.declare  (401)  rf=r size=128 type=d alias=+0 align=32 words (r11.0)
//.declare  (402)  rf=r size=128 type=d alias=+0 align=32 words (r15.0)
//.declare  (403)  rf=r size=128 type=d alias=+0 align=32 words (r7.0)
//.declare  (404)  rf=r size=128 type=d alias=+0 align=32 words (r9.0)
//.declare r0 (405)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (406)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (407)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (408)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (409)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (410)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (411)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (412)  rf=r size=32 type=ud align=2 words (r6.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :d       |    0x4 | r3       | cti+0x20         |
// | V0045    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0046    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0047    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0048    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0049    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0050    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0051    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0052    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0053    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0054    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0055    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0056    | :q       |    0x8 | r4       | cti+0x60         |
// | V0057    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0058    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0059    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0060    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0061    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0062    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0063    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0064    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0065    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0066    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0067    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0068    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0069    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0070    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// | V0071    | :q       |    0x8 | r5+0x38  | cti+0xD8         |
// | V0037    | :d x 3   |    0xC | r6       | cti+0xE0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xE0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r6:1  bti[255][r127:1+0xC0]  {$3} // ex_desc:0xFF0C0000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B035}
// _main:
(W)     mov (16|M0)              r40.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r51.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r49.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r40.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r3.0<1>:ud    r2.3<0;1,0>:ud    r40.1<0;1,0>:ud  {Compacted,$1.dst} //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r40.2<0;1,0>:uw                     //  ALU pipe: int; $4
(W)     mach (1|M0)              r5.0<1>:d     r2.3<0;1,0>:ud    r40.1<0;1,0>:ud  {$2.dst}           //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r11.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.8<2>:ud    r3.0<0;1,0>:ud                   {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.9<2>:d     r5.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r41.0<1>:d    r2.6<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
        add (16|M0)              r9.0<1>:q     r2.4<0;1,0>:q     r7.0<4;1,0>:uw   {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r13.0<1>:q    r2.4<0;1,0>:q     r11.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r94.0<1>:q    r9.0<1;1,0>:q     r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r96.0<1>:q    r13.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r42.0<1>:d    r94.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r43.0<1>:d    r96.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r42.0<1;1,0>:ud   r41.0<0;1,0>:ud  {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r44.0<1>:d    r94.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r45.0<1>:d    r96.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r44.0<1;1,0>:d    r41.1<0;1,0>:d   {I@1}              //  ALU pipe: int; $18
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r44.0<1;1,0>:ud   r41.1<0;1,0>:ud                     //  ALU pipe: int; $20
(~f0.0) goto (32|M0)                         _0_045            _0_045                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_046:
(W)     mov (8|M0)               r7.0<1>:w     0x76543210:v                                          //  ALU pipe: int; $24
(W)     mul (1|M0)               r41.2<1>:d    r3.4<0;1,0>:d     2560:w                              //  ALU pipe: int; $29
(W)     add (8|M0)               r7.8<1>:w     r7.0<1;1,0>:w     8:w               {I@2}             //  ALU pipe: int; $25
(W)     asr (1|M0)               r2.9<1>:d     r41.2<0;1,0>:d    31:w               {I@2}            //  ALU pipe: int; $30
(W)     mul (1|M0)               acc0.0<1>:ud  r3.1<0;1,0>:ud    r41.4<0;1,0>:uw                     //  ALU pipe: int; $31
(W)     macl (1|M0)              r47.0<1>:ud   r3.1<0;1,0>:ud    r41.2<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $32
(W)     mul (1|M0)               acc0.0<1>:ud  r3.1<0;1,0>:ud    r41.4<0;1,0>:uw                     //  ALU pipe: int; $32
(W)     asr (1|M0)               r2.8<1>:d     r3.1<0;1,0>:d     31:w                                //  ALU pipe: int; $28
(W)     add (16|M0)              r7.16<1>:w    r7.0<1;1,0>:w     16:w               {I@6}            //  ALU pipe: int; $26
(W)     mach (1|M0)              r3.0<1>:d     r3.1<0;1,0>:ud    r41.2<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r3.1<0;1,0>:ud    r2.18<0;1,0>:uw  {I@7}              //  ALU pipe: int; $33
(W)     asr (1|M0)               r41.8<1>:d    r41.2<0;1,0>:d    31:w                                //  ALU pipe: int; $48
(W)     macl (1|M0)              r5.0<1>:d     r3.1<0;1,0>:ud    r2.9<0;1,0>:d                       //  ALU pipe: int; $34
(W)     cmp (32|M0)   (gt)f2.0   null<1>:d     r3.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $43
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r3.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $44
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $47
        shl (32|M0)              r52.0<1>:d    r7.0<1;1,0>:uw    2:w               {I@7}             //  ALU pipe: int; $46
(W)     mul (1|M0)               acc0.0<1>:d   r41.2<0;1,0>:ud   r2.16<0;1,0>:uw                     //  ALU pipe: int; $35
(W)     add (1|M0)               r3.0<1>:d     r3.0<0;1,0>:d     r5.0<0;1,0>:d    {Compacted,I@6}    //  ALU pipe: int; $34
(W)     macl (1|M0)              r5.0<1>:d     r41.2<0;1,0>:ud   r2.8<0;1,0>:d                       //  ALU pipe: int; $37
(W)     add (1|M0)               r2.8<1>:d     r41.8<0;1,0>:d    r41.2<0;1,0>:d                      //  ALU pipe: int; $49
(W)     mov (1|M0)               r46.0<1>:uq   r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $27
(W)     mov (1|M0)               r48.0<1>:uq   r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $38
(W)     mov (1|M0)               r50.0<1>:uq   r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $39
(W)     add (1|M0)               r41.4<1>:d    r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $40
(W)     add (1|M0)               r41.5<1>:d    r3.4<0;1,0>:d     1056:w                              //  ALU pipe: int; $41
(W)     add (1|M0)               r41.3<1>:q    r5.7<0;1,0>:q     4224:w                              //  ALU pipe: int; $42
(W)     mov (1|M0)               r41.5<1>:q    r6.0<0;1,0>:ud                   {$3.dst}             //  ALU pipe: int; $51
(W)     add (1|M0)               r41.3<1>:d    r3.0<0;1,0>:d     r5.0<0;1,0>:d    {I@7}              //  ALU pipe: int; $37
(W)     xor (1|M0)               r41.9<1>:d    r2.8<0;1,0>:d     r41.8<0;1,0>:d   {I@7}              //  ALU pipe: int; $50
// B004: [inDivergent],  Preds:{B034, B003},  Succs:{B005, B033}
_0_047:
        mov (16|M0)              r54.0<1>:d    r94.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $53
        mov (16|M16)             r55.0<1>:d    r96.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $54
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r54.0<1;1,0>:ud   r47.0<0;1,0>:ud  {I@1}              //  ALU pipe: int; $57
        mov (16|M0)              r56.0<1>:d    r94.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $55
        mov (16|M16)             r57.0<1>:d    r96.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $56
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r56.0<1;1,0>:d    r41.3<0;1,0>:d   {I@1}              //  ALU pipe: int; $58
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r56.0<1;1,0>:ud   r41.3<0;1,0>:ud                     //  ALU pipe: int; $60
(~f3.0) goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $62
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B033}
_0_049:
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r48:1]            {$5} // ex_desc:0x0; desc:0x2108580 // $64
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$5.dst}          //  ALU pipe: int; $65
(f3.0)  goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $66
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B033}
_0_050:
        mov (16|M0)              r7.0<2>:f     r46.0<0;1,0>:f                                        //  ALU pipe: float; $68
        mov (16|M16)             r9.0<2>:f     r46.0<0;1,0>:f                                        //  ALU pipe: float; $68
        mov (32|M0)              r12.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $70
        mov (16|M0)              r7.1<2>:f     r46.1<0;1,0>:f                                        //  ALU pipe: float; $69
        mov (16|M16)             r9.1<2>:ud    r46.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $69
        atomic_or.ugm.d32.a64 (32|M0)  r14:2    [r7:4]            r12:2              {A@1,$6} // ex_desc:0x0; desc:0x8200599 // $71
        cmp (32|M0)   (eq)f3.0   null<1>:d     r14.0<1;1,0>:d    0:w               {$6.dst}          //  ALU pipe: int; $73
(~f3.0) goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $74
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B031}
_0_051:
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r50:1]            {$7} // ex_desc:0x0; desc:0x2108580 // $76
(W)     cmp (32|M0)   (gt)f3.0   null<1>:d     r3.0<0;1,0>:d     r41.4<0;1,0>:d   {$7.dst}           //  ALU pipe: int; $77
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $78
(W&f3.0) jmpi                                _0_052                                                  //  ALU pipe: int; $80
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B010}
_0_053:
        mov (16|M0)              r58.0<1>:d    r94.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $82
        mov (16|M16)             r59.0<1>:d    r96.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $82
(W&~f0.0) jmpi                               _0_054                                                  //  ALU pipe: int; $83
// B009: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_055:
        mov (32|M0)              r60.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $85
(W)     jmpi                                 _0_056                                                  // $86
// B010: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_054:
        asr (32|M0)              r8.0<1>:d     r58.0<1;1,0>:d    31:w               {Compacted,I@4}  //  ALU pipe: int; $88
        add (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     r58.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $89
        xor (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $90
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $91
(W)     mov (1|M0)               r2.8<1>:f     r41.9<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $92
(W)     mov (1|M0)               r3.2<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $97
(W)     math.inv (1|M0)          r4.2<1>:f     r2.8<0;1,0>:f                    {F@2}                //  ALU pipe: math; $96
        mov (32|M0)              r14.0<1>:f    r12.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $95
(W)     mad (1|M0)               r5.0<1>:f     r4.2<0;0>:f       r3.2<0;0>:f       r4.2<0>:f        {A@1} //  ALU pipe: float; $97
        mov (32|M0)              r18.0<1>:ud   r14.0<1;1,0>:f                   {F@2}                //  ALU pipe: int; $99
        mul (32|M0)              r16.0<1>:f    r14.0<1;1,0>:f    r5.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $98
(W)     mov (1|M0)               r2.9<1>:ud    r2.8<0;1,0>:f                                         //  ALU pipe: int; $93
        add (32|M0)              r20.0<1>:d    r12.0<1;1,0>:d    -r18.0<1;1,0>:d  {Compacted,@2,$4.src} //  ALU pipe: int; $100
        mov (32|M0)              r10.0<1>:ud   r16.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $101
(W)     add (1|M0)               r3.0<1>:d     r41.9<0;1,0>:d    -r2.9<0;1,0>:d   {I@3}              //  ALU pipe: int; $94
        mov (32|M0)              r24.0<1>:f    r10.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $104
        mov (32|M0)              r22.0<1>:f    r20.0<1;1,0>:ud                                       //  ALU pipe: float; $103
(W)     mov (1|M0)               r6.3<1>:f     r3.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $102
        mad (32|M0)              acc0.0<1>:f   r14.0<1;0>:f      r24.0<1;0>:f      -r2.8<0>:f       {F@3} //  ALU pipe: float; $106 R{} IR{}{E:7,E:4,E:1,},  R{r2,} IR{}{O:7,O:12,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r22.0<1;0>:f      r24.0<1;0>:f      -r6.3<0>:f       {F@2} //  ALU pipe: float; $108 R{} IR{}{E:3,E:4,E:3,},  R{r6,} IR{}{O:11,O:12,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $109
        mul (32|M0)              r26.0<1>:f    r5.0<0;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $110
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $111
        mov (32|M0)              r28.0<1>:ud   r26.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $112
        add (32|M0)              r30.0<1>:d    r28.0<1;1,0>:d    r10.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $113
(W)     mul (16|M0)              acc0.0<1>:d   r30.0<1;1,0>:d    r41.18<0;1,0>:uw {I@1}              //  ALU pipe: int; $115
        macl (16|M0)             r16.0<1>:d    r30.0<1;1,0>:d    r41.9<0;1,0>:d   {Compacted}        //  ALU pipe: int; $115
(W)     mul (16|M16)             acc0.0<1>:d   r31.0<1;1,0>:d    r41.18<0;1,0>:uw                    //  ALU pipe: int; $115
        macl (16|M16)            r17.0<1>:d    r31.0<1;1,0>:d    r41.9<0;1,0>:d   {Compacted}        //  ALU pipe: int; $116
        add (32|M0)              r14.0<1>:d    r12.0<1;1,0>:d    -r16.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $116
        cmp (32|M0)   (ge)f3.0   r20.0<1>:ud   r14.0<1;1,0>:ud   r41.9<0;1,0>:ud  {I@1}              //  ALU pipe: int; $117
        xor (32|M0)              r18.0<1>:d    r41.8<0;1,0>:d    r8.0<1;1,0>:d    {Compacted}        //  ALU pipe: int; $114
        add3 (32|M0)             r22.0<1>:d    r30.0<1;0>:d      r18.0<1;0>:d      -r20.0<1>:d      {Compacted,I@1} //  ALU pipe: int; $118 R{} IR{}{E:7,E:1,E:2,},  R{} IR{}{O:15,O:9,O:10,},  {BC=2}
        bfn.(s0^s1^s2) (32|M0)   r60.0<1>:ud   r22.0<1;0>:ud     r41.8<0;0>:ud     r8.0<1>:ud       {I@1} //  ALU pipe: int; $119
// B011: [inDivergent],  Preds:{B010, B009},  Succs:{B012, B030}
_0_056:
(W)     mul (16|M0)              acc0.0<1>:d   r60.0<1;1,0>:d    r3.8<0;1,0>:uw   {I@1}              //  ALU pipe: int; $121
        macl (16|M0)             r62.0<1>:d    r60.0<1;1,0>:d    r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $121
(W)     mul (16|M16)             acc0.0<1>:d   r61.0<1;1,0>:d    r3.8<0;1,0>:uw                      //  ALU pipe: int; $121
        macl (16|M16)            r63.0<1>:d    r61.0<1;1,0>:d    r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $122
(W)     mul (16|M0)              acc0.0<1>:d   r60.0<1;1,0>:d    r41.4<0;1,0>:uw                     //  ALU pipe: int; $122
        macl (16|M0)             r8.0<1>:d     r60.0<1;1,0>:d    r41.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $122
(W)     mul (16|M16)             acc0.0<1>:d   r61.0<1;1,0>:d    r41.4<0;1,0>:uw                     //  ALU pipe: int; $122
        macl (16|M16)            r9.0<1>:d     r61.0<1;1,0>:d    r41.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $123
        add (32|M0)              r64.0<1>:d    r58.0<1;1,0>:d    -r8.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $123
        cmp (32|M0)   (lt)f3.0   null<1>:d     r64.0<1;1,0>:d    r3.4<0;1,0>:d    {I@1}              //  ALU pipe: int; $124
(~f3.0) goto (32|M0)                         _0_057            _0_057                                //  ALU pipe: int; $125
// B012: [inDivergent],  Preds:{B011},  Succs:{B013, B015}
_0_058:
(W)     mul (16|M0)              acc0.0<1>:ud  r60.0<1;1,0>:ud   r41.10<0;1,0>:uw                    //  ALU pipe: int; $128
        asr (32|M0)              r8.0<1>:d     r60.0<1;1,0>:d    31:w               {Compacted}      //  ALU pipe: int; $127
        macl (16|M0)             r10.0<1>:ud   r60.0<1;1,0>:ud   r41.5<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $129
(W)     mul (16|M16)             acc0.0<1>:ud  r61.0<1;1,0>:ud   r41.10<0;1,0>:uw                    //  ALU pipe: int; $129
        macl (16|M16)            r14.0<1>:ud   r61.0<1;1,0>:ud   r41.5<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $130
(W)     mul (16|M0)              acc0.0<1>:ud  r60.0<1;1,0>:ud   r41.10<0;1,0>:uw                    //  ALU pipe: int; $130
        mach (16|M0)             r18.0<1>:d    r60.0<1;1,0>:ud   r41.5<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r61.0<1;1,0>:ud   r41.10<0;1,0>:uw                    //  ALU pipe: int; $130
        mach (16|M16)            r19.0<1>:d    r61.0<1;1,0>:ud   r41.5<0;1,0>:ud                     //  ALU pipe: int; $132
(W)     mul (16|M0)              acc0.0<1>:d   r41.5<0;1,0>:ud   r8.0<2;1,0>:uw   {I@7}              //  ALU pipe: int; $133
        macl (16|M0)             r20.0<1>:d    r41.5<0;1,0>:ud   r8.0<1;1,0>:d    {$4.src}           //  ALU pipe: int; $133
(W)     mul (16|M16)             acc0.0<1>:d   r41.5<0;1,0>:ud   r9.0<2;1,0>:uw                      //  ALU pipe: int; $133
        macl (16|M16)            r21.0<1>:d    r41.5<0;1,0>:ud   r9.0<1;1,0>:d                       //  ALU pipe: int; $134
        mov (16|M0)              r11.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $129
        mov (16|M16)             r15.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $130
        add (16|M0)              r11.1<2>:d    r18.0<1;1,0>:d    r20.0<1;1,0>:d   {I@5}              //  ALU pipe: int; $134
        add (16|M16)             r15.1<2>:d    r19.0<1;1,0>:d    r21.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $135
        mov (16|M0)              r24.0<2>:ud   r64.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $139
        mov (16|M16)             r28.0<2>:ud   r65.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $139
        shl (16|M0)              r22.0<1>:q    r11.0<1;1,0>:q    2:w               {Compacted,I@4}   //  ALU pipe: int; $136
        shl (16|M16)             r13.0<1>:q    r15.0<1;1,0>:q    2:w               {Compacted,I@4}   //  ALU pipe: int; $136
        shl (16|M0)              r26.0<1>:q    r24.0<2;1,0>:ud   2:w               {I@4}             //  ALU pipe: int; $139
        shl (16|M16)             r30.0<1>:q    r28.0<2;1,0>:ud   2:w               {I@4}             //  ALU pipe: int; $139
        add (16|M0)              r98.0<1>:q    r41.3<0;1,0>:q    r22.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $137
        add (16|M16)             r100.0<1>:q   r41.3<0;1,0>:q    r13.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $137
        add (16|M0)              r32.0<1>:q    r98.0<1;1,0>:q    r26.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $140
        add (16|M16)             r34.0<1>:q    r100.0<1;1,0>:q   r30.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $140
        load.ugm.d32.a64 (32|M0)  r66:2         [r32:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $142
(W&~f2.0) jmpi                               _0_059                                                  //  ALU pipe: int; $143
// B013: [inDivergent],  Preds:{B012},  Succs:{B014}
_0_060:
(W)     mov (1|M0)               r41.12<1>:d   0:w                                                   //  ALU pipe: int; $145
// B014: [inDivergent],  Preds:{B014, B013},  Succs:{B015, B014}
_0_061:
(W)     shl (1|M0)               r2.4<1>:q     r41.12<0;1,0>:ud  2:w               {I@1}             //  ALU pipe: int; $148
(W)     mul (1|M0)               r3.0<1>:d     r41.12<0;1,0>:d   128:w               {Compacted}     //  ALU pipe: int; $152
        add (16|M0)              r7.0<1>:q     r98.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $149 R{} IR{}{E:1,E:1,},  R{r2,} IR{} {BC=1}
        add (16|M16)             r9.0<1>:q     r100.0<1;1,0>:q   r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $149
        load.ugm.d32.a64 (32|M0)  r12:2         [r7:4]             {I@1,$10} // ex_desc:0x0; desc:0x8200580 // $151
        sync.nop                             null                             {Compacted,F@1}        // $154
(W)     shr (1|M0)               a0.0<1>:ud    r40.5<0;1,0>:ud   0x4:uw              {$9.src}        //  ALU pipe: int; $154
(W)     add (1|M0)               r41.12<1>:d   r41.12<0;1,0>:d   1:w                                 //  ALU pipe: int; $156
        add (32|M0)              r14.0<1>:d    r52.0<1;1,0>:d    r3.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $153
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r41.12<0;1,0>:d   r3.4<0;1,0>:d    {I@2}              //  ALU pipe: int; $157
        sync.nop                             null                             {Compacted,$10.dst}    // $155
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r14:2] r12:2     {I@2,$9} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $155
(W&f3.0) jmpi                                _0_061                                                  //  ALU pipe: int; $158
// B015: [inDivergent],  Preds:{B014, B012},  Succs:{B016, B025}
_0_059:
(W&~f1.0) jmpi                               _0_062                                                  //  ALU pipe: int; $160
// B016: [inDivergent],  Preds:{B015},  Succs:{B017}
_0_063:
(W)     mov (1|M0)               r41.13<1>:d   1:w                                                   //  ALU pipe: int; $162
// B017: [inDivergent],  Preds:{B024, B016},  Succs:{B018, B023}
_0_064:
(W)     shl (1|M0)               r41.14<1>:d   r41.13<0;1,0>:d   1:w               {I@1}             //  ALU pipe: int; $164
(W&~f2.0) jmpi                               _0_065                                                  //  ALU pipe: int; $165
// B018: [inDivergent],  Preds:{B017},  Succs:{B019}
_0_066:
(W)     mov (1|M0)               r41.15<1>:d   0:w                                                   //  ALU pipe: int; $167
// B019: [inDivergent],  Preds:{B022, B018},  Succs:{B020, B021}
_0_067:
(W)     mul (1|M0)               r2.8<1>:d     r41.15<0;1,0>:d   128:w               {I@1}           //  ALU pipe: int; $169
        sync.nop                             null                             {Compacted,$11.src}    // $171
(W)     shr (1|M0)               a0.0<1>:ud    r40.5<0;1,0>:ud   0x4:uw              {$9.src}        //  ALU pipe: int; $171
        add (32|M0)              r68.0<1>:d    r52.0<1;1,0>:d    r2.8<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $170
        load.ugm.d32.a32.ca.ca (32|M0)  r70:2   ss[a0.0][r68:2]    {I@1,$12} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $172
(W)     add (1|M0)               r46.2<1>:d    r41.15<0;1,0>:d   r41.13<0;1,0>:d                     //  ALU pipe: int; $173
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r46.2<0;1,0>:d    r3.4<0;1,0>:d    {I@1}              //  ALU pipe: int; $174
(W&f3.0) jmpi                                _0_068                                                  //  ALU pipe: int; $175
// B020: [inDivergent],  Preds:{B019},  Succs:{B022}
_0_069:
        mov (32|M0)              r72.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $177
(W)     jmpi                                 _0_070                                                  // $178
// B021: [inDivergent],  Preds:{B019},  Succs:{B022}
_0_068:
(W)     mul (1|M0)               r2.8<1>:d     r46.2<0;1,0>:d    128:w                               //  ALU pipe: int; $180
(W)     shr (1|M0)               a0.0<1>:ud    r40.5<0;1,0>:ud   0x4:uw              {$12.src}       //  ALU pipe: int; $182
        add (32|M0)              r8.0<1>:d     r52.0<1;1,0>:d    r2.8<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $181
        load.ugm.d32.a32.ca.ca (32|M0)  r72:2   ss[a0.0][r8:2]     {I@1,$13} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $183
// B022: [inDivergent],  Preds:{B021, B020},  Succs:{B023, B019}
_0_070:
        sync.nop                             null                             {Compacted,$13.src}    // $186
(W)     shr (1|M0)               a0.0<1>:ud    r40.5<0;1,0>:ud   0x4:uw              {$12.src}       //  ALU pipe: int; $186
        sync.nop                             null                             {Compacted,$13.dst}    // $185
        add (32|M0)              r8.0<1>:f     r70.0<1;1,0>:f    r72.0<1;1,0>:f   {Compacted,$12.dst} //  ALU pipe: float; $185
(W)     add (1|M0)               r41.15<1>:d   r41.15<0;1,0>:d   r41.14<0;1,0>:d                     //  ALU pipe: int; $188
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r68:2] r8:2      {F@1,$11} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $187
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r41.15<0;1,0>:d   r3.4<0;1,0>:d    {I@1}              //  ALU pipe: int; $189
(W&f3.0) jmpi                                _0_067                                                  //  ALU pipe: int; $190
// B023: [inDivergent],  Preds:{B022, B017},  Succs:{B024, B025}
_0_065:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r41.14<0;1,0>:d   r3.4<0;1,0>:d                       //  ALU pipe: int; $192
(W&~f3.0) jmpi                               _0_062                                                  //  ALU pipe: int; $193
// B024: [inDivergent],  Preds:{B023},  Succs:{B017}
_0_071:
(W)     mov (1|M0)               r41.13<1>:d   r41.14<0;1,0>:d                                       //  ALU pipe: int; $195
(W)     jmpi                                 _0_064                                                  // $196
// B025: [inDivergent],  Preds:{B023, B015},  Succs:{B026, B027}
_0_062:
        sync.nop                             null                             {Compacted,$11.src}    // $198
(W)     shr (1|M0)               a0.0<1>:ud    r40.5<0;1,0>:ud   0x4:uw              {$9.src}        //  ALU pipe: int; $198
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $200
        load.ugm.d32.a32.ca.ca (32|M0)  r74:2   ss[a0.0][r52:2]    {$14} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $199
        sync.nop                             null                             {Compacted,I@1}        // $200
        sync.nop                             null                             {Compacted,$14.dst}    // $200
        math.invm (16|M0) (eo)f3.0  r82.mme0:f  r66.nomme<1;1,0>:f  r74.nomme<1;1,0>:f {$8.dst}      //  ALU pipe: math; $200
(f3.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $200
// B026: [inDivergent],  Preds:{B025},  Succs:{B027}
_L_k0_2_:
        madm (16|M0)             r84.mme1:f    r49.nomme:f       r66.nomme:f       r82.mme0:f       {M@1} //  ALU pipe: float; $200 R{} IR{}{O:0,E:1,E:1,},  {BC=1}
        madm (16|M0)             r86.mme2:f    r51.nomme:f       -r74.nomme:f      r82.mme0:f        //  ALU pipe: float; $200
        madm (16|M0)             r76.mme3:f    r82.mme0:f        r86.mme2:f        r82.mme0:f       {F@1} //  ALU pipe: float; $200
        madm (16|M0)             r88.mme4:f    r66.nomme:f       -r74.nomme:f      r84.mme1:f        //  ALU pipe: float; $200 R{} IR{}{E:1,E:5,E:2,},  {BC=1}
        madm (16|M0)             r84.mme5:f    r84.mme1:f        r88.mme4:f        r76.mme3:f       {F@1} //  ALU pipe: float; $200 R{} IR{}{E:2,E:4,E:6,},  {BC=1}
        madm (16|M0)             r80.mme6:f    r66.nomme:f       -r74.nomme:f      r84.mme5:f       {F@1} //  ALU pipe: float; $200 R{} IR{}{E:1,E:5,E:2,},  {BC=1}
        madm (16|M0)             r82.nomme:f   r84.mme5:f        r80.mme6:f        r76.mme3:f       {F@1} //  ALU pipe: float; $200 R{} IR{}{E:2,E:0,E:6,},  {BC=1}
// B027: [inDivergent],  Preds:{B026, B025},  Succs:{B028, B029}
_L_k0_0_macro:
        join (32|M0)                         _0_057                                                  // 
L3136:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $200
        math.invm (16|M16) (eo)f3.0  r83.mme0:f  r67.nomme<1;1,0>:f  r75.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $200
(f3.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $200
// B028: [inDivergent],  Preds:{B027},  Succs:{B029}
_L_k0_3_:
        madm (16|M16)            r85.mme1:f    r49.nomme:f       r67.nomme:f       r83.mme0:f       {M@1} //  ALU pipe: float; $200 R{} IR{}{O:0,O:1,O:1,},  {BC=1}
        madm (16|M16)            r87.mme2:f    r51.nomme:f       -r75.nomme:f      r83.mme0:f        //  ALU pipe: float; $200
        madm (16|M16)            r77.mme3:f    r83.mme0:f        r87.mme2:f        r83.mme0:f       {F@1} //  ALU pipe: float; $200
        madm (16|M16)            r89.mme4:f    r67.nomme:f       -r75.nomme:f      r85.mme1:f        //  ALU pipe: float; $200 R{} IR{}{O:1,O:5,O:2,},  {BC=1}
        madm (16|M16)            r85.mme5:f    r85.mme1:f        r89.mme4:f        r77.mme3:f       {F@1} //  ALU pipe: float; $200 R{} IR{}{O:2,O:4,O:6,},  {BC=1}
        madm (16|M16)            r81.mme6:f    r67.nomme:f       -r75.nomme:f      r85.mme5:f       {F@1} //  ALU pipe: float; $200 R{} IR{}{O:1,O:5,O:2,},  {BC=1}
        madm (16|M16)            r83.nomme:f   r85.mme5:f        r81.mme6:f        r77.mme3:f       {F@1} //  ALU pipe: float; $200 R{} IR{}{O:2,O:0,O:6,},  {BC=1}
// B029: [inDivergent],  Preds:{B028, B027},  Succs:{B030}
_L_k0_1_macro:
        join (32|M0)                         _0_057                                                  // 
L3312:
        add (32|M0)              r10.0<1>:d    r62.0<1;1,0>:d    r64.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $201
        mov (16|M0)              r12.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $203
        mov (16|M16)             r16.0<2>:ud   r11.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $203
        shl (16|M0)              r14.0<1>:q    r12.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $203
        shl (16|M16)             r18.0<1>:q    r16.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $203
        mov (32|M0)              r8.0<1>:ud    r82.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $200
        add (16|M0)              r20.0<1>:q    r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $204
        add (16|M16)             r22.0<1>:q    r18.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $204
        store.ugm.d32.a64 (32|M0)  [r20:4]      r8:2               {I@1,$15} // ex_desc:0x0; desc:0x8000584 // $206
// B030: [inDivergent],  Preds:{B029, B011},  Succs:{B033}
_0_057:
        join (32|M0)                         _0_048                                                  // 
L3424:
(W)     mul (16|M0)              acc0.0<1>:ud  r64.0<1;1,0>:ud   0xCCCD:uw                           //  ALU pipe: int; $209
        mach (16|M0)             r10.0<1>:ud   r64.0<1;1,0>:ud   0xCCCCCCCD:ud                       //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r65.0<1;1,0>:ud   0xCCCD:uw                           //  ALU pipe: int; $209
        mach (16|M16)            r11.0<1>:ud   r65.0<1;1,0>:ud   0xCCCCCCCD:ud                       //  ALU pipe: int; $210
        shr (32|M0)              r12.0<1>:ud   r10.0<1;1,0>:ud   11:w               {I@1}            //  ALU pipe: int; $210
        mad (32|M0)              r14.0<1>:d    r64.0<1;0>:d      r12.0<1;0>:d      -2560:w               {I@1} //  ALU pipe: int; $211
        mad (32|M0)              r16.0<1>:d    r14.0<1;0>:d      r60.0<1;0>:d      2560:w               {I@1} //  ALU pipe: int; $212
        mov (16|M0)              r18.0<2>:ud   r16.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $214
        mov (16|M16)             r22.0<2>:ud   r17.0<1;1,0>:ud                  {Compacted,$15.src}  //  ALU pipe: int; $214
        shl (16|M0)              r20.0<1>:q    r18.0<2;1,0>:d    1:w               {@2,$4.src}       //  ALU pipe: int; $214
        shl (16|M16)             r24.0<1>:q    r22.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $214
        add (16|M0)              r26.0<1>:q    r20.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $215
        add (16|M16)             r28.0<1>:q    r24.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $215
        load.ugm.d16u32.a64 (32|M0)  r30:2      [r26:4]            {I@1,$0} // ex_desc:0x0; desc:0x8200B80 // $217
        mad (32|M0)              r8.0<1>:d     r64.0<1;0>:d      r62.0<1;0>:d      2560:w               //  ALU pipe: int; $208
        mov (16|M0)              r14.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $224
        mov (16|M16)             r18.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $224
        shl (16|M0)              r34.0<1>:q    r14.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $224
        shl (16|M16)             r16.0<1>:q    r18.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $224
        add (16|M0)              r36.0<1>:q    r34.0<1;1,0>:q    r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $225
        add (16|M16)             r38.0<1>:q    r16.0<1;1,0>:q    r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $225
        and (32|M0)              r7.0<1>:w     r30.0<2;1,0>:w    32767:w               {$0.dst}      //  ALU pipe: int; $219
        cmp (32|M0)   (gt)f3.0   r10.0<1>:uw   r7.0<1;1,0>:uw    0x7F80:uw              {I@1}        //  ALU pipe: int; $221
        or (32|M0)               r33.0<1>:w    r30.0<2;1,0>:w    64:w                                //  ALU pipe: int; $220
        mov (32|M0)              r12.0<1>:uw   r30.0<2;1,0>:uw                                       //  ALU pipe: int; $222
        bfn.(s0&s1|~s0&s2) (32|M0)   r11.0<1>:uw  r10.0<1;0>:uw  r33.0<1;0>:uw     r12.0<1>:uw      {I@1} //  ALU pipe: int; $222
        mov (32|M0)              r20.0<1>:ud   r11.0<1;1,0>:uw                  {I@1}                //  ALU pipe: int; $227
        store.ugm.d16u32.a64 (32|M0)  [r36:4]   r20:2              {I@1,$4} // ex_desc:0x0; desc:0x8000B84 // $228
        goto (32|M0)                         _0_048            _0_048                                // $229
// B031: [inDivergent],  Preds:{B007},  Succs:{B032, B033}
_0_052:
        cmp (32|M0)   (eq)f3.0   null<1>:d     r54.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $231
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r56.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $232
(~f3.0) goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $234
// B032: [inDivergent],  Preds:{B031},  Succs:{B033}
_0_072:
        mov (16|M0)              r7.0<2>:f     r46.0<0;1,0>:f                                        //  ALU pipe: float; $236
        mov (16|M16)             r9.0<2>:f     r46.0<0;1,0>:f                                        //  ALU pipe: float; $236
        mov (32|M0)              r12.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $238
        mov (16|M0)              r7.1<2>:f     r46.1<0;1,0>:f                                        //  ALU pipe: float; $237
        mov (16|M16)             r9.1<2>:ud    r46.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $237
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r7:4]           r12:2              {A@1,$1} // ex_desc:0x0; desc:0x800058B // $239
// B033: [inDivergent],  Preds:{B032, B031, B030, B006, B005, B004},  Succs:{B034, B035}
_0_048:
        join (32|M0)                         _0_045                                                  // 
L3976:
        sync.nop                             null                             {Compacted,$1.src}     // $241
        add (16|M0)              r7.0<1>:q     r94.0<1;1,0>:q    r41.5<0;1,0>:q   {Compacted,$15.src} //  ALU pipe: int; $241
        add (16|M16)             r9.0<1>:q     r96.0<1;1,0>:q    r41.5<0;1,0>:q   {Compacted}        //  ALU pipe: int; $241
        mov (16|M0)              r90.0<1>:d    r7.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $242
        mov (16|M16)             r91.0<1>:d    r9.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $243
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r90.0<1;1,0>:ud   r41.0<0;1,0>:ud  {I@1}              //  ALU pipe: int; $246
        mov (16|M0)              r92.0<1>:d    r7.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $244
        mov (16|M16)             r93.0<1>:d    r9.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $245
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r92.0<1;1,0>:d    r41.1<0;1,0>:d   {I@1}              //  ALU pipe: int; $247
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r92.0<1;1,0>:ud   r41.1<0;1,0>:ud                     //  ALU pipe: int; $249
(~f3.0) goto (32|M0)                         _0_045            _0_045                                //  ALU pipe: int; $251
// B034: [inDivergent],  Preds:{B033},  Succs:{B004}
_0_073:
(f3.0)  sel (32|M0)              r8.0<1>:d     r90.0<1;1,0>:d    r42.0<1;1,0>:d                      //  ALU pipe: int; $253 R{} IR{}{E:5,E:5,},  R{} IR{}{O:13,O:5,},  {BC=1}
(f3.0)  sel (32|M0)              r10.0<1>:d    r92.0<1;1,0>:d    r44.0<1;1,0>:d                      //  ALU pipe: int; $254 R{} IR{}{E:6,E:6,},  R{} IR{}{O:14,O:6,},  {BC=1}
        mov (16|M0)              r94.0<2>:d    r8.0<1;1,0>:d                    {I@2}                //  ALU pipe: int; $257
        mov (16|M16)             r96.0<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $258
        mov (16|M0)              r94.1<2>:d    r10.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $259
        mov (16|M16)             r96.1<2>:d    r11.0<1;1,0>:d                                        //  ALU pipe: int; $260
(W)     jmpi                                 _0_047                                                  // $261
// B035: Preds:{B033, B002},  Succs:{}
_0_045:
        join (32|M0)                         L4224                                                   // 
L4224:
(W)     mov (16|M0)              r127.0<1>:f   r40.0<1;1,0>:f                   {Compacted,$3.src}   //  ALU pipe: float; $263
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$2} // wr:1+0, rd:0; end of thread // $263
L4248:
(W)     mov (16|M0)              null<1>:ud    0x166EBD0A:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x7334B4EC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x5:ud                                                // 


//.BankConflicts: 17
//.ByteRMWs: 0
//


//.numALUInst: 269
//.accSubDef: 3
//.accSubUse: 3
//.accSubCandidateDef: 3
//.accSubCandidateUse: 3
//
//
//.singlePipeAtOneDistNum: 61
//.allAtOneDistNum: 10
//.syncInstCount: 9
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 13
//.AfterReadTokenDepCount: 16
