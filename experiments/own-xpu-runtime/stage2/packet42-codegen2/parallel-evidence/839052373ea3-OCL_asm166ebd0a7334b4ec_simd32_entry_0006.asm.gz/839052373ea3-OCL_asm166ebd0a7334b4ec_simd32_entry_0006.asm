//.kernel _ZTSZZNK11p42parallel5RouteILi4EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_2idILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 376356106 1932834028 -hashmovs1 0 6 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 376356106 1932834028 -hashmovs1 0 6 -GRFBumpUpNumber 2 "
//.instCount 268
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.private memory size 65536

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r54.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r54.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r54.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0072 (82)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0074 (84)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0075 (85)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0076 (86)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0077 (87)  rf=r size=4 type=d align=2 words (r57.0)
//.declare V0078 (88)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0079 (89)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0080 (90)  rf=r size=4 type=d align=2 words (r9.0)
//.declare V0081 (91)  rf=r size=4 type=ud alias=V0079+0 align=2 words (r6.0)
//.declare V0082 (92)  rf=r size=4 type=ud alias=V0044+0 align=2 words (r3.1)
//.declare V0083 (93)  rf=r size=4 type=ud alias=V0077+0 align=2 words (r57.0)
//.declare V0084 (94)  rf=r size=4 type=d align=32 words (r7.0)
//.declare V0086 (96)  rf=r size=4 type=d align=32 words (r8.0)
//.declare P01 (97)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0087 (98)  rf=r size=128 type=ud alias=V0075+0 align=32 words (r55.0)
//.declare P02 (99)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P03 (100)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0088 (101)  rf=r size=4 type=ud alias=V0080+0 align=2 words (r9.0)
//.declare V0089 (102)  rf=r size=8 type=uq alias=V0069+0 align=4 words (r5.6)
//.declare V0090 (103)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0091 (104)  rf=r size=4 type=d align=32 words (r7.0)
//.declare P04 (105)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0092 (106)  rf=r size=8 type=uq alias=V0066+0 align=4 words (r5.3)
//.declare V0093 (107)  rf=r size=8 type=uq align=32 words (r58.0)
//.declare V0095 (109)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0096 (110)  rf=r size=256 type=ud alias=V0095+0 align=32 words (r6.0)
//.declare V0097 (111)  rf=r size=8 type=ud alias=V0093+0 align=32 words (r58.0)
//.declare V0098 (112)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0099 (113)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P05 (115)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0101 (116)  rf=r size=8 type=uq alias=V0068+0 align=4 words (r5.5)
//.declare V0102 (117)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0103 (118)  rf=r size=4 type=d align=32 words (r7.0)
//.declare V0104 (119)  rf=r size=4 type=d align=2 words (r8.0)
//.declare P06 (120)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P07 (121)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0105 (122)  rf=r size=64 type=w align=32 words (r59.0)
//.declare P08 (123)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0106 (124)  rf=r size=128 type=d align=32 words (r61.0)
//.declare V0107 (125)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0108 (126)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0109 (127)  rf=r size=128 type=ud alias=V0108+0 align=32 words (r6.0)
//.declare V0110 (128)  rf=r size=4 type=d align=2 words (r8.0)
//.declare V0111 (129)  rf=r size=4 type=d align=2 words (r9.0)
//.declare V0112 (130)  rf=r size=4 type=f align=2 words (r10.0)
//.declare V0113 (131)  rf=r size=4 type=ud alias=V0111+0 align=2 words (r9.0)
//.declare V0114 (132)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0115 (133)  rf=r size=4 type=ud alias=V0114+0 align=2 words (r11.0)
//.declare V0116 (134)  rf=r size=4 type=d align=2 words (r12.0)
//.declare V0117 (135)  rf=r size=128 type=f align=32 words (r13.0)
//.declare V0118 (136)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0119 (137)  rf=r size=4 type=f align=2 words (r18.0)
//.declare V0120 (138)  rf=r size=128 type=f align=32 words (r19.0)
//.declare V0121 (139)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0122 (140)  rf=r size=128 type=ud alias=V0121+0 align=32 words (r21.0)
//.declare V0123 (141)  rf=r size=128 type=d align=32 words (r23.0)
//.declare V0124 (142)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0125 (143)  rf=r size=128 type=ud alias=V0124+0 align=32 words (r25.0)
//.declare V0126 (144)  rf=r size=4 type=f align=2 words (r28.0)
//.declare V0127 (145)  rf=r size=4 type=ud alias=V0116+0 align=2 words (r12.0)
//.declare V0128 (146)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0129 (147)  rf=r size=128 type=ud alias=V0123+0 align=32 words (r23.0)
//.declare V0130 (148)  rf=r size=128 type=f align=32 words (r33.0)
//.declare V0136 (154)  rf=r size=128 type=f align=32 words (r35.0)
//.declare V0137 (155)  rf=r size=128 type=d align=32 words (r37.0)
//.declare V0138 (156)  rf=r size=128 type=ud alias=V0137+0 align=32 words (r37.0)
//.declare V0139 (157)  rf=r size=128 type=d align=32 words (r39.0)
//.declare V0140 (158)  rf=r size=128 type=d align=32 words (r43.0)
//.declare V0141 (159)  rf=r size=128 type=d align=32 words (r45.0)
//.declare V0142 (160)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0143 (161)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0144 (162)  rf=r size=128 type=ud alias=V0142+0 align=32 words (r47.0)
//.declare V0145 (163)  rf=r size=128 type=ud alias=V0143+0 align=32 words (r50.0)
//.declare  (164)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0146 (165)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0147 (166)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0148 (167)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0149 (168)  rf=r size=128 type=d align=32 words (r67.0)
//.declare P09 (169)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0150 (170)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0151 (171)  rf=r size=4 type=d align=2 words (r8.0)
//.declare V0153 (173)  rf=r size=128 type=ud alias=V0106+0 align=32 words (r61.0)
//.declare V0154 (174)  rf=r size=4 type=ud alias=V0151+0 align=2 words (r8.0)
//.declare V0157 (177)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0158 (178)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0159 (179)  rf=r size=8 type=q alias=V0034+0 align=4 words (r2.3)
//.declare V0164 (184)  rf=r size=128 type=ud alias=V0149+0 align=32 words (r67.0)
//.declare V0166 (186)  rf=r size=256 type=q align=32 words (r35.0)
//.declare V0167 (187)  rf=r size=256 type=uq alias=V0166+0 align=32 words (r35.0)
//.declare V0168 (188)  rf=r size=128 type=f align=32 words (r69.0)
//.declare V0170 (190)  rf=r size=64 type=uw alias=V0105+0 align=32 words (r59.0)
//.declare V0171 (191)  rf=r size=128 type=d align=32 words (r71.0)
//.declare P10 (192)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0172 (193)  rf=r size=4 type=d align=2 words (r57.1)
//.declare V0174 (195)  rf=r size=4 type=ud alias=V0172+0 align=2 words (r57.1)
//.declare V0175 (196)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0176 (197)  rf=r size=256 type=q align=32 words (r6.0)
//.declare V0177 (198)  rf=r size=256 type=uq alias=V0176+0 align=32 words (r6.0)
//.declare V0178 (199)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0179 (200)  rf=r size=4 type=d align=2 words (r12.0)
//.declare V0180 (201)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0181 (202)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r13.0)
//.declare  (204)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare P11 (205)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P12 (206)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0183 (207)  rf=r size=4 type=d align=2 words (r57.2)
//.declare V0184 (208)  rf=r size=4 type=d align=2 words (r57.3)
//.declare V0185 (209)  rf=r size=4 type=d align=2 words (r57.4)
//.declare V0186 (210)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0187 (211)  rf=r size=128 type=d align=32 words (r73.0)
//.declare V0188 (212)  rf=r size=128 type=ud alias=V0187+0 align=32 words (r73.0)
//.declare V0189 (213)  rf=r size=128 type=f align=32 words (r75.0)
//.declare  (215)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0191 (216)  rf=r size=4 type=d align=2 words (r57.5)
//.declare P13 (217)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0192 (218)  rf=r size=128 type=f align=32 words (r77.0)
//.declare V0193 (219)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0194 (220)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0195 (221)  rf=r size=128 type=ud alias=V0194+0 align=32 words (r6.0)
//.declare  (223)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0197 (224)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (226)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare P14 (227)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P15 (228)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0199 (229)  rf=r size=128 type=ud alias=V0171+0 align=32 words (r71.0)
//.declare V0200 (230)  rf=r size=128 type=f align=32 words (r79.0)
//.declare  (232)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0202 (233)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (234)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (235)  rf=r size=128 type=f align=32 words (r81.0)
//.declare  (236)  rf=r size=128 type=f align=32 words (r83.0)
//.declare  (237)  rf=r size=128 type=f align=32 words (r85.0)
//.declare  (238)  rf=r size=128 type=f align=32 words (r87.0)
//.declare  (239)  rf=r size=128 type=f align=32 words (r89.0)
//.declare  (240)  rf=r size=128 type=f align=32 words (r91.0)
//.declare  (241)  rf=r size=128 type=f align=32 words (r93.0)
//.declare  (242)  rf=r size=64 type=f align=32 words (r60.0)
//.declare  (243)  rf=r size=64 type=f align=32 words (r63.0)
//.declare V0203 (246)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0208 (251)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare V0209 (252)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0210 (253)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0211 (254)  rf=r size=128 type=ud alias=V0210+0 align=32 words (r8.0)
//.declare V0212 (255)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0213 (256)  rf=r size=128 type=ud alias=V0212+0 align=32 words (r10.0)
//.declare V0214 (257)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0215 (258)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0220 (263)  rf=r size=256 type=uq align=32 words (r24.0)
//.declare V0222 (265)  rf=r size=128 type=ud align=32 words (r28.0)
//.declare V0223 (266)  rf=r size=128 type=w alias=V0222+0 align=32 words (r28.0)
//.declare V0224 (267)  rf=r size=64 type=w align=32 words (r30.0)
//.declare V0225 (268)  rf=r size=64 type=w align=32 words (r31.0)
//.declare V0226 (269)  rf=r size=64 type=w align=32 words (r37.0)
//.declare V0227 (270)  rf=r size=64 type=w align=32 words (r34.0)
//.declare V0228 (271)  rf=r size=64 type=uw alias=V0224+0 align=32 words (r30.0)
//.declare V0229 (272)  rf=r size=64 type=uw alias=V0227+0 align=32 words (r34.0)
//.declare  (273)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0234 (278)  rf=r size=256 type=uq align=32 words (r46.0)
//.declare V0235 (279)  rf=r size=64 type=uw alias=V0226+0 align=32 words (r37.0)
//.declare V0236 (280)  rf=r size=128 type=ud align=32 words (r50.0)
//.declare P16 (281)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0238 (283)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0239 (284)  rf=r size=256 type=ud alias=V0238+0 align=32 words (r6.0)
//.declare V0240 (285)  rf=r size=128 type=d align=32 words (r10.0)
//.declare  (286)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (287)  rf=r size=4 type=f align=2 words (r17.0)
//.declare  (288)  rf=r size=64 type=ud align=32 words (r9.0)
//.declare  (289)  rf=r size=64 type=ud align=32 words (r12.0)
//.declare  (290)  rf=r size=128 type=ud align=32 words (r27.0)
//.declare  (291)  rf=r size=128 type=ud align=32 words (r31.0)
//.declare  (292)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (293)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (294)  rf=r size=64 type=uw align=32 words (r36.0)
//.declare  (295)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (296)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare  (297)  rf=r size=128 type=ud align=32 words (r38.0)
//.declare  (298)  rf=r size=128 type=ud align=32 words (r42.0)
//.declare  (299)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (300)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (301)  rf=r size=128 type=q align=32 words (r19.0)
//.declare  (302)  rf=r size=128 type=q align=32 words (r21.0)
//.declare  (303)  rf=r size=128 type=q align=32 words (r23.0)
//.declare  (304)  rf=r size=128 type=q align=32 words (r25.0)
//.declare  (305)  rf=r size=128 type=q align=32 words (r95.0)
//.declare  (306)  rf=r size=128 type=q align=32 words (r97.0)
//.declare  (309)  rf=r size=128 type=q align=32 words (r29.0)
//.declare  (310)  rf=r size=128 type=q align=32 words (r33.0)
//.declare  (313)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (314)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (319)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (320)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (325)  rf=r size=128 type=q align=32 words (r40.0)
//.declare  (326)  rf=r size=128 type=q align=32 words (r44.0)
//.declare  (329)  rf=r size=128 type=ud alias=+0 align=32 words (r10.0)
//.declare  (330)  rf=r size=128 type=ud alias=+0 align=32 words (r13.0)
//.declare  (331)  rf=r size=128 type=d alias=+0 align=32 words (r10.0)
//.declare  (332)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare r0 (333)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (334)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (335)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (336)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (337)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (338)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (339)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0034    | :uq      |    0x8 | r2+0x18  | inline+0x18      |
// | V0043    | :d       |    0x4 | r3       | cti+0x20         |
// | V0044    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0051    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0052    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0053    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0054    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0055    | :q       |    0x8 | r4       | cti+0x60         |
// | V0056    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0057    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0058    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0059    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0060    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0061    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0062    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0063    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0064    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0065    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0066    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0067    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0068    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0069    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B030}
// _main:
(W)     mov (16|M0)              r54.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r63.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r60.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               r57.0<1>:d    r3.4<0;1,0>:d     2560:w               {A@1,$1.dst}   //  ALU pipe: int; $6
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r54.2<0;1,0>:uw  {I@3}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r3.0<1>:d     r2.3<0;1,0>:d     r54.1<0;1,0>:d   {Compacted}        //  ALU pipe: int; $4
(W)     asr (1|M0)               r5.0<1>:d     r57.0<0;1,0>:d    31:w               {Compacted,@3,$2.dst} //  ALU pipe: int; $7
(W)     mul (1|M0)               acc0.0<1>:ud  r3.1<0;1,0>:ud    r57.0<0;1,0>:uw                     //  ALU pipe: int; $8
(W)     macl (1|M0)              r6.0<1>:ud    r3.1<0;1,0>:ud    r57.0<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $9
(W)     mul (1|M0)               acc0.0<1>:ud  r3.1<0;1,0>:ud    r57.0<0;1,0>:uw                     //  ALU pipe: int; $9
(W)     asr (1|M0)               r4.2<1>:d     r3.1<0;1,0>:d     31:w                                //  ALU pipe: int; $5
        add3 (32|M0)             r55.0<1>:d    r3.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {@6,$0.dst} //  ALU pipe: int; $4
(W)     mach (1|M0)              r7.0<1>:d     r3.1<0;1,0>:ud    r57.0<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r3.1<0;1,0>:ud    r5.0<0;1,0>:uw   {I@7}              //  ALU pipe: int; $10
(W)     macl (1|M0)              r8.0<1>:d     r3.1<0;1,0>:ud    r5.0<0;1,0>:d                       //  ALU pipe: int; $11
(W)     mul (1|M0)               acc0.0<1>:d   r57.0<0;1,0>:ud   r4.4<0;1,0>:uw   {I@5}              //  ALU pipe: int; $12
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r6.0<0;1,0>:ud    r55.0<1;1,0>:ud  {I@5}              //  ALU pipe: int; $15
(W)     add (1|M0)               r7.0<1>:d     r7.0<0;1,0>:d     r8.0<0;1,0>:d    {Compacted,I@3}    //  ALU pipe: int; $11
(W)     macl (1|M0)              r8.0<1>:d     r57.0<0;1,0>:ud   r4.2<0;1,0>:d                       //  ALU pipe: int; $14
(W)     add (1|M0)               r9.0<1>:d     r7.0<0;1,0>:d     r8.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $14
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r9.0<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $16
(~f0.0) cmp (32|M0)   (gt)f0.0   null<1>:ud    r9.0<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $18
(~f0.0) goto (32|M0)                         _0_036            _0_036                                //  ALU pipe: int; $20
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B030}
_0_037:
(W)     mov (1|M0)               r6.0<1>:uq    r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $22
(W)     load.ugm.d32x1t.a64 (1|M0)  r7:1        [r6:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $23
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r7.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $24
(f2.0)  goto (32|M0)                         _0_036            _0_036                                //  ALU pipe: int; $25
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B030}
_0_038:
(W)     mov (1|M0)               r58.0<1>:uq   r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $27
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $30
        mov (16|M0)              r6.0<2>:f     r58.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $28
        mov (16|M16)             r8.0<2>:f     r58.0<0;1,0>:f                                        //  ALU pipe: float; $28
        mov (16|M0)              r6.1<2>:f     r58.1<0;1,0>:f                                        //  ALU pipe: float; $29
        mov (16|M16)             r8.1<2>:ud    r58.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $29
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$4} // ex_desc:0x0; desc:0x8200599 // $31
        cmp (32|M0)   (eq)f1.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$4.dst}          //  ALU pipe: int; $33
(~f1.0) goto (32|M0)                         _0_036            _0_036                                //  ALU pipe: int; $34
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B028}
_0_039:
(W)     mov (1|M0)               r6.0<1>:uq    r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $36
(W)     add (1|M0)               r8.0<1>:d     r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $38
(W)     load.ugm.d32x1t.a64 (1|M0)  r7:1        [r6:1]             {I@2,$5} // ex_desc:0x0; desc:0x2108580 // $37
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r7.0<0;1,0>:d     r8.0<0;1,0>:d    {@1,$5.dst}        //  ALU pipe: int; $39
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:d     r7.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $40
(W&f1.0) jmpi                                _0_040                                                  //  ALU pipe: int; $42
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_041:
(W)     mov (8|M0)               r59.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $44
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $47
(W)     add (8|M0)               r59.8<1>:w    r59.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $45
(W)     add (16|M0)              r59.16<1>:w   r59.0<1;1,0>:w    16:w               {I@1}            //  ALU pipe: int; $46
(W&~f0.0) jmpi                               _0_042                                                  //  ALU pipe: int; $48
// B007: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_043:
        mov (32|M0)              r61.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $50
(W)     jmpi                                 _0_044                                                  // $51
// B008: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_042:
(W)     asr (1|M0)               r2.8<1>:d     r57.0<0;1,0>:d    31:w                                //  ALU pipe: int; $53
        shr (32|M0)              r6.0<1>:ud    r55.0<1;1,0>:ud   31:w                                //  ALU pipe: int; $54
(W)     add (1|M0)               r8.0<1>:d     r2.8<0;1,0>:d     r57.0<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $55
(W)     xor (1|M0)               r9.0<1>:d     r8.0<0;1,0>:d     r2.8<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $56
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $57
(W)     mov (1|M0)               r10.0<1>:f    r9.0<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $58
(W)     mov (1|M0)               r17.0<1>:f    0xB4C00000:f                               {Compacted} //  ALU pipe: float; $63
(W)     math.inv (1|M0)          r16.0<1>:f    r10.0<0;1,0>:f                   {F@2}                //  ALU pipe: math; $62
        mov (32|M0)              r13.0<1>:f    r55.0<1;1,0>:ud                                       //  ALU pipe: float; $61
(W)     mad (1|M0)               r18.0<1>:f    r16.0<0;0>:f      r17.0<0;0>:f      r16.0<0>:f       {Compacted,A@1} //  ALU pipe: float; $63
        mov (32|M0)              r21.0<1>:ud   r13.0<1;1,0>:f                   {F@2}                //  ALU pipe: int; $65
        mul (32|M0)              r19.0<1>:f    r13.0<1;1,0>:f    r18.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $64
(W)     mov (1|M0)               r11.0<1>:ud   r10.0<0;1,0>:f                                        //  ALU pipe: int; $59
        add (32|M0)              r23.0<1>:d    r55.0<1;1,0>:d    -r21.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $66
        mov (32|M0)              r25.0<1>:ud   r19.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $67
(W)     add (1|M0)               r12.0<1>:d    r9.0<0;1,0>:d     -r11.0<0;1,0>:d  {I@3}              //  ALU pipe: int; $60
        mov (32|M0)              r33.0<1>:f    r25.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $70
        mov (32|M0)              r29.0<1>:f    r23.0<1;1,0>:ud                                       //  ALU pipe: float; $69
(W)     mov (1|M0)               r28.0<1>:f    r12.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $68
        mad (32|M0)              acc0.0<1>:f   r13.0<1;0>:f      r33.0<1;0>:f      -r10.0<0>:f      {F@3} //  ALU pipe: float; $72
        mad (32|M0)              acc2.0<1>:f   r29.0<1;0>:f      r33.0<1;0>:f      -r28.0<0>:f      {F@2} //  ALU pipe: float; $74
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $75
        mul (32|M0)              r35.0<1>:f    r18.0<0;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $76
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $77
        mov (32|M0)              r37.0<1>:ud   r35.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $78
        add (32|M0)              r39.0<1>:d    r37.0<1;1,0>:d    r25.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $79
(W)     mul (16|M0)              acc0.0<1>:d   r39.0<1;1,0>:d    r9.0<0;1,0>:uw   {I@1}              //  ALU pipe: int; $81
        macl (16|M0)             r45.0<1>:d    r39.0<1;1,0>:d    r9.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $81
(W)     mul (16|M16)             acc0.0<1>:d   r40.0<1;1,0>:d    r9.0<0;1,0>:uw                      //  ALU pipe: int; $81
        macl (16|M16)            r46.0<1>:d    r40.0<1;1,0>:d    r9.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $82
        add (32|M0)              r47.0<1>:d    r55.0<1;1,0>:d    -r45.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $82
        cmp (32|M0)   (ge)f3.0   r50.0<1>:ud   r47.0<1;1,0>:ud   r9.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $83
        xor (32|M0)              r43.0<1>:d    r6.0<1;1,0>:d     r2.8<0;1,0>:d    {Compacted}        //  ALU pipe: int; $80
        add3 (32|M0)             r52.0<1>:d    r39.0<1;0>:d      r43.0<1;0>:d      -r50.0<1>:d      {Compacted,I@1} //  ALU pipe: int; $84
        xor (32|M0)              r61.0<1>:d    r52.0<1;1,0>:d    r2.8<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $85
// B009: [inDivergent],  Preds:{B008, B007},  Succs:{B010, B027}
_0_044:
(W)     mul (16|M0)              acc0.0<1>:d   r61.0<1;1,0>:d    r3.8<0;1,0>:uw   {I@1}              //  ALU pipe: int; $87
        macl (16|M0)             r64.0<1>:d    r61.0<1;1,0>:d    r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $87
(W)     mul (16|M16)             acc0.0<1>:d   r62.0<1;1,0>:d    r3.8<0;1,0>:uw                      //  ALU pipe: int; $87
        macl (16|M16)            r65.0<1>:d    r62.0<1;1,0>:d    r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $88
(W)     mul (16|M0)              acc0.0<1>:d   r61.0<1;1,0>:d    r57.0<0;1,0>:uw                     //  ALU pipe: int; $88
        macl (16|M0)             r6.0<1>:d     r61.0<1;1,0>:d    r57.0<0;1,0>:d   {Compacted}        //  ALU pipe: int; $88
(W)     mul (16|M16)             acc0.0<1>:d   r62.0<1;1,0>:d    r57.0<0;1,0>:uw                     //  ALU pipe: int; $88
        macl (16|M16)            r7.0<1>:d     r62.0<1;1,0>:d    r57.0<0;1,0>:d   {Compacted}        //  ALU pipe: int; $89
        add (32|M0)              r67.0<1>:d    r55.0<1;1,0>:d    -r6.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $89
        cmp (32|M0)   (lt)f3.0   null<1>:d     r67.0<1;1,0>:d    r3.4<0;1,0>:d    {I@1}              //  ALU pipe: int; $90 R{} IR{}{O:1,O:1,},  R{r3,} IR{} {BC=1}
(~f3.0) goto (32|M0)                         _0_045            _0_045                                //  ALU pipe: int; $91
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B013}
_0_046:
(W)     add (1|M0)               r8.0<1>:d     r3.4<0;1,0>:d     1056:w               {Compacted}    //  ALU pipe: int; $94
        asr (32|M0)              r6.0<1>:d     r61.0<1;1,0>:d    31:w               {Compacted}      //  ALU pipe: int; $93
(W)     mul (16|M0)              acc0.0<1>:ud  r61.0<1;1,0>:ud   r8.0<0;1,0>:uw   {I@2}              //  ALU pipe: int; $95
        macl (16|M0)             r9.0<1>:ud    r61.0<1;1,0>:ud   r8.0<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $96
(W)     mul (16|M16)             acc0.0<1>:ud  r62.0<1;1,0>:ud   r8.0<0;1,0>:uw                      //  ALU pipe: int; $96
        macl (16|M16)            r12.0<1>:ud   r62.0<1;1,0>:ud   r8.0<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $97
(W)     mul (16|M0)              acc0.0<1>:ud  r61.0<1;1,0>:ud   r8.0<0;1,0>:uw                      //  ALU pipe: int; $97
        mach (16|M0)             r15.0<1>:d    r61.0<1;1,0>:ud   r8.0<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r62.0<1;1,0>:ud   r8.0<0;1,0>:uw                      //  ALU pipe: int; $97
        mach (16|M16)            r16.0<1>:d    r62.0<1;1,0>:ud   r8.0<0;1,0>:ud                      //  ALU pipe: int; $99
(W)     mul (16|M0)              acc0.0<1>:d   r8.0<0;1,0>:ud    r6.0<2;1,0>:uw   {I@7}              //  ALU pipe: int; $100
        macl (16|M0)             r17.0<1>:d    r8.0<0;1,0>:ud    r6.0<1;1,0>:d                       //  ALU pipe: int; $100
(W)     mul (16|M16)             acc0.0<1>:d   r8.0<0;1,0>:ud    r7.0<2;1,0>:uw                      //  ALU pipe: int; $100
        macl (16|M16)            r18.0<1>:d    r8.0<0;1,0>:ud    r7.0<1;1,0>:d                       //  ALU pipe: int; $101
        mov (16|M0)              r10.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $96
        mov (16|M16)             r13.0<2>:ud   r12.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $97
        add (16|M0)              r10.1<2>:d    r15.0<1;1,0>:d    r17.0<1;1,0>:d   {I@5}              //  ALU pipe: int; $101
        add (16|M16)             r13.1<2>:d    r16.0<1;1,0>:d    r18.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $102
        shl (16|M0)              r19.0<1>:q    r10.0<1;1,0>:q    2:w               {Compacted,I@2}   //  ALU pipe: int; $103
        shl (16|M16)             r21.0<1>:q    r13.0<1;1,0>:q    2:w               {Compacted,I@2}   //  ALU pipe: int; $103
        mov (16|M0)              r27.0<2>:ud   r67.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $107
        mov (16|M16)             r31.0<2>:ud   r68.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $107
        add (16|M0)              r23.0<1>:q    r19.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $104
        add (16|M16)             r25.0<1>:q    r21.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $104
        shl (16|M0)              r29.0<1>:q    r27.0<2;1,0>:ud   2:w               {I@4}             //  ALU pipe: int; $107
        shl (16|M16)             r33.0<1>:q    r31.0<2;1,0>:ud   2:w               {I@4}             //  ALU pipe: int; $107
        add (16|M0)              r95.0<1>:q    r23.0<1;1,0>:q    4224:w               {I@4}          //  ALU pipe: int; $105
        add (16|M16)             r97.0<1>:q    r25.0<1;1,0>:q    4224:w               {I@4}          //  ALU pipe: int; $105
        add (16|M0)              r35.0<1>:q    r95.0<1;1,0>:q    r29.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $108
        add (16|M16)             r37.0<1>:q    r97.0<1;1,0>:q    r33.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $108 R{} IR{}{O:0,O:0,},  R{} IR{}{E:1,E:1,},  {BC=2}
        load.ugm.d32.a64 (32|M0)  r69:2         [r35:4]            {I@1,$6} // ex_desc:0x0; desc:0x8200580 // $109
(W)     cmp (32|M0)   (gt)f2.0   null<1>:d     r3.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $112
        shl (32|M0)              r71.0<1>:d    r59.0<1;1,0>:uw   2:w                                 //  ALU pipe: int; $111
(W&~f2.0) jmpi                               _0_047                                                  //  ALU pipe: int; $113
// B011: [inDivergent],  Preds:{B010},  Succs:{B012}
_0_048:
(W)     mov (1|M0)               r57.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $115
// B012: [inDivergent],  Preds:{B012, B011},  Succs:{B013, B012}
_0_049:
(W)     shl (1|M0)               r2.4<1>:q     r57.1<0;1,0>:ud   2:w               {I@1}             //  ALU pipe: int; $118
(W)     mul (1|M0)               r12.0<1>:d    r57.1<0;1,0>:d    128:w               {Compacted}     //  ALU pipe: int; $121
        add (16|M0)              r6.0<1>:q     r95.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $119
        add (16|M16)             r8.0<1>:q     r97.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $119
        load.ugm.d32.a64 (32|M0)  r10:2         [r6:4]             {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $120
        sync.nop                             null                             {Compacted,F@1}        // $123
(W)     shr (1|M0)               a0.0<1>:ud    r54.5<0;1,0>:ud   0x4:uw              {$7.src}        //  ALU pipe: int; $123
(W)     add (1|M0)               r57.1<1>:d    r57.1<0;1,0>:d    1:w                                 //  ALU pipe: int; $125
        add (32|M0)              r13.0<1>:d    r71.0<1;1,0>:d    r12.0<0;1,0>:d   {Compacted}        //  ALU pipe: int; $122
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r57.1<0;1,0>:d    r3.4<0;1,0>:d    {I@2}              //  ALU pipe: int; $126
        sync.nop                             null                             {Compacted,$8.dst}     // $124
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r13:2] r10:2     {I@2,$7} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $124
(W&f2.0) jmpi                                _0_049                                                  //  ALU pipe: int; $127
// B013: [inDivergent],  Preds:{B012, B010},  Succs:{B014, B022}
_0_047:
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r3.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $129
(W&~f1.0) jmpi                               _0_050                                                  //  ALU pipe: int; $130
// B014: [inDivergent],  Preds:{B013},  Succs:{B015}
_0_051:
(W)     mov (1|M0)               r57.2<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $132
// B015: [inDivergent],  Preds:{B021, B014},  Succs:{B016}
_0_052:
(W)     shl (1|M0)               r57.3<1>:d    r57.2<0;1,0>:d    1:w               {I@1}             //  ALU pipe: int; $134
(W)     mov (1|M0)               r57.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $135
// B016: [inDivergent],  Preds:{B019, B015},  Succs:{B017, B018}
_0_053:
(W)     mul (1|M0)               r2.8<1>:d     r57.4<0;1,0>:d    128:w               {I@1}           //  ALU pipe: int; $137
        sync.nop                             null                             {Compacted,$9.src}     // $139
(W)     shr (1|M0)               a0.0<1>:ud    r54.5<0;1,0>:ud   0x4:uw              {$7.src}        //  ALU pipe: int; $139
        add (32|M0)              r73.0<1>:d    r71.0<1;1,0>:d    r2.8<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $138
        load.ugm.d32.a32.ca.ca (32|M0)  r75:2   ss[a0.0][r73:2]    {I@1,$10} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $140
(W)     add (1|M0)               r57.5<1>:d    r57.4<0;1,0>:d    r57.2<0;1,0>:d                      //  ALU pipe: int; $141
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r57.5<0;1,0>:d    r3.4<0;1,0>:d    {I@1}              //  ALU pipe: int; $142
(W&f0.0) jmpi                                _0_054                                                  //  ALU pipe: int; $143
// B017: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_055:
        mov (32|M0)              r77.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $145
(W)     jmpi                                 _0_056                                                  // $146
// B018: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_054:
(W)     mul (1|M0)               r2.8<1>:d     r57.5<0;1,0>:d    128:w                               //  ALU pipe: int; $148
(W)     shr (1|M0)               a0.0<1>:ud    r54.5<0;1,0>:ud   0x4:uw              {$10.src}       //  ALU pipe: int; $150
        add (32|M0)              r6.0<1>:d     r71.0<1;1,0>:d    r2.8<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $149
        load.ugm.d32.a32.ca.ca (32|M0)  r77:2   ss[a0.0][r6:2]     {I@1,$11} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $151
// B019: [inDivergent],  Preds:{B018, B017},  Succs:{B020, B016}
_0_056:
        sync.nop                             null                             {Compacted,$11.src}    // $154
(W)     shr (1|M0)               a0.0<1>:ud    r54.5<0;1,0>:ud   0x4:uw              {$10.src}       //  ALU pipe: int; $154
        sync.nop                             null                             {Compacted,$11.dst}    // $153
        add (32|M0)              r6.0<1>:f     r75.0<1;1,0>:f    r77.0<1;1,0>:f   {Compacted,$10.dst} //  ALU pipe: float; $153
(W)     add (1|M0)               r57.4<1>:d    r57.4<0;1,0>:d    r57.3<0;1,0>:d                      //  ALU pipe: int; $156
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r73:2] r6:2      {F@1,$9} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $155
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r57.4<0;1,0>:d    r3.4<0;1,0>:d    {I@1}              //  ALU pipe: int; $157
(W&f3.0) jmpi                                _0_053                                                  //  ALU pipe: int; $158
// B020: [inDivergent],  Preds:{B019},  Succs:{B021, B022}
_0_057:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r57.3<0;1,0>:d    r3.4<0;1,0>:d                       //  ALU pipe: int; $160
(W&~f1.0) jmpi                               _0_050                                                  //  ALU pipe: int; $161
// B021: [inDivergent],  Preds:{B020},  Succs:{B015}
_0_058:
(W)     mov (1|M0)               r57.2<1>:d    r57.3<0;1,0>:d                                        //  ALU pipe: int; $163
(W)     jmpi                                 _0_052                                                  // $164
// B022: [inDivergent],  Preds:{B020, B013},  Succs:{B023, B024}
_0_050:
        sync.nop                             null                             {Compacted,$9.src}     // $166
(W)     shr (1|M0)               a0.0<1>:ud    r54.5<0;1,0>:ud   0x4:uw              {$7.src}        //  ALU pipe: int; $166
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $168
        load.ugm.d32.a32.ca.ca (32|M0)  r79:2   ss[a0.0][r71:2]    {$12} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $167
        sync.nop                             null                             {Compacted,I@1}        // $168
        sync.nop                             null                             {Compacted,$12.dst}    // $168
        math.invm (16|M0) (eo)f3.0  r87.mme0:f  r69.nomme<1;1,0>:f  r79.nomme<1;1,0>:f {$6.dst}      //  ALU pipe: math; $168
(f3.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $168
// B023: [inDivergent],  Preds:{B022},  Succs:{B024}
_L_k0_2_:
        madm (16|M0)             r89.mme1:f    r60.nomme:f       r69.nomme:f       r87.mme0:f       {M@1} //  ALU pipe: float; $168
        madm (16|M0)             r91.mme2:f    r63.nomme:f       -r79.nomme:f      r87.mme0:f        //  ALU pipe: float; $168 R{r87,} IR{}{O:7,O:7,},  {BC=1}
        madm (16|M0)             r81.mme3:f    r87.mme0:f        r91.mme2:f        r87.mme0:f       {F@1} //  ALU pipe: float; $168
        madm (16|M0)             r93.mme4:f    r69.nomme:f       -r79.nomme:f      r89.mme1:f        //  ALU pipe: float; $168 R{} IR{}{O:2,O:7,O:4,},  {BC=1}
        madm (16|M0)             r89.mme5:f    r89.mme1:f        r93.mme4:f        r81.mme3:f       {F@1} //  ALU pipe: float; $168 R{} IR{}{O:4,O:6,O:0,},  {BC=1}
        madm (16|M0)             r85.mme6:f    r69.nomme:f       -r79.nomme:f      r89.mme5:f       {F@1} //  ALU pipe: float; $168 R{} IR{}{O:2,O:7,O:4,},  {BC=1}
        madm (16|M0)             r87.nomme:f   r89.mme5:f        r85.mme6:f        r81.mme3:f       {F@1} //  ALU pipe: float; $168 R{} IR{}{O:4,O:2,O:0,},  {BC=1}
// B024: [inDivergent],  Preds:{B023, B022},  Succs:{B025, B026}
_L_k0_0_macro:
        join (32|M0)                         _0_045                                                  // 
L2720:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $168
        math.invm (16|M16) (eo)f3.0  r88.mme0:f  r70.nomme<1;1,0>:f  r80.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $168
(f3.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $168
// B025: [inDivergent],  Preds:{B024},  Succs:{B026}
_L_k0_3_:
        madm (16|M16)            r90.mme1:f    r60.nomme:f       r70.nomme:f       r88.mme0:f       {M@1} //  ALU pipe: float; $168 R{} IR{}{E:6,E:3,E:4,},  {BC=1}
        madm (16|M16)            r92.mme2:f    r63.nomme:f       -r80.nomme:f      r88.mme0:f        //  ALU pipe: float; $168
        madm (16|M16)            r82.mme3:f    r88.mme0:f        r92.mme2:f        r88.mme0:f       {F@1} //  ALU pipe: float; $168
        madm (16|M16)            r94.mme4:f    r70.nomme:f       -r80.nomme:f      r90.mme1:f        //  ALU pipe: float; $168 R{} IR{}{E:3,E:0,E:5,},  {BC=1}
        madm (16|M16)            r90.mme5:f    r90.mme1:f        r94.mme4:f        r82.mme3:f       {F@1} //  ALU pipe: float; $168 R{} IR{}{E:5,E:7,E:1,},  {BC=1}
        madm (16|M16)            r86.mme6:f    r70.nomme:f       -r80.nomme:f      r90.mme5:f       {F@1} //  ALU pipe: float; $168 R{} IR{}{E:3,E:0,E:5,},  {BC=1}
        madm (16|M16)            r88.nomme:f   r90.mme5:f        r86.mme6:f        r82.mme3:f       {F@1} //  ALU pipe: float; $168 R{} IR{}{E:5,E:3,E:1,},  {BC=1}
// B026: [inDivergent],  Preds:{B025, B024},  Succs:{B027}
_L_k0_1_macro:
        join (32|M0)                         _0_045                                                  // 
L2896:
        add (32|M0)              r8.0<1>:d     r64.0<1;1,0>:d    r67.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $169
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $171
        mov (16|M16)             r14.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $171
        shl (16|M0)              r12.0<1>:q    r10.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $171
        shl (16|M16)             r16.0<1>:q    r14.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $171
        mov (32|M0)              r6.0<1>:ud    r87.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $168
        add (16|M0)              r18.0<1>:q    r12.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $172
        add (16|M16)             r20.0<1>:q    r16.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $172
        store.ugm.d32.a64 (32|M0)  [r18:4]      r6:2               {I@1,$13} // ex_desc:0x0; desc:0x8000584 // $174
// B027: [inDivergent],  Preds:{B026, B009},  Succs:{B030}
_0_045:
        join (32|M0)                         _0_036                                                  // 
L3008:
(W)     mul (16|M0)              acc0.0<1>:ud  r67.0<1;1,0>:ud   0xCCCD:uw                           //  ALU pipe: int; $177
        mach (16|M0)             r8.0<1>:ud    r67.0<1;1,0>:ud   0xCCCCCCCD:ud                       //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r68.0<1;1,0>:ud   0xCCCD:uw                           //  ALU pipe: int; $177
        mach (16|M16)            r9.0<1>:ud    r68.0<1;1,0>:ud   0xCCCCCCCD:ud                       //  ALU pipe: int; $178
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    11:w               {I@1}            //  ALU pipe: int; $178
        mad (32|M0)              r12.0<1>:d    r67.0<1;0>:d      r10.0<1;0>:d      -2560:w               {I@1} //  ALU pipe: int; $179
        mad (32|M0)              r14.0<1>:d    r12.0<1;0>:d      r61.0<1;0>:d      2560:w               {I@1} //  ALU pipe: int; $180
        mov (16|M0)              r16.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $182
        mov (16|M16)             r20.0<2>:ud   r15.0<1;1,0>:ud                  {Compacted,$13.src}  //  ALU pipe: int; $182
        shl (16|M0)              r18.0<1>:q    r16.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $182
        shl (16|M16)             r22.0<1>:q    r20.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $182
        add (16|M0)              r24.0<1>:q    r18.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $183
        add (16|M16)             r26.0<1>:q    r22.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $183
        load.ugm.d16u32.a64 (32|M0)  r28:2      [r24:4]            {I@1,$14} // ex_desc:0x0; desc:0x8200B80 // $185
        mad (32|M0)              r6.0<1>:d     r67.0<1;0>:d      r64.0<1;0>:d      2560:w               //  ALU pipe: int; $176
        mov (16|M0)              r38.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $192
        mov (16|M16)             r42.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $192
        shl (16|M0)              r40.0<1>:q    r38.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $192
        shl (16|M16)             r44.0<1>:q    r42.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $192
        add (16|M0)              r46.0<1>:q    r40.0<1;1,0>:q    r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $193
        add (16|M16)             r48.0<1>:q    r44.0<1;1,0>:q    r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $193
        and (32|M0)              r30.0<1>:w    r28.0<2;1,0>:w    32767:w               {$14.dst}     //  ALU pipe: int; $187
        cmp (32|M0)   (gt)f2.0   r34.0<1>:uw   r30.0<1;1,0>:uw   0x7F80:uw              {I@1}        //  ALU pipe: int; $189
        or (32|M0)               r31.0<1>:w    r28.0<2;1,0>:w    64:w                                //  ALU pipe: int; $188
        mov (32|M0)              r36.0<1>:uw   r28.0<2;1,0>:uw                                       //  ALU pipe: int; $190
        bfn.(s0&s1|~s0&s2) (32|M0)   r37.0<1>:uw  r34.0<1;0>:uw  r31.0<1;0>:uw     r36.0<1>:uw      {I@1} //  ALU pipe: int; $190
        mov (32|M0)              r50.0<1>:ud   r37.0<1;1,0>:uw                  {I@1}                //  ALU pipe: int; $195
        store.ugm.d16u32.a64 (32|M0)  [r46:4]   r50:2              {I@1,$15} // ex_desc:0x0; desc:0x8000B84 // $196
        goto (32|M0)                         _0_036            _0_036                                // $197
// B028: [inDivergent],  Preds:{B005},  Succs:{B029, B030}
_0_040:
        cmp (32|M0)   (eq)f0.0   null<1>:d     r55.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $199
(~f0.0) goto (32|M0)                         _0_036            _0_036                                //  ALU pipe: int; $200
// B029: [inDivergent],  Preds:{B028},  Succs:{B030}
_0_059:
        mov (16|M0)              r6.0<2>:f     r58.0<0;1,0>:f                                        //  ALU pipe: float; $202
        mov (16|M16)             r8.0<2>:f     r58.0<0;1,0>:f                                        //  ALU pipe: float; $202
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $204
        mov (16|M0)              r6.1<2>:f     r58.1<0;1,0>:f                                        //  ALU pipe: float; $203
        mov (16|M16)             r8.1<2>:ud    r58.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $203
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$0} // ex_desc:0x0; desc:0x800058B // $205
// B030: Preds:{B029, B028, B027, B004, B003, B002},  Succs:{}
_0_036:
        join (32|M0)                         L3544                                                   // 
L3544:
(W)     mov (16|M0)              r127.0<1>:f   r54.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $207
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$1} // wr:1+0, rd:0; end of thread // $207
L3568:
(W)     mov (16|M0)              null<1>:ud    0x166EBD0A:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x7334B4EC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x6:ud                                                // 


//.BankConflicts: 13
//.ByteRMWs: 0
//


//.numALUInst: 227
//.accSubDef: 3
//.accSubUse: 3
//.accSubCandidateDef: 3
//.accSubCandidateUse: 3
//
//
//.singlePipeAtOneDistNum: 59
//.allAtOneDistNum: 10
//.syncInstCount: 8
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 12
//.AfterReadTokenDepCount: 10
