//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE8ELj6144ELj1ELj1ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 20 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 20 -GRFBumpUpNumber 2 "
//.instCount 353
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r53.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r53.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r53.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.1)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.13)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r54.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.2)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r55.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=16 words (r53.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r1.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0067 (77)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r1.8)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r54.1)
//.declare V0069 (79)  rf=r size=8 type=d align=2 words (r54.4)
//.declare V0070 (80)  rf=r size=8 type=d alias=V0068+0 align=4 words (r54.2)
//.declare P01 (81)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0071 (82)  rf=r size=4 type=d align=2 words (r54.6)
//.declare V0072 (83)  rf=r size=4 type=d align=4 words (r1.2)
//.declare V0073 (84)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0074 (85)  rf=r size=4 type=ud alias=V0050+0 align=2 words (r2.12)
//.declare V0075 (86)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0076 (87)  rf=r size=4 type=ud alias=V0075+0 align=2 words (r3.0)
//.declare V0077 (88)  rf=r size=4 type=d alias=+0 align=2 words (r4.0)
//.declare V0078 (89)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0079 (90)  rf=r size=4 type=ud alias=V0072+0 align=2 words (r1.2)
//.declare V0080 (91)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0081 (92)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0082 (93)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0083 (94)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0084 (95)  rf=r size=4 type=ud alias=V0083+0 align=2 words (r10.0)
//.declare V0085 (96)  rf=r size=4 type=d alias=+4 align=2 words (r4.1)
//.declare V0086 (97)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0087 (98)  rf=r size=4 type=ud alias=V0086+0 align=2 words (r11.0)
//.declare V0088 (99)  rf=r size=4 type=f alias=+0 align=2 words (r12.0)
//.declare V0089 (100)  rf=r size=4 type=ud alias=V0077+0 align=2 words (r4.0)
//.declare V0090 (101)  rf=r size=4 type=f alias=+4 align=2 words (r12.1)
//.declare V0091 (102)  rf=r size=4 type=ud alias=V0085+0 align=2 words (r4.1)
//.declare V0092 (103)  rf=r size=4 type=f align=2 words (r13.0)
//.declare V0094 (105)  rf=r size=4 type=f align=2 words (r14.0)
//.declare V0096 (107)  rf=r size=4 type=f align=2 words (r15.0)
//.declare V0097 (108)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0098 (109)  rf=r size=4 type=f align=2 words (r17.0)
//.declare V0099 (110)  rf=r size=4 type=d align=2 words (r18.0)
//.declare V0100 (111)  rf=r size=4 type=ud alias=V0099+0 align=2 words (r18.0)
//.declare V0101 (112)  rf=r size=4 type=d align=2 words (r19.0)
//.declare V0102 (113)  rf=r size=4 type=d align=32 words (r20.0)
//.declare V0103 (114)  rf=r size=4 type=d align=2 words (r21.0)
//.declare V0104 (115)  rf=r size=4 type=d align=2 words (r22.0)
//.declare V0105 (116)  rf=r size=4 type=ud alias=V0103+0 align=2 words (r21.0)
//.declare V0106 (117)  rf=r size=4 type=ud alias=V0104+0 align=2 words (r22.0)
//.declare  (118)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0107 (119)  rf=r size=4 type=d align=32 words (r56.0)
//.declare V0108 (120)  rf=r size=4 type=d align=2 words (r54.7)
//.declare V0109 (121)  rf=r size=4 type=ud alias=V0107+0 align=2 words (r56.0)
//.declare V0110 (122)  rf=r size=4 type=ud alias=V0071+0 align=2 words (r54.6)
//.declare V0111 (123)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0114 (126)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0116 (128)  rf=r size=4 type=ud alias=V0114+0 align=2 words (r3.0)
//.declare V0117 (129)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r2.13)
//.declare V0118 (130)  rf=r size=4 type=d align=32 words (r4.0)
//.declare P02 (133)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0121 (134)  rf=r size=8 type=ud alias=V0069+0 align=2 words (r54.4)
//.declare P03 (135)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P04 (136)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0123 (138)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0124 (139)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r55.0)
//.declare P05 (140)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P06 (141)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P07 (142)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0125 (143)  rf=r size=4 type=d align=2 words (r54.8)
//.declare V0126 (144)  rf=r size=2 type=w align=1 words (r54.18)
//.declare V0127 (145)  rf=r size=128 type=f align=32 words (r59.0)
//.declare P08 (146)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P09 (147)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0128 (148)  rf=r size=4 type=d alias=+0 align=2 words (r56.8)
//.declare V0129 (149)  rf=r size=4 type=d alias=+4 align=2 words (r56.9)
//.declare V0130 (150)  rf=r size=4 type=d align=2 words (r54.10)
//.declare V0131 (151)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0132 (152)  rf=r size=8 type=ud alias=V0131+0 align=4 words (r1.2)
//.declare V0133 (153)  rf=r size=8 type=d alias=V0131+0 align=4 words (r1.2)
//.declare V0134 (154)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0138 (158)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0139 (159)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P10 (160)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0140 (161)  rf=r size=4 type=ud alias=V0129+0 align=2 words (r56.9)
//.declare P11 (162)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0141 (163)  rf=r size=4 type=ud alias=V0128+0 align=2 words (r56.8)
//.declare V0142 (164)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r2.14)
//.declare V0144 (166)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0145 (167)  rf=r size=8 type=d alias=V0144+0 align=4 words (r1.2)
//.declare V0146 (168)  rf=r size=8 type=q align=4 words (r54.6)
//.declare V0148 (170)  rf=r size=4 type=d align=2 words (r2.0)
//.declare P12 (171)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0149 (172)  rf=r size=4 type=ud alias=V0130+0 align=2 words (r54.10)
//.declare P13 (173)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0150 (174)  rf=r size=4 type=ud alias=V0148+0 align=2 words (r2.0)
//.declare P14 (175)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P15 (177)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0152 (178)  rf=r size=8 type=d align=2 words (r1.2)
//.declare V0153 (179)  rf=r size=8 type=d alias=V0049+0 align=4 words (r2.10)
//.declare V0154 (180)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0155 (181)  rf=r size=8 type=ud alias=V0154+0 align=4 words (r3.0)
//.declare V0156 (182)  rf=r size=8 type=d alias=V0154+0 align=4 words (r3.0)
//.declare V0157 (183)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0160 (186)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0161 (187)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0162 (188)  rf=r size=8 type=d align=2 words (r7.0)
//.declare V0163 (189)  rf=r size=8 type=d alias=V0161+0 align=4 words (r6.0)
//.declare V0164 (190)  rf=r size=8 type=q align=4 words (r9.0)
//.declare V0165 (191)  rf=r size=8 type=ud alias=V0162+0 align=2 words (r7.0)
//.declare V0166 (192)  rf=r size=8 type=ud alias=V0152+0 align=2 words (r1.2)
//.declare V0167 (193)  rf=r size=8 type=ud alias=V0164+0 align=4 words (r9.0)
//.declare V0168 (194)  rf=r size=8 type=d alias=V0164+0 align=4 words (r9.0)
//.declare V0169 (195)  rf=r size=4 type=d align=32 words (r10.0)
//.declare V0170 (196)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0171 (197)  rf=r size=8 type=q align=4 words (r54.7)
//.declare V0172 (198)  rf=r size=8 type=q align=4 words (r12.0)
//.declare V0173 (199)  rf=r size=8 type=ud alias=V0172+0 align=4 words (r12.0)
//.declare V0174 (200)  rf=r size=8 type=d alias=V0172+0 align=4 words (r12.0)
//.declare V0175 (201)  rf=r size=4 type=d align=32 words (r13.0)
//.declare V0177 (203)  rf=r size=8 type=q align=4 words (r56.1)
//.declare V0178 (204)  rf=r size=128 type=d align=32 words (r61.0)
//.declare V0179 (205)  rf=r size=8 type=q align=4 words (r56.2)
//.declare V0180 (206)  rf=r size=128 type=d align=32 words (r63.0)
//.declare V0181 (207)  rf=r size=128 type=d align=32 words (r65.0)
//.declare V0182 (208)  rf=r size=128 type=d align=32 words (r67.0)
//.declare V0183 (209)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0184 (210)  rf=r size=128 type=d align=32 words (r69.0)
//.declare V0185 (211)  rf=r size=128 type=d align=32 words (r71.0)
//.declare V0186 (212)  rf=r size=128 type=ud alias=V0184+0 align=32 words (r69.0)
//.declare V0187 (213)  rf=r size=128 type=ud alias=V0181+0 align=32 words (r65.0)
//.declare V0188 (214)  rf=r size=128 type=ud alias=V0185+0 align=32 words (r71.0)
//.declare V0189 (215)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0190 (216)  rf=r size=128 type=ud alias=V0182+0 align=32 words (r67.0)
//.declare V0191 (217)  rf=r size=128 type=ud alias=V0189+0 align=32 words (r5.0)
//.declare V0192 (218)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0194 (220)  rf=r size=128 type=ud alias=V0192+0 align=32 words (r7.0)
//.declare V0197 (223)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0198 (224)  rf=r size=128 type=d align=32 words (r73.0)
//.declare V0199 (225)  rf=r size=128 type=d align=32 words (r17.0)
//.declare P16 (226)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P17 (227)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0201 (229)  rf=r size=128 type=ud alias=V0178+0 align=32 words (r61.0)
//.declare V0204 (232)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0205 (233)  rf=r size=32 type=b align=32 words (r24.0)
//.declare V0206 (234)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0207 (235)  rf=r size=128 type=b alias=V0206+0 align=32 words (r16.0)
//.declare V0211 (239)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare V0213 (241)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare V0214 (242)  rf=r size=128 type=w alias=V0213+0 align=32 words (r22.0)
//.declare V0216 (244)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0217 (245)  rf=r size=128 type=d align=32 words (r25.0)
//.declare P18 (247)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0219 (248)  rf=r size=128 type=f align=32 words (r31.0)
//.declare V0221 (250)  rf=r size=128 type=f alias=V0198+0 align=32 words (r73.0)
//.declare V0223 (252)  rf=r size=128 type=d align=32 words (r27.0)
//.declare V0225 (254)  rf=r size=128 type=f alias=V0223+0 align=32 words (r27.0)
//.declare P19 (255)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P20 (256)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0229 (260)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0230 (261)  rf=r size=32 type=b align=32 words (r44.0)
//.declare V0231 (262)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0232 (263)  rf=r size=128 type=b alias=V0231+0 align=32 words (r24.0)
//.declare V0236 (267)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0243 (274)  rf=r size=256 type=uq align=32 words (r38.0)
//.declare V0244 (275)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0248 (279)  rf=r size=256 type=uq align=32 words (r30.0)
//.declare V0250 (281)  rf=r size=128 type=ud align=32 words (r36.0)
//.declare V0251 (282)  rf=r size=128 type=w alias=V0250+0 align=32 words (r36.0)
//.declare V0253 (284)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0254 (285)  rf=r size=128 type=d align=32 words (r45.0)
//.declare P21 (287)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0256 (288)  rf=r size=128 type=f align=32 words (r51.0)
//.declare V0259 (291)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0261 (293)  rf=r size=128 type=f alias=V0259+0 align=32 words (r47.0)
//.declare P22 (294)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P23 (295)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P24 (296)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0262 (297)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r63.0)
//.declare V0263 (298)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0264 (299)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0265 (300)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0266 (301)  rf=r size=128 type=uw alias=V0264+0 align=32 words (r5.0)
//.declare V0267 (302)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (303)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P25 (304)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0270 (307)  rf=r size=128 type=f align=32 words (r75.0)
//.declare V0271 (308)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0272 (309)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0273 (310)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0274 (311)  rf=r size=128 type=uw alias=V0272+0 align=32 words (r12.0)
//.declare V0275 (312)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (313)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P26 (314)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0278 (317)  rf=r size=128 type=f align=32 words (r77.0)
//.declare V0279 (318)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0280 (319)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0281 (320)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0282 (321)  rf=r size=128 type=uw alias=V0280+0 align=32 words (r19.0)
//.declare V0283 (322)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (323)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P27 (324)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0286 (327)  rf=r size=128 type=f align=32 words (r79.0)
//.declare V0287 (328)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0288 (329)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0289 (330)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0290 (331)  rf=r size=128 type=uw alias=V0288+0 align=32 words (r26.0)
//.declare V0291 (332)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (333)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P28 (334)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0294 (337)  rf=r size=128 type=f align=32 words (r81.0)
//.declare V0295 (338)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0296 (339)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0297 (340)  rf=r size=128 type=f align=32 words (r83.0)
//.declare V0298 (341)  rf=r size=128 type=uw alias=V0296+0 align=32 words (r33.0)
//.declare V0299 (342)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (343)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P29 (344)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P30 (345)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P31 (346)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0301 (348)  rf=r size=128 type=f align=32 words (r3.0)
//.declare P32 (349)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0302 (350)  rf=r size=128 type=d align=32 words (r85.0)
//.declare V0303 (351)  rf=r size=128 type=d alias=V0301+0 align=32 words (r3.0)
//.declare V0304 (352)  rf=r size=128 type=d align=32 words (r5.0)
//.declare P33 (353)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0305 (354)  rf=r size=128 type=ud alias=V0304+0 align=32 words (r5.0)
//.declare V0306 (355)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0307 (356)  rf=r size=128 type=ud alias=V0302+0 align=32 words (r85.0)
//.declare V0308 (357)  rf=r size=128 type=ud alias=V0306+0 align=32 words (r3.0)
//.declare V0309 (358)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0310 (359)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0311 (360)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0312 (361)  rf=r size=128 type=ud alias=V0310+0 align=32 words (r8.0)
//.declare V0313 (362)  rf=r size=128 type=ud alias=V0311+0 align=32 words (r10.0)
//.declare V0314 (363)  rf=r size=64 type=w align=32 words (r87.0)
//.declare V0315 (364)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0316 (365)  rf=r size=128 type=ud alias=V0315+0 align=32 words (r3.0)
//.declare V0318 (367)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0321 (370)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare P34 (371)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0322 (372)  rf=r size=2 type=uw align=1 words (r54.19)
//.declare V0324 (374)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare V0325 (375)  rf=r size=4 type=uw alias=V0324+0 align=2 words (r3.0)
//.declare A05 (376)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0327 (378)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare P35 (380)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P36 (381)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P37 (382)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P38 (383)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P39 (384)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P40 (385)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P41 (386)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0329 (387)  rf=r size=2 type=b align=1 words (r1.8)
//.declare V0330 (388)  rf=r size=2 type=w align=1 words (r2.0)
//.declare V0331 (389)  rf=r size=2 type=ub alias=V0329+0 align=1 words (r1.8)
//.declare P42 (390)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0332 (391)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0333 (392)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0335 (394)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0338 (397)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare  (398)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (399)  rf=r size=4 type=d alias=V0146+0 align=2 words (r54.12)
//.declare  (400)  rf=r size=128 type=w alias=V0315+0 align=32 words (r3.0)
//.declare  (401)  rf=r size=8 type=f align=8 words (r12.0)
//.declare  (402)  rf=r size=8 type=ud align=8 words (r4.0)
//.declare  (403)  rf=r size=8 type=d align=8 words (r56.8)
//.declare  (404)  rf=r size=64 type=uw align=32 words (r37.0)
//.declare  (405)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (406)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare  (407)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (408)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (409)  rf=r size=4 type=f align=2 words (r7.0)
//.declare  (410)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare  (411)  rf=r size=2 type=w align=1 words (r1.4)
//.declare  (412)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare  (413)  rf=r size=4 type=ud align=32 words (r8.0)
//.declare  (414)  rf=r size=128 type=ud align=32 words (r9.0)
//.declare  (415)  rf=r size=128 type=ud align=32 words (r15.0)
//.declare  (416)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (417)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (420)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (421)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (426)  rf=r size=2 type=uw align=1 words (r36.0)
//.declare  (428)  rf=r size=128 type=w alias=V0311+0 align=32 words (r10.0)
//.declare  (429)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare  (430)  rf=r size=2 type=uw align=1 words (r2.0)
//.declare  (432)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (441)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (442)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (449)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (450)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (451)  rf=r size=128 type=d align=32 words (r34.0)
//.declare  (452)  rf=r size=128 type=d align=32 words (r7.0)
//.declare  (453)  rf=r size=128 type=q align=32 words (r21.0)
//.declare  (454)  rf=r size=128 type=q align=32 words (r28.0)
//.declare  (457)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (458)  rf=r size=128 type=q align=32 words (r19.0)
//.declare  (461)  rf=r size=128 type=uq alias=+0 align=32 words (r13.0)
//.declare  (462)  rf=r size=128 type=uq alias=+0 align=32 words (r15.0)
//.declare  (463)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare  (464)  rf=r size=128 type=d alias=+0 align=32 words (r15.0)
//.declare  (465)  rf=r size=128 type=d alias=+0 align=32 words (r21.0)
//.declare  (466)  rf=r size=128 type=d alias=+0 align=32 words (r28.0)
//.declare r0 (467)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (468)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (469)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (470)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :q       |    0x8 | r1       | inline+0x0       |
// | V0041    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0042    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r2       | cti+0x20         |
// | V0045    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0050    | :d       |    0x4 | r2+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r2+0x34  | cti+0x54         |
// | V0052    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0054    | :b       |    0x1 | r3       | cti+0x60         |
// | V0055    | :b       |    0x1 | r3+0x4   | cti+0x64         |
// | V0037    | :uq      |    0x8 | r3+0x8   | cti+0x68         |
// | V0038    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r53.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r1.8<2>:b     r53.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     mov (8|M0)               r55.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {@2,$0.dst}          //  ALU pipe: int; $9
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $12
(W)     mov (1|M0)               r3.0<1>:q     r2.0<0;1,0>:w                    {@2,$1.dst}          //  ALU pipe: int; $9
(W)     add (8|M0)               r55.8<1>:w    r55.0<1;1,0>:w    8:w                                 //  ALU pipe: int; $5
(W)     add (1|M0)               r54.1<1>:q    r53.1<0;1,0>:ud   r3.0<0;1,0>:q    {I@2}              //  ALU pipe: int; $10
(W)     add (16|M0)              r55.16<1>:w   r55.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $6
(W)     mov (2|M0)               r54.0<1>:d    r2.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     mov (2|M0)               r54.4<1>:d    r54.2<1;1,0>:d                   {I@3}                //  ALU pipe: int; $11
(W&~f3.0) jmpi                               _0_042                                                  //  ALU pipe: int; $13
// B002: Preds:{B001},  Succs:{B004}
_0_043:
(W)     mov (1|M0)               r54.6<1>:d    -1:w                                                  //  ALU pipe: int; $15
(W)     jmpi                                 _0_044                                                  // $16
// B003: Preds:{B001},  Succs:{B004}
_0_042:
(W)     mov (1|M0)               r1.2<2>:d     r54.1<0;1,0>:q                                        //  ALU pipe: int; $18
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $19
(W)     mov (1|M0)               r2.0<1>:f     r2.12<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $20
(W)     mov (1|M0)               r7.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $25
(W)     math.inv (1|M0)          r6.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $24
(W)     mov (1|M0)               r5.0<1>:f     r1.2<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $23
(W)     mad (1|M0)               r8.0<1>:f     r6.0<0;0>:f       r7.0<0;0>:f       r6.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $25
(W)     mov (1|M0)               r3.0<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $21
(W)     mov (1|M0)               r10.0<1>:ud   r5.0<0;1,0>:f                    {F@2}                //  ALU pipe: int; $27
(W)     mul (1|M0)               r9.0<1>:f     r5.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $26
(W)     add (1|M0)               r4.0<1>:d     r2.12<0;1,0>:d    -r3.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $22
(W)     add (1|M0)               r4.1<1>:d     r1.2<0;1,0>:d     -r10.0<0;1,0>:d  {I@2}              //  ALU pipe: int; $28
(W)     mov (1|M0)               r11.0<1>:ud   r9.0<0;1,0>:f                    {F@1}                //  ALU pipe: int; $29
(W)     mov (1|M0)               r12.0<1>:f    r4.0<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $30
(W)     mov (1|M0)               r12.1<1>:f    r4.1<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $30
(W)     mov (1|M0)               r13.0<1>:f    r11.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $32
(W)     mad (1|M0)               r14.0<1>:f    r5.0<0;0>:f       r13.0<0;0>:f      -r2.0<0>:f       {F@1} //  ALU pipe: float; $34
(W)     mad (1|M0)               r15.0<1>:f    r12.1<0;0>:f      r13.0<0;0>:f      -r12.0<0>:f       //  ALU pipe: float; $36
(W)     add (1|M0)               r16.0<1>:f    r14.0<0;1,0>:f    r15.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $37
(W)     mul (1|M0)               r17.0<1>:f    r8.0<0;1,0>:f     r16.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $38
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $39
(W)     mov (1|M0)               r18.0<1>:ud   r17.0<0;1,0>:f                   {A@1}                //  ALU pipe: int; $40
(W)     add (1|M0)               r19.0<1>:d    r18.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $41
(W)     mul (1|M0)               acc0.0<1>:d   r19.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $42
(W)     macl (1|M0)              r20.0<1>:d    r19.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $43
(W)     add (1|M0)               r21.0<1>:d    r1.2<0;1,0>:d     -r20.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $43
(W)     cmp (1|M0)    (ge)f2.0   r22.0<1>:ud   r21.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@1}              //  ALU pipe: int; $44
(W)     add3 (1|M0)              r54.6<1>:d    r18.0<0;0>:d      r11.0<0;0>:d      -r22.0<0>:d      {I@1} //  ALU pipe: int; $45
// B004: Preds:{B003, B002},  Succs:{B005, B006}
_0_044:
(W)     mul (1|M0)               acc0.0<1>:ud  r54.6<0;1,0>:ud   r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $47
(W)     macl (1|M0)              r56.0<1>:ud   r54.6<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $48
(W)     mul (1|M0)               acc0.0<1>:ud  r54.6<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $48
(W)     mach (1|M0)              r2.0<1>:d     r54.6<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $54
(W)     macl (1|M0)              r3.0<1>:ud    r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; $55
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $55
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r54.4<0;1,0>:ud   r3.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $67
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r54.4<0;1,0>:ud   r3.0<0;1,0>:ud                      //  ALU pipe: int; $61
(W)     mach (1|M0)              r4.0<1>:d     r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; 
        mov (32|M0)              r57.0<1>:d    r55.0<1;1,0>:uw                                       //  ALU pipe: int; $66
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r54.5<0;1,0>:d    r4.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $68
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r54.5<0;1,0>:d    r4.0<0;1,0>:d                       //  ALU pipe: int; $62
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:ud    r54.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $70
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r54.5<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $64
(W)     mov (1|M0)               r54.7<1>:d    r2.0<0;1,0>:d                                         //  ALU pipe: int; $53
(W&f1.0) jmpi                                _0_045                                                  //  ALU pipe: int; $72
// B005: Preds:{B004},  Succs:{B028}
_0_046:
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $76
(W)     mov (1|M0)               r54.8<1>:d    0:w                                                   //  ALU pipe: int; $74
(W)     mov (1|M0)               r54.18<1>:w   0:w                                                   //  ALU pipe: int; $75
(W)     jmpi                                 _0_047                                                  // $77
// B006: Preds:{B004},  Succs:{B007, B008}
_0_045:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r54.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $79
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r54.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $80
(W&~f3.0) jmpi                               _0_048                                                  //  ALU pipe: int; $82
// B007: Preds:{B006},  Succs:{B009}
_0_049:
(W)     mov (2|M0)               r56.8<1>:d    0:w                                                   //  ALU pipe: int; $84
(W)     mov (1|M0)               r54.10<1>:d   r2.12<0;1,0>:d                                        //  ALU pipe: int; $86
(W)     jmpi                                 _0_050                                                  // $87
// B008: Preds:{B006},  Succs:{B009}
_0_048:
(W)     mul (1|M0)               acc0.0<1>:ud  r54.6<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $90
(W)     mach (1|M0)              r2.0<1>:d     r54.6<0;1,0>:ud   0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.2<2>:ud    r54.6<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $89
(W)     mov (1|M0)               r1.3<2>:d     r2.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $94
(W)     add (1|M0)               r4.0<1>:q     r1.1<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $95
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $97
(W)     mov (1|M0)               r56.8<1>:d    r5.0<0;1,0>:d                    {$2.dst}             //  ALU pipe: int; $98
(W)     mov (1|M0)               r56.9<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $99
(W)     mov (1|M0)               r54.10<1>:d   r5.2<0;1,0>:d                                         //  ALU pipe: int; $100
// B009: Preds:{B008, B007},  Succs:{B010, B011}
_0_050:
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r56.9<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $102
(W&~f2.0) cmp (32|M0) (ge)f2.0   null<1>:ud    r56.8<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; $103
(W&~f2.0) jmpi                               _0_051                                                  //  ALU pipe: int; $105
// B010: Preds:{B009},  Succs:{B028}
_0_052:
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $109
(W)     mov (1|M0)               r54.8<1>:d    0:w                                                   //  ALU pipe: int; $107
(W)     mov (1|M0)               r54.18<1>:w   0:w                                                   //  ALU pipe: int; $108
(W)     jmpi                                 _0_047                                                  // $110
// B011: Preds:{B009},  Succs:{B012, B013}
_0_051:
(W)     mov (1|M0)               r1.2<1>:d     r56.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $112
(W)     mov (1|M0)               r1.3<1>:d     r54.7<0;1,0>:d                                        //  ALU pipe: int; $113
(W)     cmp (32|M0)   (le)f3.0   null<1>:ud    r54.10<0;1,0>:ud  r2.12<0;1,0>:ud  {I@7}              //  ALU pipe: int; $119
(W)     add (1|M0)               r54.6<1>:q    r54.1<0;1,0>:q    -r1.1<0;1,0>:q   {I@2}              //  ALU pipe: int; $116
(W)     add (1|M0)               r2.0<1>:d     r2.12<0;1,0>:d    -r56.9<0;1,0>:d                     //  ALU pipe: int; $118
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r54.10<0;1,0>:ud  r54.12<0;1,0>:ud {I@2}              //  ALU pipe: int; $122
(W&f3.0) cmp (32|M0)  (le)f3.0   null<1>:ud    r54.10<0;1,0>:ud  r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $120
(W)     mov (1|M0)               r3.0<1>:ud    f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $123
(W)     and (1|M0)               f1.0<1>:ud    f3.0<0;1,0>:ud    r3.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $123
(W&f1.0) jmpi                                _0_053                                                  //  ALU pipe: int; $124
// B012: Preds:{B011},  Succs:{B028}
_0_054:
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $128
(W)     mov (1|M0)               r1.4<1>:w     1:w                                                   //  ALU pipe: int; $126
(W)     mov (1|M0)               r54.8<1>:d    0:w                                                   //  ALU pipe: int; $127
(W&f3.0) sel (1|M0)              r54.18<1>:w   r1.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $126
(W)     jmpi                                 _0_047                                                  // $129
// B013: Preds:{B011},  Succs:{B014}
_0_053:
(W)     mul (1|M0)               acc0.0<1>:ud  r56.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $132
(W)     macl (1|M0)              r2.0<1>:ud    r56.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $133
(W)     mul (1|M0)               acc0.0<1>:ud  r56.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $133
(W)     mach (1|M0)              r4.0<1>:d     r56.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r3.0<2>:f     r2.0<0;1,0>:f                    {I@3}                //  ALU pipe: float; $133
(W)     mov (1|M0)               r3.1<2>:d     r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $137
(W)     mov (2|M0)               r1.2<1>:d     r2.10<1;1,0>:d                                        //  ALU pipe: int; $131
(W)     add (1|M0)               r5.0<1>:q     r3.0<0;1,0>:q     r56.9<0;1,0>:ud  {A@1}              //  ALU pipe: int; $139
        shl (32|M0)              r61.0<1>:d    r57.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $156
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r54.6<0;1,0>:q   {I@2}              //  ALU pipe: int; $140
        mov (32|M0)              r59.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $158
(W)     mov (2|M0)               r7.0<1>:f     r6.0<1;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $141
        mov (32|M0)              r63.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $159
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw   {F@2}              //  ALU pipe: int; $142
(W)     macl (1|M0)              r8.0<1>:ud    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $143
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw                      //  ALU pipe: int; $143
(W)     mach (1|M0)              r10.0<1>:d    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r7.0<0;1,0>:ud    r1.6<0;1,0>:uw                      //  ALU pipe: int; $144
(W)     macl (1|M0)              r11.0<1>:d    r7.0<0;1,0>:ud    r1.3<0;1,0>:d                       //  ALU pipe: int; $145
(W)     mul (1|M0)               acc0.0<1>:d   r1.2<0;1,0>:ud    r7.2<0;1,0>:uw                      //  ALU pipe: int; $146
(W)     add (1|M0)               r10.0<1>:d    r10.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $145
(W)     macl (1|M0)              r11.0<1>:d    r1.2<0;1,0>:ud    r7.1<0;1,0>:d                       //  ALU pipe: int; $147
(W)     mul (1|M0)               acc0.0<1>:ud  r54.6<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $150
(W)     mov (1|M0)               r9.0<2>:f     r8.0<0;1,0>:f                                         //  ALU pipe: float; $143
(W)     add (1|M0)               r9.1<2>:d     r10.0<0;1,0>:d    r11.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $147
(W)     mach (1|M0)              r13.0<1>:d    r54.6<0;1,0>:ud   0x3000:ud                           //  ALU pipe: int; 
(W)     mul (1|M0)               r12.0<2>:ud   r54.6<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $149
(W)     add (1|M0)               r54.7<1>:q    r9.0<0;1,0>:q     r1.0<0;1,0>:q    {A@1}              //  ALU pipe: int; $148
(W)     mov (1|M0)               r12.1<2>:d    r13.0<0;1,0>:d                   {I@3}                //  ALU pipe: int; $154
(W)     add (1|M0)               r56.2<1>:q    r54.7<0;1,0>:q    6144:w               {I@2}          //  ALU pipe: int; $157
(W)     add (1|M0)               r56.1<1>:q    r12.0<0;1,0>:q    r1.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $155
// B014: [inDivergent],  Preds:{B027, B013},  Succs:{B015}
_0_055:
        add (32|M0)              r65.0<1>:d    r63.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $161
        mov (32|M0)              r67.0<1>:f    r63.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $162
// B015: [inDivergent],  Preds:{B024, B014},  Succs:{B016, B020}
_0_056:
        shr (32|M0)              r5.0<1>:ud    r67.0<1;1,0>:ud   3:w               {F@1}             //  ALU pipe: int; $167
        and (32|M0)              r7.0<1>:d     r5.0<1;1,0>:d     536870908:d               {I@1}     //  ALU pipe: int; $168
        mov (16|M0)              r9.0<2>:ud    r7.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $170
        mov (16|M16)             r15.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $170
        add (16|M0)              r11.0<1>:q    r56.2<0;1,0>:q    r9.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $170
        add (16|M16)             r13.0<1>:q    r56.2<0;1,0>:q    r15.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $170
        load.ugm.d32.a64 (32|M0)  r73:2         [r11:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200580 // $172
        and (32|M0)              r3.0<1>:d     r67.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $164
        add (32|M0)              r69.0<1>:d    r3.0<1;1,0>:d     32:w               {Compacted,I@1}  //  ALU pipe: int; $165
        sel (32|M0)   (lt)f0.0   r71.0<1>:ud   r69.0<1;1,0>:ud   r65.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $166
        and (32|M0)              r17.0<1>:d    r73.0<1;1,0>:d    2139095040:d               {$3.dst} //  ALU pipe: int; $173
        cmp (32|M0)   (eq)f2.0   null<1>:d     r17.0<1;1,0>:d    2139095040:d               {I@1}    //  ALU pipe: int; $174
(f2.0)  goto (32|M0)                         _0_057            _0_057                                //  ALU pipe: int; $175
// B016: [inDivergent],  Preds:{B015},  Succs:{B017, B023}
_0_058:
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r67.0<1;1,0>:ud   r71.0<1;1,0>:ud                     //  ALU pipe: int; $177
(~f1.0) goto (32|M0)                         _0_057            _0_059                                //  ALU pipe: int; $178
// B017: [inDivergent],  Preds:{B016},  Succs:{B018}
_0_060:
        mov (32|M0)              r61.0<1>:f    r67.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $180
// B018: [inDivergent],  Preds:{B018, B017},  Succs:{B019, B018}
_0_061:
        mov (16|M0)              r3.0<2>:ud    r61.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $183
        mov (16|M16)             r5.0<2>:ud    r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $183
        add (16|M0)              r7.0<1>:q     r54.7<0;1,0>:q    r3.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $183
        add (16|M16)             r9.0<1>:q     r54.7<0;1,0>:q    r5.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $183
        load.ugm.d8u32.a64 (32|M0)  r16:2       [r7:4]             {I@1,$4} // ex_desc:0x0; desc:0x8200980 // $185
        shl (16|M0)              r11.0<1>:q    r3.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $187
        shl (16|M16)             r13.0<1>:q    r5.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $187
        add (16|M0)              r18.0<1>:q    r56.1<0;1,0>:q    r11.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $188
        add (16|M16)             r20.0<1>:q    r56.1<0;1,0>:q    r13.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $188
        load.ugm.d16u32.a64 (32|M0)  r22:2      [r18:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200B80 // $190
        add (32|M0)              r61.0<1>:d    r61.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $200
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r61.0<1;1,0>:ud   r71.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $201
        mov (32|M0)              r24.0<1>:b    r16.0<4;1,0>:b                   {$4.dst}             //  ALU pipe: int; $186
        mov (32|M0)   (lt)f1.0   null<2>:w     r24.0<1;1,0>:b                   {I@1}                //  ALU pipe: int; $192
        or (32|M0)               r25.0<1>:d    r16.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $191
(f1.0)  sel (32|M0)              r29.0<1>:d    r25.0<1;1,0>:d    r16.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $194
        mov (32|M0)              r31.0<1>:f    r29.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $195
        shl (32|M0)              r27.0<1>:d    r22.0<1;1,0>:ud   16:w               {$5.dst}         //  ALU pipe: int; $197
        mul (32|M0)              acc0.0<1>:f   r73.0<1;1,0>:f    r31.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $196
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r27.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $198
        add (32|M0)              r59.0<1>:f    r59.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $199
(f3.0)  goto.b (32|M0)                       _L_k0_0_          _0_061                                //  ALU pipe: int; $202
// B019: [inDivergent],  Preds:{B018},  Succs:{B023}
_L_k0_0_:
        join (32|M0)                         _0_057                                                  // 
L2560:
        goto (32|M0)                         _0_057            _0_059                                // $203
// B020: [inDivergent],  Preds:{B015},  Succs:{B021, B023}
_0_057:
        join (32|M0)                         _0_059                                                  // 
L2592:
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r67.0<1;1,0>:ud   r71.0<1;1,0>:ud                     //  ALU pipe: int; $205
(~f3.0) goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $206
// B021: [inDivergent],  Preds:{B020},  Succs:{B022}
_0_062:
        mov (32|M0)              r61.0<1>:f    r67.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $208
// B022: [inDivergent],  Preds:{B022, B021},  Succs:{B023, B022}
_0_063:
        mov (16|M0)              r3.0<2>:ud    r61.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $211
        mov (16|M16)             r5.0<2>:ud    r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $211
        add (16|M0)              r9.0<1>:q     r54.7<0;1,0>:q    r3.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $211
        add (16|M16)             r11.0<1>:q    r54.7<0;1,0>:q    r5.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $211
        load.ugm.d8u32.a64 (32|M0)  r24:2       [r9:4]             {I@1,$6} // ex_desc:0x0; desc:0x8200980 // $213
        shr (16|M0)              r13.0<1>:uq   r3.0<2;1,0>:ud    3:w                                 //  ALU pipe: int; $215
        shr (16|M16)             r15.0<1>:uq   r5.0<2;1,0>:ud    3:w                                 //  ALU pipe: int; $215
        and (16|M0)              r26.0<1>:d    r13.0<2;1,0>:d    536870908:d               {I@2}     //  ALU pipe: int; $216
        and (16|M16)             r27.0<1>:d    r15.0<2;1,0>:d    536870908:d               {I@2}     //  ALU pipe: int; $217
        mov (32|M0)              r7.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $219
        mov (32|M0)              r34.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@2}      //  ALU pipe: float; $218
        shl (16|M0)              r17.0<1>:q    r3.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $227
        shl (16|M16)             r19.0<1>:q    r5.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $227
        mov (16|M0)              r21.1<2>:d    r7.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $222
        mov (16|M16)             r28.1<2>:d    r8.0<1;1,0>:d                                         //  ALU pipe: int; $223
        mov (16|M0)              r21.0<2>:d    r34.0<1;1,0>:d                   {F@1}                //  ALU pipe: int; $220
        mov (16|M16)             r28.0<2>:d    r35.0<1;1,0>:d                                        //  ALU pipe: int; $221
        add (16|M0)              r30.0<1>:q    r56.1<0;1,0>:q    r17.0<1;1,0>:q   {Compacted,I@6}    //  ALU pipe: int; $228
        add (16|M16)             r32.0<1>:q    r56.1<0;1,0>:q    r19.0<1;1,0>:q   {Compacted,I@6}    //  ALU pipe: int; $228
        add (16|M0)              r38.0<1>:q    r56.2<0;1,0>:q    r21.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $224
        add (16|M16)             r40.0<1>:q    r56.2<0;1,0>:q    r28.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $224
        load.ugm.d16u32.a64 (32|M0)  r36:2      [r30:4]            {I@3,$7} // ex_desc:0x0; desc:0x8200B80 // $230
        load.ugm.d32.a64 (32|M0)  r42:2         [r38:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $226
        add (32|M0)              r61.0<1>:d    r61.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $240
        mov (32|M0)              r44.0<1>:b    r24.0<4;1,0>:b                   {$6.dst}             //  ALU pipe: int; $214
        mov (32|M0)   (lt)f2.0   null<2>:w     r44.0<1;1,0>:b                   {I@1}                //  ALU pipe: int; $232
        or (32|M0)               r45.0<1>:d    r24.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $231
(f2.0)  sel (32|M0)              r49.0<1>:d    r45.0<1;1,0>:d    r24.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $234
        mov (32|M0)              r51.0<1>:f    r49.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $235
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r61.0<1;1,0>:ud   r71.0<1;1,0>:ud                     //  ALU pipe: int; $241
        shl (32|M0)              r47.0<1>:d    r36.0<1;1,0>:ud   16:w               {$7.dst}         //  ALU pipe: int; $237
        mul (32|M0)              acc0.0<1>:f   r42.0<1;1,0>:f    r51.0<1;1,0>:f   {Compacted,@1,$8.dst} //  ALU pipe: float; $236
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r47.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $238
        add (32|M0)              r59.0<1>:f    r59.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $239
(f1.0)  goto.b (32|M0)                       _0_059            _0_063                                //  ALU pipe: int; $242
// B023: [inDivergent],  Preds:{B022, B020, B019, B016},  Succs:{B024, B025}
_0_059:
        join (32|M0)                         _0_064                                                  // 
L3112:
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r65.0<1;1,0>:ud   r69.0<1;1,0>:ud                     //  ALU pipe: int; $244
(~f2.0) goto (32|M0)                         _0_064            _0_064                                //  ALU pipe: int; $245
// B024: [inDivergent],  Preds:{B023},  Succs:{B015}
_0_065:
        mov (32|M0)              r67.0<1>:f    r71.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $247
(W)     jmpi                                 _0_056                                                  // $248
// B025: [inDivergent],  Preds:{B023},  Succs:{B026, B027}
_0_064:
        join (32|M0)                         _0_047                                                  // 
L3184:
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r63.0<1;1,0>:ud   0x1700:uw                           //  ALU pipe: int; $250
(f3.0)  goto (32|M0)                         _0_066            _0_066                                //  ALU pipe: int; $251
// B026: [inDivergent],  Preds:{B025},  Succs:{B028}
_0_067:
(W)     mov (1|M0)               r54.8<1>:d    -1:w                                                  //  ALU pipe: int; $253
(W)     mov (1|M0)               r54.18<1>:hf  0x1:hf                                                //  ALU pipe: float; $254
        goto (32|M0)                         _0_066            _0_047                                // $255
// B027: [inDivergent],  Preds:{B025},  Succs:{B014}
_0_066:
        join (32|M0)                         _0_047                                                  // 
L3280:
        add (32|M0)              r61.0<1>:d    r63.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $257
        mov (32|M0)              r63.0<1>:f    r61.0<1;1,0>:f                   {Compacted,I@1}      //  ALU pipe: float; $258
(W)     jmpi                                 _0_055                                                  // $259
// B028: Preds:{B026, B012, B010, B005},  Succs:{B029, B033}
_0_047:
        join (32|M0)                         L3328                                                   // 
L3328:
        add (32|M0)              r3.0<1>:d     r57.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $261
        and (32|M0)              r5.0<1>:d     r3.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $262
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $263
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $264
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0xEC0:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0127(r59.0:f); $265
        add (32|M0)              r10.0<1>:d    r57.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $274
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@4}                //  ALU pipe: int; $266
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $267
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0xEC0:uw                            //  ALU pipe: int; src1 is addr of V0127(r59.0:f); $268
        and (32|M0)   (eq)f3.0   null<1>:d     r57.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $270
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $275
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $269
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $276
(f3.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $272
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $277
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0x12C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0270(r75.0:f); $278
        add (32|M0)              r75.0<1>:f    r59.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $273
        add (32|M0)              r17.0<1>:d    r57.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $287
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $279
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $280
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0x12C0:uw                           //  ALU pipe: int; src1 is addr of V0270(r75.0:f); $281
        and (32|M0)   (eq)f2.0   null<1>:d     r57.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $283
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $288
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $282
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $289
(f2.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $285
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $290
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0x1340:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0278(r77.0:f); $291
        add (32|M0)              r77.0<1>:f    r75.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $286
        add (32|M0)              r24.0<1>:d    r57.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $300
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $292
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $293
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0x1340:uw                           //  ALU pipe: int; src1 is addr of V0278(r77.0:f); $294
        and (32|M0)   (eq)f1.0   null<1>:d     r57.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $296
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $301
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $295
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $302
(f1.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $298
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $303
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0x13C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0286(r79.0:f); $304
        add (32|M0)              r79.0<1>:f    r77.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $299
        add (32|M0)              r31.0<1>:d    r57.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $313
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $305
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $306
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0x13C0:uw                           //  ALU pipe: int; src1 is addr of V0286(r79.0:f); $307
        and (32|M0)   (eq)f3.0   null<1>:d     r57.0<1;1,0>:d    15:w                                //  ALU pipe: int; $309
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $314
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $308
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $315
        cmp (32|M0)   (eq)f1.0   null<2>:w     r55.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $322
(f3.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $311
(W)     mov (1|M0)               r36.0<1>:hf   0x1:hf                                                //  ALU pipe: float; $323
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $316
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0x1440:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0294(r81.0:f); $317
        add (32|M0)              r81.0<1>:f    r79.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $312
(f0.0)  sel (32|M0)              r37.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw              {F@2}           //  ALU pipe: int; $323
(f1.0)  sel (32|M0)              r38.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw                              //  ALU pipe: int; $323
        mov (16|M0)              r83.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $318
        and (32|M0)   (ne)f2.0   null<2>:uw    r37.0<1;1,0>:uw   r38.0<1;1,0>:uw  {I@2}              //  ALU pipe: int; $323
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $319
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0x1440:uw                           //  ALU pipe: int; src1 is addr of V0294(r81.0:f); $320
        mov (16|M16)             r84.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $321
(~f2.0) goto (32|M0)                         _0_068            _0_068                                //  ALU pipe: int; $324
// B029: [inDivergent],  Preds:{B028},  Succs:{B030, B031}
_0_069:
        cmp (32|M0)   (eq)f1.0   null<2>:w     r55.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $326
(f1.0)  sel (32|M0)              acc0.0<1>:f   r83.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $327
(W)     cmp (32|M0)   (ne)f3.0   null<1>:d     r54.8<0;1,0>:d    0:w                                 //  ALU pipe: int; $329
        add (32|M0)              r3.0<1>:f     r81.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $328
(f3.0)  sel (32|M0)              r85.0<1>:d    r3.0<1;1,0>:d     2143289344:d               {F@1}    //  ALU pipe: int; $330
        and (32|M0)              r5.0<1>:d     r85.0<1;1,0>:d    2147483647:d               {I@1}    //  ALU pipe: int; $331
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r5.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $332
(f2.0)  goto (32|M0)                         _0_070            _0_070                                //  ALU pipe: int; $333
// B030: [inDivergent],  Preds:{B029},  Succs:{B032}
_0_071:
        shr (32|M0)              r3.0<1>:ud    r85.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $335
        and (32|M0)              r6.0<1>:d     r3.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $336
        add3 (32|M0)             r8.0<1>:d     r85.0<1;0>:d      r6.0<1;0>:d       32767:w               {I@1} //  ALU pipe: int; $337
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $338
        mov (32|M0)              r87.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $339
        goto (32|M0)                         _0_070            _0_072                                // $340
// B031: [inDivergent],  Preds:{B029},  Succs:{B032}
_0_070:
        join (32|M0)                         _0_072                                                  // 
L4448:
        shr (32|M0)              r3.0<1>:ud    r85.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $342
        or (32|M0)               r87.0<1>:w    r3.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $344
// B032: [inDivergent],  Preds:{B031, B030},  Succs:{B033}
_0_072:
        join (32|M0)                         _0_068                                                  // 
L4496:
(W)     mov (1|M0)               f3.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $349
        cmp (32|M0)   (eq)f3.0   null<2>:uw    r54.19<0;1,0>:uw  r54.19<0;1,0>:uw                    //  ALU pipe: int; $350
(W)     fbl (1|M0)               r3.0<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $352
(W)     shl (1|M0)               r1.1<1>:q     r54.1<0;1,0>:q    1:w                                 //  ALU pipe: int; $346
(W)     shl (1|M0)               r3.0<1>:ud    r3.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $353
(W)     add (1|M0)               r2.0<1>:q     r1.1<0;1,0>:q     r1.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $347
(W)     add (1|M0)               a0.0<1>:uw    r3.0<0;1,0>:uw    0x15C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0314(r87.0:w); $354
(W)     mov (1|M0)               r4.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $356
(W)     store.ugm.d16u32.a64 (1|M0)  [r2:2]     r4:1               {I@1,$9} // ex_desc:0x0; desc:0x4000B84 // $357
// B033: Preds:{B032, B028},  Succs:{B034, B035}
_0_068:
        join (32|M0)                         L4640                                                   // 
L4640:
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r54.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $362
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r54.4<0;1,0>:d    r56.0<0;1,0>:d                      //  ALU pipe: int; $359
(W&~f1.0) cmp (32|M0) (ne)f1.0   null<1>:d     r54.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $363
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r54.5<0;1,0>:d    r54.7<0;1,0>:d                      //  ALU pipe: int; $360
(W)     mov (1|M0)               r1.2<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $365
(W)     mov (1|M0)               r2.0<1>:hf    0x1:hf                              {$9.src}          //  ALU pipe: float; $368
(W)     and (1|M0)               f1.0<1>:ud    f2.0<0;1,0>:ud    r1.2<0;1,0>:ud   {I@1}              //  ALU pipe: int; $365
(f0.0)  sel (32|M0)              r4.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $368
(f1.0)  cmp (32|M0)   (eq)f1.0   null<2>:w     r55.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $366
(f1.0)  sel (32|M0)              r3.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $368
        and (32|M0)   (ne)f1.0   null<2>:uw    r3.0<1;1,0>:uw    r4.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $368
(~f1.0) goto (32|M0)                         _0_073            _0_073                                //  ALU pipe: int; $369
// B034: [inDivergent],  Preds:{B033},  Succs:{B035}
_0_074:
(W)     mov (1|M0)               r1.8<2>:b     r54.18<0;1,0>:w                                       //  ALU pipe: int; $371
(W)     mov (1|M0)               r3.0<1>:hf    0xFFFF:hf                              {I@3}          //  ALU pipe: float; $374
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $372
(W)     shl (1|M0)               r7.0<1>:q     r54.6<0;1,0>:ud   2:w                                 //  ALU pipe: int; $377
(W)     cmp (32|M0)   (eq)f0.0   null<2>:w     r2.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $373
(W&f0.0) sel (1|M0)              r4.0<1>:d     r3.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $374
(W)     add (1|M0)               r8.0<1>:q     r7.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $378
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $375
(W)     store.ugm.d32x1t.a64 (1|M0)  [r8:1]     r6:1               {I@1,$10} // ex_desc:0x0; desc:0x2008584 // $380
// B035: Preds:{B034, B033},  Succs:{}
_0_073:
        join (32|M0)                         L4968                                                   // 
L4968:
(W)     mov (16|M0)              r127.0<1>:f   r53.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $382
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$11} // wr:1+0, rd:0; end of thread // $382
L4992:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x14:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 2
//


//.numALUInst: 306
//.accSubDef: 9
//.accSubUse: 9
//.accSubCandidateDef: 9
//.accSubCandidateUse: 9
//
//
//.singlePipeAtOneDistNum: 67
//.allAtOneDistNum: 10
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 9
//.AfterReadTokenDepCount: 1
