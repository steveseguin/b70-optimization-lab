//.kernel _ZTSZZNK3p286KernelILN3iq34TypeE30ELj6144ELj1ELj4ELb0ELb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3271080321 1092724835 -hashmovs1 0 59 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3271080321 1092724835 -hashmovs1 0 59 -GRFBumpUpNumber 2 "
//.instCount 450
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r90.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r90.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r90.0)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.1)
//.declare V0038 (48)  rf=r size=8 type=uq align=4 words (r3.2)
//.declare V0040 (50)  rf=r size=8 type=q align=4 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r1.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r1.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r2.13)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0054 (64)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0055 (65)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0058 (68)  rf=r size=8 type=d align=2 words (r91.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.2)
//.declare V0061 (71)  rf=r size=64 type=w align=32 words (r92.0)
//.declare V0062 (72)  rf=r size=32 type=b alias=V0035+0 align=16 words (r90.0)
//.declare V0063 (73)  rf=r size=1 type=b align=1 words (r1.8)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0068 (78)  rf=r size=1 type=ub alias=V0063+0 align=1 words (r1.8)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r91.1)
//.declare V0070 (80)  rf=r size=8 type=d align=2 words (r91.4)
//.declare V0071 (81)  rf=r size=8 type=d alias=V0069+0 align=4 words (r91.2)
//.declare P01 (82)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0072 (83)  rf=r size=8 type=ud alias=V0070+0 align=2 words (r91.4)
//.declare V0073 (84)  rf=r size=4 type=f align=2 words (r1.2)
//.declare V0074 (85)  rf=r size=4 type=ud alias=V0050+0 align=2 words (r2.12)
//.declare V0075 (86)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0076 (87)  rf=r size=8 type=df align=4 words (r3.0)
//.declare V0077 (88)  rf=r size=8 type=df align=4 words (r4.0)
//.declare V0078 (89)  rf=r size=8 type=df align=4 words (r6.0)
//.declare V0079 (90)  rf=r size=8 type=df align=4 words (r5.0)
//.declare V0080 (91)  rf=r size=8 type=df align=4 words (r9.0)
//.declare V0082 (93)  rf=r size=8 type=df align=4 words (r10.0)
//.declare V0084 (95)  rf=r size=8 type=df align=4 words (r11.0)
//.declare V0086 (97)  rf=r size=8 type=df align=4 words (r12.0)
//.declare V0087 (98)  rf=r size=4 type=d align=4 words (r13.0)
//.declare V0088 (99)  rf=r size=4 type=ud alias=V0087+0 align=2 words (r13.0)
//.declare V0089 (100)  rf=r size=4 type=d align=32 words (r15.0)
//.declare V0090 (101)  rf=r size=4 type=d align=2 words (r16.0)
//.declare V0092 (103)  rf=r size=8 type=df align=4 words (r18.0)
//.declare V0093 (104)  rf=r size=4 type=ud alias=V0090+0 align=2 words (r16.0)
//.declare V0094 (105)  rf=r size=8 type=df align=4 words (r19.0)
//.declare V0096 (107)  rf=r size=8 type=df align=4 words (r22.0)
//.declare V0097 (108)  rf=r size=8 type=df align=4 words (r21.0)
//.declare V0098 (109)  rf=r size=8 type=df align=4 words (r23.0)
//.declare V0099 (110)  rf=r size=8 type=q align=4 words (r24.0)
//.declare V0100 (111)  rf=r size=8 type=uq alias=V0099+0 align=4 words (r24.0)
//.declare V0101 (112)  rf=r size=4 type=d align=2 words (r25.0)
//.declare V0102 (113)  rf=r size=8 type=d alias=V0099+0 align=4 words (r24.0)
//.declare P02 (115)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0104 (116)  rf=r size=4 type=d align=2 words (r26.0)
//.declare V0105 (117)  rf=r size=4 type=d align=2 words (r27.0)
//.declare V0106 (118)  rf=r size=8 type=q align=4 words (r28.0)
//.declare V0108 (120)  rf=r size=8 type=q align=4 words (r29.0)
//.declare V0109 (121)  rf=r size=8 type=d alias=V0108+0 align=4 words (r29.0)
//.declare V0110 (122)  rf=r size=8 type=q align=4 words (r30.0)
//.declare V0112 (124)  rf=r size=8 type=q align=4 words (r31.0)
//.declare V0113 (125)  rf=r size=8 type=d alias=V0112+0 align=4 words (r31.0)
//.declare V0114 (126)  rf=r size=8 type=q align=4 words (r33.0)
//.declare V0115 (127)  rf=r size=4 type=ud alias=V0101+0 align=2 words (r25.0)
//.declare V0116 (128)  rf=r size=8 type=ud alias=V0114+0 align=4 words (r33.0)
//.declare V0117 (129)  rf=r size=8 type=d alias=V0114+0 align=4 words (r33.0)
//.declare V0118 (130)  rf=r size=4 type=d align=32 words (r34.0)
//.declare V0120 (132)  rf=r size=8 type=q align=4 words (r35.0)
//.declare V0121 (133)  rf=r size=8 type=d align=2 words (r36.0)
//.declare V0122 (134)  rf=r size=8 type=d alias=V0120+0 align=4 words (r35.0)
//.declare V0123 (135)  rf=r size=4 type=d align=2 words (r37.0)
//.declare V0124 (136)  rf=r size=8 type=q align=4 words (r38.0)
//.declare V0125 (137)  rf=r size=8 type=q align=4 words (r39.0)
//.declare P03 (138)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0126 (139)  rf=r size=8 type=ud alias=V0121+0 align=2 words (r36.0)
//.declare P04 (140)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P05 (141)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0127 (142)  rf=r size=8 type=q align=4 words (r42.0)
//.declare V0128 (143)  rf=r size=8 type=q align=4 words (r41.0)
//.declare V0129 (144)  rf=r size=8 type=d alias=V0128+0 align=4 words (r41.0)
//.declare V0130 (145)  rf=r size=8 type=q align=4 words (r91.3)
//.declare P06 (146)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0131 (147)  rf=r size=4 type=d align=2 words (r91.8)
//.declare V0132 (148)  rf=r size=4 type=d align=4 words (r1.2)
//.declare V0133 (149)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0134 (150)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0135 (151)  rf=r size=4 type=ud alias=V0134+0 align=2 words (r3.0)
//.declare V0136 (152)  rf=r size=4 type=d alias=+0 align=2 words (r4.0)
//.declare V0137 (153)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0138 (154)  rf=r size=4 type=ud alias=V0132+0 align=2 words (r1.2)
//.declare V0139 (155)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0140 (156)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0141 (157)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0142 (158)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0143 (159)  rf=r size=4 type=ud alias=V0142+0 align=2 words (r10.0)
//.declare V0144 (160)  rf=r size=4 type=d alias=+4 align=2 words (r4.1)
//.declare V0145 (161)  rf=r size=4 type=d align=2 words (r11.0)
//.declare V0146 (162)  rf=r size=4 type=ud alias=V0145+0 align=2 words (r11.0)
//.declare V0147 (163)  rf=r size=4 type=f alias=+0 align=2 words (r12.0)
//.declare V0148 (164)  rf=r size=4 type=ud alias=V0136+0 align=2 words (r4.0)
//.declare V0149 (165)  rf=r size=4 type=f alias=+4 align=2 words (r12.1)
//.declare V0150 (166)  rf=r size=4 type=ud alias=V0144+0 align=2 words (r4.1)
//.declare V0151 (167)  rf=r size=4 type=f align=2 words (r13.0)
//.declare V0153 (169)  rf=r size=4 type=f align=2 words (r14.0)
//.declare V0155 (171)  rf=r size=4 type=f align=2 words (r15.0)
//.declare V0156 (172)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0157 (173)  rf=r size=4 type=f align=2 words (r17.0)
//.declare V0158 (174)  rf=r size=4 type=d align=2 words (r18.0)
//.declare V0159 (175)  rf=r size=4 type=ud alias=V0158+0 align=2 words (r18.0)
//.declare V0160 (176)  rf=r size=4 type=d align=2 words (r19.0)
//.declare V0161 (177)  rf=r size=4 type=d align=32 words (r20.0)
//.declare V0162 (178)  rf=r size=4 type=d align=2 words (r21.0)
//.declare V0163 (179)  rf=r size=4 type=d align=2 words (r22.0)
//.declare V0164 (180)  rf=r size=4 type=ud alias=V0162+0 align=2 words (r21.0)
//.declare V0165 (181)  rf=r size=4 type=ud alias=V0163+0 align=2 words (r22.0)
//.declare  (182)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0166 (183)  rf=r size=4 type=ud alias=V0131+0 align=2 words (r91.8)
//.declare V0167 (184)  rf=r size=8 type=d align=2 words (r91.9)
//.declare V0168 (185)  rf=r size=8 type=d alias=V0130+0 align=4 words (r91.6)
//.declare V0169 (186)  rf=r size=4 type=d align=32 words (r93.0)
//.declare V0170 (187)  rf=r size=4 type=d align=2 words (r91.11)
//.declare V0171 (188)  rf=r size=4 type=ud alias=V0169+0 align=2 words (r93.0)
//.declare V0172 (189)  rf=r size=8 type=ud alias=V0167+0 align=2 words (r91.9)
//.declare V0173 (190)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0175 (192)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0176 (193)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0178 (195)  rf=r size=4 type=ud alias=V0176+0 align=2 words (r4.0)
//.declare V0179 (196)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r2.13)
//.declare V0180 (197)  rf=r size=4 type=d align=32 words (r5.0)
//.declare P07 (200)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P08 (201)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P09 (202)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0184 (204)  rf=r size=128 type=d align=32 words (r94.0)
//.declare V0185 (205)  rf=r size=64 type=uw alias=V0061+0 align=32 words (r92.0)
//.declare P10 (206)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P11 (207)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P12 (208)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0186 (209)  rf=r size=4 type=d align=2 words (r91.12)
//.declare V0187 (210)  rf=r size=2 type=w align=1 words (r91.26)
//.declare V0188 (211)  rf=r size=128 type=f align=32 words (r96.0)
//.declare P13 (212)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P14 (213)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0189 (214)  rf=r size=4 type=d alias=+0 align=2 words (r93.8)
//.declare V0190 (215)  rf=r size=4 type=d alias=+4 align=2 words (r93.9)
//.declare V0191 (216)  rf=r size=4 type=d align=2 words (r91.14)
//.declare V0192 (217)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0193 (218)  rf=r size=8 type=ud alias=V0192+0 align=4 words (r1.2)
//.declare V0194 (219)  rf=r size=8 type=d alias=V0192+0 align=4 words (r1.2)
//.declare V0195 (220)  rf=r size=4 type=d align=32 words (r2.0)
//.declare V0199 (224)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0200 (225)  rf=r size=12 type=d align=32 words (r5.0)
//.declare P15 (226)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0201 (227)  rf=r size=4 type=ud alias=V0190+0 align=2 words (r93.9)
//.declare P16 (228)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0202 (229)  rf=r size=4 type=ud alias=V0189+0 align=2 words (r93.8)
//.declare V0203 (230)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r2.14)
//.declare V0205 (232)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0206 (233)  rf=r size=8 type=d alias=V0205+0 align=4 words (r1.2)
//.declare V0207 (234)  rf=r size=8 type=q align=4 words (r93.1)
//.declare V0209 (236)  rf=r size=4 type=d align=2 words (r2.0)
//.declare P17 (237)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0210 (238)  rf=r size=4 type=ud alias=V0191+0 align=2 words (r91.14)
//.declare P18 (239)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0211 (240)  rf=r size=4 type=ud alias=V0209+0 align=2 words (r2.0)
//.declare P19 (241)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P20 (243)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0213 (244)  rf=r size=8 type=d align=2 words (r1.2)
//.declare V0214 (245)  rf=r size=8 type=d alias=V0049+0 align=4 words (r2.10)
//.declare V0215 (246)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0216 (247)  rf=r size=8 type=ud alias=V0215+0 align=4 words (r3.0)
//.declare V0217 (248)  rf=r size=8 type=d alias=V0215+0 align=4 words (r3.0)
//.declare V0218 (249)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0221 (252)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0222 (253)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0223 (254)  rf=r size=8 type=d align=2 words (r7.0)
//.declare V0224 (255)  rf=r size=8 type=d alias=V0222+0 align=4 words (r6.0)
//.declare V0225 (256)  rf=r size=8 type=q align=4 words (r9.0)
//.declare V0226 (257)  rf=r size=8 type=ud alias=V0223+0 align=2 words (r7.0)
//.declare V0227 (258)  rf=r size=8 type=ud alias=V0213+0 align=2 words (r1.2)
//.declare V0228 (259)  rf=r size=8 type=ud alias=V0225+0 align=4 words (r9.0)
//.declare V0229 (260)  rf=r size=8 type=d alias=V0225+0 align=4 words (r9.0)
//.declare V0230 (261)  rf=r size=4 type=d align=32 words (r10.0)
//.declare V0231 (262)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0232 (263)  rf=r size=8 type=q align=4 words (r93.2)
//.declare V0233 (264)  rf=r size=8 type=q align=4 words (r12.0)
//.declare V0234 (265)  rf=r size=8 type=ud alias=V0233+0 align=4 words (r12.0)
//.declare V0235 (266)  rf=r size=8 type=d alias=V0233+0 align=4 words (r12.0)
//.declare V0236 (267)  rf=r size=4 type=d align=32 words (r13.0)
//.declare V0238 (269)  rf=r size=8 type=q align=4 words (r93.3)
//.declare V0239 (270)  rf=r size=128 type=d align=32 words (r98.0)
//.declare V0240 (271)  rf=r size=4 type=d align=2 words (r91.15)
//.declare V0241 (272)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0243 (274)  rf=r size=128 type=ud alias=V0241+0 align=32 words (r3.0)
//.declare V0246 (277)  rf=r size=256 type=uq align=32 words (r17.0)
//.declare V0247 (278)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0248 (279)  rf=r size=256 type=q alias=V0246+0 align=32 words (r17.0)
//.declare V0249 (280)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0252 (283)  rf=r size=256 type=uq align=32 words (r21.0)
//.declare V0253 (284)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0254 (285)  rf=r size=256 type=q alias=V0252+0 align=32 words (r21.0)
//.declare V0255 (286)  rf=r size=128 type=d align=32 words (r37.0)
//.declare V0256 (287)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0257 (288)  rf=r size=128 type=ub alias=V0247+0 align=32 words (r29.0)
//.declare V0258 (289)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0259 (290)  rf=r size=128 type=ud alias=V0258+0 align=32 words (r52.0)
//.declare V0260 (291)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0261 (292)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0262 (293)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0263 (294)  rf=r size=128 type=d align=32 words (r81.0)
//.declare V0264 (295)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0265 (296)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0266 (297)  rf=r size=128 type=ud alias=V0262+0 align=32 words (r62.0)
//.declare V0267 (298)  rf=r size=128 type=ud alias=V0265+0 align=32 words (r74.0)
//.declare  (299)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0269 (301)  rf=r size=128 type=w alias=V0253+0 align=32 words (r33.0)
//.declare V0273 (305)  rf=r size=128 type=w alias=V0255+0 align=32 words (r37.0)
//.declare V0276 (308)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0278 (310)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0280 (312)  rf=r size=128 type=f alias=V0264+0 align=32 words (r12.0)
//.declare V0281 (313)  rf=r size=128 type=f alias=V0278+0 align=32 words (r8.0)
//.declare V0283 (315)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0284 (316)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0285 (317)  rf=r size=128 type=ud alias=V0284+0 align=32 words (r58.0)
//.declare V0286 (318)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0287 (319)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0288 (320)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0289 (321)  rf=r size=128 type=d align=32 words (r23.0)
//.declare V0290 (322)  rf=r size=128 type=d align=32 words (r53.0)
//.declare V0291 (323)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0292 (324)  rf=r size=128 type=ud alias=V0288+0 align=32 words (r78.0)
//.declare V0293 (325)  rf=r size=128 type=ud alias=V0291+0 align=32 words (r10.0)
//.declare  (326)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0294 (327)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0296 (329)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0298 (331)  rf=r size=128 type=f alias=V0290+0 align=32 words (r53.0)
//.declare V0299 (332)  rf=r size=128 type=f alias=V0296+0 align=32 words (r49.0)
//.declare V0301 (334)  rf=r size=128 type=d align=32 words (r69.0)
//.declare V0302 (335)  rf=r size=128 type=ub alias=V0249+0 align=32 words (r31.0)
//.declare V0303 (336)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0304 (337)  rf=r size=128 type=ud alias=V0303+0 align=32 words (r72.0)
//.declare V0305 (338)  rf=r size=128 type=d align=32 words (r86.0)
//.declare V0306 (339)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0307 (340)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0308 (341)  rf=r size=128 type=d align=32 words (r61.0)
//.declare V0309 (342)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0310 (343)  rf=r size=128 type=d align=32 words (r51.0)
//.declare V0311 (344)  rf=r size=128 type=ud alias=V0307+0 align=32 words (r16.0)
//.declare V0312 (345)  rf=r size=128 type=ud alias=V0310+0 align=32 words (r51.0)
//.declare  (346)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0313 (347)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0315 (349)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0317 (351)  rf=r size=128 type=f alias=V0309+0 align=32 words (r78.0)
//.declare V0318 (352)  rf=r size=128 type=f alias=V0315+0 align=32 words (r74.0)
//.declare V0320 (354)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0321 (355)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0322 (356)  rf=r size=128 type=ud alias=V0321+0 align=32 words (r6.0)
//.declare V0323 (357)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0324 (358)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0325 (359)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0326 (360)  rf=r size=128 type=d align=32 words (r85.0)
//.declare V0327 (361)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0328 (362)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0329 (363)  rf=r size=128 type=ud alias=V0325+0 align=32 words (r57.0)
//.declare V0330 (364)  rf=r size=128 type=ud alias=V0328+0 align=32 words (r76.0)
//.declare  (365)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0331 (366)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0333 (368)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0335 (370)  rf=r size=128 type=f alias=V0327+0 align=32 words (r14.0)
//.declare V0336 (371)  rf=r size=128 type=f alias=V0333+0 align=32 words (r10.0)
//.declare V0340 (375)  rf=r size=256 type=uq align=32 words (r25.0)
//.declare V0341 (376)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0342 (377)  rf=r size=256 type=q alias=V0340+0 align=32 words (r25.0)
//.declare V0343 (378)  rf=r size=128 type=d align=32 words (r43.0)
//.declare V0346 (381)  rf=r size=256 type=uq align=32 words (r39.0)
//.declare V0347 (382)  rf=r size=128 type=d align=32 words (r45.0)
//.declare V0348 (383)  rf=r size=256 type=q alias=V0346+0 align=32 words (r39.0)
//.declare V0349 (384)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0350 (385)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0351 (386)  rf=r size=128 type=ub alias=V0341+0 align=32 words (r35.0)
//.declare V0352 (387)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0353 (388)  rf=r size=128 type=ud alias=V0352+0 align=32 words (r40.0)
//.declare V0354 (389)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0355 (390)  rf=r size=128 type=d align=32 words (r88.0)
//.declare V0356 (391)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0357 (392)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0358 (393)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0359 (394)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0360 (395)  rf=r size=128 type=ud alias=V0356+0 align=32 words (r82.0)
//.declare V0361 (396)  rf=r size=128 type=ud alias=V0359+0 align=32 words (r12.0)
//.declare  (397)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0363 (399)  rf=r size=128 type=w alias=V0347+0 align=32 words (r45.0)
//.declare V0367 (403)  rf=r size=128 type=w alias=V0349+0 align=32 words (r47.0)
//.declare V0370 (406)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0372 (408)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0374 (410)  rf=r size=128 type=f alias=V0358+0 align=32 words (r38.0)
//.declare V0375 (411)  rf=r size=128 type=f alias=V0372+0 align=32 words (r34.0)
//.declare V0377 (413)  rf=r size=128 type=d align=32 words (r69.0)
//.declare V0378 (414)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0379 (415)  rf=r size=128 type=ud alias=V0378+0 align=32 words (r72.0)
//.declare V0380 (416)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0381 (417)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0382 (418)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0383 (419)  rf=r size=128 type=d align=32 words (r45.0)
//.declare V0384 (420)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0385 (421)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0386 (422)  rf=r size=128 type=ud alias=V0382+0 align=32 words (r18.0)
//.declare V0387 (423)  rf=r size=128 type=ud alias=V0385+0 align=32 words (r36.0)
//.declare  (424)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0388 (425)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0390 (427)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0392 (429)  rf=r size=128 type=f alias=V0384+0 align=32 words (r58.0)
//.declare V0393 (430)  rf=r size=128 type=f alias=V0390+0 align=32 words (r54.0)
//.declare V0395 (432)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0396 (433)  rf=r size=128 type=ub alias=V0343+0 align=32 words (r43.0)
//.declare V0397 (434)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0398 (435)  rf=r size=128 type=ud alias=V0397+0 align=32 words (r8.0)
//.declare V0399 (436)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0400 (437)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0401 (438)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0402 (439)  rf=r size=128 type=d align=32 words (r65.0)
//.declare V0403 (440)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0404 (441)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0405 (442)  rf=r size=128 type=ud alias=V0401+0 align=32 words (r42.0)
//.declare V0406 (443)  rf=r size=128 type=ud alias=V0404+0 align=32 words (r56.0)
//.declare  (444)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0407 (445)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0409 (447)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0411 (449)  rf=r size=128 type=f alias=V0403+0 align=32 words (r74.0)
//.declare V0412 (450)  rf=r size=128 type=f alias=V0409+0 align=32 words (r70.0)
//.declare V0414 (452)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0415 (453)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0416 (454)  rf=r size=128 type=ud alias=V0415+0 align=32 words (r32.0)
//.declare V0417 (455)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0418 (456)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0419 (457)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0420 (458)  rf=r size=128 type=d align=32 words (r79.0)
//.declare V0421 (459)  rf=r size=128 type=d align=32 words (r83.0)
//.declare V0422 (460)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0423 (461)  rf=r size=128 type=ud alias=V0419+0 align=32 words (r62.0)
//.declare V0424 (462)  rf=r size=128 type=ud alias=V0422+0 align=32 words (r72.0)
//.declare  (463)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0425 (464)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0427 (466)  rf=r size=128 type=d align=32 words (r81.0)
//.declare V0429 (468)  rf=r size=128 type=f alias=V0421+0 align=32 words (r83.0)
//.declare V0430 (469)  rf=r size=128 type=f alias=V0427+0 align=32 words (r81.0)
//.declare P21 (470)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0431 (471)  rf=r size=128 type=ud alias=V0239+0 align=32 words (r98.0)
//.declare V0432 (472)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0433 (473)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0434 (474)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0435 (475)  rf=r size=128 type=uw alias=V0433+0 align=32 words (r5.0)
//.declare V0436 (476)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (477)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P22 (478)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0439 (481)  rf=r size=128 type=f align=32 words (r100.0)
//.declare V0440 (482)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0441 (483)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0442 (484)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0443 (485)  rf=r size=128 type=uw alias=V0441+0 align=32 words (r12.0)
//.declare V0444 (486)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (487)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P23 (488)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0447 (491)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0448 (492)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0449 (493)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0450 (494)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0451 (495)  rf=r size=128 type=uw alias=V0449+0 align=32 words (r19.0)
//.declare V0452 (496)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (497)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P24 (498)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0455 (501)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0456 (502)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0457 (503)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0458 (504)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0459 (505)  rf=r size=128 type=uw alias=V0457+0 align=32 words (r26.0)
//.declare V0460 (506)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (507)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P25 (508)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0463 (511)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0464 (512)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0465 (513)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0466 (514)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0467 (515)  rf=r size=128 type=uw alias=V0465+0 align=32 words (r33.0)
//.declare V0468 (516)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (517)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P26 (518)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P27 (519)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P28 (520)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0470 (522)  rf=r size=128 type=f align=32 words (r3.0)
//.declare P29 (523)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0471 (524)  rf=r size=128 type=d align=32 words (r111.0)
//.declare V0472 (525)  rf=r size=128 type=d alias=V0470+0 align=32 words (r3.0)
//.declare V0473 (526)  rf=r size=128 type=d align=32 words (r5.0)
//.declare P30 (527)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0474 (528)  rf=r size=128 type=ud alias=V0473+0 align=32 words (r5.0)
//.declare V0475 (529)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0476 (530)  rf=r size=128 type=ud alias=V0471+0 align=32 words (r111.0)
//.declare V0477 (531)  rf=r size=128 type=ud alias=V0475+0 align=32 words (r3.0)
//.declare V0478 (532)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0479 (533)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0480 (534)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0481 (535)  rf=r size=128 type=ud alias=V0479+0 align=32 words (r8.0)
//.declare V0482 (536)  rf=r size=128 type=ud alias=V0480+0 align=32 words (r10.0)
//.declare V0483 (537)  rf=r size=64 type=w align=32 words (r110.0)
//.declare V0484 (538)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0485 (539)  rf=r size=128 type=ud alias=V0484+0 align=32 words (r3.0)
//.declare V0487 (541)  rf=r size=8 type=q align=4 words (r1.1)
//.declare V0490 (544)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare P31 (545)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0491 (546)  rf=r size=2 type=uw align=1 words (r91.27)
//.declare V0493 (548)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare V0494 (549)  rf=r size=4 type=uw alias=V0493+0 align=2 words (r3.0)
//.declare A05 (550)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0496 (552)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (554)  rf=r size=64 type=ud align=32 words (r3.0)
//.declare  (555)  rf=r size=32 type=ud align=32 words (r4.0)
//.declare P32 (556)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P33 (557)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P34 (558)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P35 (559)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P36 (560)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P37 (561)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P38 (562)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0498 (563)  rf=r size=2 type=b align=1 words (r1.8)
//.declare V0499 (564)  rf=r size=2 type=w align=1 words (r2.0)
//.declare V0500 (565)  rf=r size=2 type=ub alias=V0498+0 align=1 words (r1.8)
//.declare P39 (566)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0501 (567)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0502 (568)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0503 (569)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0504 (570)  rf=r size=8 type=q align=4 words (r8.0)
//.declare V0505 (571)  rf=r size=8 type=d alias=V0504+0 align=4 words (r8.0)
//.declare V0506 (572)  rf=r size=8 type=d alias=V0503+0 align=4 words (r7.0)
//.declare V0509 (575)  rf=r size=8 type=uq align=32 words (r10.0)
//.declare  (576)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (577)  rf=r size=4 type=d alias=V0069+0 align=2 words (r91.2)
//.declare  (578)  rf=r size=4 type=d alias=V0207+0 align=2 words (r93.2)
//.declare  (579)  rf=r size=128 type=w alias=V0484+0 align=32 words (r3.0)
//.declare  (580)  rf=r size=8 type=f align=8 words (r12.0)
//.declare  (581)  rf=r size=8 type=ud align=8 words (r4.0)
//.declare  (582)  rf=r size=8 type=d align=8 words (r93.8)
//.declare  (583)  rf=r size=64 type=uw align=32 words (r37.0)
//.declare  (584)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (585)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare  (586)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (587)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (588)  rf=r size=2 type=w align=1 words (r40.0)
//.declare  (589)  rf=r size=8 type=df align=4 words (r7.0)
//.declare  (590)  rf=r size=4 type=ud align=32 words (r32.0)
//.declare  (591)  rf=r size=4 type=f align=2 words (r7.0)
//.declare  (592)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare  (593)  rf=r size=2 type=w align=1 words (r1.4)
//.declare  (594)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare  (595)  rf=r size=4 type=ud align=32 words (r8.0)
//.declare  (596)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (597)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (600)  rf=r size=2 type=uw align=1 words (r36.0)
//.declare  (602)  rf=r size=128 type=w alias=V0480+0 align=32 words (r10.0)
//.declare  (603)  rf=r size=4 type=ud align=2 words (r7.0)
//.declare  (604)  rf=r size=2 type=uw align=1 words (r5.0)
//.declare  (606)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (609)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (610)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (611)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (612)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (617)  rf=r size=128 type=uq alias=+0 align=32 words (r9.0)
//.declare  (618)  rf=r size=128 type=uq alias=+0 align=32 words (r11.0)
//.declare  (619)  rf=r size=128 type=uq alias=+0 align=32 words (r13.0)
//.declare  (620)  rf=r size=128 type=uq alias=+0 align=32 words (r15.0)
//.declare r0 (621)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (622)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (623)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (624)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :q       |    0x8 | r1       | inline+0x0       |
// | V0041    | :q       |    0x8 | r1+0x8   | inline+0x8       |
// | V0042    | :q       |    0x8 | r1+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r1+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r2       | cti+0x20         |
// | V0045    | :q       |    0x8 | r2+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r2+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r2+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r2+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r2+0x28  | cti+0x48         |
// | V0050    | :d       |    0x4 | r2+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r2+0x34  | cti+0x54         |
// | V0052    | :d       |    0x4 | r2+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r2+0x3C  | cti+0x5C         |
// | V0054    | :b       |    0x1 | r3       | cti+0x60         |
// | V0055    | :b       |    0x1 | r3+0x4   | cti+0x64         |
// | V0037    | :uq      |    0x8 | r3+0x8   | cti+0x68         |
// | V0038    | :uq      |    0x8 | r3+0x10  | cti+0x70         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r2:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1+0x40]  {$1} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B001: Preds:{B000},  Succs:{B002, B003}
// _main:
(W)     mov (16|M0)              r90.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r1.8<2>:b     r90.8<0;1,0>:b                   {A@1}                //  ALU pipe: int; $7
(W)     shl (1|M0)               r2.0<1>:q     r90.1<0;1,0>:ud   2:w               {$0.dst}          //  ALU pipe: int; $9
(W)     mov (1|M0)               r3.0<1>:w     r1.8<0;1,0>:ub                   {@2,$1.dst}          //  ALU pipe: int; $10
(W)     mov (8|M0)               r92.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $4
(W)     mov (1|M0)               r4.0<1>:q     r3.0<0;1,0>:w                    {I@2}                //  ALU pipe: int; $10
(W)     add (8|M0)               r92.8<1>:w    r92.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $5
(W)     add (1|M0)               r91.1<1>:q    r2.0<0;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $11
(W)     add (16|M0)              r92.16<1>:w   r92.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $6
(W)     mov (2|M0)               r91.4<1>:d    r91.2<1;1,0>:d                   {I@2}                //  ALU pipe: int; $12
(W)     mov (2|M0)               r91.0<1>:d    r2.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $2
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r91.5<0;1,0>:ud   0x1:uw              {I@2}           //  ALU pipe: int; $13
(W&f2.0) jmpi                                _0_029                                                  //  ALU pipe: int; $14
// B002: Preds:{B001},  Succs:{B007}
_0_030:
(W)     mov (1|M0)               r1.2<1>:f     r2.12<0;1,0>:ud                                       //  ALU pipe: float; $16
(W)     mov (1|M0)               r3.0<1>:df    r2.12<0;1,0>:ud                                       //  ALU pipe: long; $18
(W)     math.inv (1|M0)          r2.0<1>:f     r1.2<0;1,0>:f                    {F@1}                //  ALU pipe: math; $17
(W)     mov (1|M0)               r5.0<1>:df    0x3FF0000000000000:df                                 //  ALU pipe: long; $20
(W)     mov (1|M0)               r4.0<1>:df    r2.0<0;1,0>:f                    {M@1}                //  ALU pipe: long; $19
(W)     mov (1|M0)               r7.0<1>:df    0xBCF0000000000000:df                                 //  ALU pipe: long; $23
(W)     mad (1|M0)               r6.0<1>:df    r5.0<0;0>:df      r4.0<0;0>:df      -r3.0<0>:df      {L@2} //  ALU pipe: long; $21
(W)     mov (1|M0)               r11.0<1>:df   r91.3<0;1,0>:ud                                       //  ALU pipe: long; $26
(W)     add (1|M0)               r9.0<1>:df    r6.0<0;1,0>:df    r7.0<0;1,0>:df   {Compacted,L@2}    //  ALU pipe: long; $23
(W)     mov (1|M0)               r19.0<1>:df   r91.2<0;1,0>:ud                                       //  ALU pipe: long; $33
(W)     mad (1|M0)               r10.0<1>:df   r4.0<0;0>:df      r9.0<0;0>:df      r4.0<0>:df       {L@2} //  ALU pipe: long; $24
(W)     mov (1|M0)               r21.0<1>:df   0x41F0000000000000:df                                 //  ALU pipe: long; $34
(W)     mul (1|M0)               r12.0<1>:df   r10.0<0;1,0>:df   r11.0<0;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $27
(W)     mov (1|M0)               r29.0<1>:d    r91.4<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $44
(W)     mov (1|M0)               r13.0<2>:ud   r12.0<0;1,0>:df                  {L@1}                //  ALU pipe: int; $28
(W)     mov (1|M0)               r29.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $45
(W)     mul (1|M0)               acc0.0<1>:d   r13.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@2}              //  ALU pipe: int; $29
(W)     macl (1|M0)              r15.0<1>:d    r13.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $30
(W)     mov (1|M0)               r40.0<1>:hf   0xFFFF:hf                                             //  ALU pipe: float; $69
(W)     add (1|M0)               r16.0<1>:d    r91.3<0;1,0>:d    -r15.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $30
(W)     mov (1|M0)               r31.1<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $50
(W)     mov (1|M0)               r18.0<1>:df   r16.0<0;1,0>:ud                  {I@2}                //  ALU pipe: long; $32
(W)     mad (1|M0)               r22.0<1>:df   r19.0<0;0>:df     r21.0<0;0>:df     r18.0<0>:df      {L@1} //  ALU pipe: long; $35
(W)     mul (1|M0)               r23.0<1>:df   r10.0<0;1,0>:df   r22.0<0;1,0>:df  {Compacted,L@1}    //  ALU pipe: long; $36
(W)     mov (1|M0)               r24.0<1>:uq   r23.0<0;1,0>:df                  {L@1}                //  ALU pipe: int; $37
(W)     cmp (1|M0)    (eq)f1.0   null<1>:d     r24.1<0;1,0>:d    0:w               {I@1}             //  ALU pipe: int; $40
(W)     mov (1|M0)               r25.0<1>:d    r24.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $38
(W)     add (1|M0)               r37.0<1>:d    r24.1<0;1,0>:d    r13.0<0;1,0>:d   {Compacted}        //  ALU pipe: int; $61
(W)     mul (1|M0)               acc0.0<1>:ud  r25.0<0;1,0>:ud   r2.24<0;1,0>:uw  {I@2}              //  ALU pipe: int; $53
(W&~f1.0) sel (1|M0)             r26.0<1>:d    r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $41
(W)     macl (1|M0)              r32.0<1>:ud   r25.0<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $54
(W)     add3 (1|M0)              r27.0<1>:d    r91.3<0;0>:d      -r15.0<0;0>:d     -r26.0<0>:d      {I@2} //  ALU pipe: int; $42
(W)     mul (1|M0)               acc0.0<1>:ud  r25.0<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $54
(W)     shl (1|M0)               r28.0<1>:q    r27.0<0;1,0>:d    32:w               {I@2}            //  ALU pipe: int; $43
(W)     mach (1|M0)              r34.0<1>:d    r25.0<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r33.0<2>:ud   r32.0<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $54
(W)     add (1|M0)               r30.0<1>:q    r28.0<0;1,0>:q    r29.0<0;1,0>:q   {Compacted,I@3}    //  ALU pipe: int; $48
(W)     mov (1|M0)               r33.1<2>:d    r34.0<0;1,0>:d                   {I@3}                //  ALU pipe: int; $58
(W)     mov (1|M0)               r31.0<1>:d    r25.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $49
(W)     add (1|M0)               r35.0<1>:q    r30.0<0;1,0>:q    -r33.0<0;1,0>:q  {I@2}              //  ALU pipe: int; $59
(W)     shl (1|M0)               r38.0<1>:q    r37.0<0;1,0>:d    32:w                                //  ALU pipe: int; $62
(W)     mov (2|M0)               r36.0<1>:d    r35.0<1;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $60
(W)     add (1|M0)               r39.0<1>:q    r38.0<0;1,0>:q    r31.0<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $63
(W)     cmp (32|M0)   (ge)f3.0   null<1>:ud    r36.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $64
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r36.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $65
(W&~f3.0) cmp (32|M0) (gt)f3.0   null<1>:ud    r36.1<0;1,0>:ud   0x0:uw                              //  ALU pipe: int; $67
(W&f3.0) sel (1|M0)              r41.0<1>:d    r40.0<0;1,0>:w    0:w               {F@1}             //  ALU pipe: int; $69
(W)     mov (1|M0)               r42.0<1>:q    r41.0<0;1,0>:d                   {I@1}                //  ALU pipe: int; $70
(W)     add (1|M0)               r91.3<1>:q    r39.0<0;1,0>:q    -r42.0<0;1,0>:q  {I@1}              //  ALU pipe: int; $71
(W)     jmpi                                 _0_031                                                  // $72
// B003: Preds:{B001},  Succs:{B004, B005}
_0_029:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $74
(W&~f0.0) jmpi                               _0_032                                                  //  ALU pipe: int; $75
// B004: Preds:{B003},  Succs:{B006}
_0_033:
(W)     mov (1|M0)               r91.8<1>:d    -1:w                                                  //  ALU pipe: int; $77
(W)     jmpi                                 _0_034                                                  // $78
// B005: Preds:{B003},  Succs:{B006}
_0_032:
(W)     mov (1|M0)               r1.2<2>:d     r91.1<0;1,0>:q                                        //  ALU pipe: int; $80
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $81
(W)     mov (1|M0)               r2.0<1>:f     r2.12<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $82
(W)     mov (1|M0)               r7.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $87
(W)     math.inv (1|M0)          r6.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $86
(W)     mov (1|M0)               r5.0<1>:f     r1.2<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $85
(W)     mad (1|M0)               r8.0<1>:f     r6.0<0;0>:f       r7.0<0;0>:f       r6.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $87
(W)     mov (1|M0)               r3.0<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $83
(W)     mov (1|M0)               r10.0<1>:ud   r5.0<0;1,0>:f                    {F@2}                //  ALU pipe: int; $89
(W)     mul (1|M0)               r9.0<1>:f     r5.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $88
(W)     add (1|M0)               r4.0<1>:d     r2.12<0;1,0>:d    -r3.0<0;1,0>:d   {I@2}              //  ALU pipe: int; $84
(W)     add (1|M0)               r4.1<1>:d     r1.2<0;1,0>:d     -r10.0<0;1,0>:d  {I@2}              //  ALU pipe: int; $90
(W)     mov (1|M0)               r11.0<1>:ud   r9.0<0;1,0>:f                    {F@1}                //  ALU pipe: int; $91
(W)     mov (1|M0)               r12.0<1>:f    r4.0<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $92
(W)     mov (1|M0)               r12.1<1>:f    r4.1<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $92
(W)     mov (1|M0)               r13.0<1>:f    r11.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $94
(W)     mad (1|M0)               r14.0<1>:f    r5.0<0;0>:f       r13.0<0;0>:f      -r2.0<0>:f       {F@1} //  ALU pipe: float; $96
(W)     mad (1|M0)               r15.0<1>:f    r12.1<0;0>:f      r13.0<0;0>:f      -r12.0<0>:f       //  ALU pipe: float; $98
(W)     add (1|M0)               r16.0<1>:f    r14.0<0;1,0>:f    r15.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $99
(W)     mul (1|M0)               r17.0<1>:f    r8.0<0;1,0>:f     r16.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $100
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $101
(W)     mov (1|M0)               r18.0<1>:ud   r17.0<0;1,0>:f                   {A@1}                //  ALU pipe: int; $102
(W)     add (1|M0)               r19.0<1>:d    r18.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $103
(W)     mul (1|M0)               acc0.0<1>:d   r19.0<0;1,0>:d    r2.24<0;1,0>:uw  {I@1}              //  ALU pipe: int; $104
(W)     macl (1|M0)              r20.0<1>:d    r19.0<0;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $105
(W)     add (1|M0)               r21.0<1>:d    r1.2<0;1,0>:d     -r20.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $105
(W)     cmp (1|M0)    (ge)f2.0   r22.0<1>:ud   r21.0<0;1,0>:ud   r2.12<0;1,0>:ud  {I@1}              //  ALU pipe: int; $106
(W)     add3 (1|M0)              r91.8<1>:d    r18.0<0;0>:d      r11.0<0;0>:d      -r22.0<0>:d      {I@1} //  ALU pipe: int; $107
// B006: Preds:{B005, B004},  Succs:{B007}
_0_034:
(W)     mov (1|M0)               r91.3<1>:q    r91.8<0;1,0>:ud                  {I@1}                //  ALU pipe: int; $109
// B007: Preds:{B006, B002},  Succs:{B008, B009}
_0_031:
(W)     mov (2|M0)               r91.9<1>:d    r91.6<1;1,0>:d                   {I@1}                //  ALU pipe: int; $111
        mov (32|M0)              r94.0<1>:d    r92.0<1;1,0>:uw                                       //  ALU pipe: int; $131
(W)     mul (1|M0)               acc0.0<1>:ud  r91.9<0;1,0>:ud   r2.24<0;1,0>:uw  {I@2}              //  ALU pipe: int; $112
(W)     macl (1|M0)              r93.0<1>:ud   r91.9<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $113
(W)     mul (1|M0)               acc0.0<1>:ud  r91.9<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $113
(W)     mach (1|M0)              r2.0<1>:d     r91.9<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r2.12<0;1,0>:ud   r91.20<0;1,0>:uw                    //  ALU pipe: int; $116
(W)     macl (1|M0)              r3.0<1>:d     r2.12<0;1,0>:ud   r91.10<0;1,0>:d                     //  ALU pipe: int; $118
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $119
(W)     macl (1|M0)              r4.0<1>:ud    r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; $120
(W)     mul (1|M0)               acc0.0<1>:ud  r2.12<0;1,0>:ud   r2.26<0;1,0>:uw                     //  ALU pipe: int; $120
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r91.4<0;1,0>:ud   r4.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $132
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r91.4<0;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $126
(W)     mach (1|M0)              r5.0<1>:d     r2.12<0;1,0>:ud   r2.13<0;1,0>:ud                     //  ALU pipe: int; 
(W)     add (1|M0)               r91.11<1>:d   r2.0<0;1,0>:d     r3.0<0;1,0>:d                       //  ALU pipe: int; $118
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r91.5<0;1,0>:d    r5.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $133
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r91.5<0;1,0>:d    r5.0<0;1,0>:d                       //  ALU pipe: int; $127
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:ud    r91.5<0;1,0>:ud   r5.0<0;1,0>:ud                      //  ALU pipe: int; $135
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r91.5<0;1,0>:ud   r5.0<0;1,0>:ud                      //  ALU pipe: int; $129
(W&f1.0) jmpi                                _0_035                                                  //  ALU pipe: int; $137
// B008: Preds:{B007},  Succs:{B020}
_0_036:
        mov (32|M0)              r96.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $141
(W)     mov (1|M0)               r91.12<1>:d   0:w                                                   //  ALU pipe: int; $139
(W)     mov (1|M0)               r91.26<1>:w   0:w                                                   //  ALU pipe: int; $140
(W)     jmpi                                 _0_037                                                  // $142
// B009: Preds:{B007},  Succs:{B010, B011}
_0_035:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r91.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $144
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r91.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $145
(W&~f3.0) jmpi                               _0_038                                                  //  ALU pipe: int; $147
// B010: Preds:{B009},  Succs:{B012}
_0_039:
(W)     mov (2|M0)               r93.8<1>:d    0:w                                                   //  ALU pipe: int; $149
(W)     mov (1|M0)               r91.14<1>:d   r2.12<0;1,0>:d                                        //  ALU pipe: int; $151
(W)     jmpi                                 _0_040                                                  // $152
// B011: Preds:{B009},  Succs:{B012}
_0_038:
(W)     mul (1|M0)               acc0.0<1>:ud  r91.9<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $155
(W)     mach (1|M0)              r2.0<1>:d     r91.9<0;1,0>:ud   0xC:ud                              //  ALU pipe: int; 
(W)     mul (1|M0)               r1.2<2>:ud    r91.9<0;1,0>:ud   0xC:uw                              //  ALU pipe: int; $154
(W)     mov (1|M0)               r1.3<2>:d     r2.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $159
(W)     add (1|M0)               r4.0<1>:q     r1.1<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $160
(W)     load.ugm.d32x3t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$2} // ex_desc:0x0; desc:0x210A580 // $162
(W)     mov (1|M0)               r93.8<1>:d    r5.0<0;1,0>:d                    {$2.dst}             //  ALU pipe: int; $163
(W)     mov (1|M0)               r93.9<1>:d    r5.1<0;1,0>:d                                         //  ALU pipe: int; $164
(W)     mov (1|M0)               r91.14<1>:d   r5.2<0;1,0>:d                                         //  ALU pipe: int; $165
// B012: Preds:{B011, B010},  Succs:{B013, B014}
_0_040:
(W)     cmp (32|M0)   (gt)f2.0   null<1>:ud    r93.9<0;1,0>:ud   r2.12<0;1,0>:ud  {I@2}              //  ALU pipe: int; $167
(W&~f2.0) cmp (32|M0) (ge)f2.0   null<1>:ud    r93.8<0;1,0>:ud   r2.14<0;1,0>:ud                     //  ALU pipe: int; $168
(W&~f2.0) jmpi                               _0_041                                                  //  ALU pipe: int; $170
// B013: Preds:{B012},  Succs:{B020}
_0_042:
        mov (32|M0)              r96.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $174
(W)     mov (1|M0)               r91.12<1>:d   0:w                                                   //  ALU pipe: int; $172
(W)     mov (1|M0)               r91.26<1>:w   0:w                                                   //  ALU pipe: int; $173
(W)     jmpi                                 _0_037                                                  // $175
// B014: Preds:{B012},  Succs:{B015, B016}
_0_041:
(W)     mov (1|M0)               r1.2<1>:d     r93.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $177
(W)     mov (1|M0)               r1.3<1>:d     r91.11<0;1,0>:d                                       //  ALU pipe: int; $178
(W)     cmp (32|M0)   (le)f1.0   null<1>:ud    r91.14<0;1,0>:ud  r2.12<0;1,0>:ud  {I@7}              //  ALU pipe: int; $184
(W)     add (1|M0)               r93.1<1>:q    r91.1<0;1,0>:q    -r1.1<0;1,0>:q   {I@2}              //  ALU pipe: int; $181
(W)     add (1|M0)               r2.0<1>:d     r2.12<0;1,0>:d    -r93.9<0;1,0>:d                     //  ALU pipe: int; $183
(W)     cmp (32|M0)   (gt)f3.0   null<1>:ud    r91.14<0;1,0>:ud  r93.2<0;1,0>:ud  {I@2}              //  ALU pipe: int; $187
(W&f1.0) cmp (32|M0)  (le)f1.0   null<1>:ud    r91.14<0;1,0>:ud  r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $185
(W)     mov (1|M0)               r3.0<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $188
(W)     and (1|M0)               f2.0<1>:ud    f1.0<0;1,0>:ud    r3.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $188
(W&f2.0) jmpi                                _0_043                                                  //  ALU pipe: int; $189
// B015: Preds:{B014},  Succs:{B020}
_0_044:
        mov (32|M0)              r96.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $193
(W)     mov (1|M0)               r1.4<1>:w     1:w                                                   //  ALU pipe: int; $191
(W)     mov (1|M0)               r91.12<1>:d   0:w                                                   //  ALU pipe: int; $192
(W&f1.0) sel (1|M0)              r91.26<1>:w   r1.4<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $191
(W)     jmpi                                 _0_037                                                  // $194
// B016: Preds:{B014},  Succs:{B017}
_0_043:
(W)     mul (1|M0)               acc0.0<1>:ud  r93.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $197
(W)     macl (1|M0)              r2.0<1>:ud    r93.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $198
(W)     mul (1|M0)               acc0.0<1>:ud  r93.8<0;1,0>:ud   r2.24<0;1,0>:uw                     //  ALU pipe: int; $198
(W)     mach (1|M0)              r4.0<1>:d     r93.8<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mov (1|M0)               r3.0<2>:f     r2.0<0;1,0>:f                    {I@3}                //  ALU pipe: float; $198
(W)     mov (1|M0)               r3.1<2>:d     r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $202
(W)     mov (2|M0)               r1.2<1>:d     r2.10<1;1,0>:d                                        //  ALU pipe: int; $196
(W)     add (1|M0)               r5.0<1>:q     r3.0<0;1,0>:q     r93.9<0;1,0>:ud  {A@1}              //  ALU pipe: int; $204
        shl (32|M0)              r98.0<1>:d    r94.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $221
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r93.1<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $205
        mov (32|M0)              r96.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $223
(W)     mov (2|M0)               r7.0<1>:f     r6.0<1;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $206
(W)     mul (1|M0)               r12.0<2>:ud   r91.9<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $214
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw   {F@1}              //  ALU pipe: int; $207
(W)     macl (1|M0)              r8.0<1>:ud    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $208
(W)     mul (1|M0)               acc0.0<1>:ud  r7.0<0;1,0>:ud    r1.4<0;1,0>:uw                      //  ALU pipe: int; $208
(W)     mach (1|M0)              r10.0<1>:d    r7.0<0;1,0>:ud    r1.2<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r7.0<0;1,0>:ud    r1.6<0;1,0>:uw                      //  ALU pipe: int; $209
(W)     macl (1|M0)              r11.0<1>:d    r7.0<0;1,0>:ud    r1.3<0;1,0>:d                       //  ALU pipe: int; $210
(W)     mul (1|M0)               acc0.0<1>:d   r1.2<0;1,0>:ud    r7.2<0;1,0>:uw                      //  ALU pipe: int; $211
(W)     add (1|M0)               r10.0<1>:d    r10.0<0;1,0>:d    r11.0<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $210
(W)     macl (1|M0)              r11.0<1>:d    r1.2<0;1,0>:ud    r7.1<0;1,0>:d                       //  ALU pipe: int; $212
(W)     mul (1|M0)               acc0.0<1>:ud  r91.9<0;1,0>:ud   0x3000:uw                           //  ALU pipe: int; $215
(W)     mach (1|M0)              r13.0<1>:d    r91.9<0;1,0>:ud   0x3000:ud                           //  ALU pipe: int; 
(W)     mov (1|M0)               r9.0<2>:f     r8.0<0;1,0>:f                                         //  ALU pipe: float; $208
(W)     add (1|M0)               r9.1<2>:d     r10.0<0;1,0>:d    r11.0<0;1,0>:d   {I@3}              //  ALU pipe: int; $212
(W)     mov (1|M0)               r12.1<2>:d    r13.0<0;1,0>:d                   {I@2}                //  ALU pipe: int; $219
(W)     mov (1|M0)               r91.15<1>:d   32767:w                                               //  ALU pipe: int; $222
(W)     add (1|M0)               r93.2<1>:q    r9.0<0;1,0>:q     r1.0<0;1,0>:q    {Compacted,A@1}    //  ALU pipe: int; $213
(W)     add (1|M0)               r93.3<1>:q    r12.0<0;1,0>:q    r1.2<0;1,0>:q    {I@3}              //  ALU pipe: int; $220
// B017: [inDivergent],  Preds:{B019, B016},  Succs:{B018, B019}
_0_045:
        shl (32|M0)              r3.0<1>:d     r98.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $225
        mov (16|M0)              r5.0<2>:ud    r3.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $227
        mov (16|M16)             r7.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $227
        add (16|M0)              r9.0<1>:q     r93.2<0;1,0>:q    r5.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $227
        add (16|M16)             r11.0<1>:q    r93.2<0;1,0>:q    r7.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $227
        mov (16|M0)              r17.0<1>:uq   r9.0<1;1,0>:uq                   {Compacted,I@2}      //  ALU pipe: int; $228
        mov (16|M16)             r19.0<1>:uq   r11.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $228
        load.ugm.d32.a64 (32|M0)  r29:2         [r17:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200580 // $229
        add (16|M0)              r13.0<1>:q    r93.3<0;1,0>:q    r5.0<2;1,0>:ud                      //  ALU pipe: int; $231
        add (16|M16)             r15.0<1>:q    r93.3<0;1,0>:q    r7.0<2;1,0>:ud                      //  ALU pipe: int; $231
        mov (16|M0)              r21.0<1>:uq   r13.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $232
        mov (16|M16)             r23.0<1>:uq   r15.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $232
        load.ugm.d32.a64 (32|M0)  r31:2         [r17:4+0x4]        {$4} // ex_desc:0x4000; desc:0x8200580 // $230
        load.ugm.d32.a64 (32|M0)  r33:2         [r21:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $233
        add (16|M0)              r25.0<1>:q    r9.0<1;1,0>:q     8:w               {Compacted}       //  ALU pipe: int; $287
        add (16|M16)             r27.0<1>:q    r11.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $287
        load.ugm.d32.a64 (32|M0)  r35:2         [r25:4]            {I@1,$6} // ex_desc:0x0; desc:0x8200580 // $289
        load.ugm.d32.a64 (32|M0)  r37:2         [r21:4+0x4]        {$7} // ex_desc:0x4000; desc:0x8200580 // $234
        add (16|M0)              r39.0<1>:q    r13.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $291
        add (16|M16)             r41.0<1>:q    r15.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $291
        load.ugm.d32.a64 (32|M0)  r43:2         [r25:4+0x4]        {$8} // ex_desc:0x4000; desc:0x8200580 // $290
        load.ugm.d32.a64 (32|M0)  r45:2         [r39:4]            {I@1,$9} // ex_desc:0x0; desc:0x8200580 // $293
        load.ugm.d32.a64 (32|M0)  r47:2         [r39:4+0x4]        {$10} // ex_desc:0x4000; desc:0x8200580 // $294
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r98.0<1;1,0>:ud   0x1700:uw                           //  ALU pipe: int; $347
        shl (32|M0)              r49.0<1>:d    r29.1<4;1,0>:ub   8:w               {$3.dst}          //  ALU pipe: int; $235
        mov (32|M0)              r52.0<1>:ud   r29.0<4;1,0>:ub                                       //  ALU pipe: int; $236
        shl (32|M0)              r55.0<1>:d    r29.3<4;1,0>:ub   8:w                                 //  ALU pipe: int; $251
        or (32|M0)               r60.0<1>:d    r49.0<1;1,0>:d    r52.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $237
        mov (32|M0)              r58.0<1>:ud   r29.2<4;1,0>:ub                                       //  ALU pipe: int; $252
        bfn.((s0|s1)&s2) (32|M0)   r62.0<1>:ud  r49.0<1;0>:ud    r52.0<1;0>:ud     r91.15<0>:ud      //  ALU pipe: int; $239
        shl (32|M0)              r66.0<1>:d    r60.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $238
        shl (32|M0)              r69.0<1>:d    r31.1<4;1,0>:ub   8:w               {$4.dst}          //  ALU pipe: int; $263
        or (32|M0)               r64.0<1>:d    r55.0<1;1,0>:d    r58.0<1;1,0>:d   {Compacted,I@4}    //  ALU pipe: int; $253
        cmp (32|M0)   (gt)f2.0   r74.0<1>:ud   r62.0<1;1,0>:ud   0x7F80:uw              {I@4}        //  ALU pipe: int; $241
        mov (32|M0)              r72.0<1>:ud   r31.0<4;1,0>:ub                                       //  ALU pipe: int; $264
        mov (32|M0)              r76.0<1>:d    r33.0<2;1,0>:uw                  {$5.dst}             //  ALU pipe: int; $247
        bfn.((s0|s1)&s2) (32|M0)   r78.0<1>:ud  r55.0<1;0>:ud    r58.0<1;0>:ud     r91.15<0>:ud      //  ALU pipe: int; $255
        or (32|M0)               r81.0<1>:d    r66.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $240
        shl (32|M0)              r84.0<1>:d    r64.0<1;1,0>:d    16:w               {Compacted,I@6}  //  ALU pipe: int; $254
        shl (32|M0)              r3.0<1>:d     r31.3<4;1,0>:ub   8:w                                 //  ALU pipe: int; $275
        or (32|M0)               r86.0<1>:d    r69.0<1;1,0>:d    r72.0<1;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $265
        shl (32|M0)              r8.0<1>:d     r76.0<1;1,0>:d    16:w               {Compacted,I@6}  //  ALU pipe: int; $248
        cmp (32|M0)   (gt)f3.0   r10.0<1>:ud   r78.0<1;1,0>:ud   0x7F80:uw              {I@6}        //  ALU pipe: int; $257
        mov (32|M0)              r6.0<1>:ud    r31.2<4;1,0>:ub                                       //  ALU pipe: int; $276
        mov (32|M0)              r14.0<1>:d    r33.1<2;1,0>:uw                                       //  ALU pipe: int; $259
        bfn.((s0|s1)&s2) (32|M0)   r16.0<1>:ud  r69.0<1;0>:ud    r72.0<1;0>:ud     r91.15<0>:ud      //  ALU pipe: int; $267
        bfn.(s0&s1|~s0&s2) (32|M0)   r12.0<1>:ud  r74.0<1;0>:ud  r81.0<1;0>:ud     r66.0<1>:ud      {I@7} //  ALU pipe: int; $242
        or (32|M0)               r23.0<1>:d    r84.0<1;1,0>:d    4194304:d               {@7,$7.src} //  ALU pipe: int; $256
        shl (32|M0)              r26.0<1>:d    r86.0<1;1,0>:d    16:w               {Compacted,@7,$8.src} //  ALU pipe: int; $266
        or (32|M0)               r28.0<1>:d    r3.0<1;1,0>:d     r6.0<1;1,0>:d    {Compacted,I@6}    //  ALU pipe: int; $277
        shl (32|M0)              r31.0<1>:d    r35.1<4;1,0>:ub   8:w               {$6.dst}          //  ALU pipe: int; $295
        shl (32|M0)              r49.0<1>:d    r14.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $260
        cmp (32|M0)   (gt)f2.0   r51.0<1>:ud   r16.0<1;1,0>:ud   0x7F80:uw              {I@7}        //  ALU pipe: int; $269
        mul (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    r8.0<1;1,0>:f    {Compacted,I@7}    //  ALU pipe: float; $249
        mov (32|M0)              r40.0<1>:ud   r35.0<4;1,0>:ub                  {$10.src}            //  ALU pipe: int; $296
        mov (32|M0)              r55.0<1>:d    r37.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $271
        bfn.((s0|s1)&s2) (32|M0)   r57.0<1>:ud  r3.0<1;0>:ud     r6.0<1;0>:ud      r91.15<0>:ud      //  ALU pipe: int; $279
        bfn.(s0&s1|~s0&s2) (32|M0)   r53.0<1>:ud  r10.0<1;0>:ud  r23.0<1;0>:ud     r84.0<1>:ud      {I@7} //  ALU pipe: int; $258
        or (32|M0)               r61.0<1>:d    r26.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $268
        shl (32|M0)              r64.0<1>:d    r28.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $278
        add (32|M0)              acc0.0<1>:f   r96.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $250
        shl (32|M0)              r69.0<1>:d    r35.3<4;1,0>:ub   8:w                                 //  ALU pipe: int; $311
        or (32|M0)               r66.0<1>:d    r31.0<1;1,0>:d    r40.0<1;1,0>:d   {Compacted,I@7}    //  ALU pipe: int; $297
        shl (32|M0)              r74.0<1>:d    r55.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $272
        cmp (32|M0)   (gt)f3.0   r76.0<1>:ud   r57.0<1;1,0>:ud   0x7F80:uw              {I@7}        //  ALU pipe: int; $281
        mul (32|M0)              acc2.0<1>:f   r53.0<1;1,0>:f    r49.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $261
        mov (32|M0)              r72.0<1>:ud   r35.2<4;1,0>:ub                                       //  ALU pipe: int; $312
        mov (32|M0)              r80.0<1>:d    r37.1<2;1,0>:uw                                       //  ALU pipe: int; $283
        bfn.((s0|s1)&s2) (32|M0)   r82.0<1>:ud  r31.0<1;0>:ud    r40.0<1;0>:ud     r91.15<0>:ud      //  ALU pipe: int; $299
        bfn.(s0&s1|~s0&s2) (32|M0)   r78.0<1>:ud  r51.0<1;0>:ud  r61.0<1;0>:ud     r26.0<1>:ud      {I@7} //  ALU pipe: int; $270
        or (32|M0)               r85.0<1>:d    r64.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $280
        shl (32|M0)              r88.0<1>:d    r66.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $298
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $262
        shl (32|M0)              r5.0<1>:d     r43.1<4;1,0>:ub   8:w               {$8.dst}          //  ALU pipe: int; $323
        or (32|M0)               r3.0<1>:d     r69.0<1;1,0>:d    r72.0<1;1,0>:d   {Compacted,I@7}    //  ALU pipe: int; $313
        shl (32|M0)              r10.0<1>:d    r80.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $284
        cmp (32|M0)   (gt)f2.0   r12.0<1>:ud   r82.0<1;1,0>:ud   0x7F80:uw              {A@4}        //  ALU pipe: int; $301
        mul (32|M0)              acc2.0<1>:f   r78.0<1;1,0>:f    r74.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $273
        mov (32|M0)              r16.0<1>:d    r45.0<2;1,0>:uw                  {$9.dst}             //  ALU pipe: int; $307
        mov (32|M0)              r8.0<1>:ud    r43.0<4;1,0>:ub                                       //  ALU pipe: int; $324
        bfn.((s0|s1)&s2) (32|M0)   r18.0<1>:ud  r69.0<1;0>:ud    r72.0<1;0>:ud     r91.15<0>:ud      //  ALU pipe: int; $315
        bfn.(s0&s1|~s0&s2) (32|M0)   r14.0<1>:ud  r76.0<1;0>:ud  r85.0<1;0>:ud     r64.0<1>:ud      {I@7} //  ALU pipe: int; $282
        or (32|M0)               r21.0<1>:d    r88.0<1;1,0>:d    4194304:d               {I@7}       //  ALU pipe: int; $300
        shl (32|M0)              r24.0<1>:d    r3.0<1;1,0>:d     16:w               {Compacted,I@7}  //  ALU pipe: int; $314
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $274
        shl (32|M0)              r29.0<1>:d    r43.3<4;1,0>:ub   8:w                                 //  ALU pipe: int; $335
        mov (32|M0)              r32.0<1>:ud   r43.2<4;1,0>:ub                                       //  ALU pipe: int; $336
        shl (32|M0)              r34.0<1>:d    r16.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $308
        or (32|M0)               r26.0<1>:d    r5.0<1;1,0>:d     r8.0<1;1,0>:d    {Compacted,I@7}    //  ALU pipe: int; $325
        cmp (32|M0)   (gt)f3.0   r36.0<1>:ud   r18.0<1;1,0>:ud   0x7F80:uw              {I@7}        //  ALU pipe: int; $317
        mul (32|M0)              acc2.0<1>:f   r14.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $285
        mov (32|M0)              r40.0<1>:d    r45.1<2;1,0>:uw                                       //  ALU pipe: int; $319
        bfn.(s0&s1|~s0&s2) (32|M0)   r38.0<1>:ud  r12.0<1;0>:ud  r21.0<1;0>:ud     r88.0<1>:ud      {I@7} //  ALU pipe: int; $302
        bfn.((s0|s1)&s2) (32|M0)   r42.0<1>:ud  r5.0<1;0>:ud     r8.0<1;0>:ud      r91.15<0>:ud      //  ALU pipe: int; $327
        shl (32|M0)              r50.0<1>:d    r26.0<1;1,0>:d    16:w               {Compacted,A@5}  //  ALU pipe: int; $326
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $286
        or (32|M0)               r45.0<1>:d    r24.0<1;1,0>:d    4194304:d                           //  ALU pipe: int; $316
        or (32|M0)               r52.0<1>:d    r29.0<1;1,0>:d    r32.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $337
        shl (32|M0)              r54.0<1>:d    r40.0<1;1,0>:d    16:w               {Compacted,I@6}  //  ALU pipe: int; $320
        cmp (32|M0)   (gt)f2.0   r56.0<1>:ud   r42.0<1;1,0>:ud   0x7F80:uw              {I@5}        //  ALU pipe: int; $329
        mul (32|M0)              acc2.0<1>:f   r38.0<1;1,0>:f    r34.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $309
        mov (32|M0)              r60.0<1>:d    r47.0<2;1,0>:uw                  {$10.dst}            //  ALU pipe: int; $331
        bfn.((s0|s1)&s2) (32|M0)   r62.0<1>:ud  r29.0<1;0>:ud    r32.0<1;0>:ud     r91.15<0>:ud      //  ALU pipe: int; $339
        bfn.(s0&s1|~s0&s2) (32|M0)   r58.0<1>:ud  r36.0<1;0>:ud  r45.0<1;0>:ud     r24.0<1>:ud      {I@6} //  ALU pipe: int; $318
        or (32|M0)               r65.0<1>:d    r50.0<1;1,0>:d    4194304:d                           //  ALU pipe: int; $328
        shl (32|M0)              r68.0<1>:d    r52.0<1;1,0>:d    16:w               {Compacted,I@7}  //  ALU pipe: int; $338
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $310
        shl (32|M0)              r70.0<1>:d    r60.0<1;1,0>:d    16:w               {Compacted,I@5}  //  ALU pipe: int; $332
        cmp (32|M0)   (gt)f3.0   r72.0<1>:ud   r62.0<1;1,0>:ud   0x7F80:uw              {I@5}        //  ALU pipe: int; $341
        mul (32|M0)              acc2.0<1>:f   r58.0<1;1,0>:f    r54.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $321
        mov (32|M0)              r76.0<1>:d    r47.1<2;1,0>:uw                                       //  ALU pipe: int; $343
        bfn.(s0&s1|~s0&s2) (32|M0)   r74.0<1>:ud  r56.0<1;0>:ud  r65.0<1;0>:ud     r50.0<1>:ud      {A@5} //  ALU pipe: int; $330
        or (32|M0)               r79.0<1>:d    r68.0<1;1,0>:d    4194304:d               {I@5}       //  ALU pipe: int; $340
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $322
        shl (32|M0)              r81.0<1>:d    r76.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $344
        mul (32|M0)              acc2.0<1>:f   r74.0<1;1,0>:f    r70.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $333
        bfn.(s0&s1|~s0&s2) (32|M0)   r83.0<1>:ud  r72.0<1;0>:ud  r79.0<1;0>:ud     r68.0<1>:ud      {I@2} //  ALU pipe: int; $342
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $334
        mul (32|M0)              acc2.0<1>:f   r83.0<1;1,0>:f    r81.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $345
        add (32|M0)              r96.0<1>:f    acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $346
(f1.0)  goto (32|M0)                         _0_046            _0_046                                //  ALU pipe: int; $348
// B018: [inDivergent],  Preds:{B017},  Succs:{B020}
_0_047:
(W)     mov (1|M0)               r91.12<1>:d   -1:w                                                  //  ALU pipe: int; $350
(W)     mov (1|M0)               r91.26<1>:hf  0x1:hf                                                //  ALU pipe: float; $351
        goto (32|M0)                         _0_046            _0_037                                // $352
// B019: [inDivergent],  Preds:{B017},  Succs:{B017}
_0_046:
        join (32|M0)                         _0_037                                                  // 
L4400:
        add (32|M0)              r98.0<1>:d    r98.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $354
(W)     jmpi                                 _0_045                                                  // $355
// B020: Preds:{B018, B015, B013, B008},  Succs:{B021, B025}
_0_037:
        join (32|M0)                         L4440                                                   // 
L4440:
        add (32|M0)              r3.0<1>:d     r94.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $357
        and (32|M0)              r5.0<1>:d     r3.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $358
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $359
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $360
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0x1800:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0188(r96.0:f); $361
        add (32|M0)              r10.0<1>:d    r94.0<1;1,0>:d    2:w               {Compacted,F@7}   //  ALU pipe: int; $370
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@2}                //  ALU pipe: int; $362
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $363
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0x1800:uw                           //  ALU pipe: int; src1 is addr of V0188(r96.0:f); $364
        and (32|M0)   (eq)f1.0   null<1>:d     r94.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $366
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $371
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $365
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $372
(f1.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $368
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $373
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0x1900:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0439(r100.0:f); $374
        add (32|M0)              r100.0<1>:f   r96.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $369
        add (32|M0)              r17.0<1>:d    r94.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $383
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $375
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $376
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0x1900:uw                           //  ALU pipe: int; src1 is addr of V0439(r100.0:f); $377
        and (32|M0)   (eq)f3.0   null<1>:d     r94.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $379
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $384
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $378
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $385
(f3.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $381
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $386
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0x1980:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0447(r102.0:f); $387
        add (32|M0)              r102.0<1>:f   r100.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $382
        add (32|M0)              r24.0<1>:d    r94.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $396
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $388
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $389
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0x1980:uw                           //  ALU pipe: int; src1 is addr of V0447(r102.0:f); $390
        and (32|M0)   (eq)f2.0   null<1>:d     r94.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $392
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $397
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $391
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $398
(f2.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $394
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $399
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0x1A00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0455(r104.0:f); $400
        add (32|M0)              r104.0<1>:f   r102.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $395
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $401
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $402
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0x1A00:uw                           //  ALU pipe: int; src1 is addr of V0455(r104.0:f); $403
        add (32|M0)              r31.0<1>:d    r94.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $409
        and (32|M0)   (eq)f1.0   null<1>:d     r94.0<1;1,0>:d    15:w                                //  ALU pipe: int; $405
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $404
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@3}  //  ALU pipe: int; $410
(f1.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $407
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@1}           //  ALU pipe: int; $411
        cmp (32|M0)   (eq)f1.0   null<2>:w     r92.0<1;1,0>:w    0:w               {F@1}             //  ALU pipe: int; $418
(W)     mov (1|M0)               r36.0<1>:hf   0x1:hf                                                //  ALU pipe: float; $419
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $412
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0x1A80:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0463(r106.0:f); $413
        add (32|M0)              r106.0<1>:f   r104.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $408
(f0.0)  sel (32|M0)              r37.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw              {F@2}           //  ALU pipe: int; $419
(f1.0)  sel (32|M0)              r38.0<1>:uw   r36.0<0;1,0>:uw   0x0:uw                              //  ALU pipe: int; $419
        mov (16|M0)              r108.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $414
        and (32|M0)   (ne)f3.0   null<2>:uw    r37.0<1;1,0>:uw   r38.0<1;1,0>:uw  {I@2}              //  ALU pipe: int; $419
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $415
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0x1A80:uw                           //  ALU pipe: int; src1 is addr of V0463(r106.0:f); $416
        mov (16|M16)             r109.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $417
(~f3.0) goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $420
// B021: [inDivergent],  Preds:{B020},  Succs:{B022, B023}
_0_049:
        cmp (32|M0)   (eq)f2.0   null<2>:w     r92.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $422
(f2.0)  sel (32|M0)              acc0.0<1>:f   r108.0<1;1,0>:f   0x80000000:f               {I@3}    //  ALU pipe: float; $423
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r91.12<0;1,0>:d   0:w                                 //  ALU pipe: int; $425
        add (32|M0)              r3.0<1>:f     r106.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $424
(f1.0)  sel (32|M0)              r111.0<1>:d   r3.0<1;1,0>:d     2143289344:d               {F@1}    //  ALU pipe: int; $426
        and (32|M0)              r5.0<1>:d     r111.0<1;1,0>:d   2147483647:d               {I@1}    //  ALU pipe: int; $427
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r5.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $428
(f3.0)  goto (32|M0)                         _0_050            _0_050                                //  ALU pipe: int; $429
// B022: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_051:
        shr (32|M0)              r3.0<1>:ud    r111.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $431
        and (32|M0)              r6.0<1>:d     r3.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $432
        add3 (32|M0)             r8.0<1>:d     r111.0<1;0>:d     r6.0<1;0>:d       32767:w               {I@1} //  ALU pipe: int; $433
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $434
        mov (32|M0)              r110.0<1>:w   r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $435
        goto (32|M0)                         _0_050            _0_052                                // $436
// B023: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_050:
        join (32|M0)                         _0_052                                                  // 
L5560:
        shr (32|M0)              r3.0<1>:ud    r111.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $438
        or (32|M0)               r110.0<1>:w   r3.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $440
// B024: [inDivergent],  Preds:{B023, B022},  Succs:{B025}
_0_052:
        join (32|M0)                         _0_048                                                  // 
L5608:
(W)     mov (1|M0)               f3.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $445
        cmp (32|M0)   (eq)f3.0   null<2>:uw    r91.27<0;1,0>:uw  r91.27<0;1,0>:uw                    //  ALU pipe: int; $446
(W)     fbl (1|M0)               r3.0<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $448
(W)     shl (1|M0)               r1.1<1>:q     r91.1<0;1,0>:q    1:w                                 //  ALU pipe: int; $442
(W)     shl (1|M0)               r3.0<1>:ud    r3.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $449
(W)     add (1|M0)               r2.0<1>:q     r1.1<0;1,0>:q     r1.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $443
(W)     add (1|M0)               a0.0<1>:uw    r3.0<0;1,0>:uw    0x1B80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0483(r110.0:w); $450
(W)     mov (1|M0)               r4.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $452
(W)     store.ugm.d16u32.a64 (1|M0)  [r2:2]     r4:1               {I@1,$11} // ex_desc:0x0; desc:0x4000B84 // $453
// B025: Preds:{B024, B020},  Succs:{B026, B027}
_0_048:
        join (32|M0)                         L5752                                                   // 
L5752:
        sync.nop                             null                             {Compacted,$11.src}    // $455
(W)     send.slm (1|M0)          r3       r90  null:0  0x0            0x0210001F           {$12} // wr:1+0, rd:1; fence.slm.none.group // $455
(W)     mov (1|M0)               r4.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $456
(W)     mov (2|M0)               r4.10<1>:ub   r90.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $456
(W)     mov (8|M0)               null<1>:ud    r3.0<1;1,0>:ud                   {Compacted,$12.dst}  //  memory fence commit; ALU pipe: int; $456
(W)     send.gtwy (1|M0)         null     r4  null:0  0x0            0x02000004           {I@2,$13} // wr:1+0, rd:0; signal barrier // $456
(W)     sync.bar                             0x0                                                     // $456
(W)     cmp (32|M0)   (ne)f1.0   null<1>:d     r91.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $460
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r91.4<0;1,0>:d    r93.0<0;1,0>:d                      //  ALU pipe: int; $457
(W&~f1.0) cmp (32|M0) (ne)f1.0   null<1>:d     r91.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $461
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r91.5<0;1,0>:d    r91.11<0;1,0>:d                     //  ALU pipe: int; $458
(W)     mov (1|M0)               r7.0<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $463
(W)     mov (1|M0)               r5.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $466
(W)     and (1|M0)               f2.0<1>:ud    f2.0<0;1,0>:ud    r7.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $463
(f0.0)  sel (32|M0)              r6.0<1>:uw    r5.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $466
(f2.0)  cmp (32|M0)   (eq)f2.0   null<2>:w     r92.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $464
(f2.0)  sel (32|M0)              r8.0<1>:uw    r5.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $466
        and (32|M0)   (ne)f2.0   null<2>:uw    r8.0<1;1,0>:uw    r6.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $466
(~f2.0) goto (32|M0)                         _0_053            _0_053                                //  ALU pipe: int; $467
// B026: [inDivergent],  Preds:{B025},  Succs:{B027}
_0_054:
(W)     mov (1|M0)               r1.8<2>:b     r91.26<0;1,0>:w                                       //  ALU pipe: int; $469
(W)     mov (1|M0)               r3.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $472
(W)     mov (1|M0)               r2.0<1>:w     r1.8<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $470
(W)     shl (1|M0)               r7.0<1>:q     r91.3<0;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $474
(W)     cmp (32|M0)   (eq)f0.0   null<2>:w     r2.0<0;1,0>:w     0:w               {I@2}             //  ALU pipe: int; $471
(W)     and (1|M0)               r8.0<1>:d     r7.0<0;1,0>:d     -4:w               {Compacted,I@2}  //  ALU pipe: int; $475
(W)     and (1|M0)               r8.1<1>:d     r7.1<0;1,0>:d     3:w                                 //  ALU pipe: int; $476
        sync.nop                             null                             {Compacted,F@1}        // $472
(W&f0.0) sel (1|M0)              r4.0<1>:d     r3.0<0;1,0>:w     0:w               {$13.src}         //  ALU pipe: int; $472
(W)     add (1|M0)               r10.0<1>:q    r8.0<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $477
(W)     mov (1|M0)               r6.0<1>:d     -r4.0<0;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $473
(W)     store.ugm.d32x1t.a64 (1|M0)  [r10:1]    r6:1               {I@1,$14} // ex_desc:0x0; desc:0x2008584 // $479
// B027: Preds:{B026, B025},  Succs:{}
_0_053:
        join (32|M0)                         L6200                                                   // 
L6200:
(W)     mov (16|M0)              r127.0<1>:f   r90.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $481
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$15} // wr:1+0, rd:0; end of thread // $481
L6224:
(W)     mov (16|M0)              null<1>:ud    0xC2F8B981:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4121A863:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x3B:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 2
//


//.numALUInst: 409
//.accSubDef: 20
//.accSubUse: 20
//.accSubCandidateDef: 20
//.accSubCandidateUse: 20
//
//
//.singlePipeAtOneDistNum: 63
//.allAtOneDistNum: 10
//.syncInstCount: 2
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 12
//.AfterReadTokenDepCount: 5
