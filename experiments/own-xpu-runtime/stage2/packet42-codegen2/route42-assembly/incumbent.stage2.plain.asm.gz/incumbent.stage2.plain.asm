//.kernel _ZTSZZNK8packet1812_GLOBAL__N_19SimpleNewILN10integrated2OpE8ELi2ELi512ELi10EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS6_5eventESaISE_EEENKUlRNS6_7handlerEE_clESK_EUlNS6_2idILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 2611426388 3847313130 -hashmovs1 0 9 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 2611426388 3847313130 -hashmovs1 0 9 -GRFBumpUpNumber 2 "
//.instCount 270
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.private memory size 22528

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r15.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.12)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.13)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r15.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r15.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=1 type=b align=2 words (r2.24)
//.declare V0043 (53)  rf=r size=1 type=b align=2 words (r2.28)
//.declare V0044 (54)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0045 (55)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.8)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r3.9)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r3.10)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r3.11)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r3.12)
//.declare V0057 (67)  rf=r size=4 type=d align=2 words (r3.13)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r3.15)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0061 (71)  rf=r size=4 type=d align=2 words (r4.1)
//.declare V0062 (72)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0063 (73)  rf=r size=4 type=d align=2 words (r4.3)
//.declare V0064 (74)  rf=r size=4 type=d align=2 words (r4.4)
//.declare V0065 (75)  rf=r size=4 type=d align=2 words (r4.5)
//.declare V0066 (76)  rf=r size=4 type=d align=2 words (r4.6)
//.declare V0067 (77)  rf=r size=4 type=d align=2 words (r4.7)
//.declare V0068 (78)  rf=r size=4 type=d align=2 words (r4.8)
//.declare V0069 (79)  rf=r size=4 type=d align=2 words (r4.9)
//.declare V0070 (80)  rf=r size=4 type=d align=2 words (r4.10)
//.declare V0071 (81)  rf=r size=4 type=d align=2 words (r4.11)
//.declare V0072 (82)  rf=r size=4 type=d align=2 words (r4.12)
//.declare V0073 (83)  rf=r size=4 type=d align=2 words (r4.13)
//.declare V0074 (84)  rf=r size=4 type=d align=2 words (r4.14)
//.declare V0075 (85)  rf=r size=4 type=d align=2 words (r4.15)
//.declare V0076 (86)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0077 (87)  rf=r size=4 type=d align=2 words (r5.1)
//.declare V0078 (88)  rf=r size=4 type=d align=2 words (r5.2)
//.declare V0079 (89)  rf=r size=4 type=d align=2 words (r5.3)
//.declare V0080 (90)  rf=r size=4 type=d align=2 words (r5.4)
//.declare V0081 (91)  rf=r size=4 type=d align=2 words (r5.5)
//.declare V0082 (92)  rf=r size=4 type=d align=2 words (r5.6)
//.declare V0083 (93)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0084 (94)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0085 (95)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0086 (96)  rf=r size=8 type=q align=4 words (r5.7)
//.declare V0087 (97)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0088 (98)  rf=r size=8 type=q align=4 words (r6.1)
//.declare V0089 (99)  rf=r size=8 type=q align=4 words (r6.2)
//.declare V0090 (100)  rf=r size=8 type=q align=4 words (r6.3)
//.declare V0091 (101)  rf=r size=8 type=q align=4 words (r6.4)
//.declare V0092 (102)  rf=r size=8 type=q align=4 words (r6.5)
//.declare V0093 (103)  rf=r size=8 type=q align=4 words (r6.6)
//.declare V0094 (104)  rf=r size=8 type=q align=4 words (r6.7)
//.declare V0095 (105)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0096 (106)  rf=r size=8 type=q align=4 words (r7.1)
//.declare V0097 (107)  rf=r size=8 type=q align=4 words (r7.2)
//.declare V0098 (108)  rf=r size=8 type=q align=4 words (r7.3)
//.declare V0099 (109)  rf=r size=8 type=q align=4 words (r7.4)
//.declare V0100 (110)  rf=r size=8 type=q align=4 words (r7.5)
//.declare V0101 (111)  rf=r size=8 type=q align=4 words (r7.6)
//.declare V0102 (112)  rf=r size=8 type=q align=4 words (r7.7)
//.declare V0103 (113)  rf=r size=4 type=d align=2 words (r8.0)
//.declare V0104 (114)  rf=r size=4 type=d align=2 words (r8.1)
//.declare V0105 (115)  rf=r size=4 type=d align=2 words (r8.2)
//.declare V0106 (116)  rf=r size=4 type=d align=2 words (r8.3)
//.declare V0107 (117)  rf=r size=4 type=d align=2 words (r8.4)
//.declare V0108 (118)  rf=r size=4 type=d align=2 words (r8.5)
//.declare V0109 (119)  rf=r size=4 type=d align=2 words (r8.6)
//.declare V0110 (120)  rf=r size=4 type=d align=2 words (r8.7)
//.declare V0111 (121)  rf=r size=4 type=d align=2 words (r8.8)
//.declare V0112 (122)  rf=r size=4 type=d align=2 words (r8.9)
//.declare V0113 (123)  rf=r size=4 type=d align=2 words (r8.10)
//.declare V0114 (124)  rf=r size=4 type=d align=2 words (r8.11)
//.declare V0115 (125)  rf=r size=4 type=d align=2 words (r8.12)
//.declare V0116 (126)  rf=r size=4 type=d align=2 words (r8.13)
//.declare V0117 (127)  rf=r size=4 type=d align=2 words (r8.14)
//.declare V0118 (128)  rf=r size=4 type=d align=2 words (r8.15)
//.declare V0119 (129)  rf=r size=4 type=d align=2 words (r9.0)
//.declare V0120 (130)  rf=r size=4 type=d align=2 words (r9.1)
//.declare V0121 (131)  rf=r size=4 type=d align=2 words (r9.2)
//.declare V0122 (132)  rf=r size=4 type=d align=2 words (r9.3)
//.declare V0123 (133)  rf=r size=4 type=d align=2 words (r9.4)
//.declare V0124 (134)  rf=r size=4 type=d align=2 words (r9.5)
//.declare V0125 (135)  rf=r size=4 type=d align=2 words (r9.6)
//.declare V0126 (136)  rf=r size=4 type=d align=2 words (r9.7)
//.declare V0127 (137)  rf=r size=8 type=q align=4 words (r9.4)
//.declare V0128 (138)  rf=r size=8 type=q align=4 words (r9.5)
//.declare V0129 (139)  rf=r size=8 type=q align=4 words (r9.6)
//.declare V0130 (140)  rf=r size=8 type=q align=4 words (r9.7)
//.declare V0131 (141)  rf=r size=1 type=b align=2 words (r10.0)
//.declare V0132 (142)  rf=r size=1 type=b align=2 words (r10.4)
//.declare V0133 (143)  rf=r size=1 type=b align=2 words (r10.8)
//.declare V0134 (144)  rf=r size=1 type=b align=2 words (r10.12)
//.declare V0135 (145)  rf=r size=1 type=b align=2 words (r10.16)
//.declare V0136 (146)  rf=r size=1 type=b align=2 words (r10.20)
//.declare V0137 (147)  rf=r size=1 type=b align=2 words (r10.24)
//.declare V0138 (148)  rf=r size=1 type=b align=2 words (r10.28)
//.declare V0139 (149)  rf=r size=8 type=q align=4 words (r10.4)
//.declare V0140 (150)  rf=r size=8 type=q align=4 words (r10.5)
//.declare V0141 (151)  rf=r size=8 type=q align=4 words (r10.6)
//.declare V0142 (152)  rf=r size=8 type=q align=4 words (r10.7)
//.declare V0143 (153)  rf=r size=8 type=q align=4 words (r11.0)
//.declare V0144 (154)  rf=r size=8 type=q align=4 words (r11.1)
//.declare V0145 (155)  rf=r size=8 type=q align=4 words (r11.2)
//.declare V0146 (156)  rf=r size=8 type=q align=4 words (r11.3)
//.declare V0147 (157)  rf=r size=8 type=q align=4 words (r11.4)
//.declare V0148 (158)  rf=r size=8 type=q align=4 words (r11.5)
//.declare V0149 (159)  rf=r size=8 type=q align=4 words (r11.6)
//.declare V0150 (160)  rf=r size=8 type=q align=4 words (r11.7)
//.declare V0151 (161)  rf=r size=8 type=q align=4 words (r12.0)
//.declare V0152 (162)  rf=r size=8 type=q align=4 words (r12.1)
//.declare V0153 (163)  rf=r size=8 type=q align=4 words (r12.2)
//.declare V0154 (164)  rf=r size=8 type=q align=4 words (r12.3)
//.declare V0155 (165)  rf=r size=8 type=q align=4 words (r12.4)
//.declare V0156 (166)  rf=r size=8 type=q align=4 words (r12.5)
//.declare V0157 (167)  rf=r size=8 type=q align=4 words (r12.6)
//.declare V0158 (168)  rf=r size=8 type=q align=4 words (r12.7)
//.declare V0159 (169)  rf=r size=8 type=q align=4 words (r13.0)
//.declare V0160 (170)  rf=r size=8 type=q align=4 words (r13.1)
//.declare V0161 (171)  rf=r size=8 type=q align=4 words (r13.2)
//.declare V0162 (172)  rf=r size=8 type=q align=4 words (r13.3)
//.declare V0163 (173)  rf=r size=8 type=q align=4 words (r13.4)
//.declare V0164 (174)  rf=r size=8 type=q align=4 words (r13.5)
//.declare V0165 (175)  rf=r size=8 type=q align=4 words (r13.6)
//.declare V0166 (176)  rf=r size=8 type=q align=4 words (r13.7)
//.declare V0167 (177)  rf=r size=8 type=q align=4 words (r14.0)
//.declare V0168 (178)  rf=r size=8 type=q align=4 words (r14.1)
//.declare V0169 (179)  rf=r size=8 type=q align=4 words (r14.2)
//.declare V0170 (180)  rf=r size=8 type=q align=4 words (r14.3)
//.declare V0172 (182)  rf=r size=8 type=d alias=V0083+0 align=4 words (r5.8)
//.declare V0174 (184)  rf=r size=8 type=d alias=V0084+0 align=4 words (r5.10)
//.declare V0176 (186)  rf=r size=8 type=d alias=V0085+0 align=4 words (r5.12)
//.declare V0178 (188)  rf=r size=8 type=d alias=V0086+0 align=4 words (r5.14)
//.declare V0180 (190)  rf=r size=8 type=d alias=V0087+0 align=4 words (r6.0)
//.declare V0182 (192)  rf=r size=8 type=d alias=V0088+0 align=4 words (r6.2)
//.declare V0184 (194)  rf=r size=8 type=d alias=V0089+0 align=4 words (r6.4)
//.declare V0186 (196)  rf=r size=8 type=d alias=V0090+0 align=4 words (r6.6)
//.declare V0188 (198)  rf=r size=8 type=d alias=V0091+0 align=4 words (r6.8)
//.declare V0190 (200)  rf=r size=8 type=d alias=V0092+0 align=4 words (r6.10)
//.declare V0192 (202)  rf=r size=8 type=d alias=V0093+0 align=4 words (r6.12)
//.declare V0194 (204)  rf=r size=8 type=d alias=V0094+0 align=4 words (r6.14)
//.declare V0196 (206)  rf=r size=8 type=d alias=V0095+0 align=4 words (r7.0)
//.declare V0197 (207)  rf=r size=256 type=b align=32 words (r16.0)
//.declare V0198 (208)  rf=r size=256 type=d alias=V0197+0 align=32 words (r16.0)
//.declare V0199 (209)  rf=r size=4 type=ud align=32 words (r20.0)
//.declare  (211)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0202 (213)  rf=r size=8 type=d alias=V0096+0 align=4 words (r7.2)
//.declare V0204 (215)  rf=r size=8 type=d alias=V0097+0 align=4 words (r7.4)
//.declare V0206 (217)  rf=r size=8 type=d alias=V0098+0 align=4 words (r7.6)
//.declare V0208 (219)  rf=r size=8 type=d alias=V0099+0 align=4 words (r7.8)
//.declare V0210 (221)  rf=r size=8 type=d alias=V0100+0 align=4 words (r7.10)
//.declare V0212 (223)  rf=r size=8 type=d alias=V0101+0 align=4 words (r7.12)
//.declare V0214 (225)  rf=r size=8 type=d alias=V0102+0 align=4 words (r7.14)
//.declare V0215 (226)  rf=r size=64 type=b align=32 words (r21.0)
//.declare V0216 (227)  rf=r size=64 type=d alias=V0215+0 align=32 words (r21.0)
//.declare V0217 (228)  rf=r size=4 type=ud align=32 words (r22.0)
//.declare  (230)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0219 (231)  rf=r size=32 type=d align=2 words (r2.8)
//.declare V0220 (232)  rf=r size=4 type=ud align=32 words (r23.0)
//.declare V0221 (233)  rf=r size=32 type=d align=32 words (r24.0)
//.declare  (235)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0223 (236)  rf=r size=16 type=d align=2 words (r14.8)
//.declare V0224 (237)  rf=r size=4 type=ud align=32 words (r25.0)
//.declare V0225 (238)  rf=r size=16 type=d align=32 words (r26.0)
//.declare  (240)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0228 (242)  rf=r size=8 type=d alias=V0127+0 align=4 words (r9.8)
//.declare V0230 (244)  rf=r size=8 type=d alias=V0128+0 align=4 words (r9.10)
//.declare V0232 (246)  rf=r size=8 type=d alias=V0129+0 align=4 words (r9.12)
//.declare V0234 (248)  rf=r size=8 type=d alias=V0130+0 align=4 words (r9.14)
//.declare V0236 (250)  rf=r size=8 type=d alias=V0139+0 align=4 words (r10.8)
//.declare V0238 (252)  rf=r size=8 type=d alias=V0140+0 align=4 words (r10.10)
//.declare V0240 (254)  rf=r size=8 type=d alias=V0141+0 align=4 words (r10.12)
//.declare V0242 (256)  rf=r size=8 type=d alias=V0142+0 align=4 words (r10.14)
//.declare V0244 (258)  rf=r size=8 type=d alias=V0143+0 align=4 words (r11.0)
//.declare V0246 (260)  rf=r size=8 type=d alias=V0144+0 align=4 words (r11.2)
//.declare V0248 (262)  rf=r size=8 type=d alias=V0145+0 align=4 words (r11.4)
//.declare V0250 (264)  rf=r size=8 type=d alias=V0146+0 align=4 words (r11.6)
//.declare V0252 (266)  rf=r size=8 type=d alias=V0147+0 align=4 words (r11.8)
//.declare V0254 (268)  rf=r size=8 type=d alias=V0148+0 align=4 words (r11.10)
//.declare V0256 (270)  rf=r size=8 type=d alias=V0149+0 align=4 words (r11.12)
//.declare V0258 (272)  rf=r size=8 type=d alias=V0150+0 align=4 words (r11.14)
//.declare V0260 (274)  rf=r size=8 type=d alias=V0151+0 align=4 words (r12.0)
//.declare V0262 (276)  rf=r size=8 type=d alias=V0152+0 align=4 words (r12.2)
//.declare V0264 (278)  rf=r size=8 type=d alias=V0153+0 align=4 words (r12.4)
//.declare V0266 (280)  rf=r size=8 type=d alias=V0154+0 align=4 words (r12.6)
//.declare V0268 (282)  rf=r size=8 type=d alias=V0155+0 align=4 words (r12.8)
//.declare V0270 (284)  rf=r size=8 type=d alias=V0156+0 align=4 words (r12.10)
//.declare V0272 (286)  rf=r size=8 type=d alias=V0157+0 align=4 words (r12.12)
//.declare V0274 (288)  rf=r size=8 type=d alias=V0158+0 align=4 words (r12.14)
//.declare V0276 (290)  rf=r size=8 type=d alias=V0159+0 align=4 words (r13.0)
//.declare V0278 (292)  rf=r size=8 type=d alias=V0160+0 align=4 words (r13.2)
//.declare V0279 (293)  rf=r size=256 type=b align=32 words (r27.0)
//.declare V0280 (294)  rf=r size=256 type=d alias=V0279+0 align=32 words (r27.0)
//.declare V0281 (295)  rf=r size=4 type=ud align=32 words (r31.0)
//.declare  (297)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0284 (299)  rf=r size=8 type=d alias=V0161+0 align=4 words (r13.4)
//.declare V0286 (301)  rf=r size=8 type=d alias=V0162+0 align=4 words (r13.6)
//.declare V0288 (303)  rf=r size=8 type=d alias=V0163+0 align=4 words (r13.8)
//.declare V0290 (305)  rf=r size=8 type=d alias=V0164+0 align=4 words (r13.10)
//.declare V0292 (307)  rf=r size=8 type=d alias=V0165+0 align=4 words (r13.12)
//.declare V0294 (309)  rf=r size=8 type=d alias=V0166+0 align=4 words (r13.14)
//.declare V0296 (311)  rf=r size=8 type=d alias=V0167+0 align=4 words (r14.0)
//.declare V0298 (313)  rf=r size=8 type=d alias=V0168+0 align=4 words (r14.2)
//.declare V0299 (314)  rf=r size=64 type=b align=32 words (r32.0)
//.declare V0300 (315)  rf=r size=64 type=d alias=V0299+0 align=32 words (r32.0)
//.declare V0301 (316)  rf=r size=4 type=ud align=32 words (r33.0)
//.declare  (318)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0304 (320)  rf=r size=8 type=d alias=V0169+0 align=4 words (r14.4)
//.declare V0306 (322)  rf=r size=8 type=d alias=V0170+0 align=4 words (r14.6)
//.declare V0307 (323)  rf=r size=16 type=b align=32 words (r34.0)
//.declare V0308 (324)  rf=r size=16 type=d alias=V0307+0 align=32 words (r34.0)
//.declare V0309 (325)  rf=r size=4 type=ud align=32 words (r35.0)
//.declare  (327)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0311 (328)  rf=r size=4 type=ud align=32 words (r36.0)
//.declare V0312 (329)  rf=r size=12 type=d align=32 words (r37.0)
//.declare  (331)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0314 (332)  rf=r size=4 type=d align=2 words (r5.7)
//.declare V0315 (333)  rf=r size=4 type=d align=2 words (r14.12)
//.declare V0316 (334)  rf=r size=4 type=d align=32 words (r38.0)
//.declare V0317 (335)  rf=r size=4 type=ud alias=V0316+0 align=32 words (r38.0)
//.declare V0318 (336)  rf=r size=8 type=q align=32 words (r39.0)
//.declare  (338)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0320 (339)  rf=r size=8 type=uq alias=V0318+0 align=32 words (r39.0)
//.declare V0321 (340)  rf=r size=8 type=uq align=32 words (r40.0)
//.declare V0322 (341)  rf=r size=4 type=d align=32 words (r41.0)
//.declare P01 (342)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0323 (343)  rf=r size=4 type=d align=32 words (r42.0)
//.declare V0324 (344)  rf=r size=4 type=ud alias=V0323+0 align=32 words (r42.0)
//.declare V0325 (345)  rf=r size=8 type=q align=32 words (r43.0)
//.declare  (347)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0327 (348)  rf=r size=8 type=uq alias=V0325+0 align=32 words (r43.0)
//.declare V0328 (349)  rf=r size=8 type=uq align=32 words (r44.0)
//.declare V0330 (351)  rf=r size=256 type=uq align=32 words (r45.0)
//.declare V0331 (352)  rf=r size=256 type=ud alias=V0330+0 align=32 words (r45.0)
//.declare V0332 (353)  rf=r size=8 type=ud alias=V0328+0 align=32 words (r44.0)
//.declare V0333 (354)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0334 (355)  rf=r size=128 type=ud align=32 words (r51.0)
//.declare P02 (357)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0336 (358)  rf=r size=4 type=d align=32 words (r53.0)
//.declare V0338 (360)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0339 (361)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0340 (362)  rf=r size=4 type=d align=32 words (r56.0)
//.declare V0341 (363)  rf=r size=4 type=ud alias=V0340+0 align=32 words (r56.0)
//.declare V0342 (364)  rf=r size=8 type=q align=32 words (r57.0)
//.declare  (366)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0346 (369)  rf=r size=8 type=q align=4 words (r14.7)
//.declare V0347 (370)  rf=r size=8 type=uq align=32 words (r58.0)
//.declare V0348 (371)  rf=r size=32 type=f align=32 words (r59.0)
//.declare V0351 (374)  rf=r size=8 type=uq align=32 words (r60.0)
//.declare V0352 (375)  rf=r size=32 type=f align=32 words (r61.0)
//.declare V0355 (378)  rf=r size=8 type=uq align=32 words (r62.0)
//.declare V0356 (379)  rf=r size=32 type=f align=32 words (r63.0)
//.declare V0359 (382)  rf=r size=8 type=uq align=32 words (r64.0)
//.declare V0360 (383)  rf=r size=32 type=f align=32 words (r65.0)
//.declare V0361 (384)  rf=r size=4 type=f alias=+0 align=2 words (r95.0)
//.declare V0362 (385)  rf=r size=4 type=f alias=+0 align=2 words (r96.0)
//.declare V0363 (386)  rf=r size=4 type=f alias=+4 align=2 words (r95.1)
//.declare V0364 (387)  rf=r size=4 type=f alias=+4 align=2 words (r96.1)
//.declare V0365 (388)  rf=r size=4 type=f alias=+8 align=2 words (r95.2)
//.declare V0366 (389)  rf=r size=4 type=f alias=+8 align=2 words (r96.2)
//.declare V0367 (390)  rf=r size=4 type=f alias=+12 align=2 words (r95.3)
//.declare V0368 (391)  rf=r size=4 type=f alias=+12 align=2 words (r96.3)
//.declare V0369 (392)  rf=r size=4 type=f alias=+0 align=2 words (r98.0)
//.declare V0370 (393)  rf=r size=4 type=f alias=+0 align=2 words (r99.0)
//.declare V0371 (394)  rf=r size=4 type=f alias=+4 align=2 words (r98.1)
//.declare V0372 (395)  rf=r size=4 type=f alias=+4 align=2 words (r99.1)
//.declare V0373 (396)  rf=r size=4 type=f alias=+8 align=2 words (r98.2)
//.declare V0374 (397)  rf=r size=4 type=f alias=+8 align=2 words (r99.2)
//.declare V0375 (398)  rf=r size=4 type=f alias=+12 align=2 words (r98.3)
//.declare V0376 (399)  rf=r size=4 type=f alias=+12 align=2 words (r99.3)
//.declare V0377 (400)  rf=r size=4 type=f alias=+0 align=2 words (r94.0)
//.declare V0378 (401)  rf=r size=4 type=f alias=+4 align=2 words (r94.1)
//.declare V0379 (402)  rf=r size=4 type=f alias=+8 align=2 words (r94.2)
//.declare V0380 (403)  rf=r size=4 type=f alias=+12 align=2 words (r94.3)
//.declare V0381 (404)  rf=r size=4 type=f alias=+0 align=2 words (r97.0)
//.declare V0382 (405)  rf=r size=4 type=f alias=+4 align=2 words (r97.1)
//.declare V0383 (406)  rf=r size=4 type=f alias=+8 align=2 words (r97.2)
//.declare V0384 (407)  rf=r size=4 type=f alias=+12 align=2 words (r97.3)
//.declare V0385 (408)  rf=r size=4 type=f alias=+0 align=2 words (r20.8)
//.declare V0386 (409)  rf=r size=4 type=f alias=+0 align=2 words (r20.12)
//.declare V0387 (410)  rf=r size=4 type=f alias=+4 align=2 words (r20.9)
//.declare V0388 (411)  rf=r size=4 type=f alias=+4 align=2 words (r20.13)
//.declare V0389 (412)  rf=r size=4 type=f alias=+0 align=2 words (r20.4)
//.declare V0390 (413)  rf=r size=4 type=f alias=+4 align=2 words (r20.5)
//.declare V0391 (414)  rf=r size=4 type=f align=2 words (r14.13)
//.declare V0392 (415)  rf=r size=8 type=q align=4 words (r20.1)
//.declare V0394 (417)  rf=r size=128 type=ud alias=V0339+0 align=32 words (r54.0)
//.declare V0398 (421)  rf=r size=256 type=uq align=32 words (r66.0)
//.declare V0399 (422)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0400 (423)  rf=r size=128 type=f align=32 words (r72.0)
//.declare  (424)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (425)  rf=r size=128 type=f align=32 words (r74.0)
//.declare  (426)  rf=r size=128 type=f align=32 words (r76.0)
//.declare  (427)  rf=r size=128 type=f align=32 words (r78.0)
//.declare  (428)  rf=r size=128 type=f align=32 words (r80.0)
//.declare  (429)  rf=r size=128 type=f align=32 words (r82.0)
//.declare  (430)  rf=r size=128 type=f align=32 words (r84.0)
//.declare  (431)  rf=r size=128 type=f align=32 words (r86.0)
//.declare  (432)  rf=r size=64 type=f align=32 words (r88.0)
//.declare  (433)  rf=r size=64 type=f align=32 words (r89.0)
//.declare V0403 (438)  rf=r size=256 type=uq align=32 words (r90.0)
//.declare  (439)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (440)  rf=r size=16 type=f align=32 words (r94.0)
//.declare  (441)  rf=r size=16 type=f align=32 words (r95.0)
//.declare  (442)  rf=r size=16 type=f align=32 words (r96.0)
//.declare  (443)  rf=r size=16 type=f align=32 words (r97.0)
//.declare  (444)  rf=r size=16 type=f align=32 words (r98.0)
//.declare  (445)  rf=r size=16 type=f align=32 words (r99.0)
//.declare  (446)  rf=r size=8 type=f align=8 words (r20.4)
//.declare  (447)  rf=r size=8 type=f align=8 words (r20.8)
//.declare  (448)  rf=r size=8 type=f align=8 words (r20.12)
//.declare  (449)  rf=r size=128 type=ud align=32 words (r100.0)
//.declare  (450)  rf=r size=128 type=ud align=32 words (r102.0)
//.declare  (453)  rf=r size=128 type=q align=32 words (r104.0)
//.declare  (454)  rf=r size=128 type=q align=32 words (r106.0)
//.declare r0 (459)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (460)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (461)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (462)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (463)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (464)  rf=r size=256 type=ud align=32 words (r3.0)
//.declare  (465)  rf=r size=256 type=ud align=32 words (r7.0)
//.declare  (466)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (467)  rf=r size=64 type=ud align=32 words (r13.0)
//.declare  (468)  rf=r size=32 type=ud align=2 words (r14.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0037    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0042    | :b       |    0x1 | r2+0x18  | inline+0x18      |
// | V0043    | :b       |    0x1 | r2+0x1C  | inline+0x1C      |
// | V0044    | :b       |    0x1 | r3       | cti+0x20         |
// | V0045    | :b       |    0x1 | r3+0x4   | cti+0x24         |
// | V0046    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0047    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0048    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0049    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0050    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0051    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0052    | :d       |    0x4 | r3+0x20  | cti+0x40         |
// | V0053    | :d       |    0x4 | r3+0x24  | cti+0x44         |
// | V0054    | :d       |    0x4 | r3+0x28  | cti+0x48         |
// | V0055    | :d       |    0x4 | r3+0x2C  | cti+0x4C         |
// | V0056    | :d       |    0x4 | r3+0x30  | cti+0x50         |
// | V0057    | :d       |    0x4 | r3+0x34  | cti+0x54         |
// | V0058    | :d       |    0x4 | r3+0x38  | cti+0x58         |
// | V0059    | :d       |    0x4 | r3+0x3C  | cti+0x5C         |
// | V0060    | :d       |    0x4 | r4       | cti+0x60         |
// | V0061    | :d       |    0x4 | r4+0x4   | cti+0x64         |
// | V0062    | :d       |    0x4 | r4+0x8   | cti+0x68         |
// | V0063    | :d       |    0x4 | r4+0xC   | cti+0x6C         |
// | V0064    | :d       |    0x4 | r4+0x10  | cti+0x70         |
// | V0065    | :d       |    0x4 | r4+0x14  | cti+0x74         |
// | V0066    | :d       |    0x4 | r4+0x18  | cti+0x78         |
// | V0067    | :d       |    0x4 | r4+0x1C  | cti+0x7C         |
// | V0068    | :d       |    0x4 | r4+0x20  | cti+0x80         |
// | V0069    | :d       |    0x4 | r4+0x24  | cti+0x84         |
// | V0070    | :d       |    0x4 | r4+0x28  | cti+0x88         |
// | V0071    | :d       |    0x4 | r4+0x2C  | cti+0x8C         |
// | V0072    | :d       |    0x4 | r4+0x30  | cti+0x90         |
// | V0073    | :d       |    0x4 | r4+0x34  | cti+0x94         |
// | V0074    | :d       |    0x4 | r4+0x38  | cti+0x98         |
// | V0075    | :d       |    0x4 | r4+0x3C  | cti+0x9C         |
// | V0076    | :d       |    0x4 | r5       | cti+0xA0         |
// | V0077    | :d       |    0x4 | r5+0x4   | cti+0xA4         |
// | V0078    | :d       |    0x4 | r5+0x8   | cti+0xA8         |
// | V0079    | :d       |    0x4 | r5+0xC   | cti+0xAC         |
// | V0080    | :d       |    0x4 | r5+0x10  | cti+0xB0         |
// | V0081    | :d       |    0x4 | r5+0x14  | cti+0xB4         |
// | V0082    | :d       |    0x4 | r5+0x18  | cti+0xB8         |
// | V0083    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0084    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0085    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// | V0086    | :q       |    0x8 | r5+0x38  | cti+0xD8         |
// | V0087    | :q       |    0x8 | r6       | cti+0xE0         |
// | V0088    | :q       |    0x8 | r6+0x8   | cti+0xE8         |
// | V0089    | :q       |    0x8 | r6+0x10  | cti+0xF0         |
// | V0090    | :q       |    0x8 | r6+0x18  | cti+0xF8         |
// | V0091    | :q       |    0x8 | r6+0x20  | cti+0x100        |
// | V0092    | :q       |    0x8 | r6+0x28  | cti+0x108        |
// | V0093    | :q       |    0x8 | r6+0x30  | cti+0x110        |
// | V0094    | :q       |    0x8 | r6+0x38  | cti+0x118        |
// | V0095    | :q       |    0x8 | r7       | cti+0x120        |
// | V0096    | :q       |    0x8 | r7+0x8   | cti+0x128        |
// | V0097    | :q       |    0x8 | r7+0x10  | cti+0x130        |
// | V0098    | :q       |    0x8 | r7+0x18  | cti+0x138        |
// | V0099    | :q       |    0x8 | r7+0x20  | cti+0x140        |
// | V0100    | :q       |    0x8 | r7+0x28  | cti+0x148        |
// | V0101    | :q       |    0x8 | r7+0x30  | cti+0x150        |
// | V0102    | :q       |    0x8 | r7+0x38  | cti+0x158        |
// | V0103    | :d       |    0x4 | r8       | cti+0x160        |
// | V0104    | :d       |    0x4 | r8+0x4   | cti+0x164        |
// | V0105    | :d       |    0x4 | r8+0x8   | cti+0x168        |
// | V0106    | :d       |    0x4 | r8+0xC   | cti+0x16C        |
// | V0107    | :d       |    0x4 | r8+0x10  | cti+0x170        |
// | V0108    | :d       |    0x4 | r8+0x14  | cti+0x174        |
// | V0109    | :d       |    0x4 | r8+0x18  | cti+0x178        |
// | V0110    | :d       |    0x4 | r8+0x1C  | cti+0x17C        |
// | V0111    | :d       |    0x4 | r8+0x20  | cti+0x180        |
// | V0112    | :d       |    0x4 | r8+0x24  | cti+0x184        |
// | V0113    | :d       |    0x4 | r8+0x28  | cti+0x188        |
// | V0114    | :d       |    0x4 | r8+0x2C  | cti+0x18C        |
// | V0115    | :d       |    0x4 | r8+0x30  | cti+0x190        |
// | V0116    | :d       |    0x4 | r8+0x34  | cti+0x194        |
// | V0117    | :d       |    0x4 | r8+0x38  | cti+0x198        |
// | V0118    | :d       |    0x4 | r8+0x3C  | cti+0x19C        |
// | V0119    | :d       |    0x4 | r9       | cti+0x1A0        |
// | V0120    | :d       |    0x4 | r9+0x4   | cti+0x1A4        |
// | V0121    | :d       |    0x4 | r9+0x8   | cti+0x1A8        |
// | V0122    | :d       |    0x4 | r9+0xC   | cti+0x1AC        |
// | V0123    | :d       |    0x4 | r9+0x10  | cti+0x1B0        |
// | V0124    | :d       |    0x4 | r9+0x14  | cti+0x1B4        |
// | V0125    | :d       |    0x4 | r9+0x18  | cti+0x1B8        |
// | V0126    | :d       |    0x4 | r9+0x1C  | cti+0x1BC        |
// | V0127    | :q       |    0x8 | r9+0x20  | cti+0x1C0        |
// | V0128    | :q       |    0x8 | r9+0x28  | cti+0x1C8        |
// | V0129    | :q       |    0x8 | r9+0x30  | cti+0x1D0        |
// | V0130    | :q       |    0x8 | r9+0x38  | cti+0x1D8        |
// | V0131    | :b       |    0x1 | r10      | cti+0x1E0        |
// | V0132    | :b       |    0x1 | r10+0x4  | cti+0x1E4        |
// | V0133    | :b       |    0x1 | r10+0x8  | cti+0x1E8        |
// | V0134    | :b       |    0x1 | r10+0xC  | cti+0x1EC        |
// | V0135    | :b       |    0x1 | r10+0x10 | cti+0x1F0        |
// | V0136    | :b       |    0x1 | r10+0x14 | cti+0x1F4        |
// | V0137    | :b       |    0x1 | r10+0x18 | cti+0x1F8        |
// | V0138    | :b       |    0x1 | r10+0x1C | cti+0x1FC        |
// | V0139    | :q       |    0x8 | r10+0x20 | cti+0x200        |
// | V0140    | :q       |    0x8 | r10+0x28 | cti+0x208        |
// | V0141    | :q       |    0x8 | r10+0x30 | cti+0x210        |
// | V0142    | :q       |    0x8 | r10+0x38 | cti+0x218        |
// | V0143    | :q       |    0x8 | r11      | cti+0x220        |
// | V0144    | :q       |    0x8 | r11+0x8  | cti+0x228        |
// | V0145    | :q       |    0x8 | r11+0x10 | cti+0x230        |
// | V0146    | :q       |    0x8 | r11+0x18 | cti+0x238        |
// | V0147    | :q       |    0x8 | r11+0x20 | cti+0x240        |
// | V0148    | :q       |    0x8 | r11+0x28 | cti+0x248        |
// | V0149    | :q       |    0x8 | r11+0x30 | cti+0x250        |
// | V0150    | :q       |    0x8 | r11+0x38 | cti+0x258        |
// | V0151    | :q       |    0x8 | r12      | cti+0x260        |
// | V0152    | :q       |    0x8 | r12+0x8  | cti+0x268        |
// | V0153    | :q       |    0x8 | r12+0x10 | cti+0x270        |
// | V0154    | :q       |    0x8 | r12+0x18 | cti+0x278        |
// | V0155    | :q       |    0x8 | r12+0x20 | cti+0x280        |
// | V0156    | :q       |    0x8 | r12+0x28 | cti+0x288        |
// | V0157    | :q       |    0x8 | r12+0x30 | cti+0x290        |
// | V0158    | :q       |    0x8 | r12+0x38 | cti+0x298        |
// | V0159    | :q       |    0x8 | r13      | cti+0x2A0        |
// | V0160    | :q       |    0x8 | r13+0x8  | cti+0x2A8        |
// | V0161    | :q       |    0x8 | r13+0x10 | cti+0x2B0        |
// | V0162    | :q       |    0x8 | r13+0x18 | cti+0x2B8        |
// | V0163    | :q       |    0x8 | r13+0x20 | cti+0x2C0        |
// | V0164    | :q       |    0x8 | r13+0x28 | cti+0x2C8        |
// | V0165    | :q       |    0x8 | r13+0x30 | cti+0x2D0        |
// | V0166    | :q       |    0x8 | r13+0x38 | cti+0x2D8        |
// | V0167    | :q       |    0x8 | r14      | cti+0x2E0        |
// | V0168    | :q       |    0x8 | r14+0x8  | cti+0x2E8        |
// | V0169    | :q       |    0x8 | r14+0x10 | cti+0x2F0        |
// | V0170    | :q       |    0x8 | r14+0x18 | cti+0x2F8        |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x2E0:ud              {I@2}         //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x64t.a32.ca.cc (1|M0)  r3:4 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6249F500 // 
(W)     load.ugm.d32x64t.a32.ca.cc (1|M0)  r7:4 bti[255][r127:1+0x100]  {$2} // ex_desc:0xFF100000; desc:0x6249F500 // 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r11:2 bti[255][r127:1+0x200]  {$3} // ex_desc:0xFF200000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r13:1 bti[255][r127:1+0x280]  {$4} // ex_desc:0xFF280000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r14:1 bti[255][r127:1+0x2C0]  {$5} // ex_desc:0xFF2C0000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B009}
// _main:
(W)     mov (16|M0)              r15.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r89.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r88.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r2.8<1>:d     r8.2<0;1,0>:d                    {A@1,$2.dst}         //  ALU pipe: int; $91
(W)     mov (1|M0)               r2.9<1>:d     r8.3<0;1,0>:d                                         //  ALU pipe: int; $92
(W)     mov (1|M0)               r2.10<1>:d    r8.4<0;1,0>:d                                         //  ALU pipe: int; $93
(W)     mov (1|M0)               r2.11<1>:d    r8.5<0;1,0>:d                                         //  ALU pipe: int; $94
(W)     mov (1|M0)               r2.12<1>:d    r8.6<0;1,0>:d                                         //  ALU pipe: int; $95
(W)     mov (1|M0)               r2.13<1>:d    r8.7<0;1,0>:d                                         //  ALU pipe: int; $96
(W)     mov (1|M0)               r2.14<1>:d    r8.8<0;1,0>:d                                         //  ALU pipe: int; $97
(W)     mov (1|M0)               r2.15<1>:d    r8.9<0;1,0>:d                                         //  ALU pipe: int; $98
(W)     mov (1|M0)               r14.8<1>:d    r8.10<0;1,0>:d                   {$5.dst}             //  ALU pipe: int; $103
(W)     mov (1|M0)               r14.9<1>:d    r8.11<0;1,0>:d                                        //  ALU pipe: int; $104
(W)     mov (1|M0)               r14.10<1>:d   r8.12<0;1,0>:d                                        //  ALU pipe: int; $105
(W)     mov (1|M0)               r14.11<1>:d   r8.13<0;1,0>:d                                        //  ALU pipe: int; $106
(W)     shr (1|M0)               a0.0<1>:ud    r15.5<0;1,0>:ud   0x4:uw              {F@1}           //  ALU pipe: int; $70
(W)     mov (2|M0)               r18.6<1>:d    r5.8<1;1,0>:d                    {$1.dst}             //  ALU pipe: int; $2
(W)     mov (2|M0)               r18.8<1>:d    r5.10<1;1,0>:d                                        //  ALU pipe: int; $3
(W)     mov (2|M0)               r18.10<1>:d   r5.12<1;1,0>:d                                        //  ALU pipe: int; $4
(W)     mov (2|M0)               r18.12<1>:d   r5.14<1;1,0>:d                                        //  ALU pipe: int; $5
(W)     mov (2|M0)               r18.14<1>:d   r6.0<1;1,0>:d                                         //  ALU pipe: int; $6
(W)     mov (2|M0)               r19.0<1>:d    r6.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $7
(W)     mov (2|M0)               r19.2<1>:d    r6.4<1;1,0>:d                                         //  ALU pipe: int; $8
(W)     mov (2|M0)               r19.4<1>:d    r6.6<1;1,0>:d                                         //  ALU pipe: int; $9
(W)     mov (2|M0)               r19.6<1>:d    r6.8<1;1,0>:d                                         //  ALU pipe: int; $10
(W)     mov (2|M0)               r19.8<1>:d    r6.10<1;1,0>:d                                        //  ALU pipe: int; $11
(W)     mov (2|M0)               r19.10<1>:d   r6.12<1;1,0>:d                                        //  ALU pipe: int; $12
(W)     mov (2|M0)               r19.12<1>:d   r6.14<1;1,0>:d                                        //  ALU pipe: int; $13
(W)     mov (2|M0)               r19.14<1>:d   r7.0<1;1,0>:d                                         //  ALU pipe: int; $14
(W)     mov (1|M0)               r16.0<2>:b    r2.24<0;1,0>:b                   {Atomic}             //  ALU pipe: int; $15
(W)     mov (1|M0)               r16.1<2>:b    r2.28<0;1,0>:b                   {Atomic}             // $16
(W)     mov (1|M0)               r16.2<2>:b    r3.0<0;1,0>:b                    {Atomic}             // $17
(W)     mov (1|M0)               r16.3<2>:b    r3.4<0;1,0>:b                                         // $18
(W)     mov (1|M0)               r16.1<1>:d    r3.2<0;1,0>:d                                         //  ALU pipe: int; $19
(W)     mov (1|M0)               r16.2<1>:d    r3.3<0;1,0>:d                                         //  ALU pipe: int; $20
(W)     mov (1|M0)               r16.3<1>:d    r3.4<0;1,0>:d                                         //  ALU pipe: int; $21
(W)     mov (1|M0)               r16.4<1>:d    r3.5<0;1,0>:d                                         //  ALU pipe: int; $22
(W)     mov (1|M0)               r16.5<1>:d    r3.6<0;1,0>:d                                         //  ALU pipe: int; $23
(W)     mov (1|M0)               r16.6<1>:d    r3.7<0;1,0>:d                                         //  ALU pipe: int; $24
(W)     mov (1|M0)               r16.7<1>:d    r3.8<0;1,0>:d                                         //  ALU pipe: int; $25
(W)     mov (1|M0)               r16.8<1>:d    r3.9<0;1,0>:d                                         //  ALU pipe: int; $26
(W)     mov (1|M0)               r16.9<1>:d    r3.10<0;1,0>:d                                        //  ALU pipe: int; $27
(W)     mov (1|M0)               r16.10<1>:d   r3.11<0;1,0>:d                                        //  ALU pipe: int; $28
(W)     mov (1|M0)               r16.11<1>:d   r3.12<0;1,0>:d                                        //  ALU pipe: int; $29
(W)     mov (1|M0)               r16.12<1>:d   r3.13<0;1,0>:d                                        //  ALU pipe: int; $30
(W)     mov (1|M0)               r16.13<1>:d   r3.14<0;1,0>:d                                        //  ALU pipe: int; $31
(W)     mov (1|M0)               r16.14<1>:d   r3.15<0;1,0>:d                                        //  ALU pipe: int; $32
(W)     mov (1|M0)               r16.15<1>:d   r4.0<0;1,0>:d                                         //  ALU pipe: int; $33
(W)     mov (1|M0)               r17.0<1>:d    r4.1<0;1,0>:d                    {Compacted}          //  ALU pipe: int; $34
(W)     mov (1|M0)               r17.1<1>:d    r4.2<0;1,0>:d                                         //  ALU pipe: int; $35
(W)     mov (1|M0)               r17.2<1>:d    r4.3<0;1,0>:d                                         //  ALU pipe: int; $36
(W)     mov (1|M0)               r17.3<1>:d    r4.4<0;1,0>:d                                         //  ALU pipe: int; $37
(W)     mov (1|M0)               r17.4<1>:d    r4.5<0;1,0>:d                                         //  ALU pipe: int; $38
(W)     mov (1|M0)               r17.5<1>:d    r4.6<0;1,0>:d                                         //  ALU pipe: int; $39
(W)     mov (1|M0)               r17.6<1>:d    r4.7<0;1,0>:d                                         //  ALU pipe: int; $40
(W)     mov (1|M0)               r17.7<1>:d    r4.8<0;1,0>:d                                         //  ALU pipe: int; $41
(W)     mov (1|M0)               r17.8<1>:d    r4.9<0;1,0>:d                                         //  ALU pipe: int; $42
(W)     mov (1|M0)               r17.9<1>:d    r4.10<0;1,0>:d                                        //  ALU pipe: int; $43
(W)     mov (1|M0)               r17.10<1>:d   r4.11<0;1,0>:d                                        //  ALU pipe: int; $44
(W)     mov (1|M0)               r17.11<1>:d   r4.12<0;1,0>:d                                        //  ALU pipe: int; $45
(W)     mov (1|M0)               r17.12<1>:d   r4.13<0;1,0>:d                                        //  ALU pipe: int; $46
(W)     mov (1|M0)               r17.13<1>:d   r4.14<0;1,0>:d                                        //  ALU pipe: int; $47
(W)     mov (1|M0)               r17.14<1>:d   r4.15<0;1,0>:d                                        //  ALU pipe: int; $48
(W)     mov (1|M0)               r17.15<1>:d   r5.0<0;1,0>:d                                         //  ALU pipe: int; $49
(W)     mov (1|M0)               r18.0<1>:d    r5.1<0;1,0>:d                    {Compacted}          //  ALU pipe: int; $50
(W)     mov (1|M0)               r18.1<1>:d    r5.2<0;1,0>:d                                         //  ALU pipe: int; $51
(W)     mov (1|M0)               r18.2<1>:d    r5.3<0;1,0>:d                                         //  ALU pipe: int; $52
(W)     mov (1|M0)               r18.3<1>:d    r5.4<0;1,0>:d                                         //  ALU pipe: int; $53
(W)     mov (1|M0)               r18.4<1>:d    r5.5<0;1,0>:d                                         //  ALU pipe: int; $54
(W)     mov (1|M0)               r18.5<1>:d    r5.6<0;1,0>:d                                         //  ALU pipe: int; $55
(W)     mov (1|M0)               r20.0<1>:ud   0x0:uw                                                //  ALU pipe: int; $69
(W)     mov (2|M0)               r21.0<1>:d    r7.2<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $72
(W)     mov (2|M0)               r21.2<1>:d    r7.4<1;1,0>:d                                         //  ALU pipe: int; $73
(W)     mov (2|M0)               r21.4<1>:d    r7.6<1;1,0>:d                                         //  ALU pipe: int; $74
(W)     mov (2|M0)               r21.6<1>:d    r7.8<1;1,0>:d                                         //  ALU pipe: int; $75
(W)     mov (2|M0)               r21.8<1>:d    r7.10<1;1,0>:d                                        //  ALU pipe: int; $76
(W)     mov (2|M0)               r21.10<1>:d   r7.12<1;1,0>:d                                        //  ALU pipe: int; $77
(W)     mov (2|M0)               r21.12<1>:d   r7.14<1;1,0>:d                                        //  ALU pipe: int; $78
(W)     mov (1|M0)               r21.14<1>:d   r8.0<0;1,0>:d                                         //  ALU pipe: int; $86
(W)     mov (1|M0)               r21.15<1>:d   r8.1<0;1,0>:d                                         //  ALU pipe: int; $87
(W)     mov (1|M0)               r22.0<1>:ud   0x100:uw                                              //  ALU pipe: int; $88
(W)     mov (1|M0)               r23.0<1>:ud   0x140:uw                                              //  ALU pipe: int; $99
(W)     mov (1|M0)               r25.0<1>:ud   0x160:uw                                              //  ALU pipe: int; $107
(W)     mov (2|M0)               r27.10<1>:d   r9.8<1;1,0>:d                                         //  ALU pipe: int; $111
(W)     mov (2|M0)               r27.12<1>:d   r9.10<1;1,0>:d                                        //  ALU pipe: int; $112
(W)     mov (2|M0)               r27.14<1>:d   r9.12<1;1,0>:d                                        //  ALU pipe: int; $113
(W)     mov (2|M0)               r28.0<1>:d    r9.14<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $114
(W)     mov (2|M0)               r28.4<1>:d    r10.8<1;1,0>:d                                        //  ALU pipe: int; $115
(W)     mov (2|M0)               r28.6<1>:d    r10.10<1;1,0>:d                                       //  ALU pipe: int; $116
(W)     mov (2|M0)               r28.8<1>:d    r10.12<1;1,0>:d                                       //  ALU pipe: int; $117
(W)     mov (2|M0)               r28.10<1>:d   r10.14<1;1,0>:d                                       //  ALU pipe: int; $118
(W)     mov (2|M0)               r28.12<1>:d   r11.0<1;1,0>:d                   {$3.dst}             //  ALU pipe: int; $119
(W)     mov (2|M0)               r28.14<1>:d   r11.2<1;1,0>:d                                        //  ALU pipe: int; $120
(W)     mov (2|M0)               r29.0<1>:d    r11.4<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $121
(W)     mov (2|M0)               r29.2<1>:d    r11.6<1;1,0>:d                                        //  ALU pipe: int; $122
(W)     mov (2|M0)               r29.4<1>:d    r11.8<1;1,0>:d                                        //  ALU pipe: int; $123
(W)     mov (2|M0)               r29.6<1>:d    r11.10<1;1,0>:d                                       //  ALU pipe: int; $124
(W)     mov (2|M0)               r29.8<1>:d    r11.12<1;1,0>:d                                       //  ALU pipe: int; $125
(W)     mov (2|M0)               r29.10<1>:d   r11.14<1;1,0>:d                                       //  ALU pipe: int; $126
(W)     mov (2|M0)               r29.12<1>:d   r12.0<1;1,0>:d                                        //  ALU pipe: int; $127
(W)     mov (2|M0)               r29.14<1>:d   r12.2<1;1,0>:d                                        //  ALU pipe: int; $128
(W)     mov (2|M0)               r30.0<1>:d    r12.4<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $129
(W)     mov (2|M0)               r30.2<1>:d    r12.6<1;1,0>:d                                        //  ALU pipe: int; $130
(W)     mov (2|M0)               r30.4<1>:d    r12.8<1;1,0>:d                                        //  ALU pipe: int; $131
(W)     mov (2|M0)               r30.6<1>:d    r12.10<1;1,0>:d                                       //  ALU pipe: int; $132
(W)     mov (2|M0)               r30.8<1>:d    r12.12<1;1,0>:d                                       //  ALU pipe: int; $133
(W)     mov (2|M0)               r30.10<1>:d   r12.14<1;1,0>:d                                       //  ALU pipe: int; $134
(W)     mov (2|M0)               r30.12<1>:d   r13.0<1;1,0>:d                   {$4.dst}             //  ALU pipe: int; $135
(W)     mov (2|M0)               r30.14<1>:d   r13.2<1;1,0>:d                                        //  ALU pipe: int; $136
(W)     mov (1|M0)               r27.0<1>:d    r8.14<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $137
(W)     mov (1|M0)               r27.1<1>:d    r8.15<0;1,0>:d                                        //  ALU pipe: int; $138
(W)     mov (1|M0)               r27.2<1>:d    r9.0<0;1,0>:d                    {Compacted}          //  ALU pipe: int; $139
(W)     mov (1|M0)               r27.3<1>:d    r9.1<0;1,0>:d                                         //  ALU pipe: int; $140
(W)     mov (1|M0)               r27.4<1>:d    r9.2<0;1,0>:d                                         //  ALU pipe: int; $141
(W)     mov (1|M0)               r27.5<1>:d    r9.3<0;1,0>:d                                         //  ALU pipe: int; $142
(W)     mov (1|M0)               r27.6<1>:d    r9.4<0;1,0>:d                                         //  ALU pipe: int; $143
(W)     mov (1|M0)               r27.7<1>:d    r9.5<0;1,0>:d                                         //  ALU pipe: int; $144
(W)     mov (1|M0)               r27.8<1>:d    r9.6<0;1,0>:d                                         //  ALU pipe: int; $145
(W)     mov (1|M0)               r27.9<1>:d    r9.7<0;1,0>:d                                         //  ALU pipe: int; $146
(W)     mov (1|M0)               r28.8<2>:b    r10.0<0;1,0>:b                   {Atomic}             //  ALU pipe: int; $151
(W)     mov (1|M0)               r28.9<2>:b    r10.4<0;1,0>:b                   {Atomic}             // $152
(W)     mov (1|M0)               r28.10<2>:b   r10.8<0;1,0>:b                   {Atomic}             // $153
(W)     mov (1|M0)               r28.11<2>:b   r10.12<0;1,0>:b                  {Atomic}             // $154
(W)     mov (1|M0)               r28.12<2>:b   r10.16<0;1,0>:b                  {Atomic}             // $155
(W)     mov (1|M0)               r28.13<2>:b   r10.20<0;1,0>:b                  {Atomic}             // $156
(W)     mov (1|M0)               r28.14<2>:b   r10.24<0;1,0>:b                  {Atomic}             // $157
(W)     mov (1|M0)               r28.15<2>:b   r10.28<0;1,0>:b                                       // $158
(W)     mov (1|M0)               r31.0<1>:ud   0x170:uw                                              //  ALU pipe: int; $181
(W)     mov (2|M0)               r32.0<1>:d    r13.4<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $184
(W)     mov (2|M0)               r32.2<1>:d    r13.6<1;1,0>:d                                        //  ALU pipe: int; $185
(W)     mov (2|M0)               r32.4<1>:d    r13.8<1;1,0>:d                                        //  ALU pipe: int; $186
(W)     mov (2|M0)               r32.6<1>:d    r13.10<1;1,0>:d                                       //  ALU pipe: int; $187
(W)     mov (2|M0)               r32.8<1>:d    r13.12<1;1,0>:d                                       //  ALU pipe: int; $188
(W)     mov (2|M0)               r32.10<1>:d   r13.14<1;1,0>:d                                       //  ALU pipe: int; $189
(W)     mov (2|M0)               r32.12<1>:d   r14.0<1;1,0>:d                                        //  ALU pipe: int; $190
(W)     mov (2|M0)               r32.14<1>:d   r14.2<1;1,0>:d                                        //  ALU pipe: int; $191
(W)     mov (1|M0)               r33.0<1>:ud   0x270:uw                                              //  ALU pipe: int; $200
(W)     mov (2|M0)               r34.0<1>:d    r14.4<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $203
(W)     mov (2|M0)               r34.2<1>:d    r14.6<1;1,0>:d                                        //  ALU pipe: int; $204
(W)     mov (1|M0)               r35.0<1>:ud   0x2B0:uw                                              //  ALU pipe: int; $207
(W)     mov (8|M0)               r24.0<1>:d    r2.8<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $100
(W)     mov (4|M0)               r26.0<1>:d    r14.8<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $108
(W)     store.ugm.d32x64t.a32.wb.wb (1|M0)  ss[a0.0][r20:1] r16:4  {$6} // ex_desc:a0.0; desc:0x420EF504 //  address space: private; ; $71
(W)     store.ugm.d32x16t.a32.wb.wb (1|M0)  ss[a0.0][r22:1] r21:1  {$7} // ex_desc:a0.0; desc:0x420ED504 //  address space: private; ; $90
(W)     store.ugm.d32x8t.a32.wb.wb (1|M0)  ss[a0.0][r23:1] r24:1   {I@2,$8} // ex_desc:a0.0; desc:0x420EC504 //  address space: private; ; $102
(W)     store.ugm.d32x4t.a32.wb.wb (1|M0)  ss[a0.0][r25:1] r26:1   {I@1,$9} // ex_desc:a0.0; desc:0x420EB504 //  address space: private; ; $110
(W)     store.ugm.d32x64t.a32.wb.wb (1|M0)  ss[a0.0][r31:1] r27:4  {$10} // ex_desc:a0.0; desc:0x420EF504 //  address space: private; ; $183
(W)     store.ugm.d32x16t.a32.wb.wb (1|M0)  ss[a0.0][r33:1] r32:1  {$11} // ex_desc:a0.0; desc:0x420ED504 //  address space: private; ; $202
(W)     store.ugm.d32x4t.a32.wb.wb (1|M0)  ss[a0.0][r35:1] r34:1   {$12} // ex_desc:a0.0; desc:0x420EB504 //  address space: private; ; $209
(W)     mov (1|M0)               r36.0<1>:ud   0x8C:uw                                               //  ALU pipe: int; $210
(W)     load.ugm.d32x3t.a32.ca.ca (1|M0)  r37:1 ss[a0.0][r36:1]    {I@1,$13} // ex_desc:a0.0; desc:0x4218A500 // $212
(W)     add3 (1|M0)              r5.7<1>:d     r37.0<0;0>:d      r37.1<0;0>:d      r37.2<0>:d       {$13.dst} //  ALU pipe: int; $213
(W)     shl (1|M0)               r14.12<1>:d   r5.7<0;1,0>:d     3:w               {I@1}             //  ALU pipe: int; $214
(W)     add (1|M0)               r38.0<1>:d    r14.12<0;1,0>:d   472:w               {Compacted,I@1} //  ALU pipe: int; $215
(W)     load.ugm.d64x1t.a32.ca.ca (1|M0)  r39:1 ss[a0.0][r38:1]    {I@1,$14} // ex_desc:a0.0; desc:0x42188700 // $217
(W)     mov (1|M0)               r40.0<1>:uq   r39.0<0;1,0>:uq                  {Compacted,$14.dst}  //  ALU pipe: int; $218
(W)     load.ugm.d32x1t.a64 (1|M0)  r41:1       [r40:1]            {I@1,$15} // ex_desc:0x0; desc:0x2108580 // $219
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r41.0<0;1,0>:d    0:w               {$15.dst}         //  ALU pipe: int; $220
(W&f1.0) jmpi                                _0_006                                                  //  ALU pipe: int; $221
// B003: Preds:{B002},  Succs:{B004, B009}
_0_007:
        sync.allrd                           ($7,$8,$9,$10,$11,$12)                                  // $224
(W)     shr (1|M0)               a0.0<1>:ud    r15.5<0;1,0>:ud   0x4:uw              {$6.src}        //  ALU pipe: int; $224
(W)     add (1|M0)               r42.0<1>:d    r14.12<0;1,0>:d   456:w               {Compacted}     //  ALU pipe: int; $223
        mov (32|M0)              r49.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $229
(W)     load.ugm.d64x1t.a32.ca.ca (1|M0)  r43:1 ss[a0.0][r42:1]    {I@2,$1} // ex_desc:a0.0; desc:0x42188700 // $225
(W)     mov (1|M0)               r44.0<1>:uq   r43.0<0;1,0>:uq                  {Compacted,$1.dst}   //  ALU pipe: int; $226
        mov (16|M0)              r45.0<2>:f    r44.0<0;1,0>:f                   {I@1}                //  ALU pipe: float; $227
        mov (16|M16)             r47.0<2>:f    r44.0<0;1,0>:f                                        //  ALU pipe: float; $227
        mov (16|M0)              r45.1<2>:f    r44.1<0;1,0>:f                                        //  ALU pipe: float; $228
        mov (16|M16)             r47.1<2>:f    r44.1<0;1,0>:f                                        //  ALU pipe: float; $228
        atomic_or.ugm.d32.a64 (32|M0)  r51:2    [r45:4]           r49:2              {F@1,$2} // ex_desc:0x0; desc:0x8200599 // $230
        cmp (32|M0)   (eq)f0.0   null<1>:d     r51.0<1;1,0>:d    0:w               {$2.dst}          //  ALU pipe: int; $232
(~f0.0) goto (32|M0)                         _0_006            _0_006                                //  ALU pipe: int; $233
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B006}
_0_008:
(W)     shr (1|M0)               a0.0<1>:ud    r15.5<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $239
(W)     add (1|M0)               r56.0<1>:d    r14.12<0;1,0>:d   448:w               {Compacted}     //  ALU pipe: int; $238
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r15.2<0;1,0>:uw                     //  ALU pipe: int; $235
(W)     macl (1|M0)              r53.0<1>:d    r2.3<0;1,0>:d     r15.1<0;1,0>:d   {Compacted}        //  ALU pipe: int; $237
(W)     load.ugm.d64x1t.a32.ca.ca (1|M0)  r57:1 ss[a0.0][r56:1]    {I@3,$3} // ex_desc:a0.0; desc:0x42188700 // $240
        add3 (32|M0)             r54.0<1>:d    r53.0<0;0>:d      r1.0<1;0>:uw      r2.0<0>:d        {@1,$0.dst} //  ALU pipe: int; $237
        mov (16|M0)              r100.0<2>:ud  r54.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $287
        mov (16|M16)             r102.0<2>:ud  r55.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $287
        shl (16|M0)              r104.0<1>:q   r100.0<2;1,0>:ud  2:w               {I@2}             //  ALU pipe: int; $287
(W)     add (1|M0)               r58.0<1>:q    r57.0<0;1,0>:q    128:w               {Compacted,$3.dst} //  ALU pipe: int; $241
(W)     add (1|M0)               r60.0<1>:q    r57.0<0;1,0>:q    160:w               {Compacted}     //  ALU pipe: int; $245
(W)     add (1|M0)               r62.0<1>:q    r57.0<0;1,0>:q    192:w               {Compacted}     //  ALU pipe: int; $248
(W)     add (1|M0)               r64.0<1>:q    r57.0<0;1,0>:q    224:w               {Compacted}     //  ALU pipe: int; $251
(W)     load.ugm.d32x8t.a64 (1|M0)  r59:1       [r58:1]            {I@4,$4} // ex_desc:0x0; desc:0x210C580 // $244
(W)     load.ugm.d32x8t.a64 (1|M0)  r61:1       [r60:1]            {I@3,$5} // ex_desc:0x0; desc:0x210C580 // $247
(W)     load.ugm.d32x8t.a64 (1|M0)  r63:1       [r62:1]            {I@2,$13} // ex_desc:0x0; desc:0x210C580 // $250
(W)     load.ugm.d32x8t.a64 (1|M0)  r65:1       [r64:1]            {I@1,$14} // ex_desc:0x0; desc:0x210C580 // $253
        shl (16|M16)             r106.0<1>:q   r102.0<2;1,0>:ud  2:w                                 //  ALU pipe: int; $287
(W)     add (1|M0)               r14.7<1>:q    r57.0<0;1,0>:q    256:w                               //  ALU pipe: int; $242
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $291
        add (16|M0)              r66.0<1>:q    r14.7<0;1,0>:q    r104.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $288
        add (16|M16)             r68.0<1>:q    r14.7<0;1,0>:q    r106.0<1;1,0>:q  {Compacted}        //  ALU pipe: int; $288
        load.ugm.d32.a64 (32|M0)  r70:2         [r66:4]            {I@1,$15} // ex_desc:0x0; desc:0x8200580 // $290
(W)     add (1|M0)               r20.1<1>:q    r57.0<0;1,0>:q    2304:w                              //  ALU pipe: int; $285
(W)     add (1|M0)               r95.0<1>:f    r59.0<0;1,0>:f    r59.1<0;1,0>:f   {Compacted,$4.dst} //  ALU pipe: float; $254
(W)     add (1|M0)               r96.0<1>:f    r59.2<0;1,0>:f    r59.3<0;1,0>:f   {Compacted}        //  ALU pipe: float; $255
(W)     add (1|M0)               r95.1<1>:f    r59.4<0;1,0>:f    r59.5<0;1,0>:f                      //  ALU pipe: float; $256
(W)     add (1|M0)               r96.1<1>:f    r59.6<0;1,0>:f    r59.7<0;1,0>:f                      //  ALU pipe: float; $257
(W)     add (1|M0)               r95.2<1>:f    r61.0<0;1,0>:f    r61.1<0;1,0>:f   {Compacted,$5.dst} //  ALU pipe: float; $258
(W)     add (1|M0)               r96.2<1>:f    r61.2<0;1,0>:f    r61.3<0;1,0>:f                      //  ALU pipe: float; $259
(W)     add (1|M0)               r95.3<1>:f    r61.4<0;1,0>:f    r61.5<0;1,0>:f                      //  ALU pipe: float; $260
(W)     add (1|M0)               r96.3<1>:f    r61.6<0;1,0>:f    r61.7<0;1,0>:f                      //  ALU pipe: float; $261
(W)     add (1|M0)               r98.0<1>:f    r63.0<0;1,0>:f    r63.1<0;1,0>:f   {Compacted,$13.dst} //  ALU pipe: float; $262
(W)     add (1|M0)               r99.0<1>:f    r63.2<0;1,0>:f    r63.3<0;1,0>:f   {Compacted}        //  ALU pipe: float; $263
(W)     add (1|M0)               r98.1<1>:f    r63.4<0;1,0>:f    r63.5<0;1,0>:f                      //  ALU pipe: float; $264
(W)     add (1|M0)               r99.1<1>:f    r63.6<0;1,0>:f    r63.7<0;1,0>:f                      //  ALU pipe: float; $265
(W)     add (1|M0)               r98.2<1>:f    r65.0<0;1,0>:f    r65.1<0;1,0>:f   {Compacted,$14.dst} //  ALU pipe: float; $266
(W)     add (1|M0)               r99.2<1>:f    r65.2<0;1,0>:f    r65.3<0;1,0>:f                      //  ALU pipe: float; $267
(W)     add (1|M0)               r98.3<1>:f    r65.4<0;1,0>:f    r65.5<0;1,0>:f                      //  ALU pipe: float; $268
(W)     add (1|M0)               r99.3<1>:f    r65.6<0;1,0>:f    r65.7<0;1,0>:f                      //  ALU pipe: float; $269
(W)     add (4|M0)               r94.0<1>:f    r95.0<1;1,0>:f    r96.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $270
(W)     add (4|M0)               r97.0<1>:f    r98.0<1;1,0>:f    r99.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $274
(W)     add (1|M0)               r20.8<1>:f    r94.0<0;1,0>:f    r94.1<0;1,0>:f   {F@2}              //  ALU pipe: float; $278
(W)     add (1|M0)               r20.12<1>:f   r94.2<0;1,0>:f    r94.3<0;1,0>:f                      //  ALU pipe: float; $279
(W)     add (1|M0)               r20.9<1>:f    r97.0<0;1,0>:f    r97.1<0;1,0>:f   {F@3}              //  ALU pipe: float; $280
(W)     add (1|M0)               r20.13<1>:f   r97.2<0;1,0>:f    r97.3<0;1,0>:f                      //  ALU pipe: float; $281
(W)     add (1|M0)               r20.4<1>:f    r20.8<0;1,0>:f    r20.12<0;1,0>:f  {F@3}              //  ALU pipe: float; $282
(W)     add (1|M0)               r20.5<1>:f    r20.9<0;1,0>:f    r20.13<0;1,0>:f  {F@2}              //  ALU pipe: float; $282
(W)     add (1|M0)               r14.13<1>:f   r20.4<0;1,0>:f    r20.5<0;1,0>:f   {F@1}              //  ALU pipe: float; $284
        mov (32|M0)              r76.0<1>:f    r14.13<0;1,0>:f                  {Compacted,F@1}      //  ALU pipe: float; $291
        math.invm (16|M0) (eo)f2.0  r80.mme0:f  r70.nomme<1;1,0>:f  r76.nomme<1;1,0>:f {@1,$15.dst}  //  ALU pipe: math; $291
(f2.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $291
// B005: [inDivergent],  Preds:{B004},  Succs:{B006}
_L_k0_2_:
        madm (16|M0)             r82.mme1:f    r88.nomme:f       r70.nomme:f       r80.mme0:f       {M@1} //  ALU pipe: float; $291 R{} IR{}{E:4,E:3,E:0,},  {BC=1}
        madm (16|M0)             r84.mme2:f    r89.nomme:f       -r76.nomme:f      r80.mme0:f        //  ALU pipe: float; $291
        madm (16|M0)             r74.mme3:f    r80.mme0:f        r84.mme2:f        r80.mme0:f       {F@1} //  ALU pipe: float; $291
        madm (16|M0)             r86.mme4:f    r70.nomme:f       -r76.nomme:f      r82.mme1:f        //  ALU pipe: float; $291 R{} IR{}{E:3,E:6,E:1,},  {BC=1}
        madm (16|M0)             r82.mme5:f    r82.mme1:f        r86.mme4:f        r74.mme3:f       {F@1} //  ALU pipe: float; $291 R{} IR{}{E:1,E:3,E:5,},  {BC=1}
        madm (16|M0)             r78.mme6:f    r70.nomme:f       -r76.nomme:f      r82.mme5:f       {F@1} //  ALU pipe: float; $291 R{} IR{}{E:3,E:6,E:1,},  {BC=1}
        madm (16|M0)             r80.nomme:f   r82.mme5:f        r78.mme6:f        r74.mme3:f       {F@1} //  ALU pipe: float; $291 R{} IR{}{E:1,E:7,E:5,},  {BC=1}
// B006: [inDivergent],  Preds:{B005, B004},  Succs:{B007, B008}
_L_k0_0_macro:
        join (32|M0)                         _0_006                                                  // 
L3648:
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $291
        math.invm (16|M16) (eo)f2.0  r81.mme0:f  r71.nomme<1;1,0>:f  r77.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $291
(f2.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $291
// B007: [inDivergent],  Preds:{B006},  Succs:{B008}
_L_k0_3_:
        madm (16|M16)            r83.mme1:f    r88.nomme:f       r71.nomme:f       r81.mme0:f       {M@1} //  ALU pipe: float; $291
        madm (16|M16)            r85.mme2:f    r89.nomme:f       -r77.nomme:f      r81.mme0:f        //  ALU pipe: float; $291
        madm (16|M16)            r75.mme3:f    r81.mme0:f        r85.mme2:f        r81.mme0:f       {F@1} //  ALU pipe: float; $291
        madm (16|M16)            r87.mme4:f    r71.nomme:f       -r77.nomme:f      r83.mme1:f        //  ALU pipe: float; $291 R{} IR{}{O:3,O:6,O:1,},  {BC=1}
        madm (16|M16)            r83.mme5:f    r83.mme1:f        r87.mme4:f        r75.mme3:f       {F@1} //  ALU pipe: float; $291 R{} IR{}{O:1,O:3,O:5,},  {BC=1}
        madm (16|M16)            r79.mme6:f    r71.nomme:f       -r77.nomme:f      r83.mme5:f       {F@1} //  ALU pipe: float; $291 R{} IR{}{O:3,O:6,O:1,},  {BC=1}
        madm (16|M16)            r81.nomme:f   r83.mme5:f        r79.mme6:f        r75.mme3:f       {F@1} //  ALU pipe: float; $291 R{} IR{}{O:1,O:7,O:5,},  {BC=1}
// B008: [inDivergent],  Preds:{B007, B006},  Succs:{B009}
_L_k0_1_macro:
        join (32|M0)                         _0_006                                                  // 
L3824:
        mov (32|M0)              r72.0<1>:ud   r80.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $291
        add (16|M0)              r90.0<1>:q    r20.1<0;1,0>:q    r104.0<1;1,0>:q  {Compacted}        //  ALU pipe: int; $292
        add (16|M16)             r92.0<1>:q    r20.1<0;1,0>:q    r106.0<1;1,0>:q  {Compacted}        //  ALU pipe: int; $292
        store.ugm.d32.a64 (32|M0)  [r90:4]      r72:2              {I@1,$6} // ex_desc:0x0; desc:0x8000584 // $294
// B009: Preds:{B008, B003, B002},  Succs:{}
_0_006:
        join (32|M0)                         L3880                                                   // 
L3880:
(W)     mov (16|M0)              r127.0<1>:f   r15.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $296
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$7} // wr:1+0, rd:0; end of thread // $296
L3904:
(W)     mov (16|M0)              null<1>:ud    0x9BA73454:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xE55156EA:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x9:ud                                                // 


//.BankConflicts: 9
//.ByteRMWs: 12
//


//.numALUInst: 237
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 34
//.allAtOneDistNum: 3
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 17
//.AfterReadTokenDepCount: 8
