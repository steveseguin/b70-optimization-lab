//.kernel _ZTSN4sycl3_V16detail18RoundedRangeKernelINS0_4itemILi1ELb1EEELi1EZZNK8packet1812_GLOBAL__N_19SimpleNewILN10integrated2OpE8ELi0ELi512ELi10EE6submitERNS0_5queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS0_5eventESaISI_EEENKUlRNS0_7handlerEE_clESO_EUlNS0_2idILi1EEEE_EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 2611426388 3847313130 -hashmovs1 0 4 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 2611426388 3847313130 -hashmovs1 0 4 -GRFBumpUpNumber 2 "
//.instCount 544
//.RA type	LOCAL_FIRST_FIT_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 3
//.spill flag load 3
//.private memory size 22528

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r56.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.1)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.2)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.13)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.14)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.15)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r56.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r56.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r14.10)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=1 type=b align=2 words (r3.0)
//.declare V0045 (55)  rf=r size=1 type=b align=2 words (r3.4)
//.declare V0046 (56)  rf=r size=1 type=b align=2 words (r3.8)
//.declare V0047 (57)  rf=r size=1 type=b align=2 words (r3.12)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.8)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r3.9)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r3.10)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r3.11)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r3.12)
//.declare V0057 (67)  rf=r size=4 type=d align=2 words (r3.13)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r3.15)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0061 (71)  rf=r size=4 type=d align=2 words (r4.1)
//.declare V0062 (72)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0063 (73)  rf=r size=4 type=d align=2 words (r4.3)
//.declare V0064 (74)  rf=r size=4 type=d align=2 words (r4.4)
//.declare V0065 (75)  rf=r size=4 type=d align=2 words (r4.5)
//.declare V0066 (76)  rf=r size=4 type=d align=2 words (r4.6)
//.declare V0067 (77)  rf=r size=4 type=d align=2 words (r4.7)
//.declare V0068 (78)  rf=r size=4 type=d align=2 words (r4.8)
//.declare V0069 (79)  rf=r size=4 type=d align=2 words (r4.9)
//.declare V0070 (80)  rf=r size=4 type=d align=2 words (r4.10)
//.declare V0071 (81)  rf=r size=4 type=d align=2 words (r4.11)
//.declare V0072 (82)  rf=r size=4 type=d align=2 words (r4.12)
//.declare V0073 (83)  rf=r size=4 type=d align=2 words (r4.13)
//.declare V0074 (84)  rf=r size=4 type=d align=2 words (r4.14)
//.declare V0075 (85)  rf=r size=4 type=d align=2 words (r4.15)
//.declare V0076 (86)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0077 (87)  rf=r size=4 type=d align=2 words (r5.1)
//.declare V0078 (88)  rf=r size=4 type=d align=2 words (r5.2)
//.declare V0079 (89)  rf=r size=4 type=d align=2 words (r5.3)
//.declare V0080 (90)  rf=r size=4 type=d align=2 words (r5.4)
//.declare V0081 (91)  rf=r size=4 type=d align=2 words (r5.5)
//.declare V0082 (92)  rf=r size=4 type=d align=2 words (r5.6)
//.declare V0083 (93)  rf=r size=4 type=d align=2 words (r5.7)
//.declare V0084 (94)  rf=r size=4 type=d align=2 words (r5.8)
//.declare V0085 (95)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0086 (96)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0087 (97)  rf=r size=8 type=q align=4 words (r5.7)
//.declare V0088 (98)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0089 (99)  rf=r size=8 type=q align=4 words (r6.1)
//.declare V0090 (100)  rf=r size=8 type=q align=4 words (r6.2)
//.declare V0091 (101)  rf=r size=8 type=q align=4 words (r6.3)
//.declare V0092 (102)  rf=r size=8 type=q align=4 words (r6.4)
//.declare V0093 (103)  rf=r size=8 type=q align=4 words (r6.5)
//.declare V0094 (104)  rf=r size=8 type=q align=4 words (r6.6)
//.declare V0095 (105)  rf=r size=8 type=q align=4 words (r6.7)
//.declare V0096 (106)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0097 (107)  rf=r size=8 type=q align=4 words (r7.1)
//.declare V0098 (108)  rf=r size=8 type=q align=4 words (r7.2)
//.declare V0099 (109)  rf=r size=8 type=q align=4 words (r7.3)
//.declare V0100 (110)  rf=r size=8 type=q align=4 words (r7.4)
//.declare V0101 (111)  rf=r size=8 type=q align=4 words (r7.5)
//.declare V0102 (112)  rf=r size=8 type=q align=4 words (r7.6)
//.declare V0103 (113)  rf=r size=8 type=q align=4 words (r7.7)
//.declare V0104 (114)  rf=r size=8 type=q align=4 words (r8.0)
//.declare V0105 (115)  rf=r size=4 type=d align=2 words (r8.2)
//.declare V0106 (116)  rf=r size=4 type=d align=2 words (r8.3)
//.declare V0107 (117)  rf=r size=4 type=d align=2 words (r8.4)
//.declare V0108 (118)  rf=r size=4 type=d align=2 words (r8.5)
//.declare V0109 (119)  rf=r size=4 type=d align=2 words (r8.6)
//.declare V0110 (120)  rf=r size=4 type=d align=2 words (r8.7)
//.declare V0111 (121)  rf=r size=4 type=d align=2 words (r8.8)
//.declare V0112 (122)  rf=r size=4 type=d align=2 words (r8.9)
//.declare V0113 (123)  rf=r size=4 type=d align=2 words (r8.10)
//.declare V0114 (124)  rf=r size=4 type=d align=2 words (r8.11)
//.declare V0115 (125)  rf=r size=4 type=d align=2 words (r8.12)
//.declare V0116 (126)  rf=r size=4 type=d align=2 words (r8.13)
//.declare V0117 (127)  rf=r size=4 type=d align=2 words (r8.14)
//.declare V0118 (128)  rf=r size=4 type=d align=2 words (r8.15)
//.declare V0119 (129)  rf=r size=4 type=d align=2 words (r9.0)
//.declare V0120 (130)  rf=r size=4 type=d align=2 words (r9.1)
//.declare V0121 (131)  rf=r size=4 type=d align=2 words (r9.2)
//.declare V0122 (132)  rf=r size=4 type=d align=2 words (r9.3)
//.declare V0123 (133)  rf=r size=4 type=d align=2 words (r9.4)
//.declare V0124 (134)  rf=r size=4 type=d align=2 words (r9.5)
//.declare V0125 (135)  rf=r size=4 type=d align=2 words (r9.6)
//.declare V0126 (136)  rf=r size=4 type=d align=2 words (r9.7)
//.declare V0127 (137)  rf=r size=4 type=d align=2 words (r9.8)
//.declare V0128 (138)  rf=r size=4 type=d align=2 words (r9.9)
//.declare V0129 (139)  rf=r size=8 type=q align=4 words (r9.5)
//.declare V0130 (140)  rf=r size=8 type=q align=4 words (r9.6)
//.declare V0131 (141)  rf=r size=8 type=q align=4 words (r9.7)
//.declare V0132 (142)  rf=r size=8 type=q align=4 words (r10.0)
//.declare V0133 (143)  rf=r size=1 type=b align=2 words (r10.8)
//.declare V0134 (144)  rf=r size=1 type=b align=2 words (r10.12)
//.declare V0135 (145)  rf=r size=1 type=b align=2 words (r10.16)
//.declare V0136 (146)  rf=r size=1 type=b align=2 words (r10.20)
//.declare V0137 (147)  rf=r size=1 type=b align=2 words (r10.24)
//.declare V0138 (148)  rf=r size=1 type=b align=2 words (r10.28)
//.declare V0139 (149)  rf=r size=1 type=b align=2 words (r10.32)
//.declare V0140 (150)  rf=r size=1 type=b align=2 words (r10.36)
//.declare V0141 (151)  rf=r size=8 type=q align=4 words (r10.5)
//.declare V0142 (152)  rf=r size=8 type=q align=4 words (r10.6)
//.declare V0143 (153)  rf=r size=8 type=q align=4 words (r10.7)
//.declare V0144 (154)  rf=r size=8 type=q align=4 words (r11.0)
//.declare V0145 (155)  rf=r size=8 type=q align=4 words (r11.1)
//.declare V0146 (156)  rf=r size=8 type=q align=4 words (r11.2)
//.declare V0147 (157)  rf=r size=8 type=q align=4 words (r11.3)
//.declare V0148 (158)  rf=r size=8 type=q align=4 words (r11.4)
//.declare V0149 (159)  rf=r size=8 type=q align=4 words (r11.5)
//.declare V0150 (160)  rf=r size=8 type=q align=4 words (r11.6)
//.declare V0151 (161)  rf=r size=8 type=q align=4 words (r11.7)
//.declare V0152 (162)  rf=r size=8 type=q align=4 words (r12.0)
//.declare V0153 (163)  rf=r size=8 type=q align=4 words (r12.1)
//.declare V0154 (164)  rf=r size=8 type=q align=4 words (r12.2)
//.declare V0155 (165)  rf=r size=8 type=q align=4 words (r12.3)
//.declare V0156 (166)  rf=r size=8 type=q align=4 words (r12.4)
//.declare V0157 (167)  rf=r size=8 type=q align=4 words (r12.5)
//.declare V0158 (168)  rf=r size=8 type=q align=4 words (r12.6)
//.declare V0159 (169)  rf=r size=8 type=q align=4 words (r12.7)
//.declare V0160 (170)  rf=r size=8 type=q align=4 words (r13.0)
//.declare V0161 (171)  rf=r size=8 type=q align=4 words (r13.1)
//.declare V0162 (172)  rf=r size=8 type=q align=4 words (r13.2)
//.declare V0163 (173)  rf=r size=8 type=q align=4 words (r13.3)
//.declare V0164 (174)  rf=r size=8 type=q align=4 words (r13.4)
//.declare V0165 (175)  rf=r size=8 type=q align=4 words (r13.5)
//.declare V0166 (176)  rf=r size=8 type=q align=4 words (r13.6)
//.declare V0167 (177)  rf=r size=8 type=q align=4 words (r13.7)
//.declare V0168 (178)  rf=r size=8 type=q align=4 words (r14.0)
//.declare V0169 (179)  rf=r size=8 type=q align=4 words (r14.1)
//.declare V0170 (180)  rf=r size=8 type=q align=4 words (r14.2)
//.declare V0171 (181)  rf=r size=8 type=q align=4 words (r14.3)
//.declare V0172 (182)  rf=r size=8 type=q align=4 words (r14.4)
//.declare V0173 (183)  rf=r size=16 type=d align=2 words (r57.0)
//.declare V0174 (184)  rf=r size=16 type=d align=2 words (r57.4)
//.declare V0175 (185)  rf=r size=16 type=d align=2 words (r57.8)
//.declare V0176 (186)  rf=r size=16 type=d align=2 words (r57.12)
//.declare V0177 (187)  rf=r size=16 type=d align=2 words (r58.0)
//.declare V0178 (188)  rf=r size=16 type=d align=2 words (r58.4)
//.declare V0179 (189)  rf=r size=16 type=d align=2 words (r58.8)
//.declare V0180 (190)  rf=r size=16 type=d align=2 words (r58.12)
//.declare V0181 (191)  rf=r size=16 type=d align=2 words (r59.0)
//.declare V0182 (192)  rf=r size=16 type=d align=2 words (r59.4)
//.declare V0183 (193)  rf=r size=16 type=d align=2 words (r59.8)
//.declare V0184 (194)  rf=r size=16 type=d align=2 words (r59.12)
//.declare V0185 (195)  rf=r size=16 type=d align=2 words (r60.0)
//.declare V0186 (196)  rf=r size=16 type=d align=2 words (r60.4)
//.declare V0187 (197)  rf=r size=16 type=d align=2 words (r60.8)
//.declare V0188 (198)  rf=r size=16 type=d align=2 words (r60.12)
//.declare V0189 (199)  rf=r size=16 type=d align=2 words (r61.0)
//.declare V0190 (200)  rf=r size=16 type=d align=2 words (r61.4)
//.declare V0191 (201)  rf=r size=16 type=d align=2 words (r61.8)
//.declare V0192 (202)  rf=r size=16 type=d align=2 words (r61.12)
//.declare V0193 (203)  rf=r size=16 type=d align=2 words (r62.0)
//.declare V0194 (204)  rf=r size=16 type=d align=2 words (r62.4)
//.declare V0195 (205)  rf=r size=16 type=d align=2 words (r62.8)
//.declare V0196 (206)  rf=r size=16 type=d align=2 words (r62.12)
//.declare V0197 (207)  rf=r size=16 type=d align=2 words (r63.0)
//.declare V0198 (208)  rf=r size=16 type=d align=2 words (r63.4)
//.declare V0199 (209)  rf=r size=8 type=d align=2 words (r63.8)
//.declare V0200 (210)  rf=r size=8 type=d alias=V0043+0 align=32 words (r2.6)
//.declare V0201 (211)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0202 (212)  rf=r size=12 type=ud alias=V0038+0 align=32 words (r2.3)
//.declare V0203 (213)  rf=r size=32 type=ud alias=V0035+0 align=32 words (r56.0)
//.declare V0204 (214)  rf=r size=8 type=ud alias=V0201+0 align=4 words (r2.8)
//.declare V0205 (215)  rf=r size=8 type=d alias=V0201+0 align=4 words (r2.8)
//.declare V0206 (216)  rf=r size=4 type=d align=32 words (r16.0)
//.declare V0209 (219)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0212 (222)  rf=r size=12 type=ud alias=V0036+0 align=32 words (r2.0)
//.declare V0216 (226)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0217 (227)  rf=r size=128 type=d align=32 words (r66.0)
//.declare P01 (228)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0218 (229)  rf=r size=128 type=ud alias=V0216+0 align=32 words (r64.0)
//.declare V0219 (230)  rf=r size=8 type=ud alias=V0199+0 align=2 words (r63.8)
//.declare P02 (231)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P03 (232)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0220 (233)  rf=r size=128 type=ud alias=V0217+0 align=32 words (r66.0)
//.declare V0221 (234)  rf=r size=64 type=w align=32 words (r15.0)
//.declare V0223 (236)  rf=r size=64 type=uw alias=V0221+0 align=32 words (r15.0)
//.declare V0224 (237)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0225 (238)  rf=r size=128 type=ud alias=V0224+0 align=32 words (r68.0)
//.declare V0226 (239)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0227 (240)  rf=r size=128 type=ud alias=V0226+0 align=32 words (r70.0)
//.declare V0228 (241)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0229 (242)  rf=r size=128 type=ud alias=V0228+0 align=32 words (r72.0)
//.declare V0230 (243)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0231 (244)  rf=r size=128 type=ud alias=V0230+0 align=32 words (r74.0)
//.declare V0232 (245)  rf=r size=16 type=b align=32 words (r76.0)
//.declare V0233 (246)  rf=r size=16 type=d alias=V0232+0 align=32 words (r76.0)
//.declare V0234 (247)  rf=r size=16 type=d align=2 words (r63.10)
//.declare V0235 (248)  rf=r size=16 type=d align=2 words (r76.4)
//.declare V0236 (249)  rf=r size=16 type=d align=2 words (r76.8)
//.declare V0237 (250)  rf=r size=16 type=d align=2 words (r76.12)
//.declare V0238 (251)  rf=r size=16 type=d align=2 words (r77.0)
//.declare V0239 (252)  rf=r size=16 type=d align=2 words (r77.4)
//.declare V0240 (253)  rf=r size=16 type=d align=2 words (r77.8)
//.declare V0241 (254)  rf=r size=16 type=d align=2 words (r77.12)
//.declare V0242 (255)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0243 (256)  rf=r size=8 type=d alias=V0085+0 align=32 words (r5.10)
//.declare V0244 (257)  rf=r size=16 type=d align=2 words (r78.0)
//.declare V0245 (258)  rf=r size=8 type=d alias=V0086+0 align=32 words (r5.12)
//.declare V0246 (259)  rf=r size=8 type=d alias=V0087+0 align=32 words (r5.14)
//.declare V0247 (260)  rf=r size=8 type=d alias=V0088+0 align=32 words (r6.0)
//.declare V0248 (261)  rf=r size=8 type=d alias=V0089+0 align=32 words (r6.2)
//.declare V0249 (262)  rf=r size=8 type=d alias=V0090+0 align=32 words (r6.4)
//.declare V0250 (263)  rf=r size=8 type=d alias=V0091+0 align=32 words (r6.6)
//.declare V0251 (264)  rf=r size=8 type=d alias=V0092+0 align=32 words (r6.8)
//.declare V0252 (265)  rf=r size=8 type=d alias=V0093+0 align=32 words (r6.10)
//.declare V0253 (266)  rf=r size=8 type=d alias=V0094+0 align=32 words (r6.12)
//.declare V0254 (267)  rf=r size=8 type=d alias=V0095+0 align=32 words (r6.14)
//.declare V0255 (268)  rf=r size=8 type=d alias=V0096+0 align=32 words (r7.0)
//.declare V0256 (269)  rf=r size=8 type=d alias=V0097+0 align=32 words (r7.2)
//.declare V0257 (270)  rf=r size=8 type=d alias=V0098+0 align=32 words (r7.4)
//.declare V0258 (271)  rf=r size=8 type=d alias=V0099+0 align=32 words (r7.6)
//.declare V0259 (272)  rf=r size=8 type=d alias=V0100+0 align=32 words (r7.8)
//.declare V0260 (273)  rf=r size=8 type=d alias=V0101+0 align=32 words (r7.10)
//.declare V0261 (274)  rf=r size=8 type=d alias=V0102+0 align=32 words (r7.12)
//.declare V0262 (275)  rf=r size=8 type=d alias=V0103+0 align=32 words (r7.14)
//.declare V0263 (276)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0264 (277)  rf=r size=8 type=d alias=V0104+0 align=32 words (r8.0)
//.declare V0265 (278)  rf=r size=16 type=d align=2 words (r78.4)
//.declare V0266 (279)  rf=r size=16 type=d align=2 words (r78.8)
//.declare V0267 (280)  rf=r size=16 type=d align=2 words (r78.12)
//.declare V0268 (281)  rf=r size=16 type=d align=2 words (r79.0)
//.declare V0269 (282)  rf=r size=16 type=d align=2 words (r79.4)
//.declare V0270 (283)  rf=r size=16 type=d align=2 words (r79.8)
//.declare V0271 (284)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0272 (285)  rf=r size=8 type=d alias=V0129+0 align=32 words (r9.10)
//.declare V0273 (286)  rf=r size=16 type=d align=2 words (r79.12)
//.declare V0274 (287)  rf=r size=8 type=d alias=V0130+0 align=32 words (r9.12)
//.declare V0275 (288)  rf=r size=8 type=d alias=V0131+0 align=32 words (r9.14)
//.declare V0276 (289)  rf=r size=8 type=d align=2 words (r14.13)
//.declare V0277 (290)  rf=r size=8 type=d alias=V0132+0 align=32 words (r10.0)
//.declare V0278 (291)  rf=r size=16 type=b align=32 words (r80.0)
//.declare V0279 (292)  rf=r size=16 type=d alias=V0278+0 align=32 words (r80.0)
//.declare V0280 (293)  rf=r size=8 type=d alias=V0141+0 align=32 words (r10.10)
//.declare V0281 (294)  rf=r size=8 type=d alias=V0142+0 align=32 words (r10.12)
//.declare V0282 (295)  rf=r size=8 type=d alias=V0143+0 align=32 words (r10.14)
//.declare V0283 (296)  rf=r size=8 type=d alias=V0144+0 align=32 words (r11.0)
//.declare V0284 (297)  rf=r size=8 type=d alias=V0145+0 align=32 words (r11.2)
//.declare V0285 (298)  rf=r size=8 type=d alias=V0146+0 align=32 words (r11.4)
//.declare V0286 (299)  rf=r size=8 type=d alias=V0147+0 align=32 words (r11.6)
//.declare V0287 (300)  rf=r size=8 type=d alias=V0148+0 align=32 words (r11.8)
//.declare V0288 (301)  rf=r size=8 type=d alias=V0149+0 align=32 words (r11.10)
//.declare V0289 (302)  rf=r size=8 type=d alias=V0150+0 align=32 words (r11.12)
//.declare V0290 (303)  rf=r size=8 type=d alias=V0151+0 align=32 words (r11.14)
//.declare V0291 (304)  rf=r size=8 type=d alias=V0152+0 align=32 words (r12.0)
//.declare V0292 (305)  rf=r size=8 type=d alias=V0153+0 align=32 words (r12.2)
//.declare V0293 (306)  rf=r size=8 type=d alias=V0154+0 align=32 words (r12.4)
//.declare V0294 (307)  rf=r size=8 type=d alias=V0155+0 align=32 words (r12.6)
//.declare V0295 (308)  rf=r size=8 type=d alias=V0156+0 align=32 words (r12.8)
//.declare V0296 (309)  rf=r size=8 type=d alias=V0157+0 align=32 words (r12.10)
//.declare V0297 (310)  rf=r size=8 type=d alias=V0158+0 align=32 words (r12.12)
//.declare V0298 (311)  rf=r size=8 type=d alias=V0159+0 align=32 words (r12.14)
//.declare V0299 (312)  rf=r size=8 type=d alias=V0160+0 align=32 words (r13.0)
//.declare V0300 (313)  rf=r size=8 type=d alias=V0161+0 align=32 words (r13.2)
//.declare V0301 (314)  rf=r size=8 type=d alias=V0162+0 align=32 words (r13.4)
//.declare V0302 (315)  rf=r size=8 type=d alias=V0163+0 align=32 words (r13.6)
//.declare V0303 (316)  rf=r size=8 type=d alias=V0164+0 align=32 words (r13.8)
//.declare V0304 (317)  rf=r size=8 type=d alias=V0165+0 align=32 words (r13.10)
//.declare V0305 (318)  rf=r size=8 type=d alias=V0166+0 align=32 words (r13.12)
//.declare V0306 (319)  rf=r size=8 type=d alias=V0167+0 align=32 words (r13.14)
//.declare V0307 (320)  rf=r size=8 type=d alias=V0168+0 align=32 words (r14.0)
//.declare V0308 (321)  rf=r size=8 type=d alias=V0169+0 align=32 words (r14.2)
//.declare V0309 (322)  rf=r size=8 type=d alias=V0170+0 align=32 words (r14.4)
//.declare V0310 (323)  rf=r size=8 type=d alias=V0171+0 align=32 words (r14.6)
//.declare V0311 (324)  rf=r size=8 type=d alias=V0172+0 align=32 words (r14.8)
//.declare V0312 (325)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0313 (326)  rf=r size=4 type=d align=2 words (r2.9)
//.declare V0314 (327)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0315 (328)  rf=r size=4 type=d align=2 words (r5.9)
//.declare V0316 (329)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0317 (330)  rf=r size=128 type=ud alias=V0316+0 align=32 words (r82.0)
//.declare V0318 (331)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0319 (332)  rf=r size=128 type=ud alias=V0318+0 align=32 words (r84.0)
//.declare V0320 (333)  rf=r size=128 type=d align=32 words (r86.0)
//.declare V0321 (334)  rf=r size=128 type=ud alias=V0320+0 align=32 words (r86.0)
//.declare P04 (335)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P05 (336)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P06 (337)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0322 (338)  rf=r size=4 type=ud alias=V0105+0 align=32 words (r8.2)
//.declare P07 (339)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P08 (340)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P09 (341)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0323 (342)  rf=r size=8 type=q align=4 words (r63.7)
//.declare V0324 (343)  rf=r size=12 type=ud alias=V0037+0 align=32 words (r14.10)
//.declare V0325 (344)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (346)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0327 (347)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (349)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0329 (350)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (352)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0331 (353)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (355)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0333 (356)  rf=r size=512 type=d align=32 words (r48.0)
//.declare  (358)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0335 (359)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (361)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0337 (362)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (364)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0339 (365)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (367)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0341 (368)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (370)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0343 (371)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (373)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0345 (374)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (376)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0347 (377)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (379)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0349 (380)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (382)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0351 (383)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (385)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0353 (386)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (388)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0355 (389)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (391)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0357 (392)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (394)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0359 (395)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (397)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0361 (398)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (400)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0363 (401)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (403)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0365 (404)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (406)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0367 (407)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (409)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0369 (410)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (412)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0371 (413)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (415)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0373 (416)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (418)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0375 (419)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (421)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0377 (422)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (424)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0379 (425)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (427)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0381 (428)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (430)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0383 (431)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (433)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0385 (434)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (436)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0387 (437)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (439)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0389 (440)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (442)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0391 (443)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (445)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0393 (446)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (448)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0395 (449)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (451)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0397 (452)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (454)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0399 (455)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (457)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0401 (458)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (460)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0403 (461)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (463)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0405 (464)  rf=r size=512 type=d align=32 words (r40.0)
//.declare  (466)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0407 (467)  rf=r size=512 type=d align=32 words (r16.0)
//.declare  (469)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0409 (470)  rf=r size=512 type=d align=32 words (r24.0)
//.declare  (472)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0411 (473)  rf=r size=512 type=d align=32 words (r32.0)
//.declare  (475)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0413 (476)  rf=r size=256 type=q align=32 words (r40.0)
//.declare  (478)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0415 (479)  rf=r size=256 type=uq alias=V0413+0 align=32 words (r40.0)
//.declare V0416 (480)  rf=r size=256 type=uq align=32 words (r15.0)
//.declare V0417 (481)  rf=r size=128 type=d align=32 words (r20.0)
//.declare P10 (482)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0418 (483)  rf=r size=256 type=q align=32 words (r15.0)
//.declare  (485)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0420 (486)  rf=r size=256 type=uq alias=V0418+0 align=32 words (r15.0)
//.declare V0421 (487)  rf=r size=256 type=uq align=32 words (r88.0)
//.declare V0423 (489)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0424 (490)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare P11 (492)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0426 (493)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0427 (494)  rf=r size=256 type=q align=32 words (r92.0)
//.declare  (496)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0429 (497)  rf=r size=128 type=d align=32 words (r96.0)
//.declare V0430 (498)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0431 (499)  rf=r size=128 type=d align=32 words (r98.0)
//.declare P12 (500)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0432 (501)  rf=r size=128 type=f align=32 words (r100.0)
//.declare V0434 (503)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0438 (507)  rf=r size=256 type=uq align=32 words (r19.0)
//.declare V0439 (508)  rf=r size=256 type=q align=32 words (r23.0)
//.declare V0443 (512)  rf=r size=256 type=uq align=32 words (r19.0)
//.declare V0444 (513)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0445 (514)  rf=r size=128 type=ud alias=V0444+0 align=32 words (r24.0)
//.declare V0449 (518)  rf=r size=256 type=uq align=32 words (r19.0)
//.declare V0450 (519)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0454 (523)  rf=r size=256 type=uq align=32 words (r19.0)
//.declare V0456 (525)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0457 (526)  rf=r size=128 type=w alias=V0456+0 align=32 words (r24.0)
//.declare V0459 (528)  rf=r size=128 type=d alias=V0434+0 align=32 words (r102.0)
//.declare V0463 (532)  rf=r size=256 type=uq align=32 words (r19.0)
//.declare V0464 (533)  rf=r size=128 type=d align=32 words (r16.0)
//.declare P13 (534)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0465 (535)  rf=r size=128 type=f alias=V0464+0 align=32 words (r16.0)
//.declare P14 (536)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0467 (538)  rf=r size=128 type=d align=32 words (r16.0)
//.declare P15 (539)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P16 (540)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0471 (544)  rf=r size=256 type=uq align=32 words (r19.0)
//.declare V0475 (548)  rf=r size=128 type=d align=32 words (r104.0)
//.declare V0476 (549)  rf=r size=128 type=d align=32 words (r106.0)
//.declare P17 (550)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0477 (551)  rf=r size=128 type=ud alias=V0475+0 align=32 words (r104.0)
//.declare P18 (552)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P19 (553)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0478 (554)  rf=r size=128 type=ud alias=V0476+0 align=32 words (r106.0)
//.declare  (558)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (559)  rf=r size=4 type=ud align=32 words (r15.0)
//.declare  (560)  rf=r size=128 type=uw align=32 words (r17.0)
//.declare  (561)  rf=r size=128 type=uw align=32 words (r21.0)
//.declare  (564)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (565)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (566)  rf=r size=128 type=f align=32 words (r28.0)
//.declare  (567)  rf=r size=128 type=f align=32 words (r30.0)
//.declare  (570)  rf=r size=128 type=q align=32 words (r19.0)
//.declare  (571)  rf=r size=128 type=q align=32 words (r23.0)
//.declare  (572)  rf=r size=128 type=q align=32 words (r108.0)
//.declare  (573)  rf=r size=128 type=q align=32 words (r110.0)
//.declare  (576)  rf=r size=128 type=q align=32 words (r112.0)
//.declare  (577)  rf=r size=128 type=q align=32 words (r114.0)
//.declare  (578)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (579)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (582)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (583)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (586)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (587)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (590)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (591)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (594)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (595)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (598)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (599)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (602)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (603)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (606)  rf=r size=128 type=d align=32 words (r16.0)
//.declare  (607)  rf=r size=128 type=d align=32 words (r18.0)
//.declare  (608)  rf=r size=128 type=d alias=+0 align=32 words (r108.0)
//.declare  (609)  rf=r size=128 type=d alias=+0 align=32 words (r110.0)
//.declare  (610)  rf=r size=128 type=d alias=+0 align=32 words (r15.0)
//.declare  (611)  rf=r size=128 type=d alias=+0 align=32 words (r17.0)
//.declare  (612)  rf=r size=4 type=uw align=2 words (r80.8)
//.declare  (613)  rf=r size=4 type=uw align=2 words (r80.10)
//.declare  (614)  rf=r size=4 type=uw align=2 words (r80.12)
//.declare  (615)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (616)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (617)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (618)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (619)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (620)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare r0 (621)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (622)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (623)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (624)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (625)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (626)  rf=r size=256 type=ud align=32 words (r3.0)
//.declare  (627)  rf=r size=256 type=ud align=32 words (r7.0)
//.declare  (628)  rf=r size=256 type=ud align=32 words (r11.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :b       |    0x1 | r3       | cti+0x20         |
// | V0045    | :b       |    0x1 | r3+0x4   | cti+0x24         |
// | V0046    | :b       |    0x1 | r3+0x8   | cti+0x28         |
// | V0047    | :b       |    0x1 | r3+0xC   | cti+0x2C         |
// | V0048    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0049    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0050    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0051    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0052    | :d       |    0x4 | r3+0x20  | cti+0x40         |
// | V0053    | :d       |    0x4 | r3+0x24  | cti+0x44         |
// | V0054    | :d       |    0x4 | r3+0x28  | cti+0x48         |
// | V0055    | :d       |    0x4 | r3+0x2C  | cti+0x4C         |
// | V0056    | :d       |    0x4 | r3+0x30  | cti+0x50         |
// | V0057    | :d       |    0x4 | r3+0x34  | cti+0x54         |
// | V0058    | :d       |    0x4 | r3+0x38  | cti+0x58         |
// | V0059    | :d       |    0x4 | r3+0x3C  | cti+0x5C         |
// | V0060    | :d       |    0x4 | r4       | cti+0x60         |
// | V0061    | :d       |    0x4 | r4+0x4   | cti+0x64         |
// | V0062    | :d       |    0x4 | r4+0x8   | cti+0x68         |
// | V0063    | :d       |    0x4 | r4+0xC   | cti+0x6C         |
// | V0064    | :d       |    0x4 | r4+0x10  | cti+0x70         |
// | V0065    | :d       |    0x4 | r4+0x14  | cti+0x74         |
// | V0066    | :d       |    0x4 | r4+0x18  | cti+0x78         |
// | V0067    | :d       |    0x4 | r4+0x1C  | cti+0x7C         |
// | V0068    | :d       |    0x4 | r4+0x20  | cti+0x80         |
// | V0069    | :d       |    0x4 | r4+0x24  | cti+0x84         |
// | V0070    | :d       |    0x4 | r4+0x28  | cti+0x88         |
// | V0071    | :d       |    0x4 | r4+0x2C  | cti+0x8C         |
// | V0072    | :d       |    0x4 | r4+0x30  | cti+0x90         |
// | V0073    | :d       |    0x4 | r4+0x34  | cti+0x94         |
// | V0074    | :d       |    0x4 | r4+0x38  | cti+0x98         |
// | V0075    | :d       |    0x4 | r4+0x3C  | cti+0x9C         |
// | V0076    | :d       |    0x4 | r5       | cti+0xA0         |
// | V0077    | :d       |    0x4 | r5+0x4   | cti+0xA4         |
// | V0078    | :d       |    0x4 | r5+0x8   | cti+0xA8         |
// | V0079    | :d       |    0x4 | r5+0xC   | cti+0xAC         |
// | V0080    | :d       |    0x4 | r5+0x10  | cti+0xB0         |
// | V0081    | :d       |    0x4 | r5+0x14  | cti+0xB4         |
// | V0082    | :d       |    0x4 | r5+0x18  | cti+0xB8         |
// | V0083    | :d       |    0x4 | r5+0x1C  | cti+0xBC         |
// | V0084    | :d       |    0x4 | r5+0x20  | cti+0xC0         |
// | V0085    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0086    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// | V0087    | :q       |    0x8 | r5+0x38  | cti+0xD8         |
// | V0088    | :q       |    0x8 | r6       | cti+0xE0         |
// | V0089    | :q       |    0x8 | r6+0x8   | cti+0xE8         |
// | V0090    | :q       |    0x8 | r6+0x10  | cti+0xF0         |
// | V0091    | :q       |    0x8 | r6+0x18  | cti+0xF8         |
// | V0092    | :q       |    0x8 | r6+0x20  | cti+0x100        |
// | V0093    | :q       |    0x8 | r6+0x28  | cti+0x108        |
// | V0094    | :q       |    0x8 | r6+0x30  | cti+0x110        |
// | V0095    | :q       |    0x8 | r6+0x38  | cti+0x118        |
// | V0096    | :q       |    0x8 | r7       | cti+0x120        |
// | V0097    | :q       |    0x8 | r7+0x8   | cti+0x128        |
// | V0098    | :q       |    0x8 | r7+0x10  | cti+0x130        |
// | V0099    | :q       |    0x8 | r7+0x18  | cti+0x138        |
// | V0100    | :q       |    0x8 | r7+0x20  | cti+0x140        |
// | V0101    | :q       |    0x8 | r7+0x28  | cti+0x148        |
// | V0102    | :q       |    0x8 | r7+0x30  | cti+0x150        |
// | V0103    | :q       |    0x8 | r7+0x38  | cti+0x158        |
// | V0104    | :q       |    0x8 | r8       | cti+0x160        |
// | V0105    | :d       |    0x4 | r8+0x8   | cti+0x168        |
// | V0106    | :d       |    0x4 | r8+0xC   | cti+0x16C        |
// | V0107    | :d       |    0x4 | r8+0x10  | cti+0x170        |
// | V0108    | :d       |    0x4 | r8+0x14  | cti+0x174        |
// | V0109    | :d       |    0x4 | r8+0x18  | cti+0x178        |
// | V0110    | :d       |    0x4 | r8+0x1C  | cti+0x17C        |
// | V0111    | :d       |    0x4 | r8+0x20  | cti+0x180        |
// | V0112    | :d       |    0x4 | r8+0x24  | cti+0x184        |
// | V0113    | :d       |    0x4 | r8+0x28  | cti+0x188        |
// | V0114    | :d       |    0x4 | r8+0x2C  | cti+0x18C        |
// | V0115    | :d       |    0x4 | r8+0x30  | cti+0x190        |
// | V0116    | :d       |    0x4 | r8+0x34  | cti+0x194        |
// | V0117    | :d       |    0x4 | r8+0x38  | cti+0x198        |
// | V0118    | :d       |    0x4 | r8+0x3C  | cti+0x19C        |
// | V0119    | :d       |    0x4 | r9       | cti+0x1A0        |
// | V0120    | :d       |    0x4 | r9+0x4   | cti+0x1A4        |
// | V0121    | :d       |    0x4 | r9+0x8   | cti+0x1A8        |
// | V0122    | :d       |    0x4 | r9+0xC   | cti+0x1AC        |
// | V0123    | :d       |    0x4 | r9+0x10  | cti+0x1B0        |
// | V0124    | :d       |    0x4 | r9+0x14  | cti+0x1B4        |
// | V0125    | :d       |    0x4 | r9+0x18  | cti+0x1B8        |
// | V0126    | :d       |    0x4 | r9+0x1C  | cti+0x1BC        |
// | V0127    | :d       |    0x4 | r9+0x20  | cti+0x1C0        |
// | V0128    | :d       |    0x4 | r9+0x24  | cti+0x1C4        |
// | V0129    | :q       |    0x8 | r9+0x28  | cti+0x1C8        |
// | V0130    | :q       |    0x8 | r9+0x30  | cti+0x1D0        |
// | V0131    | :q       |    0x8 | r9+0x38  | cti+0x1D8        |
// | V0132    | :q       |    0x8 | r10      | cti+0x1E0        |
// | V0133    | :b       |    0x1 | r10+0x8  | cti+0x1E8        |
// | V0134    | :b       |    0x1 | r10+0xC  | cti+0x1EC        |
// | V0135    | :b       |    0x1 | r10+0x10 | cti+0x1F0        |
// | V0136    | :b       |    0x1 | r10+0x14 | cti+0x1F4        |
// | V0137    | :b       |    0x1 | r10+0x18 | cti+0x1F8        |
// | V0138    | :b       |    0x1 | r10+0x1C | cti+0x1FC        |
// | V0139    | :b       |    0x1 | r10+0x20 | cti+0x200        |
// | V0140    | :b       |    0x1 | r10+0x24 | cti+0x204        |
// | V0141    | :q       |    0x8 | r10+0x28 | cti+0x208        |
// | V0142    | :q       |    0x8 | r10+0x30 | cti+0x210        |
// | V0143    | :q       |    0x8 | r10+0x38 | cti+0x218        |
// | V0144    | :q       |    0x8 | r11      | cti+0x220        |
// | V0145    | :q       |    0x8 | r11+0x8  | cti+0x228        |
// | V0146    | :q       |    0x8 | r11+0x10 | cti+0x230        |
// | V0147    | :q       |    0x8 | r11+0x18 | cti+0x238        |
// | V0148    | :q       |    0x8 | r11+0x20 | cti+0x240        |
// | V0149    | :q       |    0x8 | r11+0x28 | cti+0x248        |
// | V0150    | :q       |    0x8 | r11+0x30 | cti+0x250        |
// | V0151    | :q       |    0x8 | r11+0x38 | cti+0x258        |
// | V0152    | :q       |    0x8 | r12      | cti+0x260        |
// | V0153    | :q       |    0x8 | r12+0x8  | cti+0x268        |
// | V0154    | :q       |    0x8 | r12+0x10 | cti+0x270        |
// | V0155    | :q       |    0x8 | r12+0x18 | cti+0x278        |
// | V0156    | :q       |    0x8 | r12+0x20 | cti+0x280        |
// | V0157    | :q       |    0x8 | r12+0x28 | cti+0x288        |
// | V0158    | :q       |    0x8 | r12+0x30 | cti+0x290        |
// | V0159    | :q       |    0x8 | r12+0x38 | cti+0x298        |
// | V0160    | :q       |    0x8 | r13      | cti+0x2A0        |
// | V0161    | :q       |    0x8 | r13+0x8  | cti+0x2A8        |
// | V0162    | :q       |    0x8 | r13+0x10 | cti+0x2B0        |
// | V0163    | :q       |    0x8 | r13+0x18 | cti+0x2B8        |
// | V0164    | :q       |    0x8 | r13+0x20 | cti+0x2C0        |
// | V0165    | :q       |    0x8 | r13+0x28 | cti+0x2C8        |
// | V0166    | :q       |    0x8 | r13+0x30 | cti+0x2D0        |
// | V0167    | :q       |    0x8 | r13+0x38 | cti+0x2D8        |
// | V0168    | :q       |    0x8 | r14      | cti+0x2E0        |
// | V0169    | :q       |    0x8 | r14+0x8  | cti+0x2E8        |
// | V0170    | :q       |    0x8 | r14+0x10 | cti+0x2F0        |
// | V0171    | :q       |    0x8 | r14+0x18 | cti+0x2F8        |
// | V0172    | :q       |    0x8 | r14+0x20 | cti+0x300        |
// | V0037    | :d x 3   |    0xC | r14+0x28 | cti+0x308        |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x300:ud              {I@2}         //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x64t.a32.ca.cc (1|M0)  r3:4 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6249F500 // 
(W)     load.ugm.d32x64t.a32.ca.cc (1|M0)  r7:4 bti[255][r127:1+0x100]  {$2} // ex_desc:0xFF100000; desc:0x6249F500 // 
(W)     load.ugm.d32x64t.a32.ca.cc (1|M0)  r11:4 bti[255][r127:1+0x200]  {$3} // ex_desc:0xFF200000; desc:0x6249F500 // 
// B002: Preds:{B001},  Succs:{B003, B028}
// _main:
(W)     mov (16|M0)              r56.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r56.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r15.0<1>:ud   r2.3<0;1,0>:ud    r56.1<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r56.2<0;1,0>:uw                     //  ALU pipe: int; $4
(W)     mach (1|M0)              r16.0<1>:d    r2.3<0;1,0>:ud    r56.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r17.0<4>:uw   r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r21.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.8<2>:ud    r15.0<0;1,0>:ud                  {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.9<2>:d     r16.0<0;1,0>:d                   {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r63.8<1>:d    r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r19.0<1>:q    r2.4<0;1,0>:q     r17.0<4;1,0>:uw  {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r23.0<1>:q    r2.4<0;1,0>:q     r21.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r108.0<1>:q   r19.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r110.0<1>:q   r23.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r64.0<1>:d    r108.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r65.0<1>:d    r110.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r64.0<1;1,0>:ud   r63.8<0;1,0>:ud  {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r66.0<1>:d    r108.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r67.0<1>:d    r110.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $16
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r66.0<1;1,0>:d    r63.9<0;1,0>:d   {I@1}              //  ALU pipe: int; $18
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r66.0<1;1,0>:ud   r63.9<0;1,0>:ud                     //  ALU pipe: int; $20
(~f0.0) goto (32|M0)                         _0_034            _0_034                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_035:
(W)     mov (8|M0)               r15.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $24
(W)     mov (2|M0)               r2.8<1>:d     r5.10<1;1,0>:d                   {$1.dst}             //  ALU pipe: int; $71
(W)     add (8|M0)               r15.8<1>:w    r15.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $25
(W)     mov (2|M0)               r78.2<1>:d    r2.8<1;1,0>:d                    {I@2}                //  ALU pipe: int; $74
(W)     mov (2|M0)               r2.8<1>:d     r8.0<1;1,0>:d                    {$2.dst}             //  ALU pipe: int; $94
(W)     add (16|M0)              r15.16<1>:w   r15.0<1;1,0>:w    16:w               {I@3}            //  ALU pipe: int; $26
(W)     mov (2|M0)               r78.4<1>:d    r2.8<1;1,0>:d                    {I@2}                //  ALU pipe: int; $95
(W)     mov (2|M0)               r2.8<1>:d     r9.10<1;1,0>:d                                        //  ALU pipe: int; $119
        mul (32|M0)              r68.0<1>:d    r15.0<1;1,0>:uw   704:w               {I@3}           //  ALU pipe: int; $28
(W)     mov (2|M0)               r79.14<1>:d   r2.8<1;1,0>:d                    {I@2}                //  ALU pipe: int; $122
(W)     shl (1|M0)               r2.9<1>:d     r5.8<0;1,0>:d     3:w                                 //  ALU pipe: int; $170
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r8.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $176
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r8.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $177
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r8.2<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $178
(W)     add (1|M0)               r2.8<1>:d     r5.6<0;1,0>:d     r5.7<0;1,0>:d                       //  ALU pipe: int; $169
        add3 (32|M0)             r16.0<1>:d    r68.0<1;0>:d      r2.9<0;0>:d       448:w               {I@5} //  ALU pipe: int; $171
(W)     shl (1|M0)               r5.9<1>:d     r2.8<0;1,0>:d     3:w               {I@2}             //  ALU pipe: int; $172
        or (32|M0)               r70.0<1>:d    r68.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $29
        or (32|M0)               r72.0<1>:d    r68.0<1;1,0>:d    32:w               {Compacted}      //  ALU pipe: int; $30
        or (32|M0)               r74.0<1>:d    r68.0<1;1,0>:d    48:w               {Compacted}      //  ALU pipe: int; $31
(W)     mov (1|M0)               r80.6<1>:ud   f2.0<0;1,0>:ud                                        //  ALU pipe: int; $176
(W)     mov (1|M0)               r80.5<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $177
(W)     mov (1|M0)               r80.4<1>:ud   f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $178
        add3 (32|M0)             r82.0<1>:d    r16.0<1;0>:d      r5.9<0;0>:d       24:w               {I@7} //  ALU pipe: int; $173
        add3 (32|M0)             r84.0<1>:d    r16.0<1;0>:d      r5.9<0;0>:d       8:w               //  ALU pipe: int; $174
        add (32|M0)              r86.0<1>:d    r16.0<1;1,0>:d    r5.9<0;1,0>:d    {Compacted}        //  ALU pipe: int; $175
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r8.2<0;1,0>:d     4:w                                 //  ALU pipe: int; $179
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r8.2<0;1,0>:d     1:w                                 //  ALU pipe: int; $180
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r8.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $181
(W)     mov (2|M0)               r14.13<1>:d   r10.0<1;1,0>:d                   {$3.dst}             //  ALU pipe: int; $126
(W)     mov (1|M0)               r76.0<2>:b    r3.0<0;1,0>:b                    {Atomic}             //  ALU pipe: int; $32
(W)     mov (1|M0)               r76.1<2>:b    r3.4<0;1,0>:b                    {Atomic}             // $33
(W)     mov (1|M0)               r76.2<2>:b    r3.8<0;1,0>:b                    {Atomic}             // $34
(W)     mov (1|M0)               r76.3<2>:b    r3.12<0;1,0>:b                                        // $35
(W)     mov (1|M0)               r76.1<1>:d    r3.4<0;1,0>:d                                         //  ALU pipe: int; $36
(W)     mov (1|M0)               r76.2<1>:d    r3.5<0;1,0>:d                                         //  ALU pipe: int; $37
(W)     mov (1|M0)               r76.3<1>:d    r3.6<0;1,0>:d                                         //  ALU pipe: int; $38
(W)     mov (1|M0)               r63.10<1>:d   r3.7<0;1,0>:d                                         //  ALU pipe: int; $39
(W)     mov (1|M0)               r63.11<1>:d   r3.8<0;1,0>:d                                         //  ALU pipe: int; $40
(W)     mov (1|M0)               r63.12<1>:d   r3.9<0;1,0>:d                                         //  ALU pipe: int; $41
(W)     mov (1|M0)               r63.13<1>:d   r3.10<0;1,0>:d                                        //  ALU pipe: int; $42
(W)     mov (1|M0)               r76.4<1>:d    r3.11<0;1,0>:d                                        //  ALU pipe: int; $43
(W)     mov (1|M0)               r76.5<1>:d    r3.12<0;1,0>:d                                        //  ALU pipe: int; $44
(W)     mov (1|M0)               r76.6<1>:d    r3.13<0;1,0>:d                                        //  ALU pipe: int; $45
(W)     mov (1|M0)               r76.7<1>:d    r3.14<0;1,0>:d                                        //  ALU pipe: int; $46
(W)     mov (1|M0)               r76.8<1>:d    r3.15<0;1,0>:d                                        //  ALU pipe: int; $47
(W)     mov (1|M0)               r76.9<1>:d    r4.0<0;1,0>:d                                         //  ALU pipe: int; $48
(W)     mov (1|M0)               r76.10<1>:d   r4.1<0;1,0>:d                                         //  ALU pipe: int; $49
(W)     mov (1|M0)               r76.11<1>:d   r4.2<0;1,0>:d                                         //  ALU pipe: int; $50
(W)     mov (1|M0)               r76.12<1>:d   r4.3<0;1,0>:d                                         //  ALU pipe: int; $51
(W)     mov (1|M0)               r76.13<1>:d   r4.4<0;1,0>:d                                         //  ALU pipe: int; $52
(W)     mov (1|M0)               r76.14<1>:d   r4.5<0;1,0>:d                                         //  ALU pipe: int; $53
(W)     mov (1|M0)               r76.15<1>:d   r4.6<0;1,0>:d                                         //  ALU pipe: int; $54
(W)     mov (1|M0)               r77.0<1>:d    r4.7<0;1,0>:d                                         //  ALU pipe: int; $55
(W)     mov (1|M0)               r77.1<1>:d    r4.8<0;1,0>:d                                         //  ALU pipe: int; $56
(W)     mov (1|M0)               r77.2<1>:d    r4.9<0;1,0>:d                                         //  ALU pipe: int; $57
(W)     mov (1|M0)               r77.3<1>:d    r4.10<0;1,0>:d                                        //  ALU pipe: int; $58
(W)     mov (1|M0)               r77.4<1>:d    r4.11<0;1,0>:d                                        //  ALU pipe: int; $59
(W)     mov (1|M0)               r77.5<1>:d    r4.12<0;1,0>:d                                        //  ALU pipe: int; $60
(W)     mov (1|M0)               r77.6<1>:d    r4.13<0;1,0>:d                                        //  ALU pipe: int; $61
(W)     mov (1|M0)               r77.7<1>:d    r4.14<0;1,0>:d                                        //  ALU pipe: int; $62
(W)     mov (1|M0)               r77.8<1>:d    r4.15<0;1,0>:d                                        //  ALU pipe: int; $63
(W)     mov (1|M0)               r77.9<1>:d    r5.0<0;1,0>:d                                         //  ALU pipe: int; $64
(W)     mov (1|M0)               r77.10<1>:d   r5.1<0;1,0>:d                                         //  ALU pipe: int; $65
(W)     mov (1|M0)               r77.11<1>:d   r5.2<0;1,0>:d                                         //  ALU pipe: int; $66
(W)     mov (1|M0)               r77.12<1>:d   r5.3<0;1,0>:d                                         //  ALU pipe: int; $67
(W)     mov (1|M0)               r77.13<1>:d   r5.4<0;1,0>:d                                         //  ALU pipe: int; $68
(W)     mov (1|M0)               r77.14<1>:d   r5.5<0;1,0>:d                                         //  ALU pipe: int; $69
(W)     mov (1|M0)               r77.15<1>:d   r5.6<0;1,0>:d                                         //  ALU pipe: int; $70
(W)     mov (1|M0)               r78.0<1>:d    r5.7<0;1,0>:d                                         //  ALU pipe: int; $72
(W)     mov (1|M0)               r78.1<1>:d    r5.8<0;1,0>:d                                         //  ALU pipe: int; $73
(W)     mov (2|M0)               r57.0<1>:d    r5.12<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $76
(W)     mov (2|M0)               r57.2<1>:d    r5.14<1;1,0>:d                                        //  ALU pipe: int; $77
(W)     mov (2|M0)               r57.4<1>:d    r6.0<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $78
(W)     mov (2|M0)               r57.6<1>:d    r6.2<1;1,0>:d                                         //  ALU pipe: int; $79
(W)     mov (2|M0)               r57.8<1>:d    r6.4<1;1,0>:d                                         //  ALU pipe: int; $80
(W)     mov (2|M0)               r57.10<1>:d   r6.6<1;1,0>:d                                         //  ALU pipe: int; $81
(W)     mov (2|M0)               r57.12<1>:d   r6.8<1;1,0>:d                                         //  ALU pipe: int; $82
(W)     mov (2|M0)               r57.14<1>:d   r6.10<1;1,0>:d                                        //  ALU pipe: int; $83
(W)     mov (2|M0)               r58.0<1>:d    r6.12<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $84
(W)     mov (2|M0)               r58.2<1>:d    r6.14<1;1,0>:d                                        //  ALU pipe: int; $85
(W)     mov (2|M0)               r58.4<1>:d    r7.0<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $86
(W)     mov (2|M0)               r58.6<1>:d    r7.2<1;1,0>:d                                         //  ALU pipe: int; $87
(W)     mov (2|M0)               r58.8<1>:d    r7.4<1;1,0>:d                                         //  ALU pipe: int; $88
(W)     mov (2|M0)               r58.10<1>:d   r7.6<1;1,0>:d                                         //  ALU pipe: int; $89
(W)     mov (2|M0)               r58.12<1>:d   r7.8<1;1,0>:d                                         //  ALU pipe: int; $90
(W)     mov (2|M0)               r58.14<1>:d   r7.10<1;1,0>:d                                        //  ALU pipe: int; $91
(W)     mov (2|M0)               r59.0<1>:d    r7.12<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $92
(W)     mov (2|M0)               r59.2<1>:d    r7.14<1;1,0>:d                                        //  ALU pipe: int; $93
(W)     mov (1|M0)               r78.6<1>:d    r8.2<0;1,0>:d                                         //  ALU pipe: int; $97
(W)     mov (1|M0)               r78.7<1>:d    r8.3<0;1,0>:d                                         //  ALU pipe: int; $98
(W)     mov (1|M0)               r78.8<1>:d    r8.4<0;1,0>:d                                         //  ALU pipe: int; $99
(W)     mov (1|M0)               r78.9<1>:d    r8.5<0;1,0>:d                                         //  ALU pipe: int; $100
(W)     mov (1|M0)               r78.10<1>:d   r8.6<0;1,0>:d                                         //  ALU pipe: int; $101
(W)     mov (1|M0)               r78.11<1>:d   r8.7<0;1,0>:d                                         //  ALU pipe: int; $102
(W)     mov (1|M0)               r78.12<1>:d   r8.8<0;1,0>:d                                         //  ALU pipe: int; $103
(W)     mov (1|M0)               r78.13<1>:d   r8.9<0;1,0>:d                                         //  ALU pipe: int; $104
(W)     mov (1|M0)               r78.14<1>:d   r8.10<0;1,0>:d                                        //  ALU pipe: int; $105
(W)     mov (1|M0)               r78.15<1>:d   r8.11<0;1,0>:d                                        //  ALU pipe: int; $106
(W)     mov (1|M0)               r79.0<1>:d    r8.12<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $107
(W)     mov (1|M0)               r79.1<1>:d    r8.13<0;1,0>:d                                        //  ALU pipe: int; $108
(W)     mov (1|M0)               r79.2<1>:d    r8.14<0;1,0>:d                                        //  ALU pipe: int; $109
(W)     mov (1|M0)               r79.3<1>:d    r8.15<0;1,0>:d                                        //  ALU pipe: int; $110
(W)     mov (1|M0)               r79.4<1>:d    r9.0<0;1,0>:d                    {Compacted}          //  ALU pipe: int; $111
(W)     mov (1|M0)               r79.5<1>:d    r9.1<0;1,0>:d                                         //  ALU pipe: int; $112
(W)     mov (1|M0)               r79.6<1>:d    r9.2<0;1,0>:d                                         //  ALU pipe: int; $113
(W)     mov (1|M0)               r79.7<1>:d    r9.3<0;1,0>:d                                         //  ALU pipe: int; $114
(W)     mov (1|M0)               r79.8<1>:d    r9.4<0;1,0>:d                                         //  ALU pipe: int; $115
(W)     mov (1|M0)               r79.9<1>:d    r9.5<0;1,0>:d                                         //  ALU pipe: int; $116
(W)     mov (1|M0)               r79.10<1>:d   r9.6<0;1,0>:d                                         //  ALU pipe: int; $117
(W)     mov (1|M0)               r79.11<1>:d   r9.7<0;1,0>:d                                         //  ALU pipe: int; $118
(W)     mov (1|M0)               r79.12<1>:d   r9.8<0;1,0>:d                                         //  ALU pipe: int; $120
(W)     mov (1|M0)               r79.13<1>:d   r9.9<0;1,0>:d                                         //  ALU pipe: int; $121
(W)     mov (2|M0)               r59.4<1>:d    r9.12<1;1,0>:d                                        //  ALU pipe: int; $124
(W)     mov (2|M0)               r59.6<1>:d    r9.14<1;1,0>:d                                        //  ALU pipe: int; $125
(W)     mov (1|M0)               r80.8<2>:b    r10.8<0;1,0>:b                   {Atomic}             //  ALU pipe: int; $129
(W)     mov (1|M0)               r80.9<2>:b    r10.12<0;1,0>:b                  {Atomic}             // $130
(W)     mov (1|M0)               r80.10<2>:b   r10.16<0;1,0>:b                  {Atomic}             // $131
(W)     mov (1|M0)               r80.11<2>:b   r10.20<0;1,0>:b                  {Atomic}             // $132
(W)     mov (1|M0)               r80.12<2>:b   r10.24<0;1,0>:b                  {Atomic}             // $133
(W)     mov (1|M0)               r80.13<2>:b   r10.28<0;1,0>:b                  {Atomic}             // $134
(W)     mov (1|M0)               r80.14<2>:b   r10.32<0;1,0>:b                  {Atomic}             // $135
(W)     mov (1|M0)               r80.15<2>:b   r10.36<0;1,0>:b                                       // $136
(W)     mov (2|M0)               r59.8<1>:d    r10.10<1;1,0>:d                                       //  ALU pipe: int; $137
(W)     mov (2|M0)               r59.10<1>:d   r10.12<1;1,0>:d                                       //  ALU pipe: int; $138
(W)     mov (2|M0)               r59.12<1>:d   r10.14<1;1,0>:d                                       //  ALU pipe: int; $139
(W)     mov (2|M0)               r59.14<1>:d   r11.0<1;1,0>:d                                        //  ALU pipe: int; $140
(W)     mov (2|M0)               r60.0<1>:d    r11.2<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $141
(W)     mov (2|M0)               r60.2<1>:d    r11.4<1;1,0>:d                                        //  ALU pipe: int; $142
(W)     mov (2|M0)               r60.4<1>:d    r11.6<1;1,0>:d                                        //  ALU pipe: int; $143
(W)     mov (2|M0)               r60.6<1>:d    r11.8<1;1,0>:d                                        //  ALU pipe: int; $144
(W)     mov (2|M0)               r60.8<1>:d    r11.10<1;1,0>:d                                       //  ALU pipe: int; $145
(W)     mov (2|M0)               r60.10<1>:d   r11.12<1;1,0>:d                                       //  ALU pipe: int; $146
(W)     mov (2|M0)               r60.12<1>:d   r11.14<1;1,0>:d                                       //  ALU pipe: int; $147
(W)     mov (2|M0)               r60.14<1>:d   r12.0<1;1,0>:d                                        //  ALU pipe: int; $148
(W)     mov (2|M0)               r61.0<1>:d    r12.2<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $149
(W)     mov (2|M0)               r61.2<1>:d    r12.4<1;1,0>:d                                        //  ALU pipe: int; $150
(W)     mov (2|M0)               r61.4<1>:d    r12.6<1;1,0>:d                                        //  ALU pipe: int; $151
(W)     mov (2|M0)               r61.6<1>:d    r12.8<1;1,0>:d                                        //  ALU pipe: int; $152
(W)     mov (2|M0)               r61.8<1>:d    r12.10<1;1,0>:d                                       //  ALU pipe: int; $153
(W)     mov (2|M0)               r61.10<1>:d   r12.12<1;1,0>:d                                       //  ALU pipe: int; $154
(W)     mov (2|M0)               r61.12<1>:d   r12.14<1;1,0>:d                                       //  ALU pipe: int; $155
(W)     mov (2|M0)               r61.14<1>:d   r13.0<1;1,0>:d                                        //  ALU pipe: int; $156
(W)     mov (2|M0)               r62.0<1>:d    r13.2<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $157
(W)     mov (2|M0)               r62.2<1>:d    r13.4<1;1,0>:d                                        //  ALU pipe: int; $158
(W)     mov (2|M0)               r62.4<1>:d    r13.6<1;1,0>:d                                        //  ALU pipe: int; $159
(W)     mov (2|M0)               r62.6<1>:d    r13.8<1;1,0>:d                                        //  ALU pipe: int; $160
(W)     mov (2|M0)               r62.8<1>:d    r13.10<1;1,0>:d                                       //  ALU pipe: int; $161
(W)     mov (2|M0)               r62.10<1>:d   r13.12<1;1,0>:d                                       //  ALU pipe: int; $162
(W)     mov (2|M0)               r62.12<1>:d   r13.14<1;1,0>:d                                       //  ALU pipe: int; $163
(W)     mov (2|M0)               r62.14<1>:d   r14.0<1;1,0>:d                                        //  ALU pipe: int; $164
(W)     mov (2|M0)               r63.0<1>:d    r14.2<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $165
(W)     mov (2|M0)               r63.2<1>:d    r14.4<1;1,0>:d                                        //  ALU pipe: int; $166
(W)     mov (2|M0)               r63.4<1>:d    r14.6<1;1,0>:d                                        //  ALU pipe: int; $167
(W)     mov (2|M0)               r63.6<1>:d    r14.8<1;1,0>:d                                        //  ALU pipe: int; $168
(W)     mov (1|M0)               r63.7<1>:q    r14.10<0;1,0>:ud                                      //  ALU pipe: int; $182
(W)     mov (1|M0)               r80.0<1>:d    r14.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $127
(W)     mov (1|M0)               r80.1<1>:d    r14.14<0;1,0>:d                                       //  ALU pipe: int; $128
// B004: [inDivergent],  Preds:{B027, B003},  Succs:{B005, B026}
_0_036:
        sync.nop                             null                             {Compacted,F@1}        // $188
        sync.allrd                           ($5,$6,$7,$8)                                           // $188
(W)     shr (1|M0)               a0.0<1>:ud    r56.5<0;1,0>:ud   0x4:uw              {$4.src}        //  ALU pipe: int; $188
        mov (32|M0)              r16.0<1>:f    r76.0<0;1,0>:f                   {Compacted}          //  ALU pipe: float; $184
        mov (32|M0)              r18.0<1>:d    r76.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $185
        mov (32|M0)              r20.0<1>:d    r76.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $186
        mov (32|M0)              r22.0<1>:d    r76.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $187
        mov (32|M0)              r24.0<1>:d    r63.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $190
        mov (32|M0)              r26.0<1>:d    r63.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $191
        mov (32|M0)              r28.0<1>:d    r63.12<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $192
        mov (32|M0)              r30.0<1>:d    r63.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $193
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2] r16:8   {A@1,$9} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $189
        mov (32|M0)              r32.0<1>:d    r76.4<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $196
        mov (32|M0)              r34.0<1>:d    r76.5<0;1,0>:d                                        //  ALU pipe: int; $197
        mov (32|M0)              r36.0<1>:d    r76.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $198
        mov (32|M0)              r38.0<1>:d    r76.7<0;1,0>:d                                        //  ALU pipe: int; $199
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r70:2] r24:8   {I@5,$10} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $195
        mov (32|M0)              r40.0<1>:d    r76.8<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $202
        mov (32|M0)              r42.0<1>:d    r76.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $203
        mov (32|M0)              r44.0<1>:d    r76.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $204
        mov (32|M0)              r46.0<1>:d    r76.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $205
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r72:2] r32:8   {I@5,$11} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $201
        mov (32|M0)              r48.0<1>:d    r76.12<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $208
        mov (32|M0)              r50.0<1>:d    r76.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $209
        mov (32|M0)              r52.0<1>:d    r76.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $210
        mov (32|M0)              r54.0<1>:d    r76.15<0;1,0>:d                                       //  ALU pipe: int; $211
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r74:2] r40:8   {I@5,$12} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $207
        mov (32|M0)              r16.0<1>:f    r77.0<0;1,0>:f                   {Compacted,$9.src}   //  ALU pipe: float; $214
        mov (32|M0)              r18.0<1>:d    r77.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $215
        mov (32|M0)              r20.0<1>:d    r77.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $216
        mov (32|M0)              r22.0<1>:d    r77.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $217
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x40] r48:8  {I@4,$4} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $213
        mov (32|M0)              r24.0<1>:d    r77.4<0;1,0>:d                   {Compacted,$10.src}  //  ALU pipe: int; $220
        mov (32|M0)              r26.0<1>:d    r77.5<0;1,0>:d                                        //  ALU pipe: int; $221
        mov (32|M0)              r28.0<1>:d    r77.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $222
        mov (32|M0)              r30.0<1>:d    r77.7<0;1,0>:d                                        //  ALU pipe: int; $223
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x50] r16:8  {A@1,$13} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $219
        mov (32|M0)              r32.0<1>:d    r77.8<0;1,0>:d                   {Compacted,$11.src}  //  ALU pipe: int; $226
        mov (32|M0)              r34.0<1>:d    r77.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $227
        mov (32|M0)              r36.0<1>:d    r77.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $228
        mov (32|M0)              r38.0<1>:d    r77.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $229
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x60] r24:8  {I@5,$14} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $225
        mov (32|M0)              r40.0<1>:d    r77.12<0;1,0>:d                  {Compacted,$12.src}  //  ALU pipe: int; $232
        mov (32|M0)              r42.0<1>:d    r77.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $233
        mov (32|M0)              r44.0<1>:d    r77.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $234
        mov (32|M0)              r46.0<1>:d    r77.15<0;1,0>:d                                       //  ALU pipe: int; $235
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x70] r32:8  {I@5,$15} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $231
        mov (32|M0)              r16.0<1>:f    r78.0<0;1,0>:f                   {Compacted,$13.src}  //  ALU pipe: float; $238
        mov (32|M0)              r18.0<1>:d    r78.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $239
        mov (32|M0)              r20.0<1>:d    r78.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $240
        mov (32|M0)              r22.0<1>:d    r78.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $241
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x80] r40:8  {I@4,$0} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $237
        mov (32|M0)              r24.0<1>:f    r57.0<0;1,0>:f                   {Compacted,$14.src}  //  ALU pipe: float; $244
        mov (32|M0)              r26.0<1>:d    r57.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $245
        mov (32|M0)              r28.0<1>:d    r57.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $246
        mov (32|M0)              r30.0<1>:d    r57.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $247
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x90] r16:8  {A@2,$1} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $243
        mov (32|M0)              r32.0<1>:d    r57.4<0;1,0>:d                   {Compacted,$15.src}  //  ALU pipe: int; $250
        mov (32|M0)              r34.0<1>:d    r57.5<0;1,0>:d                                        //  ALU pipe: int; $251
        mov (32|M0)              r36.0<1>:d    r57.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $252
        mov (32|M0)              r38.0<1>:d    r57.7<0;1,0>:d                                        //  ALU pipe: int; $253
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0xA0] r24:8  {A@1,$9} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $249
        mov (32|M0)              r40.0<1>:d    r57.8<0;1,0>:d                   {Compacted,$0.src}   //  ALU pipe: int; $256
        mov (32|M0)              r42.0<1>:d    r57.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $257
        mov (32|M0)              r44.0<1>:d    r57.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $258
        mov (32|M0)              r46.0<1>:d    r57.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $259
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0xB0] r32:8  {I@5,$10} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $255
        mov (32|M0)              r16.0<1>:d    r57.12<0;1,0>:d                  {Compacted,$1.src}   //  ALU pipe: int; $262
        mov (32|M0)              r18.0<1>:d    r57.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $263
        mov (32|M0)              r20.0<1>:d    r57.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $264
        mov (32|M0)              r22.0<1>:d    r57.15<0;1,0>:d                                       //  ALU pipe: int; $265
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0xC0] r40:8  {I@5,$11} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $261
        mov (32|M0)              r24.0<1>:f    r58.0<0;1,0>:f                   {Compacted,$9.src}   //  ALU pipe: float; $268
        mov (32|M0)              r26.0<1>:d    r58.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $269
        mov (32|M0)              r28.0<1>:d    r58.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $270
        mov (32|M0)              r30.0<1>:d    r58.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $271
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0xD0] r16:8  {I@4,$12} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $267
        mov (32|M0)              r32.0<1>:d    r58.4<0;1,0>:d                   {Compacted,$10.src}  //  ALU pipe: int; $274
        mov (32|M0)              r34.0<1>:d    r58.5<0;1,0>:d                                        //  ALU pipe: int; $275
        mov (32|M0)              r36.0<1>:d    r58.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $276
        mov (32|M0)              r38.0<1>:d    r58.7<0;1,0>:d                                        //  ALU pipe: int; $277
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0xE0] r24:8  {A@1,$2} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $273
        mov (32|M0)              r40.0<1>:d    r58.8<0;1,0>:d                   {Compacted,$11.src}  //  ALU pipe: int; $280
        mov (32|M0)              r42.0<1>:d    r58.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $281
        mov (32|M0)              r44.0<1>:d    r58.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $282
        mov (32|M0)              r46.0<1>:d    r58.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $283
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0xF0] r32:8  {I@5,$13} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $279
        mov (32|M0)              r16.0<1>:d    r58.12<0;1,0>:d                  {Compacted,$12.src}  //  ALU pipe: int; $286
        mov (32|M0)              r18.0<1>:d    r58.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $287
        mov (32|M0)              r20.0<1>:d    r58.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $288
        mov (32|M0)              r22.0<1>:d    r58.15<0;1,0>:d                                       //  ALU pipe: int; $289
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x100] r40:8  {I@5,$14} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $285
        mov (32|M0)              r24.0<1>:f    r59.0<0;1,0>:f                   {Compacted,$2.src}   //  ALU pipe: float; $292
        mov (32|M0)              r26.0<1>:d    r59.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $293
        mov (32|M0)              r28.0<1>:d    r59.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $294
        mov (32|M0)              r30.0<1>:d    r59.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $295
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x110] r16:8  {I@4,$15} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $291
        mov (32|M0)              r32.0<1>:d    r78.4<0;1,0>:d                   {Compacted,$13.src}  //  ALU pipe: int; $298
        mov (32|M0)              r34.0<1>:d    r78.5<0;1,0>:d                                        //  ALU pipe: int; $299
        mov (32|M0)              r36.0<1>:d    r78.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $300
        mov (32|M0)              r38.0<1>:d    r78.7<0;1,0>:d                                        //  ALU pipe: int; $301
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x120] r24:8  {A@1,$0} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $297
        mov (32|M0)              r40.0<1>:d    r78.8<0;1,0>:d                   {Compacted,$14.src}  //  ALU pipe: int; $304
        mov (32|M0)              r42.0<1>:d    r78.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $305
        mov (32|M0)              r44.0<1>:d    r78.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $306
        mov (32|M0)              r46.0<1>:d    r78.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $307
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x130] r32:8  {I@5,$3} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $303
        mov (32|M0)              r16.0<1>:d    r78.12<0;1,0>:d                  {Compacted,$15.src}  //  ALU pipe: int; $310
        mov (32|M0)              r18.0<1>:d    r78.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $311
        mov (32|M0)              r20.0<1>:d    r78.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $312
        mov (32|M0)              r22.0<1>:d    r78.15<0;1,0>:d                                       //  ALU pipe: int; $313
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x140] r40:8  {I@5,$9} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $309
        mov (32|M0)              r24.0<1>:f    r79.0<0;1,0>:f                   {Compacted,$0.src}   //  ALU pipe: float; $316
        mov (32|M0)              r26.0<1>:d    r79.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $317
        mov (32|M0)              r28.0<1>:d    r79.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $318
        mov (32|M0)              r30.0<1>:d    r79.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $319
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x150] r16:8  {I@4,$10} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $315
        mov (32|M0)              r32.0<1>:d    r79.4<0;1,0>:d                   {Compacted,$3.src}   //  ALU pipe: int; $322
        mov (32|M0)              r34.0<1>:d    r79.5<0;1,0>:d                                        //  ALU pipe: int; $323
        mov (32|M0)              r36.0<1>:d    r79.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $324
        mov (32|M0)              r38.0<1>:d    r79.7<0;1,0>:d                                        //  ALU pipe: int; $325
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x160] r24:8  {A@1,$11} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $321
        mov (32|M0)              r40.0<1>:d    r79.8<0;1,0>:d                   {Compacted,$9.src}   //  ALU pipe: int; $328
        mov (32|M0)              r42.0<1>:d    r79.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $329
        mov (32|M0)              r44.0<1>:d    r79.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $330
        mov (32|M0)              r46.0<1>:d    r79.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $331
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x170] r32:8  {I@5,$12} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $327
        mov (32|M0)              r16.0<1>:d    r79.12<0;1,0>:d                  {Compacted,$10.src}  //  ALU pipe: int; $334
        mov (32|M0)              r18.0<1>:d    r79.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $335
        mov (32|M0)              r20.0<1>:d    r79.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $336
        mov (32|M0)              r22.0<1>:d    r79.15<0;1,0>:d                                       //  ALU pipe: int; $337
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x180] r40:8  {I@5,$5} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $333
        mov (32|M0)              r24.0<1>:d    r59.4<0;1,0>:d                   {Compacted,$11.src}  //  ALU pipe: int; $340
        mov (32|M0)              r26.0<1>:d    r59.5<0;1,0>:d                                        //  ALU pipe: int; $341
        mov (32|M0)              r28.0<1>:d    r59.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $342
        mov (32|M0)              r30.0<1>:d    r59.7<0;1,0>:d                                        //  ALU pipe: int; $343
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x190] r16:8  {I@5,$13} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $339
        mov (32|M0)              r32.0<1>:f    r80.0<0;1,0>:f                   {Compacted,$12.src}  //  ALU pipe: float; $346
        mov (32|M0)              r34.0<1>:d    r80.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $347
        mov (32|M0)              r36.0<1>:d    r80.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $348
        mov (32|M0)              r38.0<1>:d    r80.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $349
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x1A0] r24:8  {I@4,$14} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $345
        mov (32|M0)              r40.0<1>:d    r59.8<0;1,0>:d                   {Compacted,$5.src}   //  ALU pipe: int; $352
        mov (32|M0)              r42.0<1>:d    r59.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $353
        mov (32|M0)              r44.0<1>:d    r59.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $354
        mov (32|M0)              r46.0<1>:d    r59.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $355
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x1B0] r32:8  {A@1,$15} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $351
        mov (32|M0)              r16.0<1>:d    r59.12<0;1,0>:d                  {Compacted,$13.src}  //  ALU pipe: int; $358
        mov (32|M0)              r18.0<1>:d    r59.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $359
        mov (32|M0)              r20.0<1>:d    r59.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $360
        mov (32|M0)              r22.0<1>:d    r59.15<0;1,0>:d                                       //  ALU pipe: int; $361
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x1C0] r40:8  {I@5,$0} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $357
        mov (32|M0)              r24.0<1>:f    r60.0<0;1,0>:f                   {Compacted,$14.src}  //  ALU pipe: float; $364
        mov (32|M0)              r26.0<1>:d    r60.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $365
        mov (32|M0)              r28.0<1>:d    r60.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $366
        mov (32|M0)              r30.0<1>:d    r60.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $367
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x1D0] r16:8  {I@4,$4} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $363
        mov (32|M0)              r32.0<1>:d    r60.4<0;1,0>:d                   {Compacted,$15.src}  //  ALU pipe: int; $370
        mov (32|M0)              r34.0<1>:d    r60.5<0;1,0>:d                                        //  ALU pipe: int; $371
        mov (32|M0)              r36.0<1>:d    r60.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $372
        mov (32|M0)              r38.0<1>:d    r60.7<0;1,0>:d                                        //  ALU pipe: int; $373
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x1E0] r24:8  {A@1,$9} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $369
        mov (32|M0)              r40.0<1>:d    r60.8<0;1,0>:d                   {Compacted,$0.src}   //  ALU pipe: int; $376
        mov (32|M0)              r42.0<1>:d    r60.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $377
        mov (32|M0)              r44.0<1>:d    r60.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $378
        mov (32|M0)              r46.0<1>:d    r60.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $379
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x1F0] r32:8  {I@5,$10} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $375
        mov (32|M0)              r16.0<1>:d    r60.12<0;1,0>:d                  {Compacted,$4.src}   //  ALU pipe: int; $382
        mov (32|M0)              r18.0<1>:d    r60.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $383
        mov (32|M0)              r20.0<1>:d    r60.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $384
        mov (32|M0)              r22.0<1>:d    r60.15<0;1,0>:d                                       //  ALU pipe: int; $385
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x200] r40:8  {I@5,$11} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $381
        mov (32|M0)              r24.0<1>:f    r61.0<0;1,0>:f                   {Compacted,$9.src}   //  ALU pipe: float; $388
        mov (32|M0)              r26.0<1>:d    r61.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $389
        mov (32|M0)              r28.0<1>:d    r61.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $390
        mov (32|M0)              r30.0<1>:d    r61.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $391
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x210] r16:8  {I@4,$12} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $387
        mov (32|M0)              r32.0<1>:d    r61.4<0;1,0>:d                   {Compacted,$10.src}  //  ALU pipe: int; $394
        mov (32|M0)              r34.0<1>:d    r61.5<0;1,0>:d                                        //  ALU pipe: int; $395
        mov (32|M0)              r36.0<1>:d    r61.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $396
        mov (32|M0)              r38.0<1>:d    r61.7<0;1,0>:d                                        //  ALU pipe: int; $397
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x220] r24:8  {A@1,$1} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $393
        mov (32|M0)              r40.0<1>:d    r61.8<0;1,0>:d                   {Compacted,$11.src}  //  ALU pipe: int; $400
        mov (32|M0)              r42.0<1>:d    r61.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $401
        mov (32|M0)              r44.0<1>:d    r61.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $402
        mov (32|M0)              r46.0<1>:d    r61.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $403
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x230] r32:8  {I@5,$13} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $399
        mov (32|M0)              r16.0<1>:d    r61.12<0;1,0>:d                  {Compacted,$12.src}  //  ALU pipe: int; $406
        mov (32|M0)              r18.0<1>:d    r61.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $407
        mov (32|M0)              r20.0<1>:d    r61.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $408
        mov (32|M0)              r22.0<1>:d    r61.15<0;1,0>:d                                       //  ALU pipe: int; $409
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x240] r40:8  {I@5,$14} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $405
        mov (32|M0)              r24.0<1>:f    r62.0<0;1,0>:f                   {Compacted,$1.src}   //  ALU pipe: float; $412
        mov (32|M0)              r26.0<1>:d    r62.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $413
        mov (32|M0)              r28.0<1>:d    r62.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $414
        mov (32|M0)              r30.0<1>:d    r62.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $415
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x250] r16:8  {I@4,$15} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $411
        mov (32|M0)              r32.0<1>:d    r62.4<0;1,0>:d                   {Compacted,$13.src}  //  ALU pipe: int; $418
        mov (32|M0)              r34.0<1>:d    r62.5<0;1,0>:d                                        //  ALU pipe: int; $419
        mov (32|M0)              r36.0<1>:d    r62.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $420
        mov (32|M0)              r38.0<1>:d    r62.7<0;1,0>:d                                        //  ALU pipe: int; $421
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x260] r24:8  {A@1,$0} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $417
        mov (32|M0)              r40.0<1>:d    r62.8<0;1,0>:d                   {Compacted,$14.src}  //  ALU pipe: int; $424
        mov (32|M0)              r42.0<1>:d    r62.9<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $425
        mov (32|M0)              r44.0<1>:d    r62.10<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $426
        mov (32|M0)              r46.0<1>:d    r62.11<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $427
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x270] r32:8  {I@5,$2} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $423
        mov (32|M0)              r16.0<1>:d    r62.12<0;1,0>:d                  {Compacted,$15.src}  //  ALU pipe: int; $430
        mov (32|M0)              r18.0<1>:d    r62.13<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $431
        mov (32|M0)              r20.0<1>:d    r62.14<0;1,0>:d                  {Compacted}          //  ALU pipe: int; $432
        mov (32|M0)              r22.0<1>:d    r62.15<0;1,0>:d                                       //  ALU pipe: int; $433
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x280] r40:8  {I@5,$7} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $429
        mov (32|M0)              r24.0<1>:f    r63.0<0;1,0>:f                   {Compacted,$0.src}   //  ALU pipe: float; $436
        mov (32|M0)              r26.0<1>:d    r63.1<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $437
        mov (32|M0)              r28.0<1>:d    r63.2<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $438
        mov (32|M0)              r30.0<1>:d    r63.3<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $439
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x290] r16:8  {I@4,$9} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $435
        mov (32|M0)              r32.0<1>:d    r63.4<0;1,0>:d                   {Compacted,$2.src}   //  ALU pipe: int; $442
        mov (32|M0)              r34.0<1>:d    r63.5<0;1,0>:d                                        //  ALU pipe: int; $443
        mov (32|M0)              r36.0<1>:d    r63.6<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $444
        mov (32|M0)              r38.0<1>:d    r63.7<0;1,0>:d                                        //  ALU pipe: int; $445
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x2A0] r24:8  {A@1,$8} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $441
        store.ugm.d32x4.a32.wb.wb (32|M0)  ss[a0.0][r68:2+0x2B0] r32:8  {I@1,$6} // ex_desc:a0.0; desc:0x440E3504 //  address space: private; ; $447
        load.ugm.d64.a32.ca.ca (32|M0)  r40:4   ss[a0.0][r82:2]    {$10} // ex_desc:a0.0; desc:0x44480700 // $449
        sync.nop                             null                             {Compacted,$9.src}     // $450
        mov (16|M0)              r15.0<1>:uq   r40.0<1;1,0>:uq                  {Compacted,$10.dst}  //  ALU pipe: int; $450
        mov (16|M16)             r17.0<1>:uq   r42.0<1;1,0>:uq                  {Compacted}          //  ALU pipe: int; $450
        load.ugm.d32.a64 (32|M0)  r20:2         [r15:4]            {I@1,$11} // ex_desc:0x0; desc:0x8200580 // $451
        cmp (32|M0)   (eq)f3.0   null<1>:d     r20.0<1;1,0>:d    0:w               {$11.dst}         //  ALU pipe: int; $452
(f3.0)  goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $453
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B026}
_0_038:
        sync.allrd                           ($6,$7,$8)                                              // $455
(W)     shr (1|M0)               a0.0<1>:ud    r56.5<0;1,0>:ud   0x4:uw              {$4.src}        //  ALU pipe: int; $455
        mov (32|M0)              r20.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $458
        load.ugm.d64.a32.ca.ca (32|M0)  r15:4   ss[a0.0][r84:2]    {$12} // ex_desc:a0.0; desc:0x44480700 // $456
        mov (16|M0)              r88.0<1>:uq   r15.0<1;1,0>:uq                  {Compacted,$12.dst}  //  ALU pipe: int; $457
        mov (16|M16)             r90.0<1>:uq   r17.0<1;1,0>:uq                  {Compacted}          //  ALU pipe: int; $457
        atomic_or.ugm.d32.a64 (32|M0)  r22:2    [r88:4]           r20:2              {I@1,$3} // ex_desc:0x0; desc:0x8200599 // $459
        cmp (32|M0)   (eq)f3.0   null<1>:d     r22.0<1;1,0>:d    0:w               {$3.dst}          //  ALU pipe: int; $461
(~f3.0) goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $462
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_039:
(W)     shr (1|M0)               a0.0<1>:ud    r56.5<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $465
        mov (16|M0)              r16.0<1>:d    r108.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $464
        mov (16|M16)             r17.0<1>:d    r110.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $464
        shl (32|M0)              r96.0<1>:d    r16.0<1;1,0>:d    4:w               {Compacted,I@1}   //  ALU pipe: int; $467
        load.ugm.d64.a32.ca.ca (32|M0)  r92:4   ss[a0.0][r86:2]    {$5} // ex_desc:a0.0; desc:0x44480700 // $466
        add (32|M0)              r18.0<1>:d    r96.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $468
        sel (32|M0)   (lt)f0.0   r98.0<1>:d    r18.0<1;1,0>:d    512:w               {I@1}           //  ALU pipe: int; $469
        cmp (32|M0)   (lt)f3.0   null<1>:d     r96.0<1;1,0>:d    r98.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $470
(f3.0)  goto (32|M0)                         _0_040            _0_040                                //  ALU pipe: int; $471
// B007: [inDivergent],  Preds:{B006},  Succs:{B025}
_0_041:
        mov (32|M0)              r100.0<1>:ud  0xFF800000:ud                                         //  ALU pipe: int; $473
        goto (32|M0)                         _0_040            _0_042                                // $474
// B008: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_040:
        join (32|M0)                         _0_042                                                  // 
L5696:
        mov (32|M0)              r100.0<1>:ud  0xFF800000:ud                                         //  ALU pipe: int; $476
// B009: [inDivergent],  Preds:{B024, B008},  Succs:{B010, B017}
_0_043:
(W)     mov (1|M0)               f3.0<1>:ud    r80.6<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $479
        mov (16|M0)              r16.0<2>:ud   r96.0<1;1,0>:ud                  {Compacted,$13.src}  //  ALU pipe: int; $478
        mov (16|M16)             r18.0<2>:ud   r97.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $478
        mov (16|M0)              r112.0<1>:q   r16.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $478
        mov (16|M16)             r114.0<1>:q   r18.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $478
(W&f3.0) jmpi                                _0_044                                                  //  ALU pipe: int; $479
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B016}
_0_045:
(W)     mov (1|M0)               f3.0<1>:ud    r80.5<0;1,0>:ud                                       //  ALU pipe: int; $481
(W&f3.0) jmpi                                _0_046                                                  //  ALU pipe: int; $481
// B011: [inDivergent],  Preds:{B010},  Succs:{B012, B015}
_0_047:
(W)     mov (1|M0)               f3.0<1>:ud    r80.4<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $483
(W&f3.0) jmpi                                _0_048                                                  //  ALU pipe: int; $483
// B012: [inDivergent],  Preds:{B011},  Succs:{B013, B014}
_0_049:
(W&f2.0) jmpi                                _0_050                                                  //  ALU pipe: int; $485
// B013: [inDivergent],  Preds:{B012},  Succs:{B022}
_0_051:
        mov (32|M0)              r102.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $487
(W)     jmpi                                 _0_052                                                  // $488
// B014: [inDivergent],  Preds:{B012},  Succs:{B022}
_0_050:
        shl (16|M0)              r15.0<1>:q    r112.0<1;1,0>:q   3:w               {Compacted,I@7}   //  ALU pipe: int; $490
        shl (16|M16)             r17.0<1>:q    r114.0<1;1,0>:q   3:w               {Compacted,I@7}   //  ALU pipe: int; $490
        add (16|M0)              r19.0<1>:q    r15.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $491
        add (16|M16)             r21.0<1>:q    r17.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $491
        load.ugm.d64.a64 (32|M0)  r23:4         [r19:4]            {I@1,$14} // ex_desc:0x0; desc:0x8400780 // $493
        mov (16|M0)              r28.0<2>:f    r23.0<1;1,0>:q                   {$14.dst}            //  ALU pipe: float; $494
        mov (16|M16)             r30.0<2>:f    r25.0<1;1,0>:q                                        //  ALU pipe: float; $494
        mov (16|M0)              r102.0<1>:ud  r28.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $494
        mov (16|M16)             r103.0<1>:ud  r30.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $494
(W)     jmpi                                 _0_052                                                  // $495
// B015: [inDivergent],  Preds:{B011},  Succs:{B022}
_0_048:
        shl (16|M0)              r15.0<1>:q    r112.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $497
        shl (16|M16)             r17.0<1>:q    r114.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $497
        add (16|M0)              r19.0<1>:q    r15.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $498
        add (16|M16)             r21.0<1>:q    r17.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $498
        load.ugm.d32.a64 (32|M0)  r24:2         [r19:4]            {I@1,$15} // ex_desc:0x0; desc:0x8200580 // $500
        mov (32|M0)              r102.0<1>:f   r24.0<1;1,0>:ud                  {$15.dst}            //  ALU pipe: float; $501
(W)     jmpi                                 _0_052                                                  // $502
// B016: [inDivergent],  Preds:{B010},  Succs:{B022}
_0_046:
        shl (16|M0)              r15.0<1>:q    r112.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $504
        shl (16|M16)             r17.0<1>:q    r114.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $504
        add (16|M0)              r19.0<1>:q    r15.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $505
        add (16|M16)             r21.0<1>:q    r17.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $505
        load.ugm.d32.a64 (32|M0)  r24:2         [r19:4]            {A@1,$0} // ex_desc:0x0; desc:0x8200580 // $507
        mov (32|M0)              r102.0<1>:f   r24.0<1;1,0>:d                   {$0.dst}             //  ALU pipe: float; $508
(W)     jmpi                                 _0_052                                                  // $509
// B017: [inDivergent],  Preds:{B009},  Succs:{B018, B021}
_0_044:
(W&~f1.0) jmpi                               _0_053                                                  //  ALU pipe: int; $511
// B018: [inDivergent],  Preds:{B017},  Succs:{B019, B020}
_0_054:
(W&f0.0) jmpi                                _0_055                                                  //  ALU pipe: int; $513
// B019: [inDivergent],  Preds:{B018},  Succs:{B022}
_0_056:
        mov (32|M0)              r102.0<1>:ud  0x0:ud                              {Compacted,F@1}   //  ALU pipe: int; $515
(W)     jmpi                                 _0_052                                                  // $516
// B020: [inDivergent],  Preds:{B018},  Succs:{B022}
_0_055:
        shl (16|M0)              r15.0<1>:q    r112.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $518
        shl (16|M16)             r17.0<1>:q    r114.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $518
        add (16|M0)              r19.0<1>:q    r15.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $519
        add (16|M16)             r21.0<1>:q    r17.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $519
        load.ugm.d16u32.a64 (32|M0)  r24:2      [r19:4]            {I@1,$9} // ex_desc:0x0; desc:0x8200B80 // $521
        shl (32|M0)              r102.0<1>:d   r24.0<1;1,0>:ud   16:w               {$9.dst}         //  ALU pipe: int; $522
(W)     jmpi                                 _0_052                                                  // $523
// B021: [inDivergent],  Preds:{B017},  Succs:{B022}
_0_053:
        shl (16|M0)              r15.0<1>:q    r112.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $525
        shl (16|M16)             r17.0<1>:q    r114.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $525
        add (16|M0)              r19.0<1>:q    r15.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $526
        add (16|M16)             r21.0<1>:q    r17.0<1;1,0>:q    r10.5<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $526
        load.ugm.d32.a64 (32|M0)  r102:2        [r19:4]            {I@1,$10} // ex_desc:0x0; desc:0x8200580 // $528
// B022: [inDivergent],  Preds:{B021, B020, B019, B016, B015, B014, B013},  Succs:{B023, B024}
_0_052:
        and (32|M0)              r16.0<1>:d    r102.0<1;1,0>:d   2147483647:d               {$10.dst} //  ALU pipe: int; $530
        cmp (32|M0)   (eq)f3.0   null<1>:f     r16.0<1;1,0>:f    0x7F800000:f               {I@1}    //  ALU pipe: float; $531
(~f3.0) cmp (32|M0)   (ne)f3.0   null<1>:f     r16.0<1;1,0>:f    r16.0<1;1,0>:f                      //  ALU pipe: float; $532
(~f3.0) goto (32|M0)                         _0_057            _0_057                                //  ALU pipe: int; $534
// B023: [inDivergent],  Preds:{B022},  Succs:{B026}
_0_058:
        mov (32|M0)              r16.0<1>:d    1:w                               {Compacted,F@1}     //  ALU pipe: int; $536
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r88:4]          r16:2              {I@1,$13} // ex_desc:0x0; desc:0x800058B // $537
        goto (32|M0)                         _0_057            _0_037                                // $538
// B024: [inDivergent],  Preds:{B022},  Succs:{B025, B009}
_0_057:
        join (32|M0)                         _0_042                                                  // 
L6456:
        cmp (32|M0)   (lt)f3.0   null<1>:f     r100.0<1;1,0>:f   r102.0<1;1,0>:f                     //  ALU pipe: float; $540
        add (32|M0)              r96.0<1>:d    r96.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $542
(f3.0)  mov (32|M0)              r100.0<1>:f   r102.0<1;1,0>:f                                       //  ALU pipe: float; $541
        cmp (32|M0)   (lt)f3.0   null<1>:d     r96.0<1;1,0>:d    r98.0<1;1,0>:d   {A@1}              //  ALU pipe: int; $543
(f3.0)  goto.b (32|M0)                       _0_042            _0_043                                //  ALU pipe: int; $544
// B025: [inDivergent],  Preds:{B024, B007},  Succs:{B026}
_0_042:
        join (32|M0)                         _0_037                                                  // 
L6544:
        shl (16|M0)              r15.0<1>:q    r108.0<1;1,0>:q   2:w               {Compacted,$13.src} //  ALU pipe: int; $546
        shl (16|M16)             r17.0<1>:q    r110.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $546
        add (16|M0)              r19.0<1>:q    r15.0<1;1,0>:q    r92.0<1;1,0>:q   {Compacted,@2,$5.dst} //  ALU pipe: int; $547
        add (16|M16)             r21.0<1>:q    r17.0<1;1,0>:q    r94.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $547
        store.ugm.d32.a64 (32|M0)  [r19:4]      r100:2             {I@1,$11} // ex_desc:0x0; desc:0x8000584 // $549
// B026: [inDivergent],  Preds:{B025, B023, B005, B004},  Succs:{B027, B028}
_0_037:
        join (32|M0)                         _0_034                                                  // 
L6608:
        add (16|M0)              r15.0<1>:q    r108.0<1;1,0>:q   r63.7<0;1,0>:q   {Compacted,$13.src} //  ALU pipe: int; $551
        add (16|M16)             r17.0<1>:q    r110.0<1;1,0>:q   r63.7<0;1,0>:q   {Compacted}        //  ALU pipe: int; $551
        mov (16|M0)              r104.0<1>:d   r15.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $552
        mov (16|M16)             r105.0<1>:d   r17.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $553
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r104.0<1;1,0>:ud  r63.8<0;1,0>:ud  {I@1}              //  ALU pipe: int; $556
        mov (16|M0)              r106.0<1>:d   r15.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $554
        mov (16|M16)             r107.0<1>:d   r17.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $555
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r106.0<1;1,0>:d   r63.9<0;1,0>:d   {I@1}              //  ALU pipe: int; $557
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r106.0<1;1,0>:ud  r63.9<0;1,0>:ud                     //  ALU pipe: int; $559
(~f3.0) goto (32|M0)                         _0_034            _0_034                                //  ALU pipe: int; $561
// B027: [inDivergent],  Preds:{B026},  Succs:{B004}
_0_059:
(f3.0)  sel (32|M0)              r16.0<1>:d    r104.0<1;1,0>:d   r64.0<1;1,0>:d                      //  ALU pipe: int; $563
(f3.0)  sel (32|M0)              r18.0<1>:d    r106.0<1;1,0>:d   r66.0<1;1,0>:d   {$11.src}          //  ALU pipe: int; $564
        mov (16|M0)              r108.0<2>:d   r16.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $567
        mov (16|M16)             r110.0<2>:d   r17.0<1;1,0>:d                                        //  ALU pipe: int; $568
        mov (16|M0)              r108.1<2>:d   r18.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $569
        mov (16|M16)             r110.1<2>:d   r19.0<1;1,0>:d                                        //  ALU pipe: int; $570
(W)     jmpi                                 _0_036                                                  // $571
// B028: Preds:{B026, B002},  Succs:{}
_0_034:
        join (32|M0)                         L6848                                                   // 
L6848:
        sync.allrd                           ($2,$3)                                                 // $573
(W)     mov (16|M0)              r127.0<1>:f   r56.0<1;1,0>:f                   {Compacted,$1.src}   //  ALU pipe: float; $573
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$12} // wr:1+0, rd:0; end of thread // $573
L6888:
(W)     mov (16|M0)              null<1>:ud    0x9BA73454:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xE55156EA:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x4:ud                                                // 


//.BankConflicts: 0
//.ByteRMWs: 12
//


//.numALUInst: 456
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 27
//.allAtOneDistNum: 16
//.syncInstCount: 2
//.tokenReuseCount: 8
//.AfterWriteTokenDepCount: 14
//.AfterReadTokenDepCount: 57
