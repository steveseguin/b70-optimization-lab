//.kernel _ZTSN7p42tiny17CooperativeKernelILi10ELi128EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 846394448 1255737677 -hashmovs1 0 3 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 846394448 1255737677 -hashmovs1 0 3 -GRFBumpUpNumber 2 "
//.instCount 801
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.private memory size 128

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r50.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.12)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.13)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.8)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.9)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.10)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.11)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r50.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r50.0)
//.declare V0037 (47)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0041 (51)  rf=r size=4 type=d align=2 words (r2.2)
//.declare V0042 (52)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r2.4)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r2.5)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r2.6)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r2.7)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0068 (78)  rf=r size=64 type=w align=32 words (r55.0)
//.declare V0069 (79)  rf=r size=8 type=uq alias=V0064+0 align=32 words (r5.0)
//.declare P01 (80)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P02 (81)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0070 (82)  rf=r size=8 type=uq alias=V0067+0 align=32 words (r5.3)
//.declare V0071 (83)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0072 (84)  rf=r size=4 type=d align=32 words (r6.0)
//.declare P03 (85)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0073 (86)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0074 (87)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0076 (89)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0077 (90)  rf=r size=256 type=ud alias=V0076+0 align=32 words (r6.0)
//.declare V0078 (91)  rf=r size=8 type=ud alias=V0074+0 align=32 words (r2.0)
//.declare V0079 (92)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0080 (93)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P04 (95)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0083 (97)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (98)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (99)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (100)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare V0084 (101)  rf=r size=4 type=f align=32 words (r9.0)
//.declare V0085 (102)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare P05 (103)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0086 (104)  rf=r size=8 type=uq alias=V0066+0 align=32 words (r5.2)
//.declare  (105)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (106)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (107)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare V0087 (108)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0088 (109)  rf=r size=4 type=d align=32 words (r52.0)
//.declare V0089 (110)  rf=r size=4 type=d align=2 words (r2.2)
//.declare P06 (111)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P07 (112)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P08 (113)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0090 (114)  rf=r size=2 type=w align=1 words (r3.2)
//.declare V0091 (115)  rf=r size=2 type=b align=1 words (r4.8)
//.declare V0092 (116)  rf=r size=4 type=d align=2 words (r5.8)
//.declare V0093 (117)  rf=r size=2 type=ub alias=V0091+0 align=1 words (r4.8)
//.declare V0094 (118)  rf=r size=4 type=d align=2 words (r6.0)
//.declare V0095 (119)  rf=r size=4 type=d align=2 words (r7.0)
//.declare P09 (120)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0096 (121)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0097 (122)  rf=r size=4 type=ud alias=V0088+0 align=32 words (r52.0)
//.declare V0098 (123)  rf=r size=4 type=ud alias=V0096+0 align=2 words (r2.0)
//.declare P10 (124)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0099 (125)  rf=r size=32 type=ud alias=V0035+0 align=32 words (r50.0)
//.declare V0100 (126)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0101 (127)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0102 (128)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0103 (129)  rf=r size=4 type=d align=2 words (r2.1)
//.declare  (130)  rf=f16  size=2 type=uw align=1 words (f1.0)
//.declare V0104 (131)  rf=r size=4 type=d align=2 words (r5.8)
//.declare P11 (132)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0105 (133)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0106 (134)  rf=r size=64 type=uw alias=V0037+0 align=32 words (r1.0)
//.declare P12 (135)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0107 (136)  rf=r size=4 type=d align=2 words (r4.3)
//.declare V0108 (137)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0109 (138)  rf=r size=4 type=d align=2 words (r4.4)
//.declare P13 (139)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0110 (140)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0111 (141)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0112 (142)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0116 (146)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0117 (147)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0119 (149)  rf=r size=128 type=ud alias=V0117+0 align=32 words (r6.0)
//.declare V0122 (152)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0124 (154)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare V0125 (155)  rf=r size=128 type=w alias=V0124+0 align=32 words (r10.0)
//.declare V0127 (157)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0128 (158)  rf=r size=128 type=f align=32 words (r100.0)
//.declare V0129 (159)  rf=r size=128 type=f alias=V0127+0 align=32 words (r12.0)
//.declare V0130 (160)  rf=r size=4 type=d align=2 words (r4.5)
//.declare P14 (161)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0131 (162)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0132 (163)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0133 (164)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0137 (168)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0138 (169)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0140 (171)  rf=r size=128 type=ud alias=V0138+0 align=32 words (r6.0)
//.declare V0143 (174)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0145 (176)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare V0146 (177)  rf=r size=128 type=w alias=V0145+0 align=32 words (r10.0)
//.declare V0148 (179)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0149 (180)  rf=r size=128 type=f align=32 words (r98.0)
//.declare V0150 (181)  rf=r size=128 type=f alias=V0148+0 align=32 words (r12.0)
//.declare V0151 (182)  rf=r size=4 type=d align=2 words (r4.5)
//.declare P15 (183)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0152 (184)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0153 (185)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0154 (186)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0158 (190)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0159 (191)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0161 (193)  rf=r size=128 type=ud alias=V0159+0 align=32 words (r6.0)
//.declare V0164 (196)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0166 (198)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare V0167 (199)  rf=r size=128 type=w alias=V0166+0 align=32 words (r10.0)
//.declare V0169 (201)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0170 (202)  rf=r size=128 type=f align=32 words (r96.0)
//.declare V0171 (203)  rf=r size=128 type=f alias=V0169+0 align=32 words (r12.0)
//.declare V0172 (204)  rf=r size=4 type=d align=2 words (r4.5)
//.declare P16 (205)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0173 (206)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0174 (207)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0175 (208)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0179 (212)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0180 (213)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0182 (215)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r6.0)
//.declare V0185 (218)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0187 (220)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare V0188 (221)  rf=r size=128 type=w alias=V0187+0 align=32 words (r10.0)
//.declare V0190 (223)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0192 (225)  rf=r size=128 type=f alias=V0190+0 align=32 words (r12.0)
//.declare V0193 (226)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0194 (227)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0195 (228)  rf=r size=128 type=d alias=V0193+0 align=32 words (r80.0)
//.declare P17 (229)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0196 (230)  rf=r size=128 type=ud alias=V0194+0 align=32 words (r14.0)
//.declare V0197 (231)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0198 (232)  rf=r size=128 type=ud alias=V0193+0 align=32 words (r80.0)
//.declare V0199 (233)  rf=r size=128 type=ud alias=V0197+0 align=32 words (r6.0)
//.declare V0200 (234)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0201 (235)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0202 (236)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0203 (237)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0204 (238)  rf=r size=128 type=f alias=V0202+0 align=32 words (r82.0)
//.declare V0205 (239)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0206 (240)  rf=r size=128 type=ud alias=V0205+0 align=32 words (r8.0)
//.declare  (241)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (242)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (243)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare P18 (244)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0207 (245)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0208 (246)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0209 (247)  rf=r size=128 type=ud alias=V0208+0 align=32 words (r64.0)
//.declare V0210 (248)  rf=r size=128 type=f align=32 words (r86.0)
//.declare V0211 (249)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P19 (250)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0212 (251)  rf=r size=128 type=ud alias=V0211+0 align=32 words (r8.0)
//.declare V0213 (252)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0214 (253)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0215 (254)  rf=r size=128 type=ud alias=V0214+0 align=32 words (r6.0)
//.declare V0216 (255)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (256)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (257)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (258)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare P20 (259)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0217 (260)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0218 (261)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0219 (262)  rf=r size=128 type=ud alias=V0218+0 align=32 words (r62.0)
//.declare V0220 (263)  rf=r size=128 type=f align=32 words (r84.0)
//.declare V0221 (264)  rf=r size=128 type=d align=32 words (r126.0)
//.declare P21 (265)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0222 (266)  rf=r size=128 type=ud alias=V0221+0 align=32 words (r126.0)
//.declare V0223 (267)  rf=r size=128 type=f align=32 words (r124.0)
//.declare V0224 (268)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0225 (269)  rf=r size=128 type=ud alias=V0224+0 align=32 words (r6.0)
//.declare V0226 (270)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (271)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (272)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (273)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare P22 (274)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0227 (275)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0228 (276)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0229 (277)  rf=r size=128 type=ud alias=V0228+0 align=32 words (r60.0)
//.declare V0230 (278)  rf=r size=128 type=f align=32 words (r82.0)
//.declare V0231 (279)  rf=r size=128 type=d align=32 words (r122.0)
//.declare P23 (280)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0232 (281)  rf=r size=128 type=ud alias=V0231+0 align=32 words (r122.0)
//.declare V0233 (282)  rf=r size=128 type=f align=32 words (r120.0)
//.declare V0234 (283)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0235 (284)  rf=r size=128 type=ud alias=V0234+0 align=32 words (r6.0)
//.declare V0236 (285)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (286)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (287)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (288)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare P24 (289)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0237 (290)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0238 (291)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0239 (292)  rf=r size=128 type=ud alias=V0238+0 align=32 words (r58.0)
//.declare V0240 (293)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0241 (294)  rf=r size=128 type=d align=32 words (r118.0)
//.declare P25 (295)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0242 (296)  rf=r size=128 type=ud alias=V0241+0 align=32 words (r118.0)
//.declare V0243 (297)  rf=r size=128 type=f align=32 words (r116.0)
//.declare V0244 (298)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0245 (299)  rf=r size=128 type=ud alias=V0244+0 align=32 words (r6.0)
//.declare V0246 (300)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (301)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (302)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (303)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare P26 (304)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0247 (305)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0248 (306)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0249 (307)  rf=r size=128 type=ud alias=V0248+0 align=32 words (r56.0)
//.declare V0250 (308)  rf=r size=128 type=f align=32 words (r78.0)
//.declare V0251 (309)  rf=r size=128 type=d align=32 words (r114.0)
//.declare P27 (310)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0252 (311)  rf=r size=128 type=ud alias=V0251+0 align=32 words (r114.0)
//.declare V0253 (312)  rf=r size=128 type=f align=32 words (r112.0)
//.declare V0254 (313)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0255 (314)  rf=r size=128 type=ud alias=V0254+0 align=32 words (r6.0)
//.declare V0256 (315)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (316)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (317)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (318)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare P28 (319)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0257 (320)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0258 (321)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0259 (322)  rf=r size=128 type=ud alias=V0258+0 align=32 words (r48.0)
//.declare V0260 (323)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0261 (324)  rf=r size=128 type=d align=32 words (r110.0)
//.declare P29 (325)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0262 (326)  rf=r size=128 type=ud alias=V0261+0 align=32 words (r110.0)
//.declare V0263 (327)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0264 (328)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0265 (329)  rf=r size=128 type=ud alias=V0264+0 align=32 words (r6.0)
//.declare V0266 (330)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (331)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (332)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (333)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare P30 (334)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0267 (335)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0268 (336)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0269 (337)  rf=r size=128 type=ud alias=V0268+0 align=32 words (r44.0)
//.declare V0270 (338)  rf=r size=128 type=f align=32 words (r74.0)
//.declare V0271 (339)  rf=r size=128 type=d align=32 words (r106.0)
//.declare P31 (340)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0272 (341)  rf=r size=128 type=ud alias=V0271+0 align=32 words (r106.0)
//.declare V0273 (342)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0274 (343)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0275 (344)  rf=r size=128 type=ud alias=V0274+0 align=32 words (r6.0)
//.declare V0276 (345)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (346)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (347)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (348)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare V0277 (349)  rf=r size=4 type=f align=32 words (r10.0)
//.declare V0278 (350)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare  (352)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare  (353)  rf=r size=64 type=f align=32 words (r12.0)
//.declare  (354)  rf=r size=64 type=f align=32 words (r72.0)
//.declare  (355)  rf=r size=64 type=f align=32 words (r11.0)
//.declare  (356)  rf=r size=64 type=f align=32 words (r6.0)
//.declare  (357)  rf=r size=64 type=f align=32 words (r7.0)
//.declare  (358)  rf=r size=64 type=f align=32 words (r8.0)
//.declare  (359)  rf=r size=64 type=f align=32 words (r10.0)
//.declare  (360)  rf=r size=64 type=f align=32 words (r53.0)
//.declare  (361)  rf=r size=64 type=f align=32 words (r51.0)
//.declare  (362)  rf=r size=64 type=f align=32 words (r9.0)
//.declare V0282 (367)  rf=r size=64 type=uw alias=V0068+0 align=32 words (r55.0)
//.declare V0283 (368)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0284 (369)  rf=r size=128 type=ud alias=V0283+0 align=32 words (r14.0)
//.declare  (371)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare  (372)  rf=r size=64 type=f align=32 words (r13.0)
//.declare  (373)  rf=r size=64 type=f align=32 words (r8.0)
//.declare  (374)  rf=r size=64 type=f align=32 words (r10.0)
//.declare  (375)  rf=r size=64 type=f align=32 words (r7.0)
//.declare  (376)  rf=r size=64 type=f align=32 words (r9.0)
//.declare  (377)  rf=r size=64 type=f align=32 words (r54.0)
//.declare V0287 (381)  rf=r size=128 type=d align=32 words (r16.0)
//.declare  (383)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0289 (384)  rf=r size=128 type=d align=32 words (r48.0)
//.declare  (386)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare  (387)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (388)  rf=r size=64 type=ud align=32 words (r11.0)
//.declare  (389)  rf=r size=32 type=ud align=32 words (r12.0)
//.declare V0291 (390)  rf=r size=4 type=d align=2 words (r4.4)
//.declare P32 (391)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0292 (392)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0293 (393)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0294 (394)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0298 (398)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0299 (399)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0301 (401)  rf=r size=128 type=ud alias=V0299+0 align=32 words (r6.0)
//.declare V0304 (404)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0306 (406)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare V0307 (407)  rf=r size=128 type=w alias=V0306+0 align=32 words (r10.0)
//.declare V0309 (409)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0310 (410)  rf=r size=128 type=f align=32 words (r94.0)
//.declare V0311 (411)  rf=r size=128 type=f alias=V0309+0 align=32 words (r12.0)
//.declare V0312 (412)  rf=r size=4 type=d align=2 words (r4.5)
//.declare P33 (413)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0313 (414)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0314 (415)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0315 (416)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0319 (420)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0320 (421)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0322 (423)  rf=r size=128 type=ud alias=V0320+0 align=32 words (r6.0)
//.declare V0325 (426)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0327 (428)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare V0328 (429)  rf=r size=128 type=w alias=V0327+0 align=32 words (r10.0)
//.declare V0330 (431)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0331 (432)  rf=r size=128 type=f align=32 words (r92.0)
//.declare V0332 (433)  rf=r size=128 type=f alias=V0330+0 align=32 words (r12.0)
//.declare V0333 (434)  rf=r size=4 type=d align=2 words (r4.5)
//.declare P34 (435)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0334 (436)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0335 (437)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0336 (438)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0340 (442)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0341 (443)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0343 (445)  rf=r size=128 type=ud alias=V0341+0 align=32 words (r6.0)
//.declare V0346 (448)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0348 (450)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare V0349 (451)  rf=r size=128 type=w alias=V0348+0 align=32 words (r10.0)
//.declare V0351 (453)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0352 (454)  rf=r size=128 type=f align=32 words (r90.0)
//.declare V0353 (455)  rf=r size=128 type=f alias=V0351+0 align=32 words (r12.0)
//.declare V0354 (456)  rf=r size=4 type=d align=2 words (r4.5)
//.declare P35 (457)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0355 (458)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0356 (459)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0357 (460)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0361 (464)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0362 (465)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0364 (467)  rf=r size=128 type=ud alias=V0362+0 align=32 words (r6.0)
//.declare V0367 (470)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0369 (472)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare V0370 (473)  rf=r size=128 type=w alias=V0369+0 align=32 words (r10.0)
//.declare V0372 (475)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0374 (477)  rf=r size=128 type=f alias=V0372+0 align=32 words (r12.0)
//.declare V0375 (478)  rf=r size=128 type=f align=32 words (r78.0)
//.declare V0376 (479)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0377 (480)  rf=r size=128 type=d alias=V0375+0 align=32 words (r78.0)
//.declare P36 (481)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0378 (482)  rf=r size=128 type=ud alias=V0376+0 align=32 words (r14.0)
//.declare V0379 (483)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0380 (484)  rf=r size=128 type=ud alias=V0375+0 align=32 words (r78.0)
//.declare V0381 (485)  rf=r size=128 type=ud alias=V0379+0 align=32 words (r6.0)
//.declare V0382 (486)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0383 (487)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0384 (488)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0386 (490)  rf=r size=128 type=f alias=V0289+0 align=32 words (r48.0)
//.declare  (491)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (492)  rf=r size=128 type=f align=32 words (r70.0)
//.declare  (493)  rf=r size=128 type=f align=32 words (r68.0)
//.declare  (494)  rf=r size=128 type=f align=32 words (r66.0)
//.declare  (495)  rf=r size=128 type=f align=32 words (r64.0)
//.declare  (496)  rf=r size=128 type=f align=32 words (r62.0)
//.declare  (497)  rf=r size=128 type=f align=32 words (r60.0)
//.declare  (498)  rf=r size=128 type=f align=32 words (r58.0)
//.declare  (499)  rf=r size=128 type=f align=32 words (r56.0)
//.declare V0387 (502)  rf=r size=128 type=f align=32 words (r88.0)
//.declare V0388 (503)  rf=r size=128 type=f alias=V0384+0 align=32 words (r68.0)
//.declare P37 (505)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0390 (506)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0394 (510)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0395 (511)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0399 (515)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0401 (517)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0402 (518)  rf=r size=128 type=w alias=V0401+0 align=32 words (r14.0)
//.declare V0404 (520)  rf=r size=128 type=d alias=V0395+0 align=32 words (r70.0)
//.declare V0405 (521)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0406 (522)  rf=r size=4 type=f align=2 words (r3.1)
//.declare V0407 (523)  rf=r size=4 type=ud alias=V0405+0 align=2 words (r2.0)
//.declare V0409 (525)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0410 (526)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0411 (527)  rf=r size=128 type=d alias=V0409+0 align=32 words (r76.0)
//.declare P38 (528)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0412 (529)  rf=r size=128 type=ud alias=V0410+0 align=32 words (r6.0)
//.declare V0413 (530)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0414 (531)  rf=r size=128 type=ud alias=V0409+0 align=32 words (r76.0)
//.declare V0415 (532)  rf=r size=128 type=ud alias=V0413+0 align=32 words (r6.0)
//.declare V0416 (533)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0417 (534)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0418 (535)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0419 (536)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0420 (537)  rf=r size=128 type=ud alias=V0419+0 align=32 words (r6.0)
//.declare  (538)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (539)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (540)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare V0421 (541)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0422 (542)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0423 (543)  rf=r size=128 type=ud alias=V0422+0 align=32 words (r6.0)
//.declare V0424 (544)  rf=r size=128 type=f align=32 words (r74.0)
//.declare V0425 (545)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0427 (547)  rf=r size=64 type=w align=32 words (r6.0)
//.declare V0429 (549)  rf=r size=64 type=uw alias=V0427+0 align=32 words (r6.0)
//.declare V0430 (550)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0435 (555)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare V0436 (556)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0438 (558)  rf=r size=128 type=w alias=V0436+0 align=32 words (r22.0)
//.declare V0441 (561)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0443 (563)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0444 (564)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0446 (566)  rf=r size=128 type=d align=32 words (r94.0)
//.declare V0447 (567)  rf=r size=64 type=w align=32 words (r7.0)
//.declare V0448 (568)  rf=r size=128 type=d align=32 words (r88.0)
//.declare V0449 (569)  rf=r size=64 type=uw alias=V0447+0 align=32 words (r7.0)
//.declare V0450 (570)  rf=r size=128 type=ud align=32 words (r90.0)
//.declare V0451 (571)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0452 (572)  rf=r size=128 type=ud alias=V0451+0 align=32 words (r6.0)
//.declare V0453 (573)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0454 (574)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0456 (576)  rf=r size=128 type=f alias=V0443+0 align=32 words (r42.0)
//.declare V0458 (578)  rf=r size=128 type=f alias=V0446+0 align=32 words (r94.0)
//.declare V0459 (579)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0460 (580)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0461 (581)  rf=r size=128 type=ud alias=V0460+0 align=32 words (r8.0)
//.declare V0462 (582)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0465 (585)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0466 (586)  rf=r size=128 type=d alias=V0424+0 align=32 words (r74.0)
//.declare P39 (587)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0467 (588)  rf=r size=128 type=ud alias=V0465+0 align=32 words (r6.0)
//.declare V0468 (589)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0469 (590)  rf=r size=128 type=ud alias=V0424+0 align=32 words (r74.0)
//.declare V0470 (591)  rf=r size=128 type=ud alias=V0468+0 align=32 words (r6.0)
//.declare V0471 (592)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0472 (593)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0473 (594)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0474 (595)  rf=r size=128 type=ud alias=V0472+0 align=32 words (r10.0)
//.declare V0475 (596)  rf=r size=128 type=ud alias=V0473+0 align=32 words (r12.0)
//.declare V0476 (597)  rf=r size=64 type=w align=32 words (r72.0)
//.declare V0477 (598)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0478 (599)  rf=r size=128 type=ud alias=V0477+0 align=32 words (r6.0)
//.declare V0480 (601)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0482 (603)  rf=r size=128 type=ud alias=V0480+0 align=32 words (r6.0)
//.declare V0486 (607)  rf=r size=256 type=uq align=32 words (r16.0)
//.declare V0487 (608)  rf=r size=64 type=uw alias=V0476+0 align=32 words (r72.0)
//.declare V0488 (609)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare  (610)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (611)  rf=r size=64 type=ud align=32 words (r7.0)
//.declare  (612)  rf=r size=32 type=ud align=32 words (r8.0)
//.declare V0489 (613)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0490 (614)  rf=r size=128 type=d align=32 words (r40.0)
//.declare P40 (615)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0491 (616)  rf=r size=4 type=d align=2 words (r2.1)
//.declare V0492 (617)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0493 (618)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0495 (620)  rf=r size=128 type=ud alias=V0492+0 align=32 words (r44.0)
//.declare V0499 (624)  rf=r size=256 type=uq align=32 words (r20.0)
//.declare V0501 (626)  rf=r size=128 type=ud align=32 words (r32.0)
//.declare V0502 (627)  rf=r size=128 type=w alias=V0501+0 align=32 words (r32.0)
//.declare V0505 (630)  rf=r size=256 type=uq align=32 words (r28.0)
//.declare V0506 (631)  rf=r size=64 type=w align=32 words (r10.0)
//.declare V0507 (632)  rf=r size=64 type=w align=32 words (r11.0)
//.declare V0508 (633)  rf=r size=64 type=w align=32 words (r16.0)
//.declare V0509 (634)  rf=r size=64 type=w align=32 words (r39.0)
//.declare V0510 (635)  rf=r size=64 type=uw alias=V0506+0 align=32 words (r10.0)
//.declare V0511 (636)  rf=r size=64 type=uw alias=V0509+0 align=32 words (r39.0)
//.declare  (637)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0513 (639)  rf=r size=128 type=ud alias=V0493+0 align=32 words (r10.0)
//.declare V0517 (643)  rf=r size=256 type=uq align=32 words (r34.0)
//.declare V0518 (644)  rf=r size=64 type=uw alias=V0508+0 align=32 words (r16.0)
//.declare V0519 (645)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare V0521 (647)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare V0522 (648)  rf=r size=128 type=w alias=V0521+0 align=32 words (r12.0)
//.declare V0523 (649)  rf=r size=64 type=w align=32 words (r14.0)
//.declare V0524 (650)  rf=r size=64 type=w align=32 words (r15.0)
//.declare V0525 (651)  rf=r size=64 type=w align=32 words (r21.0)
//.declare V0526 (652)  rf=r size=64 type=uw alias=V0523+0 align=32 words (r14.0)
//.declare V0527 (653)  rf=r size=64 type=uw alias=V0525+0 align=32 words (r21.0)
//.declare  (654)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0530 (657)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0531 (658)  rf=r size=64 type=uw alias=V0524+0 align=32 words (r15.0)
//.declare V0532 (659)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare V0533 (660)  rf=r size=128 type=d align=32 words (r42.0)
//.declare P41 (661)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0534 (662)  rf=r size=4 type=d align=2 words (r5.2)
//.declare P42 (663)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0535 (664)  rf=r size=4 type=d align=2 words (r5.3)
//.declare V0536 (665)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0538 (667)  rf=r size=128 type=ud alias=V0536+0 align=32 words (r6.0)
//.declare V0541 (670)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0543 (672)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0544 (673)  rf=r size=128 type=w alias=V0543+0 align=32 words (r16.0)
//.declare V0545 (674)  rf=r size=64 type=w align=32 words (r18.0)
//.declare V0546 (675)  rf=r size=64 type=w align=32 words (r19.0)
//.declare V0547 (676)  rf=r size=64 type=w align=32 words (r20.0)
//.declare V0548 (677)  rf=r size=64 type=w align=32 words (r22.0)
//.declare V0549 (678)  rf=r size=64 type=uw alias=V0545+0 align=32 words (r18.0)
//.declare V0550 (679)  rf=r size=64 type=uw alias=V0548+0 align=32 words (r22.0)
//.declare  (680)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0551 (681)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0553 (683)  rf=r size=128 type=ud alias=V0551+0 align=32 words (r26.0)
//.declare V0557 (687)  rf=r size=256 type=uq align=32 words (r34.0)
//.declare V0558 (688)  rf=r size=64 type=uw alias=V0547+0 align=32 words (r20.0)
//.declare V0559 (689)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare P43 (690)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P44 (691)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0560 (692)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0562 (694)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0563 (695)  rf=r size=256 type=ud alias=V0562+0 align=32 words (r6.0)
//.declare V0564 (696)  rf=r size=8 type=ud alias=V0560+0 align=32 words (r2.0)
//.declare V0565 (697)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0566 (698)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare  (699)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (700)  rf=r size=128 type=w alias=V0477+0 align=32 words (r6.0)
//.declare  (701)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (702)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare  (703)  rf=r size=4 type=f align=2 words (r3.1)
//.declare  (704)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (705)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (706)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (707)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (708)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (709)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (710)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (711)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (712)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (713)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (714)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (715)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (716)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (717)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (718)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (719)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (720)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (721)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (722)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (723)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (724)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (725)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (726)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (727)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (728)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (729)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (730)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (731)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (732)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (733)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (734)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (735)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (736)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (737)  rf=r size=128 type=uw align=32 words (r6.0)
//.declare  (738)  rf=r size=128 type=uw align=32 words (r8.0)
//.declare  (739)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (740)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (741)  rf=r size=128 type=w alias=V0473+0 align=32 words (r12.0)
//.declare  (742)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (743)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (744)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (745)  rf=r size=64 type=uw align=32 words (r20.0)
//.declare  (746)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (747)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (748)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (749)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (750)  rf=r size=64 type=uw align=32 words (r24.0)
//.declare  (751)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (752)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (753)  rf=r size=128 type=ud align=32 words (r28.0)
//.declare  (754)  rf=r size=128 type=ud align=32 words (r32.0)
//.declare  (755)  rf=r size=2 type=uw align=1 words (r2.0)
//.declare  (759)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (760)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (761)  rf=r size=128 type=q align=32 words (r102.0)
//.declare  (762)  rf=r size=128 type=q align=32 words (r100.0)
//.declare  (765)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (766)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (769)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (770)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (771)  rf=r size=128 type=q align=32 words (r38.0)
//.declare  (772)  rf=r size=128 type=q align=32 words (r36.0)
//.declare  (775)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (776)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (779)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (780)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (781)  rf=r size=128 type=q align=32 words (r34.0)
//.declare  (782)  rf=r size=128 type=q align=32 words (r32.0)
//.declare  (785)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (786)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (789)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (790)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (791)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (792)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (795)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (796)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (799)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (800)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (801)  rf=r size=128 type=q align=32 words (r98.0)
//.declare  (802)  rf=r size=128 type=q align=32 words (r96.0)
//.declare  (805)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (806)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (809)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (810)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (811)  rf=r size=128 type=q align=32 words (r30.0)
//.declare  (812)  rf=r size=128 type=q align=32 words (r28.0)
//.declare  (815)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (816)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (819)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (820)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (821)  rf=r size=128 type=q align=32 words (r26.0)
//.declare  (822)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (825)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (826)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (829)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (830)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (831)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (832)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (835)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (836)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (837)  rf=r size=128 type=q align=32 words (r86.0)
//.declare  (838)  rf=r size=128 type=q align=32 words (r92.0)
//.declare  (839)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (840)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (843)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (844)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (849)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (850)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (855)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (856)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (861)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (862)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (869)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (870)  rf=r size=128 type=q align=32 words (r26.0)
//.declare  (881)  rf=r size=128 type=q align=32 words (r30.0)
//.declare  (882)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (885)  rf=r size=128 type=uq alias=+0 align=32 words (r102.0)
//.declare  (886)  rf=r size=128 type=uq alias=+0 align=32 words (r100.0)
//.declare  (887)  rf=r size=128 type=uq alias=+0 align=32 words (r38.0)
//.declare  (888)  rf=r size=128 type=uq alias=+0 align=32 words (r36.0)
//.declare  (889)  rf=r size=128 type=uq alias=+0 align=32 words (r34.0)
//.declare  (890)  rf=r size=128 type=uq alias=+0 align=32 words (r32.0)
//.declare  (891)  rf=r size=128 type=uq alias=+0 align=32 words (r22.0)
//.declare  (892)  rf=r size=128 type=uq alias=+0 align=32 words (r20.0)
//.declare  (893)  rf=r size=128 type=uq alias=+0 align=32 words (r98.0)
//.declare  (894)  rf=r size=128 type=uq alias=+0 align=32 words (r96.0)
//.declare  (895)  rf=r size=128 type=uq alias=+0 align=32 words (r30.0)
//.declare  (896)  rf=r size=128 type=uq alias=+0 align=32 words (r28.0)
//.declare  (897)  rf=r size=128 type=uq alias=+0 align=32 words (r26.0)
//.declare  (898)  rf=r size=128 type=uq alias=+0 align=32 words (r24.0)
//.declare  (899)  rf=r size=128 type=uq alias=+0 align=32 words (r18.0)
//.declare  (900)  rf=r size=128 type=uq alias=+0 align=32 words (r16.0)
//.declare  (901)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (902)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (903)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (904)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (905)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (906)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (907)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (908)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (909)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (910)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (911)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (912)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (913)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (914)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (915)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (916)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (917)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (918)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (919)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (920)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (921)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (922)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (923)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (924)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (925)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (926)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (927)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (928)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (929)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (930)  rf=r size=64 type=d align=32 words (r31.0)
//.declare  (931)  rf=r size=64 type=d align=32 words (r32.0)
//.declare  (932)  rf=r size=64 type=d align=32 words (r33.0)
//.declare  (933)  rf=r size=64 type=d align=32 words (r34.0)
//.declare  (934)  rf=r size=64 type=d align=32 words (r35.0)
//.declare  (935)  rf=r size=64 type=d align=32 words (r36.0)
//.declare  (936)  rf=r size=64 type=d align=32 words (r37.0)
//.declare  (937)  rf=r size=64 type=d align=32 words (r38.0)
//.declare  (938)  rf=r size=64 type=d align=32 words (r39.0)
//.declare r0 (939)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (940)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (941)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (942)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (943)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (944)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (945)  rf=r size=32 type=ud align=2 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0037    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0566    | :ud      |    0x4 | r2       | inline+0x0       |
// | V0041    | :d       |    0x4 | r2+0x8   | inline+0x8       |
// | V0042    | :d       |    0x4 | r2+0xC   | inline+0xC       |
// | V0043    | :d       |    0x4 | r2+0x10  | inline+0x10      |
// | V0044    | :d       |    0x4 | r2+0x14  | inline+0x14      |
// | V0045    | :d       |    0x4 | r2+0x18  | inline+0x18      |
// | V0046    | :d       |    0x4 | r2+0x1C  | inline+0x1C      |
// | V0047    | :d       |    0x4 | r3       | cti+0x20         |
// | V0048    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0049    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0050    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0051    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0052    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0053    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0054    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0055    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0056    | :q       |    0x8 | r4       | cti+0x60         |
// | V0057    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0058    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0059    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0060    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0061    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0062    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0063    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0064    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0065    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0066    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0067    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xA0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r5:1  bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B007}
// _main:
(W)     mov (16|M0)              r50.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r54.0<1>:f    0x3F000000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r51.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r53.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (8|M0)               r55.0<1>:w    0x76543210:v                               {A@1}      //  ALU pipe: int; $2
        cmp (32|M0)   (eq)f1.0   null<2>:w     r1.0<1;1,0>:w     0:w               {$0.dst}          //  ALU pipe: int; $6
(W)     add (8|M0)               r55.8<1>:w    r55.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $3
        cmp (32|M0)   (eq)f0.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $5
(W)     add (16|M0)              r55.16<1>:w   r55.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $4
(~f1.0) goto (32|M0)                         _0_126            _0_126                                //  ALU pipe: int; $7
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_127:
(W)     mov (1|M0)               r2.0<1>:uq    r5.3<0;1,0>:uq                   {Compacted,$2.dst}   //  ALU pipe: int; $9
(W)     load.ugm.d32x1t.a64 (1|M0)  r6:1        [r2:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $10
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r6.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $11
(W&~f1.0) jmpi                               _0_128                                                  //  ALU pipe: int; $12
// B004: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_129:
        mov (32|M0)              r40.0<1>:ud   0x3F800000:ud                                         //  ALU pipe: int; $14
(W)     jmpi                                 _0_130                                                  // $15
// B005: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_128:
(W)     mov (1|M0)               r2.0<1>:uq    r5.0<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $17
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $20
        mov (16|M0)              r6.0<2>:f     r2.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $18
        mov (16|M16)             r8.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $18
        mov (16|M0)              r6.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $19
        mov (16|M16)             r8.1<2>:ud    r2.1<0;1,0>:ud                   {F@1}                //  ALU pipe: int; $19
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {I@1,$4} // ex_desc:0x0; desc:0x8200599 // $21
(W)     mov (1|M0)               r3.1<1>:f     0x3F800000:f                               {Compacted,$1.dst} //  ALU pipe: float; $24
        cmp (32|M0)   (ne)f1.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$4.dst}          //  ALU pipe: int; $23
(f1.0)  sel (32|M0)              r40.0<1>:f    r3.1<0;1,0>:f     0x0:f               {F@1}           //  ALU pipe: float; $24
// B006: [inDivergent],  Preds:{B005, B004},  Succs:{B007}
_0_130:
        mov (32|M0)              r6.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $27
        store.slm.d32.a32 (32|M0)  [r6:2]       r40:2              {A@1,$5} // ex_desc:0x0; desc:0x4000504 // $28
// B007: Preds:{B006, B002},  Succs:{B008, B103}
_0_126:
        join (32|M0)                         L608                                                    // 
L608:
        sync.nop                             null                             {Compacted,$5.src}     // $30
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$6} // wr:1+0, rd:1; fence.slm.none.group // $30
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$6.dst}   //  memory fence commit; ALU pipe: int; $31
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$7} // wr:1+0, rd:1; fence.ugm.none.group // $31
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $32
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $32
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$7.dst}   //  memory fence commit; ALU pipe: int; $32
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$8} // wr:1+0, rd:0; signal barrier // $32
(W)     sync.bar                             0x0                                                     // $32
(W)     mov (1|M0)               r2.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $33
(W)     load.slm.d32x1t.a32 (1|M0)  r9:1        [r2:1]             {I@1,$9} // ex_desc:0x0; desc:0x2108500 // $34
(W)     cmp (32|M0)   (ne)f1.0   null<1>:f     r9.0<0;1,0>:f     0x0:f               {$9.dst}        //  ALU pipe: float; $35
(W&f1.0) jmpi                                _0_131                                                  //  ALU pipe: int; $36
// B008: Preds:{B007},  Succs:{B009, B101}
_0_132:
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$10} // wr:1+0, rd:1; fence.slm.none.group // $38
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$10.dst}  //  memory fence commit; ALU pipe: int; $39
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$11} // wr:1+0, rd:1; fence.ugm.none.group // $39
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$8.src}        //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $40
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $40
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$11.dst}  //  memory fence commit; ALU pipe: int; $40
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$12} // wr:1+0, rd:0; signal barrier // $40
(W)     sync.bar                             0x0                                                     // $40
(W)     mov (1|M0)               r2.0<1>:uq    r5.2<0;1,0>:uq                   {Compacted,$2.dst}   //  ALU pipe: int; $41
(W)     add (1|M0)               r2.2<1>:d     r3.0<0;1,0>:d     -r2.3<0;1,0>:d   {$1.dst}           //  ALU pipe: int; $43
(W)     load.ugm.d32x1t.a64 (1|M0)  r52:1       [r2:1]             {I@1,$13} // ex_desc:0x0; desc:0x2108580 // $42
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r52.0<0;1,0>:d    r2.2<0;1,0>:d    {$13.dst}          //  ALU pipe: int; $44
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:d     r52.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $45
(W&f1.0) jmpi                                _0_133                                                  //  ALU pipe: int; $47
// B009: Preds:{B008},  Succs:{B010, B093}
_0_134:
(W)     cmp (1|M0)    (lt)f1.0   null<1>:d     r3.0<0;1,0>:d     -3:w                                //  ALU pipe: int; $49
(W)     mov (1|M0)               r2.0<1>:hf    0x6:hf                                                //  ALU pipe: float; $50
(W&f1.0) sel (1|M0)              r3.2<1>:w     r2.0<0;1,0>:w     3:w               {F@1}             //  ALU pipe: int; $50
(W)     mov (1|M0)               r4.8<2>:b     r3.2<0;1,0>:w                    {I@1}                //  ALU pipe: int; $51
(W)     mov (1|M0)               r5.8<1>:d     r4.8<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $52
(W)     add (1|M0)               r6.0<1>:d     r5.8<0;1,0>:d     r3.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $53
(W)     asr (1|M0)               r7.0<1>:d     r6.0<0;1,0>:d     2:w               {Compacted,I@1}   //  ALU pipe: int; $54
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r7.0<0;1,0>:d     r50.1<0;1,0>:d   {I@1}              //  ALU pipe: int; $55
(W&f1.0) jmpi                                _0_135                                                  //  ALU pipe: int; $56
// B010: Preds:{B009},  Succs:{B011, B103}
_0_136:
(W)     shr (1|M0)               r2.0<1>:ud    r52.0<0;1,0>:ud   2:w                                 //  ALU pipe: int; $58
(W)     cmp (32|M0)   (gt)f1.0   null<1>:ud    r2.0<0;1,0>:ud    r50.1<0;1,0>:ud  {I@1}              //  ALU pipe: int; $59 R{} IR{}{E:1,E:1,},  {BC=1}
(W&f1.0) jmpi                                _0_131                                                  //  ALU pipe: int; $60
// B011: Preds:{B010},  Succs:{B012, B103}
_0_137:
(W)     add (1|M0)               r2.0<1>:d     r52.0<0;1,0>:d    r2.3<0;1,0>:d    {Compacted}        //  ALU pipe: int; $62
(W)     add3 (1|M0)              r3.1<1>:d     r52.0<0;0>:d      r2.3<0;0>:d       3:w               //  ALU pipe: int; $63
(W)     cmp (1|M0)    (lt)f1.0   r2.1<1>:d     r2.0<0;1,0>:d     0:w               {I@2}             //  ALU pipe: int; $64
(W)     bfn.(s0&s1|~s0&s2) (1|M0)   r4.2<1>:ud  r2.1<0;0>:ud     r3.1<0;0>:ud      r2.0<0>:ud       {I@1} //  ALU pipe: int; $65
(W)     asr (1|M0)               r5.8<1>:d     r4.2<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $66
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r5.8<0;1,0>:d     r50.1<0;1,0>:d   {I@1}              //  ALU pipe: int; $67
(W&~f1.0) jmpi                               _0_131                                                  //  ALU pipe: int; $68
// B012: Preds:{B011},  Succs:{B013, B026}
_0_138:
        cmp (32|M0)   (lt)f1.0   null<2>:uw    r1.0<1;1,0>:uw    0x80:uw                             //  ALU pipe: int; $71
        mov (32|M0)              r46.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $70
(W)     mov (1|M0)               r4.3<1>:f     0xFFBF0000:f                                          //  (0xffbf0000:f); ALU pipe: float; $72
(W)     mov (1|M0)               r4.2<1>:f     0x400000:f                               {Compacted}  //  (0x00400000:f); ALU pipe: float; $73
(~f1.0) goto (32|M0)                         _0_139            _0_139                                //  ALU pipe: int; $74
// B013: [inDivergent],  Preds:{B012},  Succs:{B014, B015}
_0_140:
(W)     shl (1|M0)               r4.4<1>:d     r50.1<0;1,0>:d    2:w                                 //  ALU pipe: int; $76
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.4<0;1,0>:d     r52.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $77 R{} IR{}{E:2,E:2,},  {BC=1}
(W&f2.0) jmpi                                _0_141                                                  //  ALU pipe: int; $78
// B014: [inDivergent],  Preds:{B013},  Succs:{B016}
_0_142:
(W)     add (1|M0)               r2.0<1>:d     r4.4<0;1,0>:d     -r52.0<0;1,0>:d                     //  ALU pipe: int; $80 R{} IR{}{E:2,E:2,},  {BC=1}
(W)     shl (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     7:w               {Compacted,I@1}   //  ALU pipe: int; $81
        add (32|M0)              r6.0<1>:d     r3.1<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $82
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,@1,$12.src} //  ALU pipe: int; $84
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $84
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $84
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $84
        add (16|M0)              r102.0<1>:q   r10.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $85
        add (16|M16)             r100.0<1>:q   r14.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $85
(W)     jmpi                                 _0_143                                                  // $86
// B015: [inDivergent],  Preds:{B013},  Succs:{B016}
_0_141:
(W)     shl (1|M0)               r2.0<1>:d     r50.1<0;1,0>:d    9:w               {Compacted}       //  ALU pipe: int; $88
        add (32|M0)              r6.0<1>:d     r2.0<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $89
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,@1,$12.src} //  ALU pipe: int; $91
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $91
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $91
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $91
        add (16|M0)              r102.0<1>:q   r10.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $92
        add (16|M16)             r100.0<1>:q   r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $92
// B016: [inDivergent],  Preds:{B015, B014},  Succs:{B017, B018}
_0_143:
        mov (16|M0)              r6.0<1>:uq    r102.0<1;1,0>:uq                 {Compacted,I@2}      //  ALU pipe: int; $94
        mov (16|M16)             r8.0<1>:uq    r100.0<1;1,0>:uq                 {Compacted,I@2}      //  ALU pipe: int; $94
        load.ugm.d16u32.a64 (32|M0)  r10:2      [r6:4]             {I@1,$14} // ex_desc:0x0; desc:0x8200B80 // $95
(W)     add (1|M0)               r4.5<1>:d     r4.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $98
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.5<0;1,0>:d     r52.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $99
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:ud   16:w               {$14.dst}        //  ALU pipe: int; $96
        add (32|M0)              r100.0<1>:f   r12.0<1;1,0>:f    0x0:f               {Compacted,I@1} //  ALU pipe: float; $97
(W&f2.0) jmpi                                _0_144                                                  //  ALU pipe: int; $100
// B017: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_145:
(W)     add3 (1|M0)              r2.0<1>:d     r4.4<0;0>:d       -r52.0<0;0>:d     1:w               //  ALU pipe: int; $102 R{} IR{}{E:2,E:2,},  {BC=1}
(W)     shl (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     7:w               {Compacted,I@1}   //  ALU pipe: int; $103
        add (32|M0)              r6.0<1>:d     r3.1<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $104
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $106
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,F@1}      //  ALU pipe: int; $106
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $106
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $106
        add (16|M0)              r38.0<1>:q    r10.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $107
        add (16|M16)             r36.0<1>:q    r14.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $107
(W)     jmpi                                 _0_146                                                  // $108
// B018: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_144:
(W)     shl (1|M0)               r2.0<1>:d     r4.5<0;1,0>:d     7:w                                 //  ALU pipe: int; $110
        add (32|M0)              r6.0<1>:d     r2.0<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $111
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $113
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $113
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $113
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $113
        add (16|M0)              r38.0<1>:q    r10.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $114
        add (16|M16)             r36.0<1>:q    r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $114
// B019: [inDivergent],  Preds:{B018, B017},  Succs:{B020, B021}
_0_146:
        mov (16|M0)              r6.0<1>:uq    r38.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $116
        mov (16|M16)             r8.0<1>:uq    r36.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $116
        load.ugm.d16u32.a64 (32|M0)  r10:2      [r6:4]             {I@1,$15} // ex_desc:0x0; desc:0x8200B80 // $117
(W)     add (1|M0)               r4.5<1>:d     r4.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $120
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.5<0;1,0>:d     r52.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $121
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:ud   16:w               {$15.dst}        //  ALU pipe: int; $118
        add (32|M0)              r98.0<1>:f    r100.0<1;1,0>:f   r12.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $119
(W&f2.0) jmpi                                _0_147                                                  //  ALU pipe: int; $122
// B020: [inDivergent],  Preds:{B019},  Succs:{B022}
_0_148:
(W)     add3 (1|M0)              r2.0<1>:d     r4.4<0;0>:d       -r52.0<0;0>:d     2:w               //  ALU pipe: int; $124 R{} IR{}{E:2,E:2,},  {BC=1}
(W)     shl (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     7:w               {Compacted,I@1}   //  ALU pipe: int; $125
        add (32|M0)              r6.0<1>:d     r3.1<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $126
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $128
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,F@1}      //  ALU pipe: int; $128
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $128
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $128
        add (16|M0)              r34.0<1>:q    r10.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $129
        add (16|M16)             r32.0<1>:q    r14.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $129
(W)     jmpi                                 _0_149                                                  // $130
// B021: [inDivergent],  Preds:{B019},  Succs:{B022}
_0_147:
(W)     shl (1|M0)               r2.0<1>:d     r4.5<0;1,0>:d     7:w                                 //  ALU pipe: int; $132
        add (32|M0)              r6.0<1>:d     r2.0<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $133
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $135
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $135
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $135
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $135
        add (16|M0)              r34.0<1>:q    r10.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $136
        add (16|M16)             r32.0<1>:q    r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $136
// B022: [inDivergent],  Preds:{B021, B020},  Succs:{B023, B024}
_0_149:
        mov (16|M0)              r6.0<1>:uq    r34.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $138
        mov (16|M16)             r8.0<1>:uq    r32.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $138
        load.ugm.d16u32.a64 (32|M0)  r10:2      [r6:4]             {I@1,$0} // ex_desc:0x0; desc:0x8200B80 // $139
(W)     add (1|M0)               r4.5<1>:d     r4.4<0;1,0>:d     3:w                                 //  ALU pipe: int; $142
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.5<0;1,0>:d     r52.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $143
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:ud   16:w               {$0.dst}         //  ALU pipe: int; $140
        add (32|M0)              r96.0<1>:f    r98.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $141
(W&f2.0) jmpi                                _0_150                                                  //  ALU pipe: int; $144
// B023: [inDivergent],  Preds:{B022},  Succs:{B025}
_0_151:
(W)     add3 (1|M0)              r2.0<1>:d     r4.4<0;0>:d       -r52.0<0;0>:d     3:w               //  ALU pipe: int; $146 R{} IR{}{E:2,E:2,},  {BC=1}
(W)     shl (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     7:w               {Compacted,I@1}   //  ALU pipe: int; $147
        add (32|M0)              r6.0<1>:d     r3.1<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $148
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $150
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,F@1}      //  ALU pipe: int; $150
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $150
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $150
        add (16|M0)              r22.0<1>:q    r10.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $151
        add (16|M16)             r20.0<1>:q    r14.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $151
(W)     jmpi                                 _0_152                                                  // $152
// B024: [inDivergent],  Preds:{B022},  Succs:{B025}
_0_150:
(W)     shl (1|M0)               r2.0<1>:d     r4.5<0;1,0>:d     7:w                                 //  ALU pipe: int; $154
        add (32|M0)              r6.0<1>:d     r2.0<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $155
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $157
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $157
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $157
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $157
        add (16|M0)              r22.0<1>:q    r10.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $158
        add (16|M16)             r20.0<1>:q    r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $158
// B025: [inDivergent],  Preds:{B024, B023},  Succs:{B026}
_0_152:
        mov (16|M0)              r6.0<1>:uq    r22.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $160
        mov (16|M16)             r8.0<1>:uq    r20.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $160
        load.ugm.d16u32.a64 (32|M0)  r10:2      [r6:4]             {I@1,$3} // ex_desc:0x0; desc:0x8200B80 // $161
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:ud   16:w               {$3.dst}         //  ALU pipe: int; $162
        add (32|M0)              acc0.0<1>:f   r96.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $163
        mul (32|M0)              r80.0<1>:f    acc0.0<1;1,0>:f   0x3E800000:f               {Compacted} //  ALU pipe: float; $164
        and (32|M0)              r14.0<1>:d    r80.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $165
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r14.0<1;1,0>:ud   0x7F800000:ud              {I@1}    //  ALU pipe: int; $166
(~f0.0) shr (32|M0)              r6.0<1>:ud    r80.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $169
(~f0.0) and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $170
(~f0.0) add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r80.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $171
(~f0.0) and (32|M0)              r82.0<1>:d    r10.0<1;1,0>:d    -65536:d               {I@1}        //  ALU pipe: int; $172
(f0.0)  bfn.(s0&s1|s2) (32|M0)   r82.0<1>:ud   r80.0<1;0>:ud     r4.3<0;0>:ud      r4.2<0>:ud        //  ALU pipe: int; $175
        shl (32|M0)              r8.0<1>:d     r46.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $178
        mul (32|M0)              r6.0<1>:f     r82.0<1;1,0>:f    r82.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $177
        store.slm.d32.a32 (32|M0)  [r8:2]       r6:2               {A@1,$4} // ex_desc:0x0; desc:0x4000504 // $179
// B026: Preds:{B025, B012},  Succs:{B027, B031}
_0_139:
        join (32|M0)                         L2720                                                   // 
L2720:
        sync.nop                             null                             {Compacted,$4.src}     // $181
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$5} // wr:1+0, rd:1; fence.slm.none.group // $181
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$5.dst}   //  memory fence commit; ALU pipe: int; $182
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$6} // wr:1+0, rd:1; fence.ugm.none.group // $182
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$12.src}       //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $183
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $183
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$6.dst}   //  memory fence commit; ALU pipe: int; $183
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$7} // wr:1+0, rd:0; signal barrier // $183
(W)     sync.bar                             0x0                                                     // $183
        cmp (32|M0)   (lt)f3.0   null<2>:uw    r1.0<1;1,0>:uw    0x40:uw                             //  ALU pipe: int; $184
(~f3.0) goto (32|M0)                         _0_156            _0_156                                //  ALU pipe: int; $185
// B027: [inDivergent],  Preds:{B026},  Succs:{B028, B029}
_0_157:
        shl (32|M0)              r64.0<1>:d    r46.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $188
        load.slm.d32.a32 (32|M0)  r86:2         [r64:2]            {I@1,$8} // ex_desc:0x0; desc:0x4200500 // $189
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $187
        add (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {Compacted,@1,$7.src} //  ALU pipe: int; $190
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r8.0<1;1,0>:ud    0x80:uw              {I@1}          //  ALU pipe: int; $191
(f0.0)  goto (32|M0)                         _0_158            _0_158                                //  ALU pipe: int; $192
// B028: [inDivergent],  Preds:{B027},  Succs:{B030}
_0_159:
        mov (32|M0)              r6.0<1>:ud    0x0:ud                              {Compacted}       //  ALU pipe: int; $194
        goto (32|M0)                         _0_158            _0_160                                // $195
// B029: [inDivergent],  Preds:{B027},  Succs:{B030}
_0_158:
        join (32|M0)                         _0_160                                                  // 
L2984:
        shl (32|M0)              r6.0<1>:d     r8.0<1;1,0>:d     2:w               {Compacted}       //  ALU pipe: int; $197
        load.slm.d32.a32 (32|M0)  r6:2          [r6:2]             {I@1,$9} // ex_desc:0x0; desc:0x4200500 // $198
// B030: [inDivergent],  Preds:{B029, B028},  Succs:{B031}
_0_160:
        join (32|M0)                         _0_156                                                  // 
L3024:
        sync.nop                             null                             {Compacted,$9.dst}     // $200
        add (32|M0)              r6.0<1>:f     r86.0<1;1,0>:f    r6.0<1;1,0>:f    {Compacted,$8.dst} //  ALU pipe: float; $200 R{} IR{}{E:3,E:3,},  R{} IR{}{O:11,O:3,},  {BC=1}
        store.slm.d32.a32 (32|M0)  [r64:2]      r6:2               {F@1,$10} // ex_desc:0x0; desc:0x4000504 // $201
// B031: Preds:{B030, B026},  Succs:{B032, B036}
_0_156:
        join (32|M0)                         L3072                                                   // 
L3072:
        sync.nop                             null                             {Compacted,$10.src}    // $203
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$9} // wr:1+0, rd:1; fence.slm.none.group // $203
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$9.dst}   //  memory fence commit; ALU pipe: int; $204
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$11} // wr:1+0, rd:1; fence.ugm.none.group // $204
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$7.src}        //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $205
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $205
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$11.dst}  //  memory fence commit; ALU pipe: int; $205
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$13} // wr:1+0, rd:0; signal barrier // $205
(W)     sync.bar                             0x0                                                     // $205
        cmp (32|M0)   (lt)f0.0   null<2>:uw    r1.0<1;1,0>:uw    0x20:uw                             //  ALU pipe: int; $206
(~f0.0) goto (32|M0)                         _0_161            _0_161                                //  ALU pipe: int; $207
// B032: [inDivergent],  Preds:{B031},  Succs:{B033, B034}
_0_162:
        shl (32|M0)              r62.0<1>:d    r46.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $210
        load.slm.d32.a32 (32|M0)  r84:2         [r62:2]            {I@1,$14} // ex_desc:0x0; desc:0x4200500 // $211
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $209
        add (32|M0)              r126.0<1>:d   r6.0<1;1,0>:d     2:w               {Compacted,I@1}   //  ALU pipe: int; $212
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r126.0<1;1,0>:ud  0x80:uw              {I@1}          //  ALU pipe: int; $213
(f2.0)  goto (32|M0)                         _0_163            _0_163                                //  ALU pipe: int; $214
// B033: [inDivergent],  Preds:{B032},  Succs:{B035}
_0_164:
        mov (32|M0)              r124.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $216
        goto (32|M0)                         _0_163            _0_165                                // $217
// B034: [inDivergent],  Preds:{B032},  Succs:{B035}
_0_163:
        join (32|M0)                         _0_165                                                  // 
L3336:
        shl (32|M0)              r6.0<1>:d     r126.0<1;1,0>:d   2:w               {Compacted}       //  ALU pipe: int; $219
        load.slm.d32.a32 (32|M0)  r124:2        [r6:2]             {I@1,$15} // ex_desc:0x0; desc:0x4200500 // $220
// B035: [inDivergent],  Preds:{B034, B033},  Succs:{B036}
_0_165:
        join (32|M0)                         _0_161                                                  // 
L3376:
        sync.nop                             null                             {Compacted,$15.dst}    // $222
        add (32|M0)              r6.0<1>:f     r84.0<1;1,0>:f    r124.0<1;1,0>:f  {Compacted,$14.dst} //  ALU pipe: float; $222
        store.slm.d32.a32 (32|M0)  [r62:2]      r6:2               {F@1,$0} // ex_desc:0x0; desc:0x4000504 // $223
// B036: Preds:{B035, B031},  Succs:{B037, B041}
_0_161:
        join (32|M0)                         L3424                                                   // 
L3424:
        sync.allrd                           ($0,$15)                                                // $225
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$3} // wr:1+0, rd:1; fence.slm.none.group // $225
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$3.dst}   //  memory fence commit; ALU pipe: int; $226
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$4} // wr:1+0, rd:1; fence.ugm.none.group // $226
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$13.src}       //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $227
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $227
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$4.dst}   //  memory fence commit; ALU pipe: int; $227
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$5} // wr:1+0, rd:0; signal barrier // $227
(W)     sync.bar                             0x0                                                     // $227
        cmp (32|M0)   (lt)f2.0   null<2>:uw    r1.0<1;1,0>:uw    0x10:uw                             //  ALU pipe: int; $228
(~f2.0) goto (32|M0)                         _0_166            _0_166                                //  ALU pipe: int; $229
// B037: [inDivergent],  Preds:{B036},  Succs:{B038, B039}
_0_167:
        shl (32|M0)              r60.0<1>:d    r46.0<1;1,0>:d    5:w               {Compacted}       //  ALU pipe: int; $232
        load.slm.d32.a32 (32|M0)  r82:2         [r60:2]            {I@1,$6} // ex_desc:0x0; desc:0x4200500 // $233
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $231
        add (32|M0)              r122.0<1>:d   r6.0<1;1,0>:d     4:w               {Compacted,I@1}   //  ALU pipe: int; $234
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r122.0<1;1,0>:ud  0x80:uw              {I@1}          //  ALU pipe: int; $235
(f2.0)  goto (32|M0)                         _0_168            _0_168                                //  ALU pipe: int; $236
// B038: [inDivergent],  Preds:{B037},  Succs:{B040}
_0_169:
        mov (32|M0)              r120.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $238
        goto (32|M0)                         _0_168            _0_170                                // $239
// B039: [inDivergent],  Preds:{B037},  Succs:{B040}
_0_168:
        join (32|M0)                         _0_170                                                  // 
L3696:
        shl (32|M0)              r6.0<1>:d     r122.0<1;1,0>:d   2:w               {Compacted}       //  ALU pipe: int; $241
        load.slm.d32.a32 (32|M0)  r120:2        [r6:2]             {I@1,$7} // ex_desc:0x0; desc:0x4200500 // $242
// B040: [inDivergent],  Preds:{B039, B038},  Succs:{B041}
_0_170:
        join (32|M0)                         _0_166                                                  // 
L3736:
        sync.nop                             null                             {Compacted,$7.dst}     // $244
        add (32|M0)              r6.0<1>:f     r82.0<1;1,0>:f    r120.0<1;1,0>:f  {Compacted,$6.dst} //  ALU pipe: float; $244
        store.slm.d32.a32 (32|M0)  [r60:2]      r6:2               {F@1,$9} // ex_desc:0x0; desc:0x4000504 // $245
// B041: Preds:{B040, B036},  Succs:{B042, B046}
_0_166:
        join (32|M0)                         L3784                                                   // 
L3784:
        sync.allrd                           ($7,$9)                                                 // $247
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$10} // wr:1+0, rd:1; fence.slm.none.group // $247
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$10.dst}  //  memory fence commit; ALU pipe: int; $248
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$11} // wr:1+0, rd:1; fence.ugm.none.group // $248
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$5.src}        //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $249
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $249
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$11.dst}  //  memory fence commit; ALU pipe: int; $249
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$15} // wr:1+0, rd:0; signal barrier // $249
(W)     sync.bar                             0x0                                                     // $249
        cmp (32|M0)   (lt)f2.0   null<2>:uw    r1.0<1;1,0>:uw    0x8:uw                              //  ALU pipe: int; $250
(~f2.0) goto (32|M0)                         _0_171            _0_171                                //  ALU pipe: int; $251
// B042: [inDivergent],  Preds:{B041},  Succs:{B043, B044}
_0_172:
        shl (32|M0)              r58.0<1>:d    r46.0<1;1,0>:d    6:w               {Compacted}       //  ALU pipe: int; $254
        load.slm.d32.a32 (32|M0)  r80:2         [r58:2]            {I@1,$0} // ex_desc:0x0; desc:0x4200500 // $255
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $253
        add (32|M0)              r118.0<1>:d   r6.0<1;1,0>:d     8:w               {Compacted,I@1}   //  ALU pipe: int; $256
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r118.0<1;1,0>:ud  0x80:uw              {I@1}          //  ALU pipe: int; $257
(f2.0)  goto (32|M0)                         _0_173            _0_173                                //  ALU pipe: int; $258
// B043: [inDivergent],  Preds:{B042},  Succs:{B045}
_0_174:
        mov (32|M0)              r116.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $260
        goto (32|M0)                         _0_173            _0_175                                // $261
// B044: [inDivergent],  Preds:{B042},  Succs:{B045}
_0_173:
        join (32|M0)                         _0_175                                                  // 
L4056:
        shl (32|M0)              r6.0<1>:d     r118.0<1;1,0>:d   2:w               {Compacted}       //  ALU pipe: int; $263
        load.slm.d32.a32 (32|M0)  r116:2        [r6:2]             {I@1,$3} // ex_desc:0x0; desc:0x4200500 // $264
// B045: [inDivergent],  Preds:{B044, B043},  Succs:{B046}
_0_175:
        join (32|M0)                         _0_171                                                  // 
L4096:
        sync.nop                             null                             {Compacted,$3.dst}     // $266
        add (32|M0)              r6.0<1>:f     r80.0<1;1,0>:f    r116.0<1;1,0>:f  {Compacted,$0.dst} //  ALU pipe: float; $266
        store.slm.d32.a32 (32|M0)  [r58:2]      r6:2               {F@1,$4} // ex_desc:0x0; desc:0x4000504 // $267
// B046: Preds:{B045, B041},  Succs:{B047, B051}
_0_171:
        join (32|M0)                         L4144                                                   // 
L4144:
        sync.allrd                           ($3,$4)                                                 // $269
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$7} // wr:1+0, rd:1; fence.slm.none.group // $269
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$7.dst}   //  memory fence commit; ALU pipe: int; $270
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$9} // wr:1+0, rd:1; fence.ugm.none.group // $270
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$15.src}       //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $271
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $271
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$9.dst}   //  memory fence commit; ALU pipe: int; $271
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$10} // wr:1+0, rd:0; signal barrier // $271
(W)     sync.bar                             0x0                                                     // $271
        cmp (32|M0)   (lt)f2.0   null<2>:uw    r1.0<1;1,0>:uw    0x4:uw                              //  ALU pipe: int; $272
(~f2.0) goto (32|M0)                         _0_176            _0_176                                //  ALU pipe: int; $273
// B047: [inDivergent],  Preds:{B046},  Succs:{B048, B049}
_0_177:
        shl (32|M0)              r56.0<1>:d    r46.0<1;1,0>:d    7:w               {Compacted}       //  ALU pipe: int; $276
        load.slm.d32.a32 (32|M0)  r78:2         [r56:2]            {I@1,$11} // ex_desc:0x0; desc:0x4200500 // $277
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    5:w               {Compacted}       //  ALU pipe: int; $275
        add (32|M0)              r114.0<1>:d   r6.0<1;1,0>:d     16:w               {Compacted,I@1}  //  ALU pipe: int; $278
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r114.0<1;1,0>:ud  0x80:uw              {I@1}          //  ALU pipe: int; $279
(f2.0)  goto (32|M0)                         _0_178            _0_178                                //  ALU pipe: int; $280
// B048: [inDivergent],  Preds:{B047},  Succs:{B050}
_0_179:
        mov (32|M0)              r112.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $282
        goto (32|M0)                         _0_178            _0_180                                // $283
// B049: [inDivergent],  Preds:{B047},  Succs:{B050}
_0_178:
        join (32|M0)                         _0_180                                                  // 
L4416:
        shl (32|M0)              r6.0<1>:d     r114.0<1;1,0>:d   2:w               {Compacted}       //  ALU pipe: int; $285
        load.slm.d32.a32 (32|M0)  r112:2        [r6:2]             {I@1,$13} // ex_desc:0x0; desc:0x4200500 // $286
// B050: [inDivergent],  Preds:{B049, B048},  Succs:{B051}
_0_180:
        join (32|M0)                         _0_176                                                  // 
L4456:
        sync.nop                             null                             {Compacted,$13.dst}    // $288
        add (32|M0)              r6.0<1>:f     r78.0<1;1,0>:f    r112.0<1;1,0>:f  {Compacted,$11.dst} //  ALU pipe: float; $288
        store.slm.d32.a32 (32|M0)  [r56:2]      r6:2               {F@1,$3} // ex_desc:0x0; desc:0x4000504 // $289
// B051: Preds:{B050, B046},  Succs:{B052, B056}
_0_176:
        join (32|M0)                         L4504                                                   // 
L4504:
        sync.allrd                           ($3,$13)                                                // $291
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$4} // wr:1+0, rd:1; fence.slm.none.group // $291
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$4.dst}   //  memory fence commit; ALU pipe: int; $292
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$5} // wr:1+0, rd:1; fence.ugm.none.group // $292
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$10.src}       //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $293
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $293
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$5.dst}   //  memory fence commit; ALU pipe: int; $293
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$7} // wr:1+0, rd:0; signal barrier // $293
(W)     sync.bar                             0x0                                                     // $293
        cmp (32|M0)   (lt)f2.0   null<2>:uw    r1.0<1;1,0>:uw    0x2:uw                              //  ALU pipe: int; $294
(~f2.0) goto (32|M0)                         _0_181            _0_181                                //  ALU pipe: int; $295
// B052: [inDivergent],  Preds:{B051},  Succs:{B053, B054}
_0_182:
        shl (32|M0)              r48.0<1>:d    r46.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $298
        load.slm.d32.a32 (32|M0)  r76:2         [r48:2]            {I@1,$9} // ex_desc:0x0; desc:0x4200500 // $299
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    6:w               {Compacted}       //  ALU pipe: int; $297
        add (32|M0)              r110.0<1>:d   r6.0<1;1,0>:d     32:w               {Compacted,I@1}  //  ALU pipe: int; $300
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r110.0<1;1,0>:ud  0x80:uw              {I@1}          //  ALU pipe: int; $301
(f2.0)  goto (32|M0)                         _0_183            _0_183                                //  ALU pipe: int; $302
// B053: [inDivergent],  Preds:{B052},  Succs:{B055}
_0_184:
        mov (32|M0)              r108.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $304
        goto (32|M0)                         _0_183            _0_185                                // $305
// B054: [inDivergent],  Preds:{B052},  Succs:{B055}
_0_183:
        join (32|M0)                         _0_185                                                  // 
L4776:
        shl (32|M0)              r6.0<1>:d     r110.0<1;1,0>:d   2:w               {Compacted}       //  ALU pipe: int; $307
        load.slm.d32.a32 (32|M0)  r108:2        [r6:2]             {I@1,$13} // ex_desc:0x0; desc:0x4200500 // $308
// B055: [inDivergent],  Preds:{B054, B053},  Succs:{B056}
_0_185:
        join (32|M0)                         _0_181                                                  // 
L4816:
        sync.nop                             null                             {Compacted,$13.dst}    // $310
        add (32|M0)              r6.0<1>:f     r76.0<1;1,0>:f    r108.0<1;1,0>:f  {Compacted,$9.dst} //  ALU pipe: float; $310 R{} IR{}{E:6,E:6,},  R{} IR{}{O:6,O:6,},  {BC=2}
        store.slm.d32.a32 (32|M0)  [r48:2]      r6:2               {F@1,$15} // ex_desc:0x0; desc:0x4000504 // $311
// B056: Preds:{B055, B051},  Succs:{B057, B061}
_0_181:
        join (32|M0)                         L4864                                                   // 
L4864:
        sync.allrd                           ($13,$15)                                               // $313
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$3} // wr:1+0, rd:1; fence.slm.none.group // $313
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$3.dst}   //  memory fence commit; ALU pipe: int; $314
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$4} // wr:1+0, rd:1; fence.ugm.none.group // $314
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$7.src}        //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $315
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $315
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$4.dst}   //  memory fence commit; ALU pipe: int; $315
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$10} // wr:1+0, rd:0; signal barrier // $315
(W)     sync.bar                             0x0                                                     // $315
        cmp (32|M0)   (eq)f2.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $316
(~f2.0) goto (32|M0)                         _0_186            _0_186                                //  ALU pipe: int; $317
// B057: [inDivergent],  Preds:{B056},  Succs:{B058, B059}
_0_187:
        shl (32|M0)              r44.0<1>:d    r46.0<1;1,0>:d    9:w               {Compacted}       //  ALU pipe: int; $320
        load.slm.d32.a32 (32|M0)  r74:2         [r44:2]            {I@1,$13} // ex_desc:0x0; desc:0x4200500 // $321
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    7:w               {Compacted}       //  ALU pipe: int; $319
        add (32|M0)              r106.0<1>:d   r6.0<1;1,0>:d     64:w               {Compacted,I@1}  //  ALU pipe: int; $322
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r106.0<1;1,0>:ud  0x80:uw              {I@1}          //  ALU pipe: int; $323
(f2.0)  goto (32|M0)                         _0_188            _0_188                                //  ALU pipe: int; $324
// B058: [inDivergent],  Preds:{B057},  Succs:{B060}
_0_189:
        mov (32|M0)              r104.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $326
        goto (32|M0)                         _0_188            _0_190                                // $327
// B059: [inDivergent],  Preds:{B057},  Succs:{B060}
_0_188:
        join (32|M0)                         _0_190                                                  // 
L5136:
        shl (32|M0)              r6.0<1>:d     r106.0<1;1,0>:d   2:w               {Compacted}       //  ALU pipe: int; $329
        load.slm.d32.a32 (32|M0)  r104:2        [r6:2]             {I@1,$5} // ex_desc:0x0; desc:0x4200500 // $330
// B060: [inDivergent],  Preds:{B059, B058},  Succs:{B061}
_0_190:
        join (32|M0)                         _0_186                                                  // 
L5176:
        sync.nop                             null                             {Compacted,$5.dst}     // $332
        add (32|M0)              r6.0<1>:f     r74.0<1;1,0>:f    r104.0<1;1,0>:f  {Compacted,$13.dst} //  ALU pipe: float; $332
        store.slm.d32.a32 (32|M0)  [r44:2]      r6:2               {F@1,$15} // ex_desc:0x0; desc:0x4000504 // $333
// B061: Preds:{B060, B056},  Succs:{B062, B082}
_0_186:
        join (32|M0)                         L5224                                                   // 
L5224:
        sync.allrd                           ($5,$15)                                                // $335
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$3} // wr:1+0, rd:1; fence.slm.none.group // $335
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$3.dst}   //  memory fence commit; ALU pipe: int; $336
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$1} // wr:1+0, rd:1; fence.ugm.none.group // $336
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$10.src}       //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $337
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $337
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$1.dst}   //  memory fence commit; ALU pipe: int; $337
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$7} // wr:1+0, rd:0; signal barrier // $337
(W)     sync.bar                             0x0                                                     // $337
(W)     mov (1|M0)               r2.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $338
(W)     mov (16|M0)              r9.0<1>:f     0x43000000:f                               {Compacted} //  ALU pipe: float; $340
(W)     load.slm.d32x1t.a32 (1|M0)  r10:1       [r2:1]             {I@1,$4} // ex_desc:0x0; desc:0x2108500 // $339
(W)     mov (1|M0)               r11.0<1>:f    r10.0<0;1,0>:f                   {Compacted,$4.dst}   //  ALU pipe: float; $340
(W)     math.invm (16|M0) (eo)f2.0  r6.mme0:f  r11.nomme<1;1,0>:f  r9.nomme<1;1,0>:f {F@1}           //  ALU pipe: math; $340
(W&~f2.0) madm (16|M0)           r7.mme1:f     r53.nomme:f       r11.nomme:f       r6.mme0:f        {M@1} //  ALU pipe: float; $340
(W&~f2.0) madm (16|M0)           r8.mme2:f     r51.nomme:f       -r9.nomme:f       r6.mme0:f        {$7.src} //  ALU pipe: float; $340
(W&~f2.0) madm (16|M0)           r12.mme3:f    r6.mme0:f         r8.mme2:f         r6.mme0:f        {F@1} //  ALU pipe: float; $340
(W&~f2.0) madm (16|M0)           r10.mme4:f    r11.nomme:f       -r9.nomme:f       r7.mme1:f         //  ALU pipe: float; $340 R{} IR{}{O:5,O:4,O:3,},  {BC=1}
(W&~f2.0) madm (16|M0)           r7.mme5:f     r7.mme1:f         r10.mme4:f        r12.mme3:f       {F@1} //  ALU pipe: float; $340
(W&~f2.0) madm (16|M0)           r11.mme6:f    r11.nomme:f       -r9.nomme:f       r7.mme5:f        {F@1} //  ALU pipe: float; $340 R{} IR{}{O:5,O:4,O:3,},  {BC=1}
(W&~f2.0) madm (16|M0)           r6.nomme:f    r7.mme5:f         r11.mme6:f        r12.mme3:f       {F@1} //  ALU pipe: float; $340
(W)     add (1|M0)               r13.0<1>:f    r6.0<0;1,0>:f     0x358637BD:f               {F@1}    //  ALU pipe: float; $341
        shl (32|M0)              r14.0<1>:d    r55.0<1;1,0>:uw   2:w                                 //  ALU pipe: int; $343
(W)     math.rsqtm (16|M0) (eo)f2.0  r8.mme0:f  r13.nomme<1;1,0>:f              {F@1}                //  ALU pipe: math; $344
(W&~f2.0) madm (16|M0)           r10.mme1:f    r53.nomme:f       r54.nomme:f       r8.mme0:f        {M@1} //  ALU pipe: float; $344
(W&~f2.0) madm (16|M0)           r9.mme2:f     r53.nomme:f       r13.nomme:f       r8.mme0:f         //  ALU pipe: float; $344
(W&~f2.0) madm (16|M0)           r7.mme3:f     r54.nomme:f       -r9.mme2:f        r10.mme1:f       {F@1} //  ALU pipe: float; $344
(W&~f2.0) madm (16|M0)           r10.mme4:f    r10.mme1:f        r7.mme3:f         r10.mme1:f       {F@1} //  ALU pipe: float; $344
(W&~f2.0) madm (16|M0)           r8.mme5:f     r9.mme2:f         r7.mme3:f         r9.mme2:f         //  ALU pipe: float; $344
(W&~f2.0) madm (16|M0)           r7.mme6:f     r13.nomme:f       -r8.mme5:f        r8.mme5:f        {F@1} //  ALU pipe: float; $344
(W&~f2.0) madm (16|M0)           r8.nomme:f    r8.mme5:f         r10.mme4:f        r7.mme6:f        {F@1} //  ALU pipe: float; $344
(W)     shr (1|M0)               a0.0<1>:ud    r50.5<0;1,0>:ud   0x4:uw              {F@1}           //  ALU pipe: int; $346
        mov (32|M0)              r16.0<1>:f    r8.0<0;1,0>:f                    {Compacted,F@1}      //  ALU pipe: float; $345
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r14:2] r16:2     {A@1,$5} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $347
        sync.nop                             null                             {Compacted,$9.src}     // $349
        load.ugm.d32.a32.ca.ca (32|M0)  r48:2   ss[a0.0][r14:2]    {$10} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $349
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$15} // wr:1+0, rd:1; fence.slm.none.group // $350
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$15.dst}  //  memory fence commit; ALU pipe: int; $351
(W)     send.ugm (1|M0)          r11      r50  null:0  0x0            0x0210001F           {$3} // wr:1+0, rd:1; fence.ugm.none.group // $351
(W)     mov (1|M0)               r12.2<1>:f    0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $352
(W)     mov (2|M0)               r12.10<1>:ub  r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $352
(W)     mov (8|M0)               null<1>:ud    r11.0<1;1,0>:ud                  {Compacted,$3.dst}   //  memory fence commit; ALU pipe: int; $352
(W)     send.gtwy (1|M0)         null     r12  null:0  0x0            0x02000004           {I@2,$4} // wr:1+0, rd:0; signal barrier // $352
(W)     sync.bar                             0x0                                                     // $352
(~f1.0) goto (32|M0)                         _0_191            _0_191                                //  ALU pipe: int; $353
// B062: [inDivergent],  Preds:{B061},  Succs:{B063, B064}
_0_192:
(W)     shl (1|M0)               r4.4<1>:d     r50.1<0;1,0>:d    2:w                                 //  ALU pipe: int; $355
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.4<0;1,0>:d     r52.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $356 R{} IR{}{E:2,E:2,},  {BC=1}
(W&f2.0) jmpi                                _0_193                                                  //  ALU pipe: int; $357
// B063: [inDivergent],  Preds:{B062},  Succs:{B065}
_0_194:
(W)     add (1|M0)               r2.0<1>:d     r4.4<0;1,0>:d     -r52.0<0;1,0>:d                     //  ALU pipe: int; $359 R{} IR{}{E:2,E:2,},  {BC=1}
(W)     shl (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     7:w               {Compacted,I@1}   //  ALU pipe: int; $360
        add (32|M0)              r6.0<1>:d     r3.1<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $361
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $363
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,$4.src}   //  ALU pipe: int; $363
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $363
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    1:w               {@2,$10.src}      //  ALU pipe: int; $363
        add (16|M0)              r98.0<1>:q    r10.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $364
        add (16|M16)             r96.0<1>:q    r14.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $364
(W)     jmpi                                 _0_195                                                  // $365
// B064: [inDivergent],  Preds:{B062},  Succs:{B065}
_0_193:
(W)     shl (1|M0)               r2.0<1>:d     r50.1<0;1,0>:d    9:w               {Compacted}       //  ALU pipe: int; $367
        add (32|M0)              r6.0<1>:d     r2.0<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $368
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $370
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,$4.src}   //  ALU pipe: int; $370
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $370
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {@2,$10.src}      //  ALU pipe: int; $370
        add (16|M0)              r98.0<1>:q    r10.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $371
        add (16|M16)             r96.0<1>:q    r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $371
// B065: [inDivergent],  Preds:{B064, B063},  Succs:{B066, B067}
_0_195:
        mov (16|M0)              r6.0<1>:uq    r98.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $373
        mov (16|M16)             r8.0<1>:uq    r96.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $373
        load.ugm.d16u32.a64 (32|M0)  r10:2      [r6:4]             {I@1,$7} // ex_desc:0x0; desc:0x8200B80 // $374
(W)     add (1|M0)               r4.5<1>:d     r4.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $377
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.5<0;1,0>:d     r52.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $378
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:ud   16:w               {$7.dst}         //  ALU pipe: int; $375
        add (32|M0)              r94.0<1>:f    r12.0<1;1,0>:f    0x0:f               {Compacted,I@1} //  ALU pipe: float; $376
(W&f2.0) jmpi                                _0_196                                                  //  ALU pipe: int; $379
// B066: [inDivergent],  Preds:{B065},  Succs:{B068}
_0_197:
(W)     add3 (1|M0)              r2.0<1>:d     r4.4<0;0>:d       -r52.0<0;0>:d     1:w               //  ALU pipe: int; $381 R{} IR{}{E:2,E:2,},  {BC=1}
(W)     shl (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     7:w               {Compacted,I@1}   //  ALU pipe: int; $382
        add (32|M0)              r6.0<1>:d     r3.1<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $383
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $385
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,F@1}      //  ALU pipe: int; $385
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $385
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $385
        add (16|M0)              r30.0<1>:q    r10.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $386
        add (16|M16)             r28.0<1>:q    r14.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $386
(W)     jmpi                                 _0_198                                                  // $387
// B067: [inDivergent],  Preds:{B065},  Succs:{B068}
_0_196:
(W)     shl (1|M0)               r2.0<1>:d     r4.5<0;1,0>:d     7:w                                 //  ALU pipe: int; $389
        add (32|M0)              r6.0<1>:d     r2.0<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $390
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $392
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $392
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $392
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $392
        add (16|M0)              r30.0<1>:q    r10.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $393
        add (16|M16)             r28.0<1>:q    r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $393
// B068: [inDivergent],  Preds:{B067, B066},  Succs:{B069, B070}
_0_198:
        mov (16|M0)              r6.0<1>:uq    r30.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $395
        mov (16|M16)             r8.0<1>:uq    r28.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $395
        load.ugm.d16u32.a64 (32|M0)  r10:2      [r6:4]             {I@1,$15} // ex_desc:0x0; desc:0x8200B80 // $396
(W)     add (1|M0)               r4.5<1>:d     r4.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $399
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.5<0;1,0>:d     r52.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $400
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:ud   16:w               {$15.dst}        //  ALU pipe: int; $397
        add (32|M0)              r92.0<1>:f    r94.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $398
(W&f2.0) jmpi                                _0_199                                                  //  ALU pipe: int; $401
// B069: [inDivergent],  Preds:{B068},  Succs:{B071}
_0_200:
(W)     add3 (1|M0)              r2.0<1>:d     r4.4<0;0>:d       -r52.0<0;0>:d     2:w               //  ALU pipe: int; $403 R{} IR{}{E:2,E:2,},  {BC=1}
(W)     shl (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     7:w               {Compacted,I@1}   //  ALU pipe: int; $404
        add (32|M0)              r6.0<1>:d     r3.1<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $405
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $407
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,F@1}      //  ALU pipe: int; $407
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $407
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $407
        add (16|M0)              r26.0<1>:q    r10.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $408
        add (16|M16)             r24.0<1>:q    r14.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $408
(W)     jmpi                                 _0_201                                                  // $409
// B070: [inDivergent],  Preds:{B068},  Succs:{B071}
_0_199:
(W)     shl (1|M0)               r2.0<1>:d     r4.5<0;1,0>:d     7:w                                 //  ALU pipe: int; $411
        add (32|M0)              r6.0<1>:d     r2.0<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $412
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $414
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $414
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $414
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $414
        add (16|M0)              r26.0<1>:q    r10.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $415
        add (16|M16)             r24.0<1>:q    r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $415
// B071: [inDivergent],  Preds:{B070, B069},  Succs:{B072, B073}
_0_201:
        mov (16|M0)              r6.0<1>:uq    r26.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $417
        mov (16|M16)             r8.0<1>:uq    r24.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $417
        load.ugm.d16u32.a64 (32|M0)  r10:2      [r6:4]             {I@1,$3} // ex_desc:0x0; desc:0x8200B80 // $418
(W)     add (1|M0)               r4.5<1>:d     r4.4<0;1,0>:d     3:w                                 //  ALU pipe: int; $421
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.5<0;1,0>:d     r52.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $422
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:ud   16:w               {$3.dst}         //  ALU pipe: int; $419
        add (32|M0)              r90.0<1>:f    r92.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $420 R{} IR{}{E:6,E:6,},  R{} IR{}{O:14,O:6,},  {BC=1}
(W&f2.0) jmpi                                _0_202                                                  //  ALU pipe: int; $423
// B072: [inDivergent],  Preds:{B071},  Succs:{B074}
_0_203:
(W)     add3 (1|M0)              r2.0<1>:d     r4.4<0;0>:d       -r52.0<0;0>:d     3:w               //  ALU pipe: int; $425 R{} IR{}{E:2,E:2,},  {BC=1}
(W)     shl (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     7:w               {Compacted,I@1}   //  ALU pipe: int; $426
        add (32|M0)              r6.0<1>:d     r3.1<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $427
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $429
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,F@1}      //  ALU pipe: int; $429
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $429
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $429
        add (16|M0)              r18.0<1>:q    r10.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $430
        add (16|M16)             r16.0<1>:q    r14.0<1;1,0>:q    r3.3<0;1,0>:q    {Compacted,@2,$5.src} //  ALU pipe: int; $430
(W)     jmpi                                 _0_204                                                  // $431
// B073: [inDivergent],  Preds:{B071},  Succs:{B074}
_0_202:
(W)     shl (1|M0)               r2.0<1>:d     r4.5<0;1,0>:d     7:w                                 //  ALU pipe: int; $433
        add (32|M0)              r6.0<1>:d     r2.0<0;1,0>:d     r46.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $434
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $436
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $436
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $436
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $436
        add (16|M0)              r18.0<1>:q    r10.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $437
        add (16|M16)             r16.0<1>:q    r14.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,@2,$5.src} //  ALU pipe: int; $437
// B074: [inDivergent],  Preds:{B073, B072},  Succs:{B075, B076}
_0_204:
        mov (16|M0)              r6.0<1>:uq    r18.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $439
        mov (16|M16)             r8.0<1>:uq    r16.0<1;1,0>:uq                  {Compacted,I@2}      //  ALU pipe: int; $439
        load.ugm.d16u32.a64 (32|M0)  r10:2      [r6:4]             {I@1,$7} // ex_desc:0x0; desc:0x8200B80 // $440
(W)     mov (32|M0)              r56.0<1>:f    0x3F800000:f                               {$11.src}  //  ALU pipe: float; $456
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:ud   16:w               {$7.dst}         //  ALU pipe: int; $441
        add (32|M0)              acc0.0<1>:f   r90.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $442
        mul (32|M0)              r78.0<1>:f    acc0.0<1;1,0>:f   0x3E800000:f               {Compacted,$11.dst} //  ALU pipe: float; $443
        and (32|M0)              r14.0<1>:d    r78.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $444
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r14.0<1;1,0>:ud   0x7F800000:ud              {I@1}    //  ALU pipe: int; $445
(~f2.0) shr (32|M0)              r6.0<1>:ud    r78.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $448
(~f2.0) and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $449
(~f2.0) add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r78.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $450
(~f2.0) and (32|M0)              r68.0<1>:d    r10.0<1;1,0>:d    -65536:d               {I@1}        //  ALU pipe: int; $451
(f2.0)  bfn.(s0&s1|s2) (32|M0)   r68.0<1>:ud   r78.0<1;0>:ud     r4.3<0;0>:ud      r4.2<0>:ud        //  ALU pipe: int; $454
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $456
        sync.nop                             null                             {Compacted,I@1}        // $456
        sync.nop                             null                             {Compacted,$8.src}     // $456
        math.invm (16|M0) (eo)f2.0  r64.mme0:f  r56.nomme<1;1,0>:f  r48.nomme<1;1,0>:f {$10.dst}     //  ALU pipe: math; $456
(f2.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $456
// B075: [inDivergent],  Preds:{B074},  Succs:{B076}
_L_k0_2_:
        sync.nop                             null                             {Compacted,M@1}        // $456
        madm (16|M0)             r62.mme1:f    r53.nomme:f       r56.nomme:f       r64.mme0:f       {$14.src} //  ALU pipe: float; $456
        madm (16|M0)             r60.mme2:f    r51.nomme:f       -r48.nomme:f      r64.mme0:f       {$6.src} //  ALU pipe: float; $456
        madm (16|M0)             r70.mme3:f    r64.mme0:f        r60.mme2:f        r64.mme0:f       {F@1} //  ALU pipe: float; $456
        madm (16|M0)             r58.mme4:f    r56.nomme:f       -r48.nomme:f      r62.mme1:f       {$0.src} //  ALU pipe: float; $456 R{} IR{}{E:4,E:0,E:7,},  {BC=1}
        madm (16|M0)             r62.mme5:f    r62.mme1:f        r58.mme4:f        r70.mme3:f       {F@1} //  ALU pipe: float; $456 R{} IR{}{E:7,E:5,E:3,},  {BC=1}
        madm (16|M0)             r66.mme6:f    r56.nomme:f       -r48.nomme:f      r62.mme5:f       {F@1} //  ALU pipe: float; $456 R{} IR{}{E:4,E:0,E:7,},  {BC=1}
        madm (16|M0)             r64.nomme:f   r62.mme5:f        r66.mme6:f        r70.mme3:f       {F@1} //  ALU pipe: float; $456 R{} IR{}{E:7,E:1,E:3,},  {BC=1}
// B076: [inDivergent],  Preds:{B075, B074},  Succs:{B077, B078}
_L_k0_0_macro:
        join (32|M0)                         _0_191                                                  // 
L7424:
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $456
        math.invm (16|M16) (eo)f2.0  r65.mme0:f  r57.nomme<1;1,0>:f  r49.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $456
(f2.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $456
// B077: [inDivergent],  Preds:{B076},  Succs:{B078}
_L_k0_3_:
        sync.nop                             null                             {Compacted,M@1}        // $456
        madm (16|M16)            r63.mme1:f    r53.nomme:f       r57.nomme:f       r65.mme0:f       {$14.src} //  ALU pipe: float; $456 R{} IR{}{O:2,O:4,O:0,},  {BC=1}
        madm (16|M16)            r61.mme2:f    r51.nomme:f       -r49.nomme:f      r65.mme0:f       {$6.src} //  ALU pipe: float; $456
        madm (16|M16)            r71.mme3:f    r65.mme0:f        r61.mme2:f        r65.mme0:f       {F@1} //  ALU pipe: float; $456
        madm (16|M16)            r59.mme4:f    r57.nomme:f       -r49.nomme:f      r63.mme1:f       {$0.src} //  ALU pipe: float; $456 R{} IR{}{O:4,O:0,O:7,},  {BC=1}
        madm (16|M16)            r63.mme5:f    r63.mme1:f        r59.mme4:f        r71.mme3:f       {F@1} //  ALU pipe: float; $456 R{} IR{}{O:7,O:5,O:3,},  {BC=1}
        madm (16|M16)            r67.mme6:f    r57.nomme:f       -r49.nomme:f      r63.mme5:f       {F@1} //  ALU pipe: float; $456 R{} IR{}{O:4,O:0,O:7,},  {BC=1}
        madm (16|M16)            r65.nomme:f   r63.mme5:f        r67.mme6:f        r71.mme3:f       {F@1} //  ALU pipe: float; $456 R{} IR{}{O:7,O:1,O:3,},  {BC=1}
// B078: [inDivergent],  Preds:{B077, B076},  Succs:{B079, B080}
_L_k0_1_macro:
        join (32|M0)                         _0_191                                                  // 
L7608:
(W)     and (1|M0)               r2.0<1>:d     r2.7<0;1,0>:d     8:w                                 //  ALU pipe: int; $459
        mul (32|M0)              r88.0<1>:f    r64.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $457
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r2.0<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $460
        mov (16|M0)              r6.0<4>:uw    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $458
        mov (16|M16)             r8.0<4>:uw    r1.16<1;1,0>:uw                                       //  ALU pipe: int; $458
        mov (16|M0)              r86.0<1>:q    r6.0<4;1,0>:uw                   {@2,$8.dst}          //  ALU pipe: int; $458
        mov (16|M16)             r92.0<1>:q    r8.0<4;1,0>:uw                   {I@2}                //  ALU pipe: int; $458
(W&f2.0) jmpi                                _0_208                                                  //  ALU pipe: int; $461
// B079: [inDivergent],  Preds:{B078},  Succs:{B081}
_0_209:
        shl (16|M0)              r6.0<1>:q     r86.0<1;1,0>:q    2:w               {Compacted,I@3}   //  ALU pipe: int; $463
        shl (16|M16)             r8.0<1>:q     r92.0<1;1,0>:q    2:w               {Compacted,I@3}   //  ALU pipe: int; $463
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $464
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $464
        load.ugm.d32.a64 (32|M0)  r70:2         [r10:4]            {I@1,$15} // ex_desc:0x0; desc:0x8200580 // $466
(W)     jmpi                                 _0_210                                                  // $467
// B080: [inDivergent],  Preds:{B078},  Succs:{B081}
_0_208:
        shl (16|M0)              r6.0<1>:q     r86.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $469
        shl (16|M16)             r8.0<1>:q     r92.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $469
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $470
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $470
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r10:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200B80 // $472
        shl (32|M0)              r70.0<1>:d    r14.0<1;1,0>:ud   16:w               {$3.dst}         //  ALU pipe: int; $473
// B081: [inDivergent],  Preds:{B080, B079},  Succs:{B082}
_0_210:
(W)     and (1|M0)               r2.0<1>:d     r2.7<0;1,0>:d     1:w                                 //  ALU pipe: int; $475
(W)     mov (1|M0)               r3.1<1>:f     r2.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $476
        add (32|M0)              acc0.0<1>:f   r70.0<1;1,0>:f    r3.1<0;1,0>:f    {Compacted,@1,$15.dst} //  ALU pipe: float; $477
        mul (32|M0)              r76.0<1>:f    r88.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,$9.dst} //  ALU pipe: float; $478
        and (32|M0)              r6.0<1>:d     r76.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $479
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r6.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $480
(~f2.0) shr (32|M0)              r6.0<1>:ud    r76.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $483
(~f2.0) and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $484
(~f2.0) add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r76.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $485
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $491
(~f2.0) and (32|M0)              r84.0<1>:d    r10.0<1;1,0>:d    -65536:d               {@2,$14.dst} //  ALU pipe: int; $486
(f2.0)  bfn.(s0&s1|s2) (32|M0)   r84.0<1>:ud   r76.0<1;0>:ud     r4.3<0;0>:ud      r4.2<0>:ud        //  ALU pipe: int; $489
        store.slm.d32.a32 (32|M0)  [r6:2]       r84:2              {I@1,$7} // ex_desc:0x0; desc:0x4000504 // $492
// B082: Preds:{B081, B061},  Succs:{B083, B092}
_0_191:
        join (32|M0)                         L8056                                                   // 
L8056:
        sync.nop                             null                             {Compacted,$7.src}     // $494
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$9} // wr:1+0, rd:1; fence.slm.none.group // $494
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$9.dst}   //  memory fence commit; ALU pipe: int; $495
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$15} // wr:1+0, rd:1; fence.ugm.none.group // $495
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $496
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $496
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$15.dst}  //  memory fence commit; ALU pipe: int; $496
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$3} // wr:1+0, rd:0; signal barrier // $496
(W)     sync.bar                             0x0                                                     // $496
(~f1.0) goto (32|M0)                         _0_214            _0_214                                //  ALU pipe: int; $497
// B083: [inDivergent],  Preds:{B082},  Succs:{B084, B085}
_0_215:
(W)     shl (1|M0)               r4.2<1>:d     r50.1<0;1,0>:d    7:w                                 //  ALU pipe: int; $499
(f3.0)  goto (32|M0)                         _0_216            _0_216                                //  ALU pipe: int; $500
// B084: [inDivergent],  Preds:{B083},  Succs:{B088}
_0_217:
        shl (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $502
        sync.nop                             null                             {Compacted,$13.dst}    // $503
        load.slm.d32.a32 (32|M0)  r74:2         [r6:2]             {I@1,$2} // ex_desc:0x0; desc:0x4200500 // $503
        goto (32|M0)                         _0_216            _0_218                                // $504
// B085: [inDivergent],  Preds:{B083},  Succs:{B086, B087}
_0_216:
        join (32|M0)                         _0_218                                                  // 
L8288:
        and (32|M0)              acc0.0<1>:w   r1.0<1;1,0>:w     31:w                                //  ALU pipe: int; $507
        shl (32|M0)              r6.0<1>:w     acc0.0<1;1,0>:w   1:w               {$2.src}          //  ALU pipe: int; $508
(W)     shl (1|M0)               r2.0<1>:d     r50.1<0;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $506
        shl (32|M0)              r7.0<1>:w     acc0.0<1;1,0>:w   2:w                                 //  ALU pipe: int; $522
        or (32|M0)               r8.0<1>:d     r2.0<0;1,0>:d     r6.0<1;1,0>:uw   {@2,$3.src}        //  ALU pipe: int; $510
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $512
        mov (16|M16)             r14.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted,$10.src}  //  ALU pipe: int; $512
        shl (16|M0)              r12.0<1>:q    r10.0<2;1,0>:d    1:w               {@2,$4.src}       //  ALU pipe: int; $512
        shl (16|M16)             r16.0<1>:q    r14.0<2;1,0>:d    1:w               {@2,$5.src}       //  ALU pipe: int; $512
        add (16|M0)              r18.0<1>:q    r12.0<1;1,0>:q    r5.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $513
        add (16|M16)             r20.0<1>:q    r16.0<1;1,0>:q    r5.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $513
        load.ugm.d32.a64 (32|M0)  r22:2         [r18:4]            {I@1,$7} // ex_desc:0x0; desc:0x8200580 // $515
        mov (32|M0)              r88.0<1>:d    r7.0<1;1,0>:uw                                        //  ALU pipe: int; $523
        mov (32|M0)              r90.0<1>:ud   r7.0<1;1,0>:uw                                        //  ALU pipe: int; $524
        mov (32|M0)              r24.0<1>:d    r22.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $518
        mov (32|M0)              r26.0<1>:d    r22.1<2;1,0>:uw                                       //  ALU pipe: int; $520
        shl (32|M0)              r42.0<1>:d    r24.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $519
        shl (32|M0)              r94.0<1>:d    r26.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $521
(f0.0)  goto (32|M0)                         _0_219            _0_219                                //  ALU pipe: int; $525
// B086: [inDivergent],  Preds:{B085},  Succs:{B088}
_0_220:
        or (32|M0)               r6.0<1>:d     r88.0<1;1,0>:d    128:w               {Compacted}     //  ALU pipe: int; $527
        load.slm.d32.a32 (32|M0)  r8:2          [r6:2]             {I@1,$9} // ex_desc:0x0; desc:0x4200500 // $528
        load.slm.d32.a32 (32|M0)  r10:2         [r90:2]            {$15} // ex_desc:0x0; desc:0x4200500 // $529
        mul (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     r42.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $530
        mul (32|M0)              acc2.0<1>:f   r10.0<1;1,0>:f    r94.0<1;1,0>:f   {Compacted,$15.dst} //  ALU pipe: float; $531
        sync.nop                             null                             {Compacted,$2.dst}     // $532
        add (32|M0)              r74.0<1>:f    acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted,$13.dst} //  ALU pipe: float; $532
        goto (32|M0)                         _0_219            _0_218                                // $533
// B087: [inDivergent],  Preds:{B085},  Succs:{B088}
_0_219:
        join (32|M0)                         _0_218                                                  // 
L8640:
        or (32|M0)               r8.0<1>:d     r88.0<1;1,0>:d    128:w               {Compacted,F@3} //  ALU pipe: int; $536
        load.slm.d32.a32 (32|M0)  r6:2          [r90:2]            {$7} // ex_desc:0x0; desc:0x4200500 // $535
        load.slm.d32.a32 (32|M0)  r10:2         [r8:2]             {A@1,$9} // ex_desc:0x0; desc:0x4200500 // $537
        mul (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     r42.0<1;1,0>:f   {Compacted,$7.dst} //  ALU pipe: float; $538
        mul (32|M0)              acc2.0<1>:f   r10.0<1;1,0>:f    r94.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $539
        sync.nop                             null                             {Compacted,$2.dst}     // $540
        add (32|M0)              r74.0<1>:f    acc0.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted,$13.dst} //  ALU pipe: float; $540
// B088: [inDivergent],  Preds:{B087, B086, B084},  Succs:{B089, B090}
_0_218:
        join (32|M0)                         _0_214                                                  // 
L8728:
        sync.nop                             null                             {Compacted,F@1}        // $542
        and (32|M0)              r6.0<1>:d     r74.0<1;1,0>:d    2147483647:d               {$2.dst} //  ALU pipe: int; $542
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r6.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $543
(f0.0)  goto (32|M0)                         _0_221            _0_221                                //  ALU pipe: int; $544
// B089: [inDivergent],  Preds:{B088},  Succs:{B091}
_0_222:
        shr (32|M0)              r6.0<1>:ud    r74.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $546
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {Compacted,@1,$3.src} //  ALU pipe: int; $547
        add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r74.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $548
        shr (32|M0)              r12.0<1>:ud   r10.0<1;1,0>:ud   16:w               {@1,$4.src}      //  ALU pipe: int; $549
        mov (32|M0)              r72.0<1>:w    r12.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $550
        goto (32|M0)                         _0_221            _0_223                                // $551
// B090: [inDivergent],  Preds:{B088},  Succs:{B091}
_0_221:
        join (32|M0)                         _0_223                                                  // 
L8888:
        shr (32|M0)              r6.0<1>:ud    r74.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $553
        or (32|M0)               r72.0<1>:w    r6.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $555
// B091: [inDivergent],  Preds:{B090, B089},  Succs:{B092}
_0_223:
        join (32|M0)                         _0_214                                                  // 
L8936:
        add (32|M0)              r6.0<1>:d     r4.2<0;1,0>:d     r46.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $557
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,@1,$3.src} //  ALU pipe: int; $559
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,$4.src}   //  ALU pipe: int; $559
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $559
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:ud   1:w               {@2,$10.src}      //  ALU pipe: int; $559
        mov (32|M0)              r20.0<1>:ud   r72.0<1;1,0>:uw                                       //  ALU pipe: int; $562
        add (16|M0)              r16.0<1>:q    r10.0<1;1,0>:q    r4.0<0;1,0>:q    {Compacted,@3,$5.src} //  ALU pipe: int; $560
        add (16|M16)             r18.0<1>:q    r14.0<1;1,0>:q    r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $560
        store.ugm.d16u32.a64 (32|M0)  [r16:4]   r20:2              {I@1,$15} // ex_desc:0x0; desc:0x8000B84 // $563
// B092: Preds:{B091, B082},  Succs:{B103}
_0_214:
        join (32|M0)                         L9056                                                   // 
L9056:
        sync.nop                             null                             {Compacted,$2.src}     // $565
(W)     send.slm (1|M0)          r6       r50  null:0  0x0            0x0210001F           {$7} // wr:1+0, rd:1; fence.slm.none.group // $565
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$7.dst}   //  memory fence commit; ALU pipe: int; $566
(W)     send.ugm (1|M0)          r7       r50  null:0  0x0            0x0210001F           {$9} // wr:1+0, rd:1; fence.ugm.none.group // $566
(W)     mov (1|M0)               r8.2<1>:f     0x100:f                               {$3.src}        //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $567
(W)     mov (2|M0)               r8.10<1>:ub   r50.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $567
(W)     mov (8|M0)               null<1>:ud    r7.0<1;1,0>:ud                   {Compacted,$9.dst}   //  memory fence commit; ALU pipe: int; $567
(W)     send.gtwy (1|M0)         null     r8  null:0  0x0            0x02000004           {I@2,$7} // wr:1+0, rd:0; signal barrier // $567
(W)     sync.bar                             0x0                                                     // $567
(W)     jmpi                                 _0_131                                                  // $568
// B093: Preds:{B009},  Succs:{B094, B097}
_0_135:
(W)     shl (1|M0)               r2.0<1>:d     r2.3<0;1,0>:d     9:w               {Compacted}       //  ALU pipe: int; $570
        mov (32|M0)              r40.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $571
        cmp (32|M0)   (gt)f0.0   null<1>:d     r2.0<0;1,0>:d     r40.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $572
(~f0.0) goto (32|M0)                         _0_224            _0_224                                //  ALU pipe: int; $573
// B094: [inDivergent],  Preds:{B093},  Succs:{B095}
_0_225:
        mov (32|M0)              r44.0<1>:f    r40.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $576
(W)     shl (1|M0)               r2.1<1>:d     r52.0<0;1,0>:d    9:w               {Compacted}       //  ALU pipe: int; $575
// B095: [inDivergent],  Preds:{B096, B094},  Succs:{B096, B097}
_0_226:
        sync.nop                             null                             {Compacted,F@1}        // $580
        mov (16|M0)              r6.0<2>:ud    r44.0<1;1,0>:ud                  {Compacted,$10.src}  //  ALU pipe: int; $580
        mov (16|M16)             r8.0<2>:ud    r45.0<1;1,0>:ud                  {Compacted,$12.src}  //  ALU pipe: int; $580
        shl (16|M0)              r12.0<1>:q    r6.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $580
        shl (16|M16)             r14.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $580
        add (16|M0)              r20.0<1>:q    r12.0<1;1,0>:q    r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $581
        add (16|M16)             r22.0<1>:q    r14.0<1;1,0>:q    r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $581
        load.ugm.d16u32.a64 (32|M0)  r32:2      [r20:4]            {I@1,$11} // ex_desc:0x0; desc:0x8200B80 // $583
        add (32|M0)              r10.0<1>:d    r2.1<0;1,0>:d     r44.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $578
        mov (16|M0)              r16.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $592
        mov (16|M16)             r18.0<2>:ud   r11.0<1;1,0>:ud                  {Compacted,$9.src}   //  ALU pipe: int; $592
        shl (16|M0)              r24.0<1>:q    r16.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $592
        shl (16|M16)             r26.0<1>:q    r18.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $592
        add (16|M0)              r34.0<1>:q    r24.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $593
        add (16|M16)             r36.0<1>:q    r26.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $593
        add (16|M0)              r28.0<1>:q    r12.0<1;1,0>:q    r3.2<0;1,0>:q    {Compacted}        //  ALU pipe: int; $585
        add (16|M16)             r30.0<1>:q    r14.0<1;1,0>:q    r3.2<0;1,0>:q    {Compacted}        //  ALU pipe: int; $585
        add (32|M0)              r42.0<1>:d    r44.0<1;1,0>:d    128:w               {Compacted}     //  ALU pipe: int; $607
        cmp (32|M0)   (lt)f0.0   null<1>:d     r42.0<1;1,0>:d    r2.0<0;1,0>:d    {I@1}              //  ALU pipe: int; $608
        add (16|M0)              r6.0<1>:q     r24.0<1;1,0>:q    r3.6<0;1,0>:q                       //  ALU pipe: int; $603
        add (16|M16)             r8.0<1>:q     r26.0<1;1,0>:q    r3.6<0;1,0>:q                       //  ALU pipe: int; $603
        and (32|M0)              r10.0<1>:w    r32.0<2;1,0>:w    32767:w               {$11.dst}     //  ALU pipe: int; $587
        cmp (32|M0)   (gt)f1.0   r39.0<1>:uw   r10.0<1;1,0>:uw   0x7F80:uw              {I@1}        //  ALU pipe: int; $589
        or (32|M0)               r11.0<1>:w    r32.0<2;1,0>:w    64:w                                //  ALU pipe: int; $588
        mov (32|M0)              r38.0<1>:uw   r32.0<2;1,0>:uw                                       //  ALU pipe: int; $590
        bfn.(s0&s1|~s0&s2) (32|M0)   r16.0<1>:uw  r39.0<1;0>:uw  r11.0<1;0>:uw     r38.0<1>:uw      {I@1} //  ALU pipe: int; $590
        mov (32|M0)              r18.0<1>:ud   r16.0<1;1,0>:uw                  {I@1}                //  ALU pipe: int; $595
        store.ugm.d16u32.a64 (32|M0)  [r34:4]   r18:2              {I@1,$9} // ex_desc:0x0; desc:0x8000B84 // $596
        load.ugm.d16u32.a64 (32|M0)  r12:2      [r28:4]            {$13} // ex_desc:0x0; desc:0x8200B80 // $597
        and (32|M0)              r14.0<1>:w    r12.0<2;1,0>:w    32767:w               {$13.dst}     //  ALU pipe: int; $599
        cmp (32|M0)   (gt)f1.0   r21.0<1>:uw   r14.0<1;1,0>:uw   0x7F80:uw              {I@1}        //  ALU pipe: int; $601
        or (32|M0)               r15.0<1>:w    r12.0<2;1,0>:w    64:w                                //  ALU pipe: int; $600
        mov (32|M0)              r20.0<1>:uw   r12.0<2;1,0>:uw                                       //  ALU pipe: int; $602
        bfn.(s0&s1|~s0&s2) (32|M0)   r15.0<1>:uw  r21.0<1;0>:uw  r15.0<1;0>:uw     r20.0<1>:uw      {I@1} //  ALU pipe: int; $602
        mov (32|M0)              r22.0<1>:ud   r15.0<1;1,0>:uw                  {I@1}                //  ALU pipe: int; $605
        store.ugm.d16u32.a64 (32|M0)  [r6:4]    r22:2              {I@1,$10} // ex_desc:0x0; desc:0x8000B84 // $606
(~f0.0) goto (32|M0)                         _0_224            _0_224                                //  ALU pipe: int; $609
// B096: [inDivergent],  Preds:{B095},  Succs:{B095}
_0_227:
        mov (32|M0)              r44.0<1>:f    r42.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $611
(W)     jmpi                                 _0_226                                                  // $612
// B097: Preds:{B095, B093},  Succs:{B098, B103}
_0_224:
        join (32|M0)                         L9792                                                   // 
L9792:
(W)     shl (1|M0)               r5.2<1>:d     r2.3<0;1,0>:d     7:w                                 //  ALU pipe: int; $614
        cmp (32|M0)   (gt)f0.0   null<1>:d     r5.2<0;1,0>:d     r40.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $615
(~f0.0) goto (32|M0)                         _0_131            _0_131                                //  ALU pipe: int; $616
// B098: [inDivergent],  Preds:{B097},  Succs:{B099}
_0_228:
(W)     shl (1|M0)               r5.3<1>:d     r52.0<0;1,0>:d    7:w                                 //  ALU pipe: int; $618
// B099: [inDivergent],  Preds:{B099, B098},  Succs:{B100, B099}
_0_229:
        sync.nop                             null                             {Compacted,$14.src}    // $620
        shl (32|M0)              r6.0<1>:d     r40.0<1;1,0>:d    1:w               {Compacted,$10.src} //  ALU pipe: int; $620
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,@1,$12.src} //  ALU pipe: int; $622
        mov (16|M16)             r14.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $622
        add (16|M0)              r10.0<1>:q    r8.0<2;1,0>:ud    r3.3<0;1,0>:q    {I@2}              //  ALU pipe: int; $622
        add (16|M16)             r12.0<1>:q    r14.0<2;1,0>:ud   r3.3<0;1,0>:q    {I@2}              //  ALU pipe: int; $622
        load.ugm.d16u32.a64 (32|M0)  r16:2      [r10:4]            {I@1,$15} // ex_desc:0x0; desc:0x8200B80 // $624
        add (32|M0)              r26.0<1>:d    r5.3<0;1,0>:d     r40.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $630
        mov (16|M0)              r28.0<2>:ud   r26.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $632
        mov (16|M16)             r32.0<2>:ud   r27.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $632
        add (32|M0)              r40.0<1>:d    r40.0<1;1,0>:d    128:w               {Compacted}     //  ALU pipe: int; $637
        shl (16|M0)              r30.0<1>:q    r28.0<2;1,0>:ud   1:w               {I@3}             //  ALU pipe: int; $632
        shl (16|M16)             r8.0<1>:q     r32.0<2;1,0>:ud   1:w               {I@3}             //  ALU pipe: int; $632
        add (16|M0)              r34.0<1>:q    r30.0<1;1,0>:q    r3.7<0;1,0>:q    {Compacted,@2,$9.src} //  ALU pipe: int; $633
        add (16|M16)             r36.0<1>:q    r8.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $633
        and (32|M0)              r18.0<1>:w    r16.0<2;1,0>:w    32767:w               {$15.dst}     //  ALU pipe: int; $626
        cmp (32|M0)   (gt)f0.0   r22.0<1>:uw   r18.0<1;1,0>:uw   0x7F80:uw              {I@1}        //  ALU pipe: int; $628
        or (32|M0)               r19.0<1>:w    r16.0<2;1,0>:w    64:w                                //  ALU pipe: int; $627
        mov (32|M0)              r24.0<1>:uw   r16.0<2;1,0>:uw                                       //  ALU pipe: int; $629
        bfn.(s0&s1|~s0&s2) (32|M0)   r20.0<1>:uw  r22.0<1;0>:uw  r19.0<1;0>:uw     r24.0<1>:uw      {I@1} //  ALU pipe: int; $629
        cmp (32|M0)   (lt)f0.0   null<1>:d     r40.0<1;1,0>:d    r5.2<0;1,0>:d                       //  ALU pipe: int; $638
        mov (32|M0)              r6.0<1>:ud    r20.0<1;1,0>:uw                  {I@2}                //  ALU pipe: int; $635
        store.ugm.d16u32.a64 (32|M0)  [r34:4]   r6:2               {I@1,$14} // ex_desc:0x0; desc:0x8000B84 // $636
(f0.0)  goto.b (32|M0)                       _L_k0_4_          _0_229                                //  ALU pipe: int; $639
// B100: [inDivergent],  Preds:{B099},  Succs:{B103}
_L_k0_4_:
        join (32|M0)                         _0_131                                                  // 
L10176:
        goto (32|M0)                         _0_131            _0_131                                // $640
// B101: [inDivergent],  Preds:{B008},  Succs:{B102, B103}
_0_133:
        cmp (32|M0)   (eq)f1.0   null<1>:d     r50.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $642
(W)     mov (1|M0)               r2.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $643
        sync.nop                             null                             {Compacted,F@1}        // $643
(f1.0)  sel (32|M0)              r6.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw              {$14.src}       //  ALU pipe: int; $643
(f0.0)  sel (32|M0)              r7.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $643
        and (32|M0)   (ne)f1.0   null<2>:uw    r6.0<1;1,0>:uw    r7.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $643
(~f1.0) goto (32|M0)                         _0_131            _0_131                                //  ALU pipe: int; $644
// B102: [inDivergent],  Preds:{B101},  Succs:{B103}
_0_230:
(W)     mov (1|M0)               r2.0<1>:uq    r5.0<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $646
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $649
        mov (16|M0)              r6.0<2>:f     r2.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $647
        mov (16|M16)             r8.0<2>:f     r2.0<0;1,0>:f                    {$12.src}            //  ALU pipe: float; $647
        mov (16|M0)              r6.1<2>:f     r2.1<0;1,0>:f                                         //  ALU pipe: float; $648
        mov (16|M16)             r8.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $648
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$0} // ex_desc:0x0; desc:0x800058B // $650
// B103: Preds:{B102, B101, B100, B097, B092, B011, B010, B007},  Succs:{}
_0_131:
        join (32|M0)                         L10408                                                  // 
L10408:
        sync.nop                             null                             {Compacted,$2.src}     // $652
(W)     mov (16|M0)              r127.0<1>:f   r50.0<1;1,0>:f                   {Compacted,$1.src}   //  ALU pipe: float; $652
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$3} // wr:1+0, rd:0; end of thread // $652
L10440:
(W)     mov (16|M0)              null<1>:ud    0x3272F450:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4AD9094D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x3:ud                                                // 


//.BankConflicts: 26
//.ByteRMWs: 1
//


//.numALUInst: 602
//.accSubDef: 8
//.accSubUse: 9
//.accSubCandidateDef: 8
//.accSubCandidateUse: 9
//
//
//.singlePipeAtOneDistNum: 223
//.allAtOneDistNum: 8
//.syncInstCount: 25
//.tokenReuseCount: 2
//.AfterWriteTokenDepCount: 79
//.AfterReadTokenDepCount: 69
