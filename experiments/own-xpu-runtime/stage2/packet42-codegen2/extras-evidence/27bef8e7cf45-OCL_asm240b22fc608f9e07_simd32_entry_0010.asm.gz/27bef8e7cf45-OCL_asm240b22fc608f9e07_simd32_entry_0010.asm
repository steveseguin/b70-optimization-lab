//.kernel _ZTSN9p42extras6NgNameILi2ELi1ELi32ELi0ELi0EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 604709628 1620024839 -hashmovs1 0 10 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 604709628 1620024839 -hashmovs1 0 10 -GRFBumpUpNumber 2 "
//.instCount 414
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r52.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.6)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.2)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.4)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.5)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r52.0)
//.declare V0034 (44)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0035 (45)  rf=r size=8 type=uq align=4 words (r2.2)
//.declare V0037 (47)  rf=r size=32 type=d alias=+0 align=32 words (r52.0)
//.declare V0039 (49)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0040 (50)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=8 type=uq align=4 words (r5.7)
//.declare V0044 (54)  rf=r size=8 type=uq align=4 words (r6.0)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0070 (80)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0071 (81)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0075 (85)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0076 (86)  rf=r size=8 type=d alias=V0034+0 align=32 words (r2.6)
//.declare V0077 (87)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0078 (88)  rf=r size=12 type=ud alias=V0039+0 align=32 words (r2.0)
//.declare V0079 (89)  rf=r size=32 type=ud alias=V0037+0 align=32 words (r52.0)
//.declare V0080 (90)  rf=r size=8 type=ud alias=V0077+0 align=4 words (r2.10)
//.declare V0081 (91)  rf=r size=8 type=d alias=V0077+0 align=4 words (r2.10)
//.declare V0082 (92)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0085 (95)  rf=r size=64 type=uw alias=V0040+0 align=32 words (r1.0)
//.declare V0089 (99)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0090 (100)  rf=r size=128 type=d align=32 words (r42.0)
//.declare P01 (101)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0091 (102)  rf=r size=128 type=ud alias=V0089+0 align=32 words (r44.0)
//.declare V0092 (103)  rf=r size=8 type=ud alias=V0075+0 align=2 words (r2.8)
//.declare P02 (104)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P03 (105)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0093 (106)  rf=r size=128 type=ud alias=V0090+0 align=32 words (r42.0)
//.declare V0094 (107)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0095 (108)  rf=r size=4 type=d align=2 words (r2.3)
//.declare P04 (109)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0096 (110)  rf=r size=2 type=w align=1 words (r3.8)
//.declare V0097 (111)  rf=r size=2 type=b align=1 words (r4.0)
//.declare V0098 (112)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0099 (113)  rf=r size=2 type=ub alias=V0097+0 align=1 words (r4.0)
//.declare V0100 (114)  rf=r size=4 type=d align=2 words (r32.4)
//.declare V0101 (115)  rf=r size=4 type=d align=2 words (r32.3)
//.declare V0102 (116)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0103 (117)  rf=r size=4 type=d align=32 words (r7.0)
//.declare V0104 (118)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0105 (119)  rf=r size=4 type=ud alias=V0103+0 align=2 words (r7.0)
//.declare V0106 (120)  rf=r size=4 type=ud alias=V0094+0 align=2 words (r3.0)
//.declare V0107 (121)  rf=r size=4 type=ud alias=V0101+0 align=2 words (r32.3)
//.declare V0108 (122)  rf=r size=4 type=d align=32 words (r8.0)
//.declare V0110 (124)  rf=r size=4 type=d align=32 words (r9.0)
//.declare P05 (125)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P06 (126)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P07 (127)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0111 (128)  rf=r size=4 type=ud alias=V0104+0 align=2 words (r4.0)
//.declare V0112 (129)  rf=r size=8 type=uq alias=V0071+0 align=32 words (r5.6)
//.declare V0113 (130)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0114 (131)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P08 (132)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0115 (133)  rf=r size=8 type=uq alias=V0068+0 align=32 words (r5.3)
//.declare V0116 (134)  rf=r size=8 type=uq align=32 words (r32.0)
//.declare V0118 (136)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0119 (137)  rf=r size=256 type=ud alias=V0118+0 align=32 words (r7.0)
//.declare V0120 (138)  rf=r size=8 type=ud alias=V0116+0 align=32 words (r32.0)
//.declare V0121 (139)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0122 (140)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare P09 (142)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0124 (143)  rf=r size=8 type=uq alias=V0070+0 align=32 words (r5.5)
//.declare V0125 (144)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0126 (145)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0127 (146)  rf=r size=4 type=d align=2 words (r2.3)
//.declare P10 (147)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P11 (148)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0128 (149)  rf=r size=64 type=w align=32 words (r28.0)
//.declare V0129 (150)  rf=r size=4 type=d align=2 words (r32.5)
//.declare V0130 (151)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare V0132 (153)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare V0134 (155)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare V0135 (156)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare V0136 (157)  rf=r size=4 type=ud alias=V0129+0 align=2 words (r32.5)
//.declare P12 (158)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0137 (159)  rf=r size=2 type=w align=1 words (r5.0)
//.declare V0138 (160)  rf=r size=2 type=b align=1 words (r6.8)
//.declare V0139 (161)  rf=r size=4 type=d align=2 words (r7.0)
//.declare V0140 (162)  rf=r size=2 type=ub alias=V0138+0 align=1 words (r6.8)
//.declare V0141 (163)  rf=r size=4 type=d align=2 words (r8.0)
//.declare V0142 (164)  rf=r size=4 type=d align=2 words (r32.2)
//.declare V0143 (165)  rf=r size=128 type=d align=32 words (r66.0)
//.declare P13 (166)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0144 (167)  rf=r size=4 type=ud alias=V0100+0 align=2 words (r32.4)
//.declare V0145 (168)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0146 (169)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0147 (170)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0148 (171)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0149 (172)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0150 (173)  rf=r size=4 type=ud alias=V0148+0 align=2 words (r3.4)
//.declare V0151 (174)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0152 (175)  rf=r size=4 type=ud alias=V0151+0 align=2 words (r3.7)
//.declare V0153 (176)  rf=r size=4 type=d align=2 words (r4.1)
//.declare V0154 (177)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0155 (178)  rf=r size=128 type=ud alias=V0143+0 align=32 words (r66.0)
//.declare V0156 (179)  rf=r size=4 type=f align=2 words (r4.2)
//.declare V0157 (180)  rf=r size=4 type=f align=2 words (r6.2)
//.declare V0158 (181)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0159 (182)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0160 (183)  rf=r size=128 type=ud alias=V0159+0 align=32 words (r12.0)
//.declare V0161 (184)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0162 (185)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0163 (186)  rf=r size=128 type=ud alias=V0162+0 align=32 words (r16.0)
//.declare V0164 (187)  rf=r size=4 type=f align=2 words (r2.3)
//.declare V0165 (188)  rf=r size=4 type=ud alias=V0153+0 align=2 words (r4.1)
//.declare V0166 (189)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0167 (190)  rf=r size=128 type=ud alias=V0161+0 align=32 words (r14.0)
//.declare V0168 (191)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0174 (197)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0175 (198)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0176 (199)  rf=r size=128 type=ud alias=V0175+0 align=32 words (r24.0)
//.declare V0177 (200)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0178 (201)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0179 (202)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0180 (203)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0181 (204)  rf=r size=128 type=ud alias=V0179+0 align=32 words (r12.0)
//.declare V0182 (205)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r8.0)
//.declare  (206)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0183 (207)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0184 (208)  rf=r size=4 type=d align=32 words (r1.0)
//.declare V0185 (209)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0186 (210)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0187 (211)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0188 (212)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0189 (213)  rf=r size=64 type=uw alias=V0128+0 align=32 words (r28.0)
//.declare V0190 (214)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0191 (215)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0192 (216)  rf=r size=8 type=q alias=V0044+0 align=32 words (r6.0)
//.declare V0194 (218)  rf=r size=128 type=ud alias=V0191+0 align=32 words (r14.0)
//.declare V0195 (219)  rf=r size=256 type=q align=32 words (r46.0)
//.declare V0196 (220)  rf=r size=256 type=uq alias=V0195+0 align=32 words (r46.0)
//.declare P14 (221)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0197 (222)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0198 (223)  rf=r size=8 type=q alias=V0035+0 align=32 words (r2.2)
//.declare V0202 (227)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0204 (229)  rf=r size=4 type=ud alias=V0202+0 align=2 words (r3.0)
//.declare V0205 (230)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0206 (231)  rf=r size=256 type=q align=32 words (r7.0)
//.declare V0207 (232)  rf=r size=256 type=uq alias=V0206+0 align=32 words (r7.0)
//.declare V0208 (233)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0209 (234)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0210 (235)  rf=r size=256 type=uq alias=V0209+0 align=32 words (r14.0)
//.declare P15 (236)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P16 (237)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0211 (238)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0212 (239)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0213 (240)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0215 (242)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0216 (243)  rf=r size=256 type=q align=32 words (r68.0)
//.declare V0217 (244)  rf=r size=256 type=uq alias=V0216+0 align=32 words (r68.0)
//.declare V0218 (245)  rf=r size=128 type=f align=32 words (r114.0)
//.declare V0219 (246)  rf=r size=4 type=d align=2 words (r3.1)
//.declare P17 (247)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0220 (248)  rf=r size=128 type=f align=32 words (r112.0)
//.declare V0222 (250)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0223 (251)  rf=r size=256 type=q align=32 words (r7.0)
//.declare V0224 (252)  rf=r size=256 type=uq alias=V0223+0 align=32 words (r7.0)
//.declare V0225 (253)  rf=r size=128 type=f align=32 words (r8.0)
//.declare P18 (254)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P19 (255)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0226 (256)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0227 (257)  rf=r size=4 type=f align=2 words (r2.3)
//.declare  (259)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (260)  rf=r size=128 type=f align=32 words (r110.0)
//.declare  (261)  rf=r size=128 type=f align=32 words (r108.0)
//.declare  (262)  rf=r size=128 type=f align=32 words (r106.0)
//.declare  (263)  rf=r size=128 type=f align=32 words (r104.0)
//.declare  (264)  rf=r size=128 type=f align=32 words (r102.0)
//.declare  (265)  rf=r size=128 type=f align=32 words (r100.0)
//.declare  (266)  rf=r size=128 type=f align=32 words (r98.0)
//.declare  (267)  rf=r size=64 type=f align=32 words (r65.0)
//.declare  (268)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0229 (271)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0230 (272)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0231 (273)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0233 (275)  rf=r size=128 type=ud alias=V0231+0 align=32 words (r10.0)
//.declare V0234 (276)  rf=r size=256 type=q align=32 words (r60.0)
//.declare V0235 (277)  rf=r size=256 type=uq alias=V0234+0 align=32 words (r60.0)
//.declare V0236 (278)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (279)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (280)  rf=r size=128 type=f align=32 words (r96.0)
//.declare  (281)  rf=r size=128 type=f align=32 words (r94.0)
//.declare  (282)  rf=r size=128 type=f align=32 words (r92.0)
//.declare  (283)  rf=r size=128 type=f align=32 words (r90.0)
//.declare  (284)  rf=r size=128 type=f align=32 words (r88.0)
//.declare  (285)  rf=r size=64 type=f align=32 words (r38.0)
//.declare V0237 (288)  rf=r size=128 type=d alias=V0236+0 align=32 words (r8.0)
//.declare V0238 (289)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0239 (290)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0240 (291)  rf=r size=128 type=d align=32 words (r38.0)
//.declare P20 (292)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P21 (293)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0241 (294)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0242 (295)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0243 (296)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0244 (297)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0245 (298)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0246 (299)  rf=r size=4 type=f align=2 words (r2.8)
//.declare V0247 (300)  rf=r size=4 type=ud alias=V0243+0 align=2 words (r2.3)
//.declare V0248 (301)  rf=r size=4 type=d align=2 words (r2.9)
//.declare V0249 (302)  rf=r size=4 type=ud alias=V0248+0 align=2 words (r2.9)
//.declare V0250 (303)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0251 (304)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0252 (305)  rf=r size=128 type=ud alias=V0245+0 align=32 words (r12.0)
//.declare V0253 (306)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0254 (307)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0255 (308)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0256 (309)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0257 (310)  rf=r size=128 type=ud alias=V0256+0 align=32 words (r18.0)
//.declare V0258 (311)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0259 (312)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0260 (313)  rf=r size=128 type=ud alias=V0259+0 align=32 words (r10.0)
//.declare V0261 (314)  rf=r size=4 type=f align=2 words (r6.2)
//.declare V0262 (315)  rf=r size=4 type=ud alias=V0250+0 align=2 words (r3.0)
//.declare V0263 (316)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0264 (317)  rf=r size=128 type=ud alias=V0258+0 align=32 words (r20.0)
//.declare V0265 (318)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0271 (324)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0272 (325)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0273 (326)  rf=r size=128 type=ud alias=V0272+0 align=32 words (r28.0)
//.declare V0274 (327)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0275 (328)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0276 (329)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P22 (330)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0277 (331)  rf=r size=128 type=ud alias=V0276+0 align=32 words (r14.0)
//.declare V0278 (332)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0279 (333)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0280 (334)  rf=r size=128 type=f align=32 words (r56.0)
//.declare V0281 (335)  rf=r size=128 type=f alias=V0238+0 align=32 words (r40.0)
//.declare  (336)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (337)  rf=r size=128 type=f align=32 words (r86.0)
//.declare  (338)  rf=r size=128 type=f align=32 words (r84.0)
//.declare  (339)  rf=r size=128 type=f align=32 words (r82.0)
//.declare  (340)  rf=r size=128 type=f align=32 words (r80.0)
//.declare  (341)  rf=r size=128 type=f align=32 words (r78.0)
//.declare  (342)  rf=r size=128 type=f align=32 words (r76.0)
//.declare  (343)  rf=r size=128 type=f align=32 words (r74.0)
//.declare  (344)  rf=r size=128 type=f align=32 words (r72.0)
//.declare V0282 (347)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0283 (348)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0284 (349)  rf=r size=4 type=f align=2 words (r32.2)
//.declare V0285 (350)  rf=r size=4 type=ud alias=V0283+0 align=2 words (r2.3)
//.declare V0286 (351)  rf=r size=128 type=d align=32 words (r58.0)
//.declare P23 (352)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0287 (353)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0288 (354)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0293 (359)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0295 (361)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare V0296 (362)  rf=r size=128 type=w alias=V0295+0 align=32 words (r18.0)
//.declare V0298 (364)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0299 (365)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0300 (366)  rf=r size=128 type=f alias=V0298+0 align=32 words (r20.0)
//.declare V0301 (367)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0306 (372)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0307 (373)  rf=r size=128 type=f align=32 words (r122.0)
//.declare V0311 (377)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0313 (379)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0314 (380)  rf=r size=128 type=w alias=V0313+0 align=32 words (r16.0)
//.declare V0316 (382)  rf=r size=128 type=d alias=V0307+0 align=32 words (r122.0)
//.declare V0318 (384)  rf=r size=128 type=f align=32 words (r116.0)
//.declare V0319 (385)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0320 (386)  rf=r size=128 type=d alias=V0318+0 align=32 words (r116.0)
//.declare P24 (387)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0321 (388)  rf=r size=128 type=ud alias=V0319+0 align=32 words (r8.0)
//.declare V0322 (389)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0323 (390)  rf=r size=128 type=ud alias=V0318+0 align=32 words (r116.0)
//.declare V0324 (391)  rf=r size=128 type=ud alias=V0322+0 align=32 words (r8.0)
//.declare V0325 (392)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0326 (393)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0327 (394)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0328 (395)  rf=r size=128 type=ud alias=V0326+0 align=32 words (r12.0)
//.declare V0329 (396)  rf=r size=128 type=ud alias=V0327+0 align=32 words (r14.0)
//.declare V0330 (397)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0331 (398)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0332 (399)  rf=r size=128 type=ud alias=V0331+0 align=32 words (r8.0)
//.declare V0336 (403)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0337 (404)  rf=r size=64 type=uw alias=V0330+0 align=32 words (r1.0)
//.declare V0338 (405)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P25 (406)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P26 (407)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P27 (408)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0340 (410)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0341 (411)  rf=r size=256 type=ud alias=V0340+0 align=32 words (r7.0)
//.declare V0342 (412)  rf=r size=128 type=d align=32 words (r12.0)
//.declare  (413)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (414)  rf=r size=128 type=w alias=V0331+0 align=32 words (r8.0)
//.declare  (415)  rf=r size=4 type=ud align=32 words (r3.0)
//.declare  (416)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (417)  rf=r size=128 type=uw align=32 words (r9.0)
//.declare  (418)  rf=r size=2 type=w align=1 words (r2.16)
//.declare  (419)  rf=r size=4 type=d align=2 words (r3.0)
//.declare  (420)  rf=r size=2 type=w align=1 words (r4.0)
//.declare  (423)  rf=r size=4 type=f align=2 words (r5.0)
//.declare  (424)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (425)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (426)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (427)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (428)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (429)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (430)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (431)  rf=r size=4 type=f align=2 words (r3.4)
//.declare  (432)  rf=r size=4 type=d align=2 words (r4.0)
//.declare  (434)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (435)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (436)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (437)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (438)  rf=r size=128 type=w alias=V0327+0 align=32 words (r14.0)
//.declare  (441)  rf=r size=128 type=q align=32 words (r33.0)
//.declare  (442)  rf=r size=128 type=q align=32 words (r29.0)
//.declare  (449)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (450)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (451)  rf=r size=128 type=q align=32 words (r26.0)
//.declare  (452)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (457)  rf=r size=128 type=q align=32 words (r126.0)
//.declare  (458)  rf=r size=128 type=q align=32 words (r124.0)
//.declare  (461)  rf=r size=128 type=q align=32 words (r120.0)
//.declare  (462)  rf=r size=128 type=q align=32 words (r118.0)
//.declare  (463)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (464)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (467)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (468)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (473)  rf=r size=128 type=d alias=+0 align=32 words (r33.0)
//.declare  (474)  rf=r size=128 type=d alias=+0 align=32 words (r29.0)
//.declare  (475)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (476)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (477)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (478)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (479)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (480)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (481)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (482)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (483)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (484)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (485)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (486)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (487)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (488)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (489)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (490)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (491)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (492)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (493)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (494)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (495)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (496)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (497)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (498)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (499)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (500)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (501)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (502)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (503)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (504)  rf=r size=64 type=d align=32 words (r31.0)
//.declare r0 (505)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (506)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (507)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (508)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (509)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (510)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (511)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (512)  rf=r size=32 type=ud align=2 words (r6.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0039    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0035    | :uq      |    0x8 | r2+0x10  | inline+0x10      |
// | V0034    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0045    | :d       |    0x4 | r3       | cti+0x20         |
// | V0046    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0047    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0048    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0049    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0050    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0051    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0052    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0053    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0054    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0055    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0056    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0057    | :q       |    0x8 | r4       | cti+0x60         |
// | V0058    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0059    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0060    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0061    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0062    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0063    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0064    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0065    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0066    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0067    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0068    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0069    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0070    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0071    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// | V0043    | :uq      |    0x8 | r5+0x38  | cti+0xD8         |
// | V0044    | :uq      |    0x8 | r6       | cti+0xE0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xE0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r6:1  bti[255][r127:1+0xC0]  {$3} // ex_desc:0xFF0C0000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B049}
// _main:
(W)     mov (16|M0)              r52.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r38.0<1>:f    0x3F000000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r64.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r65.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r52.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r3.0<1>:ud    r2.0<0;1,0>:ud    r52.1<0;1,0>:ud  {Compacted,$1.dst} //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r52.2<0;1,0>:uw                     //  ALU pipe: int; $4
(W)     mach (1|M0)              r4.0<1>:d     r2.0<0;1,0>:ud    r52.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r9.0<4>:uw    r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.10<2>:ud   r3.0<0;1,0>:ud                   {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.11<2>:d    r4.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r2.8<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r33.0<1>:q    r2.5<0;1,0>:q     r7.0<4;1,0>:uw   {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r29.0<1>:q    r2.5<0;1,0>:q     r9.0<4;1,0>:uw                      //  ALU pipe: int; $10
        mov (16|M0)              r44.0<1>:d    r33.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $11
        mov (16|M16)             r45.0<1>:d    r29.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $12
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r44.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $15
        mov (16|M0)              r42.0<1>:d    r33.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $13
        mov (16|M16)             r43.0<1>:d    r29.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $14
(f2.0)  cmp (32|M0)   (eq)f2.0   null<1>:d     r42.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $16
(~f2.0) cmp (32|M0)   (lt)f2.0   null<1>:ud    r42.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $18
(~f2.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $20
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B049}
_0_050:
(W)     cmp (1|M0)    (lt)f0.0   null<1>:d     r3.2<0;1,0>:d     -3:w               {Compacted}      //  ALU pipe: int; $24
(W)     mov (1|M0)               r2.16<1>:hf   0x6:hf                                                //  ALU pipe: float; $25
(W)     mul (1|M0)               acc0.0<1>:d   r3.3<0;1,0>:d     r3.2<0;1,0>:uw                      //  ALU pipe: int; $22
(W)     macl (1|M0)              r3.0<1>:d     r3.3<0;1,0>:d     r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $23
(W&f0.0) sel (1|M0)              r3.8<1>:w     r2.16<0;1,0>:w    3:w               {F@1}             //  ALU pipe: int; $25
(W)     asr (1|M0)               r2.3<1>:d     r3.0<0;1,0>:d     31:w               {I@2}            //  ALU pipe: int; $23
(W)     mov (1|M0)               r4.0<2>:b     r3.8<0;1,0>:w                    {I@2}                //  ALU pipe: int; $26
(W)     mov (1|M0)               r5.0<1>:d     r4.0<0;1,0>:ub                   {@1,$2.dst}          //  ALU pipe: int; $27
(W)     add (1|M0)               r32.4<1>:d    r5.0<0;1,0>:d     r3.2<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $28
(W)     asr (1|M0)               r32.3<1>:d    r32.4<0;1,0>:d    2:w               {I@1}             //  ALU pipe: int; $29
(W)     asr (1|M0)               r6.2<1>:d     r32.3<0;1,0>:d    31:w               {@1,$3.dst}      //  ALU pipe: int; $30
(W)     mul (1|M0)               acc0.0<1>:ud  r3.0<0;1,0>:ud    r32.6<0;1,0>:uw                     //  ALU pipe: int; $31
(W)     macl (1|M0)              r7.0<1>:ud    r3.0<0;1,0>:ud    r32.3<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $32
(W)     mul (1|M0)               acc0.0<1>:ud  r3.0<0;1,0>:ud    r32.6<0;1,0>:uw                     //  ALU pipe: int; $32
(W)     mach (1|M0)              r8.0<1>:d     r3.0<0;1,0>:ud    r32.3<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r3.0<0;1,0>:ud    r6.4<0;1,0>:uw   {I@5}              //  ALU pipe: int; $33
(W)     macl (1|M0)              r9.0<1>:d     r3.0<0;1,0>:ud    r6.2<0;1,0>:d                       //  ALU pipe: int; $34
(W)     mul (1|M0)               acc0.0<1>:d   r32.3<0;1,0>:ud   r2.6<0;1,0>:uw                      //  ALU pipe: int; $35
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r44.0<1;1,0>:ud   r7.0<0;1,0>:ud   {I@6}              //  ALU pipe: int; $38
(W)     add (1|M0)               r8.0<1>:d     r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@3}    //  ALU pipe: int; $34
(W)     macl (1|M0)              r9.0<1>:d     r32.3<0;1,0>:ud   r2.3<0;1,0>:d                       //  ALU pipe: int; $37
(W)     add (1|M0)               r4.0<1>:d     r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $37
(f1.0)  cmp (32|M0)   (eq)f1.0   null<1>:d     r42.0<1;1,0>:d    r4.0<0;1,0>:d    {I@1}              //  ALU pipe: int; $39
(~f1.0) cmp (32|M0)   (lt)f1.0   null<1>:ud    r42.0<1;1,0>:ud   r4.0<0;1,0>:ud                      //  ALU pipe: int; $41
(~f1.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $43
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B049}
_0_051:
(W)     mov (1|M0)               r4.0<1>:uq    r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $45
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$4} // ex_desc:0x0; desc:0x2108580 // $46
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$4.dst}          //  ALU pipe: int; $47
(f3.0)  goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $48
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B049}
_0_052:
(W)     mov (1|M0)               r32.0<1>:uq   r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $50
        mov (32|M0)              r12.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $53
        mov (16|M0)              r7.0<2>:f     r32.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $51
        mov (16|M16)             r9.0<2>:f     r32.0<0;1,0>:f                                        //  ALU pipe: float; $51
        mov (16|M0)              r7.1<2>:f     r32.1<0;1,0>:f                                        //  ALU pipe: float; $52
        mov (16|M16)             r9.1<2>:ud    r32.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $52
        atomic_or.ugm.d32.a64 (32|M0)  r14:2    [r7:4]            r12:2              {A@1,$5} // ex_desc:0x0; desc:0x8200599 // $54
        cmp (32|M0)   (eq)f2.0   null<1>:d     r14.0<1;1,0>:d    0:w               {$5.dst}          //  ALU pipe: int; $56
(~f2.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $57
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B047}
_0_053:
(W)     mov (1|M0)               r4.0<1>:uq    r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $59
(W)     add (1|M0)               r2.3<1>:d     r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $61
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$6} // ex_desc:0x0; desc:0x2108580 // $60
(W)     cmp (32|M0)   (gt)f0.0   null<1>:d     r3.0<0;1,0>:d     r2.3<0;1,0>:d    {$6.dst}           //  ALU pipe: int; $62
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $63
(W&f0.0) jmpi                                _0_054                                                  //  ALU pipe: int; $65
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B009}
_0_055:
(W)     mov (8|M0)               r28.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $67
(W)     and (1|M0)               r2.3<1>:ud    msg0.0<0;1,0>:ud  0xFF:uw                             //  ALU pipe: int; $70
(W)     add (8|M0)               r28.8<1>:w    r28.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $68
(W)     add (16|M0)              r28.16<1>:w   r28.0<1;1,0>:w    16:w               {I@1}            //  ALU pipe: int; $69
(W)     and (1|M0)               r2.8<1>:ud    sr0.0<0;1,0>:ud   0x7F:uw              {A@1}          //  ALU pipe: int; $71
(W)     cmp (1|M0)    (lt)f3.0   null<1>:d     r3.2<0;1,0>:d     -31:w               {A@1}           //  ALU pipe: int; $78
(W)     mov (1|M0)               r4.0<1>:hf    0x3E:hf                                               //  ALU pipe: float; $79
(W)     and (1|M0)               r2.9<1>:ud    r2.8<0;1,0>:ud    7:w               {I@2}             //  ALU pipe: int; $73
(W)     asr (1|M0)               r2.10<1>:ud   r2.8<0;1,0>:ud    1:w                                 //  ALU pipe: int; $74
(W&f3.0) sel (1|M0)              r5.0<1>:w     r4.0<0;1,0>:w     31:w               {F@1}            //  ALU pipe: int; $79
(W)     mov (1|M0)               r3.0<1>:d     -8:w                               {Compacted}        //  ALU pipe: int; $75
(W)     mov (1|M0)               r6.8<2>:b     r5.0<0;1,0>:w                    {I@2}                //  ALU pipe: int; $80
(W)     shl (1|M0)               r2.3<1>:ud    r2.3<0;1,0>:ud    0x6:uw                              //  ALU pipe: int; $72
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r32.4<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $85
(W)     bfn.(s0&s1|s2) (1|M0)    r2.8<1>:ud    r2.10<0;0>:ud     r3.0<0;0>:ud      r2.9<0>:ud       {I@4} //  ALU pipe: int; $75
(W)     mov (1|M0)               r7.0<1>:d     r6.8<0;1,0>:ub                   {I@4}                //  ALU pipe: int; $81
(W)     or (1|M0)                r2.3<1>:ud    r2.3<0;1,0>:ud    r2.8<0;1,0>:ud   {I@2}              //  ALU pipe: int; $76
(W)     add (1|M0)               r8.0<1>:d     r7.0<0;1,0>:d     r3.2<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $82
        mov (16|M0)              r66.0<1>:d    r33.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $84
        mov (16|M16)             r67.0<1>:d    r29.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $84
(W)     mov (1|M0)               r32.5<1>:ud   r2.3<0;1,0>:ud                   {I@4}                //  ALU pipe: int; $77
(W)     asr (1|M0)               r32.2<1>:d    r8.0<0;1,0>:d     5:w               {Compacted,I@4}   //  ALU pipe: int; $83
(W&~f1.0) jmpi                               _0_056                                                  //  ALU pipe: int; $86
// B008: [inDivergent],  Preds:{B007},  Succs:{B010}
_0_057:
        mov (32|M0)              r36.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $88
(W)     jmpi                                 _0_058                                                  // $89
// B009: [inDivergent],  Preds:{B007},  Succs:{B010}
_0_056:
(W)     asr (1|M0)               r3.0<1>:d     r32.4<0;1,0>:d    31:w               {Compacted}      //  ALU pipe: int; $91
(W)     add (1|M0)               r2.3<1>:d     r3.0<0;1,0>:d     r32.3<0;1,0>:d   {I@1}              //  ALU pipe: int; $92
(W)     xor (1|M0)               r3.4<1>:d     r2.3<0;1,0>:d     r3.0<0;1,0>:d    {I@1}              //  ALU pipe: int; $93
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $94
(W)     mov (1|M0)               r4.0<1>:f     r3.4<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $95
(W)     mov (1|M0)               r5.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $100
(W)     math.inv (1|M0)          r4.2<1>:f     r4.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $99
        mov (32|M0)              r8.0<1>:f     r66.0<1;1,0>:ud                                       //  ALU pipe: float; $98
(W)     mad (1|M0)               r6.2<1>:f     r4.2<0;0>:f       r5.0<0;0>:f       r4.2<0>:f        {A@1} //  ALU pipe: float; $100
        mov (32|M0)              r12.0<1>:ud   r8.0<1;1,0>:f                    {F@2}                //  ALU pipe: int; $102
        mul (32|M0)              r10.0<1>:f    r8.0<1;1,0>:f     r6.2<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $101
(W)     mov (1|M0)               r3.7<1>:ud    r4.0<0;1,0>:f                                         //  ALU pipe: int; $96
        add (32|M0)              r14.0<1>:d    r66.0<1;1,0>:d    -r12.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $103
        mov (32|M0)              r16.0<1>:ud   r10.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $104
(W)     add (1|M0)               r4.1<1>:d     r3.4<0;1,0>:d     -r3.7<0;1,0>:d   {I@3}              //  ALU pipe: int; $97
        mov (32|M0)              r20.0<1>:f    r16.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $107
        mov (32|M0)              r18.0<1>:f    r14.0<1;1,0>:ud                                       //  ALU pipe: float; $106
(W)     mov (1|M0)               r2.3<1>:f     r4.1<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $105
        mad (32|M0)              acc0.0<1>:f   r8.0<1;0>:f       r20.0<1;0>:f      -r4.0<0>:f       {F@3} //  ALU pipe: float; $109 R{} IR{}{E:4,E:2,E:2,},  R{r4,} IR{}{O:4,O:10,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r18.0<1;0>:f      r20.0<1;0>:f      -r2.3<0>:f       {F@2} //  ALU pipe: float; $111 R{} IR{}{E:1,E:2,E:1,},  R{r2,} IR{}{O:9,O:10,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $112
        mul (32|M0)              r22.0<1>:f    r6.2<0;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $113
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $114
        mov (32|M0)              r24.0<1>:ud   r22.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $115
        add (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    r16.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $116
(W)     mul (16|M0)              acc0.0<1>:d   r26.0<1;1,0>:d    r3.8<0;1,0>:uw   {I@1}              //  ALU pipe: int; $117
        macl (16|M0)             r10.0<1>:d    r26.0<1;1,0>:d    r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $117
(W)     mul (16|M16)             acc0.0<1>:d   r27.0<1;1,0>:d    r3.8<0;1,0>:uw                      //  ALU pipe: int; $117
        macl (16|M16)            r11.0<1>:d    r27.0<1;1,0>:d    r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $118
        add (32|M0)              r12.0<1>:d    r66.0<1;1,0>:d    -r10.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $118
        cmp (32|M0)   (ge)f1.0   r8.0<1>:ud    r12.0<1;1,0>:ud   r3.4<0;1,0>:ud   {I@1}              //  ALU pipe: int; $119
        add3 (32|M0)             r14.0<1>:d    r26.0<1;0>:d      r3.0<0;0>:d       -r8.0<1>:d       {I@1} //  ALU pipe: int; $120
        xor (32|M0)              r36.0<1>:d    r14.0<1;1,0>:d    r3.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $121
// B010: [inDivergent],  Preds:{B009, B008},  Succs:{B011, B013}
_0_058:
(W)     mul (1|M0)               acc0.0<1>:d   r32.5<0;1,0>:d    0x80:uw                             //  ALU pipe: int; $123
        mov (32|M0)              r50.0<1>:d    r28.0<1;1,0>:uw                                       //  ALU pipe: int; $127
(W)     macl (1|M0)              r1.0<1>:d     r32.5<0;1,0>:d    65664:d                             //  ALU pipe: int; $124
(W)     mul (16|M0)              acc0.0<1>:d   r36.0<1;1,0>:d    r32.6<0;1,0>:uw  {I@4}              //  ALU pipe: int; $124
        shl (32|M0)              r12.0<1>:d    r50.0<1;1,0>:d    11:w               {Compacted,I@3}  //  ALU pipe: int; $128
        macl (16|M0)             r8.0<1>:d     r36.0<1;1,0>:d    r32.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $124
(W)     mul (16|M16)             acc0.0<1>:d   r37.0<1;1,0>:d    r32.6<0;1,0>:uw                     //  ALU pipe: int; $124
(W)     mov (1|M0)               r3.0<1>:hf    0x80:hf                                               //  ALU pipe: float; $129
        macl (16|M16)            r9.0<1>:d     r37.0<1;1,0>:d    r32.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $125
        add3 (32|M0)             r14.0<1>:d    r1.0<0;0>:d       r3.0<0;0>:w       r12.0<1>:d       {A@1} //  ALU pipe: int; $129
        add (32|M0)              r10.0<1>:d    r66.0<1;1,0>:d    -r8.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $125
(W)     cmp (32|M0)   (gt)f0.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $132
        mov (16|M0)              r16.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted,I@3}      //  ALU pipe: int; $131
        mov (16|M16)             r18.0<2>:ud   r15.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $131
        shl (32|M0)              r34.0<1>:d    r10.0<1;1,0>:d    2:w               {Compacted,I@4}   //  ALU pipe: int; $126
        add (16|M0)              r46.0<1>:q    r6.0<0;1,0>:q     r16.0<2;1,0>:ud  {I@3}              //  ALU pipe: int; $131
        add (16|M16)             r48.0<1>:q    r6.0<0;1,0>:q     r18.0<2;1,0>:ud  {I@3}              //  ALU pipe: int; $131
(W&~f0.0) jmpi                               _0_059                                                  //  ALU pipe: int; $133
// B011: [inDivergent],  Preds:{B010},  Succs:{B012}
_0_060:
(W)     mul (16|M0)              acc0.0<1>:d   r36.0<1;1,0>:d    r32.4<0;1,0>:uw                     //  ALU pipe: int; $135
        macl (16|M0)             r8.0<1>:d     r36.0<1;1,0>:d    r32.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $135
(W)     mul (16|M16)             acc0.0<1>:d   r37.0<1;1,0>:d    r32.4<0;1,0>:uw                     //  ALU pipe: int; $135
        macl (16|M16)            r9.0<1>:d     r37.0<1;1,0>:d    r32.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $137
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@3}      //  ALU pipe: int; $137
        mov (16|M16)             r14.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $137
        shl (16|M0)              r12.0<1>:q    r10.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $137
        shl (16|M16)             r16.0<1>:q    r14.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $137
        add (16|M0)              r26.0<1>:q    r12.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $138
        add (16|M16)             r24.0<1>:q    r16.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $138
(W)     mov (1|M0)               r3.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $139
// B012: [inDivergent],  Preds:{B012, B011},  Succs:{B013, B012}
_0_061:
(W)     shl (1|M0)               r2.4<1>:q     r3.0<0;1,0>:ud    2:w               {I@1}             //  ALU pipe: int; $142
(W)     add (1|M0)               r3.0<1>:d     r3.0<0;1,0>:d     1:w               {Compacted}       //  ALU pipe: int; $147
        add (16|M0)              r7.0<1>:q     r26.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $143
        add (16|M16)             r9.0<1>:q     r24.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $143
        load.ugm.d32.a64 (32|M0)  r12:2         [r7:4]             {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $144
        add (16|M0)              r14.0<1>:q    r46.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,$7.src} //  ALU pipe: int; $145
        add (16|M16)             r16.0<1>:q    r48.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $145
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.0<0;1,0>:d     r32.2<0;1,0>:d                      //  ALU pipe: int; $148
        sync.nop                             null                             {Compacted,$8.dst}     // $146
        store.ugm.d32.a64.wb.wb (32|M0)  [r14:4] r12:2             {I@2,$7} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $146
(W&f3.0) jmpi                                _0_061                                                  //  ALU pipe: int; $149
// B013: [inDivergent],  Preds:{B012, B010},  Succs:{B014, B022}
_0_059:
(W)     cmp (32|M0)   (gt)f3.0   null<1>:d     r3.2<0;1,0>:d     32:w                                //  ALU pipe: int; $151
(W&~f3.0) jmpi                               _0_062                                                  //  ALU pipe: int; $152
// B014: [inDivergent],  Preds:{B013},  Succs:{B015}
_0_063:
(W)     mov (1|M0)               r3.6<1>:d     1:w                                                   //  ALU pipe: int; $154
// B015: [inDivergent],  Preds:{B021, B014},  Succs:{B016}
_0_064:
(W)     shl (1|M0)               r3.4<1>:d     r3.6<0;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $156
(W)     mov (1|M0)               r3.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $157
// B016: [inDivergent],  Preds:{B019, B015},  Succs:{B017, B018}
_0_065:
(W)     shl (1|M0)               r2.4<1>:q     r3.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $160
(W)     add (1|M0)               r3.1<1>:d     r3.0<0;1,0>:d     r3.6<0;1,0>:d    {Compacted}        //  ALU pipe: int; $163
        add (16|M0)              r68.0<1>:q    r46.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,@2,$9.src} //  ALU pipe: int; $161
        add (16|M16)             r70.0<1>:q    r48.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $161
        load.ugm.d32.a64.ca.ca (32|M0)  r114:2  [r68:4]            {I@1,$10} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $162
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.1<0;1,0>:d     r32.2<0;1,0>:d                      //  ALU pipe: int; $164
(W&f1.0) jmpi                                _0_066                                                  //  ALU pipe: int; $165
// B017: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_067:
        mov (32|M0)              r112.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $167
(W)     jmpi                                 _0_068                                                  // $168
// B018: [inDivergent],  Preds:{B016},  Succs:{B019}
_0_066:
(W)     shl (1|M0)               r2.4<1>:q     r3.1<0;1,0>:d     2:w                                 //  ALU pipe: int; $171
        add (16|M0)              r7.0<1>:q     r46.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $172
        add (16|M16)             r9.0<1>:q     r48.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $172
        load.ugm.d32.a64.ca.ca (32|M0)  r112:2  [r7:4]             {I@1,$11} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $173
// B019: [inDivergent],  Preds:{B018, B017},  Succs:{B020, B016}
_0_068:
        sync.nop                             null                             {Compacted,$11.dst}    // $175
        add (32|M0)              r8.0<1>:f     r114.0<1;1,0>:f   r112.0<1;1,0>:f  {Compacted,$10.dst} //  ALU pipe: float; $175
(W)     add (1|M0)               r3.0<1>:d     r3.0<0;1,0>:d     r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $177
        store.ugm.d32.a64.wb.wb (32|M0)  [r68:4] r8:2              {F@1,$9} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $176
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.0<0;1,0>:d     r32.2<0;1,0>:d   {I@1}              //  ALU pipe: int; $178
(W&f0.0) jmpi                                _0_065                                                  //  ALU pipe: int; $179
// B020: [inDivergent],  Preds:{B019},  Succs:{B021, B022}
_0_069:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r3.4<0;1,0>:d     r32.2<0;1,0>:d                      //  ALU pipe: int; $181
(W&~f2.0) jmpi                               _0_062                                                  //  ALU pipe: int; $182
// B021: [inDivergent],  Preds:{B020},  Succs:{B015}
_0_070:
(W)     mov (1|M0)               r3.6<1>:d     r3.4<0;1,0>:d                                         //  ALU pipe: int; $184
(W)     jmpi                                 _0_064                                                  // $185
// B022: [inDivergent],  Preds:{B020, B013},  Succs:{B023, B024}
_0_062:
        load.ugm.d32.a64.ca.ca (32|M0)  r4:2    [r46:4]            {$12} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $187
(W)     mov (1|M0)               r2.3<1>:f     r3.2<0;1,0>:d                                         //  ALU pipe: float; $188
(W)     mov (1|M0)               f0.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $189
        mov (32|M0)              r108.0<1>:f   r2.3<0;1,0>:f                    {Compacted,F@1}      //  ALU pipe: float; $189
        math.invm (16|M0) (eo)f0.0  r104.mme0:f  r4.nomme<1;1,0>:f  r108.nomme<1;1,0>:f {A@1,$12.dst} //  ALU pipe: math; $189
(f0.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $189
// B023: [inDivergent],  Preds:{B022},  Succs:{B024}
_L_k0_6_:
        madm (16|M0)             r102.mme1:f   r65.nomme:f       r4.nomme:f        r104.mme0:f      {M@1} //  ALU pipe: float; $189
        madm (16|M0)             r100.mme2:f   r64.nomme:f       -r108.nomme:f     r104.mme0:f       //  ALU pipe: float; $189
        madm (16|M0)             r110.mme3:f   r104.mme0:f       r100.mme2:f       r104.mme0:f      {F@1} //  ALU pipe: float; $189
        madm (16|M0)             r98.mme4:f    r4.nomme:f        -r108.nomme:f     r102.mme1:f       //  ALU pipe: float; $189 R{} IR{}{E:2,E:6,E:3,},  {BC=1}
        madm (16|M0)             r102.mme5:f   r102.mme1:f       r98.mme4:f        r110.mme3:f      {F@1} //  ALU pipe: float; $189 R{} IR{}{E:3,E:1,E:7,},  {BC=1}
        madm (16|M0)             r106.mme6:f   r4.nomme:f        -r108.nomme:f     r102.mme5:f      {F@1} //  ALU pipe: float; $189 R{} IR{}{E:2,E:6,E:3,},  {BC=1}
        madm (16|M0)             r104.nomme:f  r102.mme5:f       r106.mme6:f       r110.mme3:f      {F@1} //  ALU pipe: float; $189 R{} IR{}{E:3,E:5,E:7,},  {BC=1}
// B024: [inDivergent],  Preds:{B023, B022},  Succs:{B025, B026}
_L_k0_0_macro:
        join (32|M0)                         _0_049                                                  // 
L3000:
(W)     mov (1|M0)               f0.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $189
        math.invm (16|M16) (eo)f0.0  r105.mme0:f  r5.nomme<1;1,0>:f  r109.nomme<1;1,0>:f {I@1}       //  ALU pipe: math; $189
(f0.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $189
// B025: [inDivergent],  Preds:{B024},  Succs:{B026}
_L_k0_7_:
        madm (16|M16)            r103.mme1:f   r65.nomme:f       r5.nomme:f        r105.mme0:f      {M@1} //  ALU pipe: float; $189 R{} IR{}{O:0,O:2,O:4,},  {BC=1}
        madm (16|M16)            r101.mme2:f   r64.nomme:f       -r109.nomme:f     r105.mme0:f       //  ALU pipe: float; $189
        madm (16|M16)            r111.mme3:f   r105.mme0:f       r101.mme2:f       r105.mme0:f      {F@1} //  ALU pipe: float; $189
        madm (16|M16)            r99.mme4:f    r5.nomme:f        -r109.nomme:f     r103.mme1:f       //  ALU pipe: float; $189 R{} IR{}{O:2,O:6,O:3,},  {BC=1}
        madm (16|M16)            r103.mme5:f   r103.mme1:f       r99.mme4:f        r111.mme3:f      {F@1} //  ALU pipe: float; $189 R{} IR{}{O:3,O:1,O:7,},  {BC=1}
        madm (16|M16)            r107.mme6:f   r5.nomme:f        -r109.nomme:f     r103.mme5:f      {F@1} //  ALU pipe: float; $189 R{} IR{}{O:2,O:6,O:3,},  {BC=1}
        madm (16|M16)            r105.nomme:f  r103.mme5:f       r107.mme6:f       r111.mme3:f      {F@1} //  ALU pipe: float; $189 R{} IR{}{O:3,O:5,O:7,},  {BC=1}
// B026: [inDivergent],  Preds:{B025, B024},  Succs:{B027, B028}
_L_k0_1_macro:
        join (32|M0)                         _0_049                                                  // 
L3176:
        shl (32|M0)              r8.0<1>:d     r50.0<1;1,0>:d    2:w               {Compacted,$9.src} //  ALU pipe: int; $191
        add (32|M0)              r10.0<1>:d    r1.0<0;1,0>:d     r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $192
        add (32|M0)              r20.0<1>:f    r104.0<1;1,0>:f   0x358637BD:f               {F@1}    //  ALU pipe: float; $190
        mov (16|M0)              r12.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted,@1,$7.src} //  ALU pipe: int; $194
        mov (16|M16)             r14.0<2>:ud   r11.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $194
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $195
        add (16|M0)              r60.0<1>:q    r6.0<0;1,0>:q     r12.0<2;1,0>:ud  {I@3}              //  ALU pipe: int; $194
        add (16|M16)             r62.0<1>:q    r6.0<0;1,0>:q     r14.0<2;1,0>:ud  {I@3}              //  ALU pipe: int; $194
        math.rsqtm (16|M0) (eo)f3.0  r94.mme0:f  r20.nomme<1;1,0>:f             {A@1}                //  ALU pipe: math; $195
(f3.0)  goto (32|M0)                         _L_k0_2_macro     _L_k0_2_macro                         //  ALU pipe: int; $195
// B027: [inDivergent],  Preds:{B026},  Succs:{B028}
_L_k0_8_:
        madm (16|M0)             r92.mme1:f    r65.nomme:f       r38.nomme:f       r94.mme0:f       {M@1} //  ALU pipe: float; $195
        madm (16|M0)             r88.mme2:f    r65.nomme:f       r20.nomme:f       r94.mme0:f        //  ALU pipe: float; $195
        madm (16|M0)             r90.mme3:f    r38.nomme:f       -r88.mme2:f       r92.mme1:f       {F@1} //  ALU pipe: float; $195 R{} IR{}{E:3,E:4,E:6,},  {BC=1}
        madm (16|M0)             r92.mme4:f    r92.mme1:f        r90.mme3:f        r92.mme1:f       {F@1} //  ALU pipe: float; $195
        madm (16|M0)             r94.mme5:f    r88.mme2:f        r90.mme3:f        r88.mme2:f        //  ALU pipe: float; $195
        madm (16|M0)             r90.mme6:f    r20.nomme:f       -r94.mme5:f       r94.mme5:f       {F@1} //  ALU pipe: float; $195
        madm (16|M0)             r94.nomme:f   r94.mme5:f        r92.mme4:f        r90.mme6:f       {F@1} //  ALU pipe: float; $195 R{} IR{}{E:7,E:6,E:5,},  {BC=1}
// B028: [inDivergent],  Preds:{B027, B026},  Succs:{B029, B030}
_L_k0_2_macro:
        join (32|M0)                         _0_049                                                  // 
L3432:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $195
        math.rsqtm (16|M16) (eo)f3.0  r95.mme0:f  r21.nomme<1;1,0>:f            {I@1}                //  ALU pipe: math; $195
(f3.0)  goto (32|M0)                         _L_k0_3_macro     _L_k0_3_macro                         //  ALU pipe: int; $195
// B029: [inDivergent],  Preds:{B028},  Succs:{B030}
_L_k0_9_:
        madm (16|M16)            r93.mme1:f    r65.nomme:f       r38.nomme:f       r95.mme0:f       {M@1} //  ALU pipe: float; $195
        madm (16|M16)            r89.mme2:f    r65.nomme:f       r21.nomme:f       r95.mme0:f        //  ALU pipe: float; $195
        madm (16|M16)            r91.mme3:f    r38.nomme:f       -r89.mme2:f       r93.mme1:f       {F@1} //  ALU pipe: float; $195
        madm (16|M16)            r93.mme4:f    r93.mme1:f        r91.mme3:f        r93.mme1:f       {F@1} //  ALU pipe: float; $195
        madm (16|M16)            r95.mme5:f    r89.mme2:f        r91.mme3:f        r89.mme2:f        //  ALU pipe: float; $195
        madm (16|M16)            r91.mme6:f    r21.nomme:f       -r95.mme5:f       r95.mme5:f       {F@1} //  ALU pipe: float; $195
        madm (16|M16)            r95.nomme:f   r95.mme5:f        r93.mme4:f        r91.mme6:f       {F@1} //  ALU pipe: float; $195 R{} IR{}{O:7,O:6,O:5,},  {BC=1}
// B030: [inDivergent],  Preds:{B029, B028},  Succs:{B031, B049}
_L_k0_3_macro:
        join (32|M0)                         _0_049                                                  // 
L3608:
        mov (32|M0)              r8.0<1>:f     r94.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $195
        store.ugm.d32.a64.wb.wb (32|M0)  [r60:4] r8:2              {F@1,$13} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $196
        add (32|M0)              r10.0<1>:d    r34.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $198
        sel (32|M0)   (lt)f0.0   r38.0<1>:d    r10.0<1;1,0>:d    r3.2<0;1,0>:d    {I@1}              //  ALU pipe: int; $199
        cmp (32|M0)   (lt)f2.0   null<1>:d     r34.0<1;1,0>:d    r38.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $200
        load.ugm.d32.a64.ca.ca (32|M0)  r40:2   [r60:4]            {$14} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $197
(~f2.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $201
// B031: [inDivergent],  Preds:{B030},  Succs:{B032, B033}
_0_071:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.3<0;1,0>:d     0:w                                 //  ALU pipe: int; $203
(W&~f1.0) jmpi                               _0_072                                                  //  ALU pipe: int; $204
// B032: [inDivergent],  Preds:{B031},  Succs:{B034}
_0_073:
        mov (32|M0)              r22.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $206
(W)     jmpi                                 _0_074                                                  // $207
// B033: [inDivergent],  Preds:{B031},  Succs:{B034}
_0_072:
        asr (32|M0)              r8.0<1>:d     r36.0<1;1,0>:d    31:w               {Compacted,$13.src} //  ALU pipe: int; $209
        add (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     r36.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $211
        xor (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $212
(W)     mov (1|M0)               r2.3<1>:d     (abs)r3.3<0;1,0>:d                                    //  ALU pipe: int; $210
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $213
(W)     mov (1|M0)               r2.8<1>:f     r2.3<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $214
(W)     mov (1|M0)               r3.4<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $219
(W)     math.inv (1|M0)          r4.0<1>:f     r2.8<0;1,0>:f                    {F@2}                //  ALU pipe: math; $218
        mov (32|M0)              r14.0<1>:f    r12.0<1;1,0>:ud                                       //  ALU pipe: float; $217
(W)     mad (1|M0)               r5.0<1>:f     r4.0<0;0>:f       r3.4<0;0>:f       r4.0<0>:f        {A@1} //  ALU pipe: float; $219
        mov (32|M0)              r18.0<1>:ud   r14.0<1;1,0>:f                   {F@2}                //  ALU pipe: int; $221
        mul (32|M0)              r16.0<1>:f    r14.0<1;1,0>:f    r5.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $220
(W)     mov (1|M0)               r2.9<1>:ud    r2.8<0;1,0>:f                                         //  ALU pipe: int; $215
        add (32|M0)              r20.0<1>:d    r12.0<1;1,0>:d    -r18.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $222
        mov (32|M0)              r10.0<1>:ud   r16.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $223
(W)     add (1|M0)               r3.0<1>:d     (abs)r3.3<0;1,0>:d  -r2.9<0;1,0>:d {I@3}              //  ALU pipe: int; $216
        mov (32|M0)              r24.0<1>:f    r10.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $226
        mov (32|M0)              r22.0<1>:f    r20.0<1;1,0>:ud                                       //  ALU pipe: float; $225
(W)     mov (1|M0)               r6.2<1>:f     r3.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $224
        mad (32|M0)              acc0.0<1>:f   r14.0<1;0>:f      r24.0<1;0>:f      -r2.8<0>:f       {F@3} //  ALU pipe: float; $228 R{} IR{}{E:7,E:4,E:1,},  R{r2,} IR{}{O:7,O:12,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r22.0<1;0>:f      r24.0<1;0>:f      -r6.2<0>:f       {F@2} //  ALU pipe: float; $230 R{} IR{}{E:3,E:4,E:3,},  R{r6,} IR{}{O:11,O:12,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $231
        mul (32|M0)              r26.0<1>:f    r5.0<0;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $232
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $233
        mov (32|M0)              r28.0<1>:ud   r26.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $234
        add (32|M0)              r30.0<1>:d    r28.0<1;1,0>:d    r10.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $235
(W)     mov (1|M0)               r4.0<1>:d     (abs)r3.3<0;1,0>:d                                    //  ALU pipe: int; $236
(W)     mul (16|M0)              acc0.0<1>:d   r30.0<1;1,0>:d    r4.0<0;1,0>:uw   {I@1}              //  ALU pipe: int; $236
        macl (16|M0)             r16.0<1>:d    r30.0<1;1,0>:d    r4.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $236
(W)     mul (16|M16)             acc0.0<1>:d   r31.0<1;1,0>:d    r4.0<0;1,0>:uw                      //  ALU pipe: int; $236
        macl (16|M16)            r17.0<1>:d    r31.0<1;1,0>:d    r4.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $237
        add (32|M0)              r14.0<1>:d    r12.0<1;1,0>:d    -r16.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $237
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r14.0<1;1,0>:ud   r2.3<0;1,0>:ud   {I@1}              //  ALU pipe: int; $238
(~f0.0) sel (32|M0)              r18.0<1>:d    (abs)r3.3<0;1,0>:d  0:w                               //  ALU pipe: int; $239
        add3 (32|M0)             r20.0<1>:d    r14.0<1;0>:d      r8.0<1;0>:d       -r18.0<1>:d      {Compacted,I@1} //  ALU pipe: int; $240 R{} IR{}{E:7,E:4,E:1,},  R{} IR{}{O:7,O:4,O:9,},  {BC=2}
        xor (32|M0)              r22.0<1>:d    r20.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $241
// B034: [inDivergent],  Preds:{B033, B032},  Succs:{B035, B036}
_0_074:
(W)     mov (32|M0)              r72.0<1>:f    0x3F800000:f                                          //  ALU pipe: float; $243
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $243
        math.invm (16|M0) (eo)f2.0  r80.mme0:f  r72.nomme<1;1,0>:f  r40.nomme<1;1,0>:f {A@1,$14.dst} //  ALU pipe: math; $243
(f2.0)  goto (32|M0)                         _L_k0_4_macro     _L_k0_4_macro                         //  ALU pipe: int; $243
// B035: [inDivergent],  Preds:{B034},  Succs:{B036}
_L_k0_10_:
        madm (16|M0)             r78.mme1:f    r65.nomme:f       r72.nomme:f       r80.mme0:f       {M@1} //  ALU pipe: float; $243
        madm (16|M0)             r76.mme2:f    r64.nomme:f       -r40.nomme:f      r80.mme0:f        //  ALU pipe: float; $243
        madm (16|M0)             r86.mme3:f    r80.mme0:f        r76.mme2:f        r80.mme0:f       {F@1} //  ALU pipe: float; $243
        madm (16|M0)             r74.mme4:f    r72.nomme:f       -r40.nomme:f      r78.mme1:f        //  ALU pipe: float; $243 R{} IR{}{E:4,E:4,E:7,},  {BC=1}
        madm (16|M0)             r78.mme5:f    r78.mme1:f        r74.mme4:f        r86.mme3:f       {F@1} //  ALU pipe: float; $243 R{} IR{}{E:7,E:5,E:3,},  {BC=1}
        madm (16|M0)             r82.mme6:f    r72.nomme:f       -r40.nomme:f      r78.mme5:f       {F@1} //  ALU pipe: float; $243 R{} IR{}{E:4,E:4,E:7,},  {BC=1}
        madm (16|M0)             r80.nomme:f   r78.mme5:f        r82.mme6:f        r86.mme3:f       {F@1} //  ALU pipe: float; $243 R{} IR{}{E:7,E:1,E:3,},  {BC=1}
// B036: [inDivergent],  Preds:{B035, B034},  Succs:{B037, B038}
_L_k0_4_macro:
        join (32|M0)                         _0_049                                                  // 
L4416:
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $243
        math.invm (16|M16) (eo)f2.0  r81.mme0:f  r73.nomme<1;1,0>:f  r41.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $243
(f2.0)  goto (32|M0)                         _L_k0_5_macro     _L_k0_5_macro                         //  ALU pipe: int; $243
// B037: [inDivergent],  Preds:{B036},  Succs:{B038}
_L_k0_11_:
        madm (16|M16)            r79.mme1:f    r65.nomme:f       r73.nomme:f       r81.mme0:f       {M@1} //  ALU pipe: float; $243 R{} IR{}{O:0,O:4,O:0,},  {BC=1}
        madm (16|M16)            r77.mme2:f    r64.nomme:f       -r41.nomme:f      r81.mme0:f        //  ALU pipe: float; $243
        madm (16|M16)            r87.mme3:f    r81.mme0:f        r77.mme2:f        r81.mme0:f       {F@1} //  ALU pipe: float; $243
        madm (16|M16)            r75.mme4:f    r73.nomme:f       -r41.nomme:f      r79.mme1:f        //  ALU pipe: float; $243 R{} IR{}{O:4,O:4,O:7,},  {BC=1}
        madm (16|M16)            r79.mme5:f    r79.mme1:f        r75.mme4:f        r87.mme3:f       {F@1} //  ALU pipe: float; $243 R{} IR{}{O:7,O:5,O:3,},  {BC=1}
        madm (16|M16)            r83.mme6:f    r73.nomme:f       -r41.nomme:f      r79.mme5:f       {F@1} //  ALU pipe: float; $243 R{} IR{}{O:4,O:4,O:7,},  {BC=1}
        madm (16|M16)            r81.nomme:f   r79.mme5:f        r83.mme6:f        r87.mme3:f       {F@1} //  ALU pipe: float; $243 R{} IR{}{O:7,O:1,O:3,},  {BC=1}
// B038: [inDivergent],  Preds:{B037, B036},  Succs:{B039}
_L_k0_5_macro:
        join (32|M0)                         _0_049                                                  // 
L4592:
(W)     mul (16|M0)              acc0.0<1>:d   r36.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $244
(W)     and (1|M0)               r3.0<1>:d     r3.5<0;1,0>:d     8:w                                 //  ALU pipe: int; $248
        macl (16|M0)             r54.0<1>:d    r36.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $244
(W)     mul (16|M16)             acc0.0<1>:d   r37.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $244
        mov (32|M0)              r56.0<1>:f    r80.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $243
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.0<0;1,0>:d     0:w               {I@3}             //  ALU pipe: int; $249
        macl (16|M16)            r55.0<1>:d    r37.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $245
(W)     mul (16|M0)              acc0.0<1>:d   r22.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $247
(W)     and (1|M0)               r2.3<1>:d     r3.5<0;1,0>:d     1:w                                 //  ALU pipe: int; $245
        macl (16|M0)             r58.0<1>:d    r22.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $247
(W)     mul (16|M16)             acc0.0<1>:d   r23.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $247
        macl (16|M16)            r59.0<1>:d    r23.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $248
(W)     mov (1|M0)               r32.2<1>:f    r2.3<0;1,0>:ud                   {I@4}                //  ALU pipe: float; $246
// B039: [inDivergent],  Preds:{B045, B038},  Succs:{B040, B041}
_0_075:
        sync.nop                             null                             {Compacted,$15.src}    // $251
        add (32|M0)              r8.0<1>:d     r54.0<1;1,0>:d    r34.0<1;1,0>:d   {Compacted,$13.src} //  ALU pipe: int; $251
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $253
        mov (16|M16)             r12.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $253
        shl (16|M0)              r126.0<1>:q   r10.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $253
        shl (16|M16)             r124.0<1>:q   r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $253
        add (16|M0)              r14.0<1>:q    r126.0<1;1,0>:q   r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $254
        add (16|M16)             r16.0<1>:q    r124.0<1;1,0>:q   r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $254
        load.ugm.d16u32.a64 (32|M0)  r18:2      [r14:4]            {I@1,$0} // ex_desc:0x0; desc:0x8200B80 // $256
        add (32|M0)              r22.0<1>:d    r58.0<1;1,0>:d    r34.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $259
        mov (16|M0)              r24.0<2>:ud   r22.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $260
        mov (16|M16)             r26.0<2>:ud   r23.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $260
        mov (16|M0)              r120.0<1>:q   r24.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $260
        mov (16|M16)             r118.0<1>:q   r26.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $260
        shl (32|M0)              r20.0<1>:d    r18.0<1;1,0>:ud   16:w               {$0.dst}         //  ALU pipe: int; $257
        mul (32|M0)              r18.0<1>:f    r56.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,A@1}    //  ALU pipe: float; $258
(W&f2.0) jmpi                                _0_076                                                  //  ALU pipe: int; $261
// B040: [inDivergent],  Preds:{B039},  Succs:{B042}
_0_077:
        shl (16|M0)              r7.0<1>:q     r120.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $263
        shl (16|M16)             r9.0<1>:q     r118.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $263
        add (16|M0)              r11.0<1>:q    r7.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $264
        add (16|M16)             r13.0<1>:q    r9.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $264
        load.ugm.d32.a64 (32|M0)  r122:2        [r11:4]            {I@1,$1} // ex_desc:0x0; desc:0x8200580 // $266
(W)     jmpi                                 _0_078                                                  // $267
// B041: [inDivergent],  Preds:{B039},  Succs:{B042}
_0_076:
        shl (16|M0)              r7.0<1>:q     r120.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $269
        shl (16|M16)             r9.0<1>:q     r118.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $269
        add (16|M0)              r11.0<1>:q    r7.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $270
        add (16|M16)             r13.0<1>:q    r9.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $270
        load.ugm.d16u32.a64 (32|M0)  r16:2      [r11:4]            {I@1,$4} // ex_desc:0x0; desc:0x8200B80 // $272
        shl (32|M0)              r122.0<1>:d   r16.0<1;1,0>:ud   16:w               {$4.dst}         //  ALU pipe: int; $273
// B042: [inDivergent],  Preds:{B041, B040},  Succs:{B043, B044}
_0_078:
        add (32|M0)              acc0.0<1>:f   r122.0<1;1,0>:f   r32.2<0;1,0>:f   {Compacted,A@1,$1.dst} //  ALU pipe: float; $275
        mul (32|M0)              r116.0<1>:f   r18.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $276
        and (32|M0)              r8.0<1>:d     r116.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $277
        cmp (32|M0)   (gt)f1.0   null<1>:ud    r8.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $278
(f1.0)  goto (32|M0)                         _0_079            _0_079                                //  ALU pipe: int; $279
// B043: [inDivergent],  Preds:{B042},  Succs:{B045}
_0_080:
        shr (32|M0)              r8.0<1>:ud    r116.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $281
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $282
        add3 (32|M0)             r12.0<1>:d    r10.0<1;0>:d      r116.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $283
        shr (32|M0)              r14.0<1>:ud   r12.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $284
        mov (32|M0)              r1.0<1>:w     r14.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $285
        goto (32|M0)                         _0_079            _0_081                                // $286
// B044: [inDivergent],  Preds:{B042},  Succs:{B045}
_0_079:
        join (32|M0)                         _0_081                                                  // 
L5248:
        shr (32|M0)              r8.0<1>:ud    r116.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $288
        or (32|M0)               r1.0<1>:w     r8.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $290
// B045: [inDivergent],  Preds:{B044, B043},  Succs:{B046, B039}
_0_081:
        join (32|M0)                         _L_k0_12_                                               // 
L5296:
        add (32|M0)              r34.0<1>:d    r34.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $296
        cmp (32|M0)   (lt)f0.0   null<1>:d     r34.0<1;1,0>:d    r38.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $297
        add (16|M0)              r7.0<1>:q     r126.0<1;1,0>:q   r3.6<0;1,0>:q                       //  ALU pipe: int; $292
        add (16|M16)             r9.0<1>:q     r124.0<1;1,0>:q   r3.6<0;1,0>:q                       //  ALU pipe: int; $292
        mov (32|M0)              r12.0<1>:ud   r1.0<1;1,0>:uw                                        //  ALU pipe: int; $294
        store.ugm.d16u32.a64 (32|M0)  [r7:4]    r12:2              {I@1,$15} // ex_desc:0x0; desc:0x8000B84 // $295
(f0.0)  goto.b (32|M0)                       _L_k0_12_         _0_075                                //  ALU pipe: int; $298
// B046: [inDivergent],  Preds:{B045},  Succs:{B049}
_L_k0_12_:
        join (32|M0)                         _0_049                                                  // 
L5416:
        goto (32|M0)                         _0_049            _0_049                                // $299
// B047: [inDivergent],  Preds:{B006},  Succs:{B048, B049}
_0_054:
        cmp (32|M0)   (eq)f3.0   null<1>:d     r44.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $301
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r42.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $302
(~f3.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $304
// B048: [inDivergent],  Preds:{B047},  Succs:{B049}
_0_082:
        mov (16|M0)              r7.0<2>:f     r32.0<0;1,0>:f                   {$15.src}            //  ALU pipe: float; $306
        mov (16|M16)             r9.0<2>:f     r32.0<0;1,0>:f                                        //  ALU pipe: float; $306
        mov (32|M0)              r12.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $308
        mov (16|M0)              r7.1<2>:f     r32.1<0;1,0>:f                                        //  ALU pipe: float; $307
        mov (16|M16)             r9.1<2>:ud    r32.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $307
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r7:4]           r12:2              {A@1,$5} // ex_desc:0x0; desc:0x800058B // $309
// B049: Preds:{B048, B047, B046, B030, B005, B004, B003, B002},  Succs:{}
_0_049:
        join (32|M0)                         L5584                                                   // 
L5584:
        sync.nop                             null                             {Compacted,$3.src}     // $311
(W)     mov (16|M0)              r127.0<1>:f   r52.0<1;1,0>:f                   {Compacted,$2.src}   //  ALU pipe: float; $311
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$6} // wr:1+0, rd:0; end of thread // $311
L5616:
(W)     mov (16|M0)              null<1>:ud    0x240B22FC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x608F9E07:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0xA:ud                                                // 


//.BankConflicts: 27
//.ByteRMWs: 2
//


//.numALUInst: 352
//.accSubDef: 7
//.accSubUse: 7
//.accSubCandidateDef: 7
//.accSubCandidateUse: 7
//
//
//.singlePipeAtOneDistNum: 105
//.allAtOneDistNum: 23
//.syncInstCount: 4
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 15
//.AfterReadTokenDepCount: 11
