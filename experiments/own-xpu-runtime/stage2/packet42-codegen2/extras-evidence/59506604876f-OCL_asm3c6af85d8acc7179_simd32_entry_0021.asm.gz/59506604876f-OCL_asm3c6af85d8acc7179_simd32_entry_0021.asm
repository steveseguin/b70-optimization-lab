//.kernel _ZTSN4sycl3_V16detail19__pf_kernel_wrapperIN9p42extras8FlatNameILNS3_4KindE2ELi0EEEEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 21 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 21 -GRFBumpUpNumber 2 "
//.instCount 357
//.RA type	LOCAL_FIRST_FIT_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 21
//.spill flag load 21

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r26.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.9)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.10)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.6)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.7)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.8)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r26.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r26.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r5.2)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r5.0)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.10)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r4.6)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.14)
//.declare V0061 (71)  rf=r size=4 type=d align=2 words (r4.15)
//.declare V0063 (73)  rf=r size=8 type=d align=2 words (r3.2)
//.declare V0064 (74)  rf=r size=8 type=d alias=V0044+0 align=32 words (r2.6)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0066 (76)  rf=r size=12 type=ud alias=V0038+0 align=32 words (r2.3)
//.declare V0067 (77)  rf=r size=32 type=ud alias=V0035+0 align=32 words (r26.0)
//.declare V0068 (78)  rf=r size=8 type=ud alias=V0065+0 align=4 words (r2.8)
//.declare V0069 (79)  rf=r size=8 type=d alias=V0065+0 align=4 words (r2.8)
//.declare V0070 (80)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0073 (83)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0076 (86)  rf=r size=12 type=ud alias=V0036+0 align=32 words (r2.0)
//.declare V0080 (90)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0081 (91)  rf=r size=128 type=d align=32 words (r30.0)
//.declare P01 (92)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0082 (93)  rf=r size=128 type=ud alias=V0080+0 align=32 words (r28.0)
//.declare V0083 (94)  rf=r size=8 type=ud alias=V0063+0 align=2 words (r3.2)
//.declare P02 (95)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P03 (96)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0084 (97)  rf=r size=128 type=ud alias=V0081+0 align=32 words (r30.0)
//.declare V0085 (98)  rf=r size=8 type=uq alias=V0057+0 align=32 words (r4.4)
//.declare V0086 (99)  rf=r size=8 type=uq alias=V0059+0 align=32 words (r4.6)
//.declare V0087 (100)  rf=r size=8 type=uq align=32 words (r32.0)
//.declare V0088 (101)  rf=r size=8 type=uq align=32 words (r34.0)
//.declare P04 (102)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P05 (103)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P06 (104)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0089 (105)  rf=r size=4 type=ud alias=V0047+0 align=32 words (r3.4)
//.declare P07 (106)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P08 (107)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P09 (108)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P10 (109)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0090 (110)  rf=r size=4 type=ud alias=V0050+0 align=32 words (r3.10)
//.declare P11 (111)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P12 (112)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P13 (113)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P14 (114)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0091 (115)  rf=r size=4 type=ud alias=V0053+0 align=32 words (r4.0)
//.declare P15 (116)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P16 (117)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P17 (118)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P18 (119)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0092 (120)  rf=r size=4 type=ud alias=V0056+0 align=32 words (r4.6)
//.declare P19 (121)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P20 (122)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P21 (123)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P22 (124)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P23 (125)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P24 (126)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P25 (127)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P26 (128)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P27 (129)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0093 (130)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0094 (131)  rf=r size=12 type=ud alias=V0037+0 align=32 words (r5.2)
//.declare V0095 (132)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0096 (133)  rf=r size=4 type=d align=2 words (r4.1)
//.declare V0097 (134)  rf=r size=4 type=d align=32 words (r5.0)
//.declare P28 (135)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0099 (137)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0100 (138)  rf=r size=256 type=ud alias=V0099+0 align=32 words (r6.0)
//.declare V0101 (139)  rf=r size=8 type=ud alias=V0088+0 align=32 words (r34.0)
//.declare V0102 (140)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0103 (141)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P29 (143)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0105 (144)  rf=r size=128 type=f align=32 words (r36.0)
//.declare V0109 (148)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0110 (149)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0114 (153)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0115 (154)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0116 (155)  rf=r size=128 type=ud alias=V0115+0 align=32 words (r14.0)
//.declare V0120 (159)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0121 (160)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0125 (164)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0127 (166)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0128 (167)  rf=r size=128 type=w alias=V0127+0 align=32 words (r14.0)
//.declare V0130 (169)  rf=r size=128 type=d alias=V0105+0 align=32 words (r36.0)
//.declare V0134 (173)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0135 (174)  rf=r size=128 type=f align=32 words (r38.0)
//.declare V0139 (178)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0140 (179)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0144 (183)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0145 (184)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0146 (185)  rf=r size=128 type=ud alias=V0145+0 align=32 words (r14.0)
//.declare V0150 (189)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0151 (190)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0155 (194)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0157 (196)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0158 (197)  rf=r size=128 type=w alias=V0157+0 align=32 words (r14.0)
//.declare V0160 (199)  rf=r size=128 type=d alias=V0135+0 align=32 words (r38.0)
//.declare V0164 (203)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0165 (204)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0169 (208)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0170 (209)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0174 (213)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0175 (214)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0176 (215)  rf=r size=128 type=ud alias=V0175+0 align=32 words (r14.0)
//.declare V0180 (219)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0181 (220)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0185 (224)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0187 (226)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0188 (227)  rf=r size=128 type=w alias=V0187+0 align=32 words (r14.0)
//.declare V0190 (229)  rf=r size=128 type=d alias=V0165+0 align=32 words (r40.0)
//.declare V0194 (233)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0195 (234)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0196 (235)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0197 (236)  rf=r size=128 type=d alias=V0195+0 align=32 words (r42.0)
//.declare P30 (237)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0198 (238)  rf=r size=128 type=ud alias=V0196+0 align=32 words (r6.0)
//.declare V0199 (239)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0200 (240)  rf=r size=128 type=ud alias=V0195+0 align=32 words (r42.0)
//.declare V0201 (241)  rf=r size=128 type=ud alias=V0199+0 align=32 words (r6.0)
//.declare V0202 (242)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0203 (243)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0204 (244)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0205 (245)  rf=r size=128 type=f align=32 words (r46.0)
//.declare V0206 (246)  rf=r size=128 type=f alias=V0204+0 align=32 words (r44.0)
//.declare V0210 (250)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0212 (252)  rf=r size=256 type=d align=32 words (r22.0)
//.declare V0214 (254)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0215 (255)  rf=r size=128 type=ud alias=V0214+0 align=32 words (r6.0)
//.declare V0219 (259)  rf=r size=256 type=uq align=32 words (r12.0)
//.declare V0220 (260)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0224 (264)  rf=r size=256 type=uq align=32 words (r12.0)
//.declare V0225 (265)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0226 (266)  rf=r size=128 type=d alias=V0205+0 align=32 words (r46.0)
//.declare P31 (267)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0227 (268)  rf=r size=128 type=ud alias=V0225+0 align=32 words (r6.0)
//.declare V0228 (269)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0229 (270)  rf=r size=128 type=ud alias=V0205+0 align=32 words (r46.0)
//.declare V0230 (271)  rf=r size=128 type=ud alias=V0228+0 align=32 words (r6.0)
//.declare V0231 (272)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0232 (273)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0233 (274)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0234 (275)  rf=r size=128 type=ud alias=V0232+0 align=32 words (r10.0)
//.declare V0235 (276)  rf=r size=128 type=ud alias=V0233+0 align=32 words (r12.0)
//.declare V0236 (277)  rf=r size=64 type=w align=32 words (r27.0)
//.declare V0237 (278)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0238 (279)  rf=r size=128 type=ud alias=V0237+0 align=32 words (r6.0)
//.declare V0243 (284)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0244 (285)  rf=r size=64 type=uw alias=V0236+0 align=32 words (r27.0)
//.declare V0245 (286)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0249 (290)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0253 (294)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0254 (295)  rf=r size=128 type=d align=32 words (r50.0)
//.declare P32 (296)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0255 (297)  rf=r size=128 type=ud alias=V0253+0 align=32 words (r48.0)
//.declare P33 (298)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P34 (299)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0256 (300)  rf=r size=128 type=ud alias=V0254+0 align=32 words (r50.0)
//.declare  (304)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (305)  rf=r size=128 type=w alias=V0237+0 align=32 words (r6.0)
//.declare  (306)  rf=r size=4 type=ud align=32 words (r5.0)
//.declare  (307)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (308)  rf=r size=128 type=uw align=32 words (r11.0)
//.declare  (309)  rf=r size=128 type=f align=32 words (r18.0)
//.declare  (310)  rf=r size=128 type=f align=32 words (r20.0)
//.declare  (311)  rf=r size=128 type=f align=32 words (r18.0)
//.declare  (312)  rf=r size=128 type=f align=32 words (r20.0)
//.declare  (313)  rf=r size=128 type=f align=32 words (r18.0)
//.declare  (314)  rf=r size=128 type=f align=32 words (r20.0)
//.declare  (315)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (316)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (317)  rf=r size=128 type=w alias=V0233+0 align=32 words (r12.0)
//.declare  (320)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (321)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (322)  rf=r size=128 type=q align=32 words (r52.0)
//.declare  (323)  rf=r size=128 type=q align=32 words (r54.0)
//.declare  (326)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (327)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (330)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (331)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (334)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (335)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (338)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (339)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (342)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (343)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (346)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (347)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (350)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (351)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (354)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (355)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (358)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (359)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (362)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (363)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (366)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (367)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (370)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (371)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (374)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (375)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (378)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (379)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (382)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (383)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (386)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (387)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (390)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (391)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (392)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (393)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (396)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (397)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (400)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (401)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (404)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (405)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (408)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (409)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (412)  rf=r size=128 type=d align=32 words (r6.0)
//.declare  (413)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (414)  rf=r size=128 type=d alias=+0 align=32 words (r52.0)
//.declare  (415)  rf=r size=128 type=d alias=+0 align=32 words (r54.0)
//.declare  (416)  rf=r size=128 type=d alias=+0 align=32 words (r16.0)
//.declare  (417)  rf=r size=128 type=d alias=+0 align=32 words (r20.0)
//.declare  (418)  rf=r size=128 type=d alias=+0 align=32 words (r6.0)
//.declare  (419)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (420)  rf=r size=4 type=uw align=2 words (r3.22)
//.declare  (421)  rf=r size=4 type=uw align=2 words (r3.28)
//.declare  (422)  rf=r size=4 type=uw align=2 words (r3.30)
//.declare  (423)  rf=r size=4 type=uw align=2 words (r4.8)
//.declare  (424)  rf=r size=4 type=uw align=2 words (r4.10)
//.declare  (425)  rf=r size=4 type=uw align=2 words (r4.14)
//.declare  (426)  rf=r size=4 type=uw align=2 words (r4.20)
//.declare  (427)  rf=r size=4 type=uw align=2 words (r4.22)
//.declare  (428)  rf=r size=4 type=uw align=2 words (r4.28)
//.declare  (429)  rf=r size=4 type=uw align=2 words (r4.30)
//.declare  (430)  rf=r size=4 type=uw align=2 words (r32.4)
//.declare  (431)  rf=r size=4 type=uw align=2 words (r32.6)
//.declare  (432)  rf=r size=4 type=uw align=2 words (r32.8)
//.declare  (433)  rf=r size=4 type=uw align=2 words (r32.10)
//.declare  (434)  rf=r size=4 type=uw align=2 words (r32.12)
//.declare  (435)  rf=r size=4 type=uw align=2 words (r32.14)
//.declare  (436)  rf=r size=4 type=uw align=2 words (r32.16)
//.declare  (437)  rf=r size=4 type=uw align=2 words (r32.18)
//.declare  (438)  rf=r size=4 type=uw align=2 words (r32.20)
//.declare  (439)  rf=r size=4 type=uw align=2 words (r32.22)
//.declare  (440)  rf=r size=4 type=uw align=2 words (r32.24)
//.declare  (441)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (442)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (443)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (444)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (445)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (446)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (447)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (448)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (449)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (450)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (451)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (452)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (453)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (454)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (455)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (456)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (457)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (458)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (459)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (460)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (461)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (462)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (463)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (464)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (465)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (466)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (467)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (468)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (469)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (470)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (471)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (472)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (473)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (474)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (475)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (476)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (477)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (478)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (479)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (480)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (481)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (482)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare r0 (483)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (484)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (485)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (486)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (487)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (488)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (489)  rf=r size=32 type=ud align=2 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0045    | :q       |    0x8 | r3       | cti+0x20         |
// | V0046    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0049    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0050    | :d       |    0x4 | r3+0x28  | cti+0x48         |
// | V0051    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0052    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r4       | cti+0x60         |
// | V0054    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0055    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0056    | :d       |    0x4 | r4+0x18  | cti+0x78         |
// | V0057    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0058    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0059    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0060    | :d       |    0x4 | r4+0x38  | cti+0x98         |
// | V0061    | :d       |    0x4 | r4+0x3C  | cti+0x9C         |
// | V0042    | :uq      |    0x8 | r5       | cti+0xA0         |
// | V0037    | :d x 3   |    0xC | r5+0x8   | cti+0xA8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xA0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r5:1  bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B061}
// _main:
(W)     mov (16|M0)              r26.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r26.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r5.0<1>:ud    r2.3<0;1,0>:ud    r26.1<0;1,0>:ud  {Compacted,$2.dst} //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r26.2<0;1,0>:uw                     //  ALU pipe: int; $4
(W)     mach (1|M0)              r6.0<1>:d     r2.3<0;1,0>:ud    r26.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r11.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.8<2>:ud    r5.0<0;1,0>:ud                   {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.9<2>:d     r6.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r3.2<1>:d     r2.6<1;1,0>:d                    {$1.dst}             //  ALU pipe: int; $2
        add (16|M0)              r9.0<1>:q     r2.4<0;1,0>:q     r7.0<4;1,0>:uw   {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r13.0<1>:q    r2.4<0;1,0>:q     r11.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r52.0<1>:q    r9.0<1;1,0>:q     r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r54.0<1>:q    r13.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r28.0<1>:d    r52.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r29.0<1>:d    r54.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r28.0<1;1,0>:ud   r3.2<0;1,0>:ud   {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r30.0<1>:d    r52.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r31.0<1>:d    r54.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r30.0<1;1,0>:d    r3.3<0;1,0>:d    {I@1}              //  ALU pipe: int; $18
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r30.0<1;1,0>:ud   r3.3<0;1,0>:ud                      //  ALU pipe: int; $20
(~f0.0) goto (32|M0)                         _0_073            _0_073                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_074:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $26
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r3.4<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $28
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.4<0;1,0>:d     4:w                                 //  ALU pipe: int; $29
(W)     mov (1|M0)               r32.12<1>:ud  f0.0<0;1,0>:ud                                        //  ALU pipe: int; $26
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.10<0;1,0>:d    2:w                                 //  ALU pipe: int; $30
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $27
(W)     mov (1|M0)               r32.10<1>:ud  f2.0<0;1,0>:ud                                        //  ALU pipe: int; $28
(W)     mov (1|M0)               r32.9<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $29
(W)     mov (1|M0)               r32.8<1>:ud   f0.0<0;1,0>:ud                                        //  ALU pipe: int; $30
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r3.10<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $32
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.10<0;1,0>:d    4:w                                 //  ALU pipe: int; $33
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r4.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $34
(W)     mov (1|M0)               r32.11<1>:ud  f3.0<0;1,0>:ud                                        //  ALU pipe: int; $27
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.10<0;1,0>:d    2:w                                 //  ALU pipe: int; $31
(W)     mov (1|M0)               r32.6<1>:ud   f2.0<0;1,0>:ud                                        //  ALU pipe: int; $32
(W)     mov (1|M0)               r32.5<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $33
(W)     mov (1|M0)               r32.4<1>:ud   f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $34
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r4.0<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $36
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.0<0;1,0>:d     4:w                                 //  ALU pipe: int; $37
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r4.6<0;1,0>:d     2:w                                 //  ALU pipe: int; $38
(W)     mov (1|M0)               r32.7<1>:ud   f3.0<0;1,0>:ud                                        //  ALU pipe: int; $31
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r4.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $35
(W)     mov (1|M0)               r32.2<1>:ud   f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $36
(W)     mov (1|M0)               r4.15<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $37
(W)     mov (1|M0)               r4.14<1>:ud   f0.0<0;1,0>:ud                                        //  ALU pipe: int; $38
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r4.6<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $40
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.6<0;1,0>:d     4:w                                 //  ALU pipe: int; $41
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $42
(W)     mov (1|M0)               r32.3<1>:ud   f3.0<0;1,0>:ud                                        //  ALU pipe: int; $35
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r4.6<0;1,0>:d     2:w                                 //  ALU pipe: int; $39
(W)     mov (1|M0)               r4.10<1>:ud   f2.0<0;1,0>:ud                                        //  ALU pipe: int; $40
(W)     mov (1|M0)               r4.7<1>:ud    f1.0<0;1,0>:ud                                        //  ALU pipe: int; $41
(W)     mov (1|M0)               r4.5<1>:ud    f0.0<0;1,0>:ud                                        //  ALU pipe: int; $42
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r3.10<0;1,0>:d    1:w                                 //  ALU pipe: int; $44
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.10<0;1,0>:d    0:w                                 //  ALU pipe: int; $45
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r4.0<0;1,0>:d     1:w                                 //  ALU pipe: int; $46
(W)     mov (1|M0)               r4.11<1>:ud   f3.0<0;1,0>:ud                                        //  ALU pipe: int; $39
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $43
(W)     mov (1|M0)               r3.15<1>:ud   f2.0<0;1,0>:ud                                        //  ALU pipe: int; $44
(W)     mov (1|M0)               r3.14<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $45
(W)     mov (1|M0)               r3.11<1>:ud   f0.0<0;1,0>:ud                                        //  ALU pipe: int; $46
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r4.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $47
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r4.6<0;1,0>:d     1:w                                 //  ALU pipe: int; $48
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r4.6<0;1,0>:d     0:w                                 //  ALU pipe: int; $49
(W)     mov (1|M0)               r32.0<1>:uq   r4.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $24
(W)     mov (1|M0)               r34.0<1>:uq   r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $25
(W)     mov (1|M0)               r3.4<1>:q     r5.2<0;1,0>:ud                                        //  ALU pipe: int; $50
(W)     mov (1|M0)               r3.5<1>:f     0xFFBF0000:f                                          //  (0xffbf0000:f); ALU pipe: float; $51
(W)     mov (1|M0)               r4.1<1>:f     0x400000:f                               {Compacted}  //  (0x00400000:f); ALU pipe: float; $52
(W)     mov (1|M0)               r4.4<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $43
// B004: [inDivergent],  Preds:{B060, B003},  Succs:{B005, B059}
_0_075:
(W)     load.ugm.d32x1t.a64 (1|M0)  r5:1        [r32:1]            {I@2,$5} // ex_desc:0x0; desc:0x2108580 // $54
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r5.0<0;1,0>:d     0:w               {$5.dst}          //  ALU pipe: int; $55
(W&f3.0) jmpi                                _0_076                                                  //  ALU pipe: int; $56
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B059}
_0_077:
        mov (16|M0)              r6.0<2>:f     r34.0<0;1,0>:f                                        //  ALU pipe: float; $58
        mov (16|M16)             r8.0<2>:f     r34.0<0;1,0>:f                                        //  ALU pipe: float; $58
        sync.allrd                           ($3,$4)                                                 // $60
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted,$6.src}  //  ALU pipe: int; $60
        mov (16|M0)              r6.1<2>:f     r34.1<0;1,0>:f                                        //  ALU pipe: float; $59
        mov (16|M16)             r8.1<2>:ud    r34.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $59
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$7} // ex_desc:0x0; desc:0x8200599 // $61
        cmp (32|M0)   (eq)f3.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$7.dst}          //  ALU pipe: int; $63
(~f3.0) goto (32|M0)                         _0_076            _0_076                                //  ALU pipe: int; $64
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B014}
_0_078:
(W)     mov (1|M0)               f3.0<1>:ud    r32.12<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $66
(W&f3.0) jmpi                                _0_079                                                  //  ALU pipe: int; $66
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B013}
_0_080:
(W)     mov (1|M0)               f3.0<1>:ud    r32.11<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $68
(W&f3.0) jmpi                                _0_081                                                  //  ALU pipe: int; $68
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B012}
_0_082:
(W)     mov (1|M0)               f3.0<1>:ud    r32.10<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $70
(W&f3.0) jmpi                                _0_083                                                  //  ALU pipe: int; $70
// B009: [inDivergent],  Preds:{B008},  Succs:{B010, B011}
_0_084:
(W)     mov (1|M0)               f3.0<1>:ud    r32.9<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $72
(W&f3.0) jmpi                                _0_085                                                  //  ALU pipe: int; $72
// B010: [inDivergent],  Preds:{B009},  Succs:{B019}
_0_086:
        mov (32|M0)              r36.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $74
(W)     jmpi                                 _0_087                                                  // $75
// B011: [inDivergent],  Preds:{B009},  Succs:{B019}
_0_085:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $77
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $77
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $78
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $78
        load.ugm.d64.a64 (32|M0)  r14:4         [r10:4]            {I@1,$8} // ex_desc:0x0; desc:0x8400780 // $80
        mov (16|M0)              r18.0<2>:f    r14.0<1;1,0>:q                   {$8.dst}             //  ALU pipe: float; $81
        mov (16|M16)             r20.0<2>:f    r16.0<1;1,0>:q                                        //  ALU pipe: float; $81
        mov (16|M0)              r36.0<1>:ud   r18.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $81
        mov (16|M16)             r37.0<1>:ud   r20.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $81
(W)     jmpi                                 _0_087                                                  // $82
// B012: [inDivergent],  Preds:{B008},  Succs:{B019}
_0_083:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $84
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $84
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $85
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $85
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {I@1,$9} // ex_desc:0x0; desc:0x8200580 // $87
        mov (32|M0)              r36.0<1>:f    r14.0<1;1,0>:ud                  {$9.dst}             //  ALU pipe: float; $88
(W)     jmpi                                 _0_087                                                  // $89
// B013: [inDivergent],  Preds:{B007},  Succs:{B019}
_0_081:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $91
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $91
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $92
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $92
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {A@1,$10} // ex_desc:0x0; desc:0x8200580 // $94
        mov (32|M0)              r36.0<1>:f    r14.0<1;1,0>:d                   {$10.dst}            //  ALU pipe: float; $95
(W)     jmpi                                 _0_087                                                  // $96
// B014: [inDivergent],  Preds:{B006},  Succs:{B015, B018}
_0_079:
(W)     mov (1|M0)               f3.0<1>:ud    r4.5<0;1,0>:ud                                        //  ALU pipe: int; $98
(W&~f3.0) jmpi                               _0_088                                                  //  ALU pipe: int; $98
// B015: [inDivergent],  Preds:{B014},  Succs:{B016, B017}
_0_089:
(W)     mov (1|M0)               f3.0<1>:ud    r4.4<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $100
(W&f3.0) jmpi                                _0_090                                                  //  ALU pipe: int; $100
// B016: [inDivergent],  Preds:{B015},  Succs:{B019}
_0_091:
        mov (32|M0)              r36.0<1>:ud   0x0:ud                              {Compacted,F@1}   //  ALU pipe: int; $102
(W)     jmpi                                 _0_087                                                  // $103
// B017: [inDivergent],  Preds:{B015},  Succs:{B019}
_0_090:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $105
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $105
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $106
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $106
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r10:4]            {I@1,$11} // ex_desc:0x0; desc:0x8200B80 // $108
        shl (32|M0)              r36.0<1>:d    r14.0<1;1,0>:ud   16:w               {$11.dst}        //  ALU pipe: int; $109
(W)     jmpi                                 _0_087                                                  // $110
// B018: [inDivergent],  Preds:{B014},  Succs:{B019}
_0_088:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $112
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $112
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $113
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $113
        load.ugm.d32.a64 (32|M0)  r36:2         [r10:4]            {I@1,$12} // ex_desc:0x0; desc:0x8200580 // $115
// B019: [inDivergent],  Preds:{B018, B017, B016, B013, B012, B011, B010},  Succs:{B020, B027}
_0_087:
(W)     mov (1|M0)               f3.0<1>:ud    r32.8<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $117
(W&f3.0) jmpi                                _0_092                                                  //  ALU pipe: int; $117
// B020: [inDivergent],  Preds:{B019},  Succs:{B021, B026}
_0_093:
(W)     mov (1|M0)               f3.0<1>:ud    r32.7<0;1,0>:ud                                       //  ALU pipe: int; $119
(W&f3.0) jmpi                                _0_094                                                  //  ALU pipe: int; $119
// B021: [inDivergent],  Preds:{B020},  Succs:{B022, B025}
_0_095:
(W)     mov (1|M0)               f3.0<1>:ud    r32.6<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $121
(W&f3.0) jmpi                                _0_096                                                  //  ALU pipe: int; $121
// B022: [inDivergent],  Preds:{B021},  Succs:{B023, B024}
_0_097:
(W)     mov (1|M0)               f3.0<1>:ud    r32.5<0;1,0>:ud                                       //  ALU pipe: int; $123
(W&f3.0) jmpi                                _0_098                                                  //  ALU pipe: int; $123
// B023: [inDivergent],  Preds:{B022},  Succs:{B032}
_0_099:
        mov (32|M0)              r38.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $125
(W)     jmpi                                 _0_100                                                  // $126
// B024: [inDivergent],  Preds:{B022},  Succs:{B032}
_0_098:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $128
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $128
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $129
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $129
        load.ugm.d64.a64 (32|M0)  r14:4         [r10:4]            {I@1,$13} // ex_desc:0x0; desc:0x8400780 // $131
        mov (16|M0)              r18.0<2>:f    r14.0<1;1,0>:q                   {$13.dst}            //  ALU pipe: float; $132
        mov (16|M16)             r20.0<2>:f    r16.0<1;1,0>:q                                        //  ALU pipe: float; $132
        mov (16|M0)              r38.0<1>:ud   r18.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $132
        mov (16|M16)             r39.0<1>:ud   r20.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $132
(W)     jmpi                                 _0_100                                                  // $133
// B025: [inDivergent],  Preds:{B021},  Succs:{B032}
_0_096:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $135
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $135
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $136
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $136
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {I@1,$14} // ex_desc:0x0; desc:0x8200580 // $138
        mov (32|M0)              r38.0<1>:f    r14.0<1;1,0>:ud                  {$14.dst}            //  ALU pipe: float; $139
(W)     jmpi                                 _0_100                                                  // $140
// B026: [inDivergent],  Preds:{B020},  Succs:{B032}
_0_094:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $142
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $142
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $143
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $143
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {A@1,$15} // ex_desc:0x0; desc:0x8200580 // $145
        mov (32|M0)              r38.0<1>:f    r14.0<1;1,0>:d                   {$15.dst}            //  ALU pipe: float; $146
(W)     jmpi                                 _0_100                                                  // $147
// B027: [inDivergent],  Preds:{B019},  Succs:{B028, B031}
_0_092:
(W)     mov (1|M0)               f3.0<1>:ud    r3.15<0;1,0>:ud                                       //  ALU pipe: int; $149
(W&~f3.0) jmpi                               _0_101                                                  //  ALU pipe: int; $149
// B028: [inDivergent],  Preds:{B027},  Succs:{B029, B030}
_0_102:
(W)     mov (1|M0)               f3.0<1>:ud    r3.14<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $151
(W&f3.0) jmpi                                _0_103                                                  //  ALU pipe: int; $151
// B029: [inDivergent],  Preds:{B028},  Succs:{B032}
_0_104:
        mov (32|M0)              r38.0<1>:ud   0x0:ud                              {Compacted,F@1}   //  ALU pipe: int; $153
(W)     jmpi                                 _0_100                                                  // $154
// B030: [inDivergent],  Preds:{B028},  Succs:{B032}
_0_103:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $156
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $156
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $157
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $157
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r10:4]            {I@1,$0} // ex_desc:0x0; desc:0x8200B80 // $159
        shl (32|M0)              r38.0<1>:d    r14.0<1;1,0>:ud   16:w               {$0.dst}         //  ALU pipe: int; $160
(W)     jmpi                                 _0_100                                                  // $161
// B031: [inDivergent],  Preds:{B027},  Succs:{B032}
_0_101:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $163
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $163
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $164
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $164
        load.ugm.d32.a64 (32|M0)  r38:2         [r10:4]            {I@1,$1} // ex_desc:0x0; desc:0x8200580 // $166
// B032: [inDivergent],  Preds:{B031, B030, B029, B026, B025, B024, B023},  Succs:{B033, B040}
_0_100:
(W)     mov (1|M0)               f3.0<1>:ud    r32.4<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $168
(W&f3.0) jmpi                                _0_105                                                  //  ALU pipe: int; $168
// B033: [inDivergent],  Preds:{B032},  Succs:{B034, B039}
_0_106:
(W)     mov (1|M0)               f3.0<1>:ud    r32.3<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $170
(W&f3.0) jmpi                                _0_107                                                  //  ALU pipe: int; $170
// B034: [inDivergent],  Preds:{B033},  Succs:{B035, B038}
_0_108:
(W)     mov (1|M0)               f3.0<1>:ud    r32.2<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $172
(W&f3.0) jmpi                                _0_109                                                  //  ALU pipe: int; $172
// B035: [inDivergent],  Preds:{B034},  Succs:{B036, B037}
_0_110:
(W)     mov (1|M0)               f3.0<1>:ud    r4.15<0;1,0>:ud                                       //  ALU pipe: int; $174
(W&f3.0) jmpi                                _0_111                                                  //  ALU pipe: int; $174
// B036: [inDivergent],  Preds:{B035},  Succs:{B045}
_0_112:
        mov (32|M0)              r40.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $176
(W)     jmpi                                 _0_113                                                  // $177
// B037: [inDivergent],  Preds:{B035},  Succs:{B045}
_0_111:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $179
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $179
        sync.nop                             null                             {Compacted,$1.src}     // $180
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.6<0;1,0>:q    {@2,$12.src}       //  ALU pipe: int; $180
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.6<0;1,0>:q    {I@2}              //  ALU pipe: int; $180
        load.ugm.d64.a64 (32|M0)  r14:4         [r10:4]            {I@1,$2} // ex_desc:0x0; desc:0x8400780 // $182
        mov (16|M0)              r18.0<2>:f    r14.0<1;1,0>:q                   {$2.dst}             //  ALU pipe: float; $183
        mov (16|M16)             r20.0<2>:f    r16.0<1;1,0>:q                                        //  ALU pipe: float; $183
        mov (16|M0)              r40.0<1>:ud   r18.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $183
        mov (16|M16)             r41.0<1>:ud   r20.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $183
(W)     jmpi                                 _0_113                                                  // $184
// B038: [inDivergent],  Preds:{B034},  Succs:{B045}
_0_109:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $186
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $186
        sync.nop                             null                             {Compacted,$1.src}     // $187
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.6<0;1,0>:q    {@2,$12.src}       //  ALU pipe: int; $187
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.6<0;1,0>:q    {I@2}              //  ALU pipe: int; $187
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $189
        mov (32|M0)              r40.0<1>:f    r14.0<1;1,0>:ud                  {$5.dst}             //  ALU pipe: float; $190
(W)     jmpi                                 _0_113                                                  // $191
// B039: [inDivergent],  Preds:{B033},  Succs:{B045}
_0_107:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $193
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $193
        sync.nop                             null                             {Compacted,$1.src}     // $194
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.6<0;1,0>:q    {@2,$12.src}       //  ALU pipe: int; $194
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.6<0;1,0>:q    {I@2}              //  ALU pipe: int; $194
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {A@1,$7} // ex_desc:0x0; desc:0x8200580 // $196
        mov (32|M0)              r40.0<1>:f    r14.0<1;1,0>:d                   {$7.dst}             //  ALU pipe: float; $197
(W)     jmpi                                 _0_113                                                  // $198
// B040: [inDivergent],  Preds:{B032},  Succs:{B041, B044}
_0_105:
(W)     mov (1|M0)               f3.0<1>:ud    r3.11<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $200
(W&~f3.0) jmpi                               _0_114                                                  //  ALU pipe: int; $200
// B041: [inDivergent],  Preds:{B040},  Succs:{B042, B043}
_0_115:
(W&f2.0) jmpi                                _0_116                                                  //  ALU pipe: int; $202
// B042: [inDivergent],  Preds:{B041},  Succs:{B045}
_0_117:
        mov (32|M0)              r40.0<1>:ud   0x0:ud                              {Compacted,F@1}   //  ALU pipe: int; $204
(W)     jmpi                                 _0_113                                                  // $205
// B043: [inDivergent],  Preds:{B041},  Succs:{B045}
_0_116:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $207
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $207
        sync.nop                             null                             {Compacted,$1.src}     // $208
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.6<0;1,0>:q    {@2,$12.src}       //  ALU pipe: int; $208
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.6<0;1,0>:q    {I@2}              //  ALU pipe: int; $208
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r10:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200B80 // $210
        shl (32|M0)              r40.0<1>:d    r14.0<1;1,0>:ud   16:w               {$8.dst}         //  ALU pipe: int; $211
(W)     jmpi                                 _0_113                                                  // $212
// B044: [inDivergent],  Preds:{B040},  Succs:{B045}
_0_114:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $214
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $214
        sync.nop                             null                             {Compacted,$1.src}     // $215
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.6<0;1,0>:q    {@2,$12.src}       //  ALU pipe: int; $215
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.6<0;1,0>:q    {I@2}              //  ALU pipe: int; $215
        load.ugm.d32.a64 (32|M0)  r40:2         [r10:4]            {I@1,$9} // ex_desc:0x0; desc:0x8200580 // $217
// B045: [inDivergent],  Preds:{B044, B043, B042, B039, B038, B037, B036},  Succs:{B046, B052}
_0_113:
        sync.nop                             null                             {Compacted,$9.dst}     // $219
        add (32|M0)              r42.0<1>:f    r38.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted,$1.dst} //  ALU pipe: float; $219
        and (32|M0)              r6.0<1>:d     r42.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $220
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r6.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $221
(~f3.0) shr (32|M0)              r6.0<1>:ud    r42.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $224
(~f3.0) and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $225
(~f3.0) add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r42.0<1;0>:d      32767:w               {@1,$12.src} //  ALU pipe: int; $226
(~f3.0) and (32|M0)              r44.0<1>:d    r10.0<1;1,0>:d    -65536:d               {I@1}        //  ALU pipe: int; $227
(f3.0)  bfn.(s0&s1|s2) (32|M0)   r44.0<1>:ud   r42.0<1;0>:ud     r3.5<0;0>:ud      r4.1<0>:ud        //  ALU pipe: int; $230
(W)     mov (1|M0)               f3.0<1>:ud    r4.14<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $233
        sync.nop                             null                             {Compacted,I@2}        // $232
        add (32|M0)              r46.0<1>:f    r36.0<1;1,0>:f    r44.0<1;1,0>:f   {Compacted,$12.dst} //  ALU pipe: float; $232
(W&f3.0) jmpi                                _0_121                                                  //  ALU pipe: int; $233
// B046: [inDivergent],  Preds:{B045},  Succs:{B047, B051}
_0_122:
(W)     mov (1|M0)               f3.0<1>:ud    r4.11<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $235
(W&f3.0) jmpi                                _0_123                                                  //  ALU pipe: int; $235
// B047: [inDivergent],  Preds:{B046},  Succs:{B048, B050}
_0_124:
(W)     mov (1|M0)               f3.0<1>:ud    r4.10<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $237
(W&f3.0) jmpi                                _0_125                                                  //  ALU pipe: int; $237
// B048: [inDivergent],  Preds:{B047},  Succs:{B049, B059}
_0_126:
(W)     mov (1|M0)               f3.0<1>:ud    r4.7<0;1,0>:ud                                        //  ALU pipe: int; $239
(~f3.0) goto (32|M0)                         _0_076            _0_076                                //  ALU pipe: int; $239
// B049: [inDivergent],  Preds:{B048},  Succs:{B059}
_0_127:
        mov (16|M0)              r14.0<2>:ud   r46.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $244
        mov (16|M16)             r18.0<2>:ud   r47.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $244
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $241
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $241
        mov (16|M0)              r16.0<1>:q    r14.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $244
        mov (16|M16)             r20.0<1>:q    r18.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $244
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $242
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $242
        mov (16|M0)              r22.0<1>:d    r16.0<2;1,0>:d                   {Compacted,I@4}      //  ALU pipe: int; $245
        mov (16|M0)              r24.0<1>:d    r16.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $247
        mov (16|M16)             r23.0<1>:d    r20.0<2;1,0>:d                   {Compacted,I@5}      //  ALU pipe: int; $246
        mov (16|M16)             r25.0<1>:d    r20.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $248
        store.ugm.d32x2.a64 (32|M0)  [r10:4]    r22:4              {I@1,$6} // ex_desc:0x0; desc:0x8001584 // $249
        goto (32|M0)                         _0_076            _0_076                                // $250
// B050: [inDivergent],  Preds:{B047},  Succs:{B059}
_0_125:
        shl (16|M0)              r8.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $253
        shl (16|M16)             r10.0<1>:q    r54.0<1;1,0>:q    2:w               {Compacted,$6.src} //  ALU pipe: int; $253
        mov (32|M0)              r6.0<1>:ud    r46.0<1;1,0>:f                                        //  ALU pipe: int; $252
        add (16|M0)              r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $254
        add (16|M16)             r14.0<1>:q    r10.0<1;1,0>:q    r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $254
        store.ugm.d32.a64 (32|M0)  [r12:4]      r6:2               {I@1,$10} // ex_desc:0x0; desc:0x8000584 // $256
        goto (32|M0)                         _0_076            _0_076                                // $257
// B051: [inDivergent],  Preds:{B046},  Succs:{B059}
_0_123:
        shl (16|M0)              r8.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $260
        shl (16|M16)             r10.0<1>:q    r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $260
        mov (32|M0)              r6.0<1>:d     r46.0<1;1,0>:f                   {$10.src}            //  ALU pipe: int; $259
        add (16|M0)              r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $261
        add (16|M16)             r14.0<1>:q    r10.0<1;1,0>:q    r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $261
        store.ugm.d32.a64 (32|M0)  [r12:4]      r6:2               {I@1,$11} // ex_desc:0x0; desc:0x8000584 // $263
        goto (32|M0)                         _0_076            _0_076                                // $264
// B052: [inDivergent],  Preds:{B045},  Succs:{B053, B058}
_0_121:
(W&~f1.0) jmpi                               _0_128                                                  //  ALU pipe: int; $266
// B053: [inDivergent],  Preds:{B052},  Succs:{B054, B059}
_0_129:
(~f0.0) goto (32|M0)                         _0_076            _0_076                                //  ALU pipe: int; $268
// B054: [inDivergent],  Preds:{B053},  Succs:{B055, B056}
_0_130:
        and (32|M0)              r6.0<1>:d     r46.0<1;1,0>:d    2147483647:d               {$11.src} //  ALU pipe: int; $270
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r6.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $271
(f3.0)  goto (32|M0)                         _0_131            _0_131                                //  ALU pipe: int; $272
// B055: [inDivergent],  Preds:{B054},  Succs:{B057}
_0_132:
        shr (32|M0)              r6.0<1>:ud    r46.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $274
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $275
        add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r46.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $276
        shr (32|M0)              r12.0<1>:ud   r10.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $277
        mov (32|M0)              r27.0<1>:w    r12.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $278
        goto (32|M0)                         _0_131            _0_133                                // $279
// B056: [inDivergent],  Preds:{B054},  Succs:{B057}
_0_131:
        join (32|M0)                         _0_133                                                  // 
L4112:
        shr (32|M0)              r6.0<1>:ud    r46.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $281
        or (32|M0)               r27.0<1>:w    r6.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $283
// B057: [inDivergent],  Preds:{B056, B055},  Succs:{B059}
_0_133:
        join (32|M0)                         _0_076                                                  // 
L4160:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $285
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $285
        mov (32|M0)              r14.0<1>:ud   r27.0<1;1,0>:uw                  {I@4}                //  ALU pipe: int; $288
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $286
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $286
        store.ugm.d16u32.a64 (32|M0)  [r10:4]   r14:2              {I@1,$3} // ex_desc:0x0; desc:0x8000B84 // $289
        goto (32|M0)                         _0_076            _0_076                                // $290
// B058: [inDivergent],  Preds:{B052},  Succs:{B059}
_0_128:
        shl (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    2:w               {Compacted,$11.src} //  ALU pipe: int; $292
        shl (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $292
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,@2,$3.src} //  ALU pipe: int; $293
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $293
        store.ugm.d32.a64 (32|M0)  [r10:4]      r46:2              {I@1,$4} // ex_desc:0x0; desc:0x8000584 // $295
// B059: [inDivergent],  Preds:{B058, B057, B053, B051, B050, B049, B048, B005, B004},  Succs:{B060, B061}
_0_076:
        join (32|M0)                         _0_073                                                  // 
L4304:
        sync.nop                             null                             {Compacted,$11.src}    // $297
        add (16|M0)              r6.0<1>:q     r52.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,$10.src} //  ALU pipe: int; $297
        add (16|M16)             r8.0<1>:q     r54.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $297
        mov (16|M0)              r48.0<1>:d    r6.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $298
        mov (16|M16)             r49.0<1>:d    r8.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $299
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r48.0<1;1,0>:ud   r3.2<0;1,0>:ud   {I@1}              //  ALU pipe: int; $302
        mov (16|M0)              r50.0<1>:d    r6.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $300
        mov (16|M16)             r51.0<1>:d    r8.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $301
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r50.0<1;1,0>:d    r3.3<0;1,0>:d    {I@1}              //  ALU pipe: int; $303
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r50.0<1;1,0>:ud   r3.3<0;1,0>:ud                      //  ALU pipe: int; $305
(~f3.0) goto (32|M0)                         _0_073            _0_073                                //  ALU pipe: int; $307
// B060: [inDivergent],  Preds:{B059},  Succs:{B004}
_0_134:
(f3.0)  sel (32|M0)              r6.0<1>:d     r48.0<1;1,0>:d    r28.0<1;1,0>:d                      //  ALU pipe: int; $309
(f3.0)  sel (32|M0)              r8.0<1>:d     r50.0<1;1,0>:d    r30.0<1;1,0>:d                      //  ALU pipe: int; $310
        mov (16|M0)              r52.0<2>:d    r6.0<1;1,0>:d                    {I@2}                //  ALU pipe: int; $313
        mov (16|M16)             r54.0<2>:d    r7.0<1;1,0>:d                                         //  ALU pipe: int; $314
        mov (16|M0)              r52.1<2>:d    r8.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $315
        mov (16|M16)             r54.1<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $316
(W)     jmpi                                 _0_075                                                  // $317
// B061: Preds:{B059, B002},  Succs:{}
_0_073:
        join (32|M0)                         L4552                                                   // 
L4552:
(W)     mov (16|M0)              r127.0<1>:f   r26.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $319
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$12} // wr:1+0, rd:0; end of thread // $319
L4576:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x15:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 274
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 44
//.allAtOneDistNum: 7
//.syncInstCount: 8
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 20
//.AfterReadTokenDepCount: 27
