//.kernel _ZTSN9p42extras8FlatNameILNS_4KindE0ELi32EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 604709628 1620024839 -hashmovs1 0 23 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 604709628 1620024839 -hashmovs1 0 23 -GRFBumpUpNumber 2 "
//.instCount 300
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r100.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r0.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r0.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r100.0)
//.declare V0034 (44)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r100.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r4.6)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.12)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.10)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.11)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0063 (73)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.0)
//.declare V0064 (74)  rf=r size=32 type=ud alias=V0036+0 align=16 words (r100.0)
//.declare V0065 (75)  rf=r size=8 type=ud alias=V0062+0 align=4 words (r5.0)
//.declare V0066 (76)  rf=r size=8 type=d alias=V0062+0 align=4 words (r5.0)
//.declare V0067 (77)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0070 (80)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0072 (82)  rf=r size=128 type=d align=32 words (r101.0)
//.declare P01 (83)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0073 (84)  rf=r size=128 type=ud alias=V0072+0 align=32 words (r101.0)
//.declare V0074 (85)  rf=r size=4 type=ud alias=V0034+0 align=2 words (r2.3)
//.declare V0075 (86)  rf=r size=8 type=uq alias=V0058+0 align=4 words (r4.4)
//.declare V0076 (87)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0077 (88)  rf=r size=4 type=d align=32 words (r4.0)
//.declare P02 (89)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0078 (90)  rf=r size=8 type=uq alias=V0056+0 align=4 words (r4.2)
//.declare V0079 (91)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0081 (93)  rf=r size=256 type=uq align=32 words (r5.0)
//.declare V0082 (94)  rf=r size=256 type=ud alias=V0081+0 align=32 words (r5.0)
//.declare V0083 (95)  rf=r size=8 type=ud alias=V0079+0 align=32 words (r2.0)
//.declare V0084 (96)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0085 (97)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare P03 (99)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0087 (100)  rf=r size=8 type=d align=2 words (r103.0)
//.declare V0088 (101)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.6)
//.declare V0091 (104)  rf=r size=128 type=d align=32 words (r104.0)
//.declare V0092 (105)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0093 (106)  rf=r size=128 type=d align=32 words (r7.0)
//.declare P04 (107)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0094 (108)  rf=r size=128 type=ud alias=V0093+0 align=32 words (r7.0)
//.declare V0097 (111)  rf=r size=8 type=df align=4 words (r1.0)
//.declare V0098 (112)  rf=r size=8 type=uq alias=V0045+0 align=4 words (r2.3)
//.declare V0099 (113)  rf=r size=4 type=f align=4 words (r2.0)
//.declare V0100 (114)  rf=r size=4 type=f align=2 words (r3.1)
//.declare V0101 (115)  rf=r size=8 type=df align=4 words (r4.0)
//.declare V0102 (116)  rf=r size=8 type=df align=4 words (r6.0)
//.declare V0103 (117)  rf=r size=8 type=df align=4 words (r5.0)
//.declare V0104 (118)  rf=r size=8 type=df align=4 words (r9.0)
//.declare V0106 (120)  rf=r size=8 type=df align=4 words (r10.0)
//.declare V0107 (121)  rf=r size=8 type=df align=4 words (r12.0)
//.declare V0109 (123)  rf=r size=4 type=d align=4 words (r13.0)
//.declare V0110 (124)  rf=r size=4 type=ud alias=V0109+0 align=2 words (r13.0)
//.declare V0111 (125)  rf=r size=4 type=d align=32 words (r15.0)
//.declare V0112 (126)  rf=r size=4 type=d align=2 words (r16.0)
//.declare V0113 (127)  rf=r size=8 type=df align=4 words (r18.0)
//.declare V0114 (128)  rf=r size=4 type=ud alias=V0112+0 align=2 words (r16.0)
//.declare V0117 (131)  rf=r size=8 type=df align=4 words (r27.0)
//.declare V0123 (137)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0124 (138)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0125 (139)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0126 (140)  rf=r size=128 type=d align=32 words (r46.0)
//.declare P05 (141)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0127 (142)  rf=r size=128 type=ud alias=V0124+0 align=32 words (r42.0)
//.declare V0128 (143)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0129 (144)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0130 (145)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0137 (152)  rf=r size=128 type=ud alias=V0123+0 align=32 words (r40.0)
//.declare V0138 (153)  rf=r size=8 type=ud alias=V0087+0 align=2 words (r103.0)
//.declare V0141 (156)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0142 (157)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0146 (161)  rf=r size=128 type=d align=32 words (r88.0)
//.declare V0147 (162)  rf=r size=128 type=d align=32 words (r90.0)
//.declare P06 (163)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0148 (164)  rf=r size=128 type=ud alias=V0146+0 align=32 words (r88.0)
//.declare P07 (165)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P08 (166)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0149 (167)  rf=r size=128 type=ud alias=V0147+0 align=32 words (r90.0)
//.declare V0156 (174)  rf=r size=4 type=d align=4 words (r103.2)
//.declare P09 (175)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0157 (176)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0158 (177)  rf=r size=4 type=ud alias=V0156+0 align=2 words (r103.2)
//.declare V0159 (178)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0160 (179)  rf=r size=4 type=ud alias=V0159+0 align=2 words (r3.1)
//.declare V0161 (180)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0162 (181)  rf=r size=128 type=f align=32 words (r5.0)
//.declare V0163 (182)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0164 (183)  rf=r size=4 type=f align=2 words (r10.0)
//.declare V0165 (184)  rf=r size=128 type=f align=32 words (r11.0)
//.declare V0166 (185)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0167 (186)  rf=r size=128 type=ud alias=V0166+0 align=32 words (r13.0)
//.declare V0168 (187)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0169 (188)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0170 (189)  rf=r size=128 type=ud alias=V0169+0 align=32 words (r17.0)
//.declare V0171 (190)  rf=r size=4 type=f align=2 words (r20.0)
//.declare V0172 (191)  rf=r size=4 type=ud alias=V0161+0 align=2 words (r4.0)
//.declare V0173 (192)  rf=r size=128 type=f align=32 words (r21.0)
//.declare V0174 (193)  rf=r size=128 type=ud alias=V0168+0 align=32 words (r15.0)
//.declare V0175 (194)  rf=r size=128 type=f align=32 words (r25.0)
//.declare V0181 (200)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0182 (201)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0183 (202)  rf=r size=128 type=ud alias=V0182+0 align=32 words (r29.0)
//.declare V0184 (203)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0185 (204)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0186 (205)  rf=r size=128 type=d align=32 words (r35.0)
//.declare P10 (206)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0187 (207)  rf=r size=128 type=ud alias=V0186+0 align=32 words (r35.0)
//.declare V0188 (208)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0189 (209)  rf=r size=128 type=d align=32 words (r106.0)
//.declare V0190 (210)  rf=r size=128 type=ud alias=V0189+0 align=32 words (r106.0)
//.declare P11 (211)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P12 (212)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P13 (213)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0191 (214)  rf=r size=4 type=ud alias=V0046+0 align=2 words (r3.0)
//.declare P14 (215)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0195 (219)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0196 (220)  rf=r size=256 type=q align=32 words (r13.0)
//.declare V0197 (221)  rf=r size=128 type=f align=32 words (r109.0)
//.declare V0201 (225)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0202 (226)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0203 (227)  rf=r size=128 type=ud alias=V0202+0 align=32 words (r13.0)
//.declare V0207 (231)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0208 (232)  rf=r size=128 type=d align=32 words (r13.0)
//.declare P15 (233)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0212 (237)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare P16 (238)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0216 (242)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0218 (244)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0219 (245)  rf=r size=128 type=w alias=V0218+0 align=32 words (r14.0)
//.declare V0221 (247)  rf=r size=128 type=d alias=V0197+0 align=32 words (r109.0)
//.declare P17 (248)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P18 (249)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P19 (250)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0222 (251)  rf=r size=4 type=ud alias=V0055+0 align=2 words (r4.2)
//.declare P20 (252)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0226 (256)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0228 (258)  rf=r size=256 type=d align=32 words (r19.0)
//.declare V0230 (260)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0231 (261)  rf=r size=128 type=ud alias=V0230+0 align=32 words (r1.0)
//.declare V0235 (265)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0236 (266)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0240 (270)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare P21 (271)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0244 (275)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare P22 (276)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0245 (277)  rf=r size=128 type=d align=32 words (r1.0)
//.declare P23 (278)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0246 (279)  rf=r size=128 type=ud alias=V0245+0 align=32 words (r1.0)
//.declare V0247 (280)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0248 (281)  rf=r size=128 type=ud alias=V0197+0 align=32 words (r109.0)
//.declare V0249 (282)  rf=r size=128 type=ud alias=V0247+0 align=32 words (r1.0)
//.declare V0250 (283)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0251 (284)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0252 (285)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0253 (286)  rf=r size=128 type=ud alias=V0251+0 align=32 words (r6.0)
//.declare V0254 (287)  rf=r size=128 type=ud alias=V0252+0 align=32 words (r8.0)
//.declare V0255 (288)  rf=r size=64 type=w align=32 words (r108.0)
//.declare V0256 (289)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0257 (290)  rf=r size=128 type=ud alias=V0256+0 align=32 words (r1.0)
//.declare V0262 (295)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0263 (296)  rf=r size=64 type=uw alias=V0255+0 align=32 words (r108.0)
//.declare V0264 (297)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (298)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (299)  rf=r size=4 type=d alias=V0045+0 align=2 words (r2.6)
//.declare  (300)  rf=r size=4 type=d alias=V0045+0 align=2 words (r2.6)
//.declare  (301)  rf=r size=128 type=w alias=V0256+0 align=32 words (r1.0)
//.declare  (304)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (305)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (306)  rf=r size=128 type=uw align=32 words (r9.0)
//.declare  (309)  rf=r size=8 type=df align=4 words (r7.0)
//.declare  (310)  rf=r size=8 type=df align=4 words (r11.0)
//.declare  (311)  rf=r size=64 type=ud align=32 words (r74.0)
//.declare  (312)  rf=r size=64 type=ud align=32 words (r77.0)
//.declare  (313)  rf=r size=128 type=ud align=32 words (r19.0)
//.declare  (314)  rf=r size=128 type=ud align=32 words (r23.0)
//.declare  (315)  rf=r size=128 type=ud align=32 words (r54.0)
//.declare  (316)  rf=r size=128 type=ud align=32 words (r58.0)
//.declare  (317)  rf=r size=4 type=f align=2 words (r9.0)
//.declare  (318)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (319)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (320)  rf=r size=128 type=f align=32 words (r17.0)
//.declare  (321)  rf=r size=128 type=f align=32 words (r19.0)
//.declare  (322)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (323)  rf=r size=128 type=ud align=32 words (r15.0)
//.declare  (324)  rf=r size=128 type=w alias=V0252+0 align=32 words (r8.0)
//.declare  (327)  rf=r size=128 type=q align=32 words (r111.0)
//.declare  (328)  rf=r size=128 type=q align=32 words (r113.0)
//.declare  (331)  rf=r size=128 type=df align=32 words (r21.0)
//.declare  (332)  rf=r size=128 type=df align=32 words (r25.0)
//.declare  (333)  rf=r size=128 type=df align=32 words (r28.0)
//.declare  (334)  rf=r size=128 type=df align=32 words (r30.0)
//.declare  (335)  rf=r size=128 type=df align=32 words (r32.0)
//.declare  (336)  rf=r size=128 type=df align=32 words (r34.0)
//.declare  (337)  rf=r size=128 type=q align=32 words (r36.0)
//.declare  (338)  rf=r size=128 type=q align=32 words (r38.0)
//.declare  (341)  rf=r size=128 type=q align=32 words (r56.0)
//.declare  (342)  rf=r size=128 type=q align=32 words (r60.0)
//.declare  (343)  rf=r size=128 type=d align=32 words (r62.0)
//.declare  (344)  rf=r size=128 type=d align=32 words (r64.0)
//.declare  (345)  rf=r size=128 type=q align=32 words (r66.0)
//.declare  (346)  rf=r size=128 type=q align=32 words (r68.0)
//.declare  (347)  rf=r size=128 type=q align=32 words (r70.0)
//.declare  (348)  rf=r size=128 type=q align=32 words (r72.0)
//.declare  (349)  rf=r size=128 type=q align=32 words (r75.0)
//.declare  (350)  rf=r size=128 type=q align=32 words (r78.0)
//.declare  (351)  rf=r size=128 type=q align=32 words (r84.0)
//.declare  (352)  rf=r size=128 type=q align=32 words (r86.0)
//.declare  (355)  rf=r size=128 type=d align=32 words (r92.0)
//.declare  (356)  rf=r size=128 type=d align=32 words (r94.0)
//.declare  (357)  rf=r size=128 type=q align=32 words (r96.0)
//.declare  (358)  rf=r size=128 type=q align=32 words (r98.0)
//.declare  (359)  rf=r size=128 type=q align=32 words (r115.0)
//.declare  (360)  rf=r size=128 type=q align=32 words (r117.0)
//.declare  (361)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (362)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (365)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (366)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (369)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (370)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (373)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (374)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (377)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (378)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (381)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (382)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (385)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (386)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (387)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (388)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (391)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (392)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (395)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (396)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (399)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (400)  rf=r size=128 type=q align=32 words (r4.0)
//.declare  (403)  rf=r size=128 type=d alias=+0 align=32 words (r111.0)
//.declare  (404)  rf=r size=128 type=d alias=+0 align=32 words (r113.0)
//.declare  (405)  rf=r size=128 type=uq alias=+0 align=32 words (r36.0)
//.declare  (406)  rf=r size=128 type=uq alias=+0 align=32 words (r38.0)
//.declare  (407)  rf=r size=128 type=d alias=+0 align=32 words (r36.0)
//.declare  (408)  rf=r size=128 type=d alias=+0 align=32 words (r38.0)
//.declare  (409)  rf=r size=128 type=d alias=+0 align=32 words (r66.0)
//.declare  (410)  rf=r size=128 type=d alias=+0 align=32 words (r68.0)
//.declare  (411)  rf=r size=128 type=ud alias=+0 align=32 words (r75.0)
//.declare  (412)  rf=r size=128 type=ud alias=+0 align=32 words (r78.0)
//.declare  (413)  rf=r size=128 type=d alias=+0 align=32 words (r75.0)
//.declare  (414)  rf=r size=128 type=d alias=+0 align=32 words (r78.0)
//.declare  (415)  rf=r size=128 type=d alias=+0 align=32 words (r84.0)
//.declare  (416)  rf=r size=128 type=d alias=+0 align=32 words (r86.0)
//.declare  (417)  rf=r size=128 type=d alias=+0 align=32 words (r96.0)
//.declare  (418)  rf=r size=128 type=d alias=+0 align=32 words (r98.0)
//.declare  (419)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare  (420)  rf=r size=128 type=d alias=+0 align=32 words (r17.0)
//.declare r0 (421)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (422)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (423)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (424)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (425)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (426)  rf=r size=128 type=ud align=32 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0038    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0034    | :d       |    0x4 | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x10  | inline+0x10      |
// | V0045    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0046    | :d       |    0x4 | r3       | cti+0x20         |
// | V0047    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0048    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0051    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0052    | :d       |    0x4 | r3+0x30  | cti+0x50         |
// | V0053    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0054    | :q       |    0x8 | r4       | cti+0x60         |
// | V0055    | :d       |    0x4 | r4+0x8   | cti+0x68         |
// | V0056    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0057    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0058    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0059    | :d       |    0x4 | r4+0x28  | cti+0x88         |
// | V0060    | :d       |    0x4 | r4+0x2C  | cti+0x8C         |
// | V0042    | :uq      |    0x8 | r4+0x30  | cti+0x90         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B038}
// _main:
(W)     mov (16|M0)              r100.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r100.2<0;1,0>:uw {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r4.0<1>:ud    r2.0<0;1,0>:ud    r100.1<0;1,0>:ud {Compacted,$1.dst} //  ALU pipe: int; $3
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r100.2<0;1,0>:uw                    //  ALU pipe: int; $3
(W)     mach (1|M0)              r6.0<1>:d     r2.0<0;1,0>:ud    r100.1<0;1,0>:ud                    //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $9
        mov (16|M16)             r9.0<4>:uw    r1.16<1;1,0>:uw                                       //  ALU pipe: int; $9
(W)     mov (1|M0)               r5.0<2>:f     r4.0<0;1,0>:f                    {I@5}                //  ALU pipe: float; $3
(W)     mov (1|M0)               r5.1<2>:d     r6.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $7
        add (16|M0)              r111.0<1>:q   r5.0<0;1,0>:q     r7.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $9
        add (16|M16)             r113.0<1>:q   r5.0<0;1,0>:q     r9.0<4;1,0>:uw                      //  ALU pipe: int; $9
        mov (16|M0)              r101.0<1>:d   r111.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $10
        mov (16|M16)             r102.0<1>:d   r113.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $10
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r101.0<1;1,0>:ud  r2.3<0;1,0>:ud   {I@1}              //  ALU pipe: int; $11
(~f3.0) goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $12
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B038}
_0_045:
(W)     mov (1|M0)               r2.0<1>:uq    r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $14
(W)     load.ugm.d32x1t.a64 (1|M0)  r4:1        [r2:1]             {I@1,$2} // ex_desc:0x0; desc:0x2108580 // $15
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r4.0<0;1,0>:d     0:w               {$2.dst}          //  ALU pipe: int; $16
(f2.0)  goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $17
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B038}
_0_046:
(W)     mov (1|M0)               r2.0<1>:uq    r4.2<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $19
        mov (32|M0)              r9.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $22
        mov (16|M0)              r5.0<2>:f     r2.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $20
        mov (16|M16)             r7.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $20
        mov (16|M0)              r5.1<2>:f     r2.1<0;1,0>:f                                         //  ALU pipe: float; $21
        mov (16|M16)             r7.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $21
        atomic_or.ugm.d32.a64 (32|M0)  r11:2    [r5:4]            r9:2               {A@1,$3} // ex_desc:0x0; desc:0x8200599 // $23
        cmp (32|M0)   (eq)f1.0   null<1>:d     r11.0<1;1,0>:d    0:w               {$3.dst}          //  ALU pipe: int; $25
(~f1.0) goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $26
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B007}
_0_047:
        or (16|M0)               r7.0<1>:d     r111.1<2;1,0>:d   r2.7<0;1,0>:d    {Compacted}        //  ALU pipe: int; $33
        or (16|M16)              r8.0<1>:d     r113.1<2;1,0>:d   r2.7<0;1,0>:d    {Compacted}        //  ALU pipe: int; $34
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r7.0<1;1,0>:ud    0x1:uw              {I@1}           //  ALU pipe: int; $35
(W)     mov (2|M0)               r103.0<1>:d   r2.6<1;1,0>:d                    {Compacted}          //  ALU pipe: int; $28
        mov (16|M0)              r104.0<1>:d   r111.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $29
        mov (16|M16)             r105.0<1>:d   r113.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $30
        mov (16|M0)              r5.0<1>:d     r111.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $31
        mov (16|M16)             r6.0<1>:d     r113.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $32
(f0.0)  goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $36
// B006: [inDivergent],  Preds:{B005},  Succs:{B011}
_0_049:
(W)     mov (1|M0)               r1.0<1>:df    r2.3<0;1,0>:uq                                        //  ALU pipe: long; $40
(W)     mov (1|M0)               r5.0<1>:df    0x3FF0000000000000:df                              {I@3} //  ALU pipe: long; $44
(W)     mov (1|M0)               r2.0<2>:f     r1.0<0;1,0>:df                   {L@2}                //  ALU pipe: float; $41
(W)     mov (1|M0)               r7.0<1>:df    0xBCF0000000000000:df                                 //  ALU pipe: long; $47
(W)     math.inv (1|M0)          r3.1<1>:f     r2.0<0;1,0>:f                    {F@1}                //  ALU pipe: math; $42
(W)     mov (1|M0)               r4.0<1>:df    r3.1<0;1,0>:f                    {M@1}                //  ALU pipe: long; $43
(W)     mov (1|M0)               r11.0<1>:df   0x0:df                                                //  ALU pipe: long; $50
(W)     mad (1|M0)               r6.0<1>:df    r5.0<0;0>:df      r4.0<0;0>:df      -r1.0<0>:df      {A@2} //  ALU pipe: long; $45
        mov (16|M0)              r19.0<2>:ud   r101.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $55
(W)     add (1|M0)               r9.0<1>:df    r6.0<0;1,0>:df    r7.0<0;1,0>:df   {Compacted,L@1}    //  ALU pipe: long; $47
        mov (16|M16)             r23.0<2>:ud   r102.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $55
(W)     mad (1|M0)               r10.0<1>:df   r4.0<0;0>:df      r9.0<0;0>:df      r4.0<0>:df       {L@1} //  ALU pipe: long; $48
(W)     mov (1|M0)               r27.0<1>:df   0x41F0000000000000:df                                 //  ALU pipe: long; $56
(W)     mul (1|M0)               r12.0<1>:df   r10.0<0;1,0>:df   r11.0<0;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $50
        mov (16|M0)              r21.0<1>:df   r19.0<2;1,0>:ud                  {I@2}                //  ALU pipe: long; $55
(W)     mov (1|M0)               r13.0<2>:ud   r12.0<0;1,0>:df                  {L@2}                //  ALU pipe: int; $51
        mov (16|M16)             r25.0<1>:df   r23.0<2;1,0>:ud                  {I@2}                //  ALU pipe: long; $55
(W)     mul (1|M0)               acc0.0<1>:d   r13.0<0;1,0>:d    r2.12<0;1,0>:uw  {I@1}              //  ALU pipe: int; $52
(W)     macl (1|M0)              r15.0<1>:d    r13.0<0;1,0>:d    r2.6<0;1,0>:d    {Compacted}        //  ALU pipe: int; $53
        mov (32|M0)              r62.0<1>:f    r104.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $71
(W)     mov (1|M0)               r16.0<1>:d    -r15.0<0;1,0>:d                  {Compacted,I@1}      //  ALU pipe: int; $53
        mov (32|M0)              r64.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $72
(W)     mov (1|M0)               r18.0<1>:df   r16.0<0;1,0>:ud                  {I@2}                //  ALU pipe: long; $54
        mov (32|M0)              r82.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $83
        mad (16|M0)              r28.0<1>:df   r21.0<1;0>:df     r27.0<0;0>:df     r18.0<0>:df      {Compacted,L@1} //  ALU pipe: long; $57
        mad (16|M16)             r30.0<1>:df   r25.0<1;0>:df     r27.0<0;0>:df     r18.0<0>:df      {Compacted} //  ALU pipe: long; $57
        mul (16|M0)              r32.0<1>:df   r10.0<0;1,0>:df   r28.0<1;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $58
        mul (16|M16)             r34.0<1>:df   r10.0<0;1,0>:df   r30.0<1;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $58
        mov (16|M0)              r36.0<1>:uq   r32.0<1;1,0>:df                  {L@2}                //  ALU pipe: int; $59
        mov (16|M16)             r38.0<1>:uq   r34.0<1;1,0>:df                  {L@1}                //  ALU pipe: int; $59
        mov (16|M0)              r42.0<1>:d    r36.1<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $62
        mov (16|M16)             r43.0<1>:d    r38.1<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $63
        mov (16|M0)              r44.0<1>:d    r36.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $64
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r42.0<1;1,0>:ud   0x1:uw              {I@2}           //  ALU pipe: int; $66
        mov (16|M16)             r45.0<1>:d    r38.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $64
(W)     mul (16|M0)              acc0.0<1>:d   r44.0<1;1,0>:d    r2.14<0;1,0>:uw  {I@3}              //  ALU pipe: int; $65
        macl (16|M0)             r46.0<1>:d    r44.0<1;1,0>:d    r2.7<0;1,0>:d    {Compacted}        //  ALU pipe: int; $65
(W)     mul (16|M16)             acc0.0<1>:d   r45.0<1;1,0>:d    r2.14<0;1,0>:uw  {I@3}              //  ALU pipe: int; $65
(~f3.0) sel (32|M0)              r48.0<1>:d    r2.6<0;1,0>:d     0:w                                 //  ALU pipe: int; $67
        macl (16|M16)            r47.0<1>:d    r45.0<1;1,0>:d    r2.7<0;1,0>:d    {Compacted}        //  ALU pipe: int; $66
        mov (16|M0)              r40.0<1>:d    r36.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $60
        add (32|M0)              r50.0<1>:d    r48.0<1;1,0>:d    r46.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $68
        mov (16|M16)             r41.0<1>:d    r38.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $61
(W)     mul (16|M0)              acc0.0<1>:ud  r40.0<1;1,0>:ud   r103.0<0;1,0>:uw {I@3}              //  ALU pipe: int; $78
        add3 (32|M0)             r52.0<1>:d    0:w                -r15.0<0;0>:d     -r50.0<1>:d      {I@3} //  ALU pipe: int; $69
        macl (16|M0)             r74.0<1>:ud   r40.0<1;1,0>:ud   r103.0<0;1,0>:ud {Compacted}        //  ALU pipe: int; $79
(W)     mul (16|M16)             acc0.0<1>:ud  r41.0<1;1,0>:ud   r103.0<0;1,0>:uw {I@4}              //  ALU pipe: int; $79
        macl (16|M16)            r77.0<1>:ud   r41.0<1;1,0>:ud   r103.0<0;1,0>:ud {Compacted}        //  ALU pipe: int; $80
(W)     mul (16|M0)              acc0.0<1>:ud  r40.0<1;1,0>:ud   r103.0<0;1,0>:uw                    //  ALU pipe: int; $80
        mach (16|M0)             r80.0<1>:d    r40.0<1;1,0>:ud   r103.0<0;1,0>:ud                    //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r41.0<1;1,0>:ud   r103.0<0;1,0>:uw                    //  ALU pipe: int; $80
        mov (16|M0)              r54.0<2>:ud   r52.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $70
        mov (16|M16)             r58.0<2>:ud   r53.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $70
        mach (16|M16)            r81.0<1>:d    r41.0<1;1,0>:ud   r103.0<0;1,0>:ud                    //  ALU pipe: int; $82
        mov (16|M0)              r66.0<2>:d    r62.0<1;1,0>:d                   {F@1}                //  ALU pipe: int; $73
        mov (16|M16)             r68.0<2>:d    r63.0<1;1,0>:d                                        //  ALU pipe: int; $74
        shl (16|M0)              r56.0<1>:q    r54.0<2;1,0>:d    32:w               {I@5}            //  ALU pipe: int; $70
        shl (16|M16)             r60.0<1>:q    r58.0<2;1,0>:d    32:w               {I@5}            //  ALU pipe: int; $70
        mov (16|M0)              r66.1<2>:d    r64.0<1;1,0>:d                                        //  ALU pipe: int; $75
        mov (16|M16)             r68.1<2>:d    r65.0<1;1,0>:d                                        //  ALU pipe: int; $76
        mov (16|M0)              r75.0<2>:ud   r74.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $79
        mov (16|M16)             r78.0<2>:ud   r77.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $80
        add (16|M0)              r70.0<1>:q    r56.0<1;1,0>:q    r66.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $77
        add (16|M16)             r72.0<1>:q    r60.0<1;1,0>:q    r68.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $77
        add (16|M0)              r75.1<2>:d    r80.0<1;1,0>:d    r82.0<1;1,0>:d                      //  ALU pipe: int; $84
        add (16|M16)             r78.1<2>:d    r81.0<1;1,0>:d    r83.0<1;1,0>:d                      //  ALU pipe: int; $85
        add (16|M0)              r84.0<1>:q    r70.0<1;1,0>:q    -r75.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $86
        add (16|M16)             r86.0<1>:q    r72.0<1;1,0>:q    -r78.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $86
        mov (16|M0)              r88.0<1>:d    r84.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $87
        mov (16|M16)             r89.0<1>:d    r86.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $88
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r88.0<1;1,0>:ud   r103.0<0;1,0>:ud {I@1}              //  ALU pipe: int; $91
        mov (16|M0)              r90.0<1>:d    r84.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $89
        mov (16|M16)             r91.0<1>:d    r86.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $90
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r90.0<1;1,0>:d    r103.1<0;1,0>:d  {I@1}              //  ALU pipe: int; $92
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r90.0<1;1,0>:ud   r103.1<0;1,0>:ud                    //  ALU pipe: int; $94
(~f0.0) sel (32|M0)              r92.0<1>:d    r103.0<0;1,0>:d   0:w                                 //  ALU pipe: int; $96
(~f0.0) sel (32|M0)              r94.0<1>:d    r103.1<0;1,0>:d   0:w                                 //  ALU pipe: int; $97
        mov (16|M0)              r96.0<2>:d    r92.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $100
        mov (16|M16)             r98.0<2>:d    r93.0<1;1,0>:d                                        //  ALU pipe: int; $101
        mov (16|M0)              r96.1<2>:d    r94.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $102
        mov (16|M16)             r98.1<2>:d    r95.0<1;1,0>:d                                        //  ALU pipe: int; $103
        add (16|M0)              r115.0<1>:q   r84.0<1;1,0>:q    -r96.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $104
        add (16|M16)             r117.0<1>:q   r86.0<1;1,0>:q    -r98.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $104
        goto (32|M0)                         _0_048            _0_050                                // $105
// B007: [inDivergent],  Preds:{B005},  Succs:{B008, B009}
_0_048:
        join (32|M0)                         _0_050                                                  // 
L1728:
(W)     mov (1|M0)               r103.2<2>:d   r2.3<0;1,0>:q                                         //  ALU pipe: int; $107
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r103.2<0;1,0>:d   0:w               {I@1}             //  ALU pipe: int; $108
(W&f2.0) jmpi                                _0_051                                                  //  ALU pipe: int; $109
// B008: [inDivergent],  Preds:{B007},  Succs:{B010}
_0_052:
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $111
(W)     mov (1|M0)               r2.0<1>:f     r103.2<0;1,0>:ud                 {A@1}                //  ALU pipe: float; $112
(W)     mov (1|M0)               r9.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $117
(W)     math.inv (1|M0)          r8.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $116
        mov (32|M0)              r5.0<1>:f     r101.0<1;1,0>:ud                                      //  ALU pipe: float; $115
(W)     mad (1|M0)               r10.0<1>:f    r8.0<0;0>:f       r9.0<0;0>:f       r8.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $117
        mov (32|M0)              r13.0<1>:ud   r5.0<1;1,0>:f                    {F@2}                //  ALU pipe: int; $119
        mul (32|M0)              r11.0<1>:f    r5.0<1;1,0>:f     r10.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $118
(W)     mov (1|M0)               r3.1<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $113
        add (32|M0)              r15.0<1>:d    r101.0<1;1,0>:d   -r13.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $120
        mov (32|M0)              r17.0<1>:ud   r11.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $121
(W)     add (1|M0)               r4.0<1>:d     r103.2<0;1,0>:d   -r3.1<0;1,0>:d   {I@3}              //  ALU pipe: int; $114
        mov (32|M0)              r25.0<1>:f    r17.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $124
        mov (32|M0)              r21.0<1>:f    r15.0<1;1,0>:ud                                       //  ALU pipe: float; $123
(W)     mov (1|M0)               r20.0<1>:f    r4.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $122
        mad (32|M0)              acc0.0<1>:f   r5.0<1;0>:f       r25.0<1;0>:f      -r2.0<0>:f       {F@3} //  ALU pipe: float; $126
        mad (32|M0)              acc2.0<1>:f   r21.0<1;0>:f      r25.0<1;0>:f      -r20.0<0>:f      {F@2} //  ALU pipe: float; $128
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $129
        mul (32|M0)              r27.0<1>:f    r10.0<0;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $130
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $131
        mov (32|M0)              r29.0<1>:ud   r27.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $132
        add (32|M0)              r31.0<1>:d    r29.0<1;1,0>:d    r17.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $133
(W)     mul (16|M0)              acc0.0<1>:d   r31.0<1;1,0>:d    r103.4<0;1,0>:uw {I@1}              //  ALU pipe: int; $134
        macl (16|M0)             r33.0<1>:d    r31.0<1;1,0>:d    r103.2<0;1,0>:d  {Compacted}        //  ALU pipe: int; $134
(W)     mul (16|M16)             acc0.0<1>:d   r32.0<1;1,0>:d    r103.4<0;1,0>:uw                    //  ALU pipe: int; $134
        macl (16|M16)            r34.0<1>:d    r32.0<1;1,0>:d    r103.2<0;1,0>:d  {Compacted}        //  ALU pipe: int; $135
        add (32|M0)              r35.0<1>:d    r101.0<1;1,0>:d   -r33.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $135
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r35.0<1;1,0>:ud   r103.2<0;1,0>:ud {I@1}              //  ALU pipe: int; $136
(~f1.0) sel (32|M0)              r38.0<1>:d    r103.2<0;1,0>:d   0:w                                 //  ALU pipe: int; $137
        add3 (32|M0)             r106.0<1>:d   r101.0<1;0>:d     -r33.0<1;0>:d     -r38.0<1>:d      {I@1} //  ALU pipe: int; $138
(W)     jmpi                                 _0_053                                                  // $139
// B009: [inDivergent],  Preds:{B007},  Succs:{B010}
_0_051:
        mov (32|M0)              r106.0<1>:d   -1:w                               {Compacted}        //  ALU pipe: int; $141
// B010: [inDivergent],  Preds:{B009, B008},  Succs:{B011}
_0_053:
        mov (16|M0)              r5.0<2>:ud    r106.0<1;1,0>:ud                 {Compacted,I@1}      //  ALU pipe: int; $143
        mov (16|M16)             r7.0<2>:ud    r107.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $143
        mov (16|M0)              r115.0<1>:q   r5.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $143
        mov (16|M16)             r117.0<1>:q   r7.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $143
// B011: [inDivergent],  Preds:{B010, B006},  Succs:{B012, B019}
_0_050:
        join (32|M0)                         _0_044                                                  // 
L2264:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $145
(W&f0.0) jmpi                                _0_054                                                  //  ALU pipe: int; $146
// B012: [inDivergent],  Preds:{B011},  Succs:{B013, B018}
_0_055:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $148
(W&f3.0) jmpi                                _0_056                                                  //  ALU pipe: int; $149
// B013: [inDivergent],  Preds:{B012},  Succs:{B014, B017}
_0_057:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r3.0<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $151
(W&f2.0) jmpi                                _0_058                                                  //  ALU pipe: int; $152
// B014: [inDivergent],  Preds:{B013},  Succs:{B015, B016}
_0_059:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.0<0;1,0>:d     4:w                                 //  ALU pipe: int; $154
(W&~f1.0) jmpi                               _0_060                                                  //  ALU pipe: int; $155
// B015: [inDivergent],  Preds:{B014},  Succs:{B024}
_0_061:
        shl (16|M0)              r5.0<1>:q     r115.0<1;1,0>:q   3:w               {Compacted,I@7}   //  ALU pipe: int; $157
        shl (16|M16)             r7.0<1>:q     r117.0<1;1,0>:q   3:w               {Compacted,I@7}   //  ALU pipe: int; $157
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $158
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $158
        load.ugm.d64.a64 (32|M0)  r13:4         [r9:4]             {I@1,$4} // ex_desc:0x0; desc:0x8400780 // $160
        mov (16|M0)              r17.0<2>:f    r13.0<1;1,0>:q                   {$4.dst}             //  ALU pipe: float; $161
        mov (16|M16)             r19.0<2>:f    r15.0<1;1,0>:q                                        //  ALU pipe: float; $161
        mov (16|M0)              r109.0<1>:ud  r17.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $161
        mov (16|M16)             r110.0<1>:ud  r19.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $161
(W)     jmpi                                 _0_062                                                  // $162
// B016: [inDivergent],  Preds:{B014},  Succs:{B024}
_0_060:
        mov (32|M0)              r109.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $164
(W)     jmpi                                 _0_062                                                  // $165
// B017: [inDivergent],  Preds:{B013},  Succs:{B024}
_0_058:
        shl (16|M0)              r5.0<1>:q     r115.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $167
        shl (16|M16)             r7.0<1>:q     r117.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $167
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $168
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $168
        load.ugm.d32.a64 (32|M0)  r13:2         [r9:4]             {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $170
        mov (32|M0)              r109.0<1>:f   r13.0<1;1,0>:ud                  {$5.dst}             //  ALU pipe: float; $171
(W)     jmpi                                 _0_062                                                  // $172
// B018: [inDivergent],  Preds:{B012},  Succs:{B024}
_0_056:
        shl (16|M0)              r5.0<1>:q     r115.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $174
        shl (16|M16)             r7.0<1>:q     r117.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $174
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $175
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $175
        load.ugm.d32.a64 (32|M0)  r13:2         [r9:4]             {A@1,$6} // ex_desc:0x0; desc:0x8200580 // $177
        mov (32|M0)              r109.0<1>:f   r13.0<1;1,0>:d                   {$6.dst}             //  ALU pipe: float; $178
(W)     jmpi                                 _0_062                                                  // $179
// B019: [inDivergent],  Preds:{B011},  Succs:{B020, B021}
_0_054:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.0<0;1,0>:d     1:w                                 //  ALU pipe: int; $181
(W&f0.0) jmpi                                _0_063                                                  //  ALU pipe: int; $182
// B020: [inDivergent],  Preds:{B019},  Succs:{B024}
_0_064:
        shl (16|M0)              r5.0<1>:q     r115.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $184
        shl (16|M16)             r7.0<1>:q     r117.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $184
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $185
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $185
        load.ugm.d32.a64 (32|M0)  r109:2        [r9:4]             {A@1,$7} // ex_desc:0x0; desc:0x8200580 // $187
(W)     jmpi                                 _0_062                                                  // $188
// B021: [inDivergent],  Preds:{B019},  Succs:{B022, B023}
_0_063:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $190
(W&~f3.0) jmpi                               _0_065                                                  //  ALU pipe: int; $191
// B022: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_066:
        shl (16|M0)              r5.0<1>:q     r115.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $193
        shl (16|M16)             r7.0<1>:q     r117.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $193
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $194
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $194
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r9:4]             {I@1,$8} // ex_desc:0x0; desc:0x8200B80 // $196
        shl (32|M0)              r109.0<1>:d   r14.0<1;1,0>:ud   16:w               {$8.dst}         //  ALU pipe: int; $197
(W)     jmpi                                 _0_062                                                  // $198
// B023: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_065:
        mov (32|M0)              r109.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $200
// B024: [inDivergent],  Preds:{B023, B022, B020, B018, B017, B016, B015},  Succs:{B025, B031}
_0_062:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $202
(W&f2.0) jmpi                                _0_067                                                  //  ALU pipe: int; $203
// B025: [inDivergent],  Preds:{B024},  Succs:{B026, B030}
_0_068:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $205
(W&f1.0) jmpi                                _0_069                                                  //  ALU pipe: int; $206
// B026: [inDivergent],  Preds:{B025},  Succs:{B027, B029}
_0_070:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r4.2<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $208
(W&f0.0) jmpi                                _0_071                                                  //  ALU pipe: int; $209
// B027: [inDivergent],  Preds:{B026},  Succs:{B028, B038}
_0_072:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r4.2<0;1,0>:d     4:w                                 //  ALU pipe: int; $211
(~f3.0) goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $212
// B028: [inDivergent],  Preds:{B027},  Succs:{B038}
_0_073:
        mov (16|M0)              r11.0<2>:ud   r109.0<1;1,0>:ud                 {Compacted,@7,$7.dst} //  ALU pipe: int; $217
        mov (16|M16)             r15.0<2>:ud   r110.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $217
        shl (16|M0)              r1.0<1>:q     r111.0<1;1,0>:q   3:w               {Compacted}       //  ALU pipe: int; $214
        shl (16|M16)             r5.0<1>:q     r113.0<1;1,0>:q   3:w               {Compacted}       //  ALU pipe: int; $214
        mov (16|M0)              r13.0<1>:q    r11.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $217
        mov (16|M16)             r17.0<1>:q    r15.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $217
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $215
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $215
        mov (16|M0)              r19.0<1>:d    r13.0<2;1,0>:d                   {Compacted,I@4}      //  ALU pipe: int; $218
        mov (16|M0)              r21.0<1>:d    r13.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $220
        mov (16|M16)             r20.0<1>:d    r17.0<2;1,0>:d                   {Compacted,I@5}      //  ALU pipe: int; $219
        mov (16|M16)             r22.0<1>:d    r17.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $221
        store.ugm.d32x2.a64 (32|M0)  [r7:4]     r19:4              {I@1,$9} // ex_desc:0x0; desc:0x8001584 // $222
        goto (32|M0)                         _0_044            _0_044                                // $223
// B029: [inDivergent],  Preds:{B026},  Succs:{B038}
_0_071:
        shl (16|M0)              r5.0<1>:q     r111.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $226
        shl (16|M16)             r7.0<1>:q     r113.0<1;1,0>:q   2:w               {Compacted,$9.src} //  ALU pipe: int; $226
        mov (32|M0)              r1.0<1>:ud    r109.0<1;1,0>:f                  {$7.dst}             //  ALU pipe: int; $225
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $227
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $227
        store.ugm.d32.a64 (32|M0)  [r9:4]       r1:2               {I@1,$10} // ex_desc:0x0; desc:0x8000584 // $229
        goto (32|M0)                         _0_044            _0_044                                // $230
// B030: [inDivergent],  Preds:{B025},  Succs:{B038}
_0_069:
        shl (16|M0)              r5.0<1>:q     r111.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $233
        shl (16|M16)             r7.0<1>:q     r113.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $233
        sync.nop                             null                             {Compacted,$10.src}    // $232
        mov (32|M0)              r1.0<1>:d     r109.0<1;1,0>:f                  {$7.dst}             //  ALU pipe: int; $232
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $234
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $234
        store.ugm.d32.a64 (32|M0)  [r9:4]       r1:2               {I@1,$11} // ex_desc:0x0; desc:0x8000584 // $236
        goto (32|M0)                         _0_044            _0_044                                // $237
// B031: [inDivergent],  Preds:{B024},  Succs:{B032, B033}
_0_067:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.2<0;1,0>:d     1:w                                 //  ALU pipe: int; $239
(W&f2.0) jmpi                                _0_074                                                  //  ALU pipe: int; $240
// B032: [inDivergent],  Preds:{B031},  Succs:{B038}
_0_075:
        shl (16|M0)              r1.0<1>:q     r111.0<1;1,0>:q   2:w               {Compacted,$11.src} //  ALU pipe: int; $242
        shl (16|M16)             r5.0<1>:q     r113.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $242
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $243
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $243
        store.ugm.d32.a64 (32|M0)  [r7:4]       r109:2             {I@1,$7} // ex_desc:0x0; desc:0x8000584 // $245
        goto (32|M0)                         _0_044            _0_044                                // $246
// B033: [inDivergent],  Preds:{B031},  Succs:{B034, B038}
_0_074:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $248
(~f1.0) goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $249
// B034: [inDivergent],  Preds:{B033},  Succs:{B035, B036}
_0_076:
        sync.nop                             null                             {Compacted,$11.src}    // $251
        and (32|M0)              r1.0<1>:d     r109.0<1;1,0>:d   2147483647:d               {$7.dst} //  ALU pipe: int; $251
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $252
(f0.0)  goto (32|M0)                         _0_077            _0_077                                //  ALU pipe: int; $253
// B035: [inDivergent],  Preds:{B034},  Succs:{B037}
_0_078:
        shr (32|M0)              r1.0<1>:ud    r109.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $255
        and (32|M0)              r4.0<1>:d     r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $256
        add3 (32|M0)             r6.0<1>:d     r4.0<1;0>:d       r109.0<1;0>:d     32767:w               {@1,$7.src} //  ALU pipe: int; $257
        shr (32|M0)              r8.0<1>:ud    r6.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $258
        mov (32|M0)              r108.0<1>:w   r8.0<2;1,0>:w                    {I@1}                //  ALU pipe: int; $259
        goto (32|M0)                         _0_077            _0_079                                // $260
// B036: [inDivergent],  Preds:{B034},  Succs:{B037}
_0_077:
        join (32|M0)                         _0_079                                                  // 
L3632:
        shr (32|M0)              r1.0<1>:ud    r109.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $262
        or (32|M0)               r108.0<1>:w   r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $264
// B037: [inDivergent],  Preds:{B036, B035},  Succs:{B038}
_0_079:
        join (32|M0)                         _0_044                                                  // 
L3680:
        shl (16|M0)              r1.0<1>:q     r111.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $266
        shl (16|M16)             r4.0<1>:q     r113.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $266
        mov (32|M0)              r10.0<1>:ud   r108.0<1;1,0>:uw                 {@4,$7.src}          //  ALU pipe: int; $269
        add (16|M0)              r6.0<1>:q     r1.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $267
        add (16|M16)             r8.0<1>:q     r4.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $267
        store.ugm.d16u32.a64 (32|M0)  [r6:4]    r10:2              {I@1,$12} // ex_desc:0x0; desc:0x8000B84 // $270
// B038: Preds:{B037, B033, B032, B030, B029, B028, B027, B004, B003, B002},  Succs:{}
_0_044:
        join (32|M0)                         L3760                                                   // 
L3760:
(W)     mov (16|M0)              r127.0<1>:f   r100.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $272
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$13} // wr:1+0, rd:0; end of thread // $272
L3784:
(W)     mov (16|M0)              null<1>:ud    0x240B22FC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x608F9E07:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x17:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 249
//.accSubDef: 3
//.accSubUse: 3
//.accSubCandidateDef: 3
//.accSubCandidateUse: 3
//
//
//.singlePipeAtOneDistNum: 44
//.allAtOneDistNum: 12
//.syncInstCount: 2
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 12
//.AfterReadTokenDepCount: 8
