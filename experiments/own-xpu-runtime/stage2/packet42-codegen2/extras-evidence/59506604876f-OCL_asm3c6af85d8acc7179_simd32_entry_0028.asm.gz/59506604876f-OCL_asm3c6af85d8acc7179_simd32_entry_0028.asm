//.kernel _ZTSN9p42extras8FlatNameILNS_4KindE5ELi0EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 28 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 28 -GRFBumpUpNumber 2 "
//.instCount 39
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r3.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.4)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r3.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r3.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=uq align=4 words (r4.7)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.8)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r4.4)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r4.12)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.13)
//.declare V0061 (71)  rf=r size=8 type=uq alias=V0055+0 align=4 words (r4.3)
//.declare V0062 (72)  rf=r size=8 type=uq alias=V0056+0 align=4 words (r4.4)
//.declare V0063 (73)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r4.5)
//.declare V0064 (74)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0066 (76)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0067 (77)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0068 (78)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0069 (79)  rf=r size=4 type=d align=32 words (r7.0)
//.declare P01 (80)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P02 (81)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0070 (82)  rf=r size=8 type=uq align=32 words (r10.0)
//.declare V0071 (83)  rf=r size=4 type=d align=32 words (r9.0)
//.declare P03 (84)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0072 (85)  rf=r size=4 type=ud alias=V0071+0 align=32 words (r9.0)
//.declare V0073 (86)  rf=r size=4 type=ud alias=V0059+0 align=2 words (r4.13)
//.declare V0074 (87)  rf=r size=8 type=uq align=32 words (r12.0)
//.declare V0076 (89)  rf=r size=256 type=uq align=32 words (r13.0)
//.declare V0077 (90)  rf=r size=256 type=ud alias=V0076+0 align=32 words (r13.0)
//.declare V0078 (91)  rf=r size=8 type=ud alias=V0074+0 align=32 words (r12.0)
//.declare V0079 (92)  rf=r size=128 type=d align=32 words (r17.0)
//.declare  (93)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare r0 (94)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (95)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (96)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (97)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (98)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (99)  rf=r size=128 type=ud align=32 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0037    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0048    | :d       |    0x4 | r3+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0050    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r3+0x38  | cti+0x58         |
// | V0052    | :q       |    0x8 | r4       | cti+0x60         |
// | V0053    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0054    | :d       |    0x4 | r4+0x10  | cti+0x70         |
// | V0055    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0056    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0057    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0058    | :d       |    0x4 | r4+0x30  | cti+0x90         |
// | V0059    | :d       |    0x4 | r4+0x34  | cti+0x94         |
// | V0041    | :uq      |    0x8 | r4+0x38  | cti+0x98         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B005}
// _main:
(W)     mov (16|M0)              r3.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted,$1.dst}   //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r8.0<1>:uq    r4.5<0;1,0>:uq                   {Compacted,A@1}      //  ALU pipe: int; $5
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r3.2<0;1,0>:uw   {I@3}              //  ALU pipe: int; $2
(W)     load.ugm.d32x1t.a64 (1|M0)  r7:1        [r8:1]             {I@2,$2} // ex_desc:0x0; desc:0x2108580 // $6
(W)     macl (1|M0)              r4.0<1>:d     r2.3<0;1,0>:d     r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $4
        add (32|M0)              r5.0<1>:d     r4.0<0;1,0>:d     r1.0<1;1,0>:uw   {@1,$0.dst}        //  ALU pipe: int; $4
        cmp (32|M0)   (eq)f1.0   null<1>:d     r5.0<1;1,0>:d     -r2.0<0;1,0>:d   {I@1}              //  ALU pipe: int; $7
(f1.0)  cmp (32|M0)   (ne)f1.0   null<1>:d     r7.0<0;1,0>:d     0:w               {$2.dst}          //  ALU pipe: int; $8
(~f1.0) goto (32|M0)                         _0_006            _0_006                                //  ALU pipe: int; $10
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_007:
(W)     mov (1|M0)               r10.0<1>:uq   r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $12
(W)     load.ugm.d32x1t.a64 (1|M0)  r9:1        [r10:1]            {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $13
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r9.0<0;1,0>:ud    r4.13<0;1,0>:ud  {$3.dst}           //  ALU pipe: int; $14
(f0.0)  goto (32|M0)                         _0_006            _0_006                                //  ALU pipe: int; $15
// B004: [inDivergent],  Preds:{B003},  Succs:{B005}
_0_008:
(W)     mov (1|M0)               r12.0<1>:uq   r4.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $17
        mov (32|M0)              r17.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $20
        mov (16|M0)              r13.0<2>:f    r12.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $18
        mov (16|M16)             r15.0<2>:f    r12.0<0;1,0>:f                                        //  ALU pipe: float; $18
        mov (16|M0)              r13.1<2>:f    r12.1<0;1,0>:f                                        //  ALU pipe: float; $19
        mov (16|M16)             r15.1<2>:ud   r12.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $19
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r13:4]          r17:2              {A@1,$4} // ex_desc:0x0; desc:0x800058B // $21
// B005: Preds:{B004, B003, B002},  Succs:{}
_0_006:
        join (32|M0)                         L480                                                    // 
L480:
(W)     mov (16|M0)              r127.0<1>:f   r3.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $23
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$5} // wr:1+0, rd:0; end of thread // $23
L504:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1C:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 30
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 8
//.allAtOneDistNum: 4
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 4
//.AfterReadTokenDepCount: 1
