//.kernel _ZTSZZNK6round26KernelILN2ng2OpE11ELi1EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 2915723252 4281227609 -hashmovs1 0 3 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 2915723252 4281227609 -hashmovs1 0 3 -GRFBumpUpNumber 2 "
//.instCount 381
//.RA type	LOCAL_FIRST_FIT_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r22.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.10)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.11)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.12)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.13)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r22.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.1)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r22.0)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=4 type=d align=2 words (r2.4)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r2.5)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r2.6)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r2.7)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0071 (81)  rf=r size=16 type=d align=2 words (r2.6)
//.declare V0072 (82)  rf=r size=8 type=uq alias=V0065+0 align=32 words (r5.1)
//.declare P01 (83)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P02 (84)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0073 (85)  rf=r size=8 type=uq alias=V0068+0 align=32 words (r5.4)
//.declare V0074 (86)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0075 (87)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P03 (88)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0076 (89)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0077 (90)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0079 (92)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0080 (93)  rf=r size=256 type=ud alias=V0079+0 align=32 words (r6.0)
//.declare V0081 (94)  rf=r size=8 type=ud alias=V0077+0 align=32 words (r2.0)
//.declare V0082 (95)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0083 (96)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P04 (98)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0086 (100)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (101)  rf=r size=64 type=ud align=32 words (r4.0)
//.declare  (102)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (103)  rf=r size=32 type=ud align=32 words (r7.0)
//.declare V0087 (104)  rf=r size=4 type=f align=32 words (r3.0)
//.declare V0088 (105)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare P05 (106)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0089 (107)  rf=r size=8 type=uq alias=V0067+0 align=32 words (r5.3)
//.declare  (108)  rf=r size=64 type=ud align=32 words (r4.0)
//.declare  (109)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (110)  rf=r size=32 type=ud align=32 words (r7.0)
//.declare V0090 (111)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0091 (112)  rf=r size=4 type=d align=32 words (r23.0)
//.declare V0092 (113)  rf=r size=4 type=d align=2 words (r2.4)
//.declare P06 (114)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P07 (115)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P08 (116)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0093 (117)  rf=r size=4 type=d align=2 words (r23.1)
//.declare V0094 (118)  rf=r size=4 type=d align=2 words (r23.2)
//.declare V0095 (119)  rf=r size=4 type=d align=2 words (r23.3)
//.declare P09 (120)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0096 (121)  rf=r size=4 type=ud alias=V0093+0 align=2 words (r23.1)
//.declare V0097 (122)  rf=r size=4 type=d align=2 words (r26.0)
//.declare V0098 (123)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0099 (124)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0100 (125)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0101 (126)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0102 (127)  rf=r size=4 type=ud alias=V0100+0 align=2 words (r3.1)
//.declare V0103 (128)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0104 (129)  rf=r size=4 type=ud alias=V0103+0 align=2 words (r3.4)
//.declare V0105 (130)  rf=r size=4 type=d alias=+0 align=2 words (r4.4)
//.declare V0106 (131)  rf=r size=4 type=f align=2 words (r4.1)
//.declare V0107 (132)  rf=r size=32 type=ud alias=V0036+0 align=32 words (r22.0)
//.declare V0108 (133)  rf=r size=4 type=f align=2 words (r4.2)
//.declare V0109 (134)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0110 (135)  rf=r size=4 type=f align=2 words (r6.1)
//.declare V0111 (136)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0112 (137)  rf=r size=4 type=ud alias=V0111+0 align=2 words (r6.2)
//.declare V0113 (138)  rf=r size=4 type=d alias=+4 align=2 words (r4.5)
//.declare V0114 (139)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0115 (140)  rf=r size=4 type=ud alias=V0114+0 align=2 words (r2.0)
//.declare V0116 (141)  rf=r size=4 type=f alias=+0 align=2 words (r2.8)
//.declare V0117 (142)  rf=r size=4 type=ud alias=V0105+0 align=2 words (r4.4)
//.declare V0118 (143)  rf=r size=4 type=f alias=+4 align=2 words (r2.9)
//.declare V0119 (144)  rf=r size=4 type=ud alias=V0113+0 align=2 words (r4.5)
//.declare V0120 (145)  rf=r size=4 type=f align=2 words (r7.0)
//.declare V0122 (147)  rf=r size=4 type=f align=2 words (r2.1)
//.declare V0124 (149)  rf=r size=4 type=f align=2 words (r3.4)
//.declare V0125 (150)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0126 (151)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0127 (152)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0128 (153)  rf=r size=4 type=ud alias=V0127+0 align=2 words (r5.0)
//.declare V0129 (154)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0130 (155)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0131 (156)  rf=r size=4 type=d align=2 words (r10.1)
//.declare V0132 (157)  rf=r size=4 type=d align=2 words (r12.0)
//.declare V0133 (158)  rf=r size=4 type=ud alias=V0131+0 align=2 words (r10.1)
//.declare V0134 (159)  rf=r size=4 type=ud alias=V0132+0 align=2 words (r12.0)
//.declare  (160)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0135 (161)  rf=r size=4 type=d align=2 words (r13.0)
//.declare V0136 (162)  rf=r size=4 type=d align=32 words (r27.0)
//.declare V0137 (163)  rf=r size=4 type=d align=2 words (r23.4)
//.declare V0138 (164)  rf=r size=4 type=d align=2 words (r23.5)
//.declare P10 (165)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0139 (166)  rf=r size=4 type=d align=2 words (r23.6)
//.declare P11 (167)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0140 (168)  rf=r size=4 type=d align=2 words (r23.7)
//.declare P12 (169)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0141 (170)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0142 (171)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.1)
//.declare V0143 (172)  rf=r size=4 type=d align=2 words (r23.8)
//.declare V0144 (173)  rf=r size=128 type=d align=32 words (r30.0)
//.declare P13 (174)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0145 (175)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0146 (176)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0148 (178)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0149 (179)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0150 (180)  rf=r size=8 type=uq alias=V0149+0 align=32 words (r4.0)
//.declare V0151 (181)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0152 (182)  rf=r size=4 type=d align=2 words (r6.0)
//.declare P14 (183)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0153 (184)  rf=r size=4 type=f alias=V0152+0 align=2 words (r6.0)
//.declare P15 (185)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0154 (186)  rf=r size=4 type=d align=2 words (r8.0)
//.declare P16 (187)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P17 (188)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (189)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P18 (190)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P19 (191)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0155 (192)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0156 (193)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare P20 (194)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0157 (195)  rf=r size=4 type=d align=32 words (r36.0)
//.declare V0158 (196)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0163 (201)  rf=r size=256 type=uq align=32 words (r16.0)
//.declare V0164 (202)  rf=r size=128 type=d align=32 words (r20.0)
//.declare P21 (203)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P22 (204)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0165 (205)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0167 (207)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0168 (208)  rf=r size=256 type=ud alias=V0167+0 align=32 words (r6.0)
//.declare V0169 (209)  rf=r size=8 type=ud alias=V0165+0 align=32 words (r2.0)
//.declare V0170 (210)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0171 (211)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0172 (212)  rf=r size=4 type=d align=2 words (r23.9)
//.declare V0173 (213)  rf=r size=4 type=d align=2 words (r23.10)
//.declare V0174 (214)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0175 (215)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0176 (216)  rf=r size=4 type=d align=2 words (r26.1)
//.declare V0177 (217)  rf=r size=4 type=d align=2 words (r23.11)
//.declare V0178 (218)  rf=r size=4 type=d align=32 words (r37.0)
//.declare V0179 (219)  rf=r size=4 type=d align=2 words (r23.12)
//.declare V0180 (220)  rf=r size=4 type=d align=2 words (r23.13)
//.declare V0181 (221)  rf=r size=128 type=d align=32 words (r38.0)
//.declare P23 (222)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0182 (223)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0183 (224)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0188 (229)  rf=r size=256 type=uq align=32 words (r16.0)
//.declare V0189 (230)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0190 (231)  rf=r size=128 type=d align=32 words (r42.0)
//.declare P24 (232)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P25 (233)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0191 (234)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0192 (235)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0197 (240)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare P26 (241)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0198 (242)  rf=r size=4 type=d align=2 words (r23.14)
//.declare P27 (243)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P28 (244)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0199 (245)  rf=r size=4 type=d alias=+0 align=2 words (r27.8)
//.declare V0201 (247)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0202 (248)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0203 (249)  rf=r size=8 type=uq alias=V0202+0 align=32 words (r4.0)
//.declare V0204 (250)  rf=r size=4 type=f align=32 words (r44.0)
//.declare V0205 (251)  rf=r size=4 type=d align=2 words (r23.15)
//.declare V0206 (252)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0207 (253)  rf=r size=4 type=d align=2 words (r26.2)
//.declare P29 (254)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0208 (255)  rf=r size=4 type=ud alias=V0206+0 align=2 words (r3.0)
//.declare V0209 (256)  rf=r size=4 type=d alias=+0 align=2 words (r27.4)
//.declare V0210 (257)  rf=r size=4 type=d alias=+4 align=2 words (r27.5)
//.declare V0211 (258)  rf=r size=4 type=d align=2 words (r26.3)
//.declare V0212 (259)  rf=r size=4 type=d alias=+4 align=2 words (r27.9)
//.declare V0213 (260)  rf=r size=4 type=d align=2 words (r26.4)
//.declare V0214 (261)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0216 (263)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0217 (264)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0218 (265)  rf=r size=8 type=uq alias=V0217+0 align=32 words (r4.0)
//.declare V0219 (266)  rf=r size=4 type=f align=32 words (r45.0)
//.declare P30 (267)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0220 (268)  rf=r size=4 type=d align=2 words (r26.5)
//.declare P31 (269)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0221 (270)  rf=r size=4 type=ud alias=V0212+0 align=2 words (r27.9)
//.declare V0222 (271)  rf=r size=4 type=ud alias=V0198+0 align=2 words (r23.14)
//.declare P32 (272)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0223 (273)  rf=r size=4 type=d align=2 words (r27.1)
//.declare  (274)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare V0224 (275)  rf=r size=4 type=d align=2 words (r26.6)
//.declare V0225 (276)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0227 (278)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0228 (279)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0229 (280)  rf=r size=8 type=uq alias=V0228+0 align=32 words (r4.0)
//.declare V0230 (281)  rf=r size=4 type=f align=32 words (r46.0)
//.declare P33 (282)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0231 (283)  rf=r size=4 type=d align=2 words (r26.7)
//.declare P34 (284)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0232 (285)  rf=r size=4 type=ud alias=V0224+0 align=2 words (r26.6)
//.declare P35 (286)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0233 (287)  rf=r size=4 type=d align=2 words (r2.0)
//.declare  (288)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0234 (289)  rf=r size=4 type=d align=2 words (r26.8)
//.declare V0235 (290)  rf=r size=4 type=d align=2 words (r26.9)
//.declare V0236 (291)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0238 (293)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0239 (294)  rf=r size=8 type=q align=32 words (r6.0)
//.declare V0240 (295)  rf=r size=8 type=uq alias=V0239+0 align=32 words (r6.0)
//.declare V0241 (296)  rf=r size=4 type=f align=32 words (r47.0)
//.declare P36 (297)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0242 (298)  rf=r size=4 type=d align=2 words (r26.10)
//.declare P37 (299)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0243 (300)  rf=r size=4 type=ud alias=V0235+0 align=2 words (r26.9)
//.declare P38 (301)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0244 (302)  rf=r size=4 type=d align=2 words (r27.2)
//.declare  (303)  rf=f16  size=2 type=uw align=1 words (f1.0)
//.declare V0245 (304)  rf=r size=4 type=d align=2 words (r26.11)
//.declare V0246 (305)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0248 (307)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0249 (308)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0250 (309)  rf=r size=8 type=uq alias=V0249+0 align=32 words (r4.0)
//.declare V0251 (310)  rf=r size=4 type=f align=32 words (r48.0)
//.declare P39 (311)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0252 (312)  rf=r size=4 type=d align=2 words (r26.12)
//.declare P40 (313)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0253 (314)  rf=r size=4 type=ud alias=V0245+0 align=2 words (r26.11)
//.declare P41 (315)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0254 (316)  rf=r size=4 type=d align=2 words (r2.0)
//.declare  (317)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare P42 (318)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P43 (319)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0255 (320)  rf=r size=4 type=d align=2 words (r27.3)
//.declare V0256 (321)  rf=r size=4 type=d align=2 words (r26.13)
//.declare V0257 (322)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0259 (324)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0260 (325)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0261 (326)  rf=r size=8 type=uq alias=V0260+0 align=32 words (r4.0)
//.declare V0262 (327)  rf=r size=4 type=f align=32 words (r49.0)
//.declare P44 (328)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0263 (329)  rf=r size=4 type=d align=2 words (r26.14)
//.declare P45 (330)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0264 (331)  rf=r size=4 type=ud alias=V0210+0 align=2 words (r27.5)
//.declare P46 (332)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0265 (333)  rf=r size=4 type=d align=2 words (r2.0)
//.declare  (334)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare P47 (335)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P48 (336)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0266 (337)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0267 (338)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0268 (339)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0270 (341)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0273 (344)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0274 (345)  rf=r size=16 type=d align=32 words (r7.0)
//.declare P49 (346)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0275 (347)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0277 (349)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0278 (350)  rf=r size=256 type=ud alias=V0277+0 align=32 words (r6.0)
//.declare V0279 (351)  rf=r size=8 type=ud alias=V0275+0 align=32 words (r2.0)
//.declare V0280 (352)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0281 (353)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare  (354)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (355)  rf=r size=8 type=f align=8 words (r2.8)
//.declare  (356)  rf=r size=8 type=ud align=8 words (r4.4)
//.declare  (357)  rf=r size=8 type=d align=8 words (r27.4)
//.declare  (358)  rf=r size=8 type=d align=8 words (r27.8)
//.declare  (359)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (360)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (361)  rf=r size=4 type=f align=2 words (r3.0)
//.declare  (362)  rf=r size=4 type=f align=2 words (r5.0)
//.declare  (363)  rf=r size=2 type=w align=1 words (r7.0)
//.declare  (364)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (365)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (366)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (367)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (368)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (369)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (370)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (371)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (372)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (373)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (374)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (375)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (376)  rf=r size=2 type=uw align=1 words (r2.0)
//.declare  (380)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (381)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (386)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (387)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (392)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (393)  rf=r size=128 type=q align=32 words (r16.0)
//.declare r0 (396)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (397)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (398)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (399)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (400)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (401)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (402)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0281    | :ud      |    0x4 | r2       | inline+0x0       |
// | V0034    | :uq      |    0x8 | r2+0x8   | inline+0x8       |
// | V0042    | :d       |    0x4 | r2+0x10  | inline+0x10      |
// | V0043    | :d       |    0x4 | r2+0x14  | inline+0x14      |
// | V0044    | :d       |    0x4 | r2+0x18  | inline+0x18      |
// | V0045    | :d       |    0x4 | r2+0x1C  | inline+0x1C      |
// | V0046    | :d       |    0x4 | r3       | cti+0x20         |
// | V0047    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0048    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0049    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0050    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0051    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0052    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0053    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0054    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0055    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0056    | :q       |    0x8 | r4       | cti+0x60         |
// | V0057    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0058    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0059    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0060    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0061    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0062    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0063    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0064    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0065    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0066    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0067    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0068    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B007}
// _main:
(W)     mov (16|M0)              r22.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
        cmp (32|M0)   (eq)f1.0   null<2>:w     r1.0<1;1,0>:w     0:w               {A@1,$0.dst}      //  ALU pipe: int; $3
        cmp (32|M0)   (eq)f0.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $2
(~f1.0) goto (32|M0)                         _0_094            _0_094                                //  ALU pipe: int; $4
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_095:
(W)     mov (1|M0)               r2.0<1>:uq    r5.4<0;1,0>:uq                   {Compacted,$2.dst}   //  ALU pipe: int; $6
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r2:1]             {I@1,$1} // ex_desc:0x0; desc:0x2108580 // $7
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$1.dst}          //  ALU pipe: int; $8
(W&~f3.0) jmpi                               _0_096                                                  //  ALU pipe: int; $9
// B004: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_097:
        mov (32|M0)              r24.0<1>:ud   0x3F800000:ud                                         //  ALU pipe: int; $11
(W)     jmpi                                 _0_098                                                  // $12
// B005: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_096:
(W)     mov (1|M0)               r2.0<1>:uq    r5.1<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $14
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $17
        mov (16|M0)              r6.0<2>:f     r2.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $15
        mov (16|M16)             r8.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $15
        mov (16|M0)              r6.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $16
        mov (16|M16)             r8.1<2>:ud    r2.1<0;1,0>:ud                   {F@1}                //  ALU pipe: int; $16
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {I@1,$3} // ex_desc:0x0; desc:0x8200599 // $18
(W)     mov (1|M0)               r3.0<1>:f     0x3F800000:f                               {Compacted} //  ALU pipe: float; $21
        cmp (32|M0)   (ne)f1.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$3.dst}          //  ALU pipe: int; $20
(f1.0)  sel (32|M0)              r24.0<1>:f    r3.0<0;1,0>:f     0x0:f               {F@1}           //  ALU pipe: float; $21
// B006: [inDivergent],  Preds:{B005, B004},  Succs:{B007}
_0_098:
        mov (32|M0)              r6.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $24
        store.slm.d32.a32 (32|M0)  [r6:2]       r24:2              {A@1,$4} // ex_desc:0x0; desc:0x4000504 // $25
// B007: Preds:{B006, B002},  Succs:{B008, B075}
_0_094:
        join (32|M0)                         L536                                                    // 
L536:
(W)     send.slm (1|M0)          r4       r22  null:0  0x0            0x0210001F           {$1} // wr:1+0, rd:1; fence.slm.none.group // $27
(W)     mov (8|M0)               null<1>:ud    r4.0<1;1,0>:ud                   {Compacted,$1.dst}   //  memory fence commit; ALU pipe: int; $28
        sync.nop                             null                             {Compacted,$4.src}     // $28
(W)     send.ugm (1|M0)          r6       r22  null:0  0x0            0x0210001F           {$5} // wr:1+0, rd:1; fence.ugm.none.group // $28
(W)     mov (1|M0)               r7.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $29
(W)     mov (2|M0)               r7.10<1>:ub   r22.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $29
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$5.dst}   //  memory fence commit; ALU pipe: int; $29
(W)     send.gtwy (1|M0)         null     r7  null:0  0x0            0x02000004           {I@2,$6} // wr:1+0, rd:0; signal barrier // $29
(W)     sync.bar                             0x0                                                     // $29
(W)     mov (1|M0)               r2.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $30
(W)     load.slm.d32x1t.a32 (1|M0)  r3:1        [r2:1]             {I@1,$7} // ex_desc:0x0; desc:0x2108500 // $31
(W)     cmp (32|M0)   (ne)f2.0   null<1>:f     r3.0<0;1,0>:f     0x0:f               {$7.dst}        //  ALU pipe: float; $32
(W&f2.0) jmpi                                _0_099                                                  //  ALU pipe: int; $33
// B008: Preds:{B007},  Succs:{B009, B073}
_0_100:
(W)     send.slm (1|M0)          r4       r22  null:0  0x0            0x0210001F           {$8} // wr:1+0, rd:1; fence.slm.none.group // $35
(W)     mov (8|M0)               null<1>:ud    r4.0<1;1,0>:ud                   {Compacted,$8.dst}   //  memory fence commit; ALU pipe: int; $36
(W)     send.ugm (1|M0)          r6       r22  null:0  0x0            0x0210001F           {$9} // wr:1+0, rd:1; fence.ugm.none.group // $36
(W)     mov (1|M0)               r7.2<1>:f     0x100:f                               {$6.src}        //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $37
(W)     mov (2|M0)               r7.10<1>:ub   r22.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $37
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$9.dst}   //  memory fence commit; ALU pipe: int; $37
(W)     send.gtwy (1|M0)         null     r7  null:0  0x0            0x02000004           {I@2,$10} // wr:1+0, rd:0; signal barrier // $37
(W)     sync.bar                             0x0                                                     // $37
(W)     mov (1|M0)               r2.0<1>:uq    r5.3<0;1,0>:uq                   {Compacted,$2.dst}   //  ALU pipe: int; $38
(W)     add (1|M0)               r2.4<1>:d     r3.2<0;1,0>:d     -r2.5<0;1,0>:d                      //  ALU pipe: int; $40
(W)     load.ugm.d32x1t.a64 (1|M0)  r23:1       [r2:1]             {I@1,$11} // ex_desc:0x0; desc:0x2108580 // $39
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r23.0<0;1,0>:d    r2.4<0;1,0>:d    {$11.dst}          //  ALU pipe: int; $41
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:d     r23.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $42
(W&f1.0) jmpi                                _0_101                                                  //  ALU pipe: int; $44
// B009: Preds:{B008},  Succs:{B010, B011}
_0_102:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.2<0;1,0>:d     -3:w                                //  ALU pipe: int; $46
(W&f1.0) jmpi                                _0_103                                                  //  ALU pipe: int; $47
// B010: Preds:{B009},  Succs:{B012}
_0_104:
(W)     add (1|M0)               r23.1<1>:d    r3.2<0;1,0>:d     3:w                                 //  ALU pipe: int; $49
(W)     jmpi                                 _0_105                                                  // $50
// B011: Preds:{B009},  Succs:{B012}
_0_103:
(W)     add (1|M0)               r23.1<1>:d    r3.2<0;1,0>:d     6:w                                 //  ALU pipe: int; $52
// B012: Preds:{B011, B010},  Succs:{B013, B014}
_0_105:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r23.1<0;1,0>:ud   0x4:uw              {I@1}           //  ALU pipe: int; $56
(W)     asr (1|M0)               r23.2<1>:d    r23.1<0;1,0>:d    2:w                                 //  ALU pipe: int; $54
(W)     add (1|M0)               r23.3<1>:d    r3.3<0;1,0>:d     3:w                                 //  ALU pipe: int; $55
(W&~f3.0) jmpi                               _0_106                                                  //  ALU pipe: int; $57
// B013: Preds:{B012},  Succs:{B015}
_0_107:
(W)     mov (1|M0)               r26.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $59
(W)     jmpi                                 _0_108                                                  // $60
// B014: Preds:{B012},  Succs:{B015}
_0_106:
(W)     asr (1|M0)               r3.0<1>:d     r23.1<0;1,0>:d    31:w               {Compacted}      //  ALU pipe: int; $62
(W)     add (1|M0)               r2.0<1>:d     r3.0<0;1,0>:d     r23.2<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $63
(W)     xor (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     r3.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $64
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $65
(W)     mov (1|M0)               r4.0<1>:f     r3.1<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $66
(W)     mov (1|M0)               r5.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $71
(W)     math.inv (1|M0)          r4.2<1>:f     r4.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $70
(W)     mov (1|M0)               r4.1<1>:f     r22.1<0;1,0>:ud                                       //  ALU pipe: float; $69
(W)     mad (1|M0)               r6.0<1>:f     r4.2<0;0>:f       r5.0<0;0>:f       r4.2<0>:f        {Compacted,A@1} //  ALU pipe: float; $71
(W)     mov (1|M0)               r3.4<1>:ud    r4.0<0;1,0>:f                                         //  ALU pipe: int; $67
(W)     mov (1|M0)               r6.2<1>:ud    r4.1<0;1,0>:f                    {F@2}                //  ALU pipe: int; $73
(W)     mul (1|M0)               r6.1<1>:f     r4.1<0;1,0>:f     r6.0<0;1,0>:f    {F@1}              //  ALU pipe: float; $72
(W)     add (1|M0)               r4.4<1>:d     r3.1<0;1,0>:d     -r3.4<0;1,0>:d   {I@2}              //  ALU pipe: int; $68
(W)     add (1|M0)               r4.5<1>:d     r22.1<0;1,0>:d    -r6.2<0;1,0>:d   {I@2}              //  ALU pipe: int; $74 R{} IR{}{E:3,E:3,},  {BC=1}
(W)     mov (1|M0)               r2.0<1>:ud    r6.1<0;1,0>:f                    {F@1}                //  ALU pipe: int; $75
(W)     mov (1|M0)               r2.8<1>:f     r4.4<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $76
(W)     mov (1|M0)               r2.9<1>:f     r4.5<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $76
(W)     mov (1|M0)               r7.0<1>:f     r2.0<0;1,0>:ud                   {@1,$10.src}         //  ALU pipe: float; $78
(W)     mad (1|M0)               r2.1<1>:f     r4.1<0;0>:f       r7.0<0;0>:f       -r4.0<0>:f       {F@1} //  ALU pipe: float; $80
(W)     mad (1|M0)               r3.4<1>:f     r2.9<0;0>:f       r7.0<0;0>:f       -r2.8<0>:f        //  ALU pipe: float; $82
(W)     add (1|M0)               r8.0<1>:f     r2.1<0;1,0>:f     r3.4<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $83
(W)     mul (1|M0)               r9.0<1>:f     r6.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $84
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $85
(W)     mov (1|M0)               r5.0<1>:ud    r9.0<0;1,0>:f                    {A@1}                //  ALU pipe: int; $86
(W)     add (1|M0)               r10.0<1>:d    r5.0<0;1,0>:d     r2.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $87
(W)     mul (1|M0)               acc0.0<1>:d   r10.0<0;1,0>:d    r3.2<0;1,0>:uw   {I@1}              //  ALU pipe: int; $88
(W)     macl (1|M0)              r11.0<1>:d    r10.0<0;1,0>:d    r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $89
(W)     add (1|M0)               r10.1<1>:d    r22.1<0;1,0>:d    -r11.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $89
(W)     cmp (1|M0)    (ge)f2.0   r12.0<1>:ud   r10.1<0;1,0>:ud   r3.1<0;1,0>:ud   {I@1}              //  ALU pipe: int; $90
(W)     add3 (1|M0)              r13.0<1>:d    r10.0<0;0>:d      r3.0<0;0>:d       -r12.0<0>:d      {I@1} //  ALU pipe: int; $91
(W)     xor (1|M0)               r26.0<1>:d    r13.0<0;1,0>:d    r3.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $92
// B015: Preds:{B014, B013},  Succs:{B016, B017}
_0_108:
(W)     add (1|M0)               r23.4<1>:d    r23.0<0;1,0>:d    r26.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $95
(W)     mul (1|M0)               acc0.0<1>:d   r26.0<0;1,0>:d    r23.4<0;1,0>:uw                     //  ALU pipe: int; $94
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r23.4<0;1,0>:d    -1:w               {I@2}            //  ALU pipe: int; $97
(W)     add3 (1|M0)              r23.5<1>:d    r23.0<0;0>:d      r26.0<0;0>:d      1:w               //  ALU pipe: int; $96
(W)     macl (1|M0)              r27.0<1>:d    r26.0<0;1,0>:d    r23.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $95
(W&~f2.0) jmpi                               _0_109                                                  //  ALU pipe: int; $98
// B016: Preds:{B015},  Succs:{B017}
_0_110:
(W)     add3 (1|M0)              r23.5<1>:d    r23.0<0;0>:d      r26.0<0;0>:d      4:w               //  ALU pipe: int; $100
// B017: Preds:{B016, B015},  Succs:{B018, B019}
_0_109:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.3<0;1,0>:d     0:w                                 //  ALU pipe: int; $103
(W)     asr (1|M0)               r23.6<1>:d    r23.5<0;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $102
(W&~f1.0) jmpi                               _0_111                                                  //  ALU pipe: int; $104
// B018: Preds:{B017},  Succs:{B020}
_0_112:
(W)     mov (1|M0)               r23.7<1>:d    r23.3<0;1,0>:d                                        //  ALU pipe: int; $106
(W)     jmpi                                 _0_113                                                  // $107
// B019: Preds:{B017},  Succs:{B020}
_0_111:
(W)     mov (1|M0)               r23.7<1>:d    r3.3<0;1,0>:d                                         //  ALU pipe: int; $109
// B020: Preds:{B019, B018},  Succs:{B021, B022}
_0_113:
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r23.4<0;1,0>:d    2:w                                 //  ALU pipe: int; $111
(W&f1.0) jmpi                                _0_114                                                  //  ALU pipe: int; $112
// B021: Preds:{B020},  Succs:{B029}
_0_115:
        mov (32|M0)              r28.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $114
(W)     jmpi                                 _0_116                                                  // $115
// B022: Preds:{B020},  Succs:{B023}
_0_114:
        mov (32|M0)              r30.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $118
(W)     mov (1|M0)               r23.8<1>:d    0:w                                                   //  ALU pipe: int; $117
// B023: Preds:{B028, B022},  Succs:{B024, B025}
_0_117:
        cmp (32|M0)   (ne)f3.0   null<1>:d     r30.0<1;1,0>:d    0:w               {I@2}             //  ALU pipe: int; $120
(f3.0)  goto (32|M0)                         _0_118            _0_118                                //  ALU pipe: int; $121
// B024: [inDivergent],  Preds:{B023},  Succs:{B026}
_0_119:
        mov (32|M0)              r32.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $123
        goto (32|M0)                         _0_118            _0_120                                // $124
// B025: [inDivergent],  Preds:{B023},  Succs:{B026}
_0_118:
        join (32|M0)                         _0_120                                                  // 
L1848:
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r23.8<0;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $126
(W)     mov (1|M0)               r7.0<1>:hf    0xFFFF:hf                              {$10.src}      //  ALU pipe: float; $135
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $128
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $129
(W)     load.ugm.d32x1t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$12} // ex_desc:0x0; desc:0x2108580 // $130
(W)     and (1|M0)               r6.0<1>:d     r5.0<0;1,0>:d     2147483647:d               {$12.dst} //  ALU pipe: int; $131
(W)     cmp (32|M0)   (ne)f2.0   null<1>:f     r6.0<0;1,0>:f     0x7F800000:f               {I@1}    //  ALU pipe: float; $132
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:f     r6.0<0;1,0>:f     r6.0<0;1,0>:f                       //  ALU pipe: float; $133
(W&f2.0) sel (1|M0)              r8.0<1>:d     r7.0<0;1,0>:w     0:w               {F@3}             //  ALU pipe: int; $135
        mov (32|M0)              r32.0<1>:d    r8.0<0;1,0>:d                    {Compacted,I@1}      //  ALU pipe: int; $136
// B026: Preds:{B025, B024},  Succs:{B027, B028}
_0_120:
        join (32|M0)                         L2000                                                   // 
L2000:
(W)     add (1|M0)               r23.8<1>:d    r23.8<0;1,0>:d    1:w                                 //  ALU pipe: int; $139
        cmp (32|M0)   (ne)f3.0   null<1>:d     r32.0<1;1,0>:d    0:w               {I@3}             //  ALU pipe: int; $138
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r23.8<0;1,0>:d    r23.6<0;1,0>:d   {A@1}              //  ALU pipe: int; $140
(W&f2.0) jmpi                                _0_121                                                  //  ALU pipe: int; $141
// B027: Preds:{B026},  Succs:{B029}
_0_122:
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $143
(f3.0)  sel (32|M0)              r28.0<1>:d    r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $143
(W)     jmpi                                 _0_116                                                  // $144
// B028: Preds:{B026},  Succs:{B023}
_0_121:
        cmp (32|M0)   (ne)f3.0   r30.0<1>:d    r32.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $146
(W)     jmpi                                 _0_117                                                  // $147
// B029: Preds:{B027, B021},  Succs:{B030, B036}
_0_116:
        cmp (32|M0)   (ne)f3.0   null<1>:d     r28.0<1;1,0>:d    0:w               {I@4}             //  ALU pipe: int; $150
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r22.1<0;1,0>:d    r27.0<0;1,0>:d                      //  ALU pipe: int; $149
(f3.0)  goto (32|M0)                         _0_123            _0_123                                //  ALU pipe: int; $151
// B030: [inDivergent],  Preds:{B029},  Succs:{B031, B075}
_0_124:
(~f2.0) goto (32|M0)                         _0_123            _0_099                                //  ALU pipe: int; $153
// B031: [inDivergent],  Preds:{B030},  Succs:{B032, B034}
_0_125:
        mov (32|M0)              r34.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $155
        cmp (32|M0)   (gt)f0.0   null<1>:d     r23.3<0;1,0>:d    r34.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $156
(~f0.0) goto (32|M0)                         _0_126            _0_126                                //  ALU pipe: int; $157
// B032: [inDivergent],  Preds:{B031},  Succs:{B033}
_0_127:
(W)     mul (1|M0)               acc0.0<1>:d   r26.0<0;1,0>:d    r23.6<0;1,0>:uw                     //  ALU pipe: int; $159
(W)     macl (1|M0)              r36.0<1>:d    r26.0<0;1,0>:d    r23.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; 
// B033: [inDivergent],  Preds:{B033, B032},  Succs:{B034, B033}
_0_128:
        add (32|M0)              r6.0<1>:d     r36.0<0;1,0>:d    r34.0<1;1,0>:d   {Compacted,@1,$10.src} //  ALU pipe: int; $161
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $163
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $163
        add (32|M0)              r34.0<1>:d    r34.0<1;1,0>:d    32:w               {Compacted}      //  ALU pipe: int; $168
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     2:w               {I@3}             //  ALU pipe: int; $163
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    2:w               {I@3}             //  ALU pipe: int; $163
        cmp (32|M0)   (lt)f0.0   null<1>:d     r34.0<1;1,0>:d    r23.3<0;1,0>:d   {I@3}              //  ALU pipe: int; $169
        mov (32|M0)              r20.0<1>:d    -1:w                               {Compacted,$13.src} //  ALU pipe: int; $166
        add (16|M0)              r16.0<1>:q    r10.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $164
        add (16|M16)             r18.0<1>:q    r14.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $164
        store.ugm.d32.a64 (32|M0)  [r16:4]      r20:2              {I@1,$13} // ex_desc:0x0; desc:0x8000584 // $167
(f0.0)  goto.b (32|M0)                       _0_126            _0_128                                //  ALU pipe: int; $170
// B034: [inDivergent],  Preds:{B033, B031},  Succs:{B035, B075}
_0_126:
        join (32|M0)                         _0_123                                                  // 
L2432:
        cmp (32|M0)   (eq)f3.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $172
(~f3.0) goto (32|M0)                         _0_123            _0_099                                //  ALU pipe: int; $173
// B035: [inDivergent],  Preds:{B034},  Succs:{B075}
_0_129:
(W)     mov (1|M0)               r2.0<1>:uq    r5.1<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $175
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $178
        sync.nop                             null                             {Compacted,I@2}        // $176
        mov (16|M0)              r6.0<2>:f     r2.0<0;1,0>:f                    {$10.src}            //  ALU pipe: float; $176
        mov (16|M16)             r8.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $176
        mov (16|M0)              r6.1<2>:f     r2.1<0;1,0>:f                                         //  ALU pipe: float; $177
        mov (16|M16)             r8.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $177
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$14} // ex_desc:0x0; desc:0x800058B // $179
        goto (32|M0)                         _0_123            _0_099                                // $180
// B036: [inDivergent],  Preds:{B029},  Succs:{B037, B044}
_0_123:
        join (32|M0)                         _0_099                                                  // 
L2600:
(W)     asr (1|M0)               r2.0<1>:d     r23.7<0;1,0>:d    2:w                                 //  ALU pipe: int; $182
(W)     sel (1|M0)    (lt)f0.0   r23.9<1>:d    r2.0<0;1,0>:d     r23.6<0;1,0>:d   {I@1}              //  ALU pipe: int; $183
(W&~f2.0) jmpi                               _0_130                                                  //  ALU pipe: int; $184
// B037: [inDivergent],  Preds:{B036},  Succs:{B038, B041}
_0_131:
(W)     shl (1|M0)               r23.10<1>:d   r23.9<0;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $186
(W)     not (1|M0)               r2.0<1>:d     r23.4<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $188
(W)     and (1|M0)               r26.1<1>:d    r23.5<0;1,0>:d    -4:w                                //  ALU pipe: int; $189
(W)     add3 (1|M0)              r3.0<1>:d     r3.3<0;0>:d       -r23.10<0;0>:d    3:w               {I@3} //  ALU pipe: int; $187
        mov (32|M0)              r38.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $194
(W)     add3 (1|M0)              r23.11<1>:d   r26.1<0;0>:d      r2.0<0;0>:d       r3.0<0>:d        {I@2} //  ALU pipe: int; $190
(W)     mul (1|M0)               acc0.0<1>:d   r26.0<0;1,0>:d    r23.6<0;1,0>:uw                     //  ALU pipe: int; $191
        cmp (32|M0)   (gt)f0.0   null<1>:d     r23.11<0;1,0>:d   r38.0<1;1,0>:d   {I@2}              //  ALU pipe: int; $195
(W)     macl (1|M0)              r37.0<1>:d    r26.0<0;1,0>:d    r23.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $192
(W)     add3 (1|M0)              r23.13<1>:d   r23.4<0;0>:d      -r26.1<0;0>:d     1:w               //  ALU pipe: int; $193
(W)     add (1|M0)               r23.12<1>:d   r37.0<0;1,0>:d    r23.10<0;1,0>:d  {I@2}              //  ALU pipe: int; $192
(~f0.0) goto (32|M0)                         _0_132            _0_132                                //  ALU pipe: int; $196
// B038: [inDivergent],  Preds:{B037},  Succs:{B039}
_0_133:
        mov (32|M0)              r40.0<1>:f    r38.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $198
// B039: [inDivergent],  Preds:{B040, B038},  Succs:{B040, B041}
_0_134:
        sync.nop                             null                             {Compacted,A@1}        // $200
        sync.nop                             null                             {Compacted,$14.src}    // $200
        add3 (32|M0)             r6.0<1>:d     r23.12<0;0>:d     r23.13<0;0>:d     r40.0<1>:d       {$10.src} //  ALU pipe: int; $200
        add (32|M0)              r42.0<1>:d    r40.0<1;1,0>:d    32:w               {Compacted}      //  ALU pipe: int; $207
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $202
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $202
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     2:w               {I@2}             //  ALU pipe: int; $202
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $202
        cmp (32|M0)   (lt)f2.0   null<1>:d     r42.0<1;1,0>:d    r23.11<0;1,0>:d                     //  ALU pipe: int; $208
        sync.nop                             null                             {Compacted,$15.src}    // $205
        mov (32|M0)              r20.0<1>:d    -1:w                               {Compacted,$13.src} //  ALU pipe: int; $205
        add (16|M0)              r16.0<1>:q    r10.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $203
        add (16|M16)             r18.0<1>:q    r14.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $203
        store.ugm.d32.a64 (32|M0)  [r16:4]      r20:2              {I@1,$15} // ex_desc:0x0; desc:0x8000584 // $206
(~f2.0) goto (32|M0)                         _0_132            _0_132                                //  ALU pipe: int; $209
// B040: [inDivergent],  Preds:{B039},  Succs:{B039}
_0_135:
        mov (32|M0)              r40.0<1>:f    r42.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $211
(W)     jmpi                                 _0_134                                                  // $212
// B041: [inDivergent],  Preds:{B039, B037},  Succs:{B042, B044}
_0_132:
        join (32|M0)                         _0_099                                                  // 
L3040:
        cmp (32|M0)   (gt)f3.0   null<1>:d     r23.13<0;1,0>:d   r38.0<1;1,0>:d                      //  ALU pipe: int; $214
(~f3.0) goto (32|M0)                         _0_130            _0_130                                //  ALU pipe: int; $215
// B042: Preds:{B041},  Succs:{B043}
_L_k0_0_preHeader:
_0_136:
// B043: [inDivergent],  Preds:{B042, B043},  Succs:{B044, B043}
        add3 (32|M0)             r8.0<1>:d     r37.0<0;0>:d      r23.10<0;0>:d     r38.0<1>:d       {$14.src} //  ALU pipe: int; $218
        sync.nop                             null                             {Compacted,$0.src}     // $217
        add (32|M0)              r6.0<1>:d     r26.1<0;1,0>:d    r38.0<1;1,0>:d   {Compacted,$10.src} //  ALU pipe: int; $217
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $220
        mov (16|M16)             r14.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $220
        add (32|M0)              r38.0<1>:d    r38.0<1;1,0>:d    32:w               {Compacted}      //  ALU pipe: int; $224
        shl (16|M0)              r12.0<1>:q    r10.0<2;1,0>:d    2:w               {I@3}             //  ALU pipe: int; $220
        sync.nop                             null                             {Compacted,$15.src}    // $220
        shl (16|M16)             r16.0<1>:q    r14.0<2;1,0>:d    2:w               {@3,$13.src}      //  ALU pipe: int; $220
        cmp (32|M0)   (lt)f0.0   null<1>:d     r38.0<1;1,0>:d    r23.13<0;1,0>:d  {I@3}              //  ALU pipe: int; $225
        add (16|M0)              r18.0<1>:q    r12.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $221
        add (16|M16)             r20.0<1>:q    r16.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $221
        store.ugm.d32.a64 (32|M0)  [r18:4]      r6:2               {I@1,$0} // ex_desc:0x0; desc:0x8000584 // $223
(f0.0)  goto.b (32|M0)                       _0_130            _L_k0_0_preHeader                     //  ALU pipe: int; $226
// B044: [inDivergent],  Preds:{B043, B041, B036},  Succs:{B045, B075}
_0_130:
        join (32|M0)                         _0_099                                                  // 
L3248:
        cmp (32|M0)   (eq)f2.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $229
(W)     add (1|M0)               r23.14<1>:d   r22.1<0;1,0>:d    -r27.0<0;1,0>:d                     //  ALU pipe: int; $228
(f2.0)  cmp (32|M0)   (lt)f2.0   null<1>:d     r23.14<0;1,0>:d   r23.6<0;1,0>:d   {I@1}              //  ALU pipe: int; $230
(~f2.0) goto (32|M0)                         _0_099            _0_099                                //  ALU pipe: int; $232
// B045: [inDivergent],  Preds:{B044},  Succs:{B046, B047}
_0_137:
(W&f1.0) jmpi                                _0_138                                                  //  ALU pipe: int; $234
// B046: [inDivergent],  Preds:{B045},  Succs:{B071}
_0_139:
(W)     mov (1|M0)               r27.8<1>:d    0:w                                                   //  ALU pipe: int; $236
(W)     jmpi                                 _0_140                                                  // $237
// B047: [inDivergent],  Preds:{B045},  Succs:{B048, B049}
_0_138:
(W)     shl (1|M0)               r2.0<1>:q     r22.1<0;1,0>:ud   2:w                                 //  ALU pipe: int; $240
(W)     sel (1|M0)    (ge)f0.0   r23.15<1>:d   r23.6<0;1,0>:d    1:w                                 //  ALU pipe: int; $243
(W)     add (1|M0)               r4.0<1>:q     r2.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $241
(W)     add (1|M0)               r3.0<1>:d     r23.15<0;1,0>:d   -1:w               {I@2}            //  ALU pipe: int; $244
(W)     load.ugm.d32x1t.a64 (1|M0)  r44:1       [r4:1]             {I@2,$1} // ex_desc:0x0; desc:0x2108580 // $242
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r3.0<0;1,0>:ud    0x3:uw              {I@1}           //  ALU pipe: int; $246
(W)     and (1|M0)               r26.2<1>:d    r23.15<0;1,0>:d   3:w                                 //  ALU pipe: int; $245
(W&~f2.0) jmpi                               _0_141                                                  //  ALU pipe: int; $247
// B048: [inDivergent],  Preds:{B047},  Succs:{B064}
_0_142:
(W)     mov (2|M0)               r27.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $249
(W)     jmpi                                 _0_143                                                  // $251
// B049: [inDivergent],  Preds:{B047},  Succs:{B050}
_0_141:
(W)     and (1|M0)               r26.3<1>:d    r23.15<0;1,0>:d   2147483644:d                        //  ALU pipe: int; $253
(W)     mov (2|M0)               r27.8<1>:d    0:w                                                   //  ALU pipe: int; $254
(W)     mov (1|M0)               r26.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $256
// B050: [inDivergent],  Preds:{B062, B049},  Succs:{B051, B052}
_0_144:
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r27.9<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $258
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $260
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,@1,$1.src} //  ALU pipe: int; $261
(W)     load.ugm.d32x1t.a64 (1|M0)  r45:1       [r4:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $262
        sync.nop                             null                             {Compacted,$3.dst}     // $263
(W)     cmp (32|M0)   (gt)f3.0   null<1>:f     r45.0<0;1,0>:f    r44.0<0;1,0>:f   {$1.dst}           //  ALU pipe: float; $263
(W&~f3.0) jmpi                               _0_145                                                  //  ALU pipe: int; $264
// B051: [inDivergent],  Preds:{B050},  Succs:{B053}
_0_146:
(W)     mov (1|M0)               r26.5<1>:d    -1:w                                                  //  ALU pipe: int; $266
(W)     jmpi                                 _0_147                                                  // $267
// B052: [inDivergent],  Preds:{B050},  Succs:{B053}
_0_145:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r27.9<0;1,0>:ud   r23.14<0;1,0>:ud {F@1}              //  ALU pipe: int; $269
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:f     r45.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $270
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $272
(W&f3.0) sel (1|M0)              r26.5<1>:d    r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $272
// B053: [inDivergent],  Preds:{B052, B051},  Succs:{B054, B055}
_0_147:
(W)     or (1|M0)                r26.6<1>:d    r27.9<0;1,0>:d    1:w                                 //  ALU pipe: int; $275
(W)     cmp (1|M0)    (ne)f3.0   r27.1<1>:d    r26.5<0;1,0>:d    0:w               {I@2}             //  ALU pipe: int; $274
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r26.6<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $276
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $278
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $279
(W)     load.ugm.d32x1t.a64 (1|M0)  r46:1       [r4:1]             {I@1,$4} // ex_desc:0x0; desc:0x2108580 // $280
(W)     cmp (32|M0)   (gt)f2.0   null<1>:f     r46.0<0;1,0>:f    r44.0<0;1,0>:f   {$4.dst}           //  ALU pipe: float; $281
(W&~f2.0) jmpi                               _0_148                                                  //  ALU pipe: int; $282
// B054: [inDivergent],  Preds:{B053},  Succs:{B056}
_0_149:
(W)     mov (1|M0)               r26.7<1>:d    -1:w                                                  //  ALU pipe: int; $284
(W)     jmpi                                 _0_150                                                  // $285
// B055: [inDivergent],  Preds:{B053},  Succs:{B056}
_0_148:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r26.6<0;1,0>:ud   r23.14<0;1,0>:ud {F@1}              //  ALU pipe: int; $287
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:f     r46.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $288
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $290
(W&f2.0) sel (1|M0)              r26.7<1>:d    r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $290
// B056: [inDivergent],  Preds:{B055, B054},  Succs:{B057, B058}
_0_150:
(W)     or (1|M0)                r26.9<1>:d    r27.9<0;1,0>:d    2:w                                 //  ALU pipe: int; $294
(W)     cmp (1|M0)    (ne)f2.0   r2.0<1>:d     r26.7<0;1,0>:d    0:w               {I@2}             //  ALU pipe: int; $292
(W)     add (1|M0)               r3.0<1>:d     r27.0<0;1,0>:d    r26.9<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $295
(W)     shl (1|M0)               r4.0<1>:q     r3.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $297
(W)     add3 (1|M0)              r26.8<1>:d    r27.8<0;0>:d      -r27.1<0;0>:d     -r2.0<0>:d        //  ALU pipe: int; $293
        sync.nop                             null                             {Compacted,$0.src}     // $298
(W)     add (1|M0)               r6.0<1>:q     r4.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,@2,$14.src} //  ALU pipe: int; $298
(W)     load.ugm.d32x1t.a64 (1|M0)  r47:1       [r6:1]             {I@1,$5} // ex_desc:0x0; desc:0x2108580 // $299
(W)     cmp (32|M0)   (gt)f1.0   null<1>:f     r47.0<0;1,0>:f    r44.0<0;1,0>:f   {$5.dst}           //  ALU pipe: float; $300
(W&~f1.0) jmpi                               _0_151                                                  //  ALU pipe: int; $301
// B057: [inDivergent],  Preds:{B056},  Succs:{B059}
_0_152:
(W)     mov (1|M0)               r26.10<1>:d   -1:w                                                  //  ALU pipe: int; $303
(W)     jmpi                                 _0_153                                                  // $304
// B058: [inDivergent],  Preds:{B056},  Succs:{B059}
_0_151:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r26.9<0;1,0>:ud   r23.14<0;1,0>:ud {F@1}              //  ALU pipe: int; $306
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:f     r47.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $307
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $309
(W&f1.0) sel (1|M0)              r26.10<1>:d   r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $309
// B059: [inDivergent],  Preds:{B058, B057},  Succs:{B060, B061}
_0_153:
(W)     or (1|M0)                r26.11<1>:d   r27.9<0;1,0>:d    3:w                                 //  ALU pipe: int; $312
(W)     cmp (1|M0)    (ne)f1.0   r27.2<1>:d    r26.10<0;1,0>:d   0:w               {I@2}             //  ALU pipe: int; $311
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r26.11<0;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $313
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $315
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $316
(W)     load.ugm.d32x1t.a64 (1|M0)  r48:1       [r4:1]             {I@1,$6} // ex_desc:0x0; desc:0x2108580 // $317
(W)     cmp (32|M0)   (gt)f3.0   null<1>:f     r48.0<0;1,0>:f    r44.0<0;1,0>:f   {$6.dst}           //  ALU pipe: float; $318
(W&~f3.0) jmpi                               _0_154                                                  //  ALU pipe: int; $319
// B060: [inDivergent],  Preds:{B059},  Succs:{B062}
_0_155:
(W)     mov (1|M0)               r26.12<1>:d   -1:w                                                  //  ALU pipe: int; $321
(W)     jmpi                                 _0_156                                                  // $322
// B061: [inDivergent],  Preds:{B059},  Succs:{B062}
_0_154:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r26.11<0;1,0>:ud  r23.14<0;1,0>:ud {F@1}              //  ALU pipe: int; $324
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:f     r48.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $325
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $327
(W&f3.0) sel (1|M0)              r26.12<1>:d   r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $327
// B062: [inDivergent],  Preds:{B061, B060},  Succs:{B063, B050}
_0_156:
(W)     add (1|M0)               r26.4<1>:d    r26.4<0;1,0>:d    4:w                                 //  ALU pipe: int; $332
(W)     cmp (1|M0)    (ne)f3.0   r2.0<1>:d     r26.12<0;1,0>:d   0:w               {I@2}             //  ALU pipe: int; $329
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r26.4<0;1,0>:d    r26.3<0;1,0>:d   {I@2}              //  ALU pipe: int; $333
(W)     add (1|M0)               r27.9<1>:d    r27.9<0;1,0>:d    4:w                                 //  ALU pipe: int; $331
(W)     add3 (1|M0)              r27.8<1>:d    r26.8<0;0>:d      -r27.2<0;0>:d     -r2.0<0>:d       {I@3} //  ALU pipe: int; $330
(W)     mov (1|M0)               r27.5<1>:d    r27.9<0;1,0>:d                   {I@2}                //  ALU pipe: int; $334
(W&~f2.0) jmpi                               _0_144                                                  //  ALU pipe: int; $335
// B063: [inDivergent],  Preds:{B062},  Succs:{B064}
_0_157:
(W)     mov (1|M0)               r27.4<1>:d    r27.8<0;1,0>:d                   {I@3}                //  ALU pipe: int; $337
// B064: [inDivergent],  Preds:{B063, B048},  Succs:{B065, B071}
_0_143:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r26.2<0;1,0>:d    0:w                                 //  ALU pipe: int; $339
(W&f1.0) jmpi                                _0_140                                                  //  ALU pipe: int; $340
// B065: [inDivergent],  Preds:{B064},  Succs:{B066}
_0_158:
(W)     mov (1|M0)               r27.3<1>:d    r27.4<0;1,0>:d                   {I@3}                //  ALU pipe: int; $342
(W)     mov (1|M0)               r26.13<1>:d   0:w                                                   //  ALU pipe: int; $343
// B066: [inDivergent],  Preds:{B070, B065},  Succs:{B067, B068}
_0_159:
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r27.5<0;1,0>:d   {Compacted}        //  ALU pipe: int; $345
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $347
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,@1,$1.src} //  ALU pipe: int; $348
(W)     load.ugm.d32x1t.a64 (1|M0)  r49:1       [r4:1]             {I@1,$7} // ex_desc:0x0; desc:0x2108580 // $349
        sync.nop                             null                             {Compacted,$7.dst}     // $350
(W)     cmp (32|M0)   (gt)f1.0   null<1>:f     r49.0<0;1,0>:f    r44.0<0;1,0>:f   {$1.dst}           //  ALU pipe: float; $350
(W&~f1.0) jmpi                               _0_160                                                  //  ALU pipe: int; $351
// B067: [inDivergent],  Preds:{B066},  Succs:{B069}
_0_161:
(W)     mov (1|M0)               r26.14<1>:d   -1:w                                                  //  ALU pipe: int; $353
(W)     jmpi                                 _0_162                                                  // $354
// B068: [inDivergent],  Preds:{B066},  Succs:{B069}
_0_160:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r27.5<0;1,0>:ud   r23.14<0;1,0>:ud                    //  ALU pipe: int; $356
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:f     r49.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $357
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $359
(W&f2.0) sel (1|M0)              r26.14<1>:d   r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $359
// B069: [inDivergent],  Preds:{B068, B067},  Succs:{B070, B071}
_0_162:
(W)     add (1|M0)               r26.13<1>:d   r26.13<0;1,0>:d   1:w                                 //  ALU pipe: int; $363
(W)     cmp (1|M0)    (ne)f2.0   r2.0<1>:d     r26.14<0;1,0>:d   0:w               {I@2}             //  ALU pipe: int; $361
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r26.13<0;1,0>:d   r26.2<0;1,0>:d   {I@2}              //  ALU pipe: int; $364
(W)     add3 (1|M0)              r27.8<1>:d    r27.3<0;0>:d      -r2.0<0;0>:d      0:w               {I@2} //  ALU pipe: int; $362
(W&f3.0) jmpi                                _0_140                                                  //  ALU pipe: int; $365
// B070: [inDivergent],  Preds:{B069},  Succs:{B066}
_0_163:
(W)     add (1|M0)               r27.5<1>:d    r27.5<0;1,0>:d    1:w                                 //  ALU pipe: int; $367
(W)     mov (1|M0)               r27.3<1>:d    r27.8<0;1,0>:d                   {I@3}                //  ALU pipe: int; $368
(W)     jmpi                                 _0_159                                                  // $369
// B071: [inDivergent],  Preds:{B069, B064, B046},  Succs:{B072, B075}
_0_140:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r27.8<0;1,0>:d    r23.9<0;1,0>:d                      //  ALU pipe: int; $371
(~f3.0) goto (32|M0)                         _0_099            _0_099                                //  ALU pipe: int; $372
// B072: [inDivergent],  Preds:{B071},  Succs:{B075}
_0_164:
(W)     mul (1|M0)               acc0.0<1>:d   r26.0<0;1,0>:d    r23.6<0;1,0>:uw                     //  ALU pipe: int; $376
(W)     shl (1|M0)               r2.0<1>:d     r27.8<0;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $374
(W)     macl (1|M0)              r3.0<1>:d     r26.0<0;1,0>:d    r23.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $377
(W)     shl (1|M0)               r2.6<1>:d     r23.14<0;1,0>:d   2:w                                 //  ALU pipe: int; $375
(W)     add (1|M0)               r4.0<1>:d     r3.0<0;1,0>:d     r2.0<0;1,0>:d    {Compacted,@2,$1.src} //  ALU pipe: int; $377
(W)     add (1|M0)               r2.7<1>:d     r2.6<0;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $382
(W)     add (1|M0)               r2.8<1>:d     r2.6<0;1,0>:d     2:w                                 //  ALU pipe: int; $383
(W)     add (1|M0)               r2.9<1>:d     r2.6<0;1,0>:d     3:w                                 //  ALU pipe: int; $384
(W)     shl (1|M0)               r5.0<1>:q     r4.0<0;1,0>:d     2:w               {I@4}             //  ALU pipe: int; $379
        sync.allrd                           ($0,$14)                                                // $385
(W)     mov (4|M0)               r7.0<1>:d     r2.6<1;1,0>:d                    {Compacted,@2,$10.src} //  ALU pipe: int; $385
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $380
(W)     store.ugm.d32x4t.a64 (1|M0)  [r6:1]     r7:1               {I@1,$8} // ex_desc:0x0; desc:0x200B584 // $386
        goto (32|M0)                         _0_099            _0_099                                // $387
// B073: [inDivergent],  Preds:{B008},  Succs:{B074, B075}
_0_101:
        cmp (32|M0)   (eq)f1.0   null<1>:d     r22.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $389
(W)     mov (1|M0)               r2.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $390
(f1.0)  sel (32|M0)              r4.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $390
(f0.0)  sel (32|M0)              r6.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw              {$8.src}        //  ALU pipe: int; $390
        and (32|M0)   (ne)f1.0   null<2>:uw    r4.0<1;1,0>:uw    r6.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $390
(~f1.0) goto (32|M0)                         _0_099            _0_099                                //  ALU pipe: int; $391
// B074: [inDivergent],  Preds:{B073},  Succs:{B075}
_0_165:
(W)     mov (1|M0)               r2.0<1>:uq    r5.1<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $393
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $396
        sync.nop                             null                             {Compacted,I@2}        // $394
        mov (16|M0)              r6.0<2>:f     r2.0<0;1,0>:f                    {$10.src}            //  ALU pipe: float; $394
        mov (16|M16)             r8.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $394
        mov (16|M0)              r6.1<2>:f     r2.1<0;1,0>:f                                         //  ALU pipe: float; $395
        mov (16|M16)             r8.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $395
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$9} // ex_desc:0x0; desc:0x800058B // $397
// B075: Preds:{B074, B073, B072, B071, B044, B035, B034, B030, B007},  Succs:{}
_0_099:
        join (32|M0)                         L5312                                                   // 
L5312:
(W)     mov (16|M0)              r127.0<1>:f   r22.0<1;1,0>:f                   {Compacted,$2.src}   //  ALU pipe: float; $399
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$11} // wr:1+0, rd:0; end of thread // $399
L5336:
(W)     mov (16|M0)              null<1>:ud    0xADCA67F4:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xFF2E5959:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x3:ud                                                // 


//.BankConflicts: 1
//.ByteRMWs: 0
//


//.numALUInst: 292
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 75
//.allAtOneDistNum: 13
//.syncInstCount: 11
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 19
//.AfterReadTokenDepCount: 28
