//.kernel _ZTSN9p42extras8FlatNameILNS_4KindE2ELi32EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 604709628 1620024839 -hashmovs1 0 25 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 604709628 1620024839 -hashmovs1 0 25 -GRFBumpUpNumber 2 "
//.instCount 286
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r23.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r0.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r0.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r23.0)
//.declare V0034 (44)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r23.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r4.6)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.12)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.10)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.11)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0063 (73)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.0)
//.declare V0064 (74)  rf=r size=32 type=ud alias=V0036+0 align=16 words (r23.0)
//.declare V0065 (75)  rf=r size=8 type=ud alias=V0062+0 align=4 words (r5.0)
//.declare V0066 (76)  rf=r size=8 type=d alias=V0062+0 align=4 words (r5.0)
//.declare V0067 (77)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0070 (80)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0072 (82)  rf=r size=128 type=d align=32 words (r11.0)
//.declare P01 (83)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0073 (84)  rf=r size=128 type=ud alias=V0072+0 align=32 words (r11.0)
//.declare V0074 (85)  rf=r size=4 type=ud alias=V0034+0 align=2 words (r2.3)
//.declare V0075 (86)  rf=r size=8 type=uq alias=V0058+0 align=4 words (r4.4)
//.declare V0076 (87)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0077 (88)  rf=r size=4 type=d align=32 words (r4.0)
//.declare P02 (89)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0078 (90)  rf=r size=8 type=uq alias=V0056+0 align=4 words (r4.2)
//.declare V0079 (91)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0081 (93)  rf=r size=256 type=uq align=32 words (r5.0)
//.declare V0082 (94)  rf=r size=256 type=ud alias=V0081+0 align=32 words (r5.0)
//.declare V0083 (95)  rf=r size=8 type=ud alias=V0079+0 align=32 words (r2.0)
//.declare V0084 (96)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0085 (97)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare P03 (99)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P04 (100)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P05 (101)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P06 (102)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0087 (103)  rf=r size=4 type=ud alias=V0046+0 align=2 words (r3.0)
//.declare P07 (104)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0091 (108)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0092 (109)  rf=r size=256 type=q align=32 words (r13.0)
//.declare V0093 (110)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0097 (114)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0098 (115)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0099 (116)  rf=r size=128 type=ud alias=V0098+0 align=32 words (r13.0)
//.declare V0103 (120)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0104 (121)  rf=r size=128 type=d align=32 words (r13.0)
//.declare P08 (122)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0108 (126)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare P09 (127)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0112 (131)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0114 (133)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0115 (134)  rf=r size=128 type=w alias=V0114+0 align=32 words (r14.0)
//.declare V0117 (136)  rf=r size=128 type=d alias=V0093+0 align=32 words (r24.0)
//.declare P10 (137)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P11 (138)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P12 (139)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0118 (140)  rf=r size=4 type=ud alias=V0049+0 align=2 words (r3.6)
//.declare P13 (141)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0122 (145)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0123 (146)  rf=r size=256 type=q align=32 words (r11.0)
//.declare V0124 (147)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0128 (151)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0129 (152)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0130 (153)  rf=r size=128 type=ud alias=V0129+0 align=32 words (r11.0)
//.declare V0134 (157)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0135 (158)  rf=r size=128 type=d align=32 words (r11.0)
//.declare P14 (159)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0139 (163)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare P15 (164)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0143 (168)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0145 (170)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare V0146 (171)  rf=r size=128 type=w alias=V0145+0 align=32 words (r12.0)
//.declare V0148 (173)  rf=r size=128 type=d alias=V0124+0 align=32 words (r26.0)
//.declare P16 (174)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P17 (175)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P18 (176)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0149 (177)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r3.12)
//.declare P19 (178)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0153 (182)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0154 (183)  rf=r size=256 type=q align=32 words (r11.0)
//.declare V0155 (184)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0159 (188)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0160 (189)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0161 (190)  rf=r size=128 type=ud alias=V0160+0 align=32 words (r11.0)
//.declare V0165 (194)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0166 (195)  rf=r size=128 type=d align=32 words (r11.0)
//.declare P20 (196)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0170 (200)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare P21 (201)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0174 (205)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0176 (207)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare V0177 (208)  rf=r size=128 type=w alias=V0176+0 align=32 words (r12.0)
//.declare V0179 (210)  rf=r size=128 type=d alias=V0155+0 align=32 words (r28.0)
//.declare V0180 (211)  rf=r size=128 type=f align=32 words (r41.0)
//.declare V0181 (212)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0182 (213)  rf=r size=128 type=d alias=V0180+0 align=32 words (r41.0)
//.declare P22 (214)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0183 (215)  rf=r size=128 type=ud alias=V0181+0 align=32 words (r1.0)
//.declare V0184 (216)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0185 (217)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r41.0)
//.declare V0186 (218)  rf=r size=128 type=ud alias=V0184+0 align=32 words (r1.0)
//.declare V0187 (219)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0188 (220)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0189 (221)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0192 (224)  rf=r size=128 type=f align=32 words (r33.0)
//.declare V0193 (225)  rf=r size=128 type=f alias=V0189+0 align=32 words (r30.0)
//.declare P23 (226)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P24 (227)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P25 (228)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0194 (229)  rf=r size=4 type=ud alias=V0055+0 align=2 words (r4.2)
//.declare P26 (230)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0198 (234)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0200 (236)  rf=r size=256 type=d align=32 words (r19.0)
//.declare V0202 (238)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0203 (239)  rf=r size=128 type=ud alias=V0202+0 align=32 words (r1.0)
//.declare V0207 (243)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0208 (244)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0212 (248)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare P27 (249)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0216 (253)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare P28 (254)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0217 (255)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0218 (256)  rf=r size=128 type=d alias=V0192+0 align=32 words (r33.0)
//.declare P29 (257)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0219 (258)  rf=r size=128 type=ud alias=V0217+0 align=32 words (r1.0)
//.declare V0220 (259)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0221 (260)  rf=r size=128 type=ud alias=V0192+0 align=32 words (r33.0)
//.declare V0222 (261)  rf=r size=128 type=ud alias=V0220+0 align=32 words (r1.0)
//.declare V0223 (262)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0224 (263)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0225 (264)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0226 (265)  rf=r size=128 type=ud alias=V0224+0 align=32 words (r6.0)
//.declare V0227 (266)  rf=r size=128 type=ud alias=V0225+0 align=32 words (r8.0)
//.declare V0228 (267)  rf=r size=64 type=w align=32 words (r32.0)
//.declare V0229 (268)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0230 (269)  rf=r size=128 type=ud alias=V0229+0 align=32 words (r1.0)
//.declare V0235 (274)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0236 (275)  rf=r size=64 type=uw alias=V0228+0 align=32 words (r32.0)
//.declare V0237 (276)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (277)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (278)  rf=r size=128 type=w alias=V0229+0 align=32 words (r1.0)
//.declare  (281)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (282)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (283)  rf=r size=128 type=uw align=32 words (r9.0)
//.declare  (284)  rf=r size=128 type=f align=32 words (r17.0)
//.declare  (285)  rf=r size=128 type=f align=32 words (r19.0)
//.declare  (286)  rf=r size=128 type=f align=32 words (r15.0)
//.declare  (287)  rf=r size=128 type=f align=32 words (r17.0)
//.declare  (288)  rf=r size=128 type=f align=32 words (r15.0)
//.declare  (289)  rf=r size=128 type=f align=32 words (r17.0)
//.declare  (290)  rf=r size=4 type=d align=2 words (r1.0)
//.declare  (291)  rf=r size=4 type=d align=32 words (r2.0)
//.declare  (292)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (293)  rf=r size=128 type=ud align=32 words (r15.0)
//.declare  (294)  rf=r size=128 type=w alias=V0225+0 align=32 words (r8.0)
//.declare  (297)  rf=r size=128 type=q align=32 words (r35.0)
//.declare  (298)  rf=r size=128 type=q align=32 words (r37.0)
//.declare  (299)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (300)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (303)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (304)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (307)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (308)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (311)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (312)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (315)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (316)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (319)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (320)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (323)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (324)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (327)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (328)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (331)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (332)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (335)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (336)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (339)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (340)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (343)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (344)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (347)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (348)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (351)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (352)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (355)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (356)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (359)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (360)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (363)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (364)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (365)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (366)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (369)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (370)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (373)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (374)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (377)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (378)  rf=r size=128 type=q align=32 words (r4.0)
//.declare  (381)  rf=r size=128 type=d alias=+0 align=32 words (r35.0)
//.declare  (382)  rf=r size=128 type=d alias=+0 align=32 words (r37.0)
//.declare  (383)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare  (384)  rf=r size=128 type=d alias=+0 align=32 words (r17.0)
//.declare r0 (385)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (386)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (387)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (388)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (389)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (390)  rf=r size=128 type=ud align=32 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0038    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0034    | :d       |    0x4 | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x10  | inline+0x10      |
// | V0045    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0046    | :d       |    0x4 | r3       | cti+0x20         |
// | V0047    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0048    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0051    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0052    | :d       |    0x4 | r3+0x30  | cti+0x50         |
// | V0053    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0054    | :q       |    0x8 | r4       | cti+0x60         |
// | V0055    | :d       |    0x4 | r4+0x8   | cti+0x68         |
// | V0056    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0057    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0058    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0059    | :d       |    0x4 | r4+0x28  | cti+0x88         |
// | V0060    | :d       |    0x4 | r4+0x2C  | cti+0x8C         |
// | V0042    | :uq      |    0x8 | r4+0x30  | cti+0x90         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B061}
// _main:
(W)     mov (16|M0)              r23.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r23.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r4.0<1>:ud    r2.0<0;1,0>:ud    r23.1<0;1,0>:ud  {Compacted,$1.dst} //  ALU pipe: int; $3
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r23.2<0;1,0>:uw                     //  ALU pipe: int; $3
(W)     mach (1|M0)              r6.0<1>:d     r2.0<0;1,0>:ud    r23.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $9
        mov (16|M16)             r9.0<4>:uw    r1.16<1;1,0>:uw                                       //  ALU pipe: int; $9
(W)     mov (1|M0)               r5.0<2>:f     r4.0<0;1,0>:f                    {I@5}                //  ALU pipe: float; $3
(W)     mov (1|M0)               r5.1<2>:d     r6.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $7
        add (16|M0)              r35.0<1>:q    r5.0<0;1,0>:q     r7.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $9
        add (16|M16)             r37.0<1>:q    r5.0<0;1,0>:q     r9.0<4;1,0>:uw                      //  ALU pipe: int; $9
        mov (16|M0)              r11.0<1>:d    r35.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $10
        mov (16|M16)             r12.0<1>:d    r37.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $10
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r11.0<1;1,0>:ud   r2.3<0;1,0>:ud   {I@1}              //  ALU pipe: int; $11
(~f0.0) goto (32|M0)                         _0_069            _0_069                                //  ALU pipe: int; $12
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B061}
_0_070:
(W)     mov (1|M0)               r2.0<1>:uq    r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $14
(W)     load.ugm.d32x1t.a64 (1|M0)  r4:1        [r2:1]             {I@1,$2} // ex_desc:0x0; desc:0x2108580 // $15
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r4.0<0;1,0>:d     0:w               {$2.dst}          //  ALU pipe: int; $16
(f3.0)  goto (32|M0)                         _0_069            _0_069                                //  ALU pipe: int; $17
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B061}
_0_071:
(W)     mov (1|M0)               r2.0<1>:uq    r4.2<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $19
        mov (32|M0)              r9.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $22
        mov (16|M0)              r5.0<2>:f     r2.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $20
        mov (16|M16)             r7.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $20
        mov (16|M0)              r5.1<2>:f     r2.1<0;1,0>:f                                         //  ALU pipe: float; $21
        mov (16|M16)             r7.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $21
        atomic_or.ugm.d32.a64 (32|M0)  r11:2    [r5:4]            r9:2               {A@1,$3} // ex_desc:0x0; desc:0x8200599 // $23
        cmp (32|M0)   (eq)f2.0   null<1>:d     r11.0<1;1,0>:d    0:w               {$3.dst}          //  ALU pipe: int; $25
(~f2.0) goto (32|M0)                         _0_069            _0_069                                //  ALU pipe: int; $26
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B013}
_0_072:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $28
(W&f1.0) jmpi                                _0_073                                                  //  ALU pipe: int; $29
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B012}
_0_074:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $31
(W&f0.0) jmpi                                _0_075                                                  //  ALU pipe: int; $32
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B011}
_0_076:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r3.0<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $34
(W&f3.0) jmpi                                _0_077                                                  //  ALU pipe: int; $35
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B010}
_0_078:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.0<0;1,0>:d     4:w                                 //  ALU pipe: int; $37
(W&~f2.0) jmpi                               _0_079                                                  //  ALU pipe: int; $38
// B009: [inDivergent],  Preds:{B008},  Succs:{B018}
_0_080:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $40
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $40
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $41
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $41
        load.ugm.d64.a64 (32|M0)  r13:4         [r9:4]             {I@1,$4} // ex_desc:0x0; desc:0x8400780 // $43
        mov (16|M0)              r17.0<2>:f    r13.0<1;1,0>:q                   {$4.dst}             //  ALU pipe: float; $44
        mov (16|M16)             r19.0<2>:f    r15.0<1;1,0>:q                                        //  ALU pipe: float; $44
        mov (16|M0)              r24.0<1>:ud   r17.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $44
        mov (16|M16)             r25.0<1>:ud   r19.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $44
(W)     jmpi                                 _0_081                                                  // $45
// B010: [inDivergent],  Preds:{B008},  Succs:{B018}
_0_079:
        mov (32|M0)              r24.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $47
(W)     jmpi                                 _0_081                                                  // $48
// B011: [inDivergent],  Preds:{B007},  Succs:{B018}
_0_077:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $50
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $50
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $51
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $51
        load.ugm.d32.a64 (32|M0)  r13:2         [r9:4]             {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $53
        mov (32|M0)              r24.0<1>:f    r13.0<1;1,0>:ud                  {$5.dst}             //  ALU pipe: float; $54
(W)     jmpi                                 _0_081                                                  // $55
// B012: [inDivergent],  Preds:{B006},  Succs:{B018}
_0_075:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $57
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $57
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $58
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $58
        load.ugm.d32.a64 (32|M0)  r13:2         [r9:4]             {A@1,$6} // ex_desc:0x0; desc:0x8200580 // $60
        mov (32|M0)              r24.0<1>:f    r13.0<1;1,0>:d                   {$6.dst}             //  ALU pipe: float; $61
(W)     jmpi                                 _0_081                                                  // $62
// B013: [inDivergent],  Preds:{B005},  Succs:{B014, B015}
_0_073:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.0<0;1,0>:d     1:w                                 //  ALU pipe: int; $64
(W&f1.0) jmpi                                _0_082                                                  //  ALU pipe: int; $65
// B014: [inDivergent],  Preds:{B013},  Succs:{B018}
_0_083:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $67
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $67
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $68
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $68
        load.ugm.d32.a64 (32|M0)  r24:2         [r9:4]             {A@1,$7} // ex_desc:0x0; desc:0x8200580 // $70
(W)     jmpi                                 _0_081                                                  // $71
// B015: [inDivergent],  Preds:{B013},  Succs:{B016, B017}
_0_082:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $73
(W&~f0.0) jmpi                               _0_084                                                  //  ALU pipe: int; $74
// B016: [inDivergent],  Preds:{B015},  Succs:{B018}
_0_085:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $76
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $76
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $77
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $77
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r9:4]             {I@1,$8} // ex_desc:0x0; desc:0x8200B80 // $79
        shl (32|M0)              r24.0<1>:d    r14.0<1;1,0>:ud   16:w               {$8.dst}         //  ALU pipe: int; $80
(W)     jmpi                                 _0_081                                                  // $81
// B017: [inDivergent],  Preds:{B015},  Succs:{B018}
_0_084:
        mov (32|M0)              r24.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $83
// B018: [inDivergent],  Preds:{B017, B016, B014, B012, B011, B010, B009},  Succs:{B019, B026}
_0_081:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.6<0;1,0>:d     2:w                                 //  ALU pipe: int; $85
(W&f3.0) jmpi                                _0_086                                                  //  ALU pipe: int; $86
// B019: [inDivergent],  Preds:{B018},  Succs:{B020, B025}
_0_087:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.6<0;1,0>:d     2:w                                 //  ALU pipe: int; $88
(W&f2.0) jmpi                                _0_088                                                  //  ALU pipe: int; $89
// B020: [inDivergent],  Preds:{B019},  Succs:{B021, B024}
_0_089:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r3.6<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $91
(W&f1.0) jmpi                                _0_090                                                  //  ALU pipe: int; $92
// B021: [inDivergent],  Preds:{B020},  Succs:{B022, B023}
_0_091:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.6<0;1,0>:d     4:w                                 //  ALU pipe: int; $94
(W&~f0.0) jmpi                               _0_092                                                  //  ALU pipe: int; $95
// B022: [inDivergent],  Preds:{B021},  Succs:{B031}
_0_093:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $97
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $97
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $98
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $98
        load.ugm.d64.a64 (32|M0)  r11:4         [r7:4]             {I@1,$9} // ex_desc:0x0; desc:0x8400780 // $100
        mov (16|M0)              r15.0<2>:f    r11.0<1;1,0>:q                   {$9.dst}             //  ALU pipe: float; $101
        mov (16|M16)             r17.0<2>:f    r13.0<1;1,0>:q                                        //  ALU pipe: float; $101
        mov (16|M0)              r26.0<1>:ud   r15.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $101
        mov (16|M16)             r27.0<1>:ud   r17.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $101
(W)     jmpi                                 _0_094                                                  // $102
// B023: [inDivergent],  Preds:{B021},  Succs:{B031}
_0_092:
        mov (32|M0)              r26.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $104
(W)     jmpi                                 _0_094                                                  // $105
// B024: [inDivergent],  Preds:{B020},  Succs:{B031}
_0_090:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $107
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $107
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $108
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $108
        load.ugm.d32.a64 (32|M0)  r11:2         [r7:4]             {I@1,$10} // ex_desc:0x0; desc:0x8200580 // $110
        mov (32|M0)              r26.0<1>:f    r11.0<1;1,0>:ud                  {$10.dst}            //  ALU pipe: float; $111
(W)     jmpi                                 _0_094                                                  // $112
// B025: [inDivergent],  Preds:{B019},  Succs:{B031}
_0_088:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $114
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $114
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $115
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $115
        load.ugm.d32.a64 (32|M0)  r11:2         [r7:4]             {A@1,$11} // ex_desc:0x0; desc:0x8200580 // $117
        mov (32|M0)              r26.0<1>:f    r11.0<1;1,0>:d                   {$11.dst}            //  ALU pipe: float; $118
(W)     jmpi                                 _0_094                                                  // $119
// B026: [inDivergent],  Preds:{B018},  Succs:{B027, B028}
_0_086:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.6<0;1,0>:d     1:w                                 //  ALU pipe: int; $121
(W&f3.0) jmpi                                _0_095                                                  //  ALU pipe: int; $122
// B027: [inDivergent],  Preds:{B026},  Succs:{B031}
_0_096:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $124
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $124
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $125
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $125
        load.ugm.d32.a64 (32|M0)  r26:2         [r7:4]             {A@1,$12} // ex_desc:0x0; desc:0x8200580 // $127
(W)     jmpi                                 _0_094                                                  // $128
// B028: [inDivergent],  Preds:{B026},  Succs:{B029, B030}
_0_095:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.6<0;1,0>:d     0:w                                 //  ALU pipe: int; $130
(W&~f2.0) jmpi                               _0_097                                                  //  ALU pipe: int; $131
// B029: [inDivergent],  Preds:{B028},  Succs:{B031}
_0_098:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $133
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $133
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $134
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.1<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $134
        load.ugm.d16u32.a64 (32|M0)  r12:2      [r7:4]             {I@1,$13} // ex_desc:0x0; desc:0x8200B80 // $136
        shl (32|M0)              r26.0<1>:d    r12.0<1;1,0>:ud   16:w               {$13.dst}        //  ALU pipe: int; $137
(W)     jmpi                                 _0_094                                                  // $138
// B030: [inDivergent],  Preds:{B028},  Succs:{B031}
_0_097:
        mov (32|M0)              r26.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $140
// B031: [inDivergent],  Preds:{B030, B029, B027, B025, B024, B023, B022},  Succs:{B032, B039}
_0_094:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.12<0;1,0>:d    2:w                                 //  ALU pipe: int; $142
(W&f1.0) jmpi                                _0_099                                                  //  ALU pipe: int; $143
// B032: [inDivergent],  Preds:{B031},  Succs:{B033, B038}
_0_100:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.12<0;1,0>:d    2:w                                 //  ALU pipe: int; $145
(W&f0.0) jmpi                                _0_101                                                  //  ALU pipe: int; $146
// B033: [inDivergent],  Preds:{B032},  Succs:{B034, B037}
_0_102:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r3.12<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $148
(W&f3.0) jmpi                                _0_103                                                  //  ALU pipe: int; $149
// B034: [inDivergent],  Preds:{B033},  Succs:{B035, B036}
_0_104:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.12<0;1,0>:d    4:w                                 //  ALU pipe: int; $151
(W&~f2.0) jmpi                               _0_105                                                  //  ALU pipe: int; $152
// B035: [inDivergent],  Preds:{B034},  Succs:{B044}
_0_106:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $154
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $154
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $155
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $155
        load.ugm.d64.a64 (32|M0)  r11:4         [r7:4]             {I@1,$14} // ex_desc:0x0; desc:0x8400780 // $157
        mov (16|M0)              r15.0<2>:f    r11.0<1;1,0>:q                   {$14.dst}            //  ALU pipe: float; $158
        mov (16|M16)             r17.0<2>:f    r13.0<1;1,0>:q                                        //  ALU pipe: float; $158
        mov (16|M0)              r28.0<1>:ud   r15.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $158
        mov (16|M16)             r29.0<1>:ud   r17.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $158
(W)     jmpi                                 _0_107                                                  // $159
// B036: [inDivergent],  Preds:{B034},  Succs:{B044}
_0_105:
        mov (32|M0)              r28.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $161
(W)     jmpi                                 _0_107                                                  // $162
// B037: [inDivergent],  Preds:{B033},  Succs:{B044}
_0_103:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $164
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $164
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $165
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $165
        load.ugm.d32.a64 (32|M0)  r11:2         [r7:4]             {I@1,$15} // ex_desc:0x0; desc:0x8200580 // $167
        mov (32|M0)              r28.0<1>:f    r11.0<1;1,0>:ud                  {$15.dst}            //  ALU pipe: float; $168
(W)     jmpi                                 _0_107                                                  // $169
// B038: [inDivergent],  Preds:{B032},  Succs:{B044}
_0_101:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $171
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $171
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $172
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $172
        load.ugm.d32.a64 (32|M0)  r11:2         [r7:4]             {A@1,$0} // ex_desc:0x0; desc:0x8200580 // $174
        mov (32|M0)              r28.0<1>:f    r11.0<1;1,0>:d                   {$0.dst}             //  ALU pipe: float; $175
(W)     jmpi                                 _0_107                                                  // $176
// B039: [inDivergent],  Preds:{B031},  Succs:{B040, B041}
_0_099:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.12<0;1,0>:d    1:w                                 //  ALU pipe: int; $178
(W&f1.0) jmpi                                _0_108                                                  //  ALU pipe: int; $179
// B040: [inDivergent],  Preds:{B039},  Succs:{B044}
_0_109:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $181
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $181
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $182
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $182
        load.ugm.d32.a64 (32|M0)  r28:2         [r7:4]             {A@1,$1} // ex_desc:0x0; desc:0x8200580 // $184
(W)     jmpi                                 _0_107                                                  // $185
// B041: [inDivergent],  Preds:{B039},  Succs:{B042, B043}
_0_108:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $187
(W&~f0.0) jmpi                               _0_110                                                  //  ALU pipe: int; $188
// B042: [inDivergent],  Preds:{B041},  Succs:{B044}
_0_111:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $190
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $190
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $191
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $191
        load.ugm.d16u32.a64 (32|M0)  r12:2      [r7:4]             {I@1,$2} // ex_desc:0x0; desc:0x8200B80 // $193
        shl (32|M0)              r28.0<1>:d    r12.0<1;1,0>:ud   16:w               {$2.dst}         //  ALU pipe: int; $194
(W)     jmpi                                 _0_107                                                  // $195
// B043: [inDivergent],  Preds:{B041},  Succs:{B044}
_0_110:
        mov (32|M0)              r28.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $197
// B044: [inDivergent],  Preds:{B043, B042, B040, B038, B037, B036, B035},  Succs:{B045, B046}
_0_107:
        sync.nop                             null                             {Compacted,I@1}        // $199
        sync.nop                             null                             {Compacted,$1.dst}     // $199
        add (32|M0)              r41.0<1>:f    r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,$12.dst} //  ALU pipe: float; $199
        and (32|M0)              r1.0<1>:d     r41.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $200
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $201
(f3.0)  goto (32|M0)                         _0_112            _0_112                                //  ALU pipe: int; $202
// B045: [inDivergent],  Preds:{B044},  Succs:{B047}
_0_113:
        shr (32|M0)              r1.0<1>:ud    r41.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $204
        and (32|M0)              r6.0<1>:d     r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $205
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r41.0<1;0>:d      32767:w               {@1,$7.src} //  ALU pipe: int; $206
        and (32|M0)              r30.0<1>:d    r8.0<1;1,0>:d     -65536:d               {I@1}        //  ALU pipe: int; $207
        goto (32|M0)                         _0_112            _0_114                                // $208
// B046: [inDivergent],  Preds:{B044},  Succs:{B047}
_0_112:
        join (32|M0)                         _0_114                                                  // 
L2664:
(W)     mov (1|M0)               r1.0<1>:f     0xFFBF0000:f                                          //  (0xffbf0000:f); ALU pipe: float; $212
(W)     mov (1|M0)               r2.0<1>:f     0x400000:f                               {Compacted}  //  (0x00400000:f); ALU pipe: float; $212
        bfn.(s0&s1|s2) (32|M0)   r30.0<1>:ud   r41.0<1;0>:ud     r1.0<0;0>:d       r2.0<0>:d        {F@1} //  ALU pipe: int; $212
// B047: [inDivergent],  Preds:{B046, B045},  Succs:{B048, B054}
_0_114:
        join (32|M0)                         _0_069                                                  // 
L2720:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $215
        sync.nop                             null                             {Compacted,I@3}        // $214
        add (32|M0)              r33.0<1>:f    r24.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,$7.dst} //  ALU pipe: float; $214
(W&f2.0) jmpi                                _0_115                                                  //  ALU pipe: int; $216
// B048: [inDivergent],  Preds:{B047},  Succs:{B049, B053}
_0_116:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $218
(W&f1.0) jmpi                                _0_117                                                  //  ALU pipe: int; $219
// B049: [inDivergent],  Preds:{B048},  Succs:{B050, B052}
_0_118:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r4.2<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $221
(W&f0.0) jmpi                                _0_119                                                  //  ALU pipe: int; $222
// B050: [inDivergent],  Preds:{B049},  Succs:{B051, B061}
_0_120:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r4.2<0;1,0>:d     4:w                                 //  ALU pipe: int; $224
(~f3.0) goto (32|M0)                         _0_069            _0_069                                //  ALU pipe: int; $225
// B051: [inDivergent],  Preds:{B050},  Succs:{B061}
_0_121:
        mov (16|M0)              r11.0<2>:ud   r33.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $230
        mov (16|M16)             r15.0<2>:ud   r34.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $230
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $227
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $227
        mov (16|M0)              r13.0<1>:q    r11.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $230
        mov (16|M16)             r17.0<1>:q    r15.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $230
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $228
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $228
        mov (16|M0)              r19.0<1>:d    r13.0<2;1,0>:d                   {Compacted,I@4}      //  ALU pipe: int; $231
        mov (16|M0)              r21.0<1>:d    r13.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $233
        mov (16|M16)             r20.0<1>:d    r17.0<2;1,0>:d                   {Compacted,I@5}      //  ALU pipe: int; $232
        mov (16|M16)             r22.0<1>:d    r17.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $234
        store.ugm.d32x2.a64 (32|M0)  [r7:4]     r19:4              {I@1,$3} // ex_desc:0x0; desc:0x8001584 // $235
        goto (32|M0)                         _0_069            _0_069                                // $236
// B052: [inDivergent],  Preds:{B049},  Succs:{B061}
_0_119:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $239
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted,$3.src} //  ALU pipe: int; $239
        mov (32|M0)              r1.0<1>:ud    r33.0<1;1,0>:f                                        //  ALU pipe: int; $238
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $240
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $240
        store.ugm.d32.a64 (32|M0)  [r9:4]       r1:2               {I@1,$4} // ex_desc:0x0; desc:0x8000584 // $242
        goto (32|M0)                         _0_069            _0_069                                // $243
// B053: [inDivergent],  Preds:{B048},  Succs:{B061}
_0_117:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $246
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $246
        mov (32|M0)              r1.0<1>:d     r33.0<1;1,0>:f                   {$4.src}             //  ALU pipe: int; $245
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $247
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $247
        store.ugm.d32.a64 (32|M0)  [r9:4]       r1:2               {I@1,$5} // ex_desc:0x0; desc:0x8000584 // $249
        goto (32|M0)                         _0_069            _0_069                                // $250
// B054: [inDivergent],  Preds:{B047},  Succs:{B055, B056}
_0_115:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.2<0;1,0>:d     1:w                                 //  ALU pipe: int; $252
(W&f2.0) jmpi                                _0_122                                                  //  ALU pipe: int; $253
// B055: [inDivergent],  Preds:{B054},  Succs:{B061}
_0_123:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted,$5.src} //  ALU pipe: int; $255
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $255
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $256
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $256
        store.ugm.d32.a64 (32|M0)  [r7:4]       r33:2              {I@1,$6} // ex_desc:0x0; desc:0x8000584 // $258
        goto (32|M0)                         _0_069            _0_069                                // $259
// B056: [inDivergent],  Preds:{B054},  Succs:{B057, B061}
_0_122:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $261
(~f1.0) goto (32|M0)                         _0_069            _0_069                                //  ALU pipe: int; $262
// B057: [inDivergent],  Preds:{B056},  Succs:{B058, B059}
_0_124:
        and (32|M0)              r1.0<1>:d     r33.0<1;1,0>:d    2147483647:d               {$5.src} //  ALU pipe: int; $264
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $265
(f0.0)  goto (32|M0)                         _0_125            _0_125                                //  ALU pipe: int; $266
// B058: [inDivergent],  Preds:{B057},  Succs:{B060}
_0_126:
        shr (32|M0)              r1.0<1>:ud    r33.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $268
        and (32|M0)              r4.0<1>:d     r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $269
        add3 (32|M0)             r6.0<1>:d     r4.0<1;0>:d       r33.0<1;0>:d      32767:w               {@1,$6.src} //  ALU pipe: int; $270
        shr (32|M0)              r8.0<1>:ud    r6.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $271
        mov (32|M0)              r32.0<1>:w    r8.0<2;1,0>:w                    {I@1}                //  ALU pipe: int; $272
        goto (32|M0)                         _0_125            _0_127                                // $273
// B059: [inDivergent],  Preds:{B057},  Succs:{B060}
_0_125:
        join (32|M0)                         _0_127                                                  // 
L3448:
        shr (32|M0)              r1.0<1>:ud    r33.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $275
        or (32|M0)               r32.0<1>:w    r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $277
// B060: [inDivergent],  Preds:{B059, B058},  Succs:{B061}
_0_127:
        join (32|M0)                         _0_069                                                  // 
L3496:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $279
        shl (16|M16)             r4.0<1>:q     r37.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $279
        mov (32|M0)              r10.0<1>:ud   r32.0<1;1,0>:uw                  {@4,$6.src}          //  ALU pipe: int; $282
        add (16|M0)              r6.0<1>:q     r1.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $280
        add (16|M16)             r8.0<1>:q     r4.0<1;1,0>:q     r3.7<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $280
        store.ugm.d16u32.a64 (32|M0)  [r6:4]    r10:2              {I@1,$7} // ex_desc:0x0; desc:0x8000B84 // $283
// B061: Preds:{B060, B056, B055, B053, B052, B051, B050, B004, B003, B002},  Succs:{}
_0_069:
        join (32|M0)                         L3576                                                   // 
L3576:
(W)     mov (16|M0)              r127.0<1>:f   r23.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $285
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$8} // wr:1+0, rd:0; end of thread // $285
L3600:
(W)     mov (16|M0)              null<1>:ud    0x240B22FC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x608F9E07:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x19:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 203
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 38
//.allAtOneDistNum: 11
//.syncInstCount: 3
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 19
//.AfterReadTokenDepCount: 23
