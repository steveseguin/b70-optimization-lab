//.kernel _ZTSN9p42extras6NgNameILi11ELi1ELi0ELi0ELi0EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 604709628 1620024839 -hashmovs1 0 2 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 604709628 1620024839 -hashmovs1 0 2 -GRFBumpUpNumber 2 "
//.instCount 379
//.RA type	LOCAL_FIRST_FIT_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r22.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.1)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.12)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.13)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r22.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.1)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r22.0)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=uq align=4 words (r5.5)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r2.4)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r2.5)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r2.6)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r2.7)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0073 (83)  rf=r size=16 type=d align=2 words (r2.6)
//.declare V0074 (84)  rf=r size=8 type=uq alias=V0066+0 align=32 words (r5.1)
//.declare P01 (85)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P02 (86)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0075 (87)  rf=r size=8 type=uq alias=V0069+0 align=32 words (r5.4)
//.declare V0076 (88)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0077 (89)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P03 (90)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0078 (91)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0079 (92)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0081 (94)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0082 (95)  rf=r size=256 type=ud alias=V0081+0 align=32 words (r6.0)
//.declare V0083 (96)  rf=r size=8 type=ud alias=V0079+0 align=32 words (r2.0)
//.declare V0084 (97)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0085 (98)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P04 (100)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0088 (102)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (103)  rf=r size=64 type=ud align=32 words (r4.0)
//.declare  (104)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (105)  rf=r size=32 type=ud align=32 words (r7.0)
//.declare V0089 (106)  rf=r size=4 type=f align=32 words (r3.0)
//.declare V0090 (107)  rf=r size=4 type=ud align=32 words (r2.0)
//.declare P05 (108)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0091 (109)  rf=r size=8 type=uq alias=V0068+0 align=32 words (r5.3)
//.declare  (110)  rf=r size=64 type=ud align=32 words (r4.0)
//.declare  (111)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (112)  rf=r size=32 type=ud align=32 words (r7.0)
//.declare V0092 (113)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0093 (114)  rf=r size=4 type=d align=32 words (r23.0)
//.declare V0094 (115)  rf=r size=4 type=d align=2 words (r2.4)
//.declare P06 (116)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P07 (117)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P08 (118)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0095 (119)  rf=r size=2 type=w align=1 words (r3.0)
//.declare V0096 (120)  rf=r size=2 type=b align=1 words (r4.0)
//.declare V0097 (121)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0098 (122)  rf=r size=2 type=ub alias=V0096+0 align=1 words (r4.0)
//.declare V0099 (123)  rf=r size=4 type=d align=2 words (r23.1)
//.declare V0100 (124)  rf=r size=4 type=d align=2 words (r23.2)
//.declare V0101 (125)  rf=r size=4 type=d align=2 words (r23.3)
//.declare P09 (126)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0102 (127)  rf=r size=4 type=ud alias=V0099+0 align=2 words (r23.1)
//.declare V0103 (128)  rf=r size=4 type=d align=2 words (r26.0)
//.declare V0104 (129)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0105 (130)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0106 (131)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0107 (132)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0108 (133)  rf=r size=4 type=ud alias=V0106+0 align=2 words (r3.1)
//.declare V0109 (134)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0110 (135)  rf=r size=4 type=ud alias=V0109+0 align=2 words (r3.4)
//.declare V0111 (136)  rf=r size=4 type=d alias=+0 align=2 words (r4.4)
//.declare V0112 (137)  rf=r size=4 type=f align=2 words (r4.1)
//.declare V0113 (138)  rf=r size=32 type=ud alias=V0036+0 align=32 words (r22.0)
//.declare V0114 (139)  rf=r size=4 type=f align=2 words (r4.2)
//.declare V0115 (140)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0116 (141)  rf=r size=4 type=f align=2 words (r6.1)
//.declare V0117 (142)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0118 (143)  rf=r size=4 type=ud alias=V0117+0 align=2 words (r6.2)
//.declare V0119 (144)  rf=r size=4 type=d alias=+4 align=2 words (r4.5)
//.declare V0120 (145)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0121 (146)  rf=r size=4 type=ud alias=V0120+0 align=2 words (r2.0)
//.declare V0122 (147)  rf=r size=4 type=f alias=+0 align=2 words (r2.8)
//.declare V0123 (148)  rf=r size=4 type=ud alias=V0111+0 align=2 words (r4.4)
//.declare V0124 (149)  rf=r size=4 type=f alias=+4 align=2 words (r2.9)
//.declare V0125 (150)  rf=r size=4 type=ud alias=V0119+0 align=2 words (r4.5)
//.declare V0126 (151)  rf=r size=4 type=f align=2 words (r7.0)
//.declare V0128 (153)  rf=r size=4 type=f align=2 words (r2.1)
//.declare V0130 (155)  rf=r size=4 type=f align=2 words (r3.4)
//.declare V0131 (156)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0132 (157)  rf=r size=4 type=f align=2 words (r9.0)
//.declare V0133 (158)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0134 (159)  rf=r size=4 type=ud alias=V0133+0 align=2 words (r5.0)
//.declare V0135 (160)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0136 (161)  rf=r size=4 type=d align=32 words (r11.0)
//.declare V0137 (162)  rf=r size=4 type=d align=2 words (r10.1)
//.declare V0138 (163)  rf=r size=4 type=d align=2 words (r12.0)
//.declare V0139 (164)  rf=r size=4 type=ud alias=V0137+0 align=2 words (r10.1)
//.declare V0140 (165)  rf=r size=4 type=ud alias=V0138+0 align=2 words (r12.0)
//.declare  (166)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0141 (167)  rf=r size=4 type=d align=2 words (r13.0)
//.declare V0142 (168)  rf=r size=4 type=d align=32 words (r27.0)
//.declare V0143 (169)  rf=r size=4 type=d align=2 words (r23.4)
//.declare V0144 (170)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0145 (171)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0146 (172)  rf=r size=4 type=d align=2 words (r23.5)
//.declare V0147 (173)  rf=r size=4 type=d align=2 words (r2.1)
//.declare  (174)  rf=f16  size=2 type=uw align=1 words (f1.0)
//.declare V0148 (175)  rf=r size=4 type=d align=2 words (r23.6)
//.declare V0149 (176)  rf=r size=4 type=d align=2 words (r23.7)
//.declare V0150 (177)  rf=r size=4 type=d align=2 words (r5.0)
//.declare  (178)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare P10 (179)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0151 (180)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0152 (181)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.1)
//.declare V0153 (182)  rf=r size=4 type=d align=2 words (r23.8)
//.declare V0154 (183)  rf=r size=128 type=d align=32 words (r30.0)
//.declare P11 (184)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0155 (185)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0156 (186)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0158 (188)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0159 (189)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0160 (190)  rf=r size=8 type=uq alias=V0159+0 align=32 words (r4.0)
//.declare V0161 (191)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0162 (192)  rf=r size=4 type=d align=2 words (r6.0)
//.declare P12 (193)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0163 (194)  rf=r size=4 type=f alias=V0162+0 align=2 words (r6.0)
//.declare P13 (195)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0164 (196)  rf=r size=4 type=d align=2 words (r8.0)
//.declare P14 (197)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P15 (198)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (199)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P16 (200)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P17 (201)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0165 (202)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0166 (203)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare P18 (204)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0167 (205)  rf=r size=4 type=d align=32 words (r36.0)
//.declare V0168 (206)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0173 (211)  rf=r size=256 type=uq align=32 words (r16.0)
//.declare V0174 (212)  rf=r size=128 type=d align=32 words (r20.0)
//.declare P19 (213)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P20 (214)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0175 (215)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0177 (217)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0178 (218)  rf=r size=256 type=ud alias=V0177+0 align=32 words (r6.0)
//.declare V0179 (219)  rf=r size=8 type=ud alias=V0175+0 align=32 words (r2.0)
//.declare V0180 (220)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0181 (221)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0182 (222)  rf=r size=4 type=d align=2 words (r23.9)
//.declare V0183 (223)  rf=r size=4 type=d align=2 words (r23.10)
//.declare V0184 (224)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0185 (225)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0186 (226)  rf=r size=4 type=d align=2 words (r26.1)
//.declare V0187 (227)  rf=r size=4 type=d align=2 words (r23.11)
//.declare V0188 (228)  rf=r size=4 type=d align=32 words (r37.0)
//.declare V0189 (229)  rf=r size=4 type=d align=2 words (r23.12)
//.declare V0190 (230)  rf=r size=4 type=d align=2 words (r23.13)
//.declare V0191 (231)  rf=r size=128 type=d align=32 words (r38.0)
//.declare P21 (232)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0192 (233)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0193 (234)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0198 (239)  rf=r size=256 type=uq align=32 words (r16.0)
//.declare V0199 (240)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0200 (241)  rf=r size=128 type=d align=32 words (r42.0)
//.declare P22 (242)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P23 (243)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0201 (244)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0202 (245)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0207 (250)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare P24 (251)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0208 (252)  rf=r size=4 type=d align=2 words (r23.14)
//.declare P25 (253)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P26 (254)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0209 (255)  rf=r size=4 type=d alias=+0 align=2 words (r27.8)
//.declare V0211 (257)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0212 (258)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0213 (259)  rf=r size=8 type=uq alias=V0212+0 align=32 words (r4.0)
//.declare V0214 (260)  rf=r size=4 type=f align=32 words (r44.0)
//.declare V0215 (261)  rf=r size=4 type=d align=2 words (r23.15)
//.declare V0216 (262)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0217 (263)  rf=r size=4 type=d align=2 words (r26.2)
//.declare P27 (264)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0218 (265)  rf=r size=4 type=ud alias=V0216+0 align=2 words (r3.0)
//.declare V0219 (266)  rf=r size=4 type=d alias=+0 align=2 words (r27.4)
//.declare V0220 (267)  rf=r size=4 type=d alias=+4 align=2 words (r27.5)
//.declare V0221 (268)  rf=r size=4 type=d align=2 words (r26.3)
//.declare V0222 (269)  rf=r size=4 type=d alias=+4 align=2 words (r27.9)
//.declare V0223 (270)  rf=r size=4 type=d align=2 words (r26.4)
//.declare V0224 (271)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0226 (273)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0227 (274)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0228 (275)  rf=r size=8 type=uq alias=V0227+0 align=32 words (r4.0)
//.declare V0229 (276)  rf=r size=4 type=f align=32 words (r45.0)
//.declare P28 (277)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0230 (278)  rf=r size=4 type=d align=2 words (r26.5)
//.declare P29 (279)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P30 (280)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0231 (281)  rf=r size=4 type=d align=2 words (r27.1)
//.declare  (282)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare V0232 (283)  rf=r size=4 type=d align=2 words (r26.6)
//.declare V0233 (284)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0235 (286)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0236 (287)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0237 (288)  rf=r size=8 type=uq alias=V0236+0 align=32 words (r4.0)
//.declare V0238 (289)  rf=r size=4 type=f align=32 words (r46.0)
//.declare P31 (290)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0239 (291)  rf=r size=4 type=d align=2 words (r26.7)
//.declare P32 (292)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P33 (293)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0240 (294)  rf=r size=4 type=d align=2 words (r2.0)
//.declare  (295)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0241 (296)  rf=r size=4 type=d align=2 words (r26.8)
//.declare V0242 (297)  rf=r size=4 type=d align=2 words (r26.9)
//.declare V0243 (298)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0245 (300)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0246 (301)  rf=r size=8 type=q align=32 words (r6.0)
//.declare V0247 (302)  rf=r size=8 type=uq alias=V0246+0 align=32 words (r6.0)
//.declare V0248 (303)  rf=r size=4 type=f align=32 words (r47.0)
//.declare P34 (304)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0249 (305)  rf=r size=4 type=d align=2 words (r26.10)
//.declare P35 (306)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P36 (307)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0250 (308)  rf=r size=4 type=d align=2 words (r27.2)
//.declare  (309)  rf=f16  size=2 type=uw align=1 words (f1.0)
//.declare V0251 (310)  rf=r size=4 type=d align=2 words (r26.11)
//.declare V0252 (311)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0254 (313)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0255 (314)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0256 (315)  rf=r size=8 type=uq alias=V0255+0 align=32 words (r4.0)
//.declare V0257 (316)  rf=r size=4 type=f align=32 words (r48.0)
//.declare P37 (317)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0258 (318)  rf=r size=4 type=d align=2 words (r26.12)
//.declare P38 (319)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P39 (320)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0259 (321)  rf=r size=4 type=d align=2 words (r2.0)
//.declare  (322)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare P40 (323)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P41 (324)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0260 (325)  rf=r size=4 type=d align=2 words (r27.3)
//.declare V0261 (326)  rf=r size=4 type=d align=2 words (r26.13)
//.declare V0262 (327)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0264 (329)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0265 (330)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0266 (331)  rf=r size=8 type=uq alias=V0265+0 align=32 words (r4.0)
//.declare V0267 (332)  rf=r size=4 type=f align=32 words (r49.0)
//.declare P42 (333)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0268 (334)  rf=r size=4 type=d align=2 words (r26.14)
//.declare P43 (335)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P44 (336)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0269 (337)  rf=r size=4 type=d align=2 words (r2.0)
//.declare  (338)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare P45 (339)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P46 (340)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0270 (341)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0271 (342)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0272 (343)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0274 (345)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0277 (348)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0278 (349)  rf=r size=16 type=d align=32 words (r7.0)
//.declare P47 (350)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0279 (351)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0281 (353)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0282 (354)  rf=r size=256 type=ud alias=V0281+0 align=32 words (r6.0)
//.declare V0283 (355)  rf=r size=8 type=ud alias=V0279+0 align=32 words (r2.0)
//.declare V0284 (356)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0285 (357)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare  (358)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (359)  rf=r size=8 type=f align=8 words (r2.8)
//.declare  (360)  rf=r size=8 type=ud align=8 words (r4.4)
//.declare  (361)  rf=r size=8 type=d align=8 words (r27.4)
//.declare  (362)  rf=r size=8 type=d align=8 words (r27.8)
//.declare  (363)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare  (364)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (365)  rf=r size=4 type=f align=2 words (r3.0)
//.declare  (366)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (367)  rf=r size=4 type=f align=2 words (r5.0)
//.declare  (368)  rf=r size=2 type=w align=1 words (r7.0)
//.declare  (369)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (370)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (371)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (372)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (373)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (374)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (375)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (376)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (377)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (378)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (379)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (380)  rf=r size=2 type=w align=1 words (r2.0)
//.declare  (381)  rf=r size=2 type=uw align=1 words (r2.0)
//.declare  (385)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (386)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (391)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (392)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (397)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (398)  rf=r size=128 type=q align=32 words (r16.0)
//.declare r0 (401)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (402)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (403)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (404)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (405)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (406)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (407)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0285    | :ud      |    0x4 | r2       | inline+0x0       |
// | V0034    | :uq      |    0x8 | r2+0x8   | inline+0x8       |
// | V0043    | :d       |    0x4 | r2+0x10  | inline+0x10      |
// | V0044    | :d       |    0x4 | r2+0x14  | inline+0x14      |
// | V0045    | :d       |    0x4 | r2+0x18  | inline+0x18      |
// | V0046    | :d       |    0x4 | r2+0x1C  | inline+0x1C      |
// | V0047    | :d       |    0x4 | r3       | cti+0x20         |
// | V0048    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0049    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0050    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0051    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0052    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0053    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0054    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0055    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0056    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0057    | :q       |    0x8 | r4       | cti+0x60         |
// | V0058    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0059    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0060    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0061    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0062    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0063    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0064    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0065    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0066    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0067    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0068    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0069    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0041    | :uq      |    0x8 | r5+0x28  | cti+0xC8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B007}
// _main:
(W)     mov (16|M0)              r22.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
        cmp (32|M0)   (eq)f1.0   null<2>:w     r1.0<1;1,0>:w     0:w               {A@1,$0.dst}      //  ALU pipe: int; $3
        cmp (32|M0)   (eq)f0.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $2
(~f1.0) goto (32|M0)                         _0_085            _0_085                                //  ALU pipe: int; $4
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_086:
(W)     mov (1|M0)               r2.0<1>:uq    r5.4<0;1,0>:uq                   {Compacted,$2.dst}   //  ALU pipe: int; $6
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r2:1]             {I@1,$1} // ex_desc:0x0; desc:0x2108580 // $7
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$1.dst}          //  ALU pipe: int; $8
(W&~f3.0) jmpi                               _0_087                                                  //  ALU pipe: int; $9
// B004: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_088:
        mov (32|M0)              r24.0<1>:ud   0x3F800000:ud                                         //  ALU pipe: int; $11
(W)     jmpi                                 _0_089                                                  // $12
// B005: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_087:
(W)     mov (1|M0)               r2.0<1>:uq    r5.1<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $14
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $17
        mov (16|M0)              r6.0<2>:f     r2.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $15
        mov (16|M16)             r8.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $15
        mov (16|M0)              r6.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $16
        mov (16|M16)             r8.1<2>:ud    r2.1<0;1,0>:ud                   {F@1}                //  ALU pipe: int; $16
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {I@1,$3} // ex_desc:0x0; desc:0x8200599 // $18
(W)     mov (1|M0)               r3.0<1>:f     0x3F800000:f                               {Compacted} //  ALU pipe: float; $21
        cmp (32|M0)   (ne)f1.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$3.dst}          //  ALU pipe: int; $20
(f1.0)  sel (32|M0)              r24.0<1>:f    r3.0<0;1,0>:f     0x0:f               {F@1}           //  ALU pipe: float; $21
// B006: [inDivergent],  Preds:{B005, B004},  Succs:{B007}
_0_089:
        mov (32|M0)              r6.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $24
        store.slm.d32.a32 (32|M0)  [r6:2]       r24:2              {A@1,$4} // ex_desc:0x0; desc:0x4000504 // $25
// B007: Preds:{B006, B002},  Succs:{B008, B067}
_0_085:
        join (32|M0)                         L536                                                    // 
L536:
(W)     send.slm (1|M0)          r4       r22  null:0  0x0            0x0210001F           {$1} // wr:1+0, rd:1; fence.slm.none.group // $27
(W)     mov (8|M0)               null<1>:ud    r4.0<1;1,0>:ud                   {Compacted,$1.dst}   //  memory fence commit; ALU pipe: int; $28
        sync.nop                             null                             {Compacted,$4.src}     // $28
(W)     send.ugm (1|M0)          r6       r22  null:0  0x0            0x0210001F           {$5} // wr:1+0, rd:1; fence.ugm.none.group // $28
(W)     mov (1|M0)               r7.2<1>:f     0x100:f                                               //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $29
(W)     mov (2|M0)               r7.10<1>:ub   r22.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $29
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$5.dst}   //  memory fence commit; ALU pipe: int; $29
(W)     send.gtwy (1|M0)         null     r7  null:0  0x0            0x02000004           {I@2,$6} // wr:1+0, rd:0; signal barrier // $29
(W)     sync.bar                             0x0                                                     // $29
(W)     mov (1|M0)               r2.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $30
(W)     load.slm.d32x1t.a32 (1|M0)  r3:1        [r2:1]             {I@1,$7} // ex_desc:0x0; desc:0x2108500 // $31
(W)     cmp (32|M0)   (ne)f2.0   null<1>:f     r3.0<0;1,0>:f     0x0:f               {$7.dst}        //  ALU pipe: float; $32
(W&f2.0) jmpi                                _0_090                                                  //  ALU pipe: int; $33
// B008: Preds:{B007},  Succs:{B009, B065}
_0_091:
(W)     send.slm (1|M0)          r4       r22  null:0  0x0            0x0210001F           {$8} // wr:1+0, rd:1; fence.slm.none.group // $35
(W)     mov (8|M0)               null<1>:ud    r4.0<1;1,0>:ud                   {Compacted,$8.dst}   //  memory fence commit; ALU pipe: int; $36
(W)     send.ugm (1|M0)          r6       r22  null:0  0x0            0x0210001F           {$9} // wr:1+0, rd:1; fence.ugm.none.group // $36
(W)     mov (1|M0)               r7.2<1>:f     0x100:f                               {$6.src}        //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $37
(W)     mov (2|M0)               r7.10<1>:ub   r22.11<0;1,0>:ub                 {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $37
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$9.dst}   //  memory fence commit; ALU pipe: int; $37
(W)     send.gtwy (1|M0)         null     r7  null:0  0x0            0x02000004           {I@2,$10} // wr:1+0, rd:0; signal barrier // $37
(W)     sync.bar                             0x0                                                     // $37
(W)     mov (1|M0)               r2.0<1>:uq    r5.3<0;1,0>:uq                   {Compacted,$2.dst}   //  ALU pipe: int; $38
(W)     add (1|M0)               r2.4<1>:d     r3.2<0;1,0>:d     -r2.5<0;1,0>:d                      //  ALU pipe: int; $40
(W)     load.ugm.d32x1t.a64 (1|M0)  r23:1       [r2:1]             {I@1,$11} // ex_desc:0x0; desc:0x2108580 // $39
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r23.0<0;1,0>:d    r2.4<0;1,0>:d    {$11.dst}          //  ALU pipe: int; $41
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:d     r23.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $42
(W&f1.0) jmpi                                _0_092                                                  //  ALU pipe: int; $44
// B009: Preds:{B008},  Succs:{B010, B011}
_0_093:
(W)     cmp (1|M0)    (lt)f2.0   null<1>:d     r3.2<0;1,0>:d     -3:w                                //  ALU pipe: int; $46
(W)     mov (1|M0)               r2.0<1>:hf    0x6:hf                                                //  ALU pipe: float; $47
(W)     add (1|M0)               r23.3<1>:d    r3.3<0;1,0>:d     3:w                                 //  ALU pipe: int; $52
(W&f2.0) sel (1|M0)              r3.0<1>:w     r2.0<0;1,0>:w     3:w               {F@1}             //  ALU pipe: int; $47
(W)     mov (1|M0)               r4.0<2>:b     r3.0<0;1,0>:w                    {I@1}                //  ALU pipe: int; $48
(W)     mov (1|M0)               r5.0<1>:d     r4.0<0;1,0>:ub                   {I@1}                //  ALU pipe: int; $49
(W)     add (1|M0)               r23.1<1>:d    r5.0<0;1,0>:d     r3.2<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $50
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r23.1<0;1,0>:ud   0x4:uw              {I@1}           //  ALU pipe: int; $53
(W)     asr (1|M0)               r23.2<1>:d    r23.1<0;1,0>:d    2:w                                 //  ALU pipe: int; $51
(W&~f1.0) jmpi                               _0_094                                                  //  ALU pipe: int; $54
// B010: Preds:{B009},  Succs:{B012}
_0_095:
(W)     mov (1|M0)               r26.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $56
(W)     jmpi                                 _0_096                                                  // $57
// B011: Preds:{B009},  Succs:{B012}
_0_094:
(W)     asr (1|M0)               r3.0<1>:d     r23.1<0;1,0>:d    31:w               {Compacted}      //  ALU pipe: int; $59
(W)     add (1|M0)               r2.0<1>:d     r3.0<0;1,0>:d     r23.2<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $60
(W)     xor (1|M0)               r3.1<1>:d     r2.0<0;1,0>:d     r3.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $61
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $62
(W)     mov (1|M0)               r4.0<1>:f     r3.1<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $63
(W)     mov (1|M0)               r5.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $68
(W)     math.inv (1|M0)          r4.2<1>:f     r4.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $67
(W)     mov (1|M0)               r4.1<1>:f     r22.1<0;1,0>:ud                                       //  ALU pipe: float; $66
(W)     mad (1|M0)               r6.0<1>:f     r4.2<0;0>:f       r5.0<0;0>:f       r4.2<0>:f        {Compacted,A@1} //  ALU pipe: float; $68
(W)     mov (1|M0)               r3.4<1>:ud    r4.0<0;1,0>:f                                         //  ALU pipe: int; $64
(W)     mov (1|M0)               r6.2<1>:ud    r4.1<0;1,0>:f                    {F@2}                //  ALU pipe: int; $70
(W)     mul (1|M0)               r6.1<1>:f     r4.1<0;1,0>:f     r6.0<0;1,0>:f    {F@1}              //  ALU pipe: float; $69
(W)     add (1|M0)               r4.4<1>:d     r3.1<0;1,0>:d     -r3.4<0;1,0>:d   {I@2}              //  ALU pipe: int; $65
(W)     add (1|M0)               r4.5<1>:d     r22.1<0;1,0>:d    -r6.2<0;1,0>:d   {I@2}              //  ALU pipe: int; $71 R{} IR{}{E:3,E:3,},  {BC=1}
(W)     mov (1|M0)               r2.0<1>:ud    r6.1<0;1,0>:f                    {F@1}                //  ALU pipe: int; $72
(W)     mov (1|M0)               r2.8<1>:f     r4.4<0;1,0>:ud                   {I@3}                //  ALU pipe: float; $73
(W)     mov (1|M0)               r2.9<1>:f     r4.5<0;1,0>:ud                   {I@2}                //  ALU pipe: float; $73
(W)     mov (1|M0)               r7.0<1>:f     r2.0<0;1,0>:ud                   {@1,$10.src}         //  ALU pipe: float; $75
(W)     mad (1|M0)               r2.1<1>:f     r4.1<0;0>:f       r7.0<0;0>:f       -r4.0<0>:f       {F@1} //  ALU pipe: float; $77
(W)     mad (1|M0)               r3.4<1>:f     r2.9<0;0>:f       r7.0<0;0>:f       -r2.8<0>:f        //  ALU pipe: float; $79
(W)     add (1|M0)               r8.0<1>:f     r2.1<0;1,0>:f     r3.4<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $80
(W)     mul (1|M0)               r9.0<1>:f     r6.0<0;1,0>:f     r8.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $81
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $82
(W)     mov (1|M0)               r5.0<1>:ud    r9.0<0;1,0>:f                    {A@1}                //  ALU pipe: int; $83
(W)     add (1|M0)               r10.0<1>:d    r5.0<0;1,0>:d     r2.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $84
(W)     mul (1|M0)               acc0.0<1>:d   r10.0<0;1,0>:d    r3.2<0;1,0>:uw   {I@1}              //  ALU pipe: int; $85
(W)     macl (1|M0)              r11.0<1>:d    r10.0<0;1,0>:d    r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $86
(W)     add (1|M0)               r10.1<1>:d    r22.1<0;1,0>:d    -r11.0<0;1,0>:d  {I@1}              //  ALU pipe: int; $86
(W)     cmp (1|M0)    (ge)f2.0   r12.0<1>:ud   r10.1<0;1,0>:ud   r3.1<0;1,0>:ud   {I@1}              //  ALU pipe: int; $87
(W)     add3 (1|M0)              r13.0<1>:d    r10.0<0;0>:d      r3.0<0;0>:d       -r12.0<0>:d      {I@1} //  ALU pipe: int; $88
(W)     xor (1|M0)               r26.0<1>:d    r13.0<0;1,0>:d    r3.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $89
// B012: Preds:{B011, B010},  Succs:{B013, B014}
_0_096:
(W)     add (1|M0)               r23.4<1>:d    r23.0<0;1,0>:d    r26.0<0;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $92
(W)     add3 (1|M0)              r2.0<1>:d     r23.0<0;0>:d      r26.0<0;0>:d      1:w               //  ALU pipe: int; $93
(W)     cmp (1|M0)    (lt)f1.0   r2.1<1>:d     r23.4<0;1,0>:d    -1:w               {I@2}            //  ALU pipe: int; $95
(W)     add3 (1|M0)              r3.0<1>:d     r23.0<0;0>:d      r26.0<0;0>:d      4:w               //  ALU pipe: int; $94
(W)     cmp (1|M0)    (lt)f3.0   r5.0<1>:d     r3.3<0;1,0>:d     0:w                                 //  ALU pipe: int; $98
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r23.4<0;1,0>:d    2:w                                 //  ALU pipe: int; $100
(W)     bfn.(s0&s1|~s0&s2) (1|M0)   r23.5<1>:ud  r2.1<0;0>:ud    r3.0<0;0>:ud      r2.0<0>:ud       {I@3} //  ALU pipe: int; $96
(W)     mul (1|M0)               acc0.0<1>:d   r26.0<0;1,0>:d    r23.4<0;1,0>:uw                     //  ALU pipe: int; $91
(W)     bfn.(s0&s1|~s0&s2) (1|M0)   r23.7<1>:ud  r5.0<0;0>:ud    r23.3<0;0>:ud     r3.3<0>:ud       {I@4} //  ALU pipe: int; $99 R{} IR{}{O:2,O:3,O:1,},  {BC=1}
(W)     macl (1|M0)              r27.0<1>:d    r26.0<0;1,0>:d    r23.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $92
(W)     asr (1|M0)               r23.6<1>:d    r23.5<0;1,0>:d    2:w               {I@4}             //  ALU pipe: int; $97
(W&f1.0) jmpi                                _0_097                                                  //  ALU pipe: int; $101
// B013: Preds:{B012},  Succs:{B021}
_0_098:
        mov (32|M0)              r28.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $103
(W)     jmpi                                 _0_099                                                  // $104
// B014: Preds:{B012},  Succs:{B015}
_0_097:
        mov (32|M0)              r30.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $107
(W)     mov (1|M0)               r23.8<1>:d    0:w                                                   //  ALU pipe: int; $106
// B015: Preds:{B020, B014},  Succs:{B016, B017}
_0_100:
        cmp (32|M0)   (ne)f3.0   null<1>:d     r30.0<1;1,0>:d    0:w               {I@2}             //  ALU pipe: int; $109
(f3.0)  goto (32|M0)                         _0_101            _0_101                                //  ALU pipe: int; $110
// B016: [inDivergent],  Preds:{B015},  Succs:{B018}
_0_102:
        mov (32|M0)              r32.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $112
        goto (32|M0)                         _0_101            _0_103                                // $113
// B017: [inDivergent],  Preds:{B015},  Succs:{B018}
_0_101:
        join (32|M0)                         _0_103                                                  // 
L1808:
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r23.8<0;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $115
(W)     mov (1|M0)               r7.0<1>:hf    0xFFFF:hf                              {$10.src}      //  ALU pipe: float; $124
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $117
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $118
(W)     load.ugm.d32x1t.a64 (1|M0)  r5:1        [r4:1]             {I@1,$12} // ex_desc:0x0; desc:0x2108580 // $119
(W)     and (1|M0)               r6.0<1>:d     r5.0<0;1,0>:d     2147483647:d               {$12.dst} //  ALU pipe: int; $120
(W)     cmp (32|M0)   (ne)f2.0   null<1>:f     r6.0<0;1,0>:f     0x7F800000:f               {I@1}    //  ALU pipe: float; $121
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:f     r6.0<0;1,0>:f     r6.0<0;1,0>:f                       //  ALU pipe: float; $122
(W&f2.0) sel (1|M0)              r8.0<1>:d     r7.0<0;1,0>:w     0:w               {F@3}             //  ALU pipe: int; $124
        mov (32|M0)              r32.0<1>:d    r8.0<0;1,0>:d                    {Compacted,I@1}      //  ALU pipe: int; $125
// B018: Preds:{B017, B016},  Succs:{B019, B020}
_0_103:
        join (32|M0)                         L1960                                                   // 
L1960:
(W)     add (1|M0)               r23.8<1>:d    r23.8<0;1,0>:d    1:w                                 //  ALU pipe: int; $128
        cmp (32|M0)   (ne)f3.0   null<1>:d     r32.0<1;1,0>:d    0:w               {I@3}             //  ALU pipe: int; $127
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r23.8<0;1,0>:d    r23.6<0;1,0>:d   {A@1}              //  ALU pipe: int; $129
(W&f2.0) jmpi                                _0_104                                                  //  ALU pipe: int; $130
// B019: Preds:{B018},  Succs:{B021}
_0_105:
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $132
(f3.0)  sel (32|M0)              r28.0<1>:d    r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $132
(W)     jmpi                                 _0_099                                                  // $133
// B020: Preds:{B018},  Succs:{B015}
_0_104:
        cmp (32|M0)   (ne)f3.0   r30.0<1>:d    r32.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $135
(W)     jmpi                                 _0_100                                                  // $136
// B021: Preds:{B019, B013},  Succs:{B022, B028}
_0_099:
        cmp (32|M0)   (ne)f3.0   null<1>:d     r28.0<1;1,0>:d    0:w               {I@4}             //  ALU pipe: int; $139
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r22.1<0;1,0>:d    r27.0<0;1,0>:d                      //  ALU pipe: int; $138
(f3.0)  goto (32|M0)                         _0_106            _0_106                                //  ALU pipe: int; $140
// B022: [inDivergent],  Preds:{B021},  Succs:{B023, B067}
_0_107:
(~f2.0) goto (32|M0)                         _0_106            _0_090                                //  ALU pipe: int; $142
// B023: [inDivergent],  Preds:{B022},  Succs:{B024, B026}
_0_108:
        mov (32|M0)              r34.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $144
        cmp (32|M0)   (gt)f0.0   null<1>:d     r23.3<0;1,0>:d    r34.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $145
(~f0.0) goto (32|M0)                         _0_109            _0_109                                //  ALU pipe: int; $146
// B024: [inDivergent],  Preds:{B023},  Succs:{B025}
_0_110:
(W)     mul (1|M0)               acc0.0<1>:d   r26.0<0;1,0>:d    r23.6<0;1,0>:uw                     //  ALU pipe: int; $148
(W)     macl (1|M0)              r36.0<1>:d    r26.0<0;1,0>:d    r23.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; 
// B025: [inDivergent],  Preds:{B025, B024},  Succs:{B026, B025}
_0_111:
        add (32|M0)              r6.0<1>:d     r36.0<0;1,0>:d    r34.0<1;1,0>:d   {Compacted,@1,$10.src} //  ALU pipe: int; $150
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $152
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $152
        add (32|M0)              r34.0<1>:d    r34.0<1;1,0>:d    32:w               {Compacted}      //  ALU pipe: int; $157
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     2:w               {I@3}             //  ALU pipe: int; $152
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    2:w               {I@3}             //  ALU pipe: int; $152
        cmp (32|M0)   (lt)f0.0   null<1>:d     r34.0<1;1,0>:d    r23.3<0;1,0>:d   {I@3}              //  ALU pipe: int; $158
        mov (32|M0)              r20.0<1>:d    -1:w                               {Compacted,$13.src} //  ALU pipe: int; $155
        add (16|M0)              r16.0<1>:q    r10.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $153
        add (16|M16)             r18.0<1>:q    r14.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $153
        store.ugm.d32.a64 (32|M0)  [r16:4]      r20:2              {I@1,$13} // ex_desc:0x0; desc:0x8000584 // $156
(f0.0)  goto.b (32|M0)                       _0_109            _0_111                                //  ALU pipe: int; $159
// B026: [inDivergent],  Preds:{B025, B023},  Succs:{B027, B067}
_0_109:
        join (32|M0)                         _0_106                                                  // 
L2392:
        cmp (32|M0)   (eq)f3.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $161
(~f3.0) goto (32|M0)                         _0_106            _0_090                                //  ALU pipe: int; $162
// B027: [inDivergent],  Preds:{B026},  Succs:{B067}
_0_112:
(W)     mov (1|M0)               r2.0<1>:uq    r5.1<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $164
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $167
        sync.nop                             null                             {Compacted,I@2}        // $165
        mov (16|M0)              r6.0<2>:f     r2.0<0;1,0>:f                    {$10.src}            //  ALU pipe: float; $165
        mov (16|M16)             r8.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $165
        mov (16|M0)              r6.1<2>:f     r2.1<0;1,0>:f                                         //  ALU pipe: float; $166
        mov (16|M16)             r8.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $166
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$14} // ex_desc:0x0; desc:0x800058B // $168
        goto (32|M0)                         _0_106            _0_090                                // $169
// B028: [inDivergent],  Preds:{B021},  Succs:{B029, B036}
_0_106:
        join (32|M0)                         _0_090                                                  // 
L2560:
(W)     asr (1|M0)               r2.0<1>:d     r23.7<0;1,0>:d    2:w                                 //  ALU pipe: int; $171
(W)     sel (1|M0)    (lt)f0.0   r23.9<1>:d    r2.0<0;1,0>:d     r23.6<0;1,0>:d   {I@1}              //  ALU pipe: int; $172
(W&~f2.0) jmpi                               _0_113                                                  //  ALU pipe: int; $173
// B029: [inDivergent],  Preds:{B028},  Succs:{B030, B033}
_0_114:
(W)     shl (1|M0)               r23.10<1>:d   r23.9<0;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $175
(W)     not (1|M0)               r2.0<1>:d     r23.4<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $177
(W)     and (1|M0)               r26.1<1>:d    r23.5<0;1,0>:d    -4:w                                //  ALU pipe: int; $178
(W)     add3 (1|M0)              r3.0<1>:d     r3.3<0;0>:d       -r23.10<0;0>:d    3:w               {I@3} //  ALU pipe: int; $176
        mov (32|M0)              r38.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $183
(W)     add3 (1|M0)              r23.11<1>:d   r26.1<0;0>:d      r2.0<0;0>:d       r3.0<0>:d        {I@2} //  ALU pipe: int; $179
(W)     mul (1|M0)               acc0.0<1>:d   r26.0<0;1,0>:d    r23.6<0;1,0>:uw                     //  ALU pipe: int; $180
        cmp (32|M0)   (gt)f0.0   null<1>:d     r23.11<0;1,0>:d   r38.0<1;1,0>:d   {I@2}              //  ALU pipe: int; $184
(W)     macl (1|M0)              r37.0<1>:d    r26.0<0;1,0>:d    r23.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $181
(W)     add3 (1|M0)              r23.13<1>:d   r23.4<0;0>:d      -r26.1<0;0>:d     1:w               //  ALU pipe: int; $182
(W)     add (1|M0)               r23.12<1>:d   r37.0<0;1,0>:d    r23.10<0;1,0>:d  {I@2}              //  ALU pipe: int; $181
(~f0.0) goto (32|M0)                         _0_115            _0_115                                //  ALU pipe: int; $185
// B030: [inDivergent],  Preds:{B029},  Succs:{B031}
_0_116:
        mov (32|M0)              r40.0<1>:f    r38.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $187
// B031: [inDivergent],  Preds:{B032, B030},  Succs:{B032, B033}
_0_117:
        sync.nop                             null                             {Compacted,A@1}        // $189
        sync.nop                             null                             {Compacted,$14.src}    // $189
        add3 (32|M0)             r6.0<1>:d     r23.12<0;0>:d     r23.13<0;0>:d     r40.0<1>:d       {$10.src} //  ALU pipe: int; $189
        add (32|M0)              r42.0<1>:d    r40.0<1;1,0>:d    32:w               {Compacted}      //  ALU pipe: int; $196
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $191
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $191
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     2:w               {I@2}             //  ALU pipe: int; $191
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $191
        cmp (32|M0)   (lt)f2.0   null<1>:d     r42.0<1;1,0>:d    r23.11<0;1,0>:d                     //  ALU pipe: int; $197
        sync.nop                             null                             {Compacted,$15.src}    // $194
        mov (32|M0)              r20.0<1>:d    -1:w                               {Compacted,$13.src} //  ALU pipe: int; $194
        add (16|M0)              r16.0<1>:q    r10.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $192
        add (16|M16)             r18.0<1>:q    r14.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $192
        store.ugm.d32.a64 (32|M0)  [r16:4]      r20:2              {I@1,$15} // ex_desc:0x0; desc:0x8000584 // $195
(~f2.0) goto (32|M0)                         _0_115            _0_115                                //  ALU pipe: int; $198
// B032: [inDivergent],  Preds:{B031},  Succs:{B031}
_0_118:
        mov (32|M0)              r40.0<1>:f    r42.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $200
(W)     jmpi                                 _0_117                                                  // $201
// B033: [inDivergent],  Preds:{B031, B029},  Succs:{B034, B036}
_0_115:
        join (32|M0)                         _0_090                                                  // 
L3000:
        cmp (32|M0)   (gt)f3.0   null<1>:d     r23.13<0;1,0>:d   r38.0<1;1,0>:d                      //  ALU pipe: int; $203
(~f3.0) goto (32|M0)                         _0_113            _0_113                                //  ALU pipe: int; $204
// B034: Preds:{B033},  Succs:{B035}
_L_k0_0_preHeader:
_0_119:
// B035: [inDivergent],  Preds:{B034, B035},  Succs:{B036, B035}
        add3 (32|M0)             r8.0<1>:d     r37.0<0;0>:d      r23.10<0;0>:d     r38.0<1>:d       {$14.src} //  ALU pipe: int; $207
        sync.nop                             null                             {Compacted,$0.src}     // $206
        add (32|M0)              r6.0<1>:d     r26.1<0;1,0>:d    r38.0<1;1,0>:d   {Compacted,$10.src} //  ALU pipe: int; $206
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $209
        mov (16|M16)             r14.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $209
        add (32|M0)              r38.0<1>:d    r38.0<1;1,0>:d    32:w               {Compacted}      //  ALU pipe: int; $213
        shl (16|M0)              r12.0<1>:q    r10.0<2;1,0>:d    2:w               {I@3}             //  ALU pipe: int; $209
        sync.nop                             null                             {Compacted,$15.src}    // $209
        shl (16|M16)             r16.0<1>:q    r14.0<2;1,0>:d    2:w               {@3,$13.src}      //  ALU pipe: int; $209
        cmp (32|M0)   (lt)f0.0   null<1>:d     r38.0<1;1,0>:d    r23.13<0;1,0>:d  {I@3}              //  ALU pipe: int; $214
        add (16|M0)              r18.0<1>:q    r12.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $210
        add (16|M16)             r20.0<1>:q    r16.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $210
        store.ugm.d32.a64 (32|M0)  [r18:4]      r6:2               {I@1,$0} // ex_desc:0x0; desc:0x8000584 // $212
(f0.0)  goto.b (32|M0)                       _0_113            _L_k0_0_preHeader                     //  ALU pipe: int; $215
// B036: [inDivergent],  Preds:{B035, B033, B028},  Succs:{B037, B067}
_0_113:
        join (32|M0)                         _0_090                                                  // 
L3208:
        cmp (32|M0)   (eq)f2.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $218
(W)     add (1|M0)               r23.14<1>:d   r22.1<0;1,0>:d    -r27.0<0;1,0>:d                     //  ALU pipe: int; $217
(f2.0)  cmp (32|M0)   (lt)f2.0   null<1>:d     r23.14<0;1,0>:d   r23.6<0;1,0>:d   {I@1}              //  ALU pipe: int; $219
(~f2.0) goto (32|M0)                         _0_090            _0_090                                //  ALU pipe: int; $221
// B037: [inDivergent],  Preds:{B036},  Succs:{B038, B039}
_0_120:
(W&f1.0) jmpi                                _0_121                                                  //  ALU pipe: int; $223
// B038: [inDivergent],  Preds:{B037},  Succs:{B063}
_0_122:
(W)     mov (1|M0)               r27.8<1>:d    0:w                                                   //  ALU pipe: int; $225
(W)     jmpi                                 _0_123                                                  // $226
// B039: [inDivergent],  Preds:{B037},  Succs:{B040, B041}
_0_121:
(W)     shl (1|M0)               r2.0<1>:q     r22.1<0;1,0>:ud   2:w                                 //  ALU pipe: int; $229
(W)     sel (1|M0)    (ge)f0.0   r23.15<1>:d   r23.6<0;1,0>:d    1:w                                 //  ALU pipe: int; $232
(W)     add (1|M0)               r4.0<1>:q     r2.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $230
(W)     add (1|M0)               r3.0<1>:d     r23.15<0;1,0>:d   -1:w               {I@2}            //  ALU pipe: int; $233
(W)     load.ugm.d32x1t.a64 (1|M0)  r44:1       [r4:1]             {I@2,$1} // ex_desc:0x0; desc:0x2108580 // $231
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r3.0<0;1,0>:ud    0x3:uw              {I@1}           //  ALU pipe: int; $235
(W)     and (1|M0)               r26.2<1>:d    r23.15<0;1,0>:d   3:w                                 //  ALU pipe: int; $234
(W&~f2.0) jmpi                               _0_124                                                  //  ALU pipe: int; $236
// B040: [inDivergent],  Preds:{B039},  Succs:{B056}
_0_125:
(W)     mov (2|M0)               r27.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $238
(W)     jmpi                                 _0_126                                                  // $240
// B041: [inDivergent],  Preds:{B039},  Succs:{B042}
_0_124:
(W)     and (1|M0)               r26.3<1>:d    r23.15<0;1,0>:d   2147483644:d                        //  ALU pipe: int; $242
(W)     mov (2|M0)               r27.8<1>:d    0:w                                                   //  ALU pipe: int; $243
(W)     mov (1|M0)               r26.4<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $245
// B042: [inDivergent],  Preds:{B054, B041},  Succs:{B043, B044}
_0_127:
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r27.9<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $247
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $249
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,@1,$1.src} //  ALU pipe: int; $250
(W)     load.ugm.d32x1t.a64 (1|M0)  r45:1       [r4:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $251
        sync.nop                             null                             {Compacted,$3.dst}     // $252
(W)     cmp (32|M0)   (gt)f3.0   null<1>:f     r45.0<0;1,0>:f    r44.0<0;1,0>:f   {$1.dst}           //  ALU pipe: float; $252
(W&~f3.0) jmpi                               _0_128                                                  //  ALU pipe: int; $253
// B043: [inDivergent],  Preds:{B042},  Succs:{B045}
_0_129:
(W)     mov (1|M0)               r26.5<1>:d    -1:w                                                  //  ALU pipe: int; $255
(W)     jmpi                                 _0_130                                                  // $256
// B044: [inDivergent],  Preds:{B042},  Succs:{B045}
_0_128:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r27.9<0;1,0>:d    r23.14<0;1,0>:d  {F@1}              //  ALU pipe: int; $258
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:f     r45.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $259
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $261
(W&f3.0) sel (1|M0)              r26.5<1>:d    r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $261
// B045: [inDivergent],  Preds:{B044, B043},  Succs:{B046, B047}
_0_130:
(W)     or (1|M0)                r26.6<1>:d    r27.9<0;1,0>:d    1:w                                 //  ALU pipe: int; $264
(W)     cmp (1|M0)    (ne)f3.0   r27.1<1>:d    r26.5<0;1,0>:d    0:w               {I@2}             //  ALU pipe: int; $263
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r26.6<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $265
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $267
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $268
(W)     load.ugm.d32x1t.a64 (1|M0)  r46:1       [r4:1]             {I@1,$4} // ex_desc:0x0; desc:0x2108580 // $269
(W)     cmp (32|M0)   (gt)f2.0   null<1>:f     r46.0<0;1,0>:f    r44.0<0;1,0>:f   {$4.dst}           //  ALU pipe: float; $270
(W&~f2.0) jmpi                               _0_131                                                  //  ALU pipe: int; $271
// B046: [inDivergent],  Preds:{B045},  Succs:{B048}
_0_132:
(W)     mov (1|M0)               r26.7<1>:d    -1:w                                                  //  ALU pipe: int; $273
(W)     jmpi                                 _0_133                                                  // $274
// B047: [inDivergent],  Preds:{B045},  Succs:{B048}
_0_131:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r26.6<0;1,0>:d    r23.14<0;1,0>:d  {F@1}              //  ALU pipe: int; $276
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:f     r46.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $277
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $279
(W&f2.0) sel (1|M0)              r26.7<1>:d    r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $279
// B048: [inDivergent],  Preds:{B047, B046},  Succs:{B049, B050}
_0_133:
(W)     or (1|M0)                r26.9<1>:d    r27.9<0;1,0>:d    2:w                                 //  ALU pipe: int; $283
(W)     cmp (1|M0)    (ne)f2.0   r2.0<1>:d     r26.7<0;1,0>:d    0:w               {I@2}             //  ALU pipe: int; $281
(W)     add (1|M0)               r3.0<1>:d     r27.0<0;1,0>:d    r26.9<0;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $284
(W)     shl (1|M0)               r4.0<1>:q     r3.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $286
(W)     add3 (1|M0)              r26.8<1>:d    r27.8<0;0>:d      -r27.1<0;0>:d     -r2.0<0>:d        //  ALU pipe: int; $282
        sync.nop                             null                             {Compacted,$0.src}     // $287
(W)     add (1|M0)               r6.0<1>:q     r4.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,@2,$14.src} //  ALU pipe: int; $287
(W)     load.ugm.d32x1t.a64 (1|M0)  r47:1       [r6:1]             {I@1,$5} // ex_desc:0x0; desc:0x2108580 // $288
(W)     cmp (32|M0)   (gt)f1.0   null<1>:f     r47.0<0;1,0>:f    r44.0<0;1,0>:f   {$5.dst}           //  ALU pipe: float; $289
(W&~f1.0) jmpi                               _0_134                                                  //  ALU pipe: int; $290
// B049: [inDivergent],  Preds:{B048},  Succs:{B051}
_0_135:
(W)     mov (1|M0)               r26.10<1>:d   -1:w                                                  //  ALU pipe: int; $292
(W)     jmpi                                 _0_136                                                  // $293
// B050: [inDivergent],  Preds:{B048},  Succs:{B051}
_0_134:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r26.9<0;1,0>:d    r23.14<0;1,0>:d  {F@1}              //  ALU pipe: int; $295
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:f     r47.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $296
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $298
(W&f1.0) sel (1|M0)              r26.10<1>:d   r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $298
// B051: [inDivergent],  Preds:{B050, B049},  Succs:{B052, B053}
_0_136:
(W)     or (1|M0)                r26.11<1>:d   r27.9<0;1,0>:d    3:w                                 //  ALU pipe: int; $301
(W)     cmp (1|M0)    (ne)f1.0   r27.2<1>:d    r26.10<0;1,0>:d   0:w               {I@2}             //  ALU pipe: int; $300
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r26.11<0;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $302
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $304
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $305
(W)     load.ugm.d32x1t.a64 (1|M0)  r48:1       [r4:1]             {I@1,$6} // ex_desc:0x0; desc:0x2108580 // $306
(W)     cmp (32|M0)   (gt)f3.0   null<1>:f     r48.0<0;1,0>:f    r44.0<0;1,0>:f   {$6.dst}           //  ALU pipe: float; $307
(W&~f3.0) jmpi                               _0_137                                                  //  ALU pipe: int; $308
// B052: [inDivergent],  Preds:{B051},  Succs:{B054}
_0_138:
(W)     mov (1|M0)               r26.12<1>:d   -1:w                                                  //  ALU pipe: int; $310
(W)     jmpi                                 _0_139                                                  // $311
// B053: [inDivergent],  Preds:{B051},  Succs:{B054}
_0_137:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r26.11<0;1,0>:d   r23.14<0;1,0>:d  {F@1}              //  ALU pipe: int; $313
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:f     r48.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $314
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $316
(W&f3.0) sel (1|M0)              r26.12<1>:d   r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $316
// B054: [inDivergent],  Preds:{B053, B052},  Succs:{B055, B042}
_0_139:
(W)     add (1|M0)               r26.4<1>:d    r26.4<0;1,0>:d    4:w                                 //  ALU pipe: int; $321
(W)     cmp (1|M0)    (ne)f3.0   r2.0<1>:d     r26.12<0;1,0>:d   0:w               {I@2}             //  ALU pipe: int; $318
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r26.4<0;1,0>:d    r26.3<0;1,0>:d   {I@2}              //  ALU pipe: int; $322
(W)     add (1|M0)               r27.9<1>:d    r27.9<0;1,0>:d    4:w                                 //  ALU pipe: int; $320
(W)     add3 (1|M0)              r27.8<1>:d    r26.8<0;0>:d      -r27.2<0;0>:d     -r2.0<0>:d       {I@3} //  ALU pipe: int; $319
(W)     mov (1|M0)               r27.5<1>:d    r27.9<0;1,0>:d                   {I@2}                //  ALU pipe: int; $323
(W&~f2.0) jmpi                               _0_127                                                  //  ALU pipe: int; $324
// B055: [inDivergent],  Preds:{B054},  Succs:{B056}
_0_140:
(W)     mov (1|M0)               r27.4<1>:d    r27.8<0;1,0>:d                   {I@3}                //  ALU pipe: int; $326
// B056: [inDivergent],  Preds:{B055, B040},  Succs:{B057, B063}
_0_126:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r26.2<0;1,0>:d    0:w                                 //  ALU pipe: int; $328
(W&f1.0) jmpi                                _0_123                                                  //  ALU pipe: int; $329
// B057: [inDivergent],  Preds:{B056},  Succs:{B058}
_0_141:
(W)     mov (1|M0)               r27.3<1>:d    r27.4<0;1,0>:d                   {I@3}                //  ALU pipe: int; $331
(W)     mov (1|M0)               r26.13<1>:d   0:w                                                   //  ALU pipe: int; $332
// B058: [inDivergent],  Preds:{B062, B057},  Succs:{B059, B060}
_0_142:
(W)     add (1|M0)               r2.0<1>:d     r27.0<0;1,0>:d    r27.5<0;1,0>:d   {Compacted}        //  ALU pipe: int; $334
(W)     shl (1|M0)               r3.0<1>:q     r2.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $336
(W)     add (1|M0)               r4.0<1>:q     r3.0<0;1,0>:q     r2.1<0;1,0>:q    {Compacted,@1,$1.src} //  ALU pipe: int; $337
(W)     load.ugm.d32x1t.a64 (1|M0)  r49:1       [r4:1]             {I@1,$7} // ex_desc:0x0; desc:0x2108580 // $338
        sync.nop                             null                             {Compacted,$7.dst}     // $339
(W)     cmp (32|M0)   (gt)f1.0   null<1>:f     r49.0<0;1,0>:f    r44.0<0;1,0>:f   {$1.dst}           //  ALU pipe: float; $339
(W&~f1.0) jmpi                               _0_143                                                  //  ALU pipe: int; $340
// B059: [inDivergent],  Preds:{B058},  Succs:{B061}
_0_144:
(W)     mov (1|M0)               r26.14<1>:d   -1:w                                                  //  ALU pipe: int; $342
(W)     jmpi                                 _0_145                                                  // $343
// B060: [inDivergent],  Preds:{B058},  Succs:{B061}
_0_143:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r27.5<0;1,0>:d    r23.14<0;1,0>:d                     //  ALU pipe: int; $345
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:f     r49.0<0;1,0>:f    r44.0<0;1,0>:f   {I@1}              //  ALU pipe: float; $346
(W)     mov (1|M0)               r2.0<1>:hf    0xFFFF:hf                                             //  ALU pipe: float; $348
(W&f2.0) sel (1|M0)              r26.14<1>:d   r2.0<0;1,0>:w     0:w               {F@1}             //  ALU pipe: int; $348
// B061: [inDivergent],  Preds:{B060, B059},  Succs:{B062, B063}
_0_145:
(W)     add (1|M0)               r26.13<1>:d   r26.13<0;1,0>:d   1:w                                 //  ALU pipe: int; $352
(W)     cmp (1|M0)    (ne)f2.0   r2.0<1>:d     r26.14<0;1,0>:d   0:w               {I@2}             //  ALU pipe: int; $350
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r26.13<0;1,0>:d   r26.2<0;1,0>:d   {I@2}              //  ALU pipe: int; $353
(W)     add3 (1|M0)              r27.8<1>:d    r27.3<0;0>:d      -r2.0<0;0>:d      0:w               {I@2} //  ALU pipe: int; $351
(W&f3.0) jmpi                                _0_123                                                  //  ALU pipe: int; $354
// B062: [inDivergent],  Preds:{B061},  Succs:{B058}
_0_146:
(W)     add (1|M0)               r27.5<1>:d    r27.5<0;1,0>:d    1:w                                 //  ALU pipe: int; $356
(W)     mov (1|M0)               r27.3<1>:d    r27.8<0;1,0>:d                   {I@3}                //  ALU pipe: int; $357
(W)     jmpi                                 _0_142                                                  // $358
// B063: [inDivergent],  Preds:{B061, B056, B038},  Succs:{B064, B067}
_0_123:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r27.8<0;1,0>:d    r23.9<0;1,0>:d                      //  ALU pipe: int; $360
(~f3.0) goto (32|M0)                         _0_090            _0_090                                //  ALU pipe: int; $361
// B064: [inDivergent],  Preds:{B063},  Succs:{B067}
_0_147:
(W)     mul (1|M0)               acc0.0<1>:d   r26.0<0;1,0>:d    r23.6<0;1,0>:uw                     //  ALU pipe: int; $365
(W)     shl (1|M0)               r2.0<1>:d     r27.8<0;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $363
(W)     macl (1|M0)              r3.0<1>:d     r26.0<0;1,0>:d    r23.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $366
(W)     shl (1|M0)               r2.6<1>:d     r23.14<0;1,0>:d   2:w                                 //  ALU pipe: int; $364
(W)     add (1|M0)               r4.0<1>:d     r3.0<0;1,0>:d     r2.0<0;1,0>:d    {Compacted,@2,$1.src} //  ALU pipe: int; $366
(W)     add (1|M0)               r2.7<1>:d     r2.6<0;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $371
(W)     add (1|M0)               r2.8<1>:d     r2.6<0;1,0>:d     2:w                                 //  ALU pipe: int; $372
(W)     add (1|M0)               r2.9<1>:d     r2.6<0;1,0>:d     3:w                                 //  ALU pipe: int; $373
(W)     shl (1|M0)               r5.0<1>:q     r4.0<0;1,0>:d     2:w               {I@4}             //  ALU pipe: int; $368
        sync.allrd                           ($0,$14)                                                // $374
(W)     mov (4|M0)               r7.0<1>:d     r2.6<1;1,0>:d                    {Compacted,@2,$10.src} //  ALU pipe: int; $374
(W)     add (1|M0)               r6.0<1>:q     r5.0<0;1,0>:q     r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $369
(W)     store.ugm.d32x4t.a64 (1|M0)  [r6:1]     r7:1               {I@1,$8} // ex_desc:0x0; desc:0x200B584 // $375
        goto (32|M0)                         _0_090            _0_090                                // $376
// B065: [inDivergent],  Preds:{B008},  Succs:{B066, B067}
_0_092:
        cmp (32|M0)   (eq)f1.0   null<1>:d     r22.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $378
(W)     mov (1|M0)               r2.0<1>:hf    0x1:hf                                                //  ALU pipe: float; $379
(f1.0)  sel (32|M0)              r4.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw              {F@1}           //  ALU pipe: int; $379
(f0.0)  sel (32|M0)              r6.0<1>:uw    r2.0<0;1,0>:uw    0x0:uw              {$8.src}        //  ALU pipe: int; $379
        and (32|M0)   (ne)f1.0   null<2>:uw    r4.0<1;1,0>:uw    r6.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $379
(~f1.0) goto (32|M0)                         _0_090            _0_090                                //  ALU pipe: int; $380
// B066: [inDivergent],  Preds:{B065},  Succs:{B067}
_0_148:
(W)     mov (1|M0)               r2.0<1>:uq    r5.1<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $382
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $385
        sync.nop                             null                             {Compacted,I@2}        // $383
        mov (16|M0)              r6.0<2>:f     r2.0<0;1,0>:f                    {$10.src}            //  ALU pipe: float; $383
        mov (16|M16)             r8.0<2>:f     r2.0<0;1,0>:f                                         //  ALU pipe: float; $383
        mov (16|M0)              r6.1<2>:f     r2.1<0;1,0>:f                                         //  ALU pipe: float; $384
        mov (16|M16)             r8.1<2>:ud    r2.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $384
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$9} // ex_desc:0x0; desc:0x800058B // $386
// B067: Preds:{B066, B065, B064, B063, B036, B027, B026, B022, B007},  Succs:{}
_0_090:
        join (32|M0)                         L5272                                                   // 
L5272:
(W)     mov (16|M0)              r127.0<1>:f   r22.0<1;1,0>:f                   {Compacted,$2.src}   //  ALU pipe: float; $388
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$11} // wr:1+0, rd:0; end of thread // $388
L5296:
(W)     mov (16|M0)              null<1>:ud    0x240B22FC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x608F9E07:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x2:ud                                                // 


//.BankConflicts: 2
//.ByteRMWs: 1
//


//.numALUInst: 295
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 79
//.allAtOneDistNum: 13
//.syncInstCount: 11
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 19
//.AfterReadTokenDepCount: 28
