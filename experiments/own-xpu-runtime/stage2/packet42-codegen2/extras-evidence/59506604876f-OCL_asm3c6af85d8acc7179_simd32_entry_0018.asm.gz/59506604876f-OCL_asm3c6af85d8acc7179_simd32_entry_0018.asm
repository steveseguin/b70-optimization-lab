//.kernel _ZTSN9p42extras8FlatNameILNS_4KindE0ELi0EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 18 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 18 -GRFBumpUpNumber 2 "
//.instCount 279
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r92.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.4)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r92.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r92.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=uq align=4 words (r4.7)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.8)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r4.4)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r4.12)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.13)
//.declare V0061 (71)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r4.5)
//.declare V0062 (72)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0063 (73)  rf=r size=4 type=d align=32 words (r7.0)
//.declare P01 (74)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0064 (75)  rf=r size=8 type=uq alias=V0055+0 align=4 words (r4.3)
//.declare V0065 (76)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0067 (78)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0068 (79)  rf=r size=256 type=ud alias=V0067+0 align=32 words (r7.0)
//.declare V0069 (80)  rf=r size=8 type=ud alias=V0065+0 align=32 words (r6.0)
//.declare V0070 (81)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0071 (82)  rf=r size=128 type=ud align=32 words (r13.0)
//.declare P02 (84)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0073 (85)  rf=r size=8 type=d align=2 words (r93.0)
//.declare V0074 (86)  rf=r size=8 type=d alias=V0044+0 align=4 words (r3.0)
//.declare V0075 (87)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0077 (89)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0078 (90)  rf=r size=128 type=d align=32 words (r94.0)
//.declare V0080 (92)  rf=r size=128 type=ud alias=V0078+0 align=32 words (r94.0)
//.declare P03 (93)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0081 (94)  rf=r size=8 type=ud alias=V0073+0 align=2 words (r93.0)
//.declare V0084 (97)  rf=r size=8 type=df align=4 words (r1.0)
//.declare V0085 (98)  rf=r size=8 type=uq alias=V0044+0 align=4 words (r3.0)
//.declare V0086 (99)  rf=r size=4 type=f align=4 words (r2.0)
//.declare V0087 (100)  rf=r size=4 type=f align=2 words (r3.3)
//.declare V0088 (101)  rf=r size=8 type=df align=4 words (r4.1)
//.declare V0089 (102)  rf=r size=8 type=df align=4 words (r6.0)
//.declare V0090 (103)  rf=r size=8 type=df align=4 words (r5.0)
//.declare V0091 (104)  rf=r size=8 type=df align=4 words (r9.0)
//.declare V0093 (106)  rf=r size=8 type=df align=4 words (r10.0)
//.declare V0094 (107)  rf=r size=8 type=df align=4 words (r12.0)
//.declare V0096 (109)  rf=r size=4 type=d align=4 words (r13.0)
//.declare V0097 (110)  rf=r size=4 type=ud alias=V0096+0 align=2 words (r13.0)
//.declare V0098 (111)  rf=r size=4 type=d align=32 words (r15.0)
//.declare V0099 (112)  rf=r size=4 type=d align=2 words (r16.0)
//.declare V0100 (113)  rf=r size=8 type=df align=4 words (r18.0)
//.declare V0101 (114)  rf=r size=4 type=ud alias=V0099+0 align=2 words (r16.0)
//.declare V0104 (117)  rf=r size=8 type=df align=4 words (r27.0)
//.declare V0110 (123)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0111 (124)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0112 (125)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0113 (126)  rf=r size=128 type=d align=32 words (r46.0)
//.declare P04 (127)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0114 (128)  rf=r size=128 type=ud alias=V0111+0 align=32 words (r42.0)
//.declare V0115 (129)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0116 (130)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0117 (131)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0121 (135)  rf=r size=128 type=ud alias=V0110+0 align=32 words (r40.0)
//.declare V0124 (138)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0125 (139)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0129 (143)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0130 (144)  rf=r size=128 type=d align=32 words (r82.0)
//.declare P05 (145)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0131 (146)  rf=r size=128 type=ud alias=V0129+0 align=32 words (r80.0)
//.declare P06 (147)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P07 (148)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0132 (149)  rf=r size=128 type=ud alias=V0130+0 align=32 words (r82.0)
//.declare V0139 (156)  rf=r size=4 type=d align=4 words (r93.2)
//.declare P08 (157)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0140 (158)  rf=r size=4 type=f align=2 words (r2.0)
//.declare V0141 (159)  rf=r size=4 type=ud alias=V0139+0 align=2 words (r93.2)
//.declare V0142 (160)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0143 (161)  rf=r size=4 type=ud alias=V0142+0 align=2 words (r3.0)
//.declare V0144 (162)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0145 (163)  rf=r size=128 type=f align=32 words (r5.0)
//.declare V0146 (164)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0147 (165)  rf=r size=4 type=f align=2 words (r10.0)
//.declare V0148 (166)  rf=r size=128 type=f align=32 words (r11.0)
//.declare V0149 (167)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0150 (168)  rf=r size=128 type=ud alias=V0149+0 align=32 words (r13.0)
//.declare V0151 (169)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0152 (170)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0153 (171)  rf=r size=128 type=ud alias=V0152+0 align=32 words (r17.0)
//.declare V0154 (172)  rf=r size=4 type=f align=2 words (r20.0)
//.declare V0155 (173)  rf=r size=4 type=ud alias=V0144+0 align=2 words (r4.2)
//.declare V0156 (174)  rf=r size=128 type=f align=32 words (r21.0)
//.declare V0157 (175)  rf=r size=128 type=ud alias=V0151+0 align=32 words (r15.0)
//.declare V0158 (176)  rf=r size=128 type=f align=32 words (r25.0)
//.declare V0164 (182)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0165 (183)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0166 (184)  rf=r size=128 type=ud alias=V0165+0 align=32 words (r29.0)
//.declare V0167 (185)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0168 (186)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0169 (187)  rf=r size=128 type=d align=32 words (r35.0)
//.declare P09 (188)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0170 (189)  rf=r size=128 type=ud alias=V0169+0 align=32 words (r35.0)
//.declare V0171 (190)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0172 (191)  rf=r size=128 type=d align=32 words (r96.0)
//.declare V0173 (192)  rf=r size=128 type=ud alias=V0172+0 align=32 words (r96.0)
//.declare P10 (193)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P11 (194)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P12 (195)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0174 (196)  rf=r size=4 type=ud alias=V0045+0 align=2 words (r3.2)
//.declare P13 (197)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0178 (201)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0179 (202)  rf=r size=256 type=q align=32 words (r13.0)
//.declare V0180 (203)  rf=r size=128 type=f align=32 words (r99.0)
//.declare V0184 (207)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0185 (208)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0186 (209)  rf=r size=128 type=ud alias=V0185+0 align=32 words (r13.0)
//.declare V0190 (213)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0191 (214)  rf=r size=128 type=d align=32 words (r13.0)
//.declare P14 (215)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0195 (219)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare P15 (220)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0199 (224)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0201 (226)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0202 (227)  rf=r size=128 type=w alias=V0201+0 align=32 words (r14.0)
//.declare V0204 (229)  rf=r size=128 type=d alias=V0180+0 align=32 words (r99.0)
//.declare P16 (230)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P17 (231)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P18 (232)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0205 (233)  rf=r size=4 type=ud alias=V0054+0 align=2 words (r4.4)
//.declare P19 (234)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0209 (238)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0211 (240)  rf=r size=256 type=d align=32 words (r19.0)
//.declare V0213 (242)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0214 (243)  rf=r size=128 type=ud alias=V0213+0 align=32 words (r1.0)
//.declare V0218 (247)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0219 (248)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0223 (252)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare P20 (253)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0227 (257)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare P21 (258)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0228 (259)  rf=r size=128 type=d align=32 words (r1.0)
//.declare P22 (260)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0229 (261)  rf=r size=128 type=ud alias=V0228+0 align=32 words (r1.0)
//.declare V0230 (262)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0231 (263)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r99.0)
//.declare V0232 (264)  rf=r size=128 type=ud alias=V0230+0 align=32 words (r1.0)
//.declare V0233 (265)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0234 (266)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0235 (267)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0236 (268)  rf=r size=128 type=ud alias=V0234+0 align=32 words (r8.0)
//.declare V0237 (269)  rf=r size=128 type=ud alias=V0235+0 align=32 words (r10.0)
//.declare V0238 (270)  rf=r size=64 type=w align=32 words (r98.0)
//.declare V0239 (271)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0240 (272)  rf=r size=128 type=ud alias=V0239+0 align=32 words (r1.0)
//.declare V0245 (277)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0246 (278)  rf=r size=64 type=uw alias=V0238+0 align=32 words (r98.0)
//.declare V0247 (279)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (280)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (281)  rf=r size=4 type=d alias=V0044+0 align=2 words (r3.0)
//.declare  (282)  rf=r size=4 type=d alias=V0044+0 align=2 words (r3.0)
//.declare  (283)  rf=r size=128 type=w alias=V0239+0 align=32 words (r1.0)
//.declare  (284)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (285)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (288)  rf=r size=8 type=df align=4 words (r7.0)
//.declare  (289)  rf=r size=8 type=df align=4 words (r11.0)
//.declare  (290)  rf=r size=64 type=ud align=32 words (r66.0)
//.declare  (291)  rf=r size=64 type=ud align=32 words (r69.0)
//.declare  (292)  rf=r size=128 type=ud align=32 words (r19.0)
//.declare  (293)  rf=r size=128 type=ud align=32 words (r23.0)
//.declare  (294)  rf=r size=128 type=ud align=32 words (r54.0)
//.declare  (295)  rf=r size=128 type=ud align=32 words (r58.0)
//.declare  (296)  rf=r size=4 type=f align=2 words (r9.0)
//.declare  (297)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (298)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (299)  rf=r size=128 type=f align=32 words (r17.0)
//.declare  (300)  rf=r size=128 type=f align=32 words (r19.0)
//.declare  (301)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (302)  rf=r size=128 type=ud align=32 words (r15.0)
//.declare  (303)  rf=r size=128 type=w alias=V0235+0 align=32 words (r10.0)
//.declare  (304)  rf=r size=128 type=q align=32 words (r101.0)
//.declare  (305)  rf=r size=128 type=q align=32 words (r103.0)
//.declare  (306)  rf=r size=128 type=df align=32 words (r21.0)
//.declare  (307)  rf=r size=128 type=df align=32 words (r25.0)
//.declare  (308)  rf=r size=128 type=df align=32 words (r28.0)
//.declare  (309)  rf=r size=128 type=df align=32 words (r30.0)
//.declare  (310)  rf=r size=128 type=df align=32 words (r32.0)
//.declare  (311)  rf=r size=128 type=df align=32 words (r34.0)
//.declare  (312)  rf=r size=128 type=q align=32 words (r36.0)
//.declare  (313)  rf=r size=128 type=q align=32 words (r38.0)
//.declare  (316)  rf=r size=128 type=q align=32 words (r56.0)
//.declare  (317)  rf=r size=128 type=q align=32 words (r60.0)
//.declare  (318)  rf=r size=128 type=q align=32 words (r62.0)
//.declare  (319)  rf=r size=128 type=q align=32 words (r64.0)
//.declare  (320)  rf=r size=128 type=q align=32 words (r67.0)
//.declare  (321)  rf=r size=128 type=q align=32 words (r70.0)
//.declare  (322)  rf=r size=128 type=q align=32 words (r76.0)
//.declare  (323)  rf=r size=128 type=q align=32 words (r78.0)
//.declare  (326)  rf=r size=128 type=d align=32 words (r84.0)
//.declare  (327)  rf=r size=128 type=d align=32 words (r86.0)
//.declare  (328)  rf=r size=128 type=q align=32 words (r88.0)
//.declare  (329)  rf=r size=128 type=q align=32 words (r90.0)
//.declare  (330)  rf=r size=128 type=q align=32 words (r105.0)
//.declare  (331)  rf=r size=128 type=q align=32 words (r107.0)
//.declare  (332)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (333)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (336)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (337)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (340)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (341)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (344)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (345)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (348)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (349)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (352)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (353)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (356)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (357)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (358)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (359)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (362)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (363)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (366)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (367)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (370)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (371)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (374)  rf=r size=128 type=uq alias=+0 align=32 words (r36.0)
//.declare  (375)  rf=r size=128 type=uq alias=+0 align=32 words (r38.0)
//.declare  (376)  rf=r size=128 type=d alias=+0 align=32 words (r36.0)
//.declare  (377)  rf=r size=128 type=d alias=+0 align=32 words (r38.0)
//.declare  (378)  rf=r size=128 type=ud alias=+0 align=32 words (r67.0)
//.declare  (379)  rf=r size=128 type=ud alias=+0 align=32 words (r70.0)
//.declare  (380)  rf=r size=128 type=d alias=+0 align=32 words (r67.0)
//.declare  (381)  rf=r size=128 type=d alias=+0 align=32 words (r70.0)
//.declare  (382)  rf=r size=128 type=d alias=+0 align=32 words (r76.0)
//.declare  (383)  rf=r size=128 type=d alias=+0 align=32 words (r78.0)
//.declare  (384)  rf=r size=128 type=d alias=+0 align=32 words (r88.0)
//.declare  (385)  rf=r size=128 type=d alias=+0 align=32 words (r90.0)
//.declare  (386)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare  (387)  rf=r size=128 type=d alias=+0 align=32 words (r17.0)
//.declare r0 (388)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (389)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (390)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (391)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (392)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (393)  rf=r size=128 type=ud align=32 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0037    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0048    | :d       |    0x4 | r3+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0050    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r3+0x38  | cti+0x58         |
// | V0052    | :q       |    0x8 | r4       | cti+0x60         |
// | V0053    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0054    | :d       |    0x4 | r4+0x10  | cti+0x70         |
// | V0055    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0056    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0057    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0058    | :d       |    0x4 | r4+0x30  | cti+0x90         |
// | V0059    | :d       |    0x4 | r4+0x34  | cti+0x94         |
// | V0041    | :uq      |    0x8 | r4+0x38  | cti+0x98         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B037}
// _main:
(W)     mov (16|M0)              r92.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r6.0<1>:uq    r4.5<0;1,0>:uq                   {Compacted,A@1,$1.dst} //  ALU pipe: int; $2
(W)     load.ugm.d32x1t.a64 (1|M0)  r7:1        [r6:1]             {I@1,$2} // ex_desc:0x0; desc:0x2108580 // $3
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r7.0<0;1,0>:d     0:w               {$2.dst}          //  ALU pipe: int; $4
(W&f2.0) jmpi                                _0_042                                                  //  ALU pipe: int; $5
// B003: Preds:{B002},  Succs:{B004, B037}
_0_043:
(W)     mov (1|M0)               r6.0<1>:uq    r4.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $7
        mov (32|M0)              r11.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $10
        mov (16|M0)              r7.0<2>:f     r6.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $8
        mov (16|M16)             r9.0<2>:f     r6.0<0;1,0>:f                                         //  ALU pipe: float; $8
        mov (16|M0)              r7.1<2>:f     r6.1<0;1,0>:f                                         //  ALU pipe: float; $9
        mov (16|M16)             r9.1<2>:ud    r6.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $9
        atomic_or.ugm.d32.a64 (32|M0)  r13:2    [r7:4]            r11:2              {A@1,$3} // ex_desc:0x0; desc:0x8200599 // $11
        cmp (32|M0)   (eq)f1.0   null<1>:d     r13.0<1;1,0>:d    0:w               {$3.dst}          //  ALU pipe: int; $13
(~f1.0) goto (32|M0)                         _0_042            _0_042                                //  ALU pipe: int; $14
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B006}
_0_044:
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r92.2<0;1,0>:uw                     //  ALU pipe: int; $17
(W)     macl (1|M0)              r5.0<1>:d     r2.3<0;1,0>:d     r92.1<0;1,0>:d   {Compacted}        //  ALU pipe: int; $19
(W)     mov (2|M0)               r93.0<1>:f    r3.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $16
        add3 (32|M0)             r94.0<1>:d    r5.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {@1,$0.dst} //  ALU pipe: int; $19
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r93.1<0;1,0>:ud   0x1:uw              {F@1}           //  ALU pipe: int; $21
        mov (16|M0)              r6.0<2>:ud    r94.0<1;1,0>:ud                  {Compacted,I@2}      //  ALU pipe: int; $20
        mov (16|M16)             r8.0<2>:ud    r95.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $20
        mov (16|M0)              r101.0<1>:q   r6.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $20
        mov (16|M16)             r103.0<1>:q   r8.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $20
(W&f0.0) jmpi                                _0_045                                                  //  ALU pipe: int; $22
// B005: [inDivergent],  Preds:{B004},  Succs:{B010}
_0_046:
(W)     mov (1|M0)               r1.0<1>:df    r3.0<0;1,0>:uq                                        //  ALU pipe: long; $26
(W)     mov (1|M0)               r5.0<1>:df    0x3FF0000000000000:df                                 //  ALU pipe: long; $30
(W)     mov (1|M0)               r2.0<2>:f     r1.0<0;1,0>:df                   {L@2}                //  ALU pipe: float; $27
(W)     mov (1|M0)               r7.0<1>:df    0xBCF0000000000000:df                              {I@3} //  ALU pipe: long; $33
(W)     math.inv (1|M0)          r3.3<1>:f     r2.0<0;1,0>:f                    {F@1}                //  ALU pipe: math; $28
(W)     mov (1|M0)               r4.1<1>:df    r3.3<0;1,0>:f                    {M@1}                //  ALU pipe: long; $29
(W)     mov (1|M0)               r11.0<1>:df   0x0:df                                                //  ALU pipe: long; $36
(W)     mad (1|M0)               r6.0<1>:df    r5.0<0;0>:df      r4.1<0;0>:df      -r1.0<0>:df      {L@2} //  ALU pipe: long; $31
        mov (16|M0)              r19.0<2>:ud   r94.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $41
(W)     add (1|M0)               r9.0<1>:df    r6.0<0;1,0>:df    r7.0<0;1,0>:df   {Compacted,A@1}    //  ALU pipe: long; $33
        mov (16|M16)             r23.0<2>:ud   r95.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $41
(W)     mad (1|M0)               r10.0<1>:df   r4.1<0;0>:df      r9.0<0;0>:df      r4.1<0>:df       {L@1} //  ALU pipe: long; $34
(W)     mov (1|M0)               r27.0<1>:df   0x41F0000000000000:df                                 //  ALU pipe: long; $42
(W)     mul (1|M0)               r12.0<1>:df   r10.0<0;1,0>:df   r11.0<0;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $36
        mov (16|M0)              r21.0<1>:df   r19.0<2;1,0>:ud                  {I@2}                //  ALU pipe: long; $41
(W)     mov (1|M0)               r13.0<2>:ud   r12.0<0;1,0>:df                  {L@2}                //  ALU pipe: int; $37
        mov (16|M16)             r25.0<1>:df   r23.0<2;1,0>:ud                  {I@2}                //  ALU pipe: long; $41
(W)     mul (1|M0)               acc0.0<1>:d   r13.0<0;1,0>:d    r3.0<0;1,0>:uw   {I@1}              //  ALU pipe: int; $38
(W)     macl (1|M0)              r15.0<1>:d    r13.0<0;1,0>:d    r3.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $39
        mov (32|M0)              r74.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $63
(W)     mov (1|M0)               r16.0<1>:d    -r15.0<0;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $39
(W)     mov (1|M0)               r18.0<1>:df   r16.0<0;1,0>:ud                  {I@1}                //  ALU pipe: long; $40
        mad (16|M0)              r28.0<1>:df   r21.0<1;0>:df     r27.0<0;0>:df     r18.0<0>:df      {Compacted,L@1} //  ALU pipe: long; $43
        mad (16|M16)             r30.0<1>:df   r25.0<1;0>:df     r27.0<0;0>:df     r18.0<0>:df      {Compacted} //  ALU pipe: long; $43
        mul (16|M0)              r32.0<1>:df   r10.0<0;1,0>:df   r28.0<1;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $44
        mul (16|M16)             r34.0<1>:df   r10.0<0;1,0>:df   r30.0<1;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $44
        mov (16|M0)              r36.0<1>:uq   r32.0<1;1,0>:df                  {L@2}                //  ALU pipe: int; $45
        mov (16|M16)             r38.0<1>:uq   r34.0<1;1,0>:df                  {L@1}                //  ALU pipe: int; $45
        mov (16|M0)              r42.0<1>:d    r36.1<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $48
        mov (16|M16)             r43.0<1>:d    r38.1<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $49
        mov (16|M0)              r44.0<1>:d    r36.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $50
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r42.0<1;1,0>:ud   0x1:uw              {I@2}           //  ALU pipe: int; $52
        mov (16|M16)             r45.0<1>:d    r38.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $50
(W)     mul (16|M0)              acc0.0<1>:d   r44.0<1;1,0>:d    r3.2<0;1,0>:uw   {I@3}              //  ALU pipe: int; $51
        macl (16|M0)             r46.0<1>:d    r44.0<1;1,0>:d    r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $51
(W)     mul (16|M16)             acc0.0<1>:d   r45.0<1;1,0>:d    r3.2<0;1,0>:uw   {I@3}              //  ALU pipe: int; $51
(~f3.0) sel (32|M0)              r48.0<1>:d    r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $53
        macl (16|M16)            r47.0<1>:d    r45.0<1;1,0>:d    r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $52
        mov (16|M0)              r40.0<1>:d    r36.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $46
        add (32|M0)              r50.0<1>:d    r48.0<1;1,0>:d    r46.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $54
        mov (16|M16)             r41.0<1>:d    r38.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $47
(W)     mul (16|M0)              acc0.0<1>:ud  r40.0<1;1,0>:ud   r93.0<0;1,0>:uw  {I@3}              //  ALU pipe: int; $58
        add3 (32|M0)             r52.0<1>:d    0:w                -r15.0<0;0>:d     -r50.0<1>:d      {I@3} //  ALU pipe: int; $55
        macl (16|M0)             r66.0<1>:ud   r40.0<1;1,0>:ud   r93.0<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $59
(W)     mul (16|M16)             acc0.0<1>:ud  r41.0<1;1,0>:ud   r93.0<0;1,0>:uw  {I@4}              //  ALU pipe: int; $59
        macl (16|M16)            r69.0<1>:ud   r41.0<1;1,0>:ud   r93.0<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $60
(W)     mul (16|M0)              acc0.0<1>:ud  r40.0<1;1,0>:ud   r93.0<0;1,0>:uw                     //  ALU pipe: int; $60
        mach (16|M0)             r72.0<1>:d    r40.0<1;1,0>:ud   r93.0<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r41.0<1;1,0>:ud   r93.0<0;1,0>:uw                     //  ALU pipe: int; $60
        mov (16|M0)              r54.0<2>:ud   r52.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $56
        mov (16|M16)             r58.0<2>:ud   r53.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $56
        mach (16|M16)            r73.0<1>:d    r41.0<1;1,0>:ud   r93.0<0;1,0>:ud                     //  ALU pipe: int; $62
        shl (16|M0)              r56.0<1>:q    r54.0<2;1,0>:d    32:w               {I@3}            //  ALU pipe: int; $56
        shl (16|M16)             r60.0<1>:q    r58.0<2;1,0>:d    32:w               {I@3}            //  ALU pipe: int; $56
        mov (16|M0)              r67.0<2>:ud   r66.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $59
        mov (16|M16)             r70.0<2>:ud   r69.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $60
        add (16|M0)              r62.0<1>:q    r56.0<1;1,0>:q    r101.0<1;1,0>:q  {Compacted,I@4}    //  ALU pipe: int; $57
        add (16|M16)             r64.0<1>:q    r60.0<1;1,0>:q    r103.0<1;1,0>:q  {Compacted,I@4}    //  ALU pipe: int; $57
        add (16|M0)              r67.1<2>:d    r72.0<1;1,0>:d    r74.0<1;1,0>:d                      //  ALU pipe: int; $64
        add (16|M16)             r70.1<2>:d    r73.0<1;1,0>:d    r75.0<1;1,0>:d                      //  ALU pipe: int; $65
        add (16|M0)              r76.0<1>:q    r62.0<1;1,0>:q    -r67.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $66
        add (16|M16)             r78.0<1>:q    r64.0<1;1,0>:q    -r70.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $66
        mov (16|M0)              r80.0<1>:d    r76.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $67
        mov (16|M16)             r81.0<1>:d    r78.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $68
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r80.0<1;1,0>:ud   r93.0<0;1,0>:ud  {I@1}              //  ALU pipe: int; $71
        mov (16|M0)              r82.0<1>:d    r76.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $69
        mov (16|M16)             r83.0<1>:d    r78.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $70
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r82.0<1;1,0>:d    r93.1<0;1,0>:d   {I@1}              //  ALU pipe: int; $72
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r82.0<1;1,0>:ud   r93.1<0;1,0>:ud                     //  ALU pipe: int; $74
(~f3.0) sel (32|M0)              r84.0<1>:d    r93.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $76
(~f3.0) sel (32|M0)              r86.0<1>:d    r93.1<0;1,0>:d    0:w                                 //  ALU pipe: int; $77
        mov (16|M0)              r88.0<2>:d    r84.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $80
        mov (16|M16)             r90.0<2>:d    r85.0<1;1,0>:d                                        //  ALU pipe: int; $81
        mov (16|M0)              r88.1<2>:d    r86.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $82
        mov (16|M16)             r90.1<2>:d    r87.0<1;1,0>:d                                        //  ALU pipe: int; $83
        add (16|M0)              r105.0<1>:q   r76.0<1;1,0>:q    -r88.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $84
        add (16|M16)             r107.0<1>:q   r78.0<1;1,0>:q    -r90.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $84
(W)     jmpi                                 _0_047                                                  // $85
// B006: [inDivergent],  Preds:{B004},  Succs:{B007, B008}
_0_045:
(W)     mov (1|M0)               r93.2<2>:d    r3.0<0;1,0>:q                                         //  ALU pipe: int; $87
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r93.2<0;1,0>:d    0:w               {I@1}             //  ALU pipe: int; $88
(W&f2.0) jmpi                                _0_048                                                  //  ALU pipe: int; $89
// B007: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_049:
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $91
(W)     mov (1|M0)               r2.0<1>:f     r93.2<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $92
(W)     mov (1|M0)               r9.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $97
(W)     math.inv (1|M0)          r8.0<1>:f     r2.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $96
        mov (32|M0)              r5.0<1>:f     r94.0<1;1,0>:ud                                       //  ALU pipe: float; $95
(W)     mad (1|M0)               r10.0<1>:f    r8.0<0;0>:f       r9.0<0;0>:f       r8.0<0>:f        {Compacted,A@1} //  ALU pipe: float; $97
        mov (32|M0)              r13.0<1>:ud   r5.0<1;1,0>:f                    {F@2}                //  ALU pipe: int; $99
        mul (32|M0)              r11.0<1>:f    r5.0<1;1,0>:f     r10.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $98
(W)     mov (1|M0)               r3.0<1>:ud    r2.0<0;1,0>:f                                         //  ALU pipe: int; $93
        add (32|M0)              r15.0<1>:d    r94.0<1;1,0>:d    -r13.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $100
        mov (32|M0)              r17.0<1>:ud   r11.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $101
(W)     add (1|M0)               r4.2<1>:d     r93.2<0;1,0>:d    -r3.0<0;1,0>:d   {I@3}              //  ALU pipe: int; $94
        mov (32|M0)              r25.0<1>:f    r17.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $104
        mov (32|M0)              r21.0<1>:f    r15.0<1;1,0>:ud                                       //  ALU pipe: float; $103
(W)     mov (1|M0)               r20.0<1>:f    r4.2<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $102
        mad (32|M0)              acc0.0<1>:f   r5.0<1;0>:f       r25.0<1;0>:f      -r2.0<0>:f       {F@3} //  ALU pipe: float; $106
        mad (32|M0)              acc2.0<1>:f   r21.0<1;0>:f      r25.0<1;0>:f      -r20.0<0>:f      {F@2} //  ALU pipe: float; $108
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $109
        mul (32|M0)              r27.0<1>:f    r10.0<0;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $110
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $111
        mov (32|M0)              r29.0<1>:ud   r27.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $112
        add (32|M0)              r31.0<1>:d    r29.0<1;1,0>:d    r17.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $113
(W)     mul (16|M0)              acc0.0<1>:d   r31.0<1;1,0>:d    r93.4<0;1,0>:uw  {I@1}              //  ALU pipe: int; $114
        macl (16|M0)             r33.0<1>:d    r31.0<1;1,0>:d    r93.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $114
(W)     mul (16|M16)             acc0.0<1>:d   r32.0<1;1,0>:d    r93.4<0;1,0>:uw                     //  ALU pipe: int; $114
        macl (16|M16)            r34.0<1>:d    r32.0<1;1,0>:d    r93.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $115
        add (32|M0)              r35.0<1>:d    r94.0<1;1,0>:d    -r33.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $115
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r35.0<1;1,0>:ud   r93.2<0;1,0>:ud  {I@1}              //  ALU pipe: int; $116
(~f1.0) sel (32|M0)              r38.0<1>:d    r93.2<0;1,0>:d    0:w                                 //  ALU pipe: int; $117
        add3 (32|M0)             r96.0<1>:d    r94.0<1;0>:d      -r33.0<1;0>:d     -r38.0<1>:d      {I@1} //  ALU pipe: int; $118
(W)     jmpi                                 _0_050                                                  // $119
// B008: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_048:
        mov (32|M0)              r96.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $121
// B009: [inDivergent],  Preds:{B008, B007},  Succs:{B010}
_0_050:
        mov (16|M0)              r5.0<2>:ud    r96.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $123
        mov (16|M16)             r7.0<2>:ud    r97.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $123
        mov (16|M0)              r105.0<1>:q   r5.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $123
        mov (16|M16)             r107.0<1>:q   r7.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $123
// B010: [inDivergent],  Preds:{B009, B005},  Succs:{B011, B018}
_0_047:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $125
(W&f0.0) jmpi                                _0_051                                                  //  ALU pipe: int; $126
// B011: [inDivergent],  Preds:{B010},  Succs:{B012, B017}
_0_052:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $128
(W&f3.0) jmpi                                _0_053                                                  //  ALU pipe: int; $129
// B012: [inDivergent],  Preds:{B011},  Succs:{B013, B016}
_0_054:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r3.2<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $131
(W&f2.0) jmpi                                _0_055                                                  //  ALU pipe: int; $132
// B013: [inDivergent],  Preds:{B012},  Succs:{B014, B015}
_0_056:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.2<0;1,0>:d     4:w                                 //  ALU pipe: int; $134
(W&~f1.0) jmpi                               _0_057                                                  //  ALU pipe: int; $135
// B014: [inDivergent],  Preds:{B013},  Succs:{B023}
_0_058:
        shl (16|M0)              r5.0<1>:q     r105.0<1;1,0>:q   3:w               {Compacted,I@7}   //  ALU pipe: int; $137
        shl (16|M16)             r7.0<1>:q     r107.0<1;1,0>:q   3:w               {Compacted,I@7}   //  ALU pipe: int; $137
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $138
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $138
        load.ugm.d64.a64 (32|M0)  r13:4         [r9:4]             {I@1,$4} // ex_desc:0x0; desc:0x8400780 // $140
        mov (16|M0)              r17.0<2>:f    r13.0<1;1,0>:q                   {$4.dst}             //  ALU pipe: float; $141
        mov (16|M16)             r19.0<2>:f    r15.0<1;1,0>:q                                        //  ALU pipe: float; $141
        mov (16|M0)              r99.0<1>:ud   r17.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $141
        mov (16|M16)             r100.0<1>:ud  r19.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $141
(W)     jmpi                                 _0_059                                                  // $142
// B015: [inDivergent],  Preds:{B013},  Succs:{B023}
_0_057:
        mov (32|M0)              r99.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $144
(W)     jmpi                                 _0_059                                                  // $145
// B016: [inDivergent],  Preds:{B012},  Succs:{B023}
_0_055:
        shl (16|M0)              r5.0<1>:q     r105.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $147
        shl (16|M16)             r7.0<1>:q     r107.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $147
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $148
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $148
        load.ugm.d32.a64 (32|M0)  r13:2         [r9:4]             {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $150
        mov (32|M0)              r99.0<1>:f    r13.0<1;1,0>:ud                  {$5.dst}             //  ALU pipe: float; $151
(W)     jmpi                                 _0_059                                                  // $152
// B017: [inDivergent],  Preds:{B011},  Succs:{B023}
_0_053:
        shl (16|M0)              r5.0<1>:q     r105.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $154
        shl (16|M16)             r7.0<1>:q     r107.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $154
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $155
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $155
        load.ugm.d32.a64 (32|M0)  r13:2         [r9:4]             {A@1,$6} // ex_desc:0x0; desc:0x8200580 // $157
        mov (32|M0)              r99.0<1>:f    r13.0<1;1,0>:d                   {$6.dst}             //  ALU pipe: float; $158
(W)     jmpi                                 _0_059                                                  // $159
// B018: [inDivergent],  Preds:{B010},  Succs:{B019, B020}
_0_051:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.2<0;1,0>:d     1:w                                 //  ALU pipe: int; $161
(W&f0.0) jmpi                                _0_060                                                  //  ALU pipe: int; $162
// B019: [inDivergent],  Preds:{B018},  Succs:{B023}
_0_061:
        shl (16|M0)              r5.0<1>:q     r105.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $164
        shl (16|M16)             r7.0<1>:q     r107.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $164
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $165
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $165
        load.ugm.d32.a64 (32|M0)  r99:2         [r9:4]             {A@1,$7} // ex_desc:0x0; desc:0x8200580 // $167
(W)     jmpi                                 _0_059                                                  // $168
// B020: [inDivergent],  Preds:{B018},  Succs:{B021, B022}
_0_060:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $170
(W&~f3.0) jmpi                               _0_062                                                  //  ALU pipe: int; $171
// B021: [inDivergent],  Preds:{B020},  Succs:{B023}
_0_063:
        shl (16|M0)              r5.0<1>:q     r105.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $173
        shl (16|M16)             r7.0<1>:q     r107.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $173
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $174
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $174
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r9:4]             {I@1,$8} // ex_desc:0x0; desc:0x8200B80 // $176
        shl (32|M0)              r99.0<1>:d    r14.0<1;1,0>:ud   16:w               {$8.dst}         //  ALU pipe: int; $177
(W)     jmpi                                 _0_059                                                  // $178
// B022: [inDivergent],  Preds:{B020},  Succs:{B023}
_0_062:
        mov (32|M0)              r99.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $180
// B023: [inDivergent],  Preds:{B022, B021, B019, B017, B016, B015, B014},  Succs:{B024, B030}
_0_059:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $182
(W&f2.0) jmpi                                _0_064                                                  //  ALU pipe: int; $183
// B024: [inDivergent],  Preds:{B023},  Succs:{B025, B029}
_0_065:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $185
(W&f1.0) jmpi                                _0_066                                                  //  ALU pipe: int; $186
// B025: [inDivergent],  Preds:{B024},  Succs:{B026, B028}
_0_067:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r4.4<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $188
(W&f0.0) jmpi                                _0_068                                                  //  ALU pipe: int; $189
// B026: [inDivergent],  Preds:{B025},  Succs:{B027, B037}
_0_069:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r4.4<0;1,0>:d     4:w                                 //  ALU pipe: int; $191
(~f3.0) goto (32|M0)                         _0_042            _0_042                                //  ALU pipe: int; $192
// B027: [inDivergent],  Preds:{B026},  Succs:{B037}
_0_070:
        mov (16|M0)              r11.0<2>:ud   r99.0<1;1,0>:ud                  {Compacted,@7,$7.dst} //  ALU pipe: int; $197
        mov (16|M16)             r15.0<2>:ud   r100.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $197
        shl (16|M0)              r1.0<1>:q     r101.0<1;1,0>:q   3:w               {Compacted}       //  ALU pipe: int; $194
        shl (16|M16)             r5.0<1>:q     r103.0<1;1,0>:q   3:w               {Compacted}       //  ALU pipe: int; $194
        mov (16|M0)              r13.0<1>:q    r11.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $197
        mov (16|M16)             r17.0<1>:q    r15.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $197
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $195
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $195
        mov (16|M0)              r19.0<1>:d    r13.0<2;1,0>:d                   {Compacted,I@4}      //  ALU pipe: int; $198
        mov (16|M0)              r21.0<1>:d    r13.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $200
        mov (16|M16)             r20.0<1>:d    r17.0<2;1,0>:d                   {Compacted,I@5}      //  ALU pipe: int; $199
        mov (16|M16)             r22.0<1>:d    r17.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $201
        store.ugm.d32x2.a64 (32|M0)  [r7:4]     r19:4              {I@1,$9} // ex_desc:0x0; desc:0x8001584 // $202
        goto (32|M0)                         _0_042            _0_042                                // $203
// B028: [inDivergent],  Preds:{B025},  Succs:{B037}
_0_068:
        shl (16|M0)              r5.0<1>:q     r101.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $206
        shl (16|M16)             r7.0<1>:q     r103.0<1;1,0>:q   2:w               {Compacted,$9.src} //  ALU pipe: int; $206
        mov (32|M0)              r1.0<1>:ud    r99.0<1;1,0>:f                   {$7.dst}             //  ALU pipe: int; $205
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $207
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $207
        store.ugm.d32.a64 (32|M0)  [r9:4]       r1:2               {I@1,$10} // ex_desc:0x0; desc:0x8000584 // $209
        goto (32|M0)                         _0_042            _0_042                                // $210
// B029: [inDivergent],  Preds:{B024},  Succs:{B037}
_0_066:
        shl (16|M0)              r5.0<1>:q     r101.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $213
        shl (16|M16)             r7.0<1>:q     r103.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $213
        sync.nop                             null                             {Compacted,$10.src}    // $212
        mov (32|M0)              r1.0<1>:d     r99.0<1;1,0>:f                   {$7.dst}             //  ALU pipe: int; $212
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $214
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $214
        store.ugm.d32.a64 (32|M0)  [r9:4]       r1:2               {I@1,$11} // ex_desc:0x0; desc:0x8000584 // $216
        goto (32|M0)                         _0_042            _0_042                                // $217
// B030: [inDivergent],  Preds:{B023},  Succs:{B031, B032}
_0_064:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $219
(W&f2.0) jmpi                                _0_071                                                  //  ALU pipe: int; $220
// B031: [inDivergent],  Preds:{B030},  Succs:{B037}
_0_072:
        shl (16|M0)              r1.0<1>:q     r101.0<1;1,0>:q   2:w               {Compacted,$11.src} //  ALU pipe: int; $222
        shl (16|M16)             r5.0<1>:q     r103.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $222
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $223
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $223
        store.ugm.d32.a64 (32|M0)  [r7:4]       r99:2              {I@1,$7} // ex_desc:0x0; desc:0x8000584 // $225
        goto (32|M0)                         _0_042            _0_042                                // $226
// B032: [inDivergent],  Preds:{B030},  Succs:{B033, B037}
_0_071:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $228
(~f1.0) goto (32|M0)                         _0_042            _0_042                                //  ALU pipe: int; $229
// B033: [inDivergent],  Preds:{B032},  Succs:{B034, B035}
_0_073:
        sync.nop                             null                             {Compacted,$11.src}    // $231
        and (32|M0)              r1.0<1>:d     r99.0<1;1,0>:d    2147483647:d               {$7.dst} //  ALU pipe: int; $231
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $232
(f0.0)  goto (32|M0)                         _0_074            _0_074                                //  ALU pipe: int; $233
// B034: [inDivergent],  Preds:{B033},  Succs:{B036}
_0_075:
        shr (32|M0)              r1.0<1>:ud    r99.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $235
        and (32|M0)              r6.0<1>:d     r1.0<1;1,0>:d     1:w               {Compacted,@1,$7.src} //  ALU pipe: int; $236
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r99.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $237
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $238
        mov (32|M0)              r98.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $239
        goto (32|M0)                         _0_074            _0_076                                // $240
// B035: [inDivergent],  Preds:{B033},  Succs:{B036}
_0_074:
        join (32|M0)                         _0_076                                                  // 
L3360:
        shr (32|M0)              r1.0<1>:ud    r99.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $242
        or (32|M0)               r98.0<1>:w    r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $244
// B036: [inDivergent],  Preds:{B035, B034},  Succs:{B037}
_0_076:
        join (32|M0)                         _0_042                                                  // 
L3408:
        shl (16|M0)              r1.0<1>:q     r101.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $246
        shl (16|M16)             r5.0<1>:q     r103.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $246
        mov (32|M0)              r11.0<1>:ud   r98.0<1;1,0>:uw                  {I@4}                //  ALU pipe: int; $249
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,@3,$7.src} //  ALU pipe: int; $247
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $247
        store.ugm.d16u32.a64 (32|M0)  [r7:4]    r11:2              {I@1,$12} // ex_desc:0x0; desc:0x8000B84 // $250
// B037: Preds:{B036, B032, B031, B029, B028, B027, B026, B003, B002},  Succs:{}
_0_042:
        join (32|M0)                         L3488                                                   // 
L3488:
(W)     mov (16|M0)              r127.0<1>:f   r92.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $252
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$13} // wr:1+0, rd:0; end of thread // $252
L3512:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x12:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 231
//.accSubDef: 3
//.accSubUse: 3
//.accSubCandidateDef: 3
//.accSubCandidateUse: 3
//
//
//.singlePipeAtOneDistNum: 42
//.allAtOneDistNum: 12
//.syncInstCount: 2
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 12
//.AfterReadTokenDepCount: 8
