//.kernel _ZTSN9p42extras8FlatNameILNS_4KindE3ELi256EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 604709628 1620024839 -hashmovs1 0 32 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 604709628 1620024839 -hashmovs1 0 32 -GRFBumpUpNumber 2 "
//.instCount 236
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 3
//.spill flag load 3

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r5.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r0.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r0.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r5.0)
//.declare V0034 (44)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r5.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r4.6)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.12)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.10)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.11)
//.declare V0062 (72)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0064 (74)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0065 (75)  rf=r size=128 type=d align=32 words (r6.0)
//.declare P01 (76)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0066 (77)  rf=r size=128 type=ud alias=V0065+0 align=32 words (r6.0)
//.declare V0067 (78)  rf=r size=4 type=ud alias=V0034+0 align=2 words (r2.3)
//.declare V0068 (79)  rf=r size=8 type=uq alias=V0058+0 align=4 words (r4.4)
//.declare V0069 (80)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0070 (81)  rf=r size=4 type=d align=32 words (r9.0)
//.declare P02 (82)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0071 (83)  rf=r size=8 type=uq alias=V0056+0 align=4 words (r4.2)
//.declare V0072 (84)  rf=r size=8 type=uq align=32 words (r10.0)
//.declare V0074 (86)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0075 (87)  rf=r size=256 type=ud alias=V0074+0 align=32 words (r11.0)
//.declare V0076 (88)  rf=r size=8 type=ud alias=V0072+0 align=32 words (r10.0)
//.declare V0077 (89)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0078 (90)  rf=r size=128 type=ud align=32 words (r17.0)
//.declare P03 (92)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0081 (94)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0082 (95)  rf=r size=8 type=d alias=V0045+0 align=4 words (r2.6)
//.declare V0084 (97)  rf=r size=32 type=d align=32 words (r19.0)
//.declare V0085 (98)  rf=r size=8 type=uq align=32 words (r20.0)
//.declare V0087 (100)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0089 (102)  rf=r size=128 type=f alias=V0087+0 align=32 words (r21.0)
//.declare V0090 (103)  rf=r size=32 type=f alias=V0084+0 align=32 words (r19.0)
//.declare V0097 (110)  rf=r size=8 type=q alias=V0042+0 align=4 words (r4.6)
//.declare V0098 (111)  rf=r size=32 type=d align=32 words (r23.0)
//.declare V0099 (112)  rf=r size=8 type=q align=32 words (r24.0)
//.declare V0100 (113)  rf=r size=32 type=f alias=V0098+0 align=32 words (r23.0)
//.declare V0109 (122)  rf=r size=32 type=d align=32 words (r25.0)
//.declare V0111 (124)  rf=r size=32 type=f alias=V0109+0 align=32 words (r25.0)
//.declare V0120 (133)  rf=r size=32 type=d align=32 words (r26.0)
//.declare V0122 (135)  rf=r size=32 type=f alias=V0120+0 align=32 words (r26.0)
//.declare P04 (144)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P05 (145)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0131 (146)  rf=r size=128 type=f align=32 words (r27.0)
//.declare P06 (147)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P07 (148)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P08 (149)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0132 (150)  rf=r size=4 type=ud alias=V0046+0 align=2 words (r3.0)
//.declare P09 (151)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P10 (152)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P11 (153)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0133 (154)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0134 (155)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0135 (156)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0136 (157)  rf=r size=4 type=f align=4 words (r2.14)
//.declare V0137 (158)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0140 (161)  rf=r size=8 type=uq align=32 words (r32.0)
//.declare V0141 (162)  rf=r size=8 type=q align=32 words (r31.0)
//.declare V0142 (163)  rf=r size=4 type=f align=32 words (r33.0)
//.declare V0143 (164)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0146 (167)  rf=r size=8 type=uq align=32 words (r34.0)
//.declare V0147 (168)  rf=r size=4 type=d align=32 words (r35.0)
//.declare V0148 (169)  rf=r size=4 type=ud alias=V0147+0 align=32 words (r35.0)
//.declare V0149 (170)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0152 (173)  rf=r size=8 type=uq align=32 words (r36.0)
//.declare V0153 (174)  rf=r size=4 type=d align=32 words (r37.0)
//.declare V0154 (175)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0157 (178)  rf=r size=8 type=uq align=32 words (r38.0)
//.declare V0159 (180)  rf=r size=4 type=ud align=32 words (r39.0)
//.declare V0160 (181)  rf=r size=4 type=w alias=V0159+0 align=32 words (r39.0)
//.declare V0162 (183)  rf=r size=4 type=d alias=V0142+0 align=32 words (r33.0)
//.declare V0163 (184)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0166 (187)  rf=r size=8 type=uq align=32 words (r40.0)
//.declare P12 (188)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0168 (190)  rf=r size=4 type=d align=4 words (r3.12)
//.declare V0169 (191)  rf=r size=4 type=f align=2 words (r2.13)
//.declare V0170 (192)  rf=r size=4 type=uw alias=V0168+0 align=2 words (r3.24)
//.declare V0171 (193)  rf=r size=2 type=uw align=1 words (r2.30)
//.declare A00 (194)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare P13 (195)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0172 (196)  rf=r size=4 type=ud alias=V0135+0 align=2 words (r2.12)
//.declare V0173 (197)  rf=r size=8 type=ud alias=V0081+0 align=2 words (r2.8)
//.declare P14 (198)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P15 (199)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0174 (200)  rf=r size=128 type=f align=32 words (r41.0)
//.declare P16 (201)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P17 (202)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P18 (203)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0175 (204)  rf=r size=128 type=f align=32 words (r43.0)
//.declare V0176 (205)  rf=r size=128 type=f align=32 words (r45.0)
//.declare V0177 (206)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0178 (207)  rf=r size=4 type=d align=2 words (r3.13)
//.declare V0179 (208)  rf=r size=128 type=f align=32 words (r47.0)
//.declare V0180 (209)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0182 (211)  rf=r size=4 type=uw alias=V0180+0 align=2 words (r3.28)
//.declare V0183 (212)  rf=r size=2 type=uw align=1 words (r3.30)
//.declare A01 (213)  rf=a size=2 type=uw align=1 words (a0.1)
//.declare V0184 (214)  rf=r size=4 type=d align=2 words (r4.1)
//.declare P19 (215)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0185 (216)  rf=r size=4 type=ud alias=V0184+0 align=2 words (r4.1)
//.declare P20 (217)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare P21 (218)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0187 (220)  rf=r size=4 type=uw alias=V0184+0 align=2 words (r4.2)
//.declare V0188 (221)  rf=r size=2 type=uw align=1 words (r4.4)
//.declare A02 (222)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0189 (223)  rf=r size=4 type=f align=2 words (r4.3)
//.declare V0191 (225)  rf=r size=4 type=f align=2 words (r4.6)
//.declare V0192 (226)  rf=r size=2 type=uw align=1 words (r4.5)
//.declare A03 (227)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare P22 (228)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0193 (229)  rf=r size=4 type=ud alias=V0180+0 align=2 words (r3.14)
//.declare P23 (230)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P24 (231)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0194 (232)  rf=r size=128 type=f align=32 words (r49.0)
//.declare P25 (233)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0195 (234)  rf=r size=4 type=ud alias=V0178+0 align=2 words (r3.13)
//.declare P26 (235)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P27 (236)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0196 (237)  rf=r size=128 type=f align=32 words (r51.0)
//.declare P28 (238)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0198 (240)  rf=r size=256 type=uq align=32 words (r53.0)
//.declare V0199 (241)  rf=r size=256 type=ud alias=V0198+0 align=32 words (r53.0)
//.declare V0200 (242)  rf=r size=128 type=d align=32 words (r57.0)
//.declare  (243)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (244)  rf=r size=4 type=f align=2 words (r4.7)
//.declare  (245)  rf=r size=2 type=w align=1 words (r4.20)
//.declare  (246)  rf=r size=2 type=uw align=1 words (r4.21)
//.declare  (247)  rf=r size=2 type=w align=1 words (r4.22)
//.declare  (248)  rf=r size=2 type=uw align=1 words (r4.23)
//.declare  (251)  rf=r size=2 type=w align=1 words (r4.28)
//.declare  (252)  rf=r size=2 type=uw align=1 words (r4.29)
//.declare  (253)  rf=r size=4 type=uw align=2 words (r4.30)
//.declare  (254)  rf=r size=4 type=uw align=2 words (r8.4)
//.declare  (255)  rf=r size=4 type=uw align=2 words (r8.6)
//.declare  (256)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (257)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (258)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (259)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (260)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (261)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare r0 (262)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (263)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (264)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (265)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (266)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (267)  rf=r size=128 type=ud align=32 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0038    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0034    | :d       |    0x4 | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x10  | inline+0x10      |
// | V0045    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0046    | :d       |    0x4 | r3       | cti+0x20         |
// | V0047    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0048    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0051    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0052    | :d       |    0x4 | r3+0x30  | cti+0x50         |
// | V0053    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0054    | :q       |    0x8 | r4       | cti+0x60         |
// | V0055    | :d       |    0x4 | r4+0x8   | cti+0x68         |
// | V0056    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0057    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0058    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0059    | :d       |    0x4 | r4+0x28  | cti+0x88         |
// | V0060    | :d       |    0x4 | r4+0x2C  | cti+0x8C         |
// | V0042    | :uq      |    0x8 | r4+0x30  | cti+0x90         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B035}
// _main:
(W)     mov (16|M0)              r5.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:d   r2.0<0;1,0>:d     r5.2<0;1,0>:uw   {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r4.0<1>:d     r2.0<0;1,0>:d     r5.1<0;1,0>:d    {Compacted,$1.dst} //  ALU pipe: int; $4
        add (32|M0)              r6.0<1>:d     r4.0<0;1,0>:d     r1.0<1;1,0>:uw   {@1,$0.dst}        //  ALU pipe: int; $4
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r6.0<1;1,0>:ud    r2.3<0;1,0>:ud   {I@1}              //  ALU pipe: int; $5
(~f2.0) goto (32|M0)                         _0_039            _0_039                                //  ALU pipe: int; $6
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B035}
_0_040:
(W)     mov (1|M0)               r8.0<1>:uq    r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $8
(W)     load.ugm.d32x1t.a64 (1|M0)  r9:1        [r8:1]             {I@1,$2} // ex_desc:0x0; desc:0x2108580 // $9
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r9.0<0;1,0>:d     0:w               {$2.dst}          //  ALU pipe: int; $10
(f1.0)  goto (32|M0)                         _0_039            _0_039                                //  ALU pipe: int; $11
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B035}
_0_041:
(W)     mov (1|M0)               r10.0<1>:uq   r4.2<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $13
        mov (32|M0)              r15.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $16
        mov (16|M0)              r11.0<2>:f    r10.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $14
        mov (16|M16)             r13.0<2>:f    r10.0<0;1,0>:f                                        //  ALU pipe: float; $14
        mov (16|M0)              r11.1<2>:f    r10.1<0;1,0>:f                                        //  ALU pipe: float; $15
        mov (16|M16)             r13.1<2>:ud   r10.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $15
        atomic_or.ugm.d32.a64 (32|M0)  r17:2    [r11:4]           r15:2              {A@1,$3} // ex_desc:0x0; desc:0x8200599 // $17
        or (32|M0)    (eq)f0.0   null<1>:d     r17.0<1;1,0>:d    r6.0<1;1,0>:d    {$3.dst}           //  ALU pipe: int; $19
(~f0.0) goto (32|M0)                         _0_039            _0_039                                //  ALU pipe: int; $21
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B007}
_0_042:
(W)     mov (1|M0)               r20.0<1>:uq   r4.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $24
(W)     mov (1|M0)               r24.0<1>:q    r4.6<0;1,0>:q                                         //  ALU pipe: int; $66
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r19:1 [r20:1]            {I@2,$4} // ex_desc:0x0; desc:0x219C580 // $25
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r23:1 [r24:1+0x20]       {I@1,$5} // ex_desc:0x20000; desc:0x219C580 // $67
(W)     mov (2|M0)               r21.0<1>:d    r19.0<1;1,0>:d                   {Compacted,$4.dst}   //  ALU pipe: int; $26
(W)     mov (1|M0)               r21.2<1>:ud   r19.2<0;1,0>:ud                                       //  ALU pipe: int; $30
(W)     mov (1|M0)               r21.3<1>:ud   r19.3<0;1,0>:ud                                       //  ALU pipe: int; $36
(W)     mov (1|M0)               r21.4<1>:ud   r19.4<0;1,0>:ud                                       //  ALU pipe: int; $42
(W)     mov (1|M0)               r21.5<1>:ud   r19.5<0;1,0>:ud                                       //  ALU pipe: int; $48
(W)     mov (1|M0)               r21.6<1>:f    r19.6<0;1,0>:f                                        //  ALU pipe: float; $54
(W)     mov (1|M0)               r21.7<1>:f    r19.7<0;1,0>:f                                        //  ALU pipe: float; $60
(W)     mov (1|M0)               r21.8<1>:f    r23.0<0;1,0>:f                   {$5.dst}             //  ALU pipe: float; $68
(W)     mov (1|M0)               r21.9<1>:f    r23.1<0;1,0>:f                                        //  ALU pipe: float; $74
(W)     mov (1|M0)               r21.10<1>:f   r23.2<0;1,0>:f                                        //  ALU pipe: float; $80
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r25:1 [r24:1+0x40]       {$6} // ex_desc:0x40000; desc:0x219C580 // $117
(W)     mov (1|M0)               r21.11<1>:f   r23.3<0;1,0>:f                                        //  ALU pipe: float; $86
(W)     mov (1|M0)               r21.12<1>:f   r23.4<0;1,0>:f                                        //  ALU pipe: float; $92
(W)     mov (1|M0)               r21.13<1>:f   r23.5<0;1,0>:f                                        //  ALU pipe: float; $98
(W)     mov (1|M0)               r21.14<1>:f   r23.6<0;1,0>:f                                        //  ALU pipe: float; $104
(W)     mov (1|M0)               r21.15<1>:f   r23.7<0;1,0>:f                                        //  ALU pipe: float; $110
(W)     mov (1|M0)               r22.0<1>:f    r25.0<0;1,0>:f                   {Compacted,$6.dst}   //  ALU pipe: float; $118
(W)     mov (1|M0)               r22.1<1>:f    r25.1<0;1,0>:f                                        //  ALU pipe: float; $124
(W)     mov (1|M0)               r22.2<1>:f    r25.2<0;1,0>:f                                        //  ALU pipe: float; $130
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r26:1 [r24:1+0x60]       {$7} // ex_desc:0x60000; desc:0x219C580 // $167
(W)     mov (1|M0)               r22.3<1>:f    r25.3<0;1,0>:f                                        //  ALU pipe: float; $136
(W)     mov (1|M0)               r22.4<1>:f    r25.4<0;1,0>:f                                        //  ALU pipe: float; $142
(W)     mov (1|M0)               r22.5<1>:f    r25.5<0;1,0>:f                                        //  ALU pipe: float; $148
(W)     mov (1|M0)               r22.6<1>:f    r25.6<0;1,0>:f                                        //  ALU pipe: float; $154
(W)     mov (1|M0)               r22.7<1>:f    r25.7<0;1,0>:f                                        //  ALU pipe: float; $160
(W)     mov (1|M0)               r22.8<1>:f    r26.0<0;1,0>:f                   {$7.dst}             //  ALU pipe: float; $168
(W)     mov (1|M0)               r22.9<1>:f    r26.1<0;1,0>:f                                        //  ALU pipe: float; $174
(W)     mov (2|M0)               r2.8<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $23
(W)     mov (1|M0)               r22.10<1>:f   r26.2<0;1,0>:f                                        //  ALU pipe: float; $180
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r2.8<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $216
(W)     mov (1|M0)               r22.11<1>:f   r26.3<0;1,0>:f                                        //  ALU pipe: float; $186
(W)     mov (1|M0)               r22.12<1>:f   r26.4<0;1,0>:f                                        //  ALU pipe: float; $192
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r2.9<0;1,0>:d     0:w                                 //  ALU pipe: int; $217
(W)     mov (1|M0)               r22.13<1>:f   r26.5<0;1,0>:f                                        //  ALU pipe: float; $198
(W)     mov (1|M0)               r22.14<1>:f   r26.6<0;1,0>:f                                        //  ALU pipe: float; $204
(W)     mov (1|M0)               r22.15<1>:f   r26.7<0;1,0>:f                                        //  ALU pipe: float; $210
(W&~f0.0) jmpi                               _0_043                                                  //  ALU pipe: int; $219
// B006: [inDivergent],  Preds:{B005},  Succs:{B024}
_0_044:
(W)     mov (8|M0)               r27.0<1>:f    r21.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $221
(W)     mov (8|M0)               r27.8<1>:ud   r21.8<1;1,0>:ud                                       //  ALU pipe: int; $222
(W)     mov (8|M0)               r28.0<1>:f    r22.0<1;1,0>:f                   {Compacted,F@7}      //  ALU pipe: float; $223
(W)     mov (8|M0)               r28.8<1>:ud   r22.8<1;1,0>:ud                  {F@3}                //  ALU pipe: int; $224
(W)     jmpi                                 _0_045                                                  // $225
// B007: [inDivergent],  Preds:{B005},  Succs:{B008}
_0_043:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r3.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $227
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.0<0;1,0>:d     2:w                                 //  ALU pipe: int; $228
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r3.0<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $229
(W)     mov (1|M0)               r8.3<1>:ud    f2.0<0;1,0>:ud                                        //  ALU pipe: int; $227
(W)     mov (1|M0)               r8.2<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $228
(W)     mov (1|M0)               r4.15<1>:ud   f0.0<0;1,0>:ud                                        //  ALU pipe: int; $229
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.0<0;1,0>:d     4:w                                 //  ALU pipe: int; $230
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.0<0;1,0>:d     1:w                                 //  ALU pipe: int; $231
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $232
(W)     mov (8|M0)               r29.0<1>:f    r21.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $233
(W)     mov (8|M0)               r29.8<1>:f    r21.8<1;1,0>:f                                        //  ALU pipe: float; $234
(W)     mov (8|M0)               r30.0<1>:f    r22.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $235
(W)     mov (8|M0)               r30.8<1>:f    r22.8<1;1,0>:f                                        //  ALU pipe: float; $236
(W)     mov (1|M0)               r2.5<1>:q     0:w                                                   //  ALU pipe: int; $237
(W)     mov (1|M0)               r2.12<1>:d    0:w                                                   //  ALU pipe: int; $238
// B008: [inDivergent],  Preds:{B023, B007},  Succs:{B009, B016}
_0_046:
(W)     mov (1|M0)               f3.0<1>:ud    r8.3<0;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $240
(W&f3.0) jmpi                                _0_047                                                  //  ALU pipe: int; $240
// B009: [inDivergent],  Preds:{B008},  Succs:{B010, B015}
_0_048:
(W)     mov (1|M0)               f3.0<1>:ud    r8.2<0;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $242
(W&f3.0) jmpi                                _0_049                                                  //  ALU pipe: int; $242
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B014}
_0_050:
(W)     mov (1|M0)               f3.0<1>:ud    r4.15<0;1,0>:ud                  {I@7}                //  ALU pipe: int; $244
(W&f3.0) jmpi                                _0_051                                                  //  ALU pipe: int; $244
// B011: [inDivergent],  Preds:{B010},  Succs:{B012, B013}
_0_052:
(W&f2.0) jmpi                                _0_053                                                  //  ALU pipe: int; $246
// B012: [inDivergent],  Preds:{B011},  Succs:{B021}
_0_054:
(W)     mov (1|M0)               r2.14<1>:f    0x0:f                                                 //  ALU pipe: float; $248
(W)     jmpi                                 _0_055                                                  // $249
// B013: [inDivergent],  Preds:{B011},  Succs:{B021}
_0_053:
(W)     shl (1|M0)               r3.1<1>:q     r2.5<0;1,0>:q     3:w               {I@7}             //  ALU pipe: int; $251
(W)     add (1|M0)               r32.0<1>:q    r3.1<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $252
(W)     load.ugm.d64x1t.a64 (1|M0)  r31:1       [r32:1]            {I@1,$8} // ex_desc:0x0; desc:0x2108780 // $254
(W)     mov (1|M0)               r2.14<2>:f    r31.0<0;1,0>:q                   {$8.dst}             //  ALU pipe: float; $255
(W)     jmpi                                 _0_055                                                  // $257
// B014: [inDivergent],  Preds:{B010},  Succs:{B021}
_0_051:
(W)     shl (1|M0)               r3.2<1>:q     r2.5<0;1,0>:q     2:w                                 //  ALU pipe: int; $259
(W)     add (1|M0)               r34.0<1>:q    r3.2<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $260
(W)     load.ugm.d32x1t.a64 (1|M0)  r35:1       [r34:1]            {I@1,$9} // ex_desc:0x0; desc:0x2108580 // $262
(W)     mov (1|M0)               r2.14<1>:f    r35.0<0;1,0>:ud                  {$9.dst}             //  ALU pipe: float; $263
(W)     jmpi                                 _0_055                                                  // $265
// B015: [inDivergent],  Preds:{B009},  Succs:{B021}
_0_049:
(W)     shl (1|M0)               r3.3<1>:q     r2.5<0;1,0>:q     2:w                                 //  ALU pipe: int; $267
(W)     add (1|M0)               r36.0<1>:q    r3.3<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $268
(W)     load.ugm.d32x1t.a64 (1|M0)  r37:1       [r36:1]            {I@1,$10} // ex_desc:0x0; desc:0x2108580 // $270
(W)     mov (1|M0)               r2.14<1>:f    r37.0<0;1,0>:d                   {$10.dst}            //  ALU pipe: float; $271
(W)     jmpi                                 _0_055                                                  // $273
// B016: [inDivergent],  Preds:{B008},  Succs:{B017, B020}
_0_047:
(W&~f1.0) jmpi                               _0_056                                                  //  ALU pipe: int; $275
// B017: [inDivergent],  Preds:{B016},  Succs:{B018, B019}
_0_057:
(W&f0.0) jmpi                                _0_058                                                  //  ALU pipe: int; $277
// B018: [inDivergent],  Preds:{B017},  Succs:{B021}
_0_059:
(W)     mov (1|M0)               r2.14<1>:f    0x0:f                                                 //  ALU pipe: float; $279
(W)     jmpi                                 _0_055                                                  // $280
// B019: [inDivergent],  Preds:{B017},  Succs:{B021}
_0_058:
(W)     shl (1|M0)               r3.4<1>:q     r2.5<0;1,0>:q     1:w                                 //  ALU pipe: int; $282
(W)     add (1|M0)               r38.0<1>:q    r3.4<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $283
(W)     load.ugm.d16u32.a64 (1|M0)  r39:1       [r38:2]            {I@1,$11} // ex_desc:0x0; desc:0x4100B80 // $285
        sync.nop                             null                             {Compacted,F@1}        // $286
(W)     shl (1|M0)               r2.14<1>:d    r39.0<0;1,0>:ud   16:w               {$11.dst}        //  ALU pipe: int; $286
(W)     jmpi                                 _0_055                                                  // $288
// B020: [inDivergent],  Preds:{B016},  Succs:{B021}
_0_056:
(W)     shl (1|M0)               r3.5<1>:q     r2.5<0;1,0>:q     2:w                                 //  ALU pipe: int; $290
(W)     add (1|M0)               r40.0<1>:q    r3.5<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $291
(W)     load.ugm.d32x1t.a64 (1|M0)  r33:1       [r40:1]            {I@1,$12} // ex_desc:0x0; desc:0x2108580 // $293
(W)     mov (1|M0)               r2.14<1>:f    r33.0<0;1,0>:f                   {$12.dst}            //  ALU pipe: float; $294
// B021: [inDivergent],  Preds:{B020, B019, B018, B015, B014, B013, B012},  Succs:{B022, B023}
_0_055:
(W)     cmp (32|M0)   (ne)f3.0   null<1>:f     r2.14<0;1,0>:f    0x0:f               {F@1}           //  ALU pipe: float; $296
(W)     mov (1|M0)               r4.7<1>:f     0x3F800000:f                                          //  ALU pipe: float; $297
(W)     add (1|M0)               r2.12<1>:d    r2.12<0;1,0>:d    1:w                                 //  ALU pipe: int; $303
(W&f3.0) sel (1|M0)              r2.13<1>:f    r4.7<0;1,0>:f     0x0:f               {F@1}           //  ALU pipe: float; $297
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r2.12<0;1,0>:ud   r2.8<0;1,0>:ud   {A@1}              //  ALU pipe: int; $304
(W)     mov (1|M0)               r4.20<1>:hf   0x0:hf                                                //  ALU pipe: float; $305
(W)     mov (1|M0)               r3.12<2>:d    r2.5<0;1,0>:q                                         //  ALU pipe: int; $298
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r4.20<0;1,0>:w    r2.9<0;1,0>:d    {F@1}              //  ALU pipe: int; $305
(W)     mov (1|M0)               r4.21<1>:hf   0x0:hf                                                //  ALU pipe: float; $307
(W)     mul (1|M0)               r2.30<1>:uw   r3.24<0;1,0>:uw   0x4:uw              {I@2}           //  ALU pipe: int; $300
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:ud    r4.21<0;1,0>:uw   r2.9<0;1,0>:ud   {F@1}              //  ALU pipe: int; $307
(W)     add (1|M0)               a0.0<1>:uw    r2.30<0;1,0>:uw   0x740:uw              {A@1}         //  ALU pipe: int; src1 is addr of V0133(r29.0:f); $301
(W)     mov (1|M0)               r[a0.0]<1>:f  r2.13<0;1,0>:f                                        //  ALU pipe: float; $302
(W)     mov (8|M0)               r41.0<1>:f    r29.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $309
(W)     mov (8|M0)               r41.8<1>:ud   r29.8<1;1,0>:ud                                       //  ALU pipe: int; $310
(W)     mov (8|M0)               r42.0<1>:f    r30.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $311
(W)     mov (8|M0)               r42.8<1>:ud   r30.8<1;1,0>:ud                                       //  ALU pipe: int; $312
(W&f3.0) jmpi                                _0_060                                                  //  ALU pipe: int; $313
// B022: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_061:
(W)     mov (8|M0)               r27.0<1>:f    r41.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $315
(W)     mov (8|M0)               r27.8<1>:ud   r41.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $316
(W)     mov (8|M0)               r28.0<1>:f    r42.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $317
(W)     mov (8|M0)               r28.8<1>:ud   r42.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $318
(W)     jmpi                                 _0_045                                                  // $319
// B023: [inDivergent],  Preds:{B021},  Succs:{B008}
_0_060:
(W)     mov (1|M0)               r2.5<1>:q     r2.12<0;1,0>:ud                                       //  ALU pipe: int; $321
(W)     jmpi                                 _0_046                                                  // $322
// B024: [inDivergent],  Preds:{B022, B006},  Succs:{B025, B026}
_0_045:
(W)     cmp (32|M0)   (gt)f0.0   null<1>:ud    r2.8<0;1,0>:ud    0x1:uw                              //  ALU pipe: int; $324
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r2.9<0;1,0>:d     0:w                                 //  ALU pipe: int; $325
(W&~f0.0) cmp (32|M0) (gt)f0.0   null<1>:ud    r2.9<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $327
(W&f0.0) jmpi                                _0_062                                                  //  ALU pipe: int; $329
// B025: [inDivergent],  Preds:{B024},  Succs:{B033}
_0_063:
(W)     mov (8|M0)               r43.0<1>:f    r27.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $331
(W)     mov (8|M0)               r43.8<1>:ud   r27.8<1;1,0>:ud                  {I@7}                //  ALU pipe: int; $332
(W)     mov (8|M0)               r44.0<1>:f    r28.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $333
(W)     mov (8|M0)               r44.8<1>:ud   r28.8<1;1,0>:ud                  {I@7}                //  ALU pipe: int; $334
(W)     jmpi                                 _0_064                                                  // $335
// B026: [inDivergent],  Preds:{B024},  Succs:{B027}
_0_062:
(W)     mov (8|M0)               r45.0<1>:f    r27.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $337
(W)     mov (8|M0)               r45.8<1>:ud   r27.8<1;1,0>:ud                                       //  ALU pipe: int; $338
(W)     mov (8|M0)               r46.0<1>:f    r28.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $339
(W)     mov (8|M0)               r46.8<1>:ud   r28.8<1;1,0>:ud                                       //  ALU pipe: int; $340
(W)     mov (1|M0)               r3.1<1>:d     1:w                               {Compacted}         //  ALU pipe: int; $341
// B027: [inDivergent],  Preds:{B032, B026},  Succs:{B028}
_0_065:
(W)     shl (1|M0)               r3.13<1>:d    r3.1<0;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $343
(W)     mov (8|M0)               r47.0<1>:f    r45.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $344
(W)     mov (8|M0)               r47.8<1>:f    r45.8<1;1,0>:f                                        //  ALU pipe: float; $345
(W)     mov (8|M0)               r48.0<1>:f    r46.0<1;1,0>:f                   {Compacted,F@3}      //  ALU pipe: float; $346
(W)     mov (8|M0)               r48.8<1>:ud   r46.8<1;1,0>:ud                                       //  ALU pipe: int; $347
(W)     mov (1|M0)               r3.14<1>:d    0:w                                                   //  ALU pipe: int; $348
// B028: [inDivergent],  Preds:{B029, B027},  Succs:{B029, B030}
_0_066:
(W)     add (1|M0)               r4.1<1>:d     r3.14<0;1,0>:d    r3.1<0;1,0>:d    {I@1}              //  ALU pipe: int; $353
(W)     mov (1|M0)               r4.22<1>:hf   0x0:hf                                                //  ALU pipe: float; $355
(W)     cmp (1|M0)    (lt)f0.0   null<1>:ud    r4.1<0;1,0>:ud    r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $354
(W)     mul (1|M0)               r3.30<1>:uw   r3.28<0;1,0>:uw   0x4:uw                              //  ALU pipe: int; $350
(W)     mul (1|M0)               r4.5<1>:uw    r3.28<0;1,0>:uw   0x4:uw                              //  ALU pipe: int; $365
(W)     add (1|M0)               r3.14<1>:d    r3.14<0;1,0>:d    r3.13<0;1,0>:d                      //  ALU pipe: int; $368
(W&f0.0) cmp (1|M0)   (eq)f0.0   null<1>:d     r4.22<0;1,0>:w    r2.9<0;1,0>:d    {F@1}              //  ALU pipe: int; $355
(W)     mov (1|M0)               r4.23<1>:hf   0x0:hf                                                //  ALU pipe: float; $357
(W)     mul (1|M0)               r4.4<1>:uw    r4.2<0;1,0>:uw    0x4:uw                              //  ALU pipe: int; $359
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r3.14<0;1,0>:ud   r2.8<0;1,0>:ud   {I@3}              //  ALU pipe: int; $369
(W&~f0.0) cmp (1|M0)  (lt)f0.0   null<1>:ud    r4.23<0;1,0>:uw   r2.9<0;1,0>:ud   {F@1}              //  ALU pipe: int; $357
(W)     add (1|M0)               a0.0<1>:uw    r4.4<0;1,0>:uw    0xBC0:uw              {I@3}         //  ALU pipe: int; src1 is addr of V0179(r47.0:f); $360
(W)     add (1|M0)               a0.1<1>:uw    r3.30<0;1,0>:uw   0xBC0:uw                            //  ALU pipe: int; src1 is addr of V0179(r47.0:f); $351
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r4.22<0;1,0>:w    r2.9<0;1,0>:d                       //  ALU pipe: int; $370
(W&f0.0) sel (1|M0)              r4.3<1>:f     r[a0.0]<0;1,0>:f  0x0:f                               //  ALU pipe: float; $362
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:ud    r4.23<0;1,0>:uw   r2.9<0;1,0>:ud                      //  ALU pipe: int; $372
(W)     add (1|M0)               r4.6<1>:f     r[a0.1]<0;1,0>:f  r4.3<0;1,0>:f    {F@1}              //  ALU pipe: float; $363
(W)     add (1|M0)               a0.0<1>:uw    r4.5<0;1,0>:uw    0xBC0:uw                            //  ALU pipe: int; src1 is addr of V0179(r47.0:f); $366
(W)     mov (1|M0)               r[a0.0]<1>:f  r4.6<0;1,0>:f                    {F@1}                //  ALU pipe: float; $367
(W)     mov (8|M0)               r49.0<1>:f    r47.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $374
(W)     mov (8|M0)               r49.8<1>:f    r47.8<1;1,0>:f                                        //  ALU pipe: float; $375
(W)     mov (8|M0)               r50.0<1>:f    r48.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $376
(W)     mov (8|M0)               r50.8<1>:f    r48.8<1;1,0>:f                                        //  ALU pipe: float; $377
(W&~f3.0) jmpi                               _0_067                                                  //  ALU pipe: int; $378
// B029: [inDivergent],  Preds:{B028},  Succs:{B028}
_0_068:
(W)     jmpi                                 _0_066                                                  // $380
// B030: [inDivergent],  Preds:{B028},  Succs:{B031, B032}
_0_067:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r3.13<0;1,0>:ud   r2.8<0;1,0>:ud                      //  ALU pipe: int; $382
(W)     mov (1|M0)               r4.28<1>:hf   0x0:hf                                                //  ALU pipe: float; $383
(W)     mov (1|M0)               r4.29<1>:hf   0x0:hf                                                //  ALU pipe: float; $385
(W&f1.0) cmp (32|M0)  (eq)f1.0   null<1>:d     r4.28<0;1,0>:w    r2.9<0;1,0>:d    {F@2}              //  ALU pipe: int; $383
(W&~f1.0) cmp (32|M0) (lt)f1.0   null<1>:ud    r4.29<0;1,0>:uw   r2.9<0;1,0>:ud   {F@1}              //  ALU pipe: int; $385
(W)     mov (8|M0)               r51.0<1>:f    r49.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $387
(W)     mov (8|M0)               r51.8<1>:ud   r49.8<1;1,0>:ud                                       //  ALU pipe: int; $388
(W)     mov (8|M0)               r52.0<1>:f    r50.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $389
(W)     mov (8|M0)               r52.8<1>:ud   r50.8<1;1,0>:ud                                       //  ALU pipe: int; $390
(W&f1.0) jmpi                                _0_069                                                  //  ALU pipe: int; $391
// B031: [inDivergent],  Preds:{B030},  Succs:{B033}
_0_070:
(W)     mov (8|M0)               r43.0<1>:f    r51.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $393
(W)     mov (8|M0)               r43.8<1>:ud   r51.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $394
(W)     mov (8|M0)               r44.0<1>:f    r52.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $395
(W)     mov (8|M0)               r44.8<1>:ud   r52.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $396
(W)     jmpi                                 _0_064                                                  // $397
// B032: [inDivergent],  Preds:{B030},  Succs:{B027}
_0_069:
(W)     mov (8|M0)               r45.0<1>:f    r49.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $399
(W)     mov (8|M0)               r45.8<1>:ud   r49.8<1;1,0>:ud                                       //  ALU pipe: int; $400
(W)     mov (8|M0)               r46.0<1>:f    r50.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $401
(W)     mov (8|M0)               r46.8<1>:ud   r50.8<1;1,0>:ud                                       //  ALU pipe: int; $402
(W)     mov (1|M0)               r3.1<1>:d     r3.13<0;1,0>:d                                        //  ALU pipe: int; $403
(W)     jmpi                                 _0_065                                                  // $404
// B033: [inDivergent],  Preds:{B031, B025},  Succs:{B034, B035}
_0_064:
(W)     cmp (32|M0)   (ne)f3.0   null<1>:f     r43.0<0;1,0>:f    0x0:f               {F@4}           //  ALU pipe: float; $406
(~f3.0) goto (32|M0)                         _0_039            _0_039                                //  ALU pipe: int; $407
// B034: [inDivergent],  Preds:{B033},  Succs:{B035}
_0_071:
        mov (16|M0)              r53.0<2>:f    r10.0<0;1,0>:f                                        //  ALU pipe: float; $409
        mov (16|M16)             r55.0<2>:f    r10.0<0;1,0>:f                                        //  ALU pipe: float; $409
        mov (32|M0)              r57.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $411
        mov (16|M0)              r53.1<2>:f    r10.1<0;1,0>:f                                        //  ALU pipe: float; $410
        mov (16|M16)             r55.1<2>:ud   r10.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $410
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r53:4]          r57:2              {A@1,$13} // ex_desc:0x0; desc:0x800058B // $412
// B035: Preds:{B034, B033, B004, B003, B002},  Succs:{}
_0_039:
        join (32|M0)                         L3352                                                   // 
L3352:
(W)     mov (16|M0)              r127.0<1>:f   r5.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $414
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$14} // wr:1+0, rd:0; end of thread // $414
L3376:
(W)     mov (16|M0)              null<1>:ud    0x240B22FC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x608F9E07:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x20:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 192
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 35
//.allAtOneDistNum: 7
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 13
//.AfterReadTokenDepCount: 1
