//.kernel _ZTSN4sycl3_V16detail19__pf_kernel_wrapperIN9p42extras8FlatNameILNS3_4KindE3ELi0EEEEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 23 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 23 -GRFBumpUpNumber 2 "
//.instCount 291
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 7
//.spill flag load 7

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r6.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.9)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.10)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.6)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.7)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.8)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r6.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r6.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r5.2)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r5.0)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.10)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r4.6)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.14)
//.declare V0061 (71)  rf=r size=4 type=d align=2 words (r4.15)
//.declare V0063 (73)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0064 (74)  rf=r size=8 type=d alias=V0044+0 align=4 words (r2.6)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0066 (76)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.3)
//.declare V0067 (77)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r6.0)
//.declare V0068 (78)  rf=r size=8 type=ud alias=V0065+0 align=4 words (r2.10)
//.declare V0069 (79)  rf=r size=8 type=d alias=V0065+0 align=4 words (r2.10)
//.declare V0070 (80)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0073 (83)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0076 (86)  rf=r size=12 type=ud alias=V0036+0 align=2 words (r2.0)
//.declare V0080 (90)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0081 (91)  rf=r size=128 type=d align=32 words (r9.0)
//.declare P01 (92)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0082 (93)  rf=r size=128 type=ud alias=V0080+0 align=32 words (r7.0)
//.declare V0083 (94)  rf=r size=8 type=ud alias=V0063+0 align=2 words (r2.8)
//.declare P02 (95)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P03 (96)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0084 (97)  rf=r size=128 type=ud alias=V0081+0 align=32 words (r9.0)
//.declare V0085 (98)  rf=r size=8 type=d align=2 words (r2.12)
//.declare V0086 (99)  rf=r size=8 type=d alias=V0046+0 align=4 words (r3.2)
//.declare V0087 (100)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r4.4)
//.declare V0088 (101)  rf=r size=8 type=uq alias=V0059+0 align=4 words (r4.6)
//.declare V0089 (102)  rf=r size=8 type=uq align=32 words (r12.0)
//.declare V0090 (103)  rf=r size=8 type=uq align=32 words (r14.0)
//.declare P04 (104)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P05 (105)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P06 (106)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P07 (107)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P08 (108)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0091 (109)  rf=r size=4 type=ud alias=V0047+0 align=2 words (r3.4)
//.declare P09 (110)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P10 (111)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0092 (112)  rf=r size=8 type=ud alias=V0085+0 align=2 words (r2.12)
//.declare P11 (113)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P12 (114)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0093 (115)  rf=r size=8 type=q alias=V0042+0 align=4 words (r5.0)
//.declare P13 (116)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P14 (117)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0094 (118)  rf=r size=8 type=q align=4 words (r2.7)
//.declare V0095 (119)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r5.2)
//.declare V0096 (120)  rf=r size=4 type=d align=32 words (r11.0)
//.declare P15 (121)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0097 (122)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0099 (124)  rf=r size=256 type=uq align=32 words (r17.0)
//.declare V0100 (125)  rf=r size=256 type=ud alias=V0099+0 align=32 words (r17.0)
//.declare V0101 (126)  rf=r size=8 type=ud alias=V0090+0 align=32 words (r14.0)
//.declare V0102 (127)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0103 (128)  rf=r size=128 type=ud align=32 words (r23.0)
//.declare P16 (130)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0106 (132)  rf=r size=32 type=d align=32 words (r13.0)
//.declare V0107 (133)  rf=r size=8 type=uq align=32 words (r25.0)
//.declare V0109 (135)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0111 (137)  rf=r size=128 type=f alias=V0109+0 align=32 words (r26.0)
//.declare V0112 (138)  rf=r size=32 type=f alias=V0106+0 align=32 words (r13.0)
//.declare V0119 (145)  rf=r size=32 type=d align=32 words (r28.0)
//.declare V0120 (146)  rf=r size=8 type=q align=32 words (r29.0)
//.declare V0121 (147)  rf=r size=32 type=f alias=V0119+0 align=32 words (r28.0)
//.declare V0130 (156)  rf=r size=32 type=d align=32 words (r30.0)
//.declare V0132 (158)  rf=r size=32 type=f alias=V0130+0 align=32 words (r30.0)
//.declare V0141 (167)  rf=r size=32 type=d align=32 words (r31.0)
//.declare V0143 (169)  rf=r size=32 type=f alias=V0141+0 align=32 words (r31.0)
//.declare V0152 (178)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0153 (179)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0154 (180)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0155 (181)  rf=r size=4 type=f align=4 words (r3.8)
//.declare V0156 (182)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0159 (185)  rf=r size=8 type=uq align=32 words (r34.0)
//.declare V0160 (186)  rf=r size=8 type=q align=32 words (r35.0)
//.declare V0161 (187)  rf=r size=4 type=f align=32 words (r36.0)
//.declare V0162 (188)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0165 (191)  rf=r size=8 type=uq align=32 words (r38.0)
//.declare V0166 (192)  rf=r size=4 type=d align=32 words (r37.0)
//.declare V0167 (193)  rf=r size=4 type=ud alias=V0166+0 align=32 words (r37.0)
//.declare V0168 (194)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0171 (197)  rf=r size=8 type=uq align=32 words (r40.0)
//.declare V0172 (198)  rf=r size=4 type=d align=32 words (r39.0)
//.declare V0173 (199)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0176 (202)  rf=r size=8 type=uq align=32 words (r42.0)
//.declare V0178 (204)  rf=r size=4 type=ud align=32 words (r41.0)
//.declare V0179 (205)  rf=r size=4 type=w alias=V0178+0 align=32 words (r41.0)
//.declare V0181 (207)  rf=r size=4 type=d alias=V0161+0 align=32 words (r36.0)
//.declare V0182 (208)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0185 (211)  rf=r size=8 type=uq align=32 words (r44.0)
//.declare P17 (212)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0187 (214)  rf=r size=4 type=d align=4 words (r4.6)
//.declare V0188 (215)  rf=r size=4 type=f align=2 words (r3.9)
//.declare V0189 (216)  rf=r size=4 type=uw alias=V0187+0 align=2 words (r4.12)
//.declare V0190 (217)  rf=r size=2 type=uw align=1 words (r4.2)
//.declare A00 (218)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare P18 (219)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0191 (220)  rf=r size=4 type=ud alias=V0154+0 align=2 words (r3.5)
//.declare P19 (221)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P20 (222)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0192 (223)  rf=r size=128 type=f align=32 words (r45.0)
//.declare V0193 (224)  rf=r size=128 type=f align=32 words (r47.0)
//.declare V0194 (225)  rf=r size=128 type=f align=32 words (r49.0)
//.declare V0195 (226)  rf=r size=128 type=f align=32 words (r51.0)
//.declare V0196 (227)  rf=r size=4 type=d align=2 words (r4.7)
//.declare V0197 (228)  rf=r size=4 type=d align=2 words (r4.10)
//.declare V0198 (229)  rf=r size=128 type=f align=32 words (r53.0)
//.declare V0199 (230)  rf=r size=4 type=d align=2 words (r4.11)
//.declare V0201 (232)  rf=r size=4 type=uw alias=V0199+0 align=2 words (r4.22)
//.declare V0202 (233)  rf=r size=2 type=uw align=1 words (r4.3)
//.declare A01 (234)  rf=a size=2 type=uw align=1 words (a0.1)
//.declare V0203 (235)  rf=r size=4 type=d align=2 words (r4.14)
//.declare P21 (236)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0204 (237)  rf=r size=4 type=ud alias=V0203+0 align=2 words (r4.14)
//.declare P22 (238)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare P23 (239)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0206 (241)  rf=r size=4 type=uw alias=V0203+0 align=2 words (r4.28)
//.declare V0207 (242)  rf=r size=2 type=uw align=1 words (r4.30)
//.declare A02 (243)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0208 (244)  rf=r size=4 type=f align=2 words (r5.5)
//.declare V0210 (246)  rf=r size=4 type=f align=2 words (r5.6)
//.declare V0211 (247)  rf=r size=2 type=uw align=1 words (r5.14)
//.declare A03 (248)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare P24 (249)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0212 (250)  rf=r size=4 type=ud alias=V0199+0 align=2 words (r4.11)
//.declare P25 (251)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P26 (252)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0213 (253)  rf=r size=128 type=f align=32 words (r55.0)
//.declare V0214 (254)  rf=r size=128 type=f align=32 words (r57.0)
//.declare P27 (255)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0215 (256)  rf=r size=4 type=ud alias=V0197+0 align=2 words (r4.10)
//.declare P28 (257)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P29 (258)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0216 (259)  rf=r size=128 type=f align=32 words (r59.0)
//.declare P30 (260)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0218 (262)  rf=r size=256 type=uq align=32 words (r61.0)
//.declare V0219 (263)  rf=r size=256 type=ud alias=V0218+0 align=32 words (r61.0)
//.declare V0220 (264)  rf=r size=128 type=d align=32 words (r65.0)
//.declare V0224 (268)  rf=r size=128 type=d align=32 words (r67.0)
//.declare V0225 (269)  rf=r size=128 type=d align=32 words (r69.0)
//.declare P31 (270)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0226 (271)  rf=r size=128 type=ud alias=V0224+0 align=32 words (r67.0)
//.declare P32 (272)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P33 (273)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0227 (274)  rf=r size=128 type=ud alias=V0225+0 align=32 words (r69.0)
//.declare  (278)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (279)  rf=r size=4 type=ud align=32 words (r43.0)
//.declare  (280)  rf=r size=128 type=uw align=32 words (r71.0)
//.declare  (281)  rf=r size=128 type=uw align=32 words (r73.0)
//.declare  (284)  rf=r size=4 type=f align=2 words (r5.8)
//.declare  (285)  rf=r size=2 type=w align=1 words (r5.15)
//.declare  (286)  rf=r size=2 type=uw align=1 words (r5.18)
//.declare  (287)  rf=r size=2 type=w align=1 words (r5.19)
//.declare  (288)  rf=r size=2 type=uw align=1 words (r5.20)
//.declare  (291)  rf=r size=2 type=w align=1 words (r5.21)
//.declare  (292)  rf=r size=2 type=uw align=1 words (r5.22)
//.declare  (295)  rf=r size=128 type=q align=32 words (r75.0)
//.declare  (296)  rf=r size=128 type=q align=32 words (r77.0)
//.declare  (297)  rf=r size=128 type=q align=32 words (r79.0)
//.declare  (298)  rf=r size=128 type=q align=32 words (r81.0)
//.declare  (301)  rf=r size=128 type=q align=32 words (r83.0)
//.declare  (302)  rf=r size=128 type=q align=32 words (r85.0)
//.declare  (305)  rf=r size=128 type=d align=32 words (r87.0)
//.declare  (306)  rf=r size=128 type=d align=32 words (r89.0)
//.declare  (307)  rf=r size=128 type=d alias=+0 align=32 words (r79.0)
//.declare  (308)  rf=r size=128 type=d alias=+0 align=32 words (r81.0)
//.declare  (309)  rf=r size=128 type=d alias=+0 align=32 words (r83.0)
//.declare  (310)  rf=r size=128 type=d alias=+0 align=32 words (r85.0)
//.declare  (311)  rf=r size=4 type=uw align=2 words (r5.24)
//.declare  (312)  rf=r size=4 type=uw align=2 words (r5.26)
//.declare  (313)  rf=r size=4 type=uw align=2 words (r5.28)
//.declare  (314)  rf=r size=4 type=uw align=2 words (r5.30)
//.declare  (315)  rf=r size=4 type=uw align=2 words (r11.2)
//.declare  (316)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (317)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (318)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (319)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (320)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (321)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (322)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (323)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (324)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (325)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (326)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (327)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare r0 (328)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (329)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (330)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (331)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (332)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (333)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (334)  rf=r size=32 type=ud align=2 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0045    | :q       |    0x8 | r3       | cti+0x20         |
// | V0046    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0049    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0050    | :d       |    0x4 | r3+0x28  | cti+0x48         |
// | V0051    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0052    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r4       | cti+0x60         |
// | V0054    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0055    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0056    | :d       |    0x4 | r4+0x18  | cti+0x78         |
// | V0057    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0058    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0059    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0060    | :d       |    0x4 | r4+0x38  | cti+0x98         |
// | V0061    | :d       |    0x4 | r4+0x3C  | cti+0x9C         |
// | V0042    | :uq      |    0x8 | r5       | cti+0xA0         |
// | V0037    | :d x 3   |    0xC | r5+0x8   | cti+0xA8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xA0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r5:1  bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B041}
// _main:
(W)     mov (16|M0)              r6.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r6.2<0;1,0>:uw   {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r43.0<1>:ud   r2.3<0;1,0>:ud    r6.1<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r6.2<0;1,0>:uw                      //  ALU pipe: int; $4
(W)     mach (1|M0)              r4.0<1>:d     r2.3<0;1,0>:ud    r6.1<0;1,0>:ud   {$1.dst}           //  ALU pipe: int; 
        mov (16|M0)              r71.0<4>:uw   r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r73.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.10<2>:ud   r43.0<0;1,0>:ud                  {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.11<2>:d    r4.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r2.8<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r75.0<1>:q    r2.5<0;1,0>:q     r71.0<4;1,0>:uw  {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r77.0<1>:q    r2.5<0;1,0>:q     r73.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r79.0<1>:q    r75.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r81.0<1>:q    r77.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r7.0<1>:d     r79.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r8.0<1>:d     r81.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r7.0<1;1,0>:ud    r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r9.0<1>:d     r79.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r10.0<1>:d    r81.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f1.0)  cmp (32|M0)   (eq)f1.0   null<1>:d     r9.0<1;1,0>:d     r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $18
(~f1.0) cmp (32|M0)   (lt)f1.0   null<1>:ud    r9.0<1;1,0>:ud    r2.9<0;1,0>:ud                      //  ALU pipe: int; $20
(~f1.0) goto (32|M0)                         _0_046            _0_046                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_047:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $31
(W)     mov (2|M0)               r2.12<1>:d    r3.2<1;1,0>:d                                         //  ALU pipe: int; $24
(W)     mov (1|M0)               r5.14<1>:ud   f0.0<0;1,0>:ud                   {$2.dst}             //  ALU pipe: int; $31
(W)     cmp (32|M0)   (gt)f0.0   null<1>:ud    r2.12<0;1,0>:ud   0x1:uw              {I@2}           //  ALU pipe: int; $34
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r3.4<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $32
(W)     mov (1|M0)               r11.1<1>:ud   f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $34
(W)     mov (1|M0)               r5.13<1>:ud   f3.0<0;1,0>:ud                                        //  ALU pipe: int; $32
(W)     mov (1|M0)               f3.0<1>:ud    r11.1<0;1,0>:ud                  {Compacted,I@2}      //  ALU pipe: int; $35
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $30
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r2.13<0;1,0>:d    0:w                                 //  ALU pipe: int; $35
(W)     mov (1|M0)               r5.15<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $30
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.4<0;1,0>:d     4:w                                 //  ALU pipe: int; $33
(W)     mov (1|M0)               r11.1<1>:ud   f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $35
(W)     mov (1|M0)               r5.12<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $33
(W)     mov (1|M0)               f1.0<1>:ud    r11.1<0;1,0>:ud                  {Compacted,I@2}      //  ALU pipe: int; $37
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r2.12<0;1,0>:d    0:w                                 //  ALU pipe: int; $27
(W&~f1.0) cmp (32|M0) (gt)f1.0   null<1>:ud    r2.13<0;1,0>:ud   0x0:uw                              //  ALU pipe: int; $37
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $39
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r2.13<0;1,0>:d    0:w                                 //  ALU pipe: int; $28
(W)     mov (1|M0)               r11.1<1>:ud   f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $37
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $40
(W)     mov (1|M0)               r12.0<1>:uq   r4.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $25
(W)     mov (1|M0)               r14.0<1>:uq   r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $26
(W)     mov (1|M0)               r2.7<1>:q     r5.2<0;1,0>:ud                                        //  ALU pipe: int; $41
// B004: [inDivergent],  Preds:{B040, B003},  Succs:{B005, B039}
_0_048:
(W)     load.ugm.d32x1t.a64 (1|M0)  r11:1       [r12:1]            {I@3,$3} // ex_desc:0x0; desc:0x2108580 // $43
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r11.0<0;1,0>:d    0:w               {$3.dst}          //  ALU pipe: int; $44
(W&f0.0) jmpi                                _0_049                                                  //  ALU pipe: int; $45
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B039}
_0_050:
        mov (16|M0)              r17.0<2>:f    r14.0<0;1,0>:f                   {I@4}                //  ALU pipe: float; $48
        mov (16|M16)             r19.0<2>:f    r14.0<0;1,0>:f                                        //  ALU pipe: float; $48
        mov (32|M0)              r21.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $50
        mov (16|M0)              r17.1<2>:f    r14.1<0;1,0>:f                                        //  ALU pipe: float; $49
        mov (16|M16)             r19.1<2>:f    r14.1<0;1,0>:f                                        //  ALU pipe: float; $49
        atomic_or.ugm.d32.a64 (32|M0)  r23:2    [r17:4]           r21:2              {A@1,$5} // ex_desc:0x0; desc:0x8200599 // $51
        mov (16|M0)              r15.0<1>:d    r79.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $47
        mov (16|M16)             r16.0<1>:d    r81.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $47
        or (32|M0)    (eq)f0.0   null<1>:d     r23.0<1;1,0>:d    r15.0<1;1,0>:d   {@1,$5.dst}        //  ALU pipe: int; $53
(~f0.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $55
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B024}
_0_051:
(W)     mov (1|M0)               r25.0<1>:uq   r5.0<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $57
(W)     mov (1|M0)               r29.0<1>:q    r5.0<0;1,0>:q                                         //  ALU pipe: int; $99
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r13:1 [r25:1]            {I@2,$6} // ex_desc:0x0; desc:0x219C580 // $58
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r28:1 [r29:1+0x20]       {I@1,$7} // ex_desc:0x20000; desc:0x219C580 // $100
(W)     mov (2|M0)               r26.0<1>:d    r13.0<1;1,0>:d                   {Compacted,$6.dst}   //  ALU pipe: int; $59
(W)     mov (1|M0)               r26.2<1>:ud   r13.2<0;1,0>:ud                                       //  ALU pipe: int; $63
(W)     mov (1|M0)               r26.3<1>:ud   r13.3<0;1,0>:ud                                       //  ALU pipe: int; $69
(W)     mov (1|M0)               r26.4<1>:ud   r13.4<0;1,0>:ud                                       //  ALU pipe: int; $75
(W)     mov (1|M0)               r26.5<1>:ud   r13.5<0;1,0>:ud                                       //  ALU pipe: int; $81
(W)     mov (1|M0)               r26.6<1>:f    r13.6<0;1,0>:f                                        //  ALU pipe: float; $87
(W)     mov (1|M0)               r26.7<1>:f    r13.7<0;1,0>:f                                        //  ALU pipe: float; $93
(W)     mov (1|M0)               r26.8<1>:f    r28.0<0;1,0>:f                   {$7.dst}             //  ALU pipe: float; $101
(W)     mov (1|M0)               r26.9<1>:f    r28.1<0;1,0>:f                                        //  ALU pipe: float; $107
(W)     mov (1|M0)               r26.10<1>:f   r28.2<0;1,0>:f                                        //  ALU pipe: float; $113
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r30:1 [r29:1+0x40]       {$8} // ex_desc:0x40000; desc:0x219C580 // $150
(W)     mov (1|M0)               r26.11<1>:f   r28.3<0;1,0>:f                                        //  ALU pipe: float; $119
(W)     mov (1|M0)               r26.12<1>:f   r28.4<0;1,0>:f                                        //  ALU pipe: float; $125
(W)     mov (1|M0)               r26.13<1>:f   r28.5<0;1,0>:f                                        //  ALU pipe: float; $131
(W)     mov (1|M0)               r26.14<1>:f   r28.6<0;1,0>:f                                        //  ALU pipe: float; $137
(W)     mov (1|M0)               r26.15<1>:f   r28.7<0;1,0>:f                                        //  ALU pipe: float; $143
(W)     mov (1|M0)               r27.0<1>:f    r30.0<0;1,0>:f                   {Compacted,$8.dst}   //  ALU pipe: float; $151
(W)     mov (1|M0)               r27.1<1>:f    r30.1<0;1,0>:f                                        //  ALU pipe: float; $157
(W)     mov (1|M0)               r27.2<1>:f    r30.2<0;1,0>:f                                        //  ALU pipe: float; $163
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r31:1 [r29:1+0x60]       {$9} // ex_desc:0x60000; desc:0x219C580 // $200
(W)     mov (1|M0)               r27.3<1>:f    r30.3<0;1,0>:f                                        //  ALU pipe: float; $169
(W)     mov (1|M0)               r27.4<1>:f    r30.4<0;1,0>:f                                        //  ALU pipe: float; $175
(W)     mov (1|M0)               r27.5<1>:f    r30.5<0;1,0>:f                                        //  ALU pipe: float; $181
(W)     mov (1|M0)               r27.6<1>:f    r30.6<0;1,0>:f                                        //  ALU pipe: float; $187
(W)     mov (1|M0)               r27.7<1>:f    r30.7<0;1,0>:f                                        //  ALU pipe: float; $193
(W)     mov (1|M0)               r27.8<1>:f    r31.0<0;1,0>:f                   {$9.dst}             //  ALU pipe: float; $201
(W)     mov (1|M0)               r27.9<1>:f    r31.1<0;1,0>:f                                        //  ALU pipe: float; $207
(W)     mov (1|M0)               r27.10<1>:f   r31.2<0;1,0>:f                                        //  ALU pipe: float; $213
(W)     mov (1|M0)               r27.11<1>:f   r31.3<0;1,0>:f                                        //  ALU pipe: float; $219
(W)     mov (1|M0)               r27.12<1>:f   r31.4<0;1,0>:f                                        //  ALU pipe: float; $225
(W)     mov (1|M0)               r27.13<1>:f   r31.5<0;1,0>:f                                        //  ALU pipe: float; $231
(W)     mov (1|M0)               r27.14<1>:f   r31.6<0;1,0>:f                                        //  ALU pipe: float; $237
(W)     mov (1|M0)               r27.15<1>:f   r31.7<0;1,0>:f                                        //  ALU pipe: float; $243
(W&f2.0) jmpi                                _0_052                                                  //  ALU pipe: int; $249
// B007: [inDivergent],  Preds:{B006},  Succs:{B008}
_0_053:
(W)     mov (8|M0)               r32.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@2}      //  ALU pipe: float; $251
(W)     mov (8|M0)               r32.8<1>:ud   r26.8<1;1,0>:ud                                       //  ALU pipe: int; $252
(W)     mov (8|M0)               r33.0<1>:f    r27.0<1;1,0>:f                   {Compacted,F@7}      //  ALU pipe: float; $253
(W)     mov (8|M0)               r33.8<1>:ud   r27.8<1;1,0>:ud                  {F@3}                //  ALU pipe: int; $254
(W)     mov (1|M0)               r3.3<1>:q     0:w                                                   //  ALU pipe: int; $255
(W)     mov (1|M0)               r3.5<1>:d     0:w                                                   //  ALU pipe: int; $256
// B008: [inDivergent],  Preds:{B023, B007},  Succs:{B009, B016}
_0_054:
(W)     mov (1|M0)               f0.0<1>:ud    r5.15<0;1,0>:ud                                       //  ALU pipe: int; $258
(W&f0.0) jmpi                                _0_055                                                  //  ALU pipe: int; $258
// B009: [inDivergent],  Preds:{B008},  Succs:{B010, B015}
_0_056:
(W)     mov (1|M0)               f0.0<1>:ud    r5.14<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $260
(W&f0.0) jmpi                                _0_057                                                  //  ALU pipe: int; $260
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B014}
_0_058:
(W)     mov (1|M0)               f0.0<1>:ud    r5.13<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $262
(W&f0.0) jmpi                                _0_059                                                  //  ALU pipe: int; $262
// B011: [inDivergent],  Preds:{B010},  Succs:{B012, B013}
_0_060:
(W)     mov (1|M0)               f0.0<1>:ud    r5.12<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $264
(W&f0.0) jmpi                                _0_061                                                  //  ALU pipe: int; $264
// B012: [inDivergent],  Preds:{B011},  Succs:{B021}
_0_062:
(W)     mov (1|M0)               r3.8<1>:f     0x0:f                                                 //  ALU pipe: float; $266
(W)     jmpi                                 _0_063                                                  // $267
// B013: [inDivergent],  Preds:{B011},  Succs:{B021}
_0_061:
(W)     shl (1|M0)               r3.5<1>:q     r3.3<0;1,0>:q     3:w               {I@7}             //  ALU pipe: int; $269
(W)     add (1|M0)               r34.0<1>:q    r3.5<0;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $270
(W)     load.ugm.d64x1t.a64 (1|M0)  r35:1       [r34:1]            {I@1,$10} // ex_desc:0x0; desc:0x2108780 // $272
(W)     mov (1|M0)               r3.8<2>:f     r35.0<0;1,0>:q                   {$10.dst}            //  ALU pipe: float; $273
(W)     jmpi                                 _0_063                                                  // $275
// B014: [inDivergent],  Preds:{B010},  Succs:{B021}
_0_059:
(W)     shl (1|M0)               r3.6<1>:q     r3.3<0;1,0>:q     2:w                                 //  ALU pipe: int; $277
(W)     add (1|M0)               r38.0<1>:q    r3.6<0;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $278
(W)     load.ugm.d32x1t.a64 (1|M0)  r37:1       [r38:1]            {I@1,$11} // ex_desc:0x0; desc:0x2108580 // $280
(W)     mov (1|M0)               r3.8<1>:f     r37.0<0;1,0>:ud                  {$11.dst}            //  ALU pipe: float; $281
(W)     jmpi                                 _0_063                                                  // $283
// B015: [inDivergent],  Preds:{B009},  Succs:{B021}
_0_057:
(W)     shl (1|M0)               r3.7<1>:q     r3.3<0;1,0>:q     2:w                                 //  ALU pipe: int; $285
(W)     add (1|M0)               r40.0<1>:q    r3.7<0;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $286
(W)     load.ugm.d32x1t.a64 (1|M0)  r39:1       [r40:1]            {I@1,$12} // ex_desc:0x0; desc:0x2108580 // $288
(W)     mov (1|M0)               r3.8<1>:f     r39.0<0;1,0>:d                   {$12.dst}            //  ALU pipe: float; $289
(W)     jmpi                                 _0_063                                                  // $291
// B016: [inDivergent],  Preds:{B008},  Succs:{B017, B020}
_0_055:
(W&~f3.0) jmpi                               _0_064                                                  //  ALU pipe: int; $293
// B017: [inDivergent],  Preds:{B016},  Succs:{B018, B019}
_0_065:
(W&f1.0) jmpi                                _0_066                                                  //  ALU pipe: int; $295
// B018: [inDivergent],  Preds:{B017},  Succs:{B021}
_0_067:
(W)     mov (1|M0)               r3.8<1>:f     0x0:f                                                 //  ALU pipe: float; $297
(W)     jmpi                                 _0_063                                                  // $298
// B019: [inDivergent],  Preds:{B017},  Succs:{B021}
_0_066:
(W)     shl (1|M0)               r4.1<1>:q     r3.3<0;1,0>:q     1:w                                 //  ALU pipe: int; $300
(W)     add (1|M0)               r42.0<1>:q    r4.1<0;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $301
(W)     load.ugm.d16u32.a64 (1|M0)  r41:1       [r42:2]            {I@1,$13} // ex_desc:0x0; desc:0x4100B80 // $303
        sync.nop                             null                             {Compacted,F@1}        // $304
(W)     shl (1|M0)               r3.8<1>:d     r41.0<0;1,0>:ud   16:w               {$13.dst}        //  ALU pipe: int; $304
(W)     jmpi                                 _0_063                                                  // $306
// B020: [inDivergent],  Preds:{B016},  Succs:{B021}
_0_064:
(W)     shl (1|M0)               r4.2<1>:q     r3.3<0;1,0>:q     2:w                                 //  ALU pipe: int; $308
(W)     add (1|M0)               r44.0<1>:q    r4.2<0;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $309
(W)     load.ugm.d32x1t.a64 (1|M0)  r36:1       [r44:1]            {I@1,$14} // ex_desc:0x0; desc:0x2108580 // $311
(W)     mov (1|M0)               r3.8<1>:f     r36.0<0;1,0>:f                   {$14.dst}            //  ALU pipe: float; $312
// B021: [inDivergent],  Preds:{B020, B019, B018, B015, B014, B013, B012},  Succs:{B022, B023}
_0_063:
(W)     cmp (32|M0)   (ne)f0.0   null<1>:f     r3.8<0;1,0>:f     0x0:f               {F@1}           //  ALU pipe: float; $314
(W)     mov (1|M0)               r5.8<1>:f     0x3F800000:f                                          //  ALU pipe: float; $315
(W)     add (1|M0)               r3.5<1>:d     r3.5<0;1,0>:d     1:w                                 //  ALU pipe: int; $321
(W&f0.0) sel (1|M0)              r3.9<1>:f     r5.8<0;1,0>:f     0x0:f               {F@1}           //  ALU pipe: float; $315
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r3.5<0;1,0>:ud    r2.12<0;1,0>:ud  {A@1}              //  ALU pipe: int; $322
(W)     mov (1|M0)               r5.15<1>:hf   0x0:hf                                                //  ALU pipe: float; $323
(W)     mov (1|M0)               r4.6<2>:d     r3.3<0;1,0>:q                                         //  ALU pipe: int; $316
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r5.15<0;1,0>:w    r2.13<0;1,0>:d   {F@1}              //  ALU pipe: int; $323
(W)     mov (1|M0)               r5.18<1>:hf   0x0:hf                                                //  ALU pipe: float; $325
(W)     mul (1|M0)               r4.2<1>:uw    r4.12<0;1,0>:uw   0x4:uw              {I@2}           //  ALU pipe: int; $318
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r5.18<0;1,0>:uw   r2.13<0;1,0>:ud  {F@1}              //  ALU pipe: int; $325
(W)     add (1|M0)               a0.0<1>:uw    r4.2<0;1,0>:uw    0x800:uw              {A@1}         //  ALU pipe: int; src1 is addr of V0152(r32.0:f); $319
(W)     mov (1|M0)               r[a0.0]<1>:f  r3.9<0;1,0>:f                                         //  ALU pipe: float; $320
(W)     mov (8|M0)               r45.0<1>:f    r32.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $327
(W)     mov (8|M0)               r45.8<1>:ud   r32.8<1;1,0>:ud                                       //  ALU pipe: int; $328
(W)     mov (8|M0)               r46.0<1>:f    r33.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $329
(W)     mov (8|M0)               r46.8<1>:ud   r33.8<1;1,0>:ud                                       //  ALU pipe: int; $330
(W&f0.0) jmpi                                _0_068                                                  //  ALU pipe: int; $331
// B022: [inDivergent],  Preds:{B021},  Succs:{B025}
_0_069:
(W)     mov (8|M0)               r47.0<1>:f    r45.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $333
(W)     mov (8|M0)               r47.8<1>:ud   r45.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $334
(W)     mov (8|M0)               r48.0<1>:f    r46.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $335
(W)     mov (8|M0)               r48.8<1>:ud   r46.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $336
(W)     jmpi                                 _0_070                                                  // $337
// B023: [inDivergent],  Preds:{B021},  Succs:{B008}
_0_068:
(W)     mov (1|M0)               r3.3<1>:q     r3.5<0;1,0>:ud                                        //  ALU pipe: int; $339
(W)     jmpi                                 _0_054                                                  // $340
// B024: [inDivergent],  Preds:{B006},  Succs:{B025}
_0_052:
(W)     mov (8|M0)               r47.0<1>:f    r26.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $342
(W)     mov (8|M0)               r47.8<1>:ud   r26.8<1;1,0>:ud                                       //  ALU pipe: int; $343
(W)     mov (8|M0)               r48.0<1>:f    r27.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $344
(W)     mov (8|M0)               r48.8<1>:ud   r27.8<1;1,0>:ud                                       //  ALU pipe: int; $345
// B025: [inDivergent],  Preds:{B024, B022},  Succs:{B026, B027}
_0_070:
(W)     mov (1|M0)               f0.0<1>:ud    r11.1<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $347
(W&f0.0) jmpi                                _0_071                                                  //  ALU pipe: int; $347
// B026: [inDivergent],  Preds:{B025},  Succs:{B037}
_0_072:
(W)     mov (8|M0)               r49.0<1>:f    r47.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $349
(W)     mov (8|M0)               r49.8<1>:ud   r47.8<1;1,0>:ud                  {I@4}                //  ALU pipe: int; $350
(W)     mov (8|M0)               r50.0<1>:f    r48.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $351
(W)     mov (8|M0)               r50.8<1>:ud   r48.8<1;1,0>:ud                  {I@4}                //  ALU pipe: int; $352
(W)     jmpi                                 _0_073                                                  // $353
// B027: [inDivergent],  Preds:{B025},  Succs:{B028}
_0_071:
(W)     mov (8|M0)               r51.0<1>:f    r47.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $355
(W)     mov (8|M0)               r51.8<1>:ud   r47.8<1;1,0>:ud                                       //  ALU pipe: int; $356
(W)     mov (8|M0)               r52.0<1>:f    r48.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $357
(W)     mov (8|M0)               r52.8<1>:ud   r48.8<1;1,0>:ud                                       //  ALU pipe: int; $358
(W)     mov (1|M0)               r4.7<1>:d     1:w                                                   //  ALU pipe: int; $359
// B028: [inDivergent],  Preds:{B036, B027},  Succs:{B029, B033}
_0_074:
(W)     shl (1|M0)               r4.10<1>:d    r4.7<0;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $361
(W&f2.0) jmpi                                _0_075                                                  //  ALU pipe: int; $362
// B029: [inDivergent],  Preds:{B028},  Succs:{B030}
_0_076:
(W)     mov (8|M0)               r53.0<1>:f    r51.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $364
(W)     mov (8|M0)               r53.8<1>:ud   r51.8<1;1,0>:ud                                       //  ALU pipe: int; $365
(W)     mov (8|M0)               r54.0<1>:f    r52.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $366
(W)     mov (8|M0)               r54.8<1>:ud   r52.8<1;1,0>:ud                                       //  ALU pipe: int; $367
(W)     mov (1|M0)               r4.11<1>:d    0:w                                                   //  ALU pipe: int; $368
// B030: [inDivergent],  Preds:{B032, B029},  Succs:{B031, B032}
_0_077:
(W)     add (1|M0)               r4.14<1>:d    r4.11<0;1,0>:d    r4.7<0;1,0>:d    {I@1}              //  ALU pipe: int; $373
(W)     mov (1|M0)               r5.19<1>:hf   0x0:hf                                                //  ALU pipe: float; $375
(W)     cmp (1|M0)    (lt)f0.0   null<1>:ud    r4.14<0;1,0>:ud   r2.12<0;1,0>:ud  {I@1}              //  ALU pipe: int; $374
(W)     mov (1|M0)               r5.20<1>:hf   0x0:hf                                                //  ALU pipe: float; $377
(W)     mul (1|M0)               r4.30<1>:uw   r4.28<0;1,0>:uw   0x4:uw                              //  ALU pipe: int; $379
(W)     mul (1|M0)               r4.3<1>:uw    r4.22<0;1,0>:uw   0x4:uw                              //  ALU pipe: int; $370
(W&f0.0) cmp (1|M0)   (eq)f0.0   null<1>:d     r5.19<0;1,0>:w    r2.13<0;1,0>:d   {F@2}              //  ALU pipe: int; $375
(W)     add (1|M0)               a0.0<1>:uw    r4.30<0;1,0>:uw   0xD40:uw              {I@3}         //  ALU pipe: int; src1 is addr of V0198(r53.0:f); $380
(W)     mul (1|M0)               r5.14<1>:uw   r4.22<0;1,0>:uw   0x4:uw                              //  ALU pipe: int; $385
(W)     add (1|M0)               r4.11<1>:d    r4.11<0;1,0>:d    r4.10<0;1,0>:d                      //  ALU pipe: int; $388
(W&~f0.0) cmp (1|M0)  (lt)f0.0   null<1>:ud    r5.20<0;1,0>:uw   r2.13<0;1,0>:ud  {F@1}              //  ALU pipe: int; $377
(W)     add (1|M0)               a0.1<1>:uw    r4.3<0;1,0>:uw    0xD40:uw              {I@6}         //  ALU pipe: int; src1 is addr of V0198(r53.0:f); $371
(W&f0.0) sel (1|M0)              r5.5<1>:f     r[a0.0]<0;1,0>:f  0x0:f                               //  ALU pipe: float; $382
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r4.11<0;1,0>:ud   r2.12<0;1,0>:ud  {A@1}              //  ALU pipe: int; $389
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r5.19<0;1,0>:w    r2.13<0;1,0>:d                      //  ALU pipe: int; $390
(W)     add (1|M0)               r5.6<1>:f     r[a0.1]<0;1,0>:f  r5.5<0;1,0>:f                       //  ALU pipe: float; $383
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r5.20<0;1,0>:uw   r2.13<0;1,0>:ud                     //  ALU pipe: int; $392
(W)     add (1|M0)               a0.0<1>:uw    r5.14<0;1,0>:uw   0xD40:uw                            //  ALU pipe: int; src1 is addr of V0198(r53.0:f); $386
(W)     mov (1|M0)               r[a0.0]<1>:f  r5.6<0;1,0>:f                    {F@1}                //  ALU pipe: float; $387
(W)     mov (8|M0)               r55.0<1>:f    r53.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $394
(W)     mov (8|M0)               r55.8<1>:f    r53.8<1;1,0>:f                                        //  ALU pipe: float; $395
(W)     mov (8|M0)               r56.0<1>:f    r54.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $396
(W)     mov (8|M0)               r56.8<1>:f    r54.8<1;1,0>:f                                        //  ALU pipe: float; $397
(W&f0.0) jmpi                                _0_078                                                  //  ALU pipe: int; $398
// B031: [inDivergent],  Preds:{B030},  Succs:{B034}
_0_079:
(W)     mov (8|M0)               r57.0<1>:f    r55.0<1;1,0>:f                   {Compacted,F@4}      //  ALU pipe: float; $400
(W)     mov (8|M0)               r57.8<1>:ud   r55.8<1;1,0>:ud                  {F@4}                //  ALU pipe: int; $401
(W)     mov (8|M0)               r58.0<1>:f    r56.0<1;1,0>:f                   {Compacted,F@3}      //  ALU pipe: float; $402
(W)     mov (8|M0)               r58.8<1>:ud   r56.8<1;1,0>:ud                  {F@3}                //  ALU pipe: int; $403
(W)     jmpi                                 _0_080                                                  // $404
// B032: [inDivergent],  Preds:{B030},  Succs:{B030}
_0_078:
(W)     jmpi                                 _0_077                                                  // $406
// B033: [inDivergent],  Preds:{B028},  Succs:{B034}
_0_075:
(W)     mov (8|M0)               r57.0<1>:f    r51.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $408
(W)     mov (8|M0)               r57.8<1>:ud   r51.8<1;1,0>:ud                                       //  ALU pipe: int; $409
(W)     mov (8|M0)               r58.0<1>:f    r52.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $410
(W)     mov (8|M0)               r58.8<1>:ud   r52.8<1;1,0>:ud                                       //  ALU pipe: int; $411
// B034: [inDivergent],  Preds:{B033, B031},  Succs:{B035, B036}
_0_080:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r4.10<0;1,0>:ud   r2.12<0;1,0>:ud                     //  ALU pipe: int; $413
(W)     mov (1|M0)               r5.21<1>:hf   0x0:hf                                                //  ALU pipe: float; $414
(W)     mov (1|M0)               r5.22<1>:hf   0x0:hf                                                //  ALU pipe: float; $416
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r5.21<0;1,0>:w    r2.13<0;1,0>:d   {F@2}              //  ALU pipe: int; $414
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r5.22<0;1,0>:uw   r2.13<0;1,0>:ud  {F@1}              //  ALU pipe: int; $416
(W)     mov (8|M0)               r59.0<1>:f    r57.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $418
(W)     mov (8|M0)               r59.8<1>:ud   r57.8<1;1,0>:ud                  {I@5}                //  ALU pipe: int; $419
(W)     mov (8|M0)               r60.0<1>:f    r58.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $420
(W)     mov (8|M0)               r60.8<1>:ud   r58.8<1;1,0>:ud                  {I@5}                //  ALU pipe: int; $421
(W&f0.0) jmpi                                _0_081                                                  //  ALU pipe: int; $422
// B035: [inDivergent],  Preds:{B034},  Succs:{B037}
_0_082:
(W)     mov (8|M0)               r49.0<1>:f    r59.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $424
(W)     mov (8|M0)               r49.8<1>:ud   r59.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $425
(W)     mov (8|M0)               r50.0<1>:f    r60.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $426
(W)     mov (8|M0)               r50.8<1>:ud   r60.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $427
(W)     jmpi                                 _0_073                                                  // $428
// B036: [inDivergent],  Preds:{B034},  Succs:{B028}
_0_081:
(W)     mov (8|M0)               r51.0<1>:f    r57.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $430
(W)     mov (8|M0)               r51.8<1>:ud   r57.8<1;1,0>:ud                                       //  ALU pipe: int; $431
(W)     mov (8|M0)               r52.0<1>:f    r58.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $432
(W)     mov (8|M0)               r52.8<1>:ud   r58.8<1;1,0>:ud                                       //  ALU pipe: int; $433
(W)     mov (1|M0)               r4.7<1>:d     r4.10<0;1,0>:d                                        //  ALU pipe: int; $434
(W)     jmpi                                 _0_074                                                  // $435
// B037: [inDivergent],  Preds:{B035, B026},  Succs:{B038, B039}
_0_073:
(W)     cmp (32|M0)   (ne)f0.0   null<1>:f     r49.0<0;1,0>:f    0x0:f               {A@4}           //  ALU pipe: float; $437
(~f0.0) goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $438
// B038: [inDivergent],  Preds:{B037},  Succs:{B039}
_0_083:
        mov (16|M0)              r61.0<2>:f    r14.0<0;1,0>:f                   {$4.src}             //  ALU pipe: float; $440
        mov (16|M16)             r63.0<2>:f    r14.0<0;1,0>:f                                        //  ALU pipe: float; $440
        mov (32|M0)              r65.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $442
        mov (16|M0)              r61.1<2>:f    r14.1<0;1,0>:f                                        //  ALU pipe: float; $441
        mov (16|M16)             r63.1<2>:ud   r14.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $441
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r61:4]          r65:2              {A@1,$4} // ex_desc:0x0; desc:0x800058B // $443
// B039: [inDivergent],  Preds:{B038, B037, B005, B004},  Succs:{B040, B041}
_0_049:
        join (32|M0)                         _0_046                                                  // 
L3824:
        add (16|M0)              r83.0<1>:q    r79.0<1;1,0>:q    r2.7<0;1,0>:q    {Compacted}        //  ALU pipe: int; $445
        add (16|M16)             r85.0<1>:q    r81.0<1;1,0>:q    r2.7<0;1,0>:q    {Compacted}        //  ALU pipe: int; $445
        mov (16|M0)              r67.0<1>:d    r83.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $446
        mov (16|M16)             r68.0<1>:d    r85.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $447
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r67.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $450
        mov (16|M0)              r69.0<1>:d    r83.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $448
        mov (16|M16)             r70.0<1>:d    r85.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $449
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r69.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $451
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r69.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $453
(~f0.0) goto (32|M0)                         _0_046            _0_046                                //  ALU pipe: int; $455
// B040: [inDivergent],  Preds:{B039},  Succs:{B004}
_0_084:
(f0.0)  sel (32|M0)              r87.0<1>:d    r67.0<1;1,0>:d    r7.0<1;1,0>:d                       //  ALU pipe: int; $457
(f0.0)  sel (32|M0)              r89.0<1>:d    r69.0<1;1,0>:d    r9.0<1;1,0>:d                       //  ALU pipe: int; $458
        mov (16|M0)              r79.0<2>:d    r87.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $461
        mov (16|M16)             r81.0<2>:d    r88.0<1;1,0>:d                                        //  ALU pipe: int; $462
        mov (16|M0)              r79.1<2>:d    r89.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $463
        mov (16|M16)             r81.1<2>:d    r90.0<1;1,0>:d                                        //  ALU pipe: int; $464
(W)     jmpi                                 _0_048                                                  // $465
// B041: Preds:{B039, B002},  Succs:{}
_0_046:
        join (32|M0)                         L4064                                                   // 
L4064:
(W)     mov (16|M0)              r127.0<1>:f   r6.0<1;1,0>:f                    {Compacted,$2.src}   //  ALU pipe: float; $467
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$15} // wr:1+0, rd:0; end of thread // $467
L4088:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x17:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 242
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 34
//.allAtOneDistNum: 8
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 14
//.AfterReadTokenDepCount: 3
