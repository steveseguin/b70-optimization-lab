//.kernel _ZTSN9p42extras6NgNameILi2ELi1ELi0ELi0ELi0EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 12 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 12 -GRFBumpUpNumber 2 "
//.instCount 393
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r48.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.6)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.2)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.4)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.5)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r48.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r48.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r5.7)
//.declare V0043 (53)  rf=r size=8 type=uq align=4 words (r6.0)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0070 (80)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0074 (84)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0076 (86)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0077 (87)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0078 (88)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0079 (89)  rf=r size=4 type=d align=2 words (r2.8)
//.declare P01 (90)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0080 (91)  rf=r size=2 type=w align=1 words (r4.2)
//.declare V0081 (92)  rf=r size=2 type=b align=1 words (r5.0)
//.declare V0082 (93)  rf=r size=4 type=d align=2 words (r6.2)
//.declare V0083 (94)  rf=r size=2 type=ub alias=V0081+0 align=1 words (r5.0)
//.declare V0084 (95)  rf=r size=4 type=d align=2 words (r32.4)
//.declare V0085 (96)  rf=r size=4 type=d align=2 words (r32.3)
//.declare V0086 (97)  rf=r size=4 type=d align=2 words (r7.0)
//.declare V0087 (98)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0088 (99)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0089 (100)  rf=r size=4 type=ud alias=V0087+0 align=2 words (r3.0)
//.declare V0090 (101)  rf=r size=4 type=ud alias=V0078+0 align=2 words (r4.0)
//.declare V0091 (102)  rf=r size=4 type=ud alias=V0085+0 align=2 words (r32.3)
//.declare V0092 (103)  rf=r size=4 type=d align=32 words (r8.0)
//.declare V0094 (105)  rf=r size=4 type=d align=32 words (r9.0)
//.declare P02 (106)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0095 (107)  rf=r size=128 type=ud alias=V0077+0 align=32 words (r28.0)
//.declare P03 (108)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P04 (109)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0096 (110)  rf=r size=4 type=ud alias=V0088+0 align=2 words (r3.4)
//.declare V0097 (111)  rf=r size=8 type=uq alias=V0070+0 align=32 words (r5.6)
//.declare V0098 (112)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0099 (113)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P05 (114)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0100 (115)  rf=r size=8 type=uq alias=V0067+0 align=32 words (r5.3)
//.declare V0101 (116)  rf=r size=8 type=uq align=32 words (r32.0)
//.declare V0103 (118)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0104 (119)  rf=r size=256 type=ud alias=V0103+0 align=32 words (r7.0)
//.declare V0105 (120)  rf=r size=8 type=ud alias=V0101+0 align=32 words (r32.0)
//.declare V0106 (121)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0107 (122)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare P06 (124)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0109 (125)  rf=r size=8 type=uq alias=V0069+0 align=32 words (r5.5)
//.declare V0110 (126)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0111 (127)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0112 (128)  rf=r size=4 type=d align=2 words (r2.8)
//.declare P07 (129)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P08 (130)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0113 (131)  rf=r size=64 type=w align=32 words (r30.0)
//.declare V0114 (132)  rf=r size=4 type=d align=2 words (r32.5)
//.declare V0115 (133)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare V0117 (135)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare V0119 (137)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare V0120 (138)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare V0121 (139)  rf=r size=4 type=ud alias=V0114+0 align=2 words (r32.5)
//.declare P09 (140)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0122 (141)  rf=r size=2 type=w align=1 words (r5.0)
//.declare V0123 (142)  rf=r size=2 type=b align=1 words (r6.8)
//.declare V0124 (143)  rf=r size=4 type=d align=2 words (r7.0)
//.declare V0125 (144)  rf=r size=2 type=ub alias=V0123+0 align=1 words (r6.8)
//.declare V0126 (145)  rf=r size=4 type=d align=2 words (r8.0)
//.declare V0127 (146)  rf=r size=4 type=d align=2 words (r32.2)
//.declare P10 (147)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0128 (148)  rf=r size=4 type=ud alias=V0084+0 align=2 words (r32.4)
//.declare V0129 (149)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0130 (150)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0131 (151)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0132 (152)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0133 (153)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0134 (154)  rf=r size=4 type=ud alias=V0132+0 align=2 words (r3.4)
//.declare V0135 (155)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0136 (156)  rf=r size=4 type=ud alias=V0135+0 align=2 words (r3.7)
//.declare V0137 (157)  rf=r size=4 type=d align=2 words (r4.1)
//.declare V0138 (158)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0139 (159)  rf=r size=4 type=f align=2 words (r4.2)
//.declare V0140 (160)  rf=r size=4 type=f align=2 words (r6.2)
//.declare V0141 (161)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0142 (162)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0143 (163)  rf=r size=128 type=ud alias=V0142+0 align=32 words (r12.0)
//.declare V0144 (164)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0145 (165)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0146 (166)  rf=r size=128 type=ud alias=V0145+0 align=32 words (r16.0)
//.declare V0147 (167)  rf=r size=4 type=f align=2 words (r2.8)
//.declare V0148 (168)  rf=r size=4 type=ud alias=V0137+0 align=2 words (r4.1)
//.declare V0149 (169)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0150 (170)  rf=r size=128 type=ud alias=V0144+0 align=32 words (r14.0)
//.declare V0151 (171)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0157 (177)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0158 (178)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0159 (179)  rf=r size=128 type=ud alias=V0158+0 align=32 words (r24.0)
//.declare V0160 (180)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0161 (181)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0162 (182)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0163 (183)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0164 (184)  rf=r size=128 type=ud alias=V0162+0 align=32 words (r12.0)
//.declare V0165 (185)  rf=r size=128 type=ud alias=V0163+0 align=32 words (r8.0)
//.declare  (186)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0166 (187)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0167 (188)  rf=r size=4 type=d align=32 words (r1.0)
//.declare V0168 (189)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0169 (190)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0170 (191)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0171 (192)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0172 (193)  rf=r size=64 type=uw alias=V0113+0 align=32 words (r30.0)
//.declare V0173 (194)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0174 (195)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0175 (196)  rf=r size=8 type=q alias=V0043+0 align=32 words (r6.0)
//.declare V0177 (198)  rf=r size=128 type=ud alias=V0174+0 align=32 words (r14.0)
//.declare V0178 (199)  rf=r size=256 type=q align=32 words (r42.0)
//.declare V0179 (200)  rf=r size=256 type=uq alias=V0178+0 align=32 words (r42.0)
//.declare P11 (201)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0180 (202)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0181 (203)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.3)
//.declare V0185 (207)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0187 (209)  rf=r size=4 type=ud alias=V0185+0 align=2 words (r3.0)
//.declare V0188 (210)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0189 (211)  rf=r size=256 type=q align=32 words (r7.0)
//.declare V0190 (212)  rf=r size=256 type=uq alias=V0189+0 align=32 words (r7.0)
//.declare V0191 (213)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0192 (214)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0193 (215)  rf=r size=256 type=uq alias=V0192+0 align=32 words (r14.0)
//.declare P12 (216)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P13 (217)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0194 (218)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0195 (219)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0196 (220)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0198 (222)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0199 (223)  rf=r size=256 type=q align=32 words (r62.0)
//.declare V0200 (224)  rf=r size=256 type=uq alias=V0199+0 align=32 words (r62.0)
//.declare V0201 (225)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0202 (226)  rf=r size=4 type=d align=2 words (r3.1)
//.declare P14 (227)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0203 (228)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0205 (230)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0206 (231)  rf=r size=256 type=q align=32 words (r7.0)
//.declare V0207 (232)  rf=r size=256 type=uq alias=V0206+0 align=32 words (r7.0)
//.declare V0208 (233)  rf=r size=128 type=f align=32 words (r8.0)
//.declare P15 (234)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P16 (235)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0209 (236)  rf=r size=128 type=f align=32 words (r124.0)
//.declare V0210 (237)  rf=r size=4 type=f align=2 words (r2.8)
//.declare  (239)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (240)  rf=r size=128 type=f align=32 words (r104.0)
//.declare  (241)  rf=r size=128 type=f align=32 words (r102.0)
//.declare  (242)  rf=r size=128 type=f align=32 words (r100.0)
//.declare  (243)  rf=r size=128 type=f align=32 words (r98.0)
//.declare  (244)  rf=r size=128 type=f align=32 words (r96.0)
//.declare  (245)  rf=r size=128 type=f align=32 words (r94.0)
//.declare  (246)  rf=r size=128 type=f align=32 words (r92.0)
//.declare  (247)  rf=r size=64 type=f align=32 words (r57.0)
//.declare  (248)  rf=r size=64 type=f align=32 words (r56.0)
//.declare V0212 (251)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0213 (252)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0214 (253)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0216 (255)  rf=r size=128 type=ud alias=V0214+0 align=32 words (r10.0)
//.declare V0217 (256)  rf=r size=256 type=q align=32 words (r58.0)
//.declare V0218 (257)  rf=r size=256 type=uq alias=V0217+0 align=32 words (r58.0)
//.declare V0219 (258)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (259)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (260)  rf=r size=128 type=f align=32 words (r90.0)
//.declare  (261)  rf=r size=128 type=f align=32 words (r88.0)
//.declare  (262)  rf=r size=128 type=f align=32 words (r86.0)
//.declare  (263)  rf=r size=128 type=f align=32 words (r84.0)
//.declare  (264)  rf=r size=128 type=f align=32 words (r82.0)
//.declare  (265)  rf=r size=64 type=f align=32 words (r31.0)
//.declare V0220 (268)  rf=r size=128 type=d alias=V0219+0 align=32 words (r8.0)
//.declare V0221 (269)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0222 (270)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0223 (271)  rf=r size=128 type=d align=32 words (r38.0)
//.declare P17 (272)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P18 (273)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0224 (274)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0225 (275)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0226 (276)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0227 (277)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0228 (278)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0229 (279)  rf=r size=4 type=f align=2 words (r2.9)
//.declare V0230 (280)  rf=r size=4 type=ud alias=V0226+0 align=2 words (r2.8)
//.declare V0231 (281)  rf=r size=4 type=d align=2 words (r2.10)
//.declare V0232 (282)  rf=r size=4 type=ud alias=V0231+0 align=2 words (r2.10)
//.declare V0233 (283)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0234 (284)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0235 (285)  rf=r size=128 type=ud alias=V0228+0 align=32 words (r12.0)
//.declare V0236 (286)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0237 (287)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0238 (288)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0239 (289)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0240 (290)  rf=r size=128 type=ud alias=V0239+0 align=32 words (r18.0)
//.declare V0241 (291)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0242 (292)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0243 (293)  rf=r size=128 type=ud alias=V0242+0 align=32 words (r10.0)
//.declare V0244 (294)  rf=r size=4 type=f align=2 words (r6.2)
//.declare V0245 (295)  rf=r size=4 type=ud alias=V0233+0 align=2 words (r3.0)
//.declare V0246 (296)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0247 (297)  rf=r size=128 type=ud alias=V0241+0 align=32 words (r20.0)
//.declare V0248 (298)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0254 (304)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0255 (305)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0256 (306)  rf=r size=128 type=ud alias=V0255+0 align=32 words (r28.0)
//.declare V0257 (307)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0258 (308)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0259 (309)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P19 (310)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0260 (311)  rf=r size=128 type=ud alias=V0259+0 align=32 words (r14.0)
//.declare V0261 (312)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0262 (313)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0263 (314)  rf=r size=128 type=f align=32 words (r52.0)
//.declare V0264 (315)  rf=r size=128 type=f alias=V0221+0 align=32 words (r40.0)
//.declare  (316)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (317)  rf=r size=128 type=f align=32 words (r80.0)
//.declare  (318)  rf=r size=128 type=f align=32 words (r78.0)
//.declare  (319)  rf=r size=128 type=f align=32 words (r76.0)
//.declare  (320)  rf=r size=128 type=f align=32 words (r74.0)
//.declare  (321)  rf=r size=128 type=f align=32 words (r72.0)
//.declare  (322)  rf=r size=128 type=f align=32 words (r70.0)
//.declare  (323)  rf=r size=128 type=f align=32 words (r68.0)
//.declare  (324)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0265 (327)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0266 (328)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0267 (329)  rf=r size=4 type=f align=2 words (r32.2)
//.declare V0268 (330)  rf=r size=4 type=ud alias=V0266+0 align=2 words (r2.8)
//.declare V0269 (331)  rf=r size=128 type=d align=32 words (r54.0)
//.declare P20 (332)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0270 (333)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0271 (334)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0276 (339)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0278 (341)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare V0279 (342)  rf=r size=128 type=w alias=V0278+0 align=32 words (r18.0)
//.declare V0281 (344)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0282 (345)  rf=r size=128 type=f align=32 words (r126.0)
//.declare V0283 (346)  rf=r size=128 type=f alias=V0281+0 align=32 words (r20.0)
//.declare V0284 (347)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0289 (352)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0290 (353)  rf=r size=128 type=f align=32 words (r116.0)
//.declare V0294 (357)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0296 (359)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0297 (360)  rf=r size=128 type=w alias=V0296+0 align=32 words (r16.0)
//.declare V0299 (362)  rf=r size=128 type=d alias=V0290+0 align=32 words (r116.0)
//.declare V0301 (364)  rf=r size=128 type=f align=32 words (r110.0)
//.declare V0302 (365)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0303 (366)  rf=r size=128 type=d alias=V0301+0 align=32 words (r110.0)
//.declare P21 (367)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0304 (368)  rf=r size=128 type=ud alias=V0302+0 align=32 words (r8.0)
//.declare V0305 (369)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0306 (370)  rf=r size=128 type=ud alias=V0301+0 align=32 words (r110.0)
//.declare V0307 (371)  rf=r size=128 type=ud alias=V0305+0 align=32 words (r8.0)
//.declare V0308 (372)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0309 (373)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0310 (374)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0311 (375)  rf=r size=128 type=ud alias=V0309+0 align=32 words (r12.0)
//.declare V0312 (376)  rf=r size=128 type=ud alias=V0310+0 align=32 words (r14.0)
//.declare V0313 (377)  rf=r size=64 type=w align=32 words (r122.0)
//.declare V0314 (378)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0315 (379)  rf=r size=128 type=ud alias=V0314+0 align=32 words (r8.0)
//.declare V0319 (383)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0320 (384)  rf=r size=64 type=uw alias=V0313+0 align=32 words (r122.0)
//.declare V0321 (385)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P22 (386)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P23 (387)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0323 (389)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0324 (390)  rf=r size=256 type=ud alias=V0323+0 align=32 words (r7.0)
//.declare V0325 (391)  rf=r size=128 type=d align=32 words (r12.0)
//.declare  (392)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (393)  rf=r size=128 type=w alias=V0314+0 align=32 words (r8.0)
//.declare  (394)  rf=r size=2 type=w align=1 words (r2.18)
//.declare  (395)  rf=r size=4 type=d align=2 words (r3.0)
//.declare  (396)  rf=r size=2 type=w align=1 words (r4.0)
//.declare  (397)  rf=r size=4 type=f align=2 words (r5.0)
//.declare  (398)  rf=r size=2 type=w align=1 words (r3.0)
//.declare  (399)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (400)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (401)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (402)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (403)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (404)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (405)  rf=r size=4 type=f align=2 words (r3.4)
//.declare  (406)  rf=r size=4 type=d align=2 words (r4.0)
//.declare  (408)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (409)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (410)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (411)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (412)  rf=r size=128 type=w alias=V0310+0 align=32 words (r14.0)
//.declare  (417)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (418)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (419)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (420)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (425)  rf=r size=128 type=q align=32 words (r120.0)
//.declare  (426)  rf=r size=128 type=q align=32 words (r118.0)
//.declare  (429)  rf=r size=128 type=q align=32 words (r114.0)
//.declare  (430)  rf=r size=128 type=q align=32 words (r112.0)
//.declare  (431)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (432)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (435)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (436)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (441)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (442)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (443)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (444)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (445)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (446)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (447)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (448)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (449)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (450)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (451)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (452)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (453)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (454)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (455)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (456)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (457)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (458)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (459)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (460)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (461)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (462)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (463)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (464)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (465)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (466)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (467)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (468)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (469)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (470)  rf=r size=64 type=d align=32 words (r31.0)
//.declare r0 (471)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (472)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (473)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (474)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (475)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (476)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (477)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (478)  rf=r size=32 type=ud align=2 words (r6.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0034    | :uq      |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :d       |    0x4 | r3       | cti+0x20         |
// | V0045    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0046    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0047    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0048    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0049    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0050    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0051    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0052    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0053    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0054    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0055    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0056    | :q       |    0x8 | r4       | cti+0x60         |
// | V0057    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0058    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0059    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0060    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0061    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0062    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0063    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0064    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0065    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0066    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0067    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0068    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0069    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0070    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// | V0042    | :uq      |    0x8 | r5+0x38  | cti+0xD8         |
// | V0043    | :uq      |    0x8 | r6       | cti+0xE0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xE0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r6:1  bti[255][r127:1+0xC0]  {$3} // ex_desc:0xFF0C0000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B048}
// _main:
(W)     mov (16|M0)              r48.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r31.0<1>:f    0x3F000000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r56.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r57.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     cmp (1|M0)    (lt)f2.0   null<1>:d     r3.2<0;1,0>:d     -3:w               {A@1,$1.dst}     //  ALU pipe: int; $7
(W)     mov (1|M0)               r2.18<1>:hf   0x6:hf                                                //  ALU pipe: float; $8
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r48.2<0;1,0>:uw  {I@3}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r3.0<1>:d     r2.3<0;1,0>:d     r48.1<0;1,0>:d   {Compacted}        //  ALU pipe: int; $4
(W&f2.0) sel (1|M0)              r4.2<1>:w     r2.18<0;1,0>:w    3:w               {F@1}             //  ALU pipe: int; $8
(W)     mul (1|M0)               acc0.0<1>:d   r3.3<0;1,0>:d     r3.2<0;1,0>:uw                      //  ALU pipe: int; $5
(W)     mov (1|M0)               r5.0<2>:b     r4.2<0;1,0>:w                    {@2,$2.dst}          //  ALU pipe: int; $9
(W)     macl (1|M0)              r4.0<1>:d     r3.3<0;1,0>:d     r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $6
(W)     mov (1|M0)               r6.2<1>:d     r5.0<0;1,0>:ub                   {@2,$3.dst}          //  ALU pipe: int; $10
        add3 (32|M0)             r28.0<1>:d    r3.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {$0.dst} //  ALU pipe: int; $4
(W)     add (1|M0)               r32.4<1>:d    r6.2<0;1,0>:d     r3.2<0;1,0>:d    {I@2}              //  ALU pipe: int; $11
(W)     asr (1|M0)               r2.8<1>:d     r4.0<0;1,0>:d     31:w                                //  ALU pipe: int; $6
(W)     asr (1|M0)               r32.3<1>:d    r32.4<0;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $12
(W)     asr (1|M0)               r7.0<1>:d     r32.3<0;1,0>:d    31:w               {Compacted,I@1}  //  ALU pipe: int; $13
(W)     mul (1|M0)               acc0.0<1>:ud  r4.0<0;1,0>:ud    r32.6<0;1,0>:uw                     //  ALU pipe: int; $14
(W)     macl (1|M0)              r3.0<1>:ud    r4.0<0;1,0>:ud    r32.3<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $15
(W)     mul (1|M0)               acc0.0<1>:ud  r4.0<0;1,0>:ud    r32.6<0;1,0>:uw                     //  ALU pipe: int; $15
(W)     mach (1|M0)              r8.0<1>:d     r4.0<0;1,0>:ud    r32.3<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r4.0<0;1,0>:ud    r7.0<0;1,0>:uw   {I@5}              //  ALU pipe: int; $16
(W)     macl (1|M0)              r9.0<1>:d     r4.0<0;1,0>:ud    r7.0<0;1,0>:d                       //  ALU pipe: int; $17
(W)     mul (1|M0)               acc0.0<1>:d   r32.3<0;1,0>:ud   r2.16<0;1,0>:uw                     //  ALU pipe: int; $18
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r3.0<0;1,0>:ud    r28.0<1;1,0>:ud  {I@6}              //  ALU pipe: int; $21
(W)     add (1|M0)               r8.0<1>:d     r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@3}    //  ALU pipe: int; $17
(W)     macl (1|M0)              r9.0<1>:d     r32.3<0;1,0>:ud   r2.8<0;1,0>:d                       //  ALU pipe: int; $20
(W)     add (1|M0)               r3.4<1>:d     r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $20
(f2.0)  cmp (32|M0)   (eq)f2.0   null<1>:d     r3.4<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $22
(~f2.0) cmp (32|M0)   (gt)f2.0   null<1>:ud    r3.4<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $24
(~f2.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $26
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B048}
_0_048:
(W)     mov (1|M0)               r4.0<1>:uq    r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $28
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$4} // ex_desc:0x0; desc:0x2108580 // $29
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$4.dst}          //  ALU pipe: int; $30
(f0.0)  goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $31
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B048}
_0_049:
(W)     mov (1|M0)               r32.0<1>:uq   r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $33
        mov (32|M0)              r12.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $36
        mov (16|M0)              r7.0<2>:f     r32.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $34
        mov (16|M16)             r9.0<2>:f     r32.0<0;1,0>:f                                        //  ALU pipe: float; $34
        mov (16|M0)              r7.1<2>:f     r32.1<0;1,0>:f                                        //  ALU pipe: float; $35
        mov (16|M16)             r9.1<2>:ud    r32.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $35
        atomic_or.ugm.d32.a64 (32|M0)  r14:2    [r7:4]            r12:2              {A@1,$5} // ex_desc:0x0; desc:0x8200599 // $37
        cmp (32|M0)   (eq)f3.0   null<1>:d     r14.0<1;1,0>:d    0:w               {$5.dst}          //  ALU pipe: int; $39
(~f3.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $40
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B046}
_0_050:
(W)     mov (1|M0)               r4.0<1>:uq    r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $42
(W)     add (1|M0)               r2.8<1>:d     r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $44
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$6} // ex_desc:0x0; desc:0x2108580 // $43
(W)     cmp (32|M0)   (gt)f3.0   null<1>:d     r3.0<0;1,0>:d     r2.8<0;1,0>:d    {$6.dst}           //  ALU pipe: int; $45
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $46
(W&f3.0) jmpi                                _0_051                                                  //  ALU pipe: int; $48
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_052:
(W)     mov (8|M0)               r30.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $50
(W)     and (1|M0)               r2.8<1>:ud    msg0.0<0;1,0>:ud  0xFF:uw                             //  ALU pipe: int; $53
(W)     add (8|M0)               r30.8<1>:w    r30.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $51
(W)     add (16|M0)              r30.16<1>:w   r30.0<1;1,0>:w    16:w               {I@1}            //  ALU pipe: int; $52
(W)     and (1|M0)               r2.9<1>:ud    sr0.0<0;1,0>:ud   0x7F:uw              {A@1}          //  ALU pipe: int; $54
(W)     cmp (1|M0)    (lt)f1.0   null<1>:d     r3.2<0;1,0>:d     -31:w               {A@1}           //  ALU pipe: int; $61
(W)     mov (1|M0)               r4.0<1>:hf    0x3E:hf                                               //  ALU pipe: float; $62
(W)     and (1|M0)               r2.10<1>:ud   r2.9<0;1,0>:ud    7:w               {I@2}             //  ALU pipe: int; $56
(W)     asr (1|M0)               r2.11<1>:ud   r2.9<0;1,0>:ud    1:w                                 //  ALU pipe: int; $57
(W&f1.0) sel (1|M0)              r5.0<1>:w     r4.0<0;1,0>:w     31:w               {F@1}            //  ALU pipe: int; $62
(W)     mov (1|M0)               r3.0<1>:d     -8:w                               {Compacted}        //  ALU pipe: int; $58
(W)     mov (1|M0)               r6.8<2>:b     r5.0<0;1,0>:w                    {I@2}                //  ALU pipe: int; $63
(W)     shl (1|M0)               r2.8<1>:ud    r2.8<0;1,0>:ud    0x6:uw                              //  ALU pipe: int; $55
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r32.4<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $67
(W)     bfn.(s0&s1|s2) (1|M0)    r2.9<1>:ud    r2.11<0;0>:ud     r3.0<0;0>:ud      r2.10<0>:ud      {I@4} //  ALU pipe: int; $58
(W)     mov (1|M0)               r7.0<1>:d     r6.8<0;1,0>:ub                   {I@4}                //  ALU pipe: int; $64
(W)     or (1|M0)                r2.8<1>:ud    r2.8<0;1,0>:ud    r2.9<0;1,0>:ud   {I@2}              //  ALU pipe: int; $59
(W)     add (1|M0)               r8.0<1>:d     r7.0<0;1,0>:d     r3.2<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $65
(W)     mov (1|M0)               r32.5<1>:ud   r2.8<0;1,0>:ud                   {I@2}                //  ALU pipe: int; $60
(W)     asr (1|M0)               r32.2<1>:d    r8.0<0;1,0>:d     5:w               {Compacted,I@2}   //  ALU pipe: int; $66
(W&~f2.0) jmpi                               _0_053                                                  //  ALU pipe: int; $68
// B007: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_054:
        mov (32|M0)              r34.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $70
(W)     jmpi                                 _0_055                                                  // $71
// B008: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_053:
(W)     asr (1|M0)               r3.0<1>:d     r32.4<0;1,0>:d    31:w               {Compacted}      //  ALU pipe: int; $73
(W)     add (1|M0)               r2.8<1>:d     r3.0<0;1,0>:d     r32.3<0;1,0>:d   {I@1}              //  ALU pipe: int; $74
(W)     xor (1|M0)               r3.4<1>:d     r2.8<0;1,0>:d     r3.0<0;1,0>:d    {I@1}              //  ALU pipe: int; $75
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $76
(W)     mov (1|M0)               r4.0<1>:f     r3.4<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $77
(W)     mov (1|M0)               r5.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $82
(W)     math.inv (1|M0)          r4.2<1>:f     r4.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $81
        mov (32|M0)              r8.0<1>:f     r28.0<1;1,0>:ud                                       //  ALU pipe: float; $80
(W)     mad (1|M0)               r6.2<1>:f     r4.2<0;0>:f       r5.0<0;0>:f       r4.2<0>:f        {A@1} //  ALU pipe: float; $82
        mov (32|M0)              r12.0<1>:ud   r8.0<1;1,0>:f                    {F@2}                //  ALU pipe: int; $84
        mul (32|M0)              r10.0<1>:f    r8.0<1;1,0>:f     r6.2<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $83
(W)     mov (1|M0)               r3.7<1>:ud    r4.0<0;1,0>:f                                         //  ALU pipe: int; $78
        add (32|M0)              r14.0<1>:d    r28.0<1;1,0>:d    -r12.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $85 R{} IR{}{E:6,E:6,},  R{} IR{}{O:14,O:6,},  {BC=1}
        mov (32|M0)              r16.0<1>:ud   r10.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $86
(W)     add (1|M0)               r4.1<1>:d     r3.4<0;1,0>:d     -r3.7<0;1,0>:d   {I@3}              //  ALU pipe: int; $79
        mov (32|M0)              r20.0<1>:f    r16.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $89
        mov (32|M0)              r18.0<1>:f    r14.0<1;1,0>:ud                                       //  ALU pipe: float; $88
(W)     mov (1|M0)               r2.8<1>:f     r4.1<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $87
        mad (32|M0)              acc0.0<1>:f   r8.0<1;0>:f       r20.0<1;0>:f      -r4.0<0>:f       {F@3} //  ALU pipe: float; $91 R{} IR{}{E:4,E:2,E:2,},  R{r4,} IR{}{O:4,O:10,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r18.0<1;0>:f      r20.0<1;0>:f      -r2.8<0>:f       {F@2} //  ALU pipe: float; $93 R{} IR{}{E:1,E:2,E:1,},  R{r2,} IR{}{O:9,O:10,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $94
        mul (32|M0)              r22.0<1>:f    r6.2<0;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $95
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $96
        mov (32|M0)              r24.0<1>:ud   r22.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $97
        add (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    r16.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $98
(W)     mul (16|M0)              acc0.0<1>:d   r26.0<1;1,0>:d    r3.8<0;1,0>:uw   {I@1}              //  ALU pipe: int; $99
        macl (16|M0)             r10.0<1>:d    r26.0<1;1,0>:d    r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $99
(W)     mul (16|M16)             acc0.0<1>:d   r27.0<1;1,0>:d    r3.8<0;1,0>:uw                      //  ALU pipe: int; $99
        macl (16|M16)            r11.0<1>:d    r27.0<1;1,0>:d    r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $100
        add (32|M0)              r12.0<1>:d    r28.0<1;1,0>:d    -r10.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $100
        cmp (32|M0)   (ge)f3.0   r8.0<1>:ud    r12.0<1;1,0>:ud   r3.4<0;1,0>:ud   {I@1}              //  ALU pipe: int; $101
        add3 (32|M0)             r14.0<1>:d    r26.0<1;0>:d      r3.0<0;0>:d       -r8.0<1>:d       {I@1} //  ALU pipe: int; $102
        xor (32|M0)              r34.0<1>:d    r14.0<1;1,0>:d    r3.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $103
// B009: [inDivergent],  Preds:{B008, B007},  Succs:{B010, B012}
_0_055:
(W)     mul (1|M0)               acc0.0<1>:d   r32.5<0;1,0>:d    0x80:uw                             //  ALU pipe: int; $105
        mov (32|M0)              r46.0<1>:d    r30.0<1;1,0>:uw                                       //  ALU pipe: int; $109
(W)     macl (1|M0)              r1.0<1>:d     r32.5<0;1,0>:d    65664:d                             //  ALU pipe: int; $106
(W)     mul (16|M0)              acc0.0<1>:d   r34.0<1;1,0>:d    r32.6<0;1,0>:uw  {I@4}              //  ALU pipe: int; $106
        shl (32|M0)              r12.0<1>:d    r46.0<1;1,0>:d    11:w               {Compacted,I@3}  //  ALU pipe: int; $110
        macl (16|M0)             r8.0<1>:d     r34.0<1;1,0>:d    r32.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $106
(W)     mul (16|M16)             acc0.0<1>:d   r35.0<1;1,0>:d    r32.6<0;1,0>:uw                     //  ALU pipe: int; $106
(W)     mov (1|M0)               r3.0<1>:hf    0x80:hf                                               //  ALU pipe: float; $111
        macl (16|M16)            r9.0<1>:d     r35.0<1;1,0>:d    r32.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $107
        add3 (32|M0)             r14.0<1>:d    r1.0<0;0>:d       r3.0<0;0>:w       r12.0<1>:d       {A@1} //  ALU pipe: int; $111
        add (32|M0)              r10.0<1>:d    r28.0<1;1,0>:d    -r8.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $107
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $114
        mov (16|M0)              r16.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted,I@3}      //  ALU pipe: int; $113
        mov (16|M16)             r18.0<2>:ud   r15.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $113
        shl (32|M0)              r36.0<1>:d    r10.0<1;1,0>:d    2:w               {Compacted,I@4}   //  ALU pipe: int; $108
        add (16|M0)              r42.0<1>:q    r6.0<0;1,0>:q     r16.0<2;1,0>:ud  {I@3}              //  ALU pipe: int; $113
        add (16|M16)             r44.0<1>:q    r6.0<0;1,0>:q     r18.0<2;1,0>:ud  {I@3}              //  ALU pipe: int; $113
(W&~f1.0) jmpi                               _0_056                                                  //  ALU pipe: int; $115
// B010: [inDivergent],  Preds:{B009},  Succs:{B011}
_0_057:
(W)     mul (16|M0)              acc0.0<1>:d   r34.0<1;1,0>:d    r32.4<0;1,0>:uw                     //  ALU pipe: int; $117
        macl (16|M0)             r8.0<1>:d     r34.0<1;1,0>:d    r32.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $117
(W)     mul (16|M16)             acc0.0<1>:d   r35.0<1;1,0>:d    r32.4<0;1,0>:uw                     //  ALU pipe: int; $117
        macl (16|M16)            r9.0<1>:d     r35.0<1;1,0>:d    r32.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $119
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@3}      //  ALU pipe: int; $119
        mov (16|M16)             r14.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $119
        shl (16|M0)              r12.0<1>:q    r10.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $119
        shl (16|M16)             r16.0<1>:q    r14.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $119
        add (16|M0)              r20.0<1>:q    r12.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $120
        add (16|M16)             r18.0<1>:q    r16.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $120
(W)     mov (1|M0)               r3.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $121
// B011: [inDivergent],  Preds:{B011, B010},  Succs:{B012, B011}
_0_058:
(W)     shl (1|M0)               r2.4<1>:q     r3.0<0;1,0>:ud    2:w               {I@1}             //  ALU pipe: int; $124
(W)     add (1|M0)               r3.0<1>:d     r3.0<0;1,0>:d     1:w               {Compacted}       //  ALU pipe: int; $129
        add (16|M0)              r7.0<1>:q     r20.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $125
        add (16|M16)             r9.0<1>:q     r18.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $125
        load.ugm.d32.a64 (32|M0)  r12:2         [r7:4]             {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $126
        add (16|M0)              r14.0<1>:q    r42.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,$7.src} //  ALU pipe: int; $127
        add (16|M16)             r16.0<1>:q    r44.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $127
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.0<0;1,0>:d     r32.2<0;1,0>:d                      //  ALU pipe: int; $130
        sync.nop                             null                             {Compacted,$8.dst}     // $128
        store.ugm.d32.a64.wb.wb (32|M0)  [r14:4] r12:2             {I@2,$7} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $128
(W&f0.0) jmpi                                _0_058                                                  //  ALU pipe: int; $131
// B012: [inDivergent],  Preds:{B011, B009},  Succs:{B013, B021}
_0_056:
(W)     cmp (32|M0)   (gt)f0.0   null<1>:d     r3.2<0;1,0>:d     32:w                                //  ALU pipe: int; $133
(W&~f0.0) jmpi                               _0_059                                                  //  ALU pipe: int; $134
// B013: [inDivergent],  Preds:{B012},  Succs:{B014}
_0_060:
(W)     mov (1|M0)               r3.6<1>:d     1:w                                                   //  ALU pipe: int; $136
// B014: [inDivergent],  Preds:{B020, B013},  Succs:{B015}
_0_061:
(W)     shl (1|M0)               r3.4<1>:d     r3.6<0;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $138
(W)     mov (1|M0)               r3.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $139
// B015: [inDivergent],  Preds:{B018, B014},  Succs:{B016, B017}
_0_062:
(W)     shl (1|M0)               r2.4<1>:q     r3.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $142
(W)     add (1|M0)               r3.1<1>:d     r3.0<0;1,0>:d     r3.6<0;1,0>:d    {Compacted}        //  ALU pipe: int; $145
        add (16|M0)              r62.0<1>:q    r42.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,@2,$9.src} //  ALU pipe: int; $143
        add (16|M16)             r64.0<1>:q    r44.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $143
        load.ugm.d32.a64.ca.ca (32|M0)  r108:2  [r62:4]            {I@1,$10} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $144
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r3.1<0;1,0>:d     r32.2<0;1,0>:d                      //  ALU pipe: int; $146
(W&f2.0) jmpi                                _0_063                                                  //  ALU pipe: int; $147
// B016: [inDivergent],  Preds:{B015},  Succs:{B018}
_0_064:
        mov (32|M0)              r106.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $149
(W)     jmpi                                 _0_065                                                  // $150
// B017: [inDivergent],  Preds:{B015},  Succs:{B018}
_0_063:
(W)     shl (1|M0)               r2.4<1>:q     r3.1<0;1,0>:d     2:w                                 //  ALU pipe: int; $153
        add (16|M0)              r7.0<1>:q     r42.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $154
        add (16|M16)             r9.0<1>:q     r44.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $154
        load.ugm.d32.a64.ca.ca (32|M0)  r106:2  [r7:4]             {I@1,$11} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $155
// B018: [inDivergent],  Preds:{B017, B016},  Succs:{B019, B015}
_0_065:
        sync.nop                             null                             {Compacted,$11.dst}    // $157
        add (32|M0)              r8.0<1>:f     r108.0<1;1,0>:f   r106.0<1;1,0>:f  {Compacted,$10.dst} //  ALU pipe: float; $157
(W)     add (1|M0)               r3.0<1>:d     r3.0<0;1,0>:d     r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $159
        store.ugm.d32.a64.wb.wb (32|M0)  [r62:4] r8:2              {F@1,$9} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $158
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.0<0;1,0>:d     r32.2<0;1,0>:d   {I@1}              //  ALU pipe: int; $160
(W&f1.0) jmpi                                _0_062                                                  //  ALU pipe: int; $161
// B019: [inDivergent],  Preds:{B018},  Succs:{B020, B021}
_0_066:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.4<0;1,0>:d     r32.2<0;1,0>:d                      //  ALU pipe: int; $163
(W&~f3.0) jmpi                               _0_059                                                  //  ALU pipe: int; $164
// B020: [inDivergent],  Preds:{B019},  Succs:{B014}
_0_067:
(W)     mov (1|M0)               r3.6<1>:d     r3.4<0;1,0>:d                                         //  ALU pipe: int; $166
(W)     jmpi                                 _0_061                                                  // $167
// B021: [inDivergent],  Preds:{B019, B012},  Succs:{B022, B023}
_0_059:
        load.ugm.d32.a64.ca.ca (32|M0)  r124:2  [r42:4]            {$12} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $169
(W)     mov (1|M0)               r2.8<1>:f     r3.2<0;1,0>:d                                         //  ALU pipe: float; $170
(W)     mov (1|M0)               f1.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $171
        mov (32|M0)              r102.0<1>:f   r2.8<0;1,0>:f                    {Compacted,F@1}      //  ALU pipe: float; $171
        math.invm (16|M0) (eo)f1.0  r98.mme0:f  r124.nomme<1;1,0>:f  r102.nomme<1;1,0>:f {A@1,$12.dst} //  ALU pipe: math; $171
(f1.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $171
// B022: [inDivergent],  Preds:{B021},  Succs:{B023}
_L_k0_6_:
        madm (16|M0)             r96.mme1:f    r57.nomme:f       r124.nomme:f      r98.mme0:f       {M@1} //  ALU pipe: float; $171
        madm (16|M0)             r94.mme2:f    r56.nomme:f       -r102.nomme:f     r98.mme0:f        //  ALU pipe: float; $171
        madm (16|M0)             r104.mme3:f   r98.mme0:f        r94.mme2:f        r98.mme0:f       {F@1} //  ALU pipe: float; $171
        madm (16|M0)             r92.mme4:f    r124.nomme:f      -r102.nomme:f     r96.mme1:f        //  ALU pipe: float; $171 R{} IR{}{E:6,E:3,E:0,},  {BC=1}
        madm (16|M0)             r96.mme5:f    r96.mme1:f        r92.mme4:f        r104.mme3:f      {F@1} //  ALU pipe: float; $171 R{} IR{}{E:0,E:6,E:4,},  {BC=1}
        madm (16|M0)             r100.mme6:f   r124.nomme:f      -r102.nomme:f     r96.mme5:f       {F@1} //  ALU pipe: float; $171 R{} IR{}{E:6,E:3,E:0,},  {BC=1}
        madm (16|M0)             r98.nomme:f   r96.mme5:f        r100.mme6:f       r104.mme3:f      {F@1} //  ALU pipe: float; $171 R{} IR{}{E:0,E:2,E:4,},  {BC=1}
// B023: [inDivergent],  Preds:{B022, B021},  Succs:{B024, B025}
_L_k0_0_macro:
        join (32|M0)                         _0_047                                                  // 
L2768:
(W)     mov (1|M0)               f1.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $171
        math.invm (16|M16) (eo)f1.0  r99.mme0:f  r125.nomme<1;1,0>:f  r103.nomme<1;1,0>:f {I@1}      //  ALU pipe: math; $171
(f1.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $171
// B024: [inDivergent],  Preds:{B023},  Succs:{B025}
_L_k0_7_:
        madm (16|M16)            r97.mme1:f    r57.nomme:f       r125.nomme:f      r99.mme0:f       {M@1} //  ALU pipe: float; $171 R{} IR{}{O:4,O:6,O:1,},  {BC=1}
        madm (16|M16)            r95.mme2:f    r56.nomme:f       -r103.nomme:f     r99.mme0:f        //  ALU pipe: float; $171
        madm (16|M16)            r105.mme3:f   r99.mme0:f        r95.mme2:f        r99.mme0:f       {F@1} //  ALU pipe: float; $171
        madm (16|M16)            r93.mme4:f    r125.nomme:f      -r103.nomme:f     r97.mme1:f        //  ALU pipe: float; $171 R{} IR{}{O:6,O:3,O:0,},  {BC=1}
        madm (16|M16)            r97.mme5:f    r97.mme1:f        r93.mme4:f        r105.mme3:f      {F@1} //  ALU pipe: float; $171 R{} IR{}{O:0,O:6,O:4,},  {BC=1}
        madm (16|M16)            r101.mme6:f   r125.nomme:f      -r103.nomme:f     r97.mme5:f       {F@1} //  ALU pipe: float; $171 R{} IR{}{O:6,O:3,O:0,},  {BC=1}
        madm (16|M16)            r99.nomme:f   r97.mme5:f        r101.mme6:f       r105.mme3:f      {F@1} //  ALU pipe: float; $171 R{} IR{}{O:0,O:2,O:4,},  {BC=1}
// B025: [inDivergent],  Preds:{B024, B023},  Succs:{B026, B027}
_L_k0_1_macro:
        join (32|M0)                         _0_047                                                  // 
L2944:
        shl (32|M0)              r8.0<1>:d     r46.0<1;1,0>:d    2:w               {Compacted,$9.src} //  ALU pipe: int; $173
        add (32|M0)              r10.0<1>:d    r1.0<0;1,0>:d     r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $174
        add (32|M0)              r4.0<1>:f     r98.0<1;1,0>:f    0x358637BD:f               {F@1}    //  ALU pipe: float; $172
        mov (16|M0)              r12.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted,@1,$7.src} //  ALU pipe: int; $176
        mov (16|M16)             r14.0<2>:ud   r11.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $176
(W)     mov (1|M0)               f0.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $177
        add (16|M0)              r58.0<1>:q    r6.0<0;1,0>:q     r12.0<2;1,0>:ud  {I@3}              //  ALU pipe: int; $176
        add (16|M16)             r60.0<1>:q    r6.0<0;1,0>:q     r14.0<2;1,0>:ud  {I@3}              //  ALU pipe: int; $176
        math.rsqtm (16|M0) (eo)f0.0  r88.mme0:f  r4.nomme<1;1,0>:f              {A@1}                //  ALU pipe: math; $177
(f0.0)  goto (32|M0)                         _L_k0_2_macro     _L_k0_2_macro                         //  ALU pipe: int; $177
// B026: [inDivergent],  Preds:{B025},  Succs:{B027}
_L_k0_8_:
        madm (16|M0)             r86.mme1:f    r57.nomme:f       r31.nomme:f       r88.mme0:f       {M@1} //  ALU pipe: float; $177
        madm (16|M0)             r82.mme2:f    r57.nomme:f       r4.nomme:f        r88.mme0:f        //  ALU pipe: float; $177
        madm (16|M0)             r84.mme3:f    r31.nomme:f       -r82.mme2:f       r86.mme1:f       {F@1} //  ALU pipe: float; $177
        madm (16|M0)             r86.mme4:f    r86.mme1:f        r84.mme3:f        r86.mme1:f       {F@1} //  ALU pipe: float; $177
        madm (16|M0)             r88.mme5:f    r82.mme2:f        r84.mme3:f        r82.mme2:f        //  ALU pipe: float; $177
        madm (16|M0)             r84.mme6:f    r4.nomme:f        -r88.mme5:f       r88.mme5:f       {F@1} //  ALU pipe: float; $177
        madm (16|M0)             r88.nomme:f   r88.mme5:f        r86.mme4:f        r84.mme6:f       {F@1} //  ALU pipe: float; $177 R{} IR{}{E:4,E:3,E:2,},  {BC=1}
// B027: [inDivergent],  Preds:{B026, B025},  Succs:{B028, B029}
_L_k0_2_macro:
        join (32|M0)                         _0_047                                                  // 
L3200:
(W)     mov (1|M0)               f0.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $177
        math.rsqtm (16|M16) (eo)f0.0  r89.mme0:f  r5.nomme<1;1,0>:f             {I@1}                //  ALU pipe: math; $177
(f0.0)  goto (32|M0)                         _L_k0_3_macro     _L_k0_3_macro                         //  ALU pipe: int; $177
// B028: [inDivergent],  Preds:{B027},  Succs:{B029}
_L_k0_9_:
        madm (16|M16)            r87.mme1:f    r57.nomme:f       r31.nomme:f       r89.mme0:f       {M@1} //  ALU pipe: float; $177 R{} IR{}{O:4,O:7,O:4,},  {BC=1}
        madm (16|M16)            r83.mme2:f    r57.nomme:f       r5.nomme:f        r89.mme0:f        //  ALU pipe: float; $177
        madm (16|M16)            r85.mme3:f    r31.nomme:f       -r83.mme2:f       r87.mme1:f       {F@1} //  ALU pipe: float; $177 R{} IR{}{O:7,O:1,O:3,},  {BC=1}
        madm (16|M16)            r87.mme4:f    r87.mme1:f        r85.mme3:f        r87.mme1:f       {F@1} //  ALU pipe: float; $177
        madm (16|M16)            r89.mme5:f    r83.mme2:f        r85.mme3:f        r83.mme2:f        //  ALU pipe: float; $177
        madm (16|M16)            r85.mme6:f    r5.nomme:f        -r89.mme5:f       r89.mme5:f       {F@1} //  ALU pipe: float; $177
        madm (16|M16)            r89.nomme:f   r89.mme5:f        r87.mme4:f        r85.mme6:f       {F@1} //  ALU pipe: float; $177 R{} IR{}{O:4,O:3,O:2,},  {BC=1}
// B029: [inDivergent],  Preds:{B028, B027},  Succs:{B030, B048}
_L_k0_3_macro:
        join (32|M0)                         _0_047                                                  // 
L3376:
        mov (32|M0)              r8.0<1>:f     r88.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $177
        store.ugm.d32.a64.wb.wb (32|M0)  [r58:4] r8:2              {F@1,$13} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $178
        add (32|M0)              r10.0<1>:d    r36.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $180
        sel (32|M0)   (lt)f0.0   r38.0<1>:d    r10.0<1;1,0>:d    r3.2<0;1,0>:d    {I@1}              //  ALU pipe: int; $181
        cmp (32|M0)   (lt)f3.0   null<1>:d     r36.0<1;1,0>:d    r38.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $182
        load.ugm.d32.a64.ca.ca (32|M0)  r40:2   [r58:4]            {$14} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $179
(~f3.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $183
// B030: [inDivergent],  Preds:{B029},  Succs:{B031, B032}
_0_068:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.3<0;1,0>:d     0:w                                 //  ALU pipe: int; $185
(W&~f2.0) jmpi                               _0_069                                                  //  ALU pipe: int; $186
// B031: [inDivergent],  Preds:{B030},  Succs:{B033}
_0_070:
        mov (32|M0)              r8.0<1>:d     -1:w                               {Compacted,$13.src} //  ALU pipe: int; $188
(W)     jmpi                                 _0_071                                                  // $189
// B032: [inDivergent],  Preds:{B030},  Succs:{B033}
_0_069:
        asr (32|M0)              r8.0<1>:d     r34.0<1;1,0>:d    31:w               {Compacted,$13.src} //  ALU pipe: int; $191
        add (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     r34.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $193
        xor (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $194
(W)     mov (1|M0)               r2.8<1>:d     (abs)r3.3<0;1,0>:d                                    //  ALU pipe: int; $192
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $195
(W)     mov (1|M0)               r2.9<1>:f     r2.8<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $196
(W)     mov (1|M0)               r3.4<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $201
(W)     math.inv (1|M0)          r4.0<1>:f     r2.9<0;1,0>:f                    {F@2}                //  ALU pipe: math; $200
        mov (32|M0)              r14.0<1>:f    r12.0<1;1,0>:ud                                       //  ALU pipe: float; $199
(W)     mad (1|M0)               r5.0<1>:f     r4.0<0;0>:f       r3.4<0;0>:f       r4.0<0>:f        {A@1} //  ALU pipe: float; $201
        mov (32|M0)              r18.0<1>:ud   r14.0<1;1,0>:f                   {F@2}                //  ALU pipe: int; $203
        mul (32|M0)              r16.0<1>:f    r14.0<1;1,0>:f    r5.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $202
(W)     mov (1|M0)               r2.10<1>:ud   r2.9<0;1,0>:f                                         //  ALU pipe: int; $197
        add (32|M0)              r20.0<1>:d    r12.0<1;1,0>:d    -r18.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $204
        mov (32|M0)              r10.0<1>:ud   r16.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $205
(W)     add (1|M0)               r3.0<1>:d     (abs)r3.3<0;1,0>:d  -r2.10<0;1,0>:d {I@3}             //  ALU pipe: int; $198
        mov (32|M0)              r24.0<1>:f    r10.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $208
        mov (32|M0)              r22.0<1>:f    r20.0<1;1,0>:ud                                       //  ALU pipe: float; $207
(W)     mov (1|M0)               r6.2<1>:f     r3.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $206
        mad (32|M0)              acc0.0<1>:f   r14.0<1;0>:f      r24.0<1;0>:f      -r2.9<0>:f       {F@3} //  ALU pipe: float; $210 R{} IR{}{E:7,E:4,E:1,},  R{r2,} IR{}{O:7,O:12,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r22.0<1;0>:f      r24.0<1;0>:f      -r6.2<0>:f       {F@2} //  ALU pipe: float; $212 R{} IR{}{E:3,E:4,E:3,},  R{r6,} IR{}{O:11,O:12,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $213
        mul (32|M0)              r26.0<1>:f    r5.0<0;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $214
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $215
        mov (32|M0)              r28.0<1>:ud   r26.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $216
        add (32|M0)              r30.0<1>:d    r28.0<1;1,0>:d    r10.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $217
(W)     mov (1|M0)               r4.0<1>:d     (abs)r3.3<0;1,0>:d                                    //  ALU pipe: int; $218
(W)     mul (16|M0)              acc0.0<1>:d   r30.0<1;1,0>:d    r4.0<0;1,0>:uw   {I@1}              //  ALU pipe: int; $218
        macl (16|M0)             r16.0<1>:d    r30.0<1;1,0>:d    r4.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $218
(W)     mul (16|M16)             acc0.0<1>:d   r31.0<1;1,0>:d    r4.0<0;1,0>:uw                      //  ALU pipe: int; $218
        macl (16|M16)            r17.0<1>:d    r31.0<1;1,0>:d    r4.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $219
        add (32|M0)              r14.0<1>:d    r12.0<1;1,0>:d    -r16.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $219
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r14.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $220
(~f1.0) sel (32|M0)              r18.0<1>:d    (abs)r3.3<0;1,0>:d  0:w                               //  ALU pipe: int; $221
        add3 (32|M0)             r20.0<1>:d    r14.0<1;0>:d      r8.0<1;0>:d       -r18.0<1>:d      {Compacted,I@1} //  ALU pipe: int; $222 R{} IR{}{E:7,E:4,E:1,},  R{} IR{}{O:7,O:4,O:9,},  {BC=2}
        xor (32|M0)              r8.0<1>:d     r20.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $223
// B033: [inDivergent],  Preds:{B032, B031},  Succs:{B034, B035}
_0_071:
(W)     mov (32|M0)              r66.0<1>:f    0x3F800000:f                                          //  ALU pipe: float; $225
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $225
        math.invm (16|M0) (eo)f3.0  r74.mme0:f  r66.nomme<1;1,0>:f  r40.nomme<1;1,0>:f {A@1,$14.dst} //  ALU pipe: math; $225
(f3.0)  goto (32|M0)                         _L_k0_4_macro     _L_k0_4_macro                         //  ALU pipe: int; $225
// B034: [inDivergent],  Preds:{B033},  Succs:{B035}
_L_k0_10_:
        madm (16|M0)             r72.mme1:f    r57.nomme:f       r66.nomme:f       r74.mme0:f       {M@1} //  ALU pipe: float; $225
        madm (16|M0)             r70.mme2:f    r56.nomme:f       -r40.nomme:f      r74.mme0:f        //  ALU pipe: float; $225 R{r74,} IR{}{E:4,E:4,},  {BC=1}
        madm (16|M0)             r80.mme3:f    r74.mme0:f        r70.mme2:f        r74.mme0:f       {F@1} //  ALU pipe: float; $225
        madm (16|M0)             r68.mme4:f    r66.nomme:f       -r40.nomme:f      r72.mme1:f        //  ALU pipe: float; $225 R{} IR{}{E:1,E:4,E:4,},  {BC=1}
        madm (16|M0)             r72.mme5:f    r72.mme1:f        r68.mme4:f        r80.mme3:f       {F@1} //  ALU pipe: float; $225 R{} IR{}{E:4,E:2,E:0,},  {BC=1}
        madm (16|M0)             r76.mme6:f    r66.nomme:f       -r40.nomme:f      r72.mme5:f       {F@1} //  ALU pipe: float; $225 R{} IR{}{E:1,E:4,E:4,},  {BC=1}
        madm (16|M0)             r74.nomme:f   r72.mme5:f        r76.mme6:f        r80.mme3:f       {F@1} //  ALU pipe: float; $225 R{} IR{}{E:4,E:6,E:0,},  {BC=1}
// B035: [inDivergent],  Preds:{B034, B033},  Succs:{B036, B037}
_L_k0_4_macro:
        join (32|M0)                         _0_047                                                  // 
L4184:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $225
        math.invm (16|M16) (eo)f3.0  r75.mme0:f  r67.nomme<1;1,0>:f  r41.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $225
(f3.0)  goto (32|M0)                         _L_k0_5_macro     _L_k0_5_macro                         //  ALU pipe: int; $225
// B036: [inDivergent],  Preds:{B035},  Succs:{B037}
_L_k0_11_:
        madm (16|M16)            r73.mme1:f    r57.nomme:f       r67.nomme:f       r75.mme0:f       {M@1} //  ALU pipe: float; $225 R{} IR{}{O:4,O:1,O:5,},  {BC=1}
        madm (16|M16)            r71.mme2:f    r56.nomme:f       -r41.nomme:f      r75.mme0:f        //  ALU pipe: float; $225
        madm (16|M16)            r81.mme3:f    r75.mme0:f        r71.mme2:f        r75.mme0:f       {F@1} //  ALU pipe: float; $225
        madm (16|M16)            r69.mme4:f    r67.nomme:f       -r41.nomme:f      r73.mme1:f        //  ALU pipe: float; $225 R{} IR{}{O:1,O:4,O:4,},  {BC=1}
        madm (16|M16)            r73.mme5:f    r73.mme1:f        r69.mme4:f        r81.mme3:f       {F@1} //  ALU pipe: float; $225 R{} IR{}{O:4,O:2,O:0,},  {BC=1}
        madm (16|M16)            r77.mme6:f    r67.nomme:f       -r41.nomme:f      r73.mme5:f       {F@1} //  ALU pipe: float; $225 R{} IR{}{O:1,O:4,O:4,},  {BC=1}
        madm (16|M16)            r75.nomme:f   r73.mme5:f        r77.mme6:f        r81.mme3:f       {F@1} //  ALU pipe: float; $225 R{} IR{}{O:4,O:6,O:0,},  {BC=1}
// B037: [inDivergent],  Preds:{B036, B035},  Succs:{B038}
_L_k0_5_macro:
        join (32|M0)                         _0_047                                                  // 
L4360:
(W)     mul (16|M0)              acc0.0<1>:d   r34.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $226
(W)     and (1|M0)               r3.0<1>:d     r3.5<0;1,0>:d     8:w                                 //  ALU pipe: int; $230
        macl (16|M0)             r50.0<1>:d    r34.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $226
(W)     mul (16|M16)             acc0.0<1>:d   r35.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $226
        mov (32|M0)              r52.0<1>:f    r74.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $225
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.0<0;1,0>:d     0:w               {I@3}             //  ALU pipe: int; $231
        macl (16|M16)            r51.0<1>:d    r35.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $227 R{} IR{}{O:1,O:1,},  {BC=1}
(W)     mul (16|M0)              acc0.0<1>:d   r8.0<1;1,0>:d     r3.4<0;1,0>:uw                      //  ALU pipe: int; $229
(W)     and (1|M0)               r2.8<1>:d     r3.5<0;1,0>:d     1:w                                 //  ALU pipe: int; $227
        macl (16|M0)             r54.0<1>:d    r8.0<1;1,0>:d     r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $229
(W)     mul (16|M16)             acc0.0<1>:d   r9.0<1;1,0>:d     r3.4<0;1,0>:uw                      //  ALU pipe: int; $229
        macl (16|M16)            r55.0<1>:d    r9.0<1;1,0>:d     r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $230
(W)     mov (1|M0)               r32.2<1>:f    r2.8<0;1,0>:ud                   {I@4}                //  ALU pipe: float; $228
// B038: [inDivergent],  Preds:{B044, B037},  Succs:{B039, B040}
_0_072:
        add (32|M0)              r8.0<1>:d     r50.0<1;1,0>:d    r36.0<1;1,0>:d   {Compacted,$15.src} //  ALU pipe: int; $233
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $235
        mov (16|M16)             r12.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $235
        shl (16|M0)              r120.0<1>:q   r10.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $235
        shl (16|M16)             r118.0<1>:q   r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $235
        add (16|M0)              r14.0<1>:q    r120.0<1;1,0>:q   r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $236
        add (16|M16)             r16.0<1>:q    r118.0<1;1,0>:q   r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $236
        load.ugm.d16u32.a64 (32|M0)  r18:2      [r14:4]            {I@1,$0} // ex_desc:0x0; desc:0x8200B80 // $238
        add (32|M0)              r22.0<1>:d    r54.0<1;1,0>:d    r36.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $241
        mov (16|M0)              r24.0<2>:ud   r22.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $242
        mov (16|M16)             r26.0<2>:ud   r23.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $242
        mov (16|M0)              r114.0<1>:q   r24.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $242
        mov (16|M16)             r112.0<1>:q   r26.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $242
        shl (32|M0)              r20.0<1>:d    r18.0<1;1,0>:ud   16:w               {$0.dst}         //  ALU pipe: int; $239
        mul (32|M0)              r126.0<1>:f   r52.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,A@1}    //  ALU pipe: float; $240 R{} IR{}{E:2,E:2,},  R{} IR{}{O:10,O:10,},  {BC=2}
(W&f0.0) jmpi                                _0_073                                                  //  ALU pipe: int; $243
// B039: [inDivergent],  Preds:{B038},  Succs:{B041}
_0_074:
        shl (16|M0)              r7.0<1>:q     r114.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $245
        shl (16|M16)             r9.0<1>:q     r112.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $245
        add (16|M0)              r11.0<1>:q    r7.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $246
        add (16|M16)             r13.0<1>:q    r9.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $246
        load.ugm.d32.a64 (32|M0)  r116:2        [r11:4]            {I@1,$1} // ex_desc:0x0; desc:0x8200580 // $248
(W)     jmpi                                 _0_075                                                  // $249
// B040: [inDivergent],  Preds:{B038},  Succs:{B041}
_0_073:
        shl (16|M0)              r7.0<1>:q     r114.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $251
        shl (16|M16)             r9.0<1>:q     r112.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $251
        add (16|M0)              r11.0<1>:q    r7.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $252
        add (16|M16)             r13.0<1>:q    r9.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $252
        load.ugm.d16u32.a64 (32|M0)  r16:2      [r11:4]            {I@1,$2} // ex_desc:0x0; desc:0x8200B80 // $254
        shl (32|M0)              r116.0<1>:d   r16.0<1;1,0>:ud   16:w               {$2.dst}         //  ALU pipe: int; $255
// B041: [inDivergent],  Preds:{B040, B039},  Succs:{B042, B043}
_0_075:
        add (32|M0)              acc0.0<1>:f   r116.0<1;1,0>:f   r32.2<0;1,0>:f   {Compacted,A@1,$1.dst} //  ALU pipe: float; $257
        mul (32|M0)              r110.0<1>:f   r126.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $258
        and (32|M0)              r8.0<1>:d     r110.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $259
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r8.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $260
(f2.0)  goto (32|M0)                         _0_076            _0_076                                //  ALU pipe: int; $261
// B042: [inDivergent],  Preds:{B041},  Succs:{B044}
_0_077:
        shr (32|M0)              r8.0<1>:ud    r110.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $263
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $264
        add3 (32|M0)             r12.0<1>:d    r10.0<1;0>:d      r110.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $265
        shr (32|M0)              r14.0<1>:ud   r12.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $266
        mov (32|M0)              r122.0<1>:w   r14.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $267
        goto (32|M0)                         _0_076            _0_078                                // $268
// B043: [inDivergent],  Preds:{B041},  Succs:{B044}
_0_076:
        join (32|M0)                         _0_078                                                  // 
L5008:
        shr (32|M0)              r8.0<1>:ud    r110.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $270
        or (32|M0)               r122.0<1>:w   r8.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $272
// B044: [inDivergent],  Preds:{B043, B042},  Succs:{B045, B038}
_0_078:
        join (32|M0)                         _L_k0_12_                                               // 
L5056:
        add (32|M0)              r36.0<1>:d    r36.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $278
        cmp (32|M0)   (lt)f1.0   null<1>:d     r36.0<1;1,0>:d    r38.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $279
        add (16|M0)              r7.0<1>:q     r120.0<1;1,0>:q   r3.6<0;1,0>:q                       //  ALU pipe: int; $274
        add (16|M16)             r9.0<1>:q     r118.0<1;1,0>:q   r3.6<0;1,0>:q                       //  ALU pipe: int; $274
        mov (32|M0)              r12.0<1>:ud   r122.0<1;1,0>:uw                                      //  ALU pipe: int; $276
        store.ugm.d16u32.a64 (32|M0)  [r7:4]    r12:2              {I@1,$15} // ex_desc:0x0; desc:0x8000B84 // $277
(f1.0)  goto.b (32|M0)                       _L_k0_12_         _0_072                                //  ALU pipe: int; $280
// B045: [inDivergent],  Preds:{B044},  Succs:{B048}
_L_k0_12_:
        join (32|M0)                         _0_047                                                  // 
L5176:
        goto (32|M0)                         _0_047            _0_047                                // $281
// B046: [inDivergent],  Preds:{B005},  Succs:{B047, B048}
_0_051:
        cmp (32|M0)   (eq)f0.0   null<1>:d     r28.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $283
(~f0.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $284
// B047: [inDivergent],  Preds:{B046},  Succs:{B048}
_0_079:
        mov (16|M0)              r7.0<2>:f     r32.0<0;1,0>:f                   {$15.src}            //  ALU pipe: float; $286
        mov (16|M16)             r9.0<2>:f     r32.0<0;1,0>:f                                        //  ALU pipe: float; $286
        mov (32|M0)              r12.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $288
        mov (16|M0)              r7.1<2>:f     r32.1<0;1,0>:f                                        //  ALU pipe: float; $287
        mov (16|M16)             r9.1<2>:ud    r32.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $287
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r7:4]           r12:2              {A@1,$3} // ex_desc:0x0; desc:0x800058B // $289
// B048: Preds:{B047, B046, B045, B029, B004, B003, B002},  Succs:{}
_0_047:
        join (32|M0)                         L5328                                                   // 
L5328:
(W)     mov (16|M0)              r127.0<1>:f   r48.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $291
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$4} // wr:1+0, rd:0; end of thread // $291
L5352:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0xC:ud                                                // 


//.BankConflicts: 33
//.ByteRMWs: 2
//


//.numALUInst: 332
//.accSubDef: 7
//.accSubUse: 7
//.accSubCandidateDef: 7
//.accSubCandidateUse: 7
//
//
//.singlePipeAtOneDistNum: 100
//.allAtOneDistNum: 23
//.syncInstCount: 2
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 15
//.AfterReadTokenDepCount: 9
