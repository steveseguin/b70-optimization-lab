//.kernel _ZTSN9p42extras8FlatNameILNS_4KindE3ELi0EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 24 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 24 -GRFBumpUpNumber 2 "
//.instCount 234
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 3
//.spill flag load 3

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r5.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.4)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r5.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r5.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=uq align=4 words (r4.7)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.8)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r4.4)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r4.12)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.13)
//.declare V0061 (71)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r4.5)
//.declare V0062 (72)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0063 (73)  rf=r size=4 type=d align=32 words (r6.0)
//.declare P01 (74)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0064 (75)  rf=r size=4 type=d align=32 words (r7.0)
//.declare V0066 (77)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0067 (78)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0068 (79)  rf=r size=8 type=uq alias=V0055+0 align=4 words (r4.3)
//.declare V0069 (80)  rf=r size=8 type=uq align=32 words (r10.0)
//.declare V0071 (82)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0072 (83)  rf=r size=256 type=ud alias=V0071+0 align=32 words (r11.0)
//.declare V0073 (84)  rf=r size=8 type=ud alias=V0069+0 align=32 words (r10.0)
//.declare V0074 (85)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0075 (86)  rf=r size=128 type=ud align=32 words (r17.0)
//.declare P02 (88)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0078 (90)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0079 (91)  rf=r size=8 type=d alias=V0044+0 align=4 words (r3.0)
//.declare V0081 (93)  rf=r size=32 type=d align=32 words (r19.0)
//.declare V0082 (94)  rf=r size=8 type=uq align=32 words (r20.0)
//.declare V0084 (96)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0086 (98)  rf=r size=128 type=f alias=V0084+0 align=32 words (r21.0)
//.declare V0087 (99)  rf=r size=32 type=f alias=V0081+0 align=32 words (r19.0)
//.declare V0094 (106)  rf=r size=8 type=q alias=V0041+0 align=4 words (r4.7)
//.declare V0095 (107)  rf=r size=32 type=d align=32 words (r23.0)
//.declare V0096 (108)  rf=r size=8 type=q align=32 words (r24.0)
//.declare V0097 (109)  rf=r size=32 type=f alias=V0095+0 align=32 words (r23.0)
//.declare V0106 (118)  rf=r size=32 type=d align=32 words (r25.0)
//.declare V0108 (120)  rf=r size=32 type=f alias=V0106+0 align=32 words (r25.0)
//.declare V0117 (129)  rf=r size=32 type=d align=32 words (r26.0)
//.declare V0119 (131)  rf=r size=32 type=f alias=V0117+0 align=32 words (r26.0)
//.declare P03 (140)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P04 (141)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0128 (142)  rf=r size=128 type=f align=32 words (r27.0)
//.declare P05 (143)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P06 (144)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P07 (145)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0129 (146)  rf=r size=4 type=ud alias=V0045+0 align=2 words (r3.2)
//.declare P08 (147)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P09 (148)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P10 (149)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0130 (150)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0131 (151)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0132 (152)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0133 (153)  rf=r size=4 type=f align=4 words (r2.14)
//.declare V0134 (154)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0137 (157)  rf=r size=8 type=uq align=32 words (r32.0)
//.declare V0138 (158)  rf=r size=8 type=q align=32 words (r31.0)
//.declare V0139 (159)  rf=r size=4 type=f align=32 words (r33.0)
//.declare V0140 (160)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0143 (163)  rf=r size=8 type=uq align=32 words (r34.0)
//.declare V0144 (164)  rf=r size=4 type=d align=32 words (r35.0)
//.declare V0145 (165)  rf=r size=4 type=ud alias=V0144+0 align=32 words (r35.0)
//.declare V0146 (166)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0149 (169)  rf=r size=8 type=uq align=32 words (r36.0)
//.declare V0150 (170)  rf=r size=4 type=d align=32 words (r37.0)
//.declare V0151 (171)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0154 (174)  rf=r size=8 type=uq align=32 words (r38.0)
//.declare V0156 (176)  rf=r size=4 type=ud align=32 words (r39.0)
//.declare V0157 (177)  rf=r size=4 type=w alias=V0156+0 align=32 words (r39.0)
//.declare V0159 (179)  rf=r size=4 type=d alias=V0139+0 align=32 words (r33.0)
//.declare V0160 (180)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0163 (183)  rf=r size=8 type=uq align=32 words (r40.0)
//.declare P11 (184)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0165 (186)  rf=r size=4 type=d align=4 words (r3.14)
//.declare V0166 (187)  rf=r size=4 type=f align=2 words (r2.13)
//.declare V0167 (188)  rf=r size=4 type=uw alias=V0165+0 align=2 words (r3.28)
//.declare V0168 (189)  rf=r size=2 type=uw align=1 words (r2.30)
//.declare A00 (190)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare P12 (191)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0169 (192)  rf=r size=4 type=ud alias=V0132+0 align=2 words (r2.12)
//.declare V0170 (193)  rf=r size=8 type=ud alias=V0078+0 align=2 words (r2.8)
//.declare P13 (194)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P14 (195)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0171 (196)  rf=r size=128 type=f align=32 words (r41.0)
//.declare P15 (197)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P16 (198)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P17 (199)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0172 (200)  rf=r size=128 type=f align=32 words (r43.0)
//.declare V0173 (201)  rf=r size=128 type=f align=32 words (r45.0)
//.declare V0174 (202)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0175 (203)  rf=r size=4 type=d align=2 words (r3.15)
//.declare V0176 (204)  rf=r size=128 type=f align=32 words (r47.0)
//.declare V0177 (205)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0179 (207)  rf=r size=4 type=uw alias=V0177+0 align=2 words (r4.4)
//.declare V0180 (208)  rf=r size=2 type=uw align=1 words (r4.6)
//.declare A01 (209)  rf=a size=2 type=uw align=1 words (a0.1)
//.declare V0181 (210)  rf=r size=4 type=d align=2 words (r4.4)
//.declare P18 (211)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0182 (212)  rf=r size=4 type=ud alias=V0181+0 align=2 words (r4.4)
//.declare P19 (213)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare P20 (214)  rf=f1  size=2 type=uw align=1 words (f3.0)
//.declare V0184 (216)  rf=r size=4 type=uw alias=V0181+0 align=2 words (r4.8)
//.declare V0185 (217)  rf=r size=2 type=uw align=1 words (r4.7)
//.declare A02 (218)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0186 (219)  rf=r size=4 type=f align=2 words (r4.5)
//.declare V0188 (221)  rf=r size=4 type=f align=2 words (r4.8)
//.declare V0189 (222)  rf=r size=2 type=uw align=1 words (r4.18)
//.declare A03 (223)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare P21 (224)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0190 (225)  rf=r size=4 type=ud alias=V0177+0 align=2 words (r4.2)
//.declare P22 (226)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P23 (227)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0191 (228)  rf=r size=128 type=f align=32 words (r49.0)
//.declare P24 (229)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0192 (230)  rf=r size=4 type=ud alias=V0175+0 align=2 words (r3.15)
//.declare P25 (231)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P26 (232)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0193 (233)  rf=r size=128 type=f align=32 words (r51.0)
//.declare P27 (234)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0195 (236)  rf=r size=256 type=uq align=32 words (r53.0)
//.declare V0196 (237)  rf=r size=256 type=ud alias=V0195+0 align=32 words (r53.0)
//.declare V0197 (238)  rf=r size=128 type=d align=32 words (r57.0)
//.declare  (239)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (240)  rf=r size=4 type=f align=2 words (r4.12)
//.declare  (241)  rf=r size=2 type=w align=1 words (r4.19)
//.declare  (242)  rf=r size=2 type=uw align=1 words (r4.26)
//.declare  (243)  rf=r size=2 type=w align=1 words (r4.27)
//.declare  (244)  rf=r size=2 type=uw align=1 words (r6.2)
//.declare  (247)  rf=r size=2 type=w align=1 words (r6.3)
//.declare  (248)  rf=r size=2 type=uw align=1 words (r6.4)
//.declare  (249)  rf=r size=4 type=uw align=2 words (r6.6)
//.declare  (250)  rf=r size=4 type=uw align=2 words (r6.8)
//.declare  (251)  rf=r size=4 type=uw align=2 words (r6.10)
//.declare  (252)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (253)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (254)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (255)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (256)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (257)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare r0 (258)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (259)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (260)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (261)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (262)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (263)  rf=r size=128 type=ud align=32 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0037    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0048    | :d       |    0x4 | r3+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0050    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r3+0x38  | cti+0x58         |
// | V0052    | :q       |    0x8 | r4       | cti+0x60         |
// | V0053    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0054    | :d       |    0x4 | r4+0x10  | cti+0x70         |
// | V0055    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0056    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0057    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0058    | :d       |    0x4 | r4+0x30  | cti+0x90         |
// | V0059    | :d       |    0x4 | r4+0x34  | cti+0x94         |
// | V0041    | :uq      |    0x8 | r4+0x38  | cti+0x98         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B034}
// _main:
(W)     mov (16|M0)              r5.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r4.0<1>:uq    r4.5<0;1,0>:uq                   {Compacted,A@1,$1.dst} //  ALU pipe: int; $2
(W)     load.ugm.d32x1t.a64 (1|M0)  r6:1        [r4:1]             {I@1,$2} // ex_desc:0x0; desc:0x2108580 // $3
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r6.0<0;1,0>:d     0:w               {$2.dst}          //  ALU pipe: int; $4
(W&f1.0) jmpi                                _0_037                                                  //  ALU pipe: int; $5
// B003: Preds:{B002},  Succs:{B004, B034}
_0_038:
(W)     mov (1|M0)               r10.0<1>:uq   r4.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $10
        mov (32|M0)              r15.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $13
        mov (16|M0)              r11.0<2>:f    r10.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $11
        mov (16|M16)             r13.0<2>:f    r10.0<0;1,0>:f                                        //  ALU pipe: float; $11
        mov (16|M0)              r11.1<2>:f    r10.1<0;1,0>:f                                        //  ALU pipe: float; $12
        mov (16|M16)             r13.1<2>:f    r10.1<0;1,0>:f                                        //  ALU pipe: float; $12
        atomic_or.ugm.d32.a64 (32|M0)  r17:2    [r11:4]           r15:2              {A@1,$3} // ex_desc:0x0; desc:0x8200599 // $14
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r5.2<0;1,0>:uw                      //  ALU pipe: int; $7
(W)     macl (1|M0)              r7.0<1>:d     r2.3<0;1,0>:d     r5.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $9
        add3 (32|M0)             r8.0<1>:d     r7.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {@1,$0.dst} //  ALU pipe: int; $9
        or (32|M0)    (eq)f0.0   null<1>:d     r17.0<1;1,0>:d    r8.0<1;1,0>:d    {@1,$3.dst}        //  ALU pipe: int; $16
(~f0.0) goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $18
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B006}
_0_039:
(W)     mov (1|M0)               r20.0<1>:uq   r4.7<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $21
(W)     mov (1|M0)               r24.0<1>:q    r4.7<0;1,0>:q                                         //  ALU pipe: int; $63
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r19:1 [r20:1]            {I@2,$4} // ex_desc:0x0; desc:0x219C580 // $22
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r23:1 [r24:1+0x20]       {I@1,$5} // ex_desc:0x20000; desc:0x219C580 // $64
(W)     mov (2|M0)               r21.0<1>:d    r19.0<1;1,0>:d                   {Compacted,$4.dst}   //  ALU pipe: int; $23
(W)     mov (1|M0)               r21.2<1>:ud   r19.2<0;1,0>:ud                                       //  ALU pipe: int; $27
(W)     mov (1|M0)               r21.3<1>:ud   r19.3<0;1,0>:ud                                       //  ALU pipe: int; $33
(W)     mov (1|M0)               r21.4<1>:ud   r19.4<0;1,0>:ud                                       //  ALU pipe: int; $39
(W)     mov (1|M0)               r21.5<1>:ud   r19.5<0;1,0>:ud                                       //  ALU pipe: int; $45
(W)     mov (1|M0)               r21.6<1>:f    r19.6<0;1,0>:f                                        //  ALU pipe: float; $51
(W)     mov (1|M0)               r21.7<1>:f    r19.7<0;1,0>:f                                        //  ALU pipe: float; $57
(W)     mov (1|M0)               r21.8<1>:f    r23.0<0;1,0>:f                   {$5.dst}             //  ALU pipe: float; $65
(W)     mov (1|M0)               r21.9<1>:f    r23.1<0;1,0>:f                                        //  ALU pipe: float; $71
(W)     mov (1|M0)               r21.10<1>:f   r23.2<0;1,0>:f                                        //  ALU pipe: float; $77
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r25:1 [r24:1+0x40]       {$6} // ex_desc:0x40000; desc:0x219C580 // $114
(W)     mov (1|M0)               r21.11<1>:f   r23.3<0;1,0>:f                                        //  ALU pipe: float; $83
(W)     mov (1|M0)               r21.12<1>:f   r23.4<0;1,0>:f                                        //  ALU pipe: float; $89
(W)     mov (1|M0)               r21.13<1>:f   r23.5<0;1,0>:f                                        //  ALU pipe: float; $95
(W)     mov (1|M0)               r21.14<1>:f   r23.6<0;1,0>:f                                        //  ALU pipe: float; $101
(W)     mov (1|M0)               r21.15<1>:f   r23.7<0;1,0>:f                                        //  ALU pipe: float; $107
(W)     mov (1|M0)               r22.0<1>:f    r25.0<0;1,0>:f                   {Compacted,$6.dst}   //  ALU pipe: float; $115
(W)     mov (1|M0)               r22.1<1>:f    r25.1<0;1,0>:f                                        //  ALU pipe: float; $121
(W)     mov (1|M0)               r22.2<1>:f    r25.2<0;1,0>:f                                        //  ALU pipe: float; $127
(W)     load.ugm.d32x8t.a64.ca.cc (1|M0)  r26:1 [r24:1+0x60]       {$7} // ex_desc:0x60000; desc:0x219C580 // $164
(W)     mov (1|M0)               r22.3<1>:f    r25.3<0;1,0>:f                                        //  ALU pipe: float; $133
(W)     mov (1|M0)               r22.4<1>:f    r25.4<0;1,0>:f                                        //  ALU pipe: float; $139
(W)     mov (1|M0)               r22.5<1>:f    r25.5<0;1,0>:f                                        //  ALU pipe: float; $145
(W)     mov (1|M0)               r22.6<1>:f    r25.6<0;1,0>:f                                        //  ALU pipe: float; $151
(W)     mov (1|M0)               r22.7<1>:f    r25.7<0;1,0>:f                                        //  ALU pipe: float; $157
(W)     mov (1|M0)               r22.8<1>:f    r26.0<0;1,0>:f                   {$7.dst}             //  ALU pipe: float; $165
(W)     mov (1|M0)               r22.9<1>:f    r26.1<0;1,0>:f                                        //  ALU pipe: float; $171
(W)     mov (2|M0)               r2.8<1>:d     r3.0<1;1,0>:d                                         //  ALU pipe: int; $20
(W)     mov (1|M0)               r22.10<1>:f   r26.2<0;1,0>:f                                        //  ALU pipe: float; $177
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r2.8<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $213
(W)     mov (1|M0)               r22.11<1>:f   r26.3<0;1,0>:f                                        //  ALU pipe: float; $183
(W)     mov (1|M0)               r22.12<1>:f   r26.4<0;1,0>:f                                        //  ALU pipe: float; $189
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r2.9<0;1,0>:d     0:w                                 //  ALU pipe: int; $214
(W)     mov (1|M0)               r22.13<1>:f   r26.5<0;1,0>:f                                        //  ALU pipe: float; $195
(W)     mov (1|M0)               r22.14<1>:f   r26.6<0;1,0>:f                                        //  ALU pipe: float; $201
(W)     mov (1|M0)               r22.15<1>:f   r26.7<0;1,0>:f                                        //  ALU pipe: float; $207
(W&~f0.0) jmpi                               _0_040                                                  //  ALU pipe: int; $216
// B005: [inDivergent],  Preds:{B004},  Succs:{B023}
_0_041:
(W)     mov (8|M0)               r27.0<1>:f    r21.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $218
(W)     mov (8|M0)               r27.8<1>:ud   r21.8<1;1,0>:ud                                       //  ALU pipe: int; $219
(W)     mov (8|M0)               r28.0<1>:f    r22.0<1;1,0>:f                   {Compacted,F@7}      //  ALU pipe: float; $220
(W)     mov (8|M0)               r28.8<1>:ud   r22.8<1;1,0>:ud                  {F@3}                //  ALU pipe: int; $221
(W)     jmpi                                 _0_042                                                  // $222
// B006: [inDivergent],  Preds:{B004},  Succs:{B007}
_0_040:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r3.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $224
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $225
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r3.2<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $226
(W)     mov (1|M0)               r6.5<1>:ud    f2.0<0;1,0>:ud                                        //  ALU pipe: int; $224
(W)     mov (1|M0)               r6.4<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $225
(W)     mov (1|M0)               r6.3<1>:ud    f0.0<0;1,0>:ud                                        //  ALU pipe: int; $226
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.2<0;1,0>:d     4:w                                 //  ALU pipe: int; $227
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.2<0;1,0>:d     1:w                                 //  ALU pipe: int; $228
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $229
(W)     mov (8|M0)               r29.0<1>:f    r21.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $230
(W)     mov (8|M0)               r29.8<1>:f    r21.8<1;1,0>:f                                        //  ALU pipe: float; $231
(W)     mov (8|M0)               r30.0<1>:f    r22.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $232
(W)     mov (8|M0)               r30.8<1>:f    r22.8<1;1,0>:f                                        //  ALU pipe: float; $233
(W)     mov (1|M0)               r2.5<1>:q     0:w                                                   //  ALU pipe: int; $234
(W)     mov (1|M0)               r2.12<1>:d    0:w                                                   //  ALU pipe: int; $235
// B007: [inDivergent],  Preds:{B022, B006},  Succs:{B008, B015}
_0_043:
(W)     mov (1|M0)               f3.0<1>:ud    r6.5<0;1,0>:ud                   {I@7}                //  ALU pipe: int; $237
(W&f3.0) jmpi                                _0_044                                                  //  ALU pipe: int; $237
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B014}
_0_045:
(W)     mov (1|M0)               f3.0<1>:ud    r6.4<0;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $239
(W&f3.0) jmpi                                _0_046                                                  //  ALU pipe: int; $239
// B009: [inDivergent],  Preds:{B008},  Succs:{B010, B013}
_0_047:
(W)     mov (1|M0)               f3.0<1>:ud    r6.3<0;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $241
(W&f3.0) jmpi                                _0_048                                                  //  ALU pipe: int; $241
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B012}
_0_049:
(W&f2.0) jmpi                                _0_050                                                  //  ALU pipe: int; $243
// B011: [inDivergent],  Preds:{B010},  Succs:{B020}
_0_051:
(W)     mov (1|M0)               r2.14<1>:f    0x0:f                                                 //  ALU pipe: float; $245
(W)     jmpi                                 _0_052                                                  // $246
// B012: [inDivergent],  Preds:{B010},  Succs:{B020}
_0_050:
(W)     shl (1|M0)               r3.2<1>:q     r2.5<0;1,0>:q     3:w               {I@7}             //  ALU pipe: int; $248
(W)     add (1|M0)               r32.0<1>:q    r3.2<0;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $249
(W)     load.ugm.d64x1t.a64 (1|M0)  r31:1       [r32:1]            {I@1,$8} // ex_desc:0x0; desc:0x2108780 // $251
(W)     mov (1|M0)               r2.14<2>:f    r31.0<0;1,0>:q                   {$8.dst}             //  ALU pipe: float; $252
(W)     jmpi                                 _0_052                                                  // $254
// B013: [inDivergent],  Preds:{B009},  Succs:{B020}
_0_048:
(W)     shl (1|M0)               r3.3<1>:q     r2.5<0;1,0>:q     2:w                                 //  ALU pipe: int; $256
(W)     add (1|M0)               r34.0<1>:q    r3.3<0;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $257
(W)     load.ugm.d32x1t.a64 (1|M0)  r35:1       [r34:1]            {I@1,$9} // ex_desc:0x0; desc:0x2108580 // $259
(W)     mov (1|M0)               r2.14<1>:f    r35.0<0;1,0>:ud                  {$9.dst}             //  ALU pipe: float; $260
(W)     jmpi                                 _0_052                                                  // $262
// B014: [inDivergent],  Preds:{B008},  Succs:{B020}
_0_046:
(W)     shl (1|M0)               r3.4<1>:q     r2.5<0;1,0>:q     2:w                                 //  ALU pipe: int; $264
(W)     add (1|M0)               r36.0<1>:q    r3.4<0;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $265
(W)     load.ugm.d32x1t.a64 (1|M0)  r37:1       [r36:1]            {I@1,$10} // ex_desc:0x0; desc:0x2108580 // $267
(W)     mov (1|M0)               r2.14<1>:f    r37.0<0;1,0>:d                   {$10.dst}            //  ALU pipe: float; $268
(W)     jmpi                                 _0_052                                                  // $270
// B015: [inDivergent],  Preds:{B007},  Succs:{B016, B019}
_0_044:
(W&~f1.0) jmpi                               _0_053                                                  //  ALU pipe: int; $272
// B016: [inDivergent],  Preds:{B015},  Succs:{B017, B018}
_0_054:
(W&f0.0) jmpi                                _0_055                                                  //  ALU pipe: int; $274
// B017: [inDivergent],  Preds:{B016},  Succs:{B020}
_0_056:
(W)     mov (1|M0)               r2.14<1>:f    0x0:f                                                 //  ALU pipe: float; $276
(W)     jmpi                                 _0_052                                                  // $277
// B018: [inDivergent],  Preds:{B016},  Succs:{B020}
_0_055:
(W)     shl (1|M0)               r3.5<1>:q     r2.5<0;1,0>:q     1:w                                 //  ALU pipe: int; $279
(W)     add (1|M0)               r38.0<1>:q    r3.5<0;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $280
(W)     load.ugm.d16u32.a64 (1|M0)  r39:1       [r38:2]            {I@1,$11} // ex_desc:0x0; desc:0x4100B80 // $282
        sync.nop                             null                             {Compacted,F@1}        // $283
(W)     shl (1|M0)               r2.14<1>:d    r39.0<0;1,0>:ud   16:w               {$11.dst}        //  ALU pipe: int; $283
(W)     jmpi                                 _0_052                                                  // $285
// B019: [inDivergent],  Preds:{B015},  Succs:{B020}
_0_053:
(W)     shl (1|M0)               r3.6<1>:q     r2.5<0;1,0>:q     2:w                                 //  ALU pipe: int; $287
(W)     add (1|M0)               r40.0<1>:q    r3.6<0;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $288
(W)     load.ugm.d32x1t.a64 (1|M0)  r33:1       [r40:1]            {I@1,$12} // ex_desc:0x0; desc:0x2108580 // $290
(W)     mov (1|M0)               r2.14<1>:f    r33.0<0;1,0>:f                   {$12.dst}            //  ALU pipe: float; $291
// B020: [inDivergent],  Preds:{B019, B018, B017, B014, B013, B012, B011},  Succs:{B021, B022}
_0_052:
(W)     cmp (32|M0)   (ne)f3.0   null<1>:f     r2.14<0;1,0>:f    0x0:f               {F@1}           //  ALU pipe: float; $293
(W)     mov (1|M0)               r4.12<1>:f    0x3F800000:f                                          //  ALU pipe: float; $294
(W)     add (1|M0)               r2.12<1>:d    r2.12<0;1,0>:d    1:w                                 //  ALU pipe: int; $300
(W&f3.0) sel (1|M0)              r2.13<1>:f    r4.12<0;1,0>:f    0x0:f               {F@1}           //  ALU pipe: float; $294
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r2.12<0;1,0>:ud   r2.8<0;1,0>:ud   {A@1}              //  ALU pipe: int; $301
(W)     mov (1|M0)               r4.19<1>:hf   0x0:hf                                                //  ALU pipe: float; $302
(W)     mov (1|M0)               r3.14<2>:d    r2.5<0;1,0>:q                                         //  ALU pipe: int; $295
(W&f3.0) cmp (32|M0)  (eq)f3.0   null<1>:d     r4.19<0;1,0>:w    r2.9<0;1,0>:d    {F@1}              //  ALU pipe: int; $302
(W)     mov (1|M0)               r4.26<1>:hf   0x0:hf                                                //  ALU pipe: float; $304
(W)     mul (1|M0)               r2.30<1>:uw   r3.28<0;1,0>:uw   0x4:uw              {I@2}           //  ALU pipe: int; $297
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:ud    r4.26<0;1,0>:uw   r2.9<0;1,0>:ud   {F@1}              //  ALU pipe: int; $304
(W)     add (1|M0)               a0.0<1>:uw    r2.30<0;1,0>:uw   0x740:uw              {A@1}         //  ALU pipe: int; src1 is addr of V0130(r29.0:f); $298
(W)     mov (1|M0)               r[a0.0]<1>:f  r2.13<0;1,0>:f                                        //  ALU pipe: float; $299
(W)     mov (8|M0)               r41.0<1>:f    r29.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $306
(W)     mov (8|M0)               r41.8<1>:ud   r29.8<1;1,0>:ud                                       //  ALU pipe: int; $307
(W)     mov (8|M0)               r42.0<1>:f    r30.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $308
(W)     mov (8|M0)               r42.8<1>:ud   r30.8<1;1,0>:ud                                       //  ALU pipe: int; $309
(W&f3.0) jmpi                                _0_057                                                  //  ALU pipe: int; $310
// B021: [inDivergent],  Preds:{B020},  Succs:{B023}
_0_058:
(W)     mov (8|M0)               r27.0<1>:f    r41.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $312
(W)     mov (8|M0)               r27.8<1>:ud   r41.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $313
(W)     mov (8|M0)               r28.0<1>:f    r42.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $314
(W)     mov (8|M0)               r28.8<1>:ud   r42.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $315
(W)     jmpi                                 _0_042                                                  // $316
// B022: [inDivergent],  Preds:{B020},  Succs:{B007}
_0_057:
(W)     mov (1|M0)               r2.5<1>:q     r2.12<0;1,0>:ud                                       //  ALU pipe: int; $318
(W)     jmpi                                 _0_043                                                  // $319
// B023: [inDivergent],  Preds:{B021, B005},  Succs:{B024, B025}
_0_042:
(W)     cmp (32|M0)   (gt)f0.0   null<1>:ud    r2.8<0;1,0>:ud    0x1:uw                              //  ALU pipe: int; $321
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r2.9<0;1,0>:d     0:w                                 //  ALU pipe: int; $322
(W&~f0.0) cmp (32|M0) (gt)f0.0   null<1>:ud    r2.9<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $324
(W&f0.0) jmpi                                _0_059                                                  //  ALU pipe: int; $326
// B024: [inDivergent],  Preds:{B023},  Succs:{B032}
_0_060:
(W)     mov (8|M0)               r43.0<1>:f    r27.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $328
(W)     mov (8|M0)               r43.8<1>:ud   r27.8<1;1,0>:ud                  {I@7}                //  ALU pipe: int; $329
(W)     mov (8|M0)               r44.0<1>:f    r28.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $330
(W)     mov (8|M0)               r44.8<1>:ud   r28.8<1;1,0>:ud                  {I@7}                //  ALU pipe: int; $331
(W)     jmpi                                 _0_061                                                  // $332
// B025: [inDivergent],  Preds:{B023},  Succs:{B026}
_0_059:
(W)     mov (8|M0)               r45.0<1>:f    r27.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $334
(W)     mov (8|M0)               r45.8<1>:ud   r27.8<1;1,0>:ud                                       //  ALU pipe: int; $335
(W)     mov (8|M0)               r46.0<1>:f    r28.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $336
(W)     mov (8|M0)               r46.8<1>:ud   r28.8<1;1,0>:ud                                       //  ALU pipe: int; $337
(W)     mov (1|M0)               r3.3<1>:d     1:w                                                   //  ALU pipe: int; $338
// B026: [inDivergent],  Preds:{B031, B025},  Succs:{B027}
_0_062:
(W)     shl (1|M0)               r3.15<1>:d    r3.3<0;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $340
(W)     mov (8|M0)               r47.0<1>:f    r45.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $341
(W)     mov (8|M0)               r47.8<1>:f    r45.8<1;1,0>:f                                        //  ALU pipe: float; $342
(W)     mov (8|M0)               r48.0<1>:f    r46.0<1;1,0>:f                   {Compacted,F@3}      //  ALU pipe: float; $343
(W)     mov (8|M0)               r48.8<1>:ud   r46.8<1;1,0>:ud                                       //  ALU pipe: int; $344
(W)     mov (1|M0)               r4.2<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $345
// B027: [inDivergent],  Preds:{B028, B026},  Succs:{B028, B029}
_0_063:
(W)     add (1|M0)               r4.4<1>:d     r4.2<0;1,0>:d     r3.3<0;1,0>:d    {I@1}              //  ALU pipe: int; $350
(W)     mov (1|M0)               r4.27<1>:hf   0x0:hf                                                //  ALU pipe: float; $352
(W)     cmp (1|M0)    (lt)f3.0   null<1>:ud    r4.4<0;1,0>:ud    r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $351
(W)     mul (1|M0)               r4.6<1>:uw    r4.4<0;1,0>:uw    0x4:uw                              //  ALU pipe: int; $347
(W)     mul (1|M0)               r4.18<1>:uw   r4.4<0;1,0>:uw    0x4:uw                              //  ALU pipe: int; $362
(W)     add (1|M0)               r4.2<1>:d     r4.2<0;1,0>:d     r3.15<0;1,0>:d                      //  ALU pipe: int; $365
(W&f3.0) cmp (1|M0)   (eq)f3.0   null<1>:d     r4.27<0;1,0>:w    r2.9<0;1,0>:d    {F@1}              //  ALU pipe: int; $352
(W)     mov (1|M0)               r6.2<1>:hf    0x0:hf                                                //  ALU pipe: float; $354
(W)     mul (1|M0)               r4.7<1>:uw    r4.8<0;1,0>:uw    0x4:uw                              //  ALU pipe: int; $356
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r4.2<0;1,0>:ud    r2.8<0;1,0>:ud   {I@3}              //  ALU pipe: int; $366
(W&~f3.0) cmp (1|M0)  (lt)f3.0   null<1>:ud    r6.2<0;1,0>:uw    r2.9<0;1,0>:ud   {F@1}              //  ALU pipe: int; $354
(W)     add (1|M0)               a0.0<1>:uw    r4.7<0;1,0>:uw    0xBC0:uw              {I@3}         //  ALU pipe: int; src1 is addr of V0176(r47.0:f); $357
(W)     add (1|M0)               a0.1<1>:uw    r4.6<0;1,0>:uw    0xBC0:uw                            //  ALU pipe: int; src1 is addr of V0176(r47.0:f); $348
(W&f2.0) cmp (32|M0)  (eq)f2.0   null<1>:d     r4.27<0;1,0>:w    r2.9<0;1,0>:d                       //  ALU pipe: int; $367
(W&f3.0) sel (1|M0)              r4.5<1>:f     r[a0.0]<0;1,0>:f  0x0:f                               //  ALU pipe: float; $359
(W&~f2.0) cmp (32|M0) (lt)f2.0   null<1>:ud    r6.2<0;1,0>:uw    r2.9<0;1,0>:ud                      //  ALU pipe: int; $369
(W)     add (1|M0)               r4.8<1>:f     r[a0.1]<0;1,0>:f  r4.5<0;1,0>:f    {F@1}              //  ALU pipe: float; $360
(W)     add (1|M0)               a0.0<1>:uw    r4.18<0;1,0>:uw   0xBC0:uw                            //  ALU pipe: int; src1 is addr of V0176(r47.0:f); $363
(W)     mov (1|M0)               r[a0.0]<1>:f  r4.8<0;1,0>:f                    {F@1}                //  ALU pipe: float; $364
(W)     mov (8|M0)               r49.0<1>:f    r47.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $371
(W)     mov (8|M0)               r49.8<1>:f    r47.8<1;1,0>:f                                        //  ALU pipe: float; $372
(W)     mov (8|M0)               r50.0<1>:f    r48.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $373
(W)     mov (8|M0)               r50.8<1>:f    r48.8<1;1,0>:f                                        //  ALU pipe: float; $374
(W&~f2.0) jmpi                               _0_064                                                  //  ALU pipe: int; $375
// B028: [inDivergent],  Preds:{B027},  Succs:{B027}
_0_065:
(W)     jmpi                                 _0_063                                                  // $377
// B029: [inDivergent],  Preds:{B027},  Succs:{B030, B031}
_0_064:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r3.15<0;1,0>:ud   r2.8<0;1,0>:ud                      //  ALU pipe: int; $379
(W)     mov (1|M0)               r6.3<1>:hf    0x0:hf                                                //  ALU pipe: float; $380
(W)     mov (1|M0)               r6.4<1>:hf    0x0:hf                                                //  ALU pipe: float; $382
(W&f0.0) cmp (32|M0)  (eq)f0.0   null<1>:d     r6.3<0;1,0>:w     r2.9<0;1,0>:d    {F@2}              //  ALU pipe: int; $380
(W&~f0.0) cmp (32|M0) (lt)f0.0   null<1>:ud    r6.4<0;1,0>:uw    r2.9<0;1,0>:ud   {F@1}              //  ALU pipe: int; $382
(W)     mov (8|M0)               r51.0<1>:f    r49.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $384
(W)     mov (8|M0)               r51.8<1>:ud   r49.8<1;1,0>:ud                                       //  ALU pipe: int; $385
(W)     mov (8|M0)               r52.0<1>:f    r50.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $386
(W)     mov (8|M0)               r52.8<1>:ud   r50.8<1;1,0>:ud                                       //  ALU pipe: int; $387
(W&f0.0) jmpi                                _0_066                                                  //  ALU pipe: int; $388
// B030: [inDivergent],  Preds:{B029},  Succs:{B032}
_0_067:
(W)     mov (8|M0)               r43.0<1>:f    r51.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $390
(W)     mov (8|M0)               r43.8<1>:ud   r51.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $391
(W)     mov (8|M0)               r44.0<1>:f    r52.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $392
(W)     mov (8|M0)               r44.8<1>:ud   r52.8<1;1,0>:ud                  {I@3}                //  ALU pipe: int; $393
(W)     jmpi                                 _0_061                                                  // $394
// B031: [inDivergent],  Preds:{B029},  Succs:{B026}
_0_066:
(W)     mov (8|M0)               r45.0<1>:f    r49.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $396
(W)     mov (8|M0)               r45.8<1>:ud   r49.8<1;1,0>:ud                                       //  ALU pipe: int; $397
(W)     mov (8|M0)               r46.0<1>:f    r50.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $398
(W)     mov (8|M0)               r46.8<1>:ud   r50.8<1;1,0>:ud                                       //  ALU pipe: int; $399
(W)     mov (1|M0)               r3.3<1>:d     r3.15<0;1,0>:d                                        //  ALU pipe: int; $400
(W)     jmpi                                 _0_062                                                  // $401
// B032: [inDivergent],  Preds:{B030, B024},  Succs:{B033, B034}
_0_061:
(W)     cmp (32|M0)   (ne)f3.0   null<1>:f     r43.0<0;1,0>:f    0x0:f               {F@4}           //  ALU pipe: float; $403
(~f3.0) goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $404
// B033: [inDivergent],  Preds:{B032},  Succs:{B034}
_0_068:
        mov (16|M0)              r53.0<2>:f    r10.0<0;1,0>:f                                        //  ALU pipe: float; $406
        mov (16|M16)             r55.0<2>:f    r10.0<0;1,0>:f                                        //  ALU pipe: float; $406
        mov (32|M0)              r57.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $408
        mov (16|M0)              r53.1<2>:f    r10.1<0;1,0>:f                                        //  ALU pipe: float; $407
        mov (16|M16)             r55.1<2>:ud   r10.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $407
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r53:4]          r57:2              {A@1,$13} // ex_desc:0x0; desc:0x800058B // $409
// B034: Preds:{B033, B032, B003, B002},  Succs:{}
_0_037:
        join (32|M0)                         L3320                                                   // 
L3320:
(W)     mov (16|M0)              r127.0<1>:f   r5.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $411
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$14} // wr:1+0, rd:0; end of thread // $411
L3344:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x18:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 191
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 35
//.allAtOneDistNum: 7
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 13
//.AfterReadTokenDepCount: 1
