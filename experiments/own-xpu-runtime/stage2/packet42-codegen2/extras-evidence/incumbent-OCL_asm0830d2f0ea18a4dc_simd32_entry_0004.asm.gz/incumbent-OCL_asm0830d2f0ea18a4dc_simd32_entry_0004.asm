//.kernel _ZTSZZNK11specialised6KernelILN2ng2OpE2ELi1ELi2560ELi4EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_2idILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 137417456 3927483612 -hashmovs1 0 4 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 137417456 3927483612 -hashmovs1 0 4 -GRFBumpUpNumber 2 "
//.instCount 317
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.private memory size 128

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r112.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r112.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r112.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0072 (82)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0074 (84)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0075 (85)  rf=r size=128 type=d align=32 words (r114.0)
//.declare V0076 (86)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0077 (87)  rf=r size=4 type=d align=2 words (r2.9)
//.declare V0078 (88)  rf=r size=4 type=d align=2 words (r2.10)
//.declare V0079 (89)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0080 (90)  rf=r size=4 type=ud alias=V0078+0 align=2 words (r2.10)
//.declare V0081 (91)  rf=r size=4 type=ud alias=V0076+0 align=2 words (r2.8)
//.declare V0082 (92)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0084 (94)  rf=r size=4 type=d align=2 words (r4.1)
//.declare P01 (95)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0085 (96)  rf=r size=128 type=ud alias=V0075+0 align=32 words (r114.0)
//.declare P02 (97)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P03 (98)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0086 (99)  rf=r size=4 type=ud alias=V0079+0 align=2 words (r5.0)
//.declare V0087 (100)  rf=r size=8 type=uq alias=V0069+0 align=32 words (r5.6)
//.declare V0088 (101)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0089 (102)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P04 (103)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0090 (104)  rf=r size=8 type=uq alias=V0066+0 align=32 words (r5.3)
//.declare V0091 (105)  rf=r size=8 type=uq align=32 words (r122.0)
//.declare V0093 (107)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0094 (108)  rf=r size=256 type=ud alias=V0093+0 align=32 words (r6.0)
//.declare V0095 (109)  rf=r size=8 type=ud alias=V0091+0 align=32 words (r122.0)
//.declare V0096 (110)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0097 (111)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P05 (113)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0099 (114)  rf=r size=8 type=uq alias=V0068+0 align=32 words (r5.5)
//.declare V0100 (115)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0101 (116)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0102 (117)  rf=r size=4 type=d align=2 words (r2.8)
//.declare P06 (118)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P07 (119)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0103 (120)  rf=r size=64 type=w align=32 words (r92.0)
//.declare V0104 (121)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0105 (122)  rf=r size=128 type=ud alias=V0104+0 align=32 words (r6.0)
//.declare V0106 (123)  rf=r size=128 type=d align=32 words (r116.0)
//.declare V0107 (124)  rf=r size=128 type=ud alias=V0106+0 align=32 words (r116.0)
//.declare V0108 (125)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0109 (126)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.3)
//.declare V0110 (127)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0112 (129)  rf=r size=128 type=ud alias=V0110+0 align=32 words (r8.0)
//.declare V0113 (130)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0114 (131)  rf=r size=256 type=uq alias=V0113+0 align=32 words (r14.0)
//.declare V0115 (132)  rf=r size=512 type=f align=32 words (r18.0)
//.declare V0116 (133)  rf=r size=512 type=f align=32 words (r26.0)
//.declare V0117 (134)  rf=r size=512 type=f align=32 words (r34.0)
//.declare V0118 (135)  rf=r size=512 type=f align=32 words (r42.0)
//.declare V0119 (136)  rf=r size=512 type=f align=32 words (r50.0)
//.declare V0120 (137)  rf=r size=512 type=f align=32 words (r58.0)
//.declare V0121 (138)  rf=r size=512 type=f align=32 words (r66.0)
//.declare V0122 (139)  rf=r size=512 type=f align=32 words (r74.0)
//.declare V0123 (140)  rf=r size=512 type=f align=32 words (r82.0)
//.declare V0124 (141)  rf=r size=512 type=f align=32 words (r52.0)
//.declare V0125 (142)  rf=r size=512 type=f align=32 words (r60.0)
//.declare V0126 (143)  rf=r size=512 type=f align=32 words (r68.0)
//.declare V0127 (144)  rf=r size=512 type=f align=32 words (r76.0)
//.declare V0128 (145)  rf=r size=512 type=f align=32 words (r18.0)
//.declare V0129 (146)  rf=r size=512 type=f align=32 words (r84.0)
//.declare V0130 (147)  rf=r size=512 type=f align=32 words (r26.0)
//.declare V0131 (148)  rf=r size=512 type=f align=32 words (r92.0)
//.declare V0132 (149)  rf=r size=512 type=f align=32 words (r34.0)
//.declare V0133 (150)  rf=r size=512 type=f align=32 words (r34.0)
//.declare V0134 (151)  rf=r size=512 type=f align=32 words (r66.0)
//.declare V0135 (152)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0136 (153)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0137 (154)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0138 (155)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0139 (156)  rf=r size=128 type=f align=32 words (r92.0)
//.declare V0140 (157)  rf=r size=128 type=f align=32 words (r90.0)
//.declare V0141 (158)  rf=r size=128 type=f align=32 words (r96.0)
//.declare V0142 (159)  rf=r size=128 type=f align=32 words (r94.0)
//.declare V0143 (160)  rf=r size=128 type=f align=32 words (r100.0)
//.declare V0144 (161)  rf=r size=128 type=f align=32 words (r98.0)
//.declare V0145 (162)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0146 (163)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0147 (164)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0148 (165)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0149 (166)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0150 (167)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0151 (168)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0152 (169)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0153 (170)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0154 (171)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0155 (172)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0156 (173)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0157 (174)  rf=r size=128 type=f align=32 words (r48.0)
//.declare V0158 (175)  rf=r size=128 type=f align=32 words (r46.0)
//.declare V0159 (176)  rf=r size=128 type=f align=32 words (r100.0)
//.declare V0160 (177)  rf=r size=128 type=f align=32 words (r50.0)
//.declare V0161 (178)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0162 (179)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0163 (180)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0164 (181)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0166 (183)  rf=r size=128 type=f align=32 words (r110.0)
//.declare V0167 (184)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0168 (185)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0169 (186)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0170 (187)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0171 (188)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0172 (189)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0174 (191)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0175 (192)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0176 (193)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0177 (194)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0178 (195)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0179 (196)  rf=r size=128 type=f align=32 words (r36.0)
//.declare V0180 (197)  rf=r size=128 type=f align=32 words (r38.0)
//.declare V0181 (198)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0182 (199)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0183 (200)  rf=r size=128 type=f align=32 words (r44.0)
//.declare V0184 (201)  rf=r size=128 type=f align=32 words (r52.0)
//.declare V0185 (202)  rf=r size=128 type=f align=32 words (r54.0)
//.declare V0186 (203)  rf=r size=128 type=f align=32 words (r56.0)
//.declare V0187 (204)  rf=r size=128 type=f align=32 words (r58.0)
//.declare V0188 (205)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0189 (206)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0190 (207)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0191 (208)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0192 (209)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0193 (210)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0195 (212)  rf=r size=128 type=f align=32 words (r46.0)
//.declare V0196 (213)  rf=r size=128 type=f align=32 words (r48.0)
//.declare V0197 (214)  rf=r size=128 type=f align=32 words (r50.0)
//.declare V0199 (216)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0200 (217)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0201 (218)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0202 (219)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0203 (220)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0205 (222)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0207 (224)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0210 (227)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0213 (230)  rf=r size=128 type=f align=32 words (r46.0)
//.declare V0214 (231)  rf=r size=128 type=f align=32 words (r84.0)
//.declare V0215 (232)  rf=r size=128 type=d align=32 words (r4.0)
//.declare  (234)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (235)  rf=r size=128 type=f align=32 words (r68.0)
//.declare  (236)  rf=r size=128 type=f align=32 words (r66.0)
//.declare  (237)  rf=r size=128 type=f align=32 words (r64.0)
//.declare  (238)  rf=r size=128 type=f align=32 words (r62.0)
//.declare  (239)  rf=r size=128 type=f align=32 words (r60.0)
//.declare  (240)  rf=r size=128 type=f align=32 words (r58.0)
//.declare  (241)  rf=r size=128 type=f align=32 words (r56.0)
//.declare  (242)  rf=r size=64 type=f align=32 words (r118.0)
//.declare  (243)  rf=r size=64 type=f align=32 words (r120.0)
//.declare  (244)  rf=r size=128 type=f align=32 words (r54.0)
//.declare V0217 (247)  rf=r size=128 type=f align=32 words (r88.0)
//.declare V0219 (249)  rf=r size=64 type=uw alias=V0103+0 align=32 words (r92.0)
//.declare V0220 (250)  rf=r size=128 type=d align=32 words (r94.0)
//.declare V0221 (251)  rf=r size=128 type=ud alias=V0220+0 align=32 words (r94.0)
//.declare V0222 (252)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (253)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (254)  rf=r size=128 type=f align=32 words (r52.0)
//.declare  (255)  rf=r size=128 type=f align=32 words (r50.0)
//.declare  (256)  rf=r size=128 type=f align=32 words (r48.0)
//.declare  (257)  rf=r size=128 type=f align=32 words (r46.0)
//.declare  (258)  rf=r size=128 type=f align=32 words (r44.0)
//.declare  (259)  rf=r size=64 type=f align=32 words (r119.0)
//.declare V0223 (262)  rf=r size=128 type=d alias=V0222+0 align=32 words (r6.0)
//.declare  (264)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0225 (265)  rf=r size=128 type=d align=32 words (r86.0)
//.declare  (267)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0227 (268)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0228 (269)  rf=r size=128 type=d align=32 words (r124.0)
//.declare P08 (270)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0229 (271)  rf=r size=128 type=ud alias=V0215+0 align=32 words (r4.0)
//.declare V0230 (272)  rf=r size=128 type=ud alias=V0228+0 align=32 words (r124.0)
//.declare V0231 (273)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0232 (274)  rf=r size=128 type=f alias=V0225+0 align=32 words (r86.0)
//.declare  (275)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (276)  rf=r size=128 type=f align=32 words (r42.0)
//.declare  (277)  rf=r size=128 type=f align=32 words (r40.0)
//.declare  (278)  rf=r size=128 type=f align=32 words (r38.0)
//.declare  (279)  rf=r size=128 type=f align=32 words (r36.0)
//.declare  (280)  rf=r size=128 type=f align=32 words (r34.0)
//.declare  (281)  rf=r size=128 type=f align=32 words (r32.0)
//.declare  (282)  rf=r size=128 type=f align=32 words (r30.0)
//.declare  (283)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0233 (286)  rf=r size=128 type=d align=32 words (r126.0)
//.declare V0234 (287)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0235 (288)  rf=r size=4 type=f align=2 words (r122.2)
//.declare V0236 (289)  rf=r size=4 type=ud alias=V0234+0 align=2 words (r2.8)
//.declare P09 (290)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0237 (291)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0238 (292)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0240 (294)  rf=r size=128 type=ud alias=V0238+0 align=32 words (r6.0)
//.declare V0244 (298)  rf=r size=256 type=uq align=32 words (r12.0)
//.declare V0246 (300)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0247 (301)  rf=r size=128 type=w alias=V0246+0 align=32 words (r16.0)
//.declare V0249 (303)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0250 (304)  rf=r size=128 type=f align=32 words (r90.0)
//.declare V0251 (305)  rf=r size=128 type=f alias=V0249+0 align=32 words (r18.0)
//.declare V0252 (306)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0254 (308)  rf=r size=128 type=ud alias=V0252+0 align=32 words (r20.0)
//.declare V0258 (312)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0259 (313)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0263 (317)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0265 (319)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0266 (320)  rf=r size=128 type=w alias=V0265+0 align=32 words (r14.0)
//.declare V0268 (322)  rf=r size=128 type=d alias=V0259+0 align=32 words (r76.0)
//.declare V0270 (324)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0271 (325)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0272 (326)  rf=r size=128 type=d alias=V0270+0 align=32 words (r70.0)
//.declare P10 (327)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0273 (328)  rf=r size=128 type=ud alias=V0271+0 align=32 words (r6.0)
//.declare V0274 (329)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0275 (330)  rf=r size=128 type=ud alias=V0270+0 align=32 words (r70.0)
//.declare V0276 (331)  rf=r size=128 type=ud alias=V0274+0 align=32 words (r6.0)
//.declare V0277 (332)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0278 (333)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0279 (334)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0280 (335)  rf=r size=128 type=ud alias=V0278+0 align=32 words (r10.0)
//.declare V0281 (336)  rf=r size=128 type=ud alias=V0279+0 align=32 words (r12.0)
//.declare V0282 (337)  rf=r size=64 type=w align=32 words (r82.0)
//.declare V0283 (338)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0284 (339)  rf=r size=128 type=ud alias=V0283+0 align=32 words (r6.0)
//.declare V0288 (343)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0289 (344)  rf=r size=64 type=uw alias=V0282+0 align=32 words (r82.0)
//.declare V0290 (345)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare P11 (346)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P12 (347)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0292 (349)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0293 (350)  rf=r size=256 type=ud alias=V0292+0 align=32 words (r6.0)
//.declare V0294 (351)  rf=r size=128 type=d align=32 words (r10.0)
//.declare  (352)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (353)  rf=r size=128 type=w alias=V0283+0 align=32 words (r6.0)
//.declare  (354)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (355)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (356)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (357)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (358)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare  (359)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (360)  rf=r size=128 type=w alias=V0279+0 align=32 words (r12.0)
//.declare  (365)  rf=r size=128 type=q align=32 words (r80.0)
//.declare  (366)  rf=r size=128 type=q align=32 words (r78.0)
//.declare  (369)  rf=r size=128 type=q align=32 words (r74.0)
//.declare  (370)  rf=r size=128 type=q align=32 words (r72.0)
//.declare  (371)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (372)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (375)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (376)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (381)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (382)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (383)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (384)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (385)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (386)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (387)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (388)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (389)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (390)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (391)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (392)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (393)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (394)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (395)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (396)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (397)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (398)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (399)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (400)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (401)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (402)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (403)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (404)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (405)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (406)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (407)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (408)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (409)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (410)  rf=r size=64 type=d align=32 words (r31.0)
//.declare  (411)  rf=r size=64 type=d align=32 words (r32.0)
//.declare  (412)  rf=r size=64 type=d align=32 words (r33.0)
//.declare  (413)  rf=r size=64 type=d align=32 words (r34.0)
//.declare  (414)  rf=r size=64 type=d align=32 words (r35.0)
//.declare  (415)  rf=r size=64 type=d align=32 words (r36.0)
//.declare  (416)  rf=r size=64 type=d align=32 words (r37.0)
//.declare  (417)  rf=r size=64 type=d align=32 words (r38.0)
//.declare  (418)  rf=r size=64 type=d align=32 words (r39.0)
//.declare  (419)  rf=r size=64 type=d align=32 words (r40.0)
//.declare  (420)  rf=r size=64 type=d align=32 words (r41.0)
//.declare  (421)  rf=r size=64 type=d align=32 words (r42.0)
//.declare  (422)  rf=r size=64 type=d align=32 words (r43.0)
//.declare  (423)  rf=r size=64 type=d align=32 words (r44.0)
//.declare  (424)  rf=r size=64 type=d align=32 words (r45.0)
//.declare  (425)  rf=r size=64 type=d align=32 words (r46.0)
//.declare  (426)  rf=r size=64 type=d align=32 words (r47.0)
//.declare  (427)  rf=r size=64 type=d align=32 words (r48.0)
//.declare  (428)  rf=r size=64 type=d align=32 words (r49.0)
//.declare  (429)  rf=r size=64 type=d align=32 words (r50.0)
//.declare  (430)  rf=r size=64 type=d align=32 words (r51.0)
//.declare  (431)  rf=r size=64 type=d align=32 words (r52.0)
//.declare  (432)  rf=r size=64 type=d align=32 words (r53.0)
//.declare  (433)  rf=r size=64 type=d align=32 words (r54.0)
//.declare  (434)  rf=r size=64 type=d align=32 words (r55.0)
//.declare  (435)  rf=r size=64 type=d align=32 words (r56.0)
//.declare  (436)  rf=r size=64 type=d align=32 words (r57.0)
//.declare  (437)  rf=r size=64 type=d align=32 words (r58.0)
//.declare  (438)  rf=r size=64 type=d align=32 words (r59.0)
//.declare  (439)  rf=r size=64 type=d align=32 words (r60.0)
//.declare  (440)  rf=r size=64 type=d align=32 words (r61.0)
//.declare  (441)  rf=r size=64 type=d align=32 words (r62.0)
//.declare  (442)  rf=r size=64 type=d align=32 words (r63.0)
//.declare  (443)  rf=r size=64 type=d align=32 words (r64.0)
//.declare  (444)  rf=r size=64 type=d align=32 words (r65.0)
//.declare  (445)  rf=r size=64 type=d align=32 words (r66.0)
//.declare  (446)  rf=r size=64 type=d align=32 words (r67.0)
//.declare  (447)  rf=r size=64 type=d align=32 words (r68.0)
//.declare  (448)  rf=r size=64 type=d align=32 words (r69.0)
//.declare  (449)  rf=r size=64 type=d align=32 words (r70.0)
//.declare  (450)  rf=r size=64 type=d align=32 words (r71.0)
//.declare  (451)  rf=r size=64 type=d align=32 words (r72.0)
//.declare  (452)  rf=r size=64 type=d align=32 words (r73.0)
//.declare  (453)  rf=r size=64 type=d align=32 words (r74.0)
//.declare  (454)  rf=r size=64 type=d align=32 words (r75.0)
//.declare  (455)  rf=r size=64 type=d align=32 words (r76.0)
//.declare  (456)  rf=r size=64 type=d align=32 words (r77.0)
//.declare  (457)  rf=r size=64 type=d align=32 words (r78.0)
//.declare  (458)  rf=r size=64 type=d align=32 words (r79.0)
//.declare  (459)  rf=r size=64 type=d align=32 words (r80.0)
//.declare  (460)  rf=r size=64 type=d align=32 words (r81.0)
//.declare  (461)  rf=r size=64 type=d align=32 words (r82.0)
//.declare  (462)  rf=r size=64 type=d align=32 words (r83.0)
//.declare  (463)  rf=r size=64 type=d align=32 words (r84.0)
//.declare  (464)  rf=r size=64 type=d align=32 words (r85.0)
//.declare  (465)  rf=r size=64 type=d align=32 words (r86.0)
//.declare  (466)  rf=r size=64 type=d align=32 words (r87.0)
//.declare  (467)  rf=r size=64 type=d align=32 words (r88.0)
//.declare  (468)  rf=r size=64 type=d align=32 words (r89.0)
//.declare  (469)  rf=r size=64 type=d align=32 words (r90.0)
//.declare  (470)  rf=r size=64 type=d align=32 words (r91.0)
//.declare  (471)  rf=r size=64 type=d align=32 words (r92.0)
//.declare  (472)  rf=r size=64 type=d align=32 words (r93.0)
//.declare  (473)  rf=r size=64 type=d align=32 words (r94.0)
//.declare  (474)  rf=r size=64 type=d align=32 words (r95.0)
//.declare  (475)  rf=r size=64 type=d align=32 words (r96.0)
//.declare  (476)  rf=r size=64 type=d align=32 words (r97.0)
//.declare  (477)  rf=r size=64 type=d align=32 words (r98.0)
//.declare  (478)  rf=r size=64 type=d align=32 words (r99.0)
//.declare  (479)  rf=r size=64 type=d align=32 words (r100.0)
//.declare  (480)  rf=r size=64 type=d align=32 words (r101.0)
//.declare  (481)  rf=r size=64 type=d align=32 words (r102.0)
//.declare  (482)  rf=r size=64 type=d align=32 words (r103.0)
//.declare  (483)  rf=r size=64 type=d align=32 words (r104.0)
//.declare  (484)  rf=r size=64 type=d align=32 words (r105.0)
//.declare  (485)  rf=r size=64 type=d align=32 words (r106.0)
//.declare  (486)  rf=r size=64 type=d align=32 words (r107.0)
//.declare  (487)  rf=r size=64 type=d align=32 words (r108.0)
//.declare  (488)  rf=r size=64 type=d align=32 words (r109.0)
//.declare  (489)  rf=r size=64 type=d align=32 words (r110.0)
//.declare  (490)  rf=r size=64 type=d align=32 words (r111.0)
//.declare r0 (491)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (492)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (493)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (494)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (495)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (496)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (497)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0034    | :uq      |    0x8 | r2+0x18  | inline+0x18      |
// | V0043    | :d       |    0x4 | r3       | cti+0x20         |
// | V0044    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0051    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0052    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0053    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0054    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0055    | :q       |    0x8 | r4       | cti+0x60         |
// | V0056    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0057    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0058    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0059    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0060    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0061    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0062    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0063    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0064    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0065    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0066    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0067    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0068    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0069    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B030}
// _main:
(W)     mov (16|M0)              r112.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r119.0<1>:f   0x3F000000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r120.0<1>:f   0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r118.0<1>:f   0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r112.2<0;1,0>:uw {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r3.0<1>:d     r2.3<0;1,0>:d     r112.1<0;1,0>:d  {Compacted,$1.dst} //  ALU pipe: int; $4
(W)     shl (1|M0)               r2.8<1>:d     r3.1<0;1,0>:d     2:w                                 //  ALU pipe: int; $5
        add3 (32|M0)             r114.0<1>:d   r3.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {@2,$0.dst} //  ALU pipe: int; $4
(W)     asr (1|M0)               r2.9<1>:d     r2.8<0;1,0>:d     31:w               {I@2}            //  ALU pipe: int; $6
(W)     mul (1|M0)               r2.10<1>:ud   r2.8<0;1,0>:ud    0x280:uw                            //  ALU pipe: int; $7
(W)     mul (1|M0)               acc0.0<1>:ud  r2.8<0;1,0>:ud    0x280:uw                            //  ALU pipe: int; $8
(W)     mul (1|M0)               r4.1<1>:d     r2.9<0;1,0>:d     0x280:uw              {I@3}         //  ALU pipe: int; $11
(W)     mach (1|M0)              r4.0<1>:d     r2.8<0;1,0>:ud    0x280:ud                            //  ALU pipe: int; 
        cmp (32|M0)   (gt)f1.0   null<1>:ud    r2.10<0;1,0>:ud   r114.0<1;1,0>:ud {I@4}              //  ALU pipe: int; $14
(W)     add (1|M0)               r5.0<1>:d     r4.0<0;1,0>:d     r4.1<0;1,0>:d    {Compacted,@2,$2.dst} //  ALU pipe: int; $13
(f1.0)  cmp (32|M0)   (eq)f1.0   null<1>:d     r5.0<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $15
(~f1.0) cmp (32|M0)   (gt)f1.0   null<1>:ud    r5.0<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $17
(~f1.0) goto (32|M0)                         _0_023            _0_023                                //  ALU pipe: int; $19
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B030}
_0_024:
(W)     mov (1|M0)               r4.0<1>:uq    r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $21
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $22
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $23
(f3.0)  goto (32|M0)                         _0_023            _0_023                                //  ALU pipe: int; $24
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B030}
_0_025:
(W)     mov (1|M0)               r122.0<1>:uq  r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $26
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $29
        mov (16|M0)              r6.0<2>:f     r122.0<0;1,0>:f                  {I@2}                //  ALU pipe: float; $27
        mov (16|M16)             r8.0<2>:f     r122.0<0;1,0>:f                                       //  ALU pipe: float; $27
        mov (16|M0)              r6.1<2>:f     r122.1<0;1,0>:f                                       //  ALU pipe: float; $28
        mov (16|M16)             r8.1<2>:ud    r122.1<0;1,0>:ud                 {F@2}                //  ALU pipe: int; $28
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$4} // ex_desc:0x0; desc:0x8200599 // $30
        cmp (32|M0)   (eq)f2.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$4.dst}          //  ALU pipe: int; $32
(~f2.0) goto (32|M0)                         _0_023            _0_023                                //  ALU pipe: int; $33
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B028}
_0_026:
(W)     mov (1|M0)               r4.0<1>:uq    r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $35
(W)     add (1|M0)               r2.8<1>:d     r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $37
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$5} // ex_desc:0x0; desc:0x2108580 // $36
(W)     cmp (32|M0)   (gt)f2.0   null<1>:d     r3.0<0;1,0>:d     r2.8<0;1,0>:d    {$5.dst}           //  ALU pipe: int; $38
(W&~f2.0) cmp (32|M0) (lt)f2.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $39
(W&f2.0) jmpi                                _0_027                                                  //  ALU pipe: int; $41
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_028:
(W)     mul (16|M0)              acc0.0<1>:ud  r114.0<1;1,0>:ud  0xCCCD:uw                           //  ALU pipe: int; $46
        mach (16|M0)             r6.0<1>:ud    r114.0<1;1,0>:ud  0xCCCCCCCD:ud                       //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r115.0<1;1,0>:ud  0xCCCD:uw                           //  ALU pipe: int; $46
        mach (16|M16)            r7.0<1>:ud    r115.0<1;1,0>:ud  0xCCCCCCCD:ud                       //  ALU pipe: int; $47
        shr (32|M0)              r116.0<1>:ud  r6.0<1;1,0>:ud    9:w               {I@1}             //  ALU pipe: int; $47
        mul (32|M0)              r8.0<1>:d     r116.0<1;1,0>:d   320:w               {Compacted,I@1} //  ALU pipe: int; $49
        mov (16|M16)             r10.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $51
        mov (16|M0)              r12.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $51
        add (16|M16)             r16.0<1>:q    r2.3<0;1,0>:q     r10.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $51
        add (16|M0)              r14.0<1>:q    r2.3<0;1,0>:q     r12.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $51
        load.ugm.d32x4.a64 (32|M0)  r18:8       [r14:4]            {I@1,$6} // ex_desc:0x0; desc:0x8803580 // $52
        load.ugm.d32x4.a64 (32|M0)  r34:8       [r14:4+0x20]       {$7} // ex_desc:0x20000; desc:0x8803580 // $54
        load.ugm.d32x4.a64 (32|M0)  r42:8       [r14:4+0x30]       {$8} // ex_desc:0x30000; desc:0x8803580 // $55
        load.ugm.d32x4.a64 (32|M0)  r50:8       [r14:4+0x40]       {$9} // ex_desc:0x40000; desc:0x8803580 // $56
        load.ugm.d32x4.a64 (32|M0)  r58:8       [r14:4+0x50]       {$10} // ex_desc:0x50000; desc:0x8803580 // $57
        load.ugm.d32x4.a64 (32|M0)  r66:8       [r14:4+0x60]       {$11} // ex_desc:0x60000; desc:0x8803580 // $58
        load.ugm.d32x4.a64 (32|M0)  r74:8       [r14:4+0x70]       {$12} // ex_desc:0x70000; desc:0x8803580 // $59
        load.ugm.d32x4.a64 (32|M0)  r26:8       [r14:4+0x10]       {$13} // ex_desc:0x10000; desc:0x8803580 // $53
        load.ugm.d32x4.a64 (32|M0)  r82:8       [r14:4+0x80]       {$14} // ex_desc:0x80000; desc:0x8803580 // $60
(W)     mov (1|M0)               f0.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $153
        add (32|M0)              r6.0<1>:f     r22.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted,$6.dst} //  ALU pipe: float; $73
        add (32|M0)              r8.0<1>:f     r18.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $72
        add (32|M0)              r90.0<1>:f    r38.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted,$7.dst} //  ALU pipe: float; $77
        add (32|M0)              r92.0<1>:f    r34.0<1;1,0>:f    r36.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $76
        add (32|M0)              r94.0<1>:f    r46.0<1;1,0>:f    r48.0<1;1,0>:f   {Compacted,$8.dst} //  ALU pipe: float; $79
        add (32|M0)              r96.0<1>:f    r42.0<1;1,0>:f    r44.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $78
        add (32|M0)              r98.0<1>:f    r54.0<1;1,0>:f    r56.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $81
        add (32|M0)              r100.0<1>:f   r50.0<1;1,0>:f    r52.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $80
        add (32|M0)              r102.0<1>:f   r62.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted,$10.dst} //  ALU pipe: float; $83
        add (32|M0)              r104.0<1>:f   r58.0<1;1,0>:f    r60.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $82
        add (32|M0)              r106.0<1>:f   r70.0<1;1,0>:f    r72.0<1;1,0>:f   {Compacted,$11.dst} //  ALU pipe: float; $85
        add (32|M0)              r18.0<1>:f    r66.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $84
        add (32|M0)              r20.0<1>:f    r78.0<1;1,0>:f    r80.0<1;1,0>:f   {Compacted,$12.dst} //  ALU pipe: float; $87
        add (32|M0)              r22.0<1>:f    r74.0<1;1,0>:f    r76.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $86
        add (32|M0)              r12.0<1>:f    r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,$13.dst} //  ALU pipe: float; $74
        add (32|M0)              r10.0<1>:f    r30.0<1;1,0>:f    r32.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $75
        add (32|M0)              r24.0<1>:f    r86.0<1;1,0>:f    r88.0<1;1,0>:f   {Compacted,$14.dst} //  ALU pipe: float; $89
        add (32|M0)              r26.0<1>:f    r82.0<1;1,0>:f    r84.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $88
        add (32|M0)              r34.0<1>:f    r96.0<1;1,0>:f    r94.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $115
        add (32|M0)              r36.0<1>:f    r100.0<1;1,0>:f   r98.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $116
        add (32|M0)              r38.0<1>:f    r104.0<1;1,0>:f   r102.0<1;1,0>:f  {Compacted,F@7}    //  ALU pipe: float; $117
        add (32|M0)              r40.0<1>:f    r18.0<1;1,0>:f    r106.0<1;1,0>:f  {Compacted,F@7}    //  ALU pipe: float; $118
        add (32|M0)              r42.0<1>:f    r22.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $119
        add (32|M0)              r32.0<1>:f    r92.0<1;1,0>:f    r90.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $114
        add (32|M0)              r44.0<1>:f    r26.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $120
        load.ugm.d32x4.a64 (32|M0)  r18:8       [r14:4+0xD0]       {F@1,$15} // ex_desc:0xD0000; desc:0x8803580 // $65
        add (32|M0)              r50.0<1>:f    r36.0<1;1,0>:f    r38.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $134
        add (32|M0)              acc2.0<1>:f   r40.0<1;1,0>:f    r42.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $135
        add (32|M0)              r48.0<1>:f    r32.0<1;1,0>:f    r34.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $133
        load.ugm.d32x4.a64 (32|M0)  r34:8       [r14:4+0x110]      {F@1,$0} // ex_desc:0x110000; desc:0x8803580 // $69
        load.ugm.d32x4.a64 (32|M0)  r60:8       [r14:4+0xA0]       {$1} // ex_desc:0xA0000; desc:0x8803580 // $62
        load.ugm.d32x4.a64 (32|M0)  r68:8       [r14:4+0xB0]       {$2} // ex_desc:0xB0000; desc:0x8803580 // $63
        add (32|M0)              r28.0<1>:f    r8.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted}        //  ALU pipe: float; $112
        add (32|M0)              r30.0<1>:f    r12.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $113
        load.ugm.d32x4.a64 (32|M0)  r52:8       [r14:4+0x90]       {$3} // ex_desc:0x90000; desc:0x8803580 // $61
        add (32|M0)              r46.0<1>:f    r28.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $132
        load.ugm.d32x4.a64 (32|M0)  r76:8       [r14:4+0xC0]       {$4} // ex_desc:0xC0000; desc:0x8803580 // $64
        load.ugm.d32x4.a64 (32|M0)  r84:8       [r14:4+0xE0]       {$5} // ex_desc:0xE0000; desc:0x8803580 // $66
        load.ugm.d32x4.a64 (32|M0)  r26:8       [r14:4+0xF0]       {F@1,$6} // ex_desc:0xF0000; desc:0x8803580 // $67
        add (32|M0)              r6.0<1>:f     r46.0<1;1,0>:f    r48.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $142
        add (32|M0)              acc2.0<1>:f   r50.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $143
        add (32|M0)              r102.0<1>:f   r22.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted,$15.dst} //  ALU pipe: float; $99
        load.ugm.d32x4.a64 (32|M0)  r92:8       [r14:4+0x100]      {$7} // ex_desc:0x100000; desc:0x8803580 // $68
        add (32|M0)              r8.0<1>:f     r6.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $147
        add (32|M0)              r22.0<1>:f    r38.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted,$0.dst} //  ALU pipe: float; $107
        add (32|M0)              r24.0<1>:f    r34.0<1;1,0>:f    r36.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $106
        load.ugm.d32x4.a64 (32|M0)  r34:8       [r14:4+0x120]      {F@1,$8} // ex_desc:0x120000; desc:0x8803580 // $70
        add (32|M0)              r46.0<1>:f    r72.0<1;1,0>:f    r74.0<1;1,0>:f   {Compacted,$2.dst} //  ALU pipe: float; $95
        add (32|M0)              r48.0<1>:f    r68.0<1;1,0>:f    r70.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $94
        add (32|M0)              r6.0<1>:f     r64.0<1;1,0>:f    r66.0<1;1,0>:f   {Compacted,$1.dst} //  ALU pipe: float; $93
        load.ugm.d32x4.a64 (32|M0)  r66:8       [r14:4+0x130]      {F@1,$9} // ex_desc:0x130000; desc:0x8803580 // $71
        add (32|M0)              r42.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $92
        add (32|M0)              r10.0<1>:f    r56.0<1;1,0>:f    r58.0<1;1,0>:f   {Compacted,$3.dst} //  ALU pipe: float; $91
        add (32|M0)              r12.0<1>:f    r52.0<1;1,0>:f    r54.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $90
        add (32|M0)              r104.0<1>:f   r18.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $98
        add (32|M0)              r50.0<1>:f    r80.0<1;1,0>:f    r82.0<1;1,0>:f   {Compacted,$4.dst} //  ALU pipe: float; $97
        add (32|M0)              r100.0<1>:f   r76.0<1;1,0>:f    r78.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $96
        add (32|M0)              r106.0<1>:f   r88.0<1;1,0>:f    r90.0<1;1,0>:f   {Compacted,$5.dst} //  ALU pipe: float; $101
        add (32|M0)              r108.0<1>:f   r84.0<1;1,0>:f    r86.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $100
        add (32|M0)              r110.0<1>:f   r30.0<1;1,0>:f    r32.0<1;1,0>:f   {Compacted,$6.dst} //  ALU pipe: float; $103
        add (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $102
        add (32|M0)              r56.0<1>:f    r48.0<1;1,0>:f    r46.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $123
        add (32|M0)              r52.0<1>:f    r12.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $121
        add (32|M0)              r54.0<1>:f    r42.0<1;1,0>:f    r6.0<1;1,0>:f    {Compacted}        //  ALU pipe: float; $122
        add (32|M0)              r60.0<1>:f    r104.0<1;1,0>:f   r102.0<1;1,0>:f  {Compacted,F@7}    //  ALU pipe: float; $125
        add (32|M0)              r58.0<1>:f    r100.0<1;1,0>:f   r50.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $124
        add (32|M0)              r62.0<1>:f    r108.0<1;1,0>:f   r106.0<1;1,0>:f  {Compacted,F@7}    //  ALU pipe: float; $126
        add (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r110.0<1;1,0>:f  {Compacted,F@7}    //  ALU pipe: float; $127
        add (32|M0)              r26.0<1>:f    r44.0<1;1,0>:f    r52.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $136
        add (32|M0)              r10.0<1>:f    r54.0<1;1,0>:f    r56.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $137
        add (32|M0)              r6.0<1>:f     r58.0<1;1,0>:f    r60.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $138
        add (32|M0)              r12.0<1>:f    r62.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $139
        add (32|M0)              r32.0<1>:f    r26.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $144 R{} IR{}{E:5,E:5,},  R{} IR{}{O:13,O:5,},  {BC=1}
        add (32|M0)              acc2.0<1>:f   r6.0<1;1,0>:f     r12.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $145
        add (32|M0)              acc2.0<1>:f   r32.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $148
        add (32|M0)              r18.0<1>:f    r96.0<1;1,0>:f    r98.0<1;1,0>:f   {Compacted,$7.dst} //  ALU pipe: float; $105
        add (32|M0)              r20.0<1>:f    r92.0<1;1,0>:f    r94.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $104
        add (32|M0)              r46.0<1>:f    r8.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $150
        add (32|M0)              r6.0<1>:f     r38.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted,$8.dst} //  ALU pipe: float; $109
        add (32|M0)              r8.0<1>:f     r34.0<1;1,0>:f    r36.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $108
        add (32|M0)              r10.0<1>:f    r70.0<1;1,0>:f    r72.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $111
        add (32|M0)              r30.0<1>:f    r24.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $129
        add (32|M0)              r28.0<1>:f    r20.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $128
        add (32|M0)              acc2.0<1>:f   r66.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $110
        add (32|M0)              r12.0<1>:f    r8.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted,F@5}    //  ALU pipe: float; $130
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $131
        add (32|M0)              r42.0<1>:f    r28.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $140
        add (32|M0)              acc2.0<1>:f   r12.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $141
        add (32|M0)              acc2.0<1>:f   r42.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $146
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   0x0:f               {Compacted}     //  ALU pipe: float; $149
(W)     mov (8|M0)               r92.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $43
        mad (32|M0)              r18.0<1>:d    r114.0<1;0>:d     r116.0<1;0>:d     -640:w               //  ALU pipe: int; $48
        add (32|M0)              r84.0<1>:f    r46.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $151
(W)     mov (32|M0)              r54.0<1>:ud   0x45200000:ud                                         //  ALU pipe: int; $153
(W)     add (8|M0)               r92.8<1>:w    r92.0<1;1,0>:w    8:w               {I@3}             //  ALU pipe: int; $44
        shl (32|M0)              r4.0<1>:d     r18.0<1;1,0>:d    2:w               {Compacted,I@3}   //  ALU pipe: int; $152
(W)     add (16|M0)              r92.16<1>:w   r92.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $45
        math.invm (16|M0) (eo)f0.0  r62.mme0:f  r84.nomme<1;1,0>:f  r54.nomme<1;1,0>:f {F@1}         //  ALU pipe: math; $153
(f0.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $153
// B007: [inDivergent],  Preds:{B006},  Succs:{B008}
_L_k0_6_:
        madm (16|M0)             r60.mme1:f    r118.nomme:f      r84.nomme:f       r62.mme0:f       {M@1} //  ALU pipe: float; $153 R{} IR{}{E:3,E:2,E:7,},  {BC=1}
        madm (16|M0)             r58.mme2:f    r120.nomme:f      -r54.nomme:f      r62.mme0:f        //  ALU pipe: float; $153
        madm (16|M0)             r68.mme3:f    r62.mme0:f        r58.mme2:f        r62.mme0:f       {F@1} //  ALU pipe: float; $153
        madm (16|M0)             r56.mme4:f    r84.nomme:f       -r54.nomme:f      r60.mme1:f        //  ALU pipe: float; $153 R{} IR{}{E:2,E:3,E:6,},  {BC=1}
        madm (16|M0)             r60.mme5:f    r60.mme1:f        r56.mme4:f        r68.mme3:f       {F@1} //  ALU pipe: float; $153 R{} IR{}{E:6,E:4,E:2,},  {BC=1}
        madm (16|M0)             r64.mme6:f    r84.nomme:f       -r54.nomme:f      r60.mme5:f       {F@1} //  ALU pipe: float; $153 R{} IR{}{E:2,E:3,E:6,},  {BC=1}
        madm (16|M0)             r62.nomme:f   r60.mme5:f        r64.mme6:f        r68.mme3:f       {F@1} //  ALU pipe: float; $153 R{} IR{}{E:6,E:0,E:2,},  {BC=1}
// B008: [inDivergent],  Preds:{B007, B006},  Succs:{B009, B010}
_L_k0_0_macro:
        join (32|M0)                         _0_023                                                  // 
L2080:
(W)     mov (1|M0)               f0.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $153
        math.invm (16|M16) (eo)f0.0  r63.mme0:f  r85.nomme<1;1,0>:f  r55.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $153
(f0.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $153
// B009: [inDivergent],  Preds:{B008},  Succs:{B010}
_L_k0_7_:
        madm (16|M16)            r61.mme1:f    r118.nomme:f      r85.nomme:f       r63.mme0:f       {M@1} //  ALU pipe: float; $153
        madm (16|M16)            r59.mme2:f    r120.nomme:f      -r55.nomme:f      r63.mme0:f        //  ALU pipe: float; $153
        madm (16|M16)            r69.mme3:f    r63.mme0:f        r59.mme2:f        r63.mme0:f       {F@1} //  ALU pipe: float; $153
        madm (16|M16)            r57.mme4:f    r85.nomme:f       -r55.nomme:f      r61.mme1:f        //  ALU pipe: float; $153 R{} IR{}{O:2,O:3,O:6,},  {BC=1}
        madm (16|M16)            r61.mme5:f    r61.mme1:f        r57.mme4:f        r69.mme3:f       {F@1} //  ALU pipe: float; $153 R{} IR{}{O:6,O:4,O:2,},  {BC=1}
        madm (16|M16)            r65.mme6:f    r85.nomme:f       -r55.nomme:f      r61.mme5:f       {F@1} //  ALU pipe: float; $153 R{} IR{}{O:2,O:3,O:6,},  {BC=1}
        madm (16|M16)            r63.nomme:f   r61.mme5:f        r65.mme6:f        r69.mme3:f       {F@1} //  ALU pipe: float; $153 R{} IR{}{O:6,O:0,O:2,},  {BC=1}
// B010: [inDivergent],  Preds:{B009, B008},  Succs:{B011, B012}
_L_k0_1_macro:
        join (32|M0)                         _0_023                                                  // 
L2256:
        add (32|M0)              r88.0<1>:f    r62.0<1;1,0>:f    0x358637BD:f               {F@1}    //  ALU pipe: float; $154
        shl (32|M0)              r94.0<1>:d    r92.0<1;1,0>:uw   2:w                                 //  ALU pipe: int; $156
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $157
        math.rsqtm (16|M0) (eo)f3.0  r50.mme0:f  r88.nomme<1;1,0>:f             {A@1}                //  ALU pipe: math; $157
(f3.0)  goto (32|M0)                         _L_k0_2_macro     _L_k0_2_macro                         //  ALU pipe: int; $157
// B011: [inDivergent],  Preds:{B010},  Succs:{B012}
_L_k0_8_:
        madm (16|M0)             r48.mme1:f    r118.nomme:f      r119.nomme:f      r50.mme0:f       {M@1} //  ALU pipe: float; $157
        madm (16|M0)             r44.mme2:f    r118.nomme:f      r88.nomme:f       r50.mme0:f        //  ALU pipe: float; $157
        madm (16|M0)             r46.mme3:f    r119.nomme:f      -r44.mme2:f       r48.mme1:f       {F@1} //  ALU pipe: float; $157
        madm (16|M0)             r48.mme4:f    r48.mme1:f        r46.mme3:f        r48.mme1:f       {F@1} //  ALU pipe: float; $157
        madm (16|M0)             r50.mme5:f    r44.mme2:f        r46.mme3:f        r44.mme2:f        //  ALU pipe: float; $157
        madm (16|M0)             r46.mme6:f    r88.nomme:f       -r50.mme5:f       r50.mme5:f       {F@1} //  ALU pipe: float; $157
        madm (16|M0)             r50.nomme:f   r50.mme5:f        r48.mme4:f        r46.mme6:f       {F@1} //  ALU pipe: float; $157 R{} IR{}{E:1,E:0,E:7,},  {BC=1}
// B012: [inDivergent],  Preds:{B011, B010},  Succs:{B013, B014}
_L_k0_2_macro:
        join (32|M0)                         _0_023                                                  // 
L2464:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $157
        math.rsqtm (16|M16) (eo)f3.0  r51.mme0:f  r89.nomme<1;1,0>:f            {I@1}                //  ALU pipe: math; $157
(f3.0)  goto (32|M0)                         _L_k0_3_macro     _L_k0_3_macro                         //  ALU pipe: int; $157
// B013: [inDivergent],  Preds:{B012},  Succs:{B014}
_L_k0_9_:
        madm (16|M16)            r49.mme1:f    r118.nomme:f      r119.nomme:f      r51.mme0:f       {M@1} //  ALU pipe: float; $157
        madm (16|M16)            r45.mme2:f    r118.nomme:f      r89.nomme:f       r51.mme0:f        //  ALU pipe: float; $157
        madm (16|M16)            r47.mme3:f    r119.nomme:f      -r45.mme2:f       r49.mme1:f       {F@1} //  ALU pipe: float; $157 R{} IR{}{O:3,O:6,O:0,},  {BC=1}
        madm (16|M16)            r49.mme4:f    r49.mme1:f        r47.mme3:f        r49.mme1:f       {F@1} //  ALU pipe: float; $157
        madm (16|M16)            r51.mme5:f    r45.mme2:f        r47.mme3:f        r45.mme2:f        //  ALU pipe: float; $157
        madm (16|M16)            r47.mme6:f    r89.nomme:f       -r51.mme5:f       r51.mme5:f       {F@1} //  ALU pipe: float; $157
        madm (16|M16)            r51.nomme:f   r51.mme5:f        r49.mme4:f        r47.mme6:f       {F@1} //  ALU pipe: float; $157 R{} IR{}{O:1,O:0,O:7,},  {BC=1}
// B014: [inDivergent],  Preds:{B013, B012},  Succs:{B015, B030}
_L_k0_3_macro:
        join (32|M0)                         _0_023                                                  // 
L2640:
(W)     shr (1|M0)               a0.0<1>:ud    r112.5<0;1,0>:ud  0x4:uw              {F@1}           //  ALU pipe: int; $158
        mov (32|M0)              r6.0<1>:f     r50.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $157
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r94:2] r6:2      {F@1,$10} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $159
        sel (32|M0)   (lt)f0.0   r8.0<1>:d     r4.0<1;1,0>:d     2556:w                              //  ALU pipe: int; $162
        add (32|M0)              r124.0<1>:d   r8.0<1;1,0>:d     4:w               {Compacted,I@1}   //  ALU pipe: int; $163
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r4.0<1;1,0>:ud    r124.0<1;1,0>:ud {I@1}              //  ALU pipe: int; $164
        load.ugm.d32.a32.ca.ca (32|M0)  r86:2   ss[a0.0][r94:2]    {$11} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $161
(~f1.0) goto (32|M0)                         _0_023            _0_023                                //  ALU pipe: int; $165
// B015: [inDivergent],  Preds:{B014},  Succs:{B016, B017}
_0_029:
(W)     mov (32|M0)              r28.0<1>:f    0x3F800000:f                                          //  ALU pipe: float; $167
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $167
        math.invm (16|M0) (eo)f2.0  r36.mme0:f  r28.nomme<1;1,0>:f  r86.nomme<1;1,0>:f {A@1,$11.dst} //  ALU pipe: math; $167
(f2.0)  goto (32|M0)                         _L_k0_4_macro     _L_k0_4_macro                         //  ALU pipe: int; $167
// B016: [inDivergent],  Preds:{B015},  Succs:{B017}
_L_k0_10_:
        madm (16|M0)             r34.mme1:f    r118.nomme:f      r28.nomme:f       r36.mme0:f       {M@1} //  ALU pipe: float; $167 R{} IR{}{E:3,E:6,E:2,},  {BC=1}
        madm (16|M0)             r32.mme2:f    r120.nomme:f      -r86.nomme:f      r36.mme0:f        //  ALU pipe: float; $167
        madm (16|M0)             r42.mme3:f    r36.mme0:f        r32.mme2:f        r36.mme0:f       {F@1} //  ALU pipe: float; $167
        madm (16|M0)             r30.mme4:f    r28.nomme:f       -r86.nomme:f      r34.mme1:f        //  ALU pipe: float; $167 R{} IR{}{E:6,E:3,E:1,},  {BC=1}
        madm (16|M0)             r34.mme5:f    r34.mme1:f        r30.mme4:f        r42.mme3:f       {F@1} //  ALU pipe: float; $167 R{} IR{}{E:1,E:7,E:5,},  {BC=1}
        madm (16|M0)             r38.mme6:f    r28.nomme:f       -r86.nomme:f      r34.mme5:f       {F@1} //  ALU pipe: float; $167 R{} IR{}{E:6,E:3,E:1,},  {BC=1}
        madm (16|M0)             r36.nomme:f   r34.mme5:f        r38.mme6:f        r42.mme3:f       {F@1} //  ALU pipe: float; $167 R{} IR{}{E:1,E:3,E:5,},  {BC=1}
// B017: [inDivergent],  Preds:{B016, B015},  Succs:{B018, B019}
_L_k0_4_macro:
        join (32|M0)                         _0_023                                                  // 
L2944:
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $167
        math.invm (16|M16) (eo)f2.0  r37.mme0:f  r29.nomme<1;1,0>:f  r87.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $167
(f2.0)  goto (32|M0)                         _L_k0_5_macro     _L_k0_5_macro                         //  ALU pipe: int; $167
// B018: [inDivergent],  Preds:{B017},  Succs:{B019}
_L_k0_11_:
        madm (16|M16)            r35.mme1:f    r118.nomme:f      r29.nomme:f       r37.mme0:f       {M@1} //  ALU pipe: float; $167
        madm (16|M16)            r33.mme2:f    r120.nomme:f      -r87.nomme:f      r37.mme0:f        //  ALU pipe: float; $167
        madm (16|M16)            r43.mme3:f    r37.mme0:f        r33.mme2:f        r37.mme0:f       {F@1} //  ALU pipe: float; $167
        madm (16|M16)            r31.mme4:f    r29.nomme:f       -r87.nomme:f      r35.mme1:f        //  ALU pipe: float; $167 R{} IR{}{O:6,O:3,O:1,},  {BC=1}
        madm (16|M16)            r35.mme5:f    r35.mme1:f        r31.mme4:f        r43.mme3:f       {F@1} //  ALU pipe: float; $167 R{} IR{}{O:1,O:7,O:5,},  {BC=1}
        madm (16|M16)            r39.mme6:f    r29.nomme:f       -r87.nomme:f      r35.mme5:f       {F@1} //  ALU pipe: float; $167 R{} IR{}{O:6,O:3,O:1,},  {BC=1}
        madm (16|M16)            r37.nomme:f   r35.mme5:f        r39.mme6:f        r43.mme3:f       {F@1} //  ALU pipe: float; $167 R{} IR{}{O:1,O:3,O:5,},  {BC=1}
// B019: [inDivergent],  Preds:{B018, B017},  Succs:{B020}
_L_k0_5_macro:
        join (32|M0)                         _0_023                                                  // 
L3120:
(W)     and (1|M0)               r3.0<1>:d     r3.5<0;1,0>:d     8:w                                 //  ALU pipe: int; $171
        mov (32|M0)              r26.0<1>:f    r36.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $167
        and (32|M0)              r126.0<1>:d   r116.0<1;1,0>:d   3:w               {Compacted}       //  ALU pipe: int; $168
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w               {I@2}             //  ALU pipe: int; $172
(W)     and (1|M0)               r2.8<1>:d     r3.5<0;1,0>:d     1:w                                 //  ALU pipe: int; $169
(W)     mov (1|M0)               r122.2<1>:f   r2.8<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $170
// B020: [inDivergent],  Preds:{B026, B019},  Succs:{B021, B022}
_0_030:
        sync.nop                             null                             {Compacted,$12.src}    // $174
        mad (32|M0)              r6.0<1>:d     r4.0<1;0>:d       r116.0<1;0>:d     2560:w               {$10.src} //  ALU pipe: int; $174 R{} IR{}{E:2,E:2,},  R{} IR{}{O:2,O:10,},  {BC=1}
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $176
        mov (16|M16)             r10.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $176
        shl (16|M0)              r80.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $176
        shl (16|M16)             r78.0<1>:q    r10.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $176
        add (16|M0)              r12.0<1>:q    r80.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $177
        add (16|M16)             r14.0<1>:q    r78.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $177
        load.ugm.d16u32.a64 (32|M0)  r16:2      [r12:4]            {I@1,$13} // ex_desc:0x0; desc:0x8200B80 // $179
        mad (32|M0)              r20.0<1>:d    r4.0<1;0>:d       r126.0<1;0>:d     2560:w               //  ALU pipe: int; $182
        mov (16|M0)              r22.0<2>:ud   r20.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $183
        mov (16|M16)             r24.0<2>:ud   r21.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $183
        mov (16|M0)              r74.0<1>:q    r22.0<2;1,0>:ud                  {I@2}                //  ALU pipe: int; $183
        mov (16|M16)             r72.0<1>:q    r24.0<2;1,0>:ud                  {I@2}                //  ALU pipe: int; $183
        shl (32|M0)              r18.0<1>:d    r16.0<1;1,0>:ud   16:w               {$13.dst}        //  ALU pipe: int; $180
        mul (32|M0)              r90.0<1>:f    r26.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,A@1}    //  ALU pipe: float; $181
(W&f3.0) jmpi                                _0_031                                                  //  ALU pipe: int; $184
// B021: [inDivergent],  Preds:{B020},  Succs:{B023}
_0_032:
        shl (16|M0)              r6.0<1>:q     r74.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $186
        shl (16|M16)             r8.0<1>:q     r72.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $186
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $187
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $187
        load.ugm.d32.a64 (32|M0)  r76:2         [r10:4]            {I@1,$14} // ex_desc:0x0; desc:0x8200580 // $189
(W)     jmpi                                 _0_033                                                  // $190
// B022: [inDivergent],  Preds:{B020},  Succs:{B023}
_0_031:
        shl (16|M0)              r6.0<1>:q     r74.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $192
        shl (16|M16)             r8.0<1>:q     r72.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $192
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $193
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $193
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r10:4]            {I@1,$15} // ex_desc:0x0; desc:0x8200B80 // $195
        shl (32|M0)              r76.0<1>:d    r14.0<1;1,0>:ud   16:w               {$15.dst}        //  ALU pipe: int; $196
// B023: [inDivergent],  Preds:{B022, B021},  Succs:{B024, B025}
_0_033:
        add (32|M0)              acc0.0<1>:f   r76.0<1;1,0>:f    r122.2<0;1,0>:f  {Compacted,A@1,$14.dst} //  ALU pipe: float; $198
        mul (32|M0)              r70.0<1>:f    r90.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $199
        and (32|M0)              r6.0<1>:d     r70.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $200
        cmp (32|M0)   (gt)f1.0   null<1>:ud    r6.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $201
(f1.0)  goto (32|M0)                         _0_034            _0_034                                //  ALU pipe: int; $202
// B024: [inDivergent],  Preds:{B023},  Succs:{B026}
_0_035:
        shr (32|M0)              r6.0<1>:ud    r70.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $204
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $205
        add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r70.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $206
        shr (32|M0)              r12.0<1>:ud   r10.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $207
        mov (32|M0)              r82.0<1>:w    r12.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $208
        goto (32|M0)                         _0_034            _0_036                                // $209
// B025: [inDivergent],  Preds:{B023},  Succs:{B026}
_0_034:
        join (32|M0)                         _0_036                                                  // 
L3704:
        shr (32|M0)              r6.0<1>:ud    r70.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $211
        or (32|M0)               r82.0<1>:w    r6.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $213
// B026: [inDivergent],  Preds:{B025, B024},  Succs:{B027, B020}
_0_036:
        join (32|M0)                         _L_k0_12_                                               // 
L3752:
        add (32|M0)              r4.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted}       //  ALU pipe: int; $219
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r4.0<1;1,0>:ud    r124.0<1;1,0>:ud {I@1}              //  ALU pipe: int; $220
        add (16|M0)              r6.0<1>:q     r80.0<1;1,0>:q    r3.6<0;1,0>:q                       //  ALU pipe: int; $215
        add (16|M16)             r8.0<1>:q     r78.0<1;1,0>:q    r3.6<0;1,0>:q                       //  ALU pipe: int; $215
        mov (32|M0)              r10.0<1>:ud   r82.0<1;1,0>:uw                                       //  ALU pipe: int; $217
        store.ugm.d16u32.a64 (32|M0)  [r6:4]    r10:2              {I@1,$12} // ex_desc:0x0; desc:0x8000B84 // $218
(f0.0)  goto.b (32|M0)                       _L_k0_12_         _0_030                                //  ALU pipe: int; $221
// B027: [inDivergent],  Preds:{B026},  Succs:{B030}
_L_k0_12_:
        join (32|M0)                         _0_023                                                  // 
L3872:
        goto (32|M0)                         _0_023            _0_023                                // $222
// B028: [inDivergent],  Preds:{B005},  Succs:{B029, B030}
_0_027:
        cmp (32|M0)   (eq)f0.0   null<1>:d     r114.0<1;1,0>:d   0:w                                 //  ALU pipe: int; $224
(~f0.0) goto (32|M0)                         _0_023            _0_023                                //  ALU pipe: int; $225
// B029: [inDivergent],  Preds:{B028},  Succs:{B030}
_0_037:
        mov (16|M0)              r6.0<2>:f     r122.0<0;1,0>:f                  {$12.src}            //  ALU pipe: float; $227
        mov (16|M16)             r8.0<2>:f     r122.0<0;1,0>:f                                       //  ALU pipe: float; $227
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $229
        mov (16|M0)              r6.1<2>:f     r122.1<0;1,0>:f                                       //  ALU pipe: float; $228
        mov (16|M16)             r8.1<2>:ud    r122.1<0;1,0>:ud                 {F@2}                //  ALU pipe: int; $228
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$0} // ex_desc:0x0; desc:0x800058B // $230
// B030: Preds:{B029, B028, B027, B014, B004, B003, B002},  Succs:{}
_0_023:
        join (32|M0)                         L4024                                                   // 
L4024:
(W)     mov (16|M0)              r127.0<1>:f   r112.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $232
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$1} // wr:1+0, rd:0; end of thread // $232
L4048:
(W)     mov (16|M0)              null<1>:ud    0x830D2F0:ud                                          // 
(W)     mov (16|M0)              null<1>:ud    0xEA18A4DC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x4:ud                                                // 


//.BankConflicts: 23
//.ByteRMWs: 0
//


//.numALUInst: 255
//.accSubDef: 11
//.accSubUse: 11
//.accSubCandidateDef: 80
//.accSubCandidateUse: 80
//
//
//.singlePipeAtOneDistNum: 74
//.allAtOneDistNum: 9
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 30
//.AfterReadTokenDepCount: 4
