//.kernel _ZTSN4sycl3_V16detail19__pf_kernel_wrapperIN9p42extras6NgNameILi2ELi1ELi0ELi2560ELi4EEEEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 3 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 3 -GRFBumpUpNumber 2 "
//.instCount 418
//.RA type	GRAPH_COLORING_FF_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r4.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.12)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r4.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r4.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r6.4)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r6.0)
//.declare V0043 (53)  rf=r size=8 type=uq align=4 words (r6.1)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0070 (80)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0071 (81)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0072 (82)  rf=r size=8 type=q align=4 words (r5.7)
//.declare V0074 (84)  rf=r size=8 type=d align=2 words (r3.2)
//.declare V0075 (85)  rf=r size=8 type=d alias=V0044+0 align=32 words (r2.6)
//.declare V0076 (86)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0077 (87)  rf=r size=12 type=ud alias=V0038+0 align=32 words (r2.3)
//.declare V0078 (88)  rf=r size=32 type=ud alias=V0035+0 align=32 words (r4.0)
//.declare V0079 (89)  rf=r size=8 type=ud alias=V0076+0 align=4 words (r2.6)
//.declare V0080 (90)  rf=r size=8 type=d alias=V0076+0 align=4 words (r2.6)
//.declare V0081 (91)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0084 (94)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0087 (97)  rf=r size=12 type=ud alias=V0036+0 align=32 words (r2.0)
//.declare V0091 (101)  rf=r size=128 type=d align=32 words (r98.0)
//.declare V0092 (102)  rf=r size=128 type=d align=32 words (r96.0)
//.declare P01 (103)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0093 (104)  rf=r size=128 type=ud alias=V0091+0 align=32 words (r98.0)
//.declare V0094 (105)  rf=r size=8 type=ud alias=V0074+0 align=2 words (r3.2)
//.declare P02 (106)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P03 (107)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0095 (108)  rf=r size=128 type=ud alias=V0092+0 align=32 words (r96.0)
//.declare V0096 (109)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0098 (111)  rf=r size=4 type=ud align=2 words (r3.4)
//.declare V0100 (113)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare V0102 (115)  rf=r size=4 type=ud align=2 words (r3.15)
//.declare V0103 (116)  rf=r size=4 type=ud align=2 words (r3.14)
//.declare V0105 (118)  rf=r size=4 type=d align=2 words (r3.15)
//.declare V0106 (119)  rf=r size=8 type=uq alias=V0068+0 align=32 words (r5.3)
//.declare V0107 (120)  rf=r size=8 type=uq alias=V0070+0 align=32 words (r5.5)
//.declare V0108 (121)  rf=r size=8 type=uq alias=V0071+0 align=32 words (r5.6)
//.declare V0109 (122)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0110 (123)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0111 (124)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0112 (125)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0113 (126)  rf=r size=4 type=ud alias=V0111+0 align=2 words (r3.14)
//.declare V0114 (127)  rf=r size=4 type=ud alias=V0109+0 align=2 words (r3.0)
//.declare V0115 (128)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0117 (130)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0118 (131)  rf=r size=8 type=uq align=32 words (r104.0)
//.declare V0119 (132)  rf=r size=8 type=uq align=32 words (r100.0)
//.declare V0120 (133)  rf=r size=8 type=uq align=32 words (r102.0)
//.declare V0121 (134)  rf=r size=4 type=d align=2 words (r3.1)
//.declare P04 (135)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0122 (136)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0123 (137)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0124 (138)  rf=r size=4 type=f align=2 words (r3.0)
//.declare V0125 (139)  rf=r size=4 type=ud alias=V0123+0 align=2 words (r3.0)
//.declare V0127 (141)  rf=r size=64 type=uw alias=V0096+0 align=32 words (r1.0)
//.declare V0128 (142)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0129 (143)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0130 (144)  rf=r size=8 type=q alias=V0043+0 align=32 words (r6.1)
//.declare V0132 (146)  rf=r size=128 type=ud alias=V0129+0 align=32 words (r10.0)
//.declare V0133 (147)  rf=r size=256 type=q align=32 words (r83.0)
//.declare V0134 (148)  rf=r size=256 type=uq alias=V0133+0 align=32 words (r83.0)
//.declare V0135 (149)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0136 (150)  rf=r size=12 type=ud alias=V0037+0 align=32 words (r6.4)
//.declare V0138 (152)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0139 (153)  rf=r size=128 type=d align=32 words (r6.0)
//.declare P05 (154)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0140 (155)  rf=r size=128 type=ud alias=V0138+0 align=32 words (r8.0)
//.declare P06 (156)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P07 (157)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0141 (158)  rf=r size=128 type=ud alias=V0139+0 align=32 words (r6.0)
//.declare V0142 (159)  rf=r size=4 type=ud alias=V0112+0 align=2 words (r3.7)
//.declare V0143 (160)  rf=r size=4 type=d align=32 words (r1.0)
//.declare P08 (161)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0145 (163)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0146 (164)  rf=r size=256 type=ud alias=V0145+0 align=32 words (r10.0)
//.declare V0147 (165)  rf=r size=8 type=ud alias=V0119+0 align=32 words (r100.0)
//.declare V0148 (166)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0149 (167)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare P09 (169)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0151 (170)  rf=r size=4 type=d align=32 words (r1.0)
//.declare P10 (171)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P11 (172)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0152 (173)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0153 (174)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0154 (175)  rf=r size=128 type=ud alias=V0152+0 align=32 words (r6.0)
//.declare V0155 (176)  rf=r size=128 type=ud alias=V0153+0 align=32 words (r8.0)
//.declare V0156 (177)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0157 (178)  rf=r size=128 type=ud alias=V0156+0 align=32 words (r72.0)
//.declare V0158 (179)  rf=r size=128 type=d align=32 words (r94.0)
//.declare V0159 (180)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0161 (182)  rf=r size=128 type=ud alias=V0159+0 align=32 words (r8.0)
//.declare V0164 (185)  rf=r size=256 type=uq align=32 words (r38.0)
//.declare V0165 (186)  rf=r size=512 type=f align=32 words (r30.0)
//.declare V0168 (189)  rf=r size=256 type=uq align=32 words (r30.0)
//.declare V0169 (190)  rf=r size=512 type=f align=32 words (r22.0)
//.declare V0172 (193)  rf=r size=256 type=uq align=32 words (r22.0)
//.declare V0173 (194)  rf=r size=512 type=f align=32 words (r14.0)
//.declare V0176 (197)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0177 (198)  rf=r size=512 type=f align=32 words (r6.0)
//.declare V0180 (201)  rf=r size=256 type=uq align=32 words (r78.0)
//.declare V0181 (202)  rf=r size=512 type=f align=32 words (r62.0)
//.declare V0184 (205)  rf=r size=256 type=uq align=32 words (r62.0)
//.declare V0185 (206)  rf=r size=512 type=f align=32 words (r54.0)
//.declare V0188 (209)  rf=r size=256 type=uq align=32 words (r54.0)
//.declare V0189 (210)  rf=r size=512 type=f align=32 words (r46.0)
//.declare V0192 (213)  rf=r size=256 type=uq align=32 words (r46.0)
//.declare V0193 (214)  rf=r size=512 type=f align=32 words (r38.0)
//.declare V0196 (217)  rf=r size=256 type=uq align=32 words (r38.0)
//.declare V0197 (218)  rf=r size=512 type=f align=32 words (r30.0)
//.declare V0200 (221)  rf=r size=256 type=uq align=32 words (r30.0)
//.declare V0201 (222)  rf=r size=512 type=f align=32 words (r22.0)
//.declare V0204 (225)  rf=r size=256 type=uq align=32 words (r22.0)
//.declare V0205 (226)  rf=r size=512 type=f align=32 words (r14.0)
//.declare V0208 (229)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0209 (230)  rf=r size=512 type=f align=32 words (r6.0)
//.declare V0212 (233)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0213 (234)  rf=r size=512 type=f align=32 words (r46.0)
//.declare V0216 (237)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0217 (238)  rf=r size=512 type=f align=32 words (r38.0)
//.declare V0220 (241)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare V0221 (242)  rf=r size=512 type=f align=32 words (r30.0)
//.declare V0224 (245)  rf=r size=256 type=uq align=32 words (r30.0)
//.declare V0225 (246)  rf=r size=512 type=f align=32 words (r22.0)
//.declare V0228 (249)  rf=r size=256 type=uq align=32 words (r78.0)
//.declare V0229 (250)  rf=r size=512 type=f align=32 words (r62.0)
//.declare V0232 (253)  rf=r size=256 type=uq align=32 words (r62.0)
//.declare V0233 (254)  rf=r size=512 type=f align=32 words (r54.0)
//.declare V0236 (257)  rf=r size=256 type=uq align=32 words (r54.0)
//.declare V0237 (258)  rf=r size=512 type=f align=32 words (r14.0)
//.declare V0240 (261)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0241 (262)  rf=r size=512 type=f align=32 words (r6.0)
//.declare V0242 (263)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0243 (264)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0244 (265)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0245 (266)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0246 (267)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0247 (268)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0248 (269)  rf=r size=128 type=f align=32 words (r48.0)
//.declare V0249 (270)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0250 (271)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0251 (272)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0252 (273)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0253 (274)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0254 (275)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0255 (276)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0256 (277)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0257 (278)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0258 (279)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0259 (280)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0260 (281)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0261 (282)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0262 (283)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0263 (284)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0264 (285)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0265 (286)  rf=r size=128 type=f align=32 words (r78.0)
//.declare V0266 (287)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0267 (288)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0268 (289)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0269 (290)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0270 (291)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0271 (292)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0272 (293)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0273 (294)  rf=r size=128 type=f align=32 words (r78.0)
//.declare V0274 (295)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0275 (296)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0276 (297)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0277 (298)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0278 (299)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0279 (300)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0280 (301)  rf=r size=128 type=f align=32 words (r36.0)
//.declare V0281 (302)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0283 (304)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0284 (305)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0285 (306)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0286 (307)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0287 (308)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0288 (309)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0289 (310)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0290 (311)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0291 (312)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0292 (313)  rf=r size=128 type=f align=32 words (r36.0)
//.declare V0293 (314)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0294 (315)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0295 (316)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0296 (317)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0297 (318)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0298 (319)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0299 (320)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0300 (321)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0301 (322)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0303 (324)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0305 (326)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0306 (327)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0307 (328)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0308 (329)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0309 (330)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0311 (332)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0313 (334)  rf=r size=128 type=f align=32 words (r44.0)
//.declare V0314 (335)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0315 (336)  rf=r size=128 type=f align=32 words (r90.0)
//.declare V0316 (337)  rf=r size=128 type=f align=32 words (r92.0)
//.declare V0318 (339)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0319 (340)  rf=r size=128 type=f align=32 words (r38.0)
//.declare V0321 (342)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0322 (343)  rf=r size=128 type=d align=32 words (r46.0)
//.declare  (345)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (346)  rf=r size=128 type=f align=32 words (r16.0)
//.declare  (347)  rf=r size=128 type=f align=32 words (r1.0)
//.declare  (348)  rf=r size=128 type=f align=32 words (r14.0)
//.declare  (349)  rf=r size=128 type=f align=32 words (r12.0)
//.declare  (350)  rf=r size=128 type=f align=32 words (r10.0)
//.declare  (351)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (352)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (353)  rf=r size=64 type=f align=32 words (r82.0)
//.declare  (354)  rf=r size=64 type=f align=32 words (r88.0)
//.declare  (355)  rf=r size=128 type=f align=32 words (r1.0)
//.declare V0324 (358)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0325 (359)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (360)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (361)  rf=r size=128 type=f align=32 words (r1.0)
//.declare  (362)  rf=r size=128 type=f align=32 words (r12.0)
//.declare  (363)  rf=r size=128 type=f align=32 words (r10.0)
//.declare  (364)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (365)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (366)  rf=r size=64 type=f align=32 words (r87.0)
//.declare V0326 (369)  rf=r size=128 type=d alias=V0325+0 align=32 words (r6.0)
//.declare V0327 (370)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0328 (371)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0329 (372)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P12 (373)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0330 (374)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0331 (375)  rf=r size=128 type=f alias=V0327+0 align=32 words (r20.0)
//.declare  (376)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (377)  rf=r size=128 type=f align=32 words (r18.0)
//.declare  (378)  rf=r size=128 type=f align=32 words (r1.0)
//.declare  (379)  rf=r size=128 type=f align=32 words (r16.0)
//.declare  (380)  rf=r size=128 type=f align=32 words (r12.0)
//.declare  (381)  rf=r size=128 type=f align=32 words (r10.0)
//.declare  (382)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (383)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (384)  rf=r size=128 type=f align=32 words (r1.0)
//.declare V0332 (387)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0333 (388)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0338 (393)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0340 (395)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0341 (396)  rf=r size=128 type=w alias=V0340+0 align=32 words (r16.0)
//.declare V0343 (398)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0344 (399)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0345 (400)  rf=r size=128 type=f alias=V0343+0 align=32 words (r10.0)
//.declare V0346 (401)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0351 (406)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0352 (407)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0356 (411)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0358 (413)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare V0359 (414)  rf=r size=128 type=w alias=V0358+0 align=32 words (r22.0)
//.declare V0361 (416)  rf=r size=128 type=d alias=V0352+0 align=32 words (r16.0)
//.declare V0363 (418)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0364 (419)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0365 (420)  rf=r size=128 type=d alias=V0363+0 align=32 words (r10.0)
//.declare P13 (421)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0366 (422)  rf=r size=128 type=ud alias=V0364+0 align=32 words (r12.0)
//.declare V0367 (423)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0368 (424)  rf=r size=128 type=ud alias=V0363+0 align=32 words (r10.0)
//.declare V0369 (425)  rf=r size=128 type=ud alias=V0367+0 align=32 words (r12.0)
//.declare V0370 (426)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0371 (427)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0372 (428)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0373 (429)  rf=r size=128 type=ud alias=V0371+0 align=32 words (r12.0)
//.declare V0374 (430)  rf=r size=128 type=ud alias=V0372+0 align=32 words (r10.0)
//.declare V0375 (431)  rf=r size=64 type=w align=32 words (r16.0)
//.declare V0376 (432)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0377 (433)  rf=r size=128 type=ud alias=V0376+0 align=32 words (r12.0)
//.declare V0381 (437)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0382 (438)  rf=r size=64 type=uw alias=V0375+0 align=32 words (r16.0)
//.declare V0383 (439)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare P14 (440)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P15 (441)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P16 (442)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0385 (444)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0386 (445)  rf=r size=256 type=ud alias=V0385+0 align=32 words (r6.0)
//.declare V0387 (446)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0391 (450)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0392 (451)  rf=r size=128 type=d align=32 words (r6.0)
//.declare P17 (452)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0393 (453)  rf=r size=128 type=ud alias=V0391+0 align=32 words (r8.0)
//.declare P18 (454)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P19 (455)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0394 (456)  rf=r size=128 type=ud alias=V0392+0 align=32 words (r6.0)
//.declare  (460)  rf=r size=64 type=ud align=32 words (r112.0)
//.declare  (461)  rf=r size=128 type=w alias=V0376+0 align=32 words (r12.0)
//.declare  (462)  rf=r size=4 type=ud align=32 words (r3.0)
//.declare  (463)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (464)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (465)  rf=r size=4 type=d align=2 words (r3.0)
//.declare  (466)  rf=r size=128 type=ud align=32 words (r1.0)
//.declare  (467)  rf=r size=128 type=ud align=32 words (r1.0)
//.declare  (470)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (471)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (472)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (473)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (474)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (475)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (476)  rf=r size=128 type=w alias=V0372+0 align=32 words (r10.0)
//.declare  (479)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (480)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (481)  rf=r size=128 type=q align=32 words (r76.0)
//.declare  (482)  rf=r size=128 type=q align=32 words (r74.0)
//.declare  (491)  rf=r size=128 type=q align=32 words (r70.0)
//.declare  (492)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (533)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (534)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (537)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (538)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (539)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (540)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (543)  rf=r size=128 type=q align=32 words (r26.0)
//.declare  (544)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (549)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (550)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (553)  rf=r size=128 type=d align=32 words (r10.0)
//.declare  (554)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (555)  rf=r size=128 type=d alias=+0 align=32 words (r76.0)
//.declare  (556)  rf=r size=128 type=d alias=+0 align=32 words (r74.0)
//.declare  (557)  rf=r size=128 type=uq alias=+0 align=32 words (r70.0)
//.declare  (558)  rf=r size=128 type=uq alias=+0 align=32 words (r1.0)
//.declare  (559)  rf=r size=128 type=d alias=+0 align=32 words (r10.0)
//.declare  (560)  rf=r size=128 type=d alias=+0 align=32 words (r1.0)
//.declare r0 (811)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (812)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (813)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (814)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (815)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (816)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (817)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (818)  rf=r size=32 type=ud align=2 words (r6.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0045    | :d       |    0x4 | r3       | cti+0x20         |
// | V0046    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0047    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0048    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0049    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0050    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0051    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0052    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0053    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0054    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0055    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0056    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0057    | :q       |    0x8 | r4       | cti+0x60         |
// | V0058    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0059    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0060    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0061    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0062    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0063    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0064    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0065    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0066    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0067    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0068    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0069    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0070    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0071    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// | V0072    | :q       |    0x8 | r5+0x38  | cti+0xD8         |
// | V0042    | :uq      |    0x8 | r6       | cti+0xE0         |
// | V0043    | :uq      |    0x8 | r6+0x8   | cti+0xE8         |
// | V0037    | :d x 3   |    0xC | r6+0x10  | cti+0xF0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xE0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r6:1  bti[255][r127:1+0xC0]  {$3} // ex_desc:0xFF0C0000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B034}
// _main:
(W)     mov (16|M0)              r4.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted,$1.dst}   //  ALU pipe: int; $1
(W)     mov (16|M0)              r87.0<1>:f    0x3F000000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r88.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r82.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r4.2<0;1,0>:uw   {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r3.0<1>:ud    r2.3<0;1,0>:ud    r4.1<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r4.2<0;1,0>:uw                      //  ALU pipe: int; $4
(W)     mov (2|M0)               r3.2<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
(W)     mov (1|M0)               r2.6<2>:ud    r3.0<0;1,0>:ud                   {I@3}                //  ALU pipe: int; $4
(W)     mach (1|M0)              r3.0<1>:d     r2.3<0;1,0>:ud    r4.1<0;1,0>:ud                      //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.7<2>:d     r3.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $8
        add (16|M0)              r11.0<1>:q    r2.3<0;1,0>:q     r7.0<4;1,0>:uw   {I@1}              //  ALU pipe: int; $10
        mov (16|M16)             r7.0<4>:uw    r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
        add (16|M16)             r9.0<1>:q     r2.3<0;1,0>:q     r7.0<4;1,0>:uw   {I@1}              //  ALU pipe: int; $10
        add (16|M0)              r76.0<1>:q    r11.0<1;1,0>:q    r2.0<0;1,0>:ud                      //  ALU pipe: int; $12
        add (16|M16)             r74.0<1>:q    r9.0<1;1,0>:q     r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r98.0<1>:d    r76.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r99.0<1>:d    r74.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r98.0<1;1,0>:ud   r3.2<0;1,0>:ud   {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r96.0<1>:d    r76.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r97.0<1>:d    r74.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r96.0<1;1,0>:d    r3.3<0;1,0>:d    {I@1}              //  ALU pipe: int; $18
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r96.0<1;1,0>:ud   r3.3<0;1,0>:ud                      //  ALU pipe: int; $20
(~f0.0) goto (32|M0)                         _0_029            _0_029                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_030:
(W)     mov (8|M0)               r1.0<1>:w     0x76543210:v                                          //  ALU pipe: int; $24
(W)     and (1|M0)               r3.4<1>:ud    msg0.0<0;1,0>:ud  0xFF:uw                             //  ALU pipe: int; $27
(W)     add (8|M0)               r1.8<1>:w     r1.0<1;1,0>:w     8:w               {I@2}             //  ALU pipe: int; $25
(W)     add (16|M0)              r1.16<1>:w    r1.0<1;1,0>:w     16:w               {I@1}            //  ALU pipe: int; $26
(W)     and (1|M0)               r3.7<1>:ud    sr0.0<0;1,0>:ud   0x7F:uw              {A@1}          //  ALU pipe: int; $28
(W)     and (1|M0)               r3.14<1>:ud   r3.7<0;1,0>:ud    7:w               {A@1}             //  ALU pipe: int; $30
(W)     asr (1|M0)               r3.15<1>:ud   r3.7<0;1,0>:ud    1:w                                 //  ALU pipe: int; $31
(W)     mov (1|M0)               r3.0<1>:d     -8:w                               {Compacted}        //  ALU pipe: int; $32
(W)     shl (1|M0)               r3.4<1>:ud    r3.4<0;1,0>:ud    0x6:uw                              //  ALU pipe: int; $29
(W)     bfn.(s0&s1|s2) (1|M0)    r3.7<1>:ud    r3.15<0;0>:ud     r3.0<0;0>:ud      r3.14<0>:ud      {I@2} //  ALU pipe: int; $32
        shl (32|M0)              r8.0<1>:d     r1.0<1;1,0>:uw    2:w                                 //  ALU pipe: int; $54
(W)     or (1|M0)                r3.4<1>:ud    r3.4<0;1,0>:ud    r3.7<0;1,0>:ud   {I@2}              //  ALU pipe: int; $33
(W)     shl (1|M0)               r3.0<1>:d     r3.1<0;1,0>:d     2:w               {Compacted}       //  ALU pipe: int; $36
(W)     mul (1|M0)               r3.15<1>:d    r3.4<0;1,0>:d     128:w               {I@2}           //  ALU pipe: int; $35
(W)     asr (1|M0)               r3.4<1>:d     r3.0<0;1,0>:d     31:w               {Compacted,I@2}  //  ALU pipe: int; $37
(W)     mul (1|M0)               acc0.0<1>:ud  r3.0<0;1,0>:ud    0x280:uw                            //  ALU pipe: int; $39
        add (32|M0)              r10.0<1>:d    r3.15<0;1,0>:d    r8.0<1;1,0>:d    {I@3}              //  ALU pipe: int; $55
(W)     mul (1|M0)               r3.14<1>:ud   r3.0<0;1,0>:ud    0x280:uw                            //  ALU pipe: int; $38
(W)     mach (1|M0)              r6.0<1>:d     r3.0<0;1,0>:ud    0x280:ud              {$3.dst}      //  ALU pipe: int; 
(W)     mul (1|M0)               r3.0<1>:d     r3.4<0;1,0>:d     0x280:uw              {I@5}         //  ALU pipe: int; $42
        mov (16|M0)              r1.0<2>:ud    r10.0<1;1,0>:ud                  {Compacted,I@4}      //  ALU pipe: int; $57
(W)     add (1|M0)               r3.7<1>:d     r6.0<0;1,0>:d     r3.0<0;1,0>:d    {I@2}              //  ALU pipe: int; $44
(W)     and (1|M0)               r3.0<1>:d     r3.5<0;1,0>:d     8:w                                 //  ALU pipe: int; $49
        add (16|M0)              r83.0<1>:q    r6.1<0;1,0>:q     r1.0<2;1,0>:ud   {I@3}              //  ALU pipe: int; $57
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.0<0;1,0>:d     0:w               {I@2}             //  ALU pipe: int; $50
        mov (16|M16)             r1.0<2>:ud    r11.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $57
(W)     and (1|M0)               r3.0<1>:d     r3.5<0;1,0>:d     1:w                                 //  ALU pipe: int; $51
        add (16|M16)             r85.0<1>:q    r6.1<0;1,0>:q     r1.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $57
(W)     mov (1|M0)               r104.0<1>:uq  r5.6<0;1,0>:uq                   {Compacted,$2.dst}   //  ALU pipe: int; $45
(W)     mov (1|M0)               r100.0<1>:uq  r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $46
(W)     mov (1|M0)               r102.0<1>:uq  r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $47
(W)     add (1|M0)               r3.1<1>:d     r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $48
(W)     mov (1|M0)               r3.2<1>:q     r6.4<0;1,0>:ud                                        //  ALU pipe: int; $58
(W)     mov (1|M0)               r3.0<1>:f     r3.0<0;1,0>:ud                   {I@7}                //  ALU pipe: float; $52
// B004: [inDivergent],  Preds:{B033, B003},  Succs:{B005, B032}
_0_031:
        mov (16|M0)              r8.0<1>:d     r76.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $60
        mov (16|M16)             r9.0<1>:d     r74.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $61
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r8.0<1;1,0>:ud    r3.14<0;1,0>:ud  {I@1}              //  ALU pipe: int; $64
        mov (16|M0)              r6.0<1>:d     r76.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $62
        mov (16|M16)             r7.0<1>:d     r74.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $63
(f1.0)  cmp (32|M0)   (eq)f1.0   null<1>:d     r6.0<1;1,0>:d     r3.7<0;1,0>:d    {I@1}              //  ALU pipe: int; $65
(~f1.0) cmp (32|M0)   (lt)f1.0   null<1>:ud    r6.0<1;1,0>:ud    r3.7<0;1,0>:ud                      //  ALU pipe: int; $67
(~f1.0) goto (32|M0)                         _0_032            _0_032                                //  ALU pipe: int; $69
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B032}
_0_033:
(W)     load.ugm.d32x1t.a64 (1|M0)  r1:1        [r104:1]           {$5} // ex_desc:0x0; desc:0x2108580 // $71
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r1.0<0;1,0>:d     0:w               {$5.dst}          //  ALU pipe: int; $72
(f3.0)  goto (32|M0)                         _0_032            _0_032                                //  ALU pipe: int; $73
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B032}
_0_034:
        mov (16|M0)              r10.0<2>:f    r100.0<0;1,0>:f                                       //  ALU pipe: float; $75
        mov (16|M16)             r12.0<2>:f    r100.0<0;1,0>:f                                       //  ALU pipe: float; $75
        mov (32|M0)              r16.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $77
        mov (16|M0)              r10.1<2>:f    r100.1<0;1,0>:f                                       //  ALU pipe: float; $76
        mov (16|M16)             r12.1<2>:ud   r100.1<0;1,0>:ud                 {F@2}                //  ALU pipe: int; $76
        atomic_or.ugm.d32.a64 (32|M0)  r14:2    [r10:4]           r16:2              {A@1,$6} // ex_desc:0x0; desc:0x8200599 // $78
        cmp (32|M0)   (eq)f2.0   null<1>:d     r14.0<1;1,0>:d    0:w               {$6.dst}          //  ALU pipe: int; $80
(~f2.0) goto (32|M0)                         _0_032            _0_032                                //  ALU pipe: int; $81
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B030}
_0_035:
(W)     load.ugm.d32x1t.a64 (1|M0)  r1:1        [r102:1]           {$7} // ex_desc:0x0; desc:0x2108580 // $83
(W)     cmp (32|M0)   (gt)f3.0   null<1>:d     r1.0<0;1,0>:d     r3.1<0;1,0>:d    {$7.dst}           //  ALU pipe: int; $84
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:d     r1.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $85
(W&f3.0) jmpi                                _0_036                                                  //  ALU pipe: int; $87
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B010}
_0_037:
        mov (16|M0)              r6.0<1>:d     r76.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $89
        mov (16|M16)             r7.0<1>:d     r74.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $89
(W)     mul (16|M0)              acc0.0<1>:ud  r6.0<1;1,0>:ud    0xCCCD:uw              {I@2}        //  ALU pipe: int; $90
        mach (16|M0)             r8.0<1>:ud    r6.0<1;1,0>:ud    0xCCCCCCCD:ud                       //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r7.0<1;1,0>:ud    0xCCCD:uw              {I@3}        //  ALU pipe: int; $90
        mach (16|M16)            r9.0<1>:ud    r7.0<1;1,0>:ud    0xCCCCCCCD:ud                       //  ALU pipe: int; $91
        shr (32|M0)              r72.0<1>:ud   r8.0<1;1,0>:ud    9:w               {I@1}             //  ALU pipe: int; $91
        mul (32|M0)              r8.0<1>:d     r72.0<1;1,0>:d    320:w               {Compacted,I@1} //  ALU pipe: int; $93
        mov (16|M16)             r10.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $95
        mov (16|M0)              r12.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $95
        add (16|M16)             r1.0<1>:q     r10.0<2;1,0>:ud   r5.7<0;1,0>:q    {I@2}              //  ALU pipe: int; $95
        add (16|M0)              r70.0<1>:q    r12.0<2;1,0>:ud   r5.7<0;1,0>:q    {I@2}              //  ALU pipe: int; $95
        add (16|M16)             r16.0<1>:q    r1.0<1;1,0>:q     208:w               {Compacted,I@2} //  ALU pipe: int; $134
        add (16|M0)              r14.0<1>:q    r70.0<1;1,0>:q    208:w               {Compacted,I@2} //  ALU pipe: int; $134
        load.ugm.d32x4.a64 (32|M0)  r38:8       [r14:4]            {I@1,$8} // ex_desc:0x0; desc:0x8803580 // $136
        add (16|M16)             r32.0<1>:q    r1.0<1;1,0>:q     240:w               {Compacted}     //  ALU pipe: int; $140
        add (16|M0)              r30.0<1>:q    r70.0<1;1,0>:q    240:w               {Compacted}     //  ALU pipe: int; $140
        add (16|M16)             r12.0<1>:q    r1.0<1;1,0>:q     192:w               {Compacted}     //  ALU pipe: int; $131
        add (16|M0)              r10.0<1>:q    r70.0<1;1,0>:q    192:w               {Compacted}     //  ALU pipe: int; $131
        add (16|M16)             r20.0<1>:q    r1.0<1;1,0>:q     224:w               {Compacted,$4.dst} //  ALU pipe: int; $137
        add (16|M0)              r18.0<1>:q    r70.0<1;1,0>:q    224:w               {Compacted}     //  ALU pipe: int; $137
        add (16|M16)             r16.0<1>:q    r1.0<1;1,0>:q     304:w               {Compacted,$8.src} //  ALU pipe: int; $152
        add (16|M0)              r14.0<1>:q    r70.0<1;1,0>:q    304:w               {Compacted}     //  ALU pipe: int; $152
        load.ugm.d32x4.a64 (32|M0)  r22:8       [r30:4]            {I@7,$9} // ex_desc:0x0; desc:0x8803580 // $142
        load.ugm.d32x4.a64 (32|M0)  r46:8       [r10:4]            {I@5,$10} // ex_desc:0x0; desc:0x8803580 // $133
        mad (32|M0)              r94.0<1>:d    r6.0<1;0>:d       r72.0<1;0>:d      -640:w               //  ALU pipe: int; $92
        add (16|M16)             r56.0<1>:q    r1.0<1;1,0>:q     288:w               {Compacted}     //  ALU pipe: int; $149
        add (16|M0)              r54.0<1>:q    r70.0<1;1,0>:q    288:w               {Compacted}     //  ALU pipe: int; $149
        load.ugm.d32x4.a64 (32|M0)  r30:8       [r18:4]            {I@6,$11} // ex_desc:0x0; desc:0x8803580 // $139
        load.ugm.d32x4.a64 (32|M0)  r6:8        [r14:4]            {I@3,$12} // ex_desc:0x0; desc:0x8803580 // $154
        add (16|M16)             r64.0<1>:q    r1.0<1;1,0>:q     272:w               {Compacted}     //  ALU pipe: int; $146
        add (16|M0)              r62.0<1>:q    r70.0<1;1,0>:q    272:w               {Compacted}     //  ALU pipe: int; $146
        load.ugm.d32x4.a64 (32|M0)  r14:8       [r54:4]            {I@3,$13} // ex_desc:0x0; desc:0x8803580 // $151
        add (16|M16)             r80.0<1>:q    r1.0<1;1,0>:q     256:w               {Compacted}     //  ALU pipe: int; $143
        add (16|M0)              r78.0<1>:q    r70.0<1;1,0>:q    256:w               {Compacted}     //  ALU pipe: int; $143
        load.ugm.d32x4.a64 (32|M0)  r54:8       [r62:4]            {I@3,$14} // ex_desc:0x0; desc:0x8803580 // $148
        load.ugm.d32x4.a64 (32|M0)  r62:8       [r78:4]            {I@1,$15} // ex_desc:0x0; desc:0x8803580 // $145
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $236
        sync.nop                             null                             {Compacted,$15.src}    // $185
        add (32|M0)              r80.0<1>:f    r22.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $185
        add (32|M0)              r78.0<1>:f    r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $186
        add (32|M0)              r26.0<1>:f    r42.0<1;1,0>:f    r44.0<1;1,0>:f   {Compacted,$8.dst} //  ALU pipe: float; $182
        add (32|M0)              r28.0<1>:f    r38.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $181
        add (32|M0)              r22.0<1>:f    r34.0<1;1,0>:f    r36.0<1;1,0>:f   {Compacted,$11.dst} //  ALU pipe: float; $184
        add (32|M0)              r24.0<1>:f    r30.0<1;1,0>:f    r32.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $183
        add (32|M0)              r36.0<1>:f    r6.0<1;1,0>:f     r8.0<1;1,0>:f    {Compacted,$12.dst} //  ALU pipe: float; $193
        add (32|M0)              r30.0<1>:f    r50.0<1;1,0>:f    r52.0<1;1,0>:f   {Compacted,$10.dst} //  ALU pipe: float; $180
        add (32|M0)              r32.0<1>:f    r46.0<1;1,0>:f    r48.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $179
        add (32|M0)              r34.0<1>:f    r10.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $194
        add (32|M0)              r6.0<1>:f     r18.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,$13.dst} //  ALU pipe: float; $192
        add (32|M0)              r8.0<1>:f     r14.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $191
        add (32|M0)              r10.0<1>:f    r58.0<1;1,0>:f    r60.0<1;1,0>:f   {Compacted,$14.dst} //  ALU pipe: float; $190
        add (32|M0)              r12.0<1>:f    r54.0<1;1,0>:f    r56.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $189
        add (32|M0)              r20.0<1>:f    r24.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $209
        add (32|M0)              r14.0<1>:f    r66.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted,$15.dst} //  ALU pipe: float; $188
        add (32|M0)              r16.0<1>:f    r62.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $187
        add (32|M0)              r18.0<1>:f    r80.0<1;1,0>:f    r78.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $210
        add (32|M0)              r22.0<1>:f    r28.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $208
        add (32|M0)              r24.0<1>:f    r32.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $207
        add (32|M0)              r28.0<1>:f    r8.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $213
        add (32|M0)              r26.0<1>:f    r36.0<1;1,0>:f    r34.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $214
        add (32|M0)              r6.0<1>:f     r12.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $212
        add (32|M0)              r8.0<1>:f     r16.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $211
        add (32|M0)              r12.0<1>:f    r24.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $221
        add (32|M0)              r14.0<1>:f    r20.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $222
        add (32|M0)              r10.0<1>:f    r28.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $224
        add (32|M0)              acc2.0<1>:f   r8.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted,F@4}    //  ALU pipe: float; $223
        add (32|M0)              r90.0<1>:f    r12.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $228
        add (16|M16)             r16.0<1>:q    r1.0<1;1,0>:q     176:w               {Compacted}     //  ALU pipe: int; $128
        add (16|M0)              r14.0<1>:q    r70.0<1;1,0>:q    176:w               {Compacted,F@1} //  ALU pipe: int; $128
        add (16|M16)             r24.0<1>:q    r1.0<1;1,0>:q     160:w               {Compacted}     //  ALU pipe: int; $125
        add (16|M0)              r22.0<1>:q    r70.0<1;1,0>:q    160:w               {Compacted}     //  ALU pipe: int; $125
        add (32|M0)              r92.0<1>:f    acc2.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $229
        load.ugm.d32x4.a64 (32|M0)  r6:8        [r14:4]            {A@1,$0} // ex_desc:0x0; desc:0x8803580 // $130
        add (16|M16)             r32.0<1>:q    r1.0<1;1,0>:q     144:w               {Compacted}     //  ALU pipe: int; $122
        add (16|M0)              r30.0<1>:q    r70.0<1;1,0>:q    144:w               {Compacted}     //  ALU pipe: int; $122
        load.ugm.d32x4.a64 (32|M0)  r14:8       [r22:4]            {I@3,$1} // ex_desc:0x0; desc:0x8803580 // $127
        add (16|M16)             r40.0<1>:q    r1.0<1;1,0>:q     128:w               {Compacted}     //  ALU pipe: int; $119
        add (16|M0)              r38.0<1>:q    r70.0<1;1,0>:q    128:w               {Compacted}     //  ALU pipe: int; $119
        load.ugm.d32x4.a64 (32|M0)  r22:8       [r30:4]            {I@3,$2} // ex_desc:0x0; desc:0x8803580 // $124
        add (16|M16)             r48.0<1>:q    r1.0<1;1,0>:q     112:w               {Compacted}     //  ALU pipe: int; $116
        add (16|M0)              r46.0<1>:q    r70.0<1;1,0>:q    112:w               {Compacted}     //  ALU pipe: int; $116
        load.ugm.d32x4.a64 (32|M0)  r30:8       [r38:4]            {I@3,$3} // ex_desc:0x0; desc:0x8803580 // $121
        add (16|M16)             r56.0<1>:q    r1.0<1;1,0>:q     96:w               {Compacted}      //  ALU pipe: int; $113
        add (16|M0)              r54.0<1>:q    r70.0<1;1,0>:q    96:w               {Compacted}      //  ALU pipe: int; $113
        load.ugm.d32x4.a64 (32|M0)  r38:8       [r46:4]            {I@3,$5} // ex_desc:0x0; desc:0x8803580 // $118
        add (16|M16)             r64.0<1>:q    r1.0<1;1,0>:q     80:w               {Compacted}      //  ALU pipe: int; $110
        add (16|M0)              r62.0<1>:q    r70.0<1;1,0>:q    80:w               {Compacted}      //  ALU pipe: int; $110
        load.ugm.d32x4.a64 (32|M0)  r46:8       [r54:4]            {I@3,$6} // ex_desc:0x0; desc:0x8803580 // $115
        add (16|M16)             r80.0<1>:q    r1.0<1;1,0>:q     64:w               {Compacted}      //  ALU pipe: int; $107
        add (16|M0)              r78.0<1>:q    r70.0<1;1,0>:q    64:w               {Compacted}      //  ALU pipe: int; $107
        load.ugm.d32x4.a64 (32|M0)  r54:8       [r62:4]            {I@3,$7} // ex_desc:0x0; desc:0x8803580 // $112
        load.ugm.d32x4.a64 (32|M0)  r62:8       [r78:4]            {I@1,$8} // ex_desc:0x0; desc:0x8803580 // $109
        sync.nop                             null                             {Compacted,$8.src}     // $177
        add (32|M0)              r80.0<1>:f    r6.0<1;1,0>:f     r8.0<1;1,0>:f    {Compacted,$0.dst} //  ALU pipe: float; $177
        add (32|M0)              r78.0<1>:f    r10.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $178
        add (32|M0)              r6.0<1>:f     r18.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,$1.dst} //  ALU pipe: float; $176
        add (32|M0)              r8.0<1>:f     r14.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $175
        add (32|M0)              r10.0<1>:f    r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,$2.dst} //  ALU pipe: float; $174
        add (32|M0)              r12.0<1>:f    r22.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $173
        add (32|M0)              r14.0<1>:f    r34.0<1;1,0>:f    r36.0<1;1,0>:f   {Compacted,$3.dst} //  ALU pipe: float; $172
        add (32|M0)              r16.0<1>:f    r30.0<1;1,0>:f    r32.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $171
        add (32|M0)              r18.0<1>:f    r42.0<1;1,0>:f    r44.0<1;1,0>:f   {Compacted,$5.dst} //  ALU pipe: float; $170
        add (32|M0)              r20.0<1>:f    r38.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $169
        add (32|M0)              r36.0<1>:f    r8.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $205
        add (32|M0)              r34.0<1>:f    r80.0<1;1,0>:f    r78.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $206
        add (32|M0)              r22.0<1>:f    r50.0<1;1,0>:f    r52.0<1;1,0>:f   {Compacted,$6.dst} //  ALU pipe: float; $168
        add (32|M0)              r24.0<1>:f    r46.0<1;1,0>:f    r48.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $167
        add (32|M0)              r6.0<1>:f     r12.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $204
        add (32|M0)              r8.0<1>:f     r16.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $203
        add (32|M0)              r26.0<1>:f    r58.0<1;1,0>:f    r60.0<1;1,0>:f   {Compacted,$7.dst} //  ALU pipe: float; $166
        add (32|M0)              r28.0<1>:f    r54.0<1;1,0>:f    r56.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $165
        add (32|M0)              r30.0<1>:f    r66.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted,$8.dst} //  ALU pipe: float; $164
        add (32|M0)              r32.0<1>:f    r62.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $163
        add (32|M0)              r10.0<1>:f    r20.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $202
        add (32|M0)              r12.0<1>:f    r24.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $201
        add (32|M0)              r18.0<1>:f    r36.0<1;1,0>:f    r34.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $220
        add (32|M0)              r20.0<1>:f    r8.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $219
        add (32|M0)              r14.0<1>:f    r28.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $200
        add (32|M0)              r16.0<1>:f    r32.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $199
        add (32|M0)              r8.0<1>:f     r12.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $218
        add (32|M0)              r6.0<1>:f     r20.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $227
        add (32|M0)              acc2.0<1>:f   r16.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $217
        add (16|M16)             r16.0<1>:q    r1.0<1;1,0>:q     48:w               {Compacted,F@1}  //  ALU pipe: int; $104
        add (16|M0)              r14.0<1>:q    r70.0<1;1,0>:q    48:w               {Compacted}      //  ALU pipe: int; $104
        add (16|M16)             r24.0<1>:q    r1.0<1;1,0>:q     32:w               {Compacted}      //  ALU pipe: int; $101
        add (16|M0)              r22.0<1>:q    r70.0<1;1,0>:q    32:w               {Compacted}      //  ALU pipe: int; $101
        add (32|M0)              r42.0<1>:f    r6.0<1;1,0>:f     r90.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $231
        add (32|M0)              r44.0<1>:f    acc2.0<1;1,0>:f   r8.0<1;1,0>:f    {Compacted}        //  ALU pipe: float; $226
        load.ugm.d32x4.a64 (32|M0)  r6:8        [r14:4]            {A@1,$9} // ex_desc:0x0; desc:0x8803580 // $106
        add (16|M16)             r32.0<1>:q    r1.0<1;1,0>:q     16:w               {Compacted}      //  ALU pipe: int; $98
        add (16|M0)              r30.0<1>:q    r70.0<1;1,0>:q    16:w               {Compacted}      //  ALU pipe: int; $98
        load.ugm.d32x4.a64 (32|M0)  r14:8       [r22:4]            {I@3,$10} // ex_desc:0x0; desc:0x8803580 // $103
        mov (16|M16)             r40.0<1>:uq   r1.0<1;1,0>:uq                   {Compacted}          //  ALU pipe: int; $96
        mov (16|M0)              r38.0<1>:uq   r70.0<1;1,0>:uq                  {Compacted}          //  ALU pipe: int; $96
        load.ugm.d32x4.a64 (32|M0)  r22:8       [r30:4]            {I@3,$11} // ex_desc:0x0; desc:0x8803580 // $100
        load.ugm.d32x4.a64 (32|M0)  r30:8       [r38:4]            {I@1,$12} // ex_desc:0x0; desc:0x8803580 // $97
        add (32|M0)              r38.0<1>:f    r92.0<1;1,0>:f    0x0:f               {Compacted,$12.src} //  ALU pipe: float; $232
(W)     mov (32|M0)              r1.0<1>:ud    0x45200000:ud                                         //  ALU pipe: int; $236
        shl (32|M0)              r46.0<1>:d    r94.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $235
        add (32|M0)              r48.0<1>:f    r6.0<1;1,0>:f     r8.0<1;1,0>:f    {Compacted,$9.dst} //  ALU pipe: float; $161
        add (32|M0)              r40.0<1>:f    r10.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $162
        add (32|M0)              r6.0<1>:f     r18.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,$10.dst} //  ALU pipe: float; $160
        add (32|M0)              r8.0<1>:f     r14.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $159
        add (32|M0)              r10.0<1>:f    r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,$11.dst} //  ALU pipe: float; $158
        add (32|M0)              r12.0<1>:f    r22.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $157
        add (32|M0)              r14.0<1>:f    r34.0<1;1,0>:f    r36.0<1;1,0>:f   {Compacted,$12.dst} //  ALU pipe: float; $156
        add (32|M0)              r16.0<1>:f    r30.0<1;1,0>:f    r32.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $155
        add (32|M0)              r18.0<1>:f    r48.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $198
        add (32|M0)              r20.0<1>:f    r8.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted,F@6}    //  ALU pipe: float; $197
        add (32|M0)              r8.0<1>:f     r12.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $196
        add (32|M0)              acc2.0<1>:f   r16.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $195
        add (32|M0)              r6.0<1>:f     r20.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $216
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r8.0<1;1,0>:f    {Compacted,F@3}    //  ALU pipe: float; $215
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r6.0<1;1,0>:f    {Compacted,F@2}    //  ALU pipe: float; $225
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r44.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $230
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r42.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $233
        add (32|M0)              r18.0<1>:f    acc2.0<1;1,0>:f   r38.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $234
        math.invm (16|M0) (eo)f3.0  r12.mme0:f  r18.nomme<1;1,0>:f  r1.nomme<1;1,0>:f {A@1}          //  ALU pipe: math; $236
(f3.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $236
// B009: [inDivergent],  Preds:{B008},  Succs:{B010}
_L_k0_6_:
        madm (16|M0)             r10.mme1:f    r82.nomme:f       r18.nomme:f       r12.mme0:f       {M@1} //  ALU pipe: float; $236 R{} IR{}{E:1,E:1,E:6,},  {BC=1}
        madm (16|M0)             r8.mme2:f     r88.nomme:f       -r1.nomme:f       r12.mme0:f        //  ALU pipe: float; $236
        madm (16|M0)             r16.mme3:f    r12.mme0:f        r8.mme2:f         r12.mme0:f       {F@1} //  ALU pipe: float; $236
        madm (16|M0)             r6.mme4:f     r18.nomme:f       -r1.nomme:f       r10.mme1:f        //  ALU pipe: float; $236
        madm (16|M0)             r10.mme5:f    r10.mme1:f        r6.mme4:f         r16.mme3:f       {F@1} //  ALU pipe: float; $236 R{} IR{}{E:5,E:3,E:0,},  {BC=1}
        madm (16|M0)             r14.mme6:f    r18.nomme:f       -r1.nomme:f       r10.mme5:f       {F@1} //  ALU pipe: float; $236
        madm (16|M0)             r12.nomme:f   r10.mme5:f        r14.mme6:f        r16.mme3:f       {F@1} //  ALU pipe: float; $236 R{} IR{}{E:5,E:7,E:0,},  {BC=1}
// B010: [inDivergent],  Preds:{B009, B008},  Succs:{B011, B012}
_L_k0_0_macro:
        join (32|M0)                         _0_032                                                  // 
L3024:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $236
        math.invm (16|M16) (eo)f3.0  r13.mme0:f  r19.nomme<1;1,0>:f  r2.nomme<1;1,0>:f {I@1}         //  ALU pipe: math; $236
(f3.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $236
// B011: [inDivergent],  Preds:{B010},  Succs:{B012}
_L_k0_7_:
        madm (16|M16)            r11.mme1:f    r82.nomme:f       r19.nomme:f       r13.mme0:f       {M@1} //  ALU pipe: float; $236
        madm (16|M16)            r9.mme2:f     r88.nomme:f       -r2.nomme:f       r13.mme0:f        //  ALU pipe: float; $236
        madm (16|M16)            r17.mme3:f    r13.mme0:f        r9.mme2:f         r13.mme0:f       {F@1} //  ALU pipe: float; $236
        madm (16|M16)            r7.mme4:f     r19.nomme:f       -r2.nomme:f       r11.mme1:f        //  ALU pipe: float; $236
        madm (16|M16)            r11.mme5:f    r11.mme1:f        r7.mme4:f         r17.mme3:f       {F@1} //  ALU pipe: float; $236 R{} IR{}{O:5,O:3,O:0,},  {BC=1}
        madm (16|M16)            r15.mme6:f    r19.nomme:f       -r2.nomme:f       r11.mme5:f       {F@1} //  ALU pipe: float; $236
        madm (16|M16)            r13.nomme:f   r11.mme5:f        r15.mme6:f        r17.mme3:f       {F@1} //  ALU pipe: float; $236 R{} IR{}{O:5,O:7,O:0,},  {BC=1}
// B012: [inDivergent],  Preds:{B011, B010},  Succs:{B013, B014}
_L_k0_1_macro:
        join (32|M0)                         _0_032                                                  // 
L3200:
        add (32|M0)              r14.0<1>:f    r12.0<1;1,0>:f    0x358637BD:f               {F@1}    //  ALU pipe: float; $237
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $238
        math.rsqtm (16|M0) (eo)f2.0  r12.mme0:f  r14.nomme<1;1,0>:f             {A@1}                //  ALU pipe: math; $238
(f2.0)  goto (32|M0)                         _L_k0_2_macro     _L_k0_2_macro                         //  ALU pipe: int; $238
// B013: [inDivergent],  Preds:{B012},  Succs:{B014}
_L_k0_8_:
        madm (16|M0)             r10.mme1:f    r82.nomme:f       r87.nomme:f       r12.mme0:f       {M@1} //  ALU pipe: float; $238
        madm (16|M0)             r6.mme2:f     r82.nomme:f       r14.nomme:f       r12.mme0:f        //  ALU pipe: float; $238
        madm (16|M0)             r8.mme3:f     r87.nomme:f       -r6.mme2:f        r10.mme1:f       {F@1} //  ALU pipe: float; $238
        madm (16|M0)             r10.mme4:f    r10.mme1:f        r8.mme3:f         r10.mme1:f       {F@1} //  ALU pipe: float; $238
        madm (16|M0)             r12.mme5:f    r6.mme2:f         r8.mme3:f         r6.mme2:f         //  ALU pipe: float; $238
        madm (16|M0)             r8.mme6:f     r14.nomme:f       -r12.mme5:f       r12.mme5:f       {F@1} //  ALU pipe: float; $238
        madm (16|M0)             r12.nomme:f   r12.mme5:f        r10.mme4:f        r8.mme6:f        {F@1} //  ALU pipe: float; $238 R{} IR{}{E:6,E:5,E:4,},  {BC=1}
// B014: [inDivergent],  Preds:{B013, B012},  Succs:{B015, B016}
_L_k0_2_macro:
        join (32|M0)                         _0_032                                                  // 
L3392:
(W)     mov (1|M0)               f2.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $238
        math.rsqtm (16|M16) (eo)f2.0  r13.mme0:f  r15.nomme<1;1,0>:f            {I@1}                //  ALU pipe: math; $238
(f2.0)  goto (32|M0)                         _L_k0_3_macro     _L_k0_3_macro                         //  ALU pipe: int; $238
// B015: [inDivergent],  Preds:{B014},  Succs:{B016}
_L_k0_9_:
        madm (16|M16)            r11.mme1:f    r82.nomme:f       r87.nomme:f       r13.mme0:f       {M@1} //  ALU pipe: float; $238
        madm (16|M16)            r7.mme2:f     r82.nomme:f       r15.nomme:f       r13.mme0:f        //  ALU pipe: float; $238
        madm (16|M16)            r9.mme3:f     r87.nomme:f       -r7.mme2:f        r11.mme1:f       {F@1} //  ALU pipe: float; $238 R{} IR{}{O:3,O:3,O:5,},  {BC=1}
        madm (16|M16)            r11.mme4:f    r11.mme1:f        r9.mme3:f         r11.mme1:f       {F@1} //  ALU pipe: float; $238
        madm (16|M16)            r13.mme5:f    r7.mme2:f         r9.mme3:f         r7.mme2:f         //  ALU pipe: float; $238
        madm (16|M16)            r9.mme6:f     r15.nomme:f       -r13.mme5:f       r13.mme5:f       {F@1} //  ALU pipe: float; $238
        madm (16|M16)            r13.nomme:f   r13.mme5:f        r11.mme4:f        r9.mme6:f        {F@1} //  ALU pipe: float; $238 R{} IR{}{O:6,O:5,O:4,},  {BC=1}
// B016: [inDivergent],  Preds:{B015, B014},  Succs:{B017, B032}
_L_k0_3_macro:
        join (32|M0)                         _0_032                                                  // 
L3568:
        mov (32|M0)              r6.0<1>:f     r12.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $238
        store.ugm.d32.a64.wb.wb (32|M0)  [r83:4] r6:2              {F@1,$13} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $239
        sel (32|M0)   (lt)f0.0   r6.0<1>:d     r46.0<1;1,0>:d    2556:w               {$13.src}      //  ALU pipe: int; $241
        add (32|M0)              r14.0<1>:d    r6.0<1;1,0>:d     4:w               {Compacted,I@1}   //  ALU pipe: int; $242
        cmp (32|M0)   (lt)f1.0   null<1>:d     r46.0<1;1,0>:d    r14.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $243 R{} IR{}{E:7,E:7,},  R{} IR{}{O:7,O:7,},  {BC=2}
        load.ugm.d32.a64.ca.ca (32|M0)  r20:2   [r83:4]            {$4} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $240
(~f1.0) goto (32|M0)                         _0_032            _0_032                                //  ALU pipe: int; $244
// B017: [inDivergent],  Preds:{B016},  Succs:{B018, B019}
_0_038:
(W)     mov (32|M0)              r1.0<1>:f     0x3F800000:f                                          //  ALU pipe: float; $246
(W)     mov (1|M0)               f1.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $246
        math.invm (16|M0) (eo)f1.0  r12.mme0:f  r1.nomme<1;1,0>:f  r20.nomme<1;1,0>:f {A@1,$4.dst}   //  ALU pipe: math; $246
(f1.0)  goto (32|M0)                         _L_k0_4_macro     _L_k0_4_macro                         //  ALU pipe: int; $246
// B018: [inDivergent],  Preds:{B017},  Succs:{B019}
_L_k0_10_:
        madm (16|M0)             r10.mme1:f    r82.nomme:f       r1.nomme:f        r12.mme0:f       {M@1} //  ALU pipe: float; $246
        madm (16|M0)             r8.mme2:f     r88.nomme:f       -r20.nomme:f      r12.mme0:f        //  ALU pipe: float; $246
        madm (16|M0)             r18.mme3:f    r12.mme0:f        r8.mme2:f         r12.mme0:f       {F@1} //  ALU pipe: float; $246
        madm (16|M0)             r6.mme4:f     r1.nomme:f        -r20.nomme:f      r10.mme1:f        //  ALU pipe: float; $246
        madm (16|M0)             r10.mme5:f    r10.mme1:f        r6.mme4:f         r18.mme3:f       {F@1} //  ALU pipe: float; $246 R{} IR{}{E:5,E:3,E:1,},  {BC=1}
        madm (16|M0)             r16.mme6:f    r1.nomme:f        -r20.nomme:f      r10.mme5:f       {F@1} //  ALU pipe: float; $246
        madm (16|M0)             r12.nomme:f   r10.mme5:f        r16.mme6:f        r18.mme3:f       {F@1} //  ALU pipe: float; $246 R{} IR{}{E:5,E:0,E:1,},  {BC=1}
// B019: [inDivergent],  Preds:{B018, B017},  Succs:{B020, B021}
_L_k0_4_macro:
        join (32|M0)                         _0_032                                                  // 
L3856:
(W)     mov (1|M0)               f1.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $246
        math.invm (16|M16) (eo)f1.0  r13.mme0:f  r2.nomme<1;1,0>:f  r21.nomme<1;1,0>:f {I@1}         //  ALU pipe: math; $246
(f1.0)  goto (32|M0)                         _L_k0_5_macro     _L_k0_5_macro                         //  ALU pipe: int; $246
// B020: [inDivergent],  Preds:{B019},  Succs:{B021}
_L_k0_11_:
        madm (16|M16)            r11.mme1:f    r82.nomme:f       r2.nomme:f        r13.mme0:f       {M@1} //  ALU pipe: float; $246 R{} IR{}{E:1,E:1,O:6,},  {BC=1}
        madm (16|M16)            r9.mme2:f     r88.nomme:f       -r21.nomme:f      r13.mme0:f        //  ALU pipe: float; $246
        madm (16|M16)            r19.mme3:f    r13.mme0:f        r9.mme2:f         r13.mme0:f       {F@1} //  ALU pipe: float; $246
        madm (16|M16)            r7.mme4:f     r2.nomme:f        -r21.nomme:f      r11.mme1:f        //  ALU pipe: float; $246
        madm (16|M16)            r11.mme5:f    r11.mme1:f        r7.mme4:f         r19.mme3:f       {F@1} //  ALU pipe: float; $246 R{} IR{}{O:5,O:3,O:1,},  {BC=1}
        madm (16|M16)            r17.mme6:f    r2.nomme:f        -r21.nomme:f      r11.mme5:f       {F@1} //  ALU pipe: float; $246
        madm (16|M16)            r13.nomme:f   r11.mme5:f        r17.mme6:f        r19.mme3:f       {F@1} //  ALU pipe: float; $246 R{} IR{}{O:5,O:0,O:1,},  {BC=1}
// B021: [inDivergent],  Preds:{B020, B019},  Succs:{B022}
_L_k0_5_macro:
        join (32|M0)                         _0_032                                                  // 
L4032:
        mov (32|M0)              r8.0<1>:f     r12.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $246
        and (32|M0)              r6.0<1>:d     r72.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $247
// B022: [inDivergent],  Preds:{B028, B021},  Succs:{B023, B024}
_0_039:
        mad (32|M0)              r10.0<1>:d    r46.0<1;0>:d      r72.0<1;0>:d      2560:w               {$14.src} //  ALU pipe: int; $249
        mov (16|M0)              r12.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted,A@1}      //  ALU pipe: int; $251
        shl (16|M0)              r1.0<1>:q     r12.0<2;1,0>:d    1:w               {I@1}             //  ALU pipe: int; $251
        mov (16|M16)             r12.0<2>:ud   r11.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $251
        shl (16|M16)             r20.0<1>:q    r12.0<2;1,0>:d    1:w               {I@1}             //  ALU pipe: int; $251
        add (16|M0)              r10.0<1>:q    r1.0<1;1,0>:q     r3.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $252
        add (16|M16)             r12.0<1>:q    r20.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $252
        load.ugm.d16u32.a64 (32|M0)  r16:2      [r10:4]            {I@1,$15} // ex_desc:0x0; desc:0x8200B80 // $254
        mad (32|M0)              r12.0<1>:d    r46.0<1;0>:d      r6.0<1;0>:d       2560:w               {$15.src} //  ALU pipe: int; $257
        shl (32|M0)              r10.0<1>:d    r16.0<1;1,0>:ud   16:w               {$15.dst}        //  ALU pipe: int; $255
        mov (16|M0)              r16.0<2>:ud   r12.0<1;1,0>:ud                  {Compacted,I@2}      //  ALU pipe: int; $258
        mul (32|M0)              r18.0<1>:f    r8.0<1;1,0>:f     r10.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $256
        mov (16|M0)              r10.0<1>:q    r16.0<2;1,0>:d                   {A@1}                //  ALU pipe: int; $258
        mov (16|M16)             r16.0<2>:ud   r13.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $258
        mov (16|M16)             r22.0<1>:q    r16.0<2;1,0>:d                   {I@1}                //  ALU pipe: int; $258
(W&f0.0) jmpi                                _0_040                                                  //  ALU pipe: int; $259
// B023: [inDivergent],  Preds:{B022},  Succs:{B025}
_0_041:
        shl (16|M0)              r24.0<1>:q    r10.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $261
        shl (16|M16)             r16.0<1>:q    r22.0<1;1,0>:q    2:w               {Compacted,I@3}   //  ALU pipe: int; $261
        add (16|M0)              r10.0<1>:q    r24.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $262
        add (16|M16)             r12.0<1>:q    r16.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $262
        load.ugm.d32.a64 (32|M0)  r16:2         [r10:4]            {I@1,$0} // ex_desc:0x0; desc:0x8200580 // $264
(W)     jmpi                                 _0_042                                                  // $265
// B024: [inDivergent],  Preds:{B022},  Succs:{B025}
_0_040:
        shl (16|M0)              r26.0<1>:q    r10.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $267
        shl (16|M16)             r24.0<1>:q    r22.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $267
        add (16|M0)              r10.0<1>:q    r26.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $268
        add (16|M16)             r12.0<1>:q    r24.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $268
        load.ugm.d16u32.a64 (32|M0)  r22:2      [r10:4]            {I@1,$1} // ex_desc:0x0; desc:0x8200B80 // $270
        shl (32|M0)              r16.0<1>:d    r22.0<1;1,0>:ud   16:w               {$1.dst}         //  ALU pipe: int; $271
// B025: [inDivergent],  Preds:{B024, B023},  Succs:{B026, B027}
_0_042:
        sync.nop                             null                             {Compacted,I@1}        // $273
        add (32|M0)              acc0.0<1>:f   r16.0<1;1,0>:f    r3.0<0;1,0>:f    {Compacted,$0.dst} //  ALU pipe: float; $273
        mul (32|M0)              r10.0<1>:f    r18.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $274
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $275
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r12.0<1;1,0>:ud   0x7F800000:ud              {I@1}    //  ALU pipe: int; $276
(f3.0)  goto (32|M0)                         _0_043            _0_043                                //  ALU pipe: int; $277
// B026: [inDivergent],  Preds:{B025},  Succs:{B028}
_0_044:
        shr (32|M0)              r12.0<1>:ud   r10.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $279
        and (32|M0)              r16.0<1>:d    r12.0<1;1,0>:d    1:w               {Compacted,I@1}   //  ALU pipe: int; $280
        add3 (32|M0)             r12.0<1>:d    r16.0<1;0>:d      r10.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $281
        shr (32|M0)              r10.0<1>:ud   r12.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $282
        mov (32|M0)              r16.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $283
        goto (32|M0)                         _0_043            _0_045                                // $284
// B027: [inDivergent],  Preds:{B025},  Succs:{B028}
_0_043:
        join (32|M0)                         _0_045                                                  // 
L4552:
        shr (32|M0)              r12.0<1>:ud   r10.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $286
        or (32|M0)               r16.0<1>:w    r12.0<2;1,0>:w    64:w               {I@1}            //  ALU pipe: int; $288
// B028: [inDivergent],  Preds:{B027, B026},  Succs:{B029, B022}
_0_045:
        join (32|M0)                         _L_k0_12_                                               // 
L4600:
        add (32|M0)              r46.0<1>:d    r46.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $294
        cmp (32|M0)   (lt)f2.0   null<1>:d     r46.0<1;1,0>:d    r14.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $295 R{} IR{}{E:7,E:7,},  R{} IR{}{O:7,O:7,},  {BC=2}
        add (16|M0)              r10.0<1>:q    r1.0<1;1,0>:q     r3.6<0;1,0>:q                       //  ALU pipe: int; $290
        add (16|M16)             r12.0<1>:q    r20.0<1;1,0>:q    r3.6<0;1,0>:q                       //  ALU pipe: int; $290
        mov (32|M0)              r18.0<1>:ud   r16.0<1;1,0>:uw                                       //  ALU pipe: int; $292
        store.ugm.d16u32.a64 (32|M0)  [r10:4]   r18:2              {I@1,$14} // ex_desc:0x0; desc:0x8000B84 // $293
(f2.0)  goto.b (32|M0)                       _L_k0_12_         _0_039                                //  ALU pipe: int; $296
// B029: [inDivergent],  Preds:{B028},  Succs:{B032}
_L_k0_12_:
        join (32|M0)                         _0_032                                                  // 
L4720:
        goto (32|M0)                         _0_032            _0_032                                // $297
// B030: [inDivergent],  Preds:{B007},  Succs:{B031, B032}
_0_036:
        cmp (32|M0)   (eq)f2.0   null<1>:d     r8.0<1;1,0>:d     0:w                                 //  ALU pipe: int; $299
(f2.0)  cmp (32|M0)   (eq)f2.0   null<1>:d     r6.0<1;1,0>:d     0:w                                 //  ALU pipe: int; $300
(~f2.0) goto (32|M0)                         _0_032            _0_032                                //  ALU pipe: int; $302
// B031: [inDivergent],  Preds:{B030},  Succs:{B032}
_0_046:
        mov (16|M0)              r6.0<2>:f     r100.0<0;1,0>:f                  {I@2}                //  ALU pipe: float; $304
        mov (16|M16)             r8.0<2>:f     r100.0<0;1,0>:f                                       //  ALU pipe: float; $304
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted,$14.src} //  ALU pipe: int; $306
        mov (16|M0)              r6.1<2>:f     r100.1<0;1,0>:f                                       //  ALU pipe: float; $305
        mov (16|M16)             r8.1<2>:ud    r100.1<0;1,0>:ud                 {F@2}                //  ALU pipe: int; $305
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$2} // ex_desc:0x0; desc:0x800058B // $307
// B032: [inDivergent],  Preds:{B031, B030, B029, B016, B006, B005, B004},  Succs:{B033, B034}
_0_032:
        join (32|M0)                         _0_029                                                  // 
L4888:
        sync.nop                             null                             {Compacted,$2.src}     // $309
        add (16|M0)              r10.0<1>:q    r76.0<1;1,0>:q    r3.2<0;1,0>:q    {Compacted,$14.src} //  ALU pipe: int; $309
        add (16|M16)             r1.0<1>:q     r74.0<1;1,0>:q    r3.2<0;1,0>:q    {Compacted}        //  ALU pipe: int; $309
        mov (16|M0)              r8.0<1>:d     r10.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $310
        mov (16|M16)             r9.0<1>:d     r1.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $311
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r8.0<1;1,0>:ud    r3.2<0;1,0>:ud   {I@1}              //  ALU pipe: int; $314
        mov (16|M0)              r6.0<1>:d     r10.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $312
        mov (16|M16)             r7.0<1>:d     r1.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $313
(f1.0)  cmp (32|M0)   (eq)f1.0   null<1>:d     r6.0<1;1,0>:d     r3.3<0;1,0>:d    {I@1}              //  ALU pipe: int; $315
(~f1.0) cmp (32|M0)   (lt)f1.0   null<1>:ud    r6.0<1;1,0>:ud    r3.3<0;1,0>:ud                      //  ALU pipe: int; $317
(~f1.0) goto (32|M0)                         _0_029            _0_029                                //  ALU pipe: int; $319
// B033: [inDivergent],  Preds:{B032},  Succs:{B004}
_0_047:
(f1.0)  sel (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     r98.0<1;1,0>:d                      //  ALU pipe: int; $321
(f1.0)  sel (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     r96.0<1;1,0>:d                      //  ALU pipe: int; $322
        mov (16|M0)              r76.0<2>:d    r10.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $325
        mov (16|M16)             r74.0<2>:d    r11.0<1;1,0>:d                                        //  ALU pipe: int; $326
        mov (16|M0)              r76.1<2>:d    r8.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $327
        mov (16|M16)             r74.1<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $328
(W)     jmpi                                 _0_031                                                  // $329
// B034: Preds:{B032, B002},  Succs:{}
_0_029:
        join (32|M0)                         L5136                                                   // 
L5136:
(W)     mov (16|M0)              r112.0<1>:f   r4.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $331
(W)     send.gtwy (1|M0)         null     r112  null:0  0x0            0x02000010           {EOT,F@1,$3} // wr:1+0, rd:0; end of thread // $331
L5160:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x3:ud                                                // 


//.BankConflicts: 17
//.ByteRMWs: 0
//


//.numALUInst: 351
//.accSubDef: 8
//.accSubUse: 8
//.accSubCandidateDef: 80
//.accSubCandidateUse: 80
//
//
//.singlePipeAtOneDistNum: 78
//.allAtOneDistNum: 14
//.syncInstCount: 4
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 32
//.AfterReadTokenDepCount: 11
