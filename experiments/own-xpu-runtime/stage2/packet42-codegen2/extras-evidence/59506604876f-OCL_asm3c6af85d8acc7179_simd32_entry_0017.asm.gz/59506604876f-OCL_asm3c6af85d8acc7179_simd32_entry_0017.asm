//.kernel _ZTSN4sycl3_V16detail19__pf_kernel_wrapperIN9p42extras8FlatNameILNS3_4KindE0ELi0EEEEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 17 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 17 -GRFBumpUpNumber 2 "
//.instCount 373
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 10
//.spill flag load 10

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r40.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.9)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.10)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.6)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.7)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.8)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r40.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r40.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r5.2)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r5.0)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.10)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r4.6)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.14)
//.declare V0061 (71)  rf=r size=4 type=d align=2 words (r4.15)
//.declare V0063 (73)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0064 (74)  rf=r size=8 type=d alias=V0044+0 align=4 words (r2.6)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0066 (76)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.3)
//.declare V0067 (77)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r40.0)
//.declare V0068 (78)  rf=r size=8 type=ud alias=V0065+0 align=4 words (r5.0)
//.declare V0069 (79)  rf=r size=8 type=d alias=V0065+0 align=4 words (r5.0)
//.declare V0070 (80)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0073 (83)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0076 (86)  rf=r size=12 type=ud alias=V0036+0 align=2 words (r2.0)
//.declare V0080 (90)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0081 (91)  rf=r size=128 type=d align=32 words (r86.0)
//.declare P01 (92)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0082 (93)  rf=r size=128 type=ud alias=V0080+0 align=32 words (r84.0)
//.declare V0083 (94)  rf=r size=8 type=ud alias=V0063+0 align=2 words (r2.8)
//.declare P02 (95)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P03 (96)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0084 (97)  rf=r size=128 type=ud alias=V0081+0 align=32 words (r86.0)
//.declare V0085 (98)  rf=r size=8 type=d align=2 words (r2.10)
//.declare V0086 (99)  rf=r size=8 type=d alias=V0046+0 align=4 words (r3.2)
//.declare V0087 (100)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r4.4)
//.declare V0088 (101)  rf=r size=8 type=uq alias=V0059+0 align=4 words (r4.6)
//.declare V0089 (102)  rf=r size=8 type=uq align=32 words (r88.0)
//.declare V0090 (103)  rf=r size=8 type=uq align=32 words (r90.0)
//.declare P04 (104)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P05 (105)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P06 (106)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0091 (107)  rf=r size=4 type=ud alias=V0047+0 align=2 words (r3.4)
//.declare P07 (108)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P08 (109)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P09 (110)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P10 (111)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0092 (112)  rf=r size=4 type=ud alias=V0056+0 align=2 words (r4.6)
//.declare P11 (113)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0093 (114)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0094 (115)  rf=r size=4 type=d align=4 words (r2.14)
//.declare V0095 (116)  rf=r size=8 type=df align=4 words (r3.3)
//.declare V0096 (117)  rf=r size=8 type=uq alias=V0046+0 align=4 words (r3.1)
//.declare V0097 (118)  rf=r size=4 type=f align=4 words (r4.0)
//.declare V0098 (119)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0099 (120)  rf=r size=8 type=df align=4 words (r6.0)
//.declare V0100 (121)  rf=r size=8 type=df align=4 words (r8.0)
//.declare V0101 (122)  rf=r size=8 type=df align=4 words (r7.0)
//.declare V0102 (123)  rf=r size=8 type=df align=4 words (r11.0)
//.declare V0104 (125)  rf=r size=8 type=df align=4 words (r67.0)
//.declare P12 (126)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P13 (127)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P14 (128)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P15 (129)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P16 (130)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0105 (131)  rf=r size=8 type=q align=4 words (r67.1)
//.declare V0106 (132)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r5.2)
//.declare V0107 (133)  rf=r size=8 type=df align=4 words (r67.2)
//.declare V0108 (134)  rf=r size=4 type=d align=32 words (r4.0)
//.declare P17 (135)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0110 (137)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0111 (138)  rf=r size=256 type=ud alias=V0110+0 align=32 words (r6.0)
//.declare V0112 (139)  rf=r size=8 type=ud alias=V0090+0 align=32 words (r90.0)
//.declare V0113 (140)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0114 (141)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P18 (143)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0117 (145)  rf=r size=128 type=d align=32 words (r91.0)
//.declare V0118 (146)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0119 (147)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P19 (148)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0120 (149)  rf=r size=128 type=ud alias=V0119+0 align=32 words (r8.0)
//.declare V0121 (150)  rf=r size=128 type=d align=32 words (r93.0)
//.declare V0122 (151)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0123 (152)  rf=r size=4 type=f align=2 words (r8.0)
//.declare V0124 (153)  rf=r size=4 type=ud alias=V0094+0 align=2 words (r2.14)
//.declare V0125 (154)  rf=r size=4 type=d align=2 words (r9.0)
//.declare V0126 (155)  rf=r size=4 type=ud alias=V0125+0 align=2 words (r9.0)
//.declare V0127 (156)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0128 (157)  rf=r size=128 type=f align=32 words (r11.0)
//.declare V0129 (158)  rf=r size=128 type=ud alias=V0122+0 align=32 words (r6.0)
//.declare V0130 (159)  rf=r size=4 type=f align=2 words (r14.0)
//.declare V0131 (160)  rf=r size=4 type=f align=2 words (r16.0)
//.declare V0132 (161)  rf=r size=128 type=f align=32 words (r17.0)
//.declare V0133 (162)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0134 (163)  rf=r size=128 type=ud alias=V0133+0 align=32 words (r19.0)
//.declare V0135 (164)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0136 (165)  rf=r size=128 type=d align=32 words (r23.0)
//.declare V0137 (166)  rf=r size=128 type=ud alias=V0136+0 align=32 words (r23.0)
//.declare V0138 (167)  rf=r size=4 type=f align=2 words (r26.0)
//.declare V0139 (168)  rf=r size=4 type=ud alias=V0127+0 align=2 words (r10.0)
//.declare V0140 (169)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0141 (170)  rf=r size=128 type=ud alias=V0135+0 align=32 words (r21.0)
//.declare V0142 (171)  rf=r size=128 type=f align=32 words (r31.0)
//.declare V0148 (177)  rf=r size=128 type=f align=32 words (r33.0)
//.declare V0149 (178)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0150 (179)  rf=r size=128 type=ud alias=V0149+0 align=32 words (r35.0)
//.declare V0151 (180)  rf=r size=128 type=d align=32 words (r37.0)
//.declare V0152 (181)  rf=r size=128 type=d align=32 words (r41.0)
//.declare V0153 (182)  rf=r size=128 type=d align=32 words (r43.0)
//.declare P20 (183)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0154 (184)  rf=r size=128 type=ud alias=V0153+0 align=32 words (r43.0)
//.declare V0155 (185)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0157 (187)  rf=r size=128 type=ud alias=V0121+0 align=32 words (r93.0)
//.declare V0159 (189)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0161 (191)  rf=r size=128 type=ud alias=V0159+0 align=32 words (r6.0)
//.declare V0163 (193)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0164 (194)  rf=r size=128 type=ud alias=V0163+0 align=32 words (r22.0)
//.declare V0165 (195)  rf=r size=128 type=d align=32 words (r27.0)
//.declare V0166 (196)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0169 (199)  rf=r size=128 type=ud alias=V0166+0 align=32 words (r29.0)
//.declare V0178 (208)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0179 (209)  rf=r size=128 type=d align=32 words (r59.0)
//.declare V0180 (210)  rf=r size=128 type=d align=32 words (r61.0)
//.declare V0181 (211)  rf=r size=128 type=d align=32 words (r63.0)
//.declare P21 (212)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0182 (213)  rf=r size=128 type=ud alias=V0179+0 align=32 words (r59.0)
//.declare V0183 (214)  rf=r size=128 type=d align=32 words (r65.0)
//.declare V0184 (215)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0185 (216)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0192 (223)  rf=r size=128 type=ud alias=V0178+0 align=32 words (r57.0)
//.declare V0193 (224)  rf=r size=8 type=ud alias=V0085+0 align=2 words (r2.10)
//.declare V0196 (227)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0197 (228)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0201 (232)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0202 (233)  rf=r size=128 type=d align=32 words (r30.0)
//.declare P22 (234)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0203 (235)  rf=r size=128 type=ud alias=V0201+0 align=32 words (r28.0)
//.declare P23 (236)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P24 (237)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0204 (238)  rf=r size=128 type=ud alias=V0202+0 align=32 words (r30.0)
//.declare V0210 (244)  rf=r size=128 type=f align=32 words (r95.0)
//.declare V0214 (248)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0215 (249)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0219 (253)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0220 (254)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0221 (255)  rf=r size=128 type=ud alias=V0220+0 align=32 words (r14.0)
//.declare V0225 (259)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0226 (260)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0230 (264)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0232 (266)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0233 (267)  rf=r size=128 type=w alias=V0232+0 align=32 words (r14.0)
//.declare V0235 (269)  rf=r size=128 type=d alias=V0210+0 align=32 words (r95.0)
//.declare V0239 (273)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0243 (277)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0245 (279)  rf=r size=256 type=d align=32 words (r22.0)
//.declare V0247 (281)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0248 (282)  rf=r size=128 type=ud alias=V0247+0 align=32 words (r6.0)
//.declare V0252 (286)  rf=r size=256 type=uq align=32 words (r12.0)
//.declare V0253 (287)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0257 (291)  rf=r size=256 type=uq align=32 words (r12.0)
//.declare V0258 (292)  rf=r size=128 type=d align=32 words (r6.0)
//.declare P25 (293)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0259 (294)  rf=r size=128 type=ud alias=V0258+0 align=32 words (r6.0)
//.declare V0260 (295)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0261 (296)  rf=r size=128 type=ud alias=V0210+0 align=32 words (r95.0)
//.declare V0262 (297)  rf=r size=128 type=ud alias=V0260+0 align=32 words (r6.0)
//.declare V0263 (298)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0264 (299)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0265 (300)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0266 (301)  rf=r size=128 type=ud alias=V0264+0 align=32 words (r10.0)
//.declare V0267 (302)  rf=r size=128 type=ud alias=V0265+0 align=32 words (r12.0)
//.declare V0268 (303)  rf=r size=64 type=w align=32 words (r89.0)
//.declare V0269 (304)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0270 (305)  rf=r size=128 type=ud alias=V0269+0 align=32 words (r6.0)
//.declare V0275 (310)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0276 (311)  rf=r size=64 type=uw alias=V0268+0 align=32 words (r89.0)
//.declare V0277 (312)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0281 (316)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0285 (320)  rf=r size=128 type=d align=32 words (r97.0)
//.declare V0286 (321)  rf=r size=128 type=d align=32 words (r99.0)
//.declare P26 (322)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0287 (323)  rf=r size=128 type=ud alias=V0285+0 align=32 words (r97.0)
//.declare P27 (324)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P28 (325)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0288 (326)  rf=r size=128 type=ud alias=V0286+0 align=32 words (r99.0)
//.declare  (330)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (333)  rf=r size=128 type=w alias=V0269+0 align=32 words (r6.0)
//.declare  (334)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (335)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (336)  rf=r size=128 type=uw align=32 words (r11.0)
//.declare  (337)  rf=r size=8 type=df align=4 words (r9.0)
//.declare  (338)  rf=r size=4 type=f align=2 words (r15.0)
//.declare  (341)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (342)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (343)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare  (344)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (347)  rf=r size=64 type=ud align=32 words (r14.0)
//.declare  (348)  rf=r size=64 type=ud align=32 words (r17.0)
//.declare  (349)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (350)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (351)  rf=r size=128 type=ud align=32 words (r31.0)
//.declare  (352)  rf=r size=128 type=ud align=32 words (r36.0)
//.declare  (353)  rf=r size=128 type=ud align=32 words (r72.0)
//.declare  (354)  rf=r size=128 type=ud align=32 words (r76.0)
//.declare  (355)  rf=r size=128 type=f align=32 words (r18.0)
//.declare  (356)  rf=r size=128 type=f align=32 words (r20.0)
//.declare  (357)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (358)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (359)  rf=r size=128 type=w alias=V0265+0 align=32 words (r12.0)
//.declare  (362)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (363)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (364)  rf=r size=128 type=q align=32 words (r101.0)
//.declare  (365)  rf=r size=128 type=q align=32 words (r103.0)
//.declare  (370)  rf=r size=128 type=q align=32 words (r105.0)
//.declare  (371)  rf=r size=128 type=q align=32 words (r107.0)
//.declare  (372)  rf=r size=128 type=df align=32 words (r10.0)
//.declare  (373)  rf=r size=128 type=df align=32 words (r14.0)
//.declare  (374)  rf=r size=128 type=df align=32 words (r16.0)
//.declare  (375)  rf=r size=128 type=df align=32 words (r18.0)
//.declare  (376)  rf=r size=128 type=df align=32 words (r34.0)
//.declare  (377)  rf=r size=128 type=df align=32 words (r38.0)
//.declare  (378)  rf=r size=128 type=df align=32 words (r41.0)
//.declare  (379)  rf=r size=128 type=df align=32 words (r43.0)
//.declare  (380)  rf=r size=128 type=df align=32 words (r45.0)
//.declare  (381)  rf=r size=128 type=df align=32 words (r47.0)
//.declare  (382)  rf=r size=128 type=df align=32 words (r49.0)
//.declare  (383)  rf=r size=128 type=df align=32 words (r51.0)
//.declare  (384)  rf=r size=128 type=q align=32 words (r53.0)
//.declare  (385)  rf=r size=128 type=q align=32 words (r55.0)
//.declare  (388)  rf=r size=128 type=q align=32 words (r74.0)
//.declare  (389)  rf=r size=128 type=q align=32 words (r78.0)
//.declare  (390)  rf=r size=128 type=d align=32 words (r80.0)
//.declare  (391)  rf=r size=128 type=d align=32 words (r82.0)
//.declare  (392)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (393)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (394)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (395)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (396)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (397)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (398)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (399)  rf=r size=128 type=q align=32 words (r26.0)
//.declare  (402)  rf=r size=128 type=d align=32 words (r32.0)
//.declare  (403)  rf=r size=128 type=d align=32 words (r34.0)
//.declare  (404)  rf=r size=128 type=q align=32 words (r36.0)
//.declare  (405)  rf=r size=128 type=q align=32 words (r38.0)
//.declare  (406)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (407)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (410)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (411)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (414)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (415)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (418)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (419)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (422)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (423)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (426)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (427)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (430)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (431)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (432)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (433)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (436)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (437)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (440)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (441)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (444)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (445)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (448)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (449)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (452)  rf=r size=128 type=d align=32 words (r6.0)
//.declare  (453)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (454)  rf=r size=128 type=d alias=+0 align=32 words (r101.0)
//.declare  (455)  rf=r size=128 type=d alias=+0 align=32 words (r103.0)
//.declare  (456)  rf=r size=128 type=ud alias=+0 align=32 words (r101.0)
//.declare  (457)  rf=r size=128 type=ud alias=+0 align=32 words (r103.0)
//.declare  (458)  rf=r size=128 type=uq alias=+0 align=32 words (r53.0)
//.declare  (459)  rf=r size=128 type=uq alias=+0 align=32 words (r55.0)
//.declare  (460)  rf=r size=128 type=d alias=+0 align=32 words (r53.0)
//.declare  (461)  rf=r size=128 type=d alias=+0 align=32 words (r55.0)
//.declare  (462)  rf=r size=128 type=d alias=+0 align=32 words (r6.0)
//.declare  (463)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (464)  rf=r size=128 type=ud alias=+0 align=32 words (r15.0)
//.declare  (465)  rf=r size=128 type=ud alias=+0 align=32 words (r18.0)
//.declare  (466)  rf=r size=128 type=d alias=+0 align=32 words (r15.0)
//.declare  (467)  rf=r size=128 type=d alias=+0 align=32 words (r18.0)
//.declare  (468)  rf=r size=128 type=d alias=+0 align=32 words (r24.0)
//.declare  (469)  rf=r size=128 type=d alias=+0 align=32 words (r26.0)
//.declare  (470)  rf=r size=128 type=d alias=+0 align=32 words (r36.0)
//.declare  (471)  rf=r size=128 type=d alias=+0 align=32 words (r38.0)
//.declare  (472)  rf=r size=128 type=d alias=+0 align=32 words (r16.0)
//.declare  (473)  rf=r size=128 type=d alias=+0 align=32 words (r20.0)
//.declare  (474)  rf=r size=128 type=d alias=+0 align=32 words (r6.0)
//.declare  (475)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (476)  rf=r size=4 type=uw align=2 words (r2.26)
//.declare  (477)  rf=r size=4 type=uw align=2 words (r2.30)
//.declare  (478)  rf=r size=4 type=uw align=2 words (r67.12)
//.declare  (479)  rf=r size=4 type=uw align=2 words (r67.14)
//.declare  (480)  rf=r size=4 type=uw align=2 words (r67.16)
//.declare  (481)  rf=r size=4 type=uw align=2 words (r67.18)
//.declare  (482)  rf=r size=4 type=uw align=2 words (r67.20)
//.declare  (483)  rf=r size=4 type=uw align=2 words (r67.22)
//.declare  (484)  rf=r size=4 type=uw align=2 words (r67.24)
//.declare  (485)  rf=r size=4 type=uw align=2 words (r67.26)
//.declare  (486)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (487)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (488)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (489)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (490)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (491)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (492)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (493)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (494)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (495)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (496)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (497)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (498)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (499)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (500)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (501)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (502)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (503)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (504)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (505)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare r0 (506)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (507)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (508)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (509)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (510)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (511)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (512)  rf=r size=32 type=ud align=2 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0045    | :q       |    0x8 | r3       | cti+0x20         |
// | V0046    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0049    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0050    | :d       |    0x4 | r3+0x28  | cti+0x48         |
// | V0051    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0052    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r4       | cti+0x60         |
// | V0054    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0055    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0056    | :d       |    0x4 | r4+0x18  | cti+0x78         |
// | V0057    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0058    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0059    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0060    | :d       |    0x4 | r4+0x38  | cti+0x98         |
// | V0061    | :d       |    0x4 | r4+0x3C  | cti+0x9C         |
// | V0042    | :uq      |    0x8 | r5       | cti+0xA0         |
// | V0037    | :d x 3   |    0xC | r5+0x8   | cti+0xA8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xA0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r5:1  bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B041}
// _main:
(W)     mov (16|M0)              r40.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r40.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r4.0<1>:ud    r2.3<0;1,0>:ud    r40.1<0;1,0>:ud  {Compacted,$1.dst} //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r40.2<0;1,0>:uw                     //  ALU pipe: int; $4
(W)     mach (1|M0)              r6.0<1>:d     r2.3<0;1,0>:ud    r40.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r11.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
        sync.nop                             null                             {Compacted,I@5}        // $4
(W)     mov (1|M0)               r5.0<2>:f     r4.0<0;1,0>:f                    {$2.dst}             //  ALU pipe: float; $4
(W)     mov (1|M0)               r5.1<2>:d     r6.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r2.8<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r9.0<1>:q     r5.0<0;1,0>:q     r7.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $10
        add (16|M16)             r13.0<1>:q    r5.0<0;1,0>:q     r11.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r101.0<1>:q   r9.0<1;1,0>:q     r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r103.0<1>:q   r13.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r84.0<1>:d    r101.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r85.0<1>:d    r103.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r84.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r86.0<1>:d    r101.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r87.0<1>:d    r103.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $16
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r86.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $18
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r86.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $20
(~f0.0) goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_049:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $27
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $28
(W)     mov (1|M0)               r3.3<1>:df    r3.1<0;1,0>:uq                                        //  ALU pipe: long; $37
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.4<0;1,0>:d     4:w                                 //  ALU pipe: int; $30
(W)     mov (1|M0)               r4.0<2>:f     r3.3<0;1,0>:df                   {L@1}                //  ALU pipe: float; $38
(W)     mov (1|M0)               r67.13<1>:ud  f1.0<0;1,0>:ud                                        //  ALU pipe: int; $27
(W)     mov (1|M0)               r67.12<1>:ud  f0.0<0;1,0>:ud                                        //  ALU pipe: int; $28
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r4.6<0;1,0>:d     2:w                                 //  ALU pipe: int; $31
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r4.6<0;1,0>:d     2:w                                 //  ALU pipe: int; $32
(W)     math.inv (1|M0)          r5.0<1>:f     r4.0<0;1,0>:f                    {F@1}                //  ALU pipe: math; $39
(W)     mov (1|M0)               r2.14<2>:d    r3.1<0;1,0>:q                                         //  ALU pipe: int; $36
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r3.4<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $29
(W)     mov (1|M0)               r67.10<1>:ud  f2.0<0;1,0>:ud                                        //  ALU pipe: int; $30
(W)     mov (1|M0)               r67.9<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $31
(W)     mov (1|M0)               r67.8<1>:ud   f0.0<0;1,0>:ud                                        //  ALU pipe: int; $32
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r4.6<0;1,0>:d     4:w                                 //  ALU pipe: int; $34
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r2.14<0;1,0>:d    0:w               {I@6}             //  ALU pipe: int; $46
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r3.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $47
(W)     mov (1|M0)               r7.0<1>:df    0x3FF0000000000000:df                                 //  ALU pipe: long; $41
(W)     mov (1|M0)               r6.0<1>:df    r5.0<0;1,0>:f                    {M@1}                //  ALU pipe: long; $40
(W)     mov (1|M0)               r9.0<1>:df    0xBCF0000000000000:df                                 //  ALU pipe: long; $44
(W)     mov (1|M0)               r67.11<1>:ud  f3.0<0;1,0>:ud                                        //  ALU pipe: int; $29
(W)     mad (1|M0)               r8.0<1>:df    r7.0<0;0>:df      r6.0<0;0>:df      -r3.3<0>:df      {L@2} //  ALU pipe: long; $42
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r4.6<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $33
(W)     mov (1|M0)               r67.6<1>:ud   f2.0<0;1,0>:ud                                        //  ALU pipe: int; $34
(W)     mov (1|M0)               r2.15<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $46
(W)     mov (1|M0)               r2.13<1>:ud   f0.0<0;1,0>:ud                                        //  ALU pipe: int; $47
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $48
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r4.6<0;1,0>:d     1:w                                 //  ALU pipe: int; $49
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r4.6<0;1,0>:d     0:w                                 //  ALU pipe: int; $50
(W)     add (1|M0)               r11.0<1>:df   r8.0<0;1,0>:df    r9.0<0;1,0>:df   {Compacted,L@1}    //  ALU pipe: long; $44
(W)     mov (2|M0)               r2.10<1>:d    r3.2<1;1,0>:d                                         //  ALU pipe: int; $24
(W)     mov (1|M0)               r88.0<1>:uq   r4.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $25
(W)     mov (1|M0)               r90.0<1>:uq   r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $26
(W)     mov (1|M0)               r2.12<1>:d    r3.3<0;1,0>:d                                         //  ALU pipe: int; $35
(W)     mov (1|M0)               r67.1<1>:q    r5.2<0;1,0>:ud                                        //  ALU pipe: int; $51
(W)     mov (1|M0)               r67.2<1>:df   0x41F0000000000000:df                                 //  ALU pipe: long; $52
(W)     mov (1|M0)               r67.7<1>:ud   f3.0<0;1,0>:ud                                        //  ALU pipe: int; $33
(W)     mad (1|M0)               r67.0<1>:df   r6.0<0;0>:df      r11.0<0;0>:df     r6.0<0>:df       {L@2} //  ALU pipe: long; $45
// B004: [inDivergent],  Preds:{B040, B003},  Succs:{B005, B039}
_0_050:
(W)     load.ugm.d32x1t.a64 (1|M0)  r4:1        [r88:1]            {I@4,$3} // ex_desc:0x0; desc:0x2108580 // $54
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r4.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $55
(W&f3.0) jmpi                                _0_051                                                  //  ALU pipe: int; $56
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B039}
_0_052:
        mov (16|M0)              r6.0<2>:f     r90.0<0;1,0>:f                   {L@1}                //  ALU pipe: float; $58
        mov (16|M16)             r8.0<2>:f     r90.0<0;1,0>:f                                        //  ALU pipe: float; $58
        sync.allrd                           ($4,$6,$7)                                              // $60
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted,$5.src}  //  ALU pipe: int; $60
        mov (16|M0)              r6.1<2>:f     r90.1<0;1,0>:f                                        //  ALU pipe: float; $59
        mov (16|M16)             r8.1<2>:ud    r90.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $59
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$8} // ex_desc:0x0; desc:0x8200599 // $61
        cmp (32|M0)   (eq)f3.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$8.dst}          //  ALU pipe: int; $63
(~f3.0) goto (32|M0)                         _0_051            _0_051                                //  ALU pipe: int; $64
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B011}
_0_053:
        or (16|M0)               r8.0<1>:d     r101.1<2;1,0>:d   r2.11<0;1,0>:d   {Compacted}        //  ALU pipe: int; $70
        or (16|M16)              r9.0<1>:d     r103.1<2;1,0>:d   r2.11<0;1,0>:d   {Compacted}        //  ALU pipe: int; $71
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r8.0<1;1,0>:ud    0x1:uw              {I@1}           //  ALU pipe: int; $72
        mov (16|M0)              r91.0<1>:d    r101.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $66
        mov (16|M16)             r92.0<1>:d    r103.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $67
        mov (16|M0)              r6.0<1>:d     r101.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $68
        mov (16|M16)             r7.0<1>:d     r103.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $69
(~f3.0) goto (32|M0)                         _0_054            _0_054                                //  ALU pipe: int; $73
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B009}
_0_055:
(W)     mov (1|M0)               f3.0<1>:ud    r2.15<0;1,0>:ud                                       //  ALU pipe: int; $75
(W&~f3.0) jmpi                               _0_056                                                  //  ALU pipe: int; $75
// B008: [inDivergent],  Preds:{B007},  Succs:{B010}
_0_057:
        mov (32|M0)              r93.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $77
(W)     jmpi                                 _0_058                                                  // $78
// B009: [inDivergent],  Preds:{B007},  Succs:{B010}
_0_056:
        mov (16|M0)              r6.0<1>:d     r101.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $80
        mov (16|M16)             r7.0<1>:d     r103.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $80
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $81
(W)     mov (1|M0)               r8.0<1>:f     r2.14<0;1,0>:ud                  {A@1}                //  ALU pipe: float; $82
(W)     mov (1|M0)               r15.0<1>:f    0xB4C00000:f                               {Compacted} //  ALU pipe: float; $87
(W)     math.inv (1|M0)          r14.0<1>:f    r8.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $86
        mov (32|M0)              r11.0<1>:f    r6.0<1;1,0>:ud                   {I@2}                //  ALU pipe: float; $85
(W)     mad (1|M0)               r16.0<1>:f    r14.0<0;0>:f      r15.0<0;0>:f      r14.0<0>:f       {Compacted,A@1} //  ALU pipe: float; $87
        mov (32|M0)              r19.0<1>:ud   r11.0<1;1,0>:f                   {F@2}                //  ALU pipe: int; $89
        mul (32|M0)              r17.0<1>:f    r11.0<1;1,0>:f    r16.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $88
(W)     mov (1|M0)               r9.0<1>:ud    r8.0<0;1,0>:f                                         //  ALU pipe: int; $83
        add (32|M0)              r21.0<1>:d    r6.0<1;1,0>:d     -r19.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $90
        mov (32|M0)              r23.0<1>:ud   r17.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $91
(W)     add (1|M0)               r10.0<1>:d    r2.14<0;1,0>:d    -r9.0<0;1,0>:d   {I@3}              //  ALU pipe: int; $84
        mov (32|M0)              r31.0<1>:f    r23.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $94
        mov (32|M0)              r27.0<1>:f    r21.0<1;1,0>:ud                                       //  ALU pipe: float; $93
(W)     mov (1|M0)               r26.0<1>:f    r10.0<0;1,0>:ud                  {I@1}                //  ALU pipe: float; $92
        mad (32|M0)              acc0.0<1>:f   r11.0<1;0>:f      r31.0<1;0>:f      -r8.0<0>:f       {F@3} //  ALU pipe: float; $96
        mad (32|M0)              acc2.0<1>:f   r27.0<1;0>:f      r31.0<1;0>:f      -r26.0<0>:f      {F@2} //  ALU pipe: float; $98
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $99
        mul (32|M0)              r33.0<1>:f    r16.0<0;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $100
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $101
        mov (32|M0)              r35.0<1>:ud   r33.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $102
        add (32|M0)              r37.0<1>:d    r35.0<1;1,0>:d    r23.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $103
(W)     mul (16|M0)              acc0.0<1>:d   r37.0<1;1,0>:d    r2.28<0;1,0>:uw  {I@1}              //  ALU pipe: int; $104
        macl (16|M0)             r41.0<1>:d    r37.0<1;1,0>:d    r2.14<0;1,0>:d   {Compacted}        //  ALU pipe: int; $104
(W)     mul (16|M16)             acc0.0<1>:d   r38.0<1;1,0>:d    r2.28<0;1,0>:uw                     //  ALU pipe: int; $104
        macl (16|M16)            r42.0<1>:d    r38.0<1;1,0>:d    r2.14<0;1,0>:d   {Compacted}        //  ALU pipe: int; $105
        add (32|M0)              r43.0<1>:d    r6.0<1;1,0>:d     -r41.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $105
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r43.0<1;1,0>:ud   r2.14<0;1,0>:ud  {I@1}              //  ALU pipe: int; $106
(~f3.0) sel (32|M0)              r46.0<1>:d    r2.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $107
        add3 (32|M0)             r93.0<1>:d    r6.0<1;0>:d       -r41.0<1;0>:d     -r46.0<1>:d      {I@1} //  ALU pipe: int; $108
// B010: [inDivergent],  Preds:{B009, B008},  Succs:{B012}
_0_058:
        mov (16|M0)              r6.0<2>:ud    r93.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $110
        mov (16|M16)             r8.0<2>:ud    r94.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $110
        mov (16|M0)              r105.0<1>:q   r6.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $110
        mov (16|M16)             r107.0<1>:q   r8.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $110
        goto (32|M0)                         _0_054            _0_059                                // $111
// B011: [inDivergent],  Preds:{B006},  Succs:{B012}
_0_054:
        join (32|M0)                         _0_059                                                  // 
L1936:
        mov (16|M0)              r6.0<1>:d     r101.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $113
        mov (16|M16)             r7.0<1>:d     r103.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $114
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $115
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $115
        mov (16|M0)              r10.0<1>:df   r8.0<2;1,0>:ud                   {I@2}                //  ALU pipe: long; $115
        mov (16|M16)             r14.0<1>:df   r12.0<2;1,0>:ud                  {I@1}                //  ALU pipe: long; $115
        mul (16|M0)              r16.0<1>:df   r67.0<0;1,0>:df   r10.0<1;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $116
        mul (16|M16)             r18.0<1>:df   r67.0<0;1,0>:df   r14.0<1;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $116
        mov (16|M0)              r20.0<2>:ud   r16.0<1;1,0>:df                  {L@2}                //  ALU pipe: int; $117
        mov (16|M16)             r24.0<2>:ud   r18.0<1;1,0>:df                  {L@1}                //  ALU pipe: int; $117
        mov (16|M0)              r22.0<1>:ud   r20.0<2;1,0>:ud                  {Compacted,I@2}      //  ALU pipe: int; $117
        mov (16|M16)             r23.0<1>:ud   r24.0<2;1,0>:ud                  {Compacted,I@2}      //  ALU pipe: int; $117
(W)     mul (16|M0)              acc0.0<1>:d   r22.0<1;1,0>:d    r2.28<0;1,0>:uw  {I@2}              //  ALU pipe: int; $118
        macl (16|M0)             r27.0<1>:d    r22.0<1;1,0>:d    r2.14<0;1,0>:d   {Compacted}        //  ALU pipe: int; $118
(W)     mul (16|M16)             acc0.0<1>:d   r23.0<1;1,0>:d    r2.28<0;1,0>:uw  {I@3}              //  ALU pipe: int; $118
        macl (16|M16)            r28.0<1>:d    r23.0<1;1,0>:d    r2.14<0;1,0>:d   {Compacted}        //  ALU pipe: int; $119
        add (32|M0)              r29.0<1>:d    r6.0<1;1,0>:d     -r27.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $119
        mov (16|M0)              r31.0<2>:ud   r29.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $121
        mov (16|M16)             r36.0<2>:ud   r30.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $121
        mov (16|M0)              r41.0<1>:df   r101.0<2;1,0>:ud                                      //  ALU pipe: long; $122
        mov (16|M16)             r43.0<1>:df   r103.0<2;1,0>:ud                                      //  ALU pipe: long; $122
        mov (16|M0)              r34.0<1>:df   r31.0<2;1,0>:ud                  {I@2}                //  ALU pipe: long; $121
        mov (16|M16)             r38.0<1>:df   r36.0<2;1,0>:ud                  {I@1}                //  ALU pipe: long; $121
        mad (16|M0)              r45.0<1>:df   r41.0<1;0>:df     r34.0<1;0>:df     r67.2<0>:df      {Compacted,L@2} //  ALU pipe: long; $123
        mad (16|M16)             r47.0<1>:df   r43.0<1;0>:df     r38.0<1;0>:df     r67.2<0>:df      {Compacted,L@2} //  ALU pipe: long; $123
        mul (16|M0)              r49.0<1>:df   r67.0<0;1,0>:df   r45.0<1;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $124
        mul (16|M16)             r51.0<1>:df   r67.0<0;1,0>:df   r47.0<1;1,0>:df  {Compacted,L@2}    //  ALU pipe: long; $124
        mov (16|M0)              r53.0<1>:uq   r49.0<1;1,0>:df                  {L@2}                //  ALU pipe: int; $125
        mov (16|M16)             r55.0<1>:uq   r51.0<1;1,0>:df                  {L@1}                //  ALU pipe: int; $125
        mov (16|M0)              r59.0<1>:d    r53.1<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $128
        mov (16|M16)             r60.0<1>:d    r55.1<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $129
        mov (16|M0)              r61.0<1>:d    r53.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $130
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r59.0<1;1,0>:ud   0x1:uw              {I@2}           //  ALU pipe: int; $132
        mov (16|M16)             r62.0<1>:d    r55.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $130
(W)     mul (16|M0)              acc0.0<1>:d   r61.0<1;1,0>:d    r2.24<0;1,0>:uw  {I@3}              //  ALU pipe: int; $131
        macl (16|M0)             r63.0<1>:d    r61.0<1;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $131
(W)     mul (16|M16)             acc0.0<1>:d   r62.0<1;1,0>:d    r2.24<0;1,0>:uw  {I@3}              //  ALU pipe: int; $131
(~f3.0) sel (32|M0)              r65.0<1>:d    r2.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $133
        macl (16|M16)            r64.0<1>:d    r62.0<1;1,0>:d    r2.12<0;1,0>:d                      //  ALU pipe: int; $132
        mov (16|M0)              r57.0<1>:d    r53.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $126
        add (32|M0)              r68.0<1>:d    r65.0<1;1,0>:d    r63.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $134
        mov (16|M16)             r58.0<1>:d    r55.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $127
(W)     mul (16|M0)              acc0.0<1>:ud  r57.0<1;1,0>:ud   r2.20<0;1,0>:uw  {I@3}              //  ALU pipe: int; $144
        add3 (32|M0)             r70.0<1>:d    r6.0<1;0>:d       -r27.0<1;0>:d     -r68.0<1>:d      {I@3} //  ALU pipe: int; $135
        macl (16|M0)             r14.0<1>:ud   r57.0<1;1,0>:ud   r2.10<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $145
(W)     mul (16|M16)             acc0.0<1>:ud  r58.0<1;1,0>:ud   r2.20<0;1,0>:uw  {I@4}              //  ALU pipe: int; $145
        macl (16|M16)            r17.0<1>:ud   r58.0<1;1,0>:ud   r2.10<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $146
(W)     mul (16|M0)              acc0.0<1>:ud  r57.0<1;1,0>:ud   r2.20<0;1,0>:uw                     //  ALU pipe: int; $146
        mach (16|M0)             r20.0<1>:d    r57.0<1;1,0>:ud   r2.10<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r58.0<1;1,0>:ud   r2.20<0;1,0>:uw                     //  ALU pipe: int; $146
        mov (32|M0)              r80.0<1>:f    r91.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $137
        mov (32|M0)              r82.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $138
        mov (16|M0)              r72.0<2>:ud   r70.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $136
        mov (16|M16)             r76.0<2>:ud   r71.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $136
        mach (16|M16)            r21.0<1>:d    r58.0<1;1,0>:ud   r2.10<0;1,0>:ud                     //  ALU pipe: int; $148
        mov (32|M0)              r22.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $149
        mov (16|M0)              r6.0<2>:d     r80.0<1;1,0>:d                   {F@1}                //  ALU pipe: int; $139
        mov (16|M16)             r8.0<2>:d     r81.0<1;1,0>:d                                        //  ALU pipe: int; $140
        shl (16|M0)              r74.0<1>:q    r72.0<2;1,0>:d    32:w               {I@6}            //  ALU pipe: int; $136
        shl (16|M16)             r78.0<1>:q    r76.0<2;1,0>:d    32:w               {I@6}            //  ALU pipe: int; $136
        mov (16|M0)              r6.1<2>:d     r82.0<1;1,0>:d                                        //  ALU pipe: int; $141
        mov (16|M16)             r8.1<2>:d     r83.0<1;1,0>:d                                        //  ALU pipe: int; $142
        mov (16|M0)              r15.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $145
        mov (16|M16)             r18.0<2>:ud   r17.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $146
        add (16|M0)              r10.0<1>:q    r74.0<1;1,0>:q    r6.0<1;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $143
        add (16|M16)             r12.0<1>:q    r78.0<1;1,0>:q    r8.0<1;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $143
        add (16|M0)              r15.1<2>:d    r20.0<1;1,0>:d    r22.0<1;1,0>:d                      //  ALU pipe: int; $150
        add (16|M16)             r18.1<2>:d    r21.0<1;1,0>:d    r23.0<1;1,0>:d                      //  ALU pipe: int; $151
        add (16|M0)              r24.0<1>:q    r10.0<1;1,0>:q    -r15.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $152
        add (16|M16)             r26.0<1>:q    r12.0<1;1,0>:q    -r18.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $152
        mov (16|M0)              r28.0<1>:d    r24.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $153
        mov (16|M16)             r29.0<1>:d    r26.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $154
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r28.0<1;1,0>:ud   r2.10<0;1,0>:ud  {I@1}              //  ALU pipe: int; $157
        mov (16|M0)              r30.0<1>:d    r24.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $155
        mov (16|M16)             r31.0<1>:d    r26.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $156
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r30.0<1;1,0>:d    r2.11<0;1,0>:d   {I@1}              //  ALU pipe: int; $158
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r30.0<1;1,0>:ud   r2.11<0;1,0>:ud                     //  ALU pipe: int; $160
(~f3.0) sel (32|M0)              r32.0<1>:d    r2.10<0;1,0>:d    0:w                                 //  ALU pipe: int; $162
(~f3.0) sel (32|M0)              r34.0<1>:d    r2.11<0;1,0>:d    0:w                                 //  ALU pipe: int; $163
        mov (16|M0)              r36.0<2>:d    r32.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $166
        mov (16|M16)             r38.0<2>:d    r33.0<1;1,0>:d                                        //  ALU pipe: int; $167
        mov (16|M0)              r36.1<2>:d    r34.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $168
        mov (16|M16)             r38.1<2>:d    r35.0<1;1,0>:d                                        //  ALU pipe: int; $169
        add (16|M0)              r105.0<1>:q   r24.0<1;1,0>:q    -r36.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $170
        add (16|M16)             r107.0<1>:q   r26.0<1;1,0>:q    -r38.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $170
// B012: [inDivergent],  Preds:{B011, B010},  Succs:{B013, B020}
_0_059:
        join (32|M0)                         _0_051                                                  // 
L2968:
(W)     mov (1|M0)               f3.0<1>:ud    r67.13<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $172
(W&f3.0) jmpi                                _0_060                                                  //  ALU pipe: int; $172
// B013: [inDivergent],  Preds:{B012},  Succs:{B014, B019}
_0_061:
(W)     mov (1|M0)               f3.0<1>:ud    r67.12<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $174
(W&f3.0) jmpi                                _0_062                                                  //  ALU pipe: int; $174
// B014: [inDivergent],  Preds:{B013},  Succs:{B015, B018}
_0_063:
(W)     mov (1|M0)               f3.0<1>:ud    r67.11<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $176
(W&f3.0) jmpi                                _0_064                                                  //  ALU pipe: int; $176
// B015: [inDivergent],  Preds:{B014},  Succs:{B016, B017}
_0_065:
(W)     mov (1|M0)               f3.0<1>:ud    r67.10<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $178
(W&f3.0) jmpi                                _0_066                                                  //  ALU pipe: int; $178
// B016: [inDivergent],  Preds:{B015},  Succs:{B025}
_0_067:
        mov (32|M0)              r95.0<1>:ud   0x0:ud                              {Compacted,$5.dst} //  ALU pipe: int; $180
(W)     jmpi                                 _0_068                                                  // $181
// B017: [inDivergent],  Preds:{B015},  Succs:{B025}
_0_066:
        shl (16|M0)              r6.0<1>:q     r105.0<1;1,0>:q   3:w               {Compacted}       //  ALU pipe: int; $183
        shl (16|M16)             r8.0<1>:q     r107.0<1;1,0>:q   3:w               {Compacted}       //  ALU pipe: int; $183
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $184
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $184
        load.ugm.d64.a64 (32|M0)  r14:4         [r10:4]            {I@1,$9} // ex_desc:0x0; desc:0x8400780 // $186
        mov (16|M0)              r18.0<2>:f    r14.0<1;1,0>:q                   {$9.dst}             //  ALU pipe: float; $187
        mov (16|M16)             r20.0<2>:f    r16.0<1;1,0>:q                                        //  ALU pipe: float; $187
        sync.nop                             null                             {Compacted,F@2}        // $187
        mov (16|M0)              r95.0<1>:ud   r18.0<2;1,0>:ud                  {Compacted,$5.dst}   //  ALU pipe: int; $187
        mov (16|M16)             r96.0<1>:ud   r20.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $187
(W)     jmpi                                 _0_068                                                  // $188
// B018: [inDivergent],  Preds:{B014},  Succs:{B025}
_0_064:
        shl (16|M0)              r6.0<1>:q     r105.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $190
        shl (16|M16)             r8.0<1>:q     r107.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $190
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $191
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $191
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {I@1,$10} // ex_desc:0x0; desc:0x8200580 // $193
        sync.nop                             null                             {Compacted,$5.dst}     // $194
        mov (32|M0)              r95.0<1>:f    r14.0<1;1,0>:ud                  {$10.dst}            //  ALU pipe: float; $194
(W)     jmpi                                 _0_068                                                  // $195
// B019: [inDivergent],  Preds:{B013},  Succs:{B025}
_0_062:
        shl (16|M0)              r6.0<1>:q     r105.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $197
        shl (16|M16)             r8.0<1>:q     r107.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $197
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $198
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $198
        load.ugm.d32.a64 (32|M0)  r14:2         [r10:4]            {A@1,$11} // ex_desc:0x0; desc:0x8200580 // $200
        sync.nop                             null                             {Compacted,$5.dst}     // $201
        mov (32|M0)              r95.0<1>:f    r14.0<1;1,0>:d                   {$11.dst}            //  ALU pipe: float; $201
(W)     jmpi                                 _0_068                                                  // $202
// B020: [inDivergent],  Preds:{B012},  Succs:{B021, B024}
_0_060:
(W)     mov (1|M0)               f3.0<1>:ud    r2.13<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $204
(W&~f3.0) jmpi                               _0_069                                                  //  ALU pipe: int; $204
// B021: [inDivergent],  Preds:{B020},  Succs:{B022, B023}
_0_070:
(W&f2.0) jmpi                                _0_071                                                  //  ALU pipe: int; $206
// B022: [inDivergent],  Preds:{B021},  Succs:{B025}
_0_072:
        sync.nop                             null                             {Compacted,F@1}        // $208
        mov (32|M0)              r95.0<1>:ud   0x0:ud                              {Compacted,$5.dst} //  ALU pipe: int; $208
(W)     jmpi                                 _0_068                                                  // $209
// B023: [inDivergent],  Preds:{B021},  Succs:{B025}
_0_071:
        shl (16|M0)              r6.0<1>:q     r105.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $211
        shl (16|M16)             r8.0<1>:q     r107.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $211
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $212
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $212
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r10:4]            {I@1,$12} // ex_desc:0x0; desc:0x8200B80 // $214
        sync.nop                             null                             {Compacted,$5.dst}     // $215
        shl (32|M0)              r95.0<1>:d    r14.0<1;1,0>:ud   16:w               {$12.dst}        //  ALU pipe: int; $215
(W)     jmpi                                 _0_068                                                  // $216
// B024: [inDivergent],  Preds:{B020},  Succs:{B025}
_0_069:
        shl (16|M0)              r6.0<1>:q     r105.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $218
        shl (16|M16)             r8.0<1>:q     r107.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $218
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $219
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $219
        load.ugm.d32.a64 (32|M0)  r95:2         [r10:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $221
// B025: [inDivergent],  Preds:{B024, B023, B022, B019, B018, B017, B016},  Succs:{B026, B032}
_0_068:
(W)     mov (1|M0)               f3.0<1>:ud    r67.9<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $223
(W&f3.0) jmpi                                _0_073                                                  //  ALU pipe: int; $223
// B026: [inDivergent],  Preds:{B025},  Succs:{B027, B031}
_0_074:
(W)     mov (1|M0)               f3.0<1>:ud    r67.8<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $225
(W&f3.0) jmpi                                _0_075                                                  //  ALU pipe: int; $225
// B027: [inDivergent],  Preds:{B026},  Succs:{B028, B030}
_0_076:
(W)     mov (1|M0)               f3.0<1>:ud    r67.7<0;1,0>:ud                                       //  ALU pipe: int; $227
(W&f3.0) jmpi                                _0_077                                                  //  ALU pipe: int; $227
// B028: [inDivergent],  Preds:{B027},  Succs:{B029, B039}
_0_078:
(W)     mov (1|M0)               f3.0<1>:ud    r67.6<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $229
(~f3.0) goto (32|M0)                         _0_051            _0_051                                //  ALU pipe: int; $229
// B029: [inDivergent],  Preds:{B028},  Succs:{B039}
_0_079:
        mov (16|M0)              r14.0<2>:ud   r95.0<1;1,0>:ud                  {Compacted,$5.dst}   //  ALU pipe: int; $234
        mov (16|M16)             r18.0<2>:ud   r96.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $234
        shl (16|M0)              r6.0<1>:q     r101.0<1;1,0>:q   3:w               {Compacted}       //  ALU pipe: int; $231
        shl (16|M16)             r8.0<1>:q     r103.0<1;1,0>:q   3:w               {Compacted}       //  ALU pipe: int; $231
        mov (16|M0)              r16.0<1>:q    r14.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $234
        mov (16|M16)             r20.0<1>:q    r18.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $234
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $232
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $232
        mov (16|M0)              r22.0<1>:d    r16.0<2;1,0>:d                   {Compacted,I@4}      //  ALU pipe: int; $235
        mov (16|M0)              r24.0<1>:d    r16.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $237
        mov (16|M16)             r23.0<1>:d    r20.0<2;1,0>:d                   {Compacted,I@5}      //  ALU pipe: int; $236
        mov (16|M16)             r25.0<1>:d    r20.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $238
        store.ugm.d32x2.a64 (32|M0)  [r10:4]    r22:4              {I@1,$6} // ex_desc:0x0; desc:0x8001584 // $239
        goto (32|M0)                         _0_051            _0_051                                // $240
// B030: [inDivergent],  Preds:{B027},  Succs:{B039}
_0_077:
        shl (16|M0)              r8.0<1>:q     r101.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $243
        sync.nop                             null                             {Compacted,$6.src}     // $243
        shl (16|M16)             r10.0<1>:q    r103.0<1;1,0>:q   2:w               {Compacted,$5.src} //  ALU pipe: int; $243
        mov (32|M0)              r6.0<1>:ud    r95.0<1;1,0>:f                   {$5.dst}             //  ALU pipe: int; $242
        add (16|M0)              r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $244
        add (16|M16)             r14.0<1>:q    r10.0<1;1,0>:q    r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $244
        store.ugm.d32.a64 (32|M0)  [r12:4]      r6:2               {I@1,$13} // ex_desc:0x0; desc:0x8000584 // $246
        goto (32|M0)                         _0_051            _0_051                                // $247
// B031: [inDivergent],  Preds:{B026},  Succs:{B039}
_0_075:
        shl (16|M0)              r8.0<1>:q     r101.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $250
        shl (16|M16)             r10.0<1>:q    r103.0<1;1,0>:q   2:w               {Compacted,$5.src} //  ALU pipe: int; $250
        sync.nop                             null                             {Compacted,$13.src}    // $249
        mov (32|M0)              r6.0<1>:d     r95.0<1;1,0>:f                   {$5.dst}             //  ALU pipe: int; $249
        add (16|M0)              r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $251
        add (16|M16)             r14.0<1>:q    r10.0<1;1,0>:q    r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $251
        store.ugm.d32.a64 (32|M0)  [r12:4]      r6:2               {I@1,$14} // ex_desc:0x0; desc:0x8000584 // $253
        goto (32|M0)                         _0_051            _0_051                                // $254
// B032: [inDivergent],  Preds:{B025},  Succs:{B033, B038}
_0_073:
(W&~f1.0) jmpi                               _0_080                                                  //  ALU pipe: int; $256
// B033: [inDivergent],  Preds:{B032},  Succs:{B034, B039}
_0_081:
(~f0.0) goto (32|M0)                         _0_051            _0_051                                //  ALU pipe: int; $258
// B034: [inDivergent],  Preds:{B033},  Succs:{B035, B036}
_0_082:
        sync.nop                             null                             {Compacted,$14.src}    // $260
        and (32|M0)              r6.0<1>:d     r95.0<1;1,0>:d    2147483647:d               {$5.dst} //  ALU pipe: int; $260
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r6.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $261
(f3.0)  goto (32|M0)                         _0_083            _0_083                                //  ALU pipe: int; $262
// B035: [inDivergent],  Preds:{B034},  Succs:{B037}
_0_084:
        shr (32|M0)              r6.0<1>:ud    r95.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $264
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $265
        add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r95.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $266
        shr (32|M0)              r12.0<1>:ud   r10.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $267
        mov (32|M0)              r89.0<1>:w    r12.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $268
        goto (32|M0)                         _0_083            _0_085                                // $269
// B036: [inDivergent],  Preds:{B034},  Succs:{B037}
_0_083:
        join (32|M0)                         _0_085                                                  // 
L4208:
        shr (32|M0)              r6.0<1>:ud    r95.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $271
        or (32|M0)               r89.0<1>:w    r6.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $273
// B037: [inDivergent],  Preds:{B036, B035},  Succs:{B039}
_0_085:
        join (32|M0)                         _0_051                                                  // 
L4256:
        shl (16|M0)              r6.0<1>:q     r101.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $275
        shl (16|M16)             r8.0<1>:q     r103.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $275
        mov (32|M0)              r14.0<1>:ud   r89.0<1;1,0>:uw                  {I@4}                //  ALU pipe: int; $278
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $276
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $276
        store.ugm.d16u32.a64 (32|M0)  [r10:4]   r14:2              {I@1,$7} // ex_desc:0x0; desc:0x8000B84 // $279
        goto (32|M0)                         _0_051            _0_051                                // $280
// B038: [inDivergent],  Preds:{B032},  Succs:{B039}
_0_080:
        shl (16|M0)              r6.0<1>:q     r101.0<1;1,0>:q   2:w               {Compacted,$14.src} //  ALU pipe: int; $282
        shl (16|M16)             r8.0<1>:q     r103.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $282
        sync.nop                             null                             {Compacted,$7.src}     // $283
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,@2,$5.src} //  ALU pipe: int; $283
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r4.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $283
        sync.nop                             null                             {Compacted,$5.dst}     // $285
        store.ugm.d32.a64 (32|M0)  [r10:4]      r95:2              {I@1,$4} // ex_desc:0x0; desc:0x8000584 // $285
// B039: [inDivergent],  Preds:{B038, B037, B033, B031, B030, B029, B028, B005, B004},  Succs:{B040, B041}
_0_051:
        join (32|M0)                         _0_048                                                  // 
L4416:
        sync.nop                             null                             {Compacted,$14.src}    // $287
        add (16|M0)              r6.0<1>:q     r101.0<1;1,0>:q   r67.1<0;1,0>:q   {Compacted,$13.src} //  ALU pipe: int; $287
        add (16|M16)             r8.0<1>:q     r103.0<1;1,0>:q   r67.1<0;1,0>:q   {Compacted}        //  ALU pipe: int; $287
        mov (16|M0)              r97.0<1>:d    r6.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $288
        mov (16|M16)             r98.0<1>:d    r8.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $289
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r97.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $292
        mov (16|M0)              r99.0<1>:d    r6.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $290
        mov (16|M16)             r100.0<1>:d   r8.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $291
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r99.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $293
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r99.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $295
(~f3.0) goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $297
// B040: [inDivergent],  Preds:{B039},  Succs:{B004}
_0_086:
(f3.0)  sel (32|M0)              r6.0<1>:d     r97.0<1;1,0>:d    r84.0<1;1,0>:d                      //  ALU pipe: int; $299
(f3.0)  sel (32|M0)              r8.0<1>:d     r99.0<1;1,0>:d    r86.0<1;1,0>:d                      //  ALU pipe: int; $300
        mov (16|M0)              r101.0<2>:d   r6.0<1;1,0>:d                    {I@2}                //  ALU pipe: int; $303
        mov (16|M16)             r103.0<2>:d   r7.0<1;1,0>:d                                         //  ALU pipe: int; $304
        mov (16|M0)              r101.1<2>:d   r8.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $305
        mov (16|M16)             r103.1<2>:d   r9.0<1;1,0>:d                                         //  ALU pipe: int; $306
(W)     jmpi                                 _0_050                                                  // $307
// B041: Preds:{B039, B002},  Succs:{}
_0_048:
        join (32|M0)                         L4664                                                   // 
L4664:
(W)     mov (16|M0)              r127.0<1>:f   r40.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $309
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$15} // wr:1+0, rd:0; end of thread // $309
L4688:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x11:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 318
//.accSubDef: 3
//.accSubUse: 3
//.accSubCandidateDef: 3
//.accSubCandidateUse: 3
//
//
//.singlePipeAtOneDistNum: 50
//.allAtOneDistNum: 11
//.syncInstCount: 12
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 20
//.AfterReadTokenDepCount: 15
