//.kernel _ZTSN4sycl3_V16detail19__pf_kernel_wrapperIN9p42extras6NgNameILi2ELi1ELi0ELi0ELi0EEEEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 11 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 11 -GRFBumpUpNumber 2 "
//.instCount 449
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 2
//.spill flag load 2

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r88.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.12)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r88.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r88.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r6.4)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r6.0)
//.declare V0043 (53)  rf=r size=8 type=uq align=4 words (r6.1)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0070 (80)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0071 (81)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0072 (82)  rf=r size=8 type=q align=4 words (r5.7)
//.declare V0074 (84)  rf=r size=8 type=d align=2 words (r64.2)
//.declare V0075 (85)  rf=r size=8 type=d alias=V0044+0 align=32 words (r2.6)
//.declare V0076 (86)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0077 (87)  rf=r size=12 type=ud alias=V0038+0 align=32 words (r2.3)
//.declare V0078 (88)  rf=r size=32 type=ud alias=V0035+0 align=32 words (r88.0)
//.declare V0079 (89)  rf=r size=8 type=ud alias=V0076+0 align=4 words (r2.8)
//.declare V0080 (90)  rf=r size=8 type=d alias=V0076+0 align=4 words (r2.8)
//.declare V0081 (91)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0084 (94)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0087 (97)  rf=r size=12 type=ud alias=V0036+0 align=32 words (r2.0)
//.declare V0091 (101)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0092 (102)  rf=r size=128 type=d align=32 words (r48.0)
//.declare P01 (103)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0093 (104)  rf=r size=128 type=ud alias=V0091+0 align=32 words (r52.0)
//.declare V0094 (105)  rf=r size=8 type=ud alias=V0074+0 align=2 words (r64.2)
//.declare P02 (106)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P03 (107)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0095 (108)  rf=r size=128 type=ud alias=V0092+0 align=32 words (r48.0)
//.declare V0096 (109)  rf=r size=64 type=w align=32 words (r4.0)
//.declare V0098 (111)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare V0100 (113)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare V0102 (115)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare V0103 (116)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare V0105 (118)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0106 (119)  rf=r size=8 type=uq alias=V0068+0 align=32 words (r5.3)
//.declare V0107 (120)  rf=r size=8 type=uq alias=V0070+0 align=32 words (r5.5)
//.declare V0108 (121)  rf=r size=8 type=uq alias=V0071+0 align=32 words (r5.6)
//.declare V0109 (122)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0110 (123)  rf=r size=4 type=d align=2 words (r5.1)
//.declare P04 (124)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0111 (125)  rf=r size=2 type=w align=1 words (r6.2)
//.declare V0112 (126)  rf=r size=2 type=b align=1 words (r7.0)
//.declare V0113 (127)  rf=r size=4 type=d align=2 words (r8.0)
//.declare V0114 (128)  rf=r size=2 type=ub alias=V0112+0 align=1 words (r7.0)
//.declare V0115 (129)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0116 (130)  rf=r size=4 type=d align=2 words (r64.5)
//.declare V0117 (131)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0118 (132)  rf=r size=4 type=d align=32 words (r65.0)
//.declare V0119 (133)  rf=r size=4 type=d align=2 words (r64.4)
//.declare V0120 (134)  rf=r size=4 type=ud alias=V0118+0 align=2 words (r65.0)
//.declare V0121 (135)  rf=r size=4 type=ud alias=V0109+0 align=2 words (r6.0)
//.declare V0122 (136)  rf=r size=4 type=ud alias=V0116+0 align=2 words (r64.5)
//.declare V0123 (137)  rf=r size=4 type=d align=32 words (r9.0)
//.declare V0125 (139)  rf=r size=4 type=d align=32 words (r10.0)
//.declare V0126 (140)  rf=r size=8 type=uq align=32 words (r68.0)
//.declare V0127 (141)  rf=r size=8 type=uq align=32 words (r64.0)
//.declare V0128 (142)  rf=r size=8 type=uq align=32 words (r66.0)
//.declare V0129 (143)  rf=r size=4 type=d align=2 words (r66.2)
//.declare P05 (144)  rf=f1  size=2 type=uw align=1 words (f0.0)
//.declare V0130 (145)  rf=r size=2 type=w align=1 words (r7.0)
//.declare V0131 (146)  rf=r size=2 type=b align=1 words (r3.16)
//.declare V0132 (147)  rf=r size=4 type=d align=2 words (r6.0)
//.declare V0133 (148)  rf=r size=2 type=ub alias=V0131+0 align=1 words (r3.16)
//.declare V0134 (149)  rf=r size=4 type=d align=2 words (r8.0)
//.declare V0135 (150)  rf=r size=4 type=d align=2 words (r64.7)
//.declare P06 (151)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P07 (152)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0136 (153)  rf=r size=4 type=f align=2 words (r64.15)
//.declare P08 (154)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0137 (155)  rf=r size=4 type=d align=2 words (r5.1)
//.declare V0138 (156)  rf=r size=4 type=d align=2 words (r9.0)
//.declare V0139 (157)  rf=r size=4 type=f align=2 words (r64.6)
//.declare V0140 (158)  rf=r size=4 type=ud alias=V0138+0 align=2 words (r9.0)
//.declare V0142 (160)  rf=r size=64 type=uw alias=V0096+0 align=32 words (r4.0)
//.declare V0143 (161)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0144 (162)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0145 (163)  rf=r size=8 type=q alias=V0043+0 align=32 words (r6.1)
//.declare V0147 (165)  rf=r size=128 type=ud alias=V0144+0 align=32 words (r12.0)
//.declare V0148 (166)  rf=r size=256 type=q align=32 words (r44.0)
//.declare V0149 (167)  rf=r size=256 type=uq alias=V0148+0 align=32 words (r44.0)
//.declare V0150 (168)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0151 (169)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0153 (171)  rf=r size=128 type=ud alias=V0151+0 align=32 words (r20.0)
//.declare V0154 (172)  rf=r size=256 type=q align=32 words (r32.0)
//.declare V0155 (173)  rf=r size=256 type=uq alias=V0154+0 align=32 words (r32.0)
//.declare P09 (174)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0156 (175)  rf=r size=4 type=ud alias=V0115+0 align=2 words (r3.0)
//.declare V0157 (176)  rf=r size=4 type=d align=2 words (r64.12)
//.declare V0158 (177)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0159 (178)  rf=r size=4 type=d align=2 words (r64.11)
//.declare P10 (179)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0160 (180)  rf=r size=4 type=d align=2 words (r64.10)
//.declare V0161 (181)  rf=r size=8 type=q align=4 words (r64.4)
//.declare V0162 (182)  rf=r size=12 type=ud alias=V0037+0 align=32 words (r6.4)
//.declare V0164 (184)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0165 (185)  rf=r size=128 type=d align=32 words (r70.0)
//.declare P11 (186)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0166 (187)  rf=r size=128 type=ud alias=V0164+0 align=32 words (r72.0)
//.declare P12 (188)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P13 (189)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0167 (190)  rf=r size=128 type=ud alias=V0165+0 align=32 words (r70.0)
//.declare V0168 (191)  rf=r size=4 type=ud alias=V0119+0 align=2 words (r64.4)
//.declare V0169 (192)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P14 (193)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0171 (195)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0172 (196)  rf=r size=256 type=ud alias=V0171+0 align=32 words (r7.0)
//.declare V0173 (197)  rf=r size=8 type=ud alias=V0127+0 align=32 words (r64.0)
//.declare V0174 (198)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0175 (199)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare P15 (201)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0177 (202)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P16 (203)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P17 (204)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0178 (205)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0179 (206)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0180 (207)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0181 (208)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0182 (209)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0183 (210)  rf=r size=4 type=f align=2 words (r2.8)
//.declare V0184 (211)  rf=r size=4 type=ud alias=V0159+0 align=2 words (r64.11)
//.declare V0185 (212)  rf=r size=4 type=d align=2 words (r2.9)
//.declare V0186 (213)  rf=r size=4 type=ud alias=V0185+0 align=2 words (r2.9)
//.declare V0187 (214)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0188 (215)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0189 (216)  rf=r size=128 type=ud alias=V0182+0 align=32 words (r12.0)
//.declare V0190 (217)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0191 (218)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0192 (219)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0193 (220)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0194 (221)  rf=r size=128 type=ud alias=V0193+0 align=32 words (r18.0)
//.declare V0195 (222)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0196 (223)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0197 (224)  rf=r size=128 type=ud alias=V0196+0 align=32 words (r10.0)
//.declare V0198 (225)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0199 (226)  rf=r size=4 type=ud alias=V0187+0 align=2 words (r3.0)
//.declare V0200 (227)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0201 (228)  rf=r size=128 type=ud alias=V0195+0 align=32 words (r20.0)
//.declare V0202 (229)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0208 (235)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0209 (236)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0210 (237)  rf=r size=128 type=ud alias=V0209+0 align=32 words (r28.0)
//.declare V0211 (238)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0212 (239)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0213 (240)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0214 (241)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0215 (242)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0216 (243)  rf=r size=128 type=ud alias=V0214+0 align=32 words (r14.0)
//.declare V0217 (244)  rf=r size=128 type=ud alias=V0215+0 align=32 words (r20.0)
//.declare  (245)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0218 (246)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0219 (247)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0220 (248)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0221 (249)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0222 (250)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0226 (254)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0228 (256)  rf=r size=4 type=ud alias=V0226+0 align=2 words (r3.0)
//.declare V0229 (257)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0232 (260)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0233 (261)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0234 (262)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0235 (263)  rf=r size=256 type=uq alias=V0234+0 align=32 words (r14.0)
//.declare P18 (264)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0236 (265)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0237 (266)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0238 (267)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0240 (269)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0241 (270)  rf=r size=256 type=q align=32 words (r76.0)
//.declare V0242 (271)  rf=r size=256 type=uq alias=V0241+0 align=32 words (r76.0)
//.declare V0243 (272)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0244 (273)  rf=r size=4 type=d align=2 words (r3.1)
//.declare P19 (274)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0245 (275)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0247 (277)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0248 (278)  rf=r size=256 type=q align=32 words (r7.0)
//.declare V0249 (279)  rf=r size=256 type=uq alias=V0248+0 align=32 words (r7.0)
//.declare V0250 (280)  rf=r size=128 type=f align=32 words (r8.0)
//.declare P20 (281)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P21 (282)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0251 (283)  rf=r size=128 type=f align=32 words (r124.0)
//.declare  (285)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (286)  rf=r size=128 type=f align=32 words (r122.0)
//.declare  (287)  rf=r size=128 type=f align=32 words (r120.0)
//.declare  (288)  rf=r size=128 type=f align=32 words (r118.0)
//.declare  (289)  rf=r size=128 type=f align=32 words (r116.0)
//.declare  (290)  rf=r size=128 type=f align=32 words (r114.0)
//.declare  (291)  rf=r size=128 type=f align=32 words (r112.0)
//.declare  (292)  rf=r size=128 type=f align=32 words (r110.0)
//.declare  (293)  rf=r size=64 type=f align=32 words (r91.0)
//.declare  (294)  rf=r size=64 type=f align=32 words (r90.0)
//.declare V0253 (297)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0254 (298)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (299)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (300)  rf=r size=128 type=f align=32 words (r24.0)
//.declare  (301)  rf=r size=128 type=f align=32 words (r12.0)
//.declare  (302)  rf=r size=128 type=f align=32 words (r10.0)
//.declare  (303)  rf=r size=128 type=f align=32 words (r8.0)
//.declare  (304)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (305)  rf=r size=64 type=f align=32 words (r89.0)
//.declare V0255 (308)  rf=r size=128 type=d alias=V0254+0 align=32 words (r8.0)
//.declare V0256 (309)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0257 (310)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0258 (311)  rf=r size=128 type=d align=32 words (r36.0)
//.declare P22 (312)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0259 (313)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0260 (314)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0261 (315)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0262 (316)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0263 (317)  rf=r size=4 type=f align=2 words (r2.8)
//.declare V0264 (318)  rf=r size=4 type=ud alias=V0160+0 align=2 words (r64.10)
//.declare V0265 (319)  rf=r size=4 type=d align=2 words (r2.9)
//.declare V0266 (320)  rf=r size=4 type=ud alias=V0265+0 align=2 words (r2.9)
//.declare V0267 (321)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0268 (322)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0269 (323)  rf=r size=128 type=ud alias=V0262+0 align=32 words (r12.0)
//.declare V0270 (324)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0271 (325)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0272 (326)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0273 (327)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0274 (328)  rf=r size=128 type=ud alias=V0273+0 align=32 words (r18.0)
//.declare V0275 (329)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0276 (330)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0277 (331)  rf=r size=128 type=ud alias=V0276+0 align=32 words (r10.0)
//.declare V0278 (332)  rf=r size=4 type=f align=2 words (r6.0)
//.declare V0279 (333)  rf=r size=4 type=ud alias=V0267+0 align=2 words (r3.0)
//.declare V0280 (334)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0281 (335)  rf=r size=128 type=ud alias=V0275+0 align=32 words (r20.0)
//.declare V0282 (336)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0288 (342)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0289 (343)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0290 (344)  rf=r size=128 type=ud alias=V0289+0 align=32 words (r28.0)
//.declare V0291 (345)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0292 (346)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0293 (347)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P23 (348)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0294 (349)  rf=r size=128 type=ud alias=V0293+0 align=32 words (r14.0)
//.declare V0295 (350)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0296 (351)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0297 (352)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0298 (353)  rf=r size=128 type=f alias=V0256+0 align=32 words (r38.0)
//.declare  (354)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (355)  rf=r size=128 type=f align=32 words (r104.0)
//.declare  (356)  rf=r size=128 type=f align=32 words (r22.0)
//.declare  (357)  rf=r size=128 type=f align=32 words (r102.0)
//.declare  (358)  rf=r size=128 type=f align=32 words (r100.0)
//.declare  (359)  rf=r size=128 type=f align=32 words (r98.0)
//.declare  (360)  rf=r size=128 type=f align=32 words (r96.0)
//.declare  (361)  rf=r size=128 type=f align=32 words (r94.0)
//.declare  (362)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0299 (365)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0300 (366)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0301 (367)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0306 (372)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0308 (374)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare V0309 (375)  rf=r size=128 type=w alias=V0308+0 align=32 words (r18.0)
//.declare V0311 (377)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0312 (378)  rf=r size=128 type=f align=32 words (r74.0)
//.declare V0313 (379)  rf=r size=128 type=f alias=V0311+0 align=32 words (r20.0)
//.declare V0314 (380)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0319 (385)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0320 (386)  rf=r size=128 type=f align=32 words (r86.0)
//.declare V0324 (390)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0326 (392)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0327 (393)  rf=r size=128 type=w alias=V0326+0 align=32 words (r16.0)
//.declare V0329 (395)  rf=r size=128 type=d alias=V0320+0 align=32 words (r86.0)
//.declare V0331 (397)  rf=r size=128 type=f align=32 words (r92.0)
//.declare V0332 (398)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0333 (399)  rf=r size=128 type=d alias=V0331+0 align=32 words (r92.0)
//.declare P24 (400)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0334 (401)  rf=r size=128 type=ud alias=V0332+0 align=32 words (r8.0)
//.declare V0335 (402)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0336 (403)  rf=r size=128 type=ud alias=V0331+0 align=32 words (r92.0)
//.declare V0337 (404)  rf=r size=128 type=ud alias=V0335+0 align=32 words (r8.0)
//.declare V0338 (405)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0339 (406)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0340 (407)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0341 (408)  rf=r size=128 type=ud alias=V0339+0 align=32 words (r12.0)
//.declare V0342 (409)  rf=r size=128 type=ud alias=V0340+0 align=32 words (r14.0)
//.declare V0343 (410)  rf=r size=64 type=w align=32 words (r26.0)
//.declare V0344 (411)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0345 (412)  rf=r size=128 type=ud alias=V0344+0 align=32 words (r8.0)
//.declare V0349 (416)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0350 (417)  rf=r size=64 type=uw alias=V0343+0 align=32 words (r26.0)
//.declare V0351 (418)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P25 (419)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P26 (420)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P27 (421)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0353 (423)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0354 (424)  rf=r size=256 type=ud alias=V0353+0 align=32 words (r7.0)
//.declare V0355 (425)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0359 (429)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0360 (430)  rf=r size=128 type=d align=32 words (r16.0)
//.declare P28 (431)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0361 (432)  rf=r size=128 type=ud alias=V0359+0 align=32 words (r18.0)
//.declare P29 (433)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P30 (434)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0362 (435)  rf=r size=128 type=ud alias=V0360+0 align=32 words (r16.0)
//.declare  (439)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (440)  rf=r size=128 type=w alias=V0344+0 align=32 words (r8.0)
//.declare  (441)  rf=r size=4 type=ud align=32 words (r3.0)
//.declare  (442)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (443)  rf=r size=128 type=uw align=32 words (r11.0)
//.declare  (444)  rf=r size=4 type=d align=2 words (r3.0)
//.declare  (445)  rf=r size=2 type=w align=1 words (r5.4)
//.declare  (446)  rf=r size=2 type=w align=1 words (r2.16)
//.declare  (447)  rf=r size=2 type=w align=1 words (r3.8)
//.declare  (448)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (449)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (450)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare  (451)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (454)  rf=r size=4 type=f align=2 words (r3.4)
//.declare  (455)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (456)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (457)  rf=r size=4 type=f align=2 words (r3.4)
//.declare  (458)  rf=r size=4 type=d align=2 words (r4.0)
//.declare  (460)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (461)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (462)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (463)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (464)  rf=r size=128 type=w alias=V0340+0 align=32 words (r14.0)
//.declare  (467)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (468)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (469)  rf=r size=128 type=q align=32 words (r56.0)
//.declare  (470)  rf=r size=128 type=q align=32 words (r54.0)
//.declare  (481)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (482)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (483)  rf=r size=128 type=q align=32 words (r29.0)
//.declare  (484)  rf=r size=128 type=q align=32 words (r27.0)
//.declare  (489)  rf=r size=128 type=q align=32 words (r84.0)
//.declare  (490)  rf=r size=128 type=q align=32 words (r82.0)
//.declare  (493)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (494)  rf=r size=128 type=q align=32 words (r126.0)
//.declare  (495)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (496)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (499)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (500)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (505)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (506)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (509)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (510)  rf=r size=128 type=d align=32 words (r10.0)
//.declare  (511)  rf=r size=128 type=d alias=+0 align=32 words (r56.0)
//.declare  (512)  rf=r size=128 type=d alias=+0 align=32 words (r54.0)
//.declare  (513)  rf=r size=128 type=d alias=+0 align=32 words (r7.0)
//.declare  (514)  rf=r size=128 type=d alias=+0 align=32 words (r9.0)
//.declare  (515)  rf=r size=4 type=uw align=2 words (r64.26)
//.declare  (516)  rf=r size=4 type=uw align=2 words (r64.28)
//.declare  (517)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (518)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (519)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (520)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (521)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (522)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (523)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (524)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (525)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (526)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (527)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (528)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (529)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (530)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (531)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (532)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (533)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (534)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (535)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (536)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (537)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (538)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (539)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (540)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (541)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (542)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (543)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (544)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (545)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (546)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (547)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (548)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (549)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (550)  rf=r size=64 type=d align=32 words (r31.0)
//.declare r0 (551)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (552)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (553)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (554)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (555)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (556)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (557)  rf=r size=64 type=ud align=32 words (r5.0)
//.declare  (558)  rf=r size=32 type=ud align=2 words (r6.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0045    | :d       |    0x4 | r3       | cti+0x20         |
// | V0046    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0047    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0048    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0049    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0050    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0051    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0052    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0053    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0054    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0055    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0056    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0057    | :q       |    0x8 | r4       | cti+0x60         |
// | V0058    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0059    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0060    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0061    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0062    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0063    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0064    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0065    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0066    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0067    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0068    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0069    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0070    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0071    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// | V0072    | :q       |    0x8 | r5+0x38  | cti+0xD8         |
// | V0042    | :uq      |    0x8 | r6       | cti+0xE0         |
// | V0043    | :uq      |    0x8 | r6+0x8   | cti+0xE8         |
// | V0037    | :d x 3   |    0xC | r6+0x10  | cti+0xF0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xE0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r6:1  bti[255][r127:1+0xC0]  {$3} // ex_desc:0xFF0C0000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B053}
// _main:
(W)     mov (16|M0)              r88.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r89.0<1>:f    0x3F000000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r90.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r91.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r88.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r3.0<1>:ud    r2.3<0;1,0>:ud    r88.1<0;1,0>:ud  {Compacted,$1.dst} //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r88.2<0;1,0>:uw                     //  ALU pipe: int; $4
(W)     mach (1|M0)              r4.0<1>:d     r2.3<0;1,0>:ud    r88.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r11.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.8<2>:ud    r3.0<0;1,0>:ud                   {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.9<2>:d     r4.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r64.2<1>:d    r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r9.0<1>:q     r2.4<0;1,0>:q     r7.0<4;1,0>:uw   {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r13.0<1>:q    r2.4<0;1,0>:q     r11.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r56.0<1>:q    r9.0<1;1,0>:q     r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r54.0<1>:q    r13.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r52.0<1>:d    r56.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r53.0<1>:d    r54.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r52.0<1;1,0>:ud   r64.2<0;1,0>:ud  {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r48.0<1>:d    r56.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r49.0<1>:d    r54.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r48.0<1;1,0>:d    r64.3<0;1,0>:d   {I@1}              //  ALU pipe: int; $18 R{} IR{}{E:0,E:0,},  R{r64,} IR{} {BC=1}
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r48.0<1;1,0>:ud   r64.3<0;1,0>:ud                     //  ALU pipe: int; $20
(~f0.0) goto (32|M0)                         _0_056            _0_056                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_057:
(W)     mov (8|M0)               r4.0<1>:w     0x76543210:v                                          //  ALU pipe: int; $24
(W)     and (1|M0)               r2.8<1>:ud    msg0.0<0;1,0>:ud  0xFF:uw                             //  ALU pipe: int; $27
(W)     add (8|M0)               r4.8<1>:w     r4.0<1;1,0>:w     8:w               {I@2}             //  ALU pipe: int; $25
(W)     add (16|M0)              r4.16<1>:w    r4.0<1;1,0>:w     16:w               {I@1}            //  ALU pipe: int; $26
(W)     and (1|M0)               r2.9<1>:ud    sr0.0<0;1,0>:ud   0x7F:uw              {A@1}          //  ALU pipe: int; $28
(W)     cmp (1|M0)    (lt)f1.0   null<1>:d     r3.2<0;1,0>:d     -3:w               {A@1}            //  ALU pipe: int; $38
(W)     mov (1|M0)               r5.4<1>:hf    0x6:hf                              {$2.dst}          //  ALU pipe: float; $39
(W)     and (1|M0)               r2.10<1>:ud   r2.9<0;1,0>:ud    7:w               {I@2}             //  ALU pipe: int; $30
(W)     asr (1|M0)               r2.11<1>:ud   r2.9<0;1,0>:ud    1:w                                 //  ALU pipe: int; $31
(W)     mov (1|M0)               r3.0<1>:d     -8:w                               {Compacted}        //  ALU pipe: int; $32
        sync.nop                             null                             {Compacted,F@1}        // $39
(W&f1.0) sel (1|M0)              r6.2<1>:w     r5.4<0;1,0>:w     3:w               {$3.dst}          //  ALU pipe: int; $39
(W)     shl (1|M0)               r2.8<1>:ud    r2.8<0;1,0>:ud    0x6:uw                              //  ALU pipe: int; $29
(W)     bfn.(s0&s1|s2) (1|M0)    r2.9<1>:ud    r2.11<0;0>:ud     r3.0<0;0>:ud      r2.10<0>:ud      {I@3} //  ALU pipe: int; $32
(W)     mov (1|M0)               r7.0<2>:b     r6.2<0;1,0>:w                    {I@3}                //  ALU pipe: int; $40
(W)     or (1|M0)                r2.8<1>:ud    r2.8<0;1,0>:ud    r2.9<0;1,0>:ud   {I@2}              //  ALU pipe: int; $33
(W)     mov (1|M0)               r8.0<1>:d     r7.0<0;1,0>:ub                   {I@2}                //  ALU pipe: int; $41
(W)     mul (1|M0)               acc0.0<1>:d   r2.8<0;1,0>:d     0x80:uw              {I@2}          //  ALU pipe: int; $35
(W)     add (1|M0)               r3.0<1>:d     r8.0<0;1,0>:d     r3.2<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $42
(W)     macl (1|M0)              r5.0<1>:d     r2.8<0;1,0>:d     65664:d                             //  ALU pipe: int; $36
(W)     mul (1|M0)               acc0.0<1>:d   r3.3<0;1,0>:d     r3.2<0;1,0>:uw                      //  ALU pipe: int; $36
(W)     asr (1|M0)               r64.5<1>:d    r3.0<0;1,0>:d     2:w               {I@3}             //  ALU pipe: int; $43
(W)     macl (1|M0)              r6.0<1>:d     r3.3<0;1,0>:d     r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $37
(W)     cmp (1|M0)    (lt)f0.0   null<1>:d     r3.2<0;1,0>:d     -31:w               {Compacted}     //  ALU pipe: int; $56
(W)     asr (1|M0)               r3.4<1>:d     r64.5<0;1,0>:d    31:w               {I@3}            //  ALU pipe: int; $44
(W)     mul (1|M0)               acc0.0<1>:ud  r6.0<0;1,0>:ud    r64.10<0;1,0>:uw {I@3}              //  ALU pipe: int; $45
(W)     macl (1|M0)              r65.0<1>:ud   r6.0<0;1,0>:ud    r64.5<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $46
(W)     mul (1|M0)               acc0.0<1>:ud  r6.0<0;1,0>:ud    r64.10<0;1,0>:uw                    //  ALU pipe: int; $46
(W)     mov (1|M0)               r2.16<1>:hf   0x3E:hf                                               //  ALU pipe: float; $57
(W)     asr (1|M0)               r5.1<1>:d     r6.0<0;1,0>:d     31:w               {Compacted}      //  ALU pipe: int; $37
(W)     mach (1|M0)              r9.0<1>:d     r6.0<0;1,0>:ud    r64.5<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r6.0<0;1,0>:ud    r3.8<0;1,0>:uw   {I@6}              //  ALU pipe: int; $47
(W)     macl (1|M0)              r10.0<1>:d    r6.0<0;1,0>:ud    r3.4<0;1,0>:d                       //  ALU pipe: int; $48
(W&f0.0) sel (1|M0)              r7.0<1>:w     r2.16<0;1,0>:w    31:w               {F@1}            //  ALU pipe: int; $57
(W)     mul (1|M0)               acc0.0<1>:d   r64.5<0;1,0>:ud   r5.2<0;1,0>:uw   {I@5}              //  ALU pipe: int; $49
(W)     add (1|M0)               r9.0<1>:d     r9.0<0;1,0>:d     r10.0<0;1,0>:d   {Compacted,I@3}    //  ALU pipe: int; $48
(W)     macl (1|M0)              r10.0<1>:d    r64.5<0;1,0>:ud   r5.1<0;1,0>:d                       //  ALU pipe: int; $51
(W)     mov (1|M0)               r3.16<2>:b    r7.0<0;1,0>:w                    {I@4}                //  ALU pipe: int; $58
        shl (32|M0)              r18.0<1>:d    r4.0<1;1,0>:uw    11:w                                //  ALU pipe: int; $74
(W)     add (1|M0)               r64.4<1>:d    r9.0<0;1,0>:d     r10.0<0;1,0>:d   {Compacted,I@3}    //  ALU pipe: int; $51
        shl (32|M0)              r10.0<1>:d    r4.0<1;1,0>:uw    2:w                                 //  ALU pipe: int; $70
(W)     mov (1|M0)               r6.0<1>:d     r3.16<0;1,0>:ub                  {I@4}                //  ALU pipe: int; $59
(W)     mov (1|M0)               r3.8<1>:hf    0x80:hf                              {I@1}            //  ALU pipe: float; $75
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r3.2<0;1,0>:d     32:w                                //  ALU pipe: int; $63
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r3.0<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $78
        add (32|M0)              r12.0<1>:d    r5.0<0;1,0>:d     r10.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $71
        add3 (32|M0)             r20.0<1>:d    r5.0<0;0>:d       r3.8<0;0>:w       r18.0<1>:d       {F@1} //  ALU pipe: int; $75
(W)     and (1|M0)               r5.1<1>:d     r3.5<0;1,0>:d     8:w                                 //  ALU pipe: int; $65
(W)     and (1|M0)               r9.0<1>:d     r3.5<0;1,0>:d     1:w                                 //  ALU pipe: int; $67
(W)     add (1|M0)               r8.0<1>:d     r6.0<0;1,0>:d     r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $60
(W)     asr (1|M0)               r64.12<1>:d   r3.0<0;1,0>:d     31:w                                //  ALU pipe: int; $79
(W)     cmp (32|M0)   (gt)f2.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $62
(W)     mov (1|M0)               r64.14<1>:ud  f1.0<0;1,0>:ud                                        //  ALU pipe: int; $63
(W)     mov (1|M0)               r64.13<1>:ud  f0.0<0;1,0>:ud                                        //  ALU pipe: int; $78
        mov (16|M0)              r14.0<2>:ud   r12.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $73
        mov (16|M16)             r16.0<2>:ud   r13.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $73
        mov (16|M0)              r22.0<2>:ud   r20.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $77
(W)     mov (1|M0)               r64.6<1>:f    r9.0<0;1,0>:ud                   {I@7}                //  ALU pipe: float; $68
(W)     asr (1|M0)               r64.7<1>:d    r8.0<0;1,0>:d     5:w               {I@7}             //  ALU pipe: int; $61
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r5.1<0;1,0>:d     0:w                                 //  ALU pipe: int; $66
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.3<0;1,0>:d     0:w                                 //  ALU pipe: int; $82
        mov (16|M16)             r8.0<2>:ud    r21.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $77
(W)     add (1|M0)               r2.8<1>:d     r64.12<0;1,0>:d   r64.5<0;1,0>:d   {I@7}              //  ALU pipe: int; $80
        add (16|M0)              r44.0<1>:q    r6.1<0;1,0>:q     r14.0<2;1,0>:ud  {I@7}              //  ALU pipe: int; $73
        add (16|M16)             r46.0<1>:q    r6.1<0;1,0>:q     r16.0<2;1,0>:ud  {I@7}              //  ALU pipe: int; $73
        add (16|M0)              r32.0<1>:q    r6.1<0;1,0>:q     r22.0<2;1,0>:ud  {I@7}              //  ALU pipe: int; $77
        add (16|M16)             r34.0<1>:q    r6.1<0;1,0>:q     r8.0<2;1,0>:ud   {I@5}              //  ALU pipe: int; $77
(W)     mov (1|M0)               r68.0<1>:uq   r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $52
(W)     mov (1|M0)               r64.0<1>:uq   r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $53
(W)     mov (1|M0)               r66.0<1>:uq   r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $54
(W)     add (1|M0)               r66.2<1>:d    r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $55
(W)     mov (1|M0)               r64.15<1>:f   r3.2<0;1,0>:d                                         //  ALU pipe: float; $64
(W)     mov (1|M0)               r64.10<1>:d   (abs)r3.3<0;1,0>:d                                    //  ALU pipe: int; $83
(W)     mov (1|M0)               r64.4<1>:q    r6.4<0;1,0>:ud                                        //  ALU pipe: int; $84
(W)     xor (1|M0)               r64.11<1>:d   r2.8<0;1,0>:d     r64.12<0;1,0>:d  {I@7}              //  ALU pipe: int; $81
// B004: [inDivergent],  Preds:{B052, B003},  Succs:{B005, B051}
_0_058:
        mov (16|M0)              r72.0<1>:d    r56.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $86
        mov (16|M16)             r73.0<1>:d    r54.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $87
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r72.0<1;1,0>:ud   r65.0<0;1,0>:ud  {I@1}              //  ALU pipe: int; $90
        mov (16|M0)              r70.0<1>:d    r56.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $88
        mov (16|M16)             r71.0<1>:d    r54.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $89
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r70.0<1;1,0>:d    r64.4<0;1,0>:d   {I@1}              //  ALU pipe: int; $91
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r70.0<1;1,0>:ud   r64.4<0;1,0>:ud                     //  ALU pipe: int; $93
(~f3.0) goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $95
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B051}
_0_060:
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r68:1]            {F@1,$5} // ex_desc:0x0; desc:0x2108580 // $97
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$5.dst}          //  ALU pipe: int; $98
(f3.0)  goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $99
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B051}
_0_061:
        mov (16|M0)              r7.0<2>:f     r64.0<0;1,0>:f                                        //  ALU pipe: float; $101
        mov (16|M16)             r9.0<2>:f     r64.0<0;1,0>:f                                        //  ALU pipe: float; $101
        mov (32|M0)              r12.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $103
        mov (16|M0)              r7.1<2>:f     r64.1<0;1,0>:f                                        //  ALU pipe: float; $102
        mov (16|M16)             r9.1<2>:ud    r64.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $102
        atomic_or.ugm.d32.a64 (32|M0)  r14:2    [r7:4]            r12:2              {A@1,$6} // ex_desc:0x0; desc:0x8200599 // $104
        cmp (32|M0)   (eq)f3.0   null<1>:d     r14.0<1;1,0>:d    0:w               {$6.dst}          //  ALU pipe: int; $106
(~f3.0) goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $107
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B049}
_0_062:
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r66:1]            {$7} // ex_desc:0x0; desc:0x2108580 // $109
(W)     cmp (32|M0)   (gt)f3.0   null<1>:d     r3.0<0;1,0>:d     r66.2<0;1,0>:d   {$7.dst}           //  ALU pipe: int; $110
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $111
(W&f3.0) jmpi                                _0_063                                                  //  ALU pipe: int; $113
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B010}
_0_064:
(W)     mov (1|M0)               f3.0<1>:ud    r64.13<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $116
        mov (16|M0)              r50.0<1>:d    r56.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $115
        mov (16|M16)             r51.0<1>:d    r54.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $115
(W&~f3.0) jmpi                               _0_065                                                  //  ALU pipe: int; $116
// B009: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_066:
        mov (32|M0)              r42.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $118
(W)     jmpi                                 _0_067                                                  // $119
// B010: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_065:
        asr (32|M0)              r8.0<1>:d     r50.0<1;1,0>:d    31:w               {Compacted,I@4}  //  ALU pipe: int; $121
        add (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     r50.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $122
        xor (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $123
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $124
(W)     mov (1|M0)               r2.8<1>:f     r64.11<0;1,0>:ud                 {A@1}                //  ALU pipe: float; $125
(W)     mov (1|M0)               r3.4<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $130
(W)     math.inv (1|M0)          r4.0<1>:f     r2.8<0;1,0>:f                    {F@2}                //  ALU pipe: math; $129
        mov (32|M0)              r14.0<1>:f    r12.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $128
(W)     mad (1|M0)               r5.0<1>:f     r4.0<0;0>:f       r3.4<0;0>:f       r4.0<0>:f        {A@1} //  ALU pipe: float; $130
        mov (32|M0)              r18.0<1>:ud   r14.0<1;1,0>:f                   {F@2}                //  ALU pipe: int; $132
        mul (32|M0)              r16.0<1>:f    r14.0<1;1,0>:f    r5.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $131
(W)     mov (1|M0)               r2.9<1>:ud    r2.8<0;1,0>:f                                         //  ALU pipe: int; $126
        add (32|M0)              r20.0<1>:d    r12.0<1;1,0>:d    -r18.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $133
        mov (32|M0)              r10.0<1>:ud   r16.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $134
(W)     add (1|M0)               r3.0<1>:d     r64.11<0;1,0>:d   -r2.9<0;1,0>:d   {I@3}              //  ALU pipe: int; $127
        mov (32|M0)              r24.0<1>:f    r10.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $137
        mov (32|M0)              r22.0<1>:f    r20.0<1;1,0>:ud                                       //  ALU pipe: float; $136
(W)     mov (1|M0)               r6.0<1>:f     r3.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $135
        mad (32|M0)              acc0.0<1>:f   r14.0<1;0>:f      r24.0<1;0>:f      -r2.8<0>:f       {F@3} //  ALU pipe: float; $139 R{} IR{}{E:7,E:4,E:1,},  R{r2,} IR{}{O:7,O:12,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r22.0<1;0>:f      r24.0<1;0>:f      -r6.0<0>:f       {F@2} //  ALU pipe: float; $141 R{} IR{}{E:3,E:4,E:3,},  R{r6,} IR{}{O:11,O:12,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $142
        mul (32|M0)              r26.0<1>:f    r5.0<0;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $143
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $144
        mov (32|M0)              r28.0<1>:ud   r26.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $145
        add (32|M0)              r30.0<1>:d    r28.0<1;1,0>:d    r10.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $146
(W)     mul (16|M0)              acc0.0<1>:d   r30.0<1;1,0>:d    r64.22<0;1,0>:uw {I@1}              //  ALU pipe: int; $148
        macl (16|M0)             r16.0<1>:d    r30.0<1;1,0>:d    r64.11<0;1,0>:d  {Compacted}        //  ALU pipe: int; $148
(W)     mul (16|M16)             acc0.0<1>:d   r31.0<1;1,0>:d    r64.22<0;1,0>:uw                    //  ALU pipe: int; $148
        macl (16|M16)            r17.0<1>:d    r31.0<1;1,0>:d    r64.11<0;1,0>:d  {Compacted}        //  ALU pipe: int; $149
        add (32|M0)              r14.0<1>:d    r12.0<1;1,0>:d    -r16.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $149
        cmp (32|M0)   (ge)f3.0   r20.0<1>:ud   r14.0<1;1,0>:ud   r64.11<0;1,0>:ud {I@1}              //  ALU pipe: int; $150
        xor (32|M0)              r18.0<1>:d    r64.12<0;1,0>:d   r8.0<1;1,0>:d    {Compacted}        //  ALU pipe: int; $147
        add3 (32|M0)             r22.0<1>:d    r30.0<1;0>:d      r18.0<1;0>:d      -r20.0<1>:d      {Compacted,I@1} //  ALU pipe: int; $151 R{} IR{}{E:7,E:1,E:2,},  R{} IR{}{O:15,O:9,O:10,},  {BC=2}
        bfn.(s0^s1^s2) (32|M0)   r42.0<1>:ud   r22.0<1;0>:ud     r64.12<0;0>:ud    r8.0<1>:ud       {I@1} //  ALU pipe: int; $152 R{} IR{}{E:3,E:0,E:4,},  R{r64,} IR{}{O:11,O:4,},  {BC=1}
// B011: [inDivergent],  Preds:{B010, B009},  Succs:{B012, B014}
_0_067:
(W)     mul (16|M0)              acc0.0<1>:d   r42.0<1;1,0>:d    r64.10<0;1,0>:uw {I@1}              //  ALU pipe: int; $154
        macl (16|M0)             r8.0<1>:d     r42.0<1;1,0>:d    r64.5<0;1,0>:d   {Compacted}        //  ALU pipe: int; $154
(W)     mul (16|M16)             acc0.0<1>:d   r43.0<1;1,0>:d    r64.10<0;1,0>:uw                    //  ALU pipe: int; $154
        macl (16|M16)            r9.0<1>:d     r43.0<1;1,0>:d    r64.5<0;1,0>:d   {Compacted}        //  ALU pipe: int; $155
        add (32|M0)              r10.0<1>:d    r50.0<1;1,0>:d    -r8.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $155
        shl (32|M0)              r40.0<1>:d    r10.0<1;1,0>:d    2:w               {Compacted,I@1}   //  ALU pipe: int; $156
(W&~f2.0) jmpi                               _0_068                                                  //  ALU pipe: int; $157
// B012: [inDivergent],  Preds:{B011},  Succs:{B013}
_0_069:
(W)     mul (16|M0)              acc0.0<1>:d   r42.0<1;1,0>:d    r64.14<0;1,0>:uw                    //  ALU pipe: int; $159
        macl (16|M0)             r8.0<1>:d     r42.0<1;1,0>:d    r64.7<0;1,0>:d   {Compacted}        //  ALU pipe: int; $159
(W)     mul (16|M16)             acc0.0<1>:d   r43.0<1;1,0>:d    r64.14<0;1,0>:uw                    //  ALU pipe: int; $159
        macl (16|M16)            r9.0<1>:d     r43.0<1;1,0>:d    r64.7<0;1,0>:d   {Compacted}        //  ALU pipe: int; $161
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@3}      //  ALU pipe: int; $161
        mov (16|M16)             r14.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $161
        shl (16|M0)              r12.0<1>:q    r10.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $161
        shl (16|M16)             r16.0<1>:q    r14.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $161
        add (16|M0)              r29.0<1>:q    r12.0<1;1,0>:q    r5.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $162
        add (16|M16)             r27.0<1>:q    r16.0<1;1,0>:q    r5.7<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $162
(W)     mov (1|M0)               r3.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $163
// B013: [inDivergent],  Preds:{B013, B012},  Succs:{B014, B013}
_0_070:
(W)     shl (1|M0)               r2.4<1>:q     r3.0<0;1,0>:ud    2:w               {I@1}             //  ALU pipe: int; $166
(W)     add (1|M0)               r3.0<1>:d     r3.0<0;1,0>:d     1:w               {Compacted}       //  ALU pipe: int; $172
        add (16|M0)              r7.0<1>:q     r29.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $167
        add (16|M16)             r9.0<1>:q     r27.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $167
        load.ugm.d32.a64 (32|M0)  r12:2         [r7:4]             {I@1,$9} // ex_desc:0x0; desc:0x8200580 // $169
        add (16|M0)              r14.0<1>:q    r32.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,$8.src} //  ALU pipe: int; $170
        add (16|M16)             r16.0<1>:q    r34.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $170
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.0<0;1,0>:d     r64.7<0;1,0>:d                      //  ALU pipe: int; $173
        sync.nop                             null                             {Compacted,$9.dst}     // $171
        store.ugm.d32.a64.wb.wb (32|M0)  [r14:4] r12:2             {I@2,$8} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $171
(W&f3.0) jmpi                                _0_070                                                  //  ALU pipe: int; $174
// B014: [inDivergent],  Preds:{B013, B011},  Succs:{B015, B024}
_0_068:
(W)     mov (1|M0)               f3.0<1>:ud    r64.14<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $176
(W&~f3.0) jmpi                               _0_071                                                  //  ALU pipe: int; $176
// B015: [inDivergent],  Preds:{B014},  Succs:{B016}
_0_072:
(W)     mov (1|M0)               r3.5<1>:d     1:w                                                   //  ALU pipe: int; $178
// B016: [inDivergent],  Preds:{B023, B015},  Succs:{B017, B022}
_0_073:
(W)     shl (1|M0)               r3.4<1>:d     r3.5<0;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $180
(W&~f2.0) jmpi                               _0_074                                                  //  ALU pipe: int; $181
// B017: [inDivergent],  Preds:{B016},  Succs:{B018}
_0_075:
(W)     mov (1|M0)               r3.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $183
// B018: [inDivergent],  Preds:{B021, B017},  Succs:{B019, B020}
_0_076:
(W)     shl (1|M0)               r2.4<1>:q     r3.0<0;1,0>:d     2:w               {I@1}             //  ALU pipe: int; $186
(W)     add (1|M0)               r3.1<1>:d     r3.0<0;1,0>:d     r3.5<0;1,0>:d    {Compacted}        //  ALU pipe: int; $189
        add (16|M0)              r76.0<1>:q    r32.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,@2,$10.src} //  ALU pipe: int; $187
        add (16|M16)             r78.0<1>:q    r34.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $187
        load.ugm.d32.a64.ca.ca (32|M0)  r108:2  [r76:4]            {I@1,$11} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $188
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.1<0;1,0>:d     r64.7<0;1,0>:d                      //  ALU pipe: int; $190
(W&f3.0) jmpi                                _0_077                                                  //  ALU pipe: int; $191
// B019: [inDivergent],  Preds:{B018},  Succs:{B021}
_0_078:
        mov (32|M0)              r106.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $193
(W)     jmpi                                 _0_079                                                  // $194
// B020: [inDivergent],  Preds:{B018},  Succs:{B021}
_0_077:
(W)     shl (1|M0)               r2.4<1>:q     r3.1<0;1,0>:d     2:w                                 //  ALU pipe: int; $197
        add (16|M0)              r7.0<1>:q     r32.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $198
        add (16|M16)             r9.0<1>:q     r34.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $198
        load.ugm.d32.a64.ca.ca (32|M0)  r106:2  [r7:4]             {I@1,$12} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $199
// B021: [inDivergent],  Preds:{B020, B019},  Succs:{B022, B018}
_0_079:
        sync.nop                             null                             {Compacted,$12.dst}    // $201
        add (32|M0)              r8.0<1>:f     r108.0<1;1,0>:f   r106.0<1;1,0>:f  {Compacted,$11.dst} //  ALU pipe: float; $201
(W)     add (1|M0)               r3.0<1>:d     r3.0<0;1,0>:d     r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $203
        store.ugm.d32.a64.wb.wb (32|M0)  [r76:4] r8:2              {F@1,$10} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $202
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.0<0;1,0>:d     r64.7<0;1,0>:d   {I@1}              //  ALU pipe: int; $204
(W&f3.0) jmpi                                _0_076                                                  //  ALU pipe: int; $205
// B022: [inDivergent],  Preds:{B021, B016},  Succs:{B023, B024}
_0_074:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.4<0;1,0>:d     r64.7<0;1,0>:d                      //  ALU pipe: int; $207
(W&~f3.0) jmpi                               _0_071                                                  //  ALU pipe: int; $208
// B023: [inDivergent],  Preds:{B022},  Succs:{B016}
_0_080:
(W)     mov (1|M0)               r3.5<1>:d     r3.4<0;1,0>:d                                         //  ALU pipe: int; $210
(W)     jmpi                                 _0_073                                                  // $211
// B024: [inDivergent],  Preds:{B022, B014},  Succs:{B025, B026}
_0_071:
        load.ugm.d32.a64.ca.ca (32|M0)  r124:2  [r32:4]            {$13} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $213
        mov (32|M0)              r120.0<1>:f   r64.15<0;1,0>:f                                       //  ALU pipe: float; $214
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $214
        math.invm (16|M0) (eo)f3.0  r116.mme0:f  r124.nomme<1;1,0>:f  r120.nomme<1;1,0>:f {A@1,$13.dst} //  ALU pipe: math; $214
(f3.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $214
// B025: [inDivergent],  Preds:{B024},  Succs:{B026}
_L_k0_6_:
        madm (16|M0)             r114.mme1:f   r91.nomme:f       r124.nomme:f      r116.mme0:f      {M@1} //  ALU pipe: float; $214
        madm (16|M0)             r112.mme2:f   r90.nomme:f       -r120.nomme:f     r116.mme0:f       //  ALU pipe: float; $214
        madm (16|M0)             r122.mme3:f   r116.mme0:f       r112.mme2:f       r116.mme0:f      {F@1} //  ALU pipe: float; $214
        madm (16|M0)             r110.mme4:f   r124.nomme:f      -r120.nomme:f     r114.mme1:f       //  ALU pipe: float; $214 R{} IR{}{E:6,E:4,E:1,},  {BC=1}
        madm (16|M0)             r114.mme5:f   r114.mme1:f       r110.mme4:f       r122.mme3:f      {F@1} //  ALU pipe: float; $214 R{} IR{}{E:1,E:7,E:5,},  {BC=1}
        madm (16|M0)             r118.mme6:f   r124.nomme:f      -r120.nomme:f     r114.mme5:f      {F@1} //  ALU pipe: float; $214 R{} IR{}{E:6,E:4,E:1,},  {BC=1}
        madm (16|M0)             r116.nomme:f  r114.mme5:f       r118.mme6:f       r122.mme3:f      {F@1} //  ALU pipe: float; $214 R{} IR{}{E:1,E:3,E:5,},  {BC=1}
// B026: [inDivergent],  Preds:{B025, B024},  Succs:{B027, B028}
_L_k0_0_macro:
        join (32|M0)                         _0_059                                                  // 
L3344:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $214
        math.invm (16|M16) (eo)f3.0  r117.mme0:f  r125.nomme<1;1,0>:f  r121.nomme<1;1,0>:f {I@1}     //  ALU pipe: math; $214
(f3.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $214
// B027: [inDivergent],  Preds:{B026},  Succs:{B028}
_L_k0_7_:
        madm (16|M16)            r115.mme1:f   r91.nomme:f       r125.nomme:f      r117.mme0:f      {M@1} //  ALU pipe: float; $214 R{} IR{}{O:5,O:6,O:2,},  {BC=1}
        madm (16|M16)            r113.mme2:f   r90.nomme:f       -r121.nomme:f     r117.mme0:f       //  ALU pipe: float; $214
        madm (16|M16)            r123.mme3:f   r117.mme0:f       r113.mme2:f       r117.mme0:f      {F@1} //  ALU pipe: float; $214
        madm (16|M16)            r111.mme4:f   r125.nomme:f      -r121.nomme:f     r115.mme1:f       //  ALU pipe: float; $214 R{} IR{}{O:6,O:4,O:1,},  {BC=1}
        madm (16|M16)            r115.mme5:f   r115.mme1:f       r111.mme4:f       r123.mme3:f      {F@1} //  ALU pipe: float; $214 R{} IR{}{O:1,O:7,O:5,},  {BC=1}
        madm (16|M16)            r119.mme6:f   r125.nomme:f      -r121.nomme:f     r115.mme5:f      {F@1} //  ALU pipe: float; $214 R{} IR{}{O:6,O:4,O:1,},  {BC=1}
        madm (16|M16)            r117.nomme:f  r115.mme5:f       r119.mme6:f       r123.mme3:f      {F@1} //  ALU pipe: float; $214 R{} IR{}{O:1,O:3,O:5,},  {BC=1}
// B028: [inDivergent],  Preds:{B027, B026},  Succs:{B029, B030}
_L_k0_1_macro:
        join (32|M0)                         _0_059                                                  // 
L3520:
        add (32|M0)              r14.0<1>:f    r116.0<1;1,0>:f   0x358637BD:f               {@1,$8.src} //  ALU pipe: float; $215
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $216
        math.rsqtm (16|M0) (eo)f3.0  r12.mme0:f  r14.nomme<1;1,0>:f             {A@1}                //  ALU pipe: math; $216
(f3.0)  goto (32|M0)                         _L_k0_2_macro     _L_k0_2_macro                         //  ALU pipe: int; $216
// B029: [inDivergent],  Preds:{B028},  Succs:{B030}
_L_k0_8_:
        madm (16|M0)             r10.mme1:f    r91.nomme:f       r89.nomme:f       r12.mme0:f       {M@1} //  ALU pipe: float; $216
        madm (16|M0)             r6.mme2:f     r91.nomme:f       r14.nomme:f       r12.mme0:f        //  ALU pipe: float; $216
        madm (16|M0)             r8.mme3:f     r89.nomme:f       -r6.mme2:f        r10.mme1:f       {@1,$10.src} //  ALU pipe: float; $216
        madm (16|M0)             r10.mme4:f    r10.mme1:f        r8.mme3:f         r10.mme1:f       {F@1} //  ALU pipe: float; $216
        madm (16|M0)             r12.mme5:f    r6.mme2:f         r8.mme3:f         r6.mme2:f         //  ALU pipe: float; $216
        madm (16|M0)             r8.mme6:f     r14.nomme:f       -r12.mme5:f       r12.mme5:f       {F@1} //  ALU pipe: float; $216
        madm (16|M0)             r12.nomme:f   r12.mme5:f        r10.mme4:f        r8.mme6:f        {F@1} //  ALU pipe: float; $216 R{} IR{}{E:6,E:5,E:4,},  {BC=1}
// B030: [inDivergent],  Preds:{B029, B028},  Succs:{B031, B032}
_L_k0_2_macro:
        join (32|M0)                         _0_059                                                  // 
L3712:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $216
        math.rsqtm (16|M16) (eo)f3.0  r13.mme0:f  r15.nomme<1;1,0>:f            {I@1}                //  ALU pipe: math; $216
(f3.0)  goto (32|M0)                         _L_k0_3_macro     _L_k0_3_macro                         //  ALU pipe: int; $216
// B031: [inDivergent],  Preds:{B030},  Succs:{B032}
_L_k0_9_:
        madm (16|M16)            r11.mme1:f    r91.nomme:f       r89.nomme:f       r13.mme0:f       {M@1} //  ALU pipe: float; $216 R{} IR{}{O:5,O:4,O:6,},  {BC=1}
        madm (16|M16)            r7.mme2:f     r91.nomme:f       r15.nomme:f       r13.mme0:f        //  ALU pipe: float; $216
        madm (16|M16)            r9.mme3:f     r89.nomme:f       -r7.mme2:f        r11.mme1:f       {@1,$10.src} //  ALU pipe: float; $216 R{} IR{}{O:4,O:3,O:5,},  {BC=1}
        madm (16|M16)            r11.mme4:f    r11.mme1:f        r9.mme3:f         r11.mme1:f       {F@1} //  ALU pipe: float; $216
        madm (16|M16)            r13.mme5:f    r7.mme2:f         r9.mme3:f         r7.mme2:f         //  ALU pipe: float; $216
        madm (16|M16)            r9.mme6:f     r15.nomme:f       -r13.mme5:f       r13.mme5:f       {F@1} //  ALU pipe: float; $216
        madm (16|M16)            r13.nomme:f   r13.mme5:f        r11.mme4:f        r9.mme6:f        {F@1} //  ALU pipe: float; $216 R{} IR{}{O:6,O:5,O:4,},  {BC=1}
// B032: [inDivergent],  Preds:{B031, B030},  Succs:{B033, B051}
_L_k0_3_macro:
        join (32|M0)                         _0_059                                                  // 
L3888:
        mov (32|M0)              r8.0<1>:f     r12.0<1;1,0>:f                   {Compacted,@1,$10.src} //  ALU pipe: float; $216
        store.ugm.d32.a64.wb.wb (32|M0)  [r44:4] r8:2              {F@1,$14} // ex_desc:0x0; desc:0x80E0584 //  address space: private; ; $217
        add (32|M0)              r10.0<1>:d    r40.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $219
        sel (32|M0)   (lt)f0.0   r36.0<1>:d    r10.0<1;1,0>:d    r3.2<0;1,0>:d    {I@1}              //  ALU pipe: int; $220
        cmp (32|M0)   (lt)f3.0   null<1>:d     r40.0<1;1,0>:d    r36.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $221
        load.ugm.d32.a64.ca.ca (32|M0)  r38:2   [r44:4]            {$4} // ex_desc:0x0; desc:0x8280580 //  address space: private; ; $218
(~f3.0) goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $222
// B033: [inDivergent],  Preds:{B032},  Succs:{B034, B035}
_0_081:
(W&~f0.0) jmpi                               _0_082                                                  //  ALU pipe: int; $224
// B034: [inDivergent],  Preds:{B033},  Succs:{B036}
_0_083:
        mov (32|M0)              r80.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $226
(W)     jmpi                                 _0_084                                                  // $227
// B035: [inDivergent],  Preds:{B033},  Succs:{B036}
_0_082:
        asr (32|M0)              r8.0<1>:d     r42.0<1;1,0>:d    31:w               {Compacted,$14.src} //  ALU pipe: int; $229
        add (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     r42.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $230
        xor (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $231
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $232
(W)     mov (1|M0)               r2.8<1>:f     r64.10<0;1,0>:ud                 {A@1}                //  ALU pipe: float; $233
(W)     mov (1|M0)               r3.4<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $238
(W)     math.inv (1|M0)          r4.0<1>:f     r2.8<0;1,0>:f                    {F@2}                //  ALU pipe: math; $237
        mov (32|M0)              r14.0<1>:f    r12.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $236
(W)     mad (1|M0)               r5.0<1>:f     r4.0<0;0>:f       r3.4<0;0>:f       r4.0<0>:f        {A@1} //  ALU pipe: float; $238
        mov (32|M0)              r18.0<1>:ud   r14.0<1;1,0>:f                   {F@2}                //  ALU pipe: int; $240
        mul (32|M0)              r16.0<1>:f    r14.0<1;1,0>:f    r5.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $239
(W)     mov (1|M0)               r2.9<1>:ud    r2.8<0;1,0>:f                                         //  ALU pipe: int; $234
        add (32|M0)              r20.0<1>:d    r12.0<1;1,0>:d    -r18.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $241
        mov (32|M0)              r10.0<1>:ud   r16.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $242
(W)     add (1|M0)               r3.0<1>:d     (abs)r3.3<0;1,0>:d  -r2.9<0;1,0>:d {I@3}              //  ALU pipe: int; $235
        mov (32|M0)              r24.0<1>:f    r10.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $245
        mov (32|M0)              r22.0<1>:f    r20.0<1;1,0>:ud                                       //  ALU pipe: float; $244
(W)     mov (1|M0)               r6.0<1>:f     r3.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $243
        mad (32|M0)              acc0.0<1>:f   r14.0<1;0>:f      r24.0<1;0>:f      -r2.8<0>:f       {F@3} //  ALU pipe: float; $247 R{} IR{}{E:7,E:4,E:1,},  R{r2,} IR{}{O:7,O:12,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r22.0<1;0>:f      r24.0<1;0>:f      -r6.0<0>:f       {F@2} //  ALU pipe: float; $249 R{} IR{}{E:3,E:4,E:3,},  R{r6,} IR{}{O:11,O:12,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $250
        mul (32|M0)              r26.0<1>:f    r5.0<0;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $251
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $252
        mov (32|M0)              r28.0<1>:ud   r26.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $253
        add (32|M0)              r30.0<1>:d    r28.0<1;1,0>:d    r10.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $254
(W)     mov (1|M0)               r4.0<1>:d     (abs)r3.3<0;1,0>:d                                    //  ALU pipe: int; $255
(W)     mul (16|M0)              acc0.0<1>:d   r30.0<1;1,0>:d    r4.0<0;1,0>:uw   {I@1}              //  ALU pipe: int; $255
        macl (16|M0)             r16.0<1>:d    r30.0<1;1,0>:d    r4.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $255
(W)     mul (16|M16)             acc0.0<1>:d   r31.0<1;1,0>:d    r4.0<0;1,0>:uw                      //  ALU pipe: int; $255
        macl (16|M16)            r17.0<1>:d    r31.0<1;1,0>:d    r4.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $256
        add (32|M0)              r14.0<1>:d    r12.0<1;1,0>:d    -r16.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $256
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r14.0<1;1,0>:ud   r64.10<0;1,0>:ud {I@1}              //  ALU pipe: int; $257
(~f3.0) sel (32|M0)              r18.0<1>:d    (abs)r3.3<0;1,0>:d  0:w                               //  ALU pipe: int; $258
        add3 (32|M0)             r20.0<1>:d    r14.0<1;0>:d      r8.0<1;0>:d       -r18.0<1>:d      {Compacted,I@1} //  ALU pipe: int; $259 R{} IR{}{E:7,E:4,E:1,},  R{} IR{}{O:7,O:4,O:9,},  {BC=2}
        xor (32|M0)              r80.0<1>:d    r20.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $260
// B036: [inDivergent],  Preds:{B035, B034},  Succs:{B037, B038}
_0_084:
(W)     mov (32|M0)              r20.0<1>:f    0x3F800000:f                               {I@1}      //  ALU pipe: float; $262
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $262
        math.invm (16|M0) (eo)f3.0  r100.mme0:f  r20.nomme<1;1,0>:f  r38.nomme<1;1,0>:f {A@1,$4.dst} //  ALU pipe: math; $262
(f3.0)  goto (32|M0)                         _L_k0_4_macro     _L_k0_4_macro                         //  ALU pipe: int; $262
// B037: [inDivergent],  Preds:{B036},  Succs:{B038}
_L_k0_10_:
        madm (16|M0)             r98.mme1:f    r91.nomme:f       r20.nomme:f       r100.mme0:f      {M@1} //  ALU pipe: float; $262 R{} IR{}{O:5,E:2,E:2,},  {BC=1}
        madm (16|M0)             r96.mme2:f    r90.nomme:f       -r38.nomme:f      r100.mme0:f       //  ALU pipe: float; $262
        madm (16|M0)             r104.mme3:f   r100.mme0:f       r96.mme2:f        r100.mme0:f      {F@1} //  ALU pipe: float; $262
        madm (16|M0)             r94.mme4:f    r20.nomme:f       -r38.nomme:f      r98.mme1:f        //  ALU pipe: float; $262 R{} IR{}{E:2,E:3,E:1,},  {BC=1}
        madm (16|M0)             r98.mme5:f    r98.mme1:f        r94.mme4:f        r104.mme3:f      {F@1} //  ALU pipe: float; $262 R{} IR{}{E:1,E:7,E:4,},  {BC=1}
        madm (16|M0)             r102.mme6:f   r20.nomme:f       -r38.nomme:f      r98.mme5:f       {F@1} //  ALU pipe: float; $262 R{} IR{}{E:2,E:3,E:1,},  {BC=1}
        madm (16|M0)             r100.nomme:f  r98.mme5:f        r102.mme6:f       r104.mme3:f      {F@1} //  ALU pipe: float; $262 R{} IR{}{E:1,E:3,E:4,},  {BC=1}
// B038: [inDivergent],  Preds:{B037, B036},  Succs:{B039, B040}
_L_k0_4_macro:
        join (32|M0)                         _0_059                                                  // 
L4664:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $262
        math.invm (16|M16) (eo)f3.0  r101.mme0:f  r21.nomme<1;1,0>:f  r39.nomme<1;1,0>:f {I@1}       //  ALU pipe: math; $262
(f3.0)  goto (32|M0)                         _L_k0_5_macro     _L_k0_5_macro                         //  ALU pipe: int; $262
// B039: [inDivergent],  Preds:{B038},  Succs:{B040}
_L_k0_11_:
        madm (16|M16)            r99.mme1:f    r91.nomme:f       r21.nomme:f       r101.mme0:f      {M@1} //  ALU pipe: float; $262 R{} IR{}{O:5,O:2,O:2,},  {BC=1}
        madm (16|M16)            r97.mme2:f    r90.nomme:f       -r39.nomme:f      r101.mme0:f       //  ALU pipe: float; $262
        madm (16|M16)            r105.mme3:f   r101.mme0:f       r97.mme2:f        r101.mme0:f      {F@1} //  ALU pipe: float; $262
        madm (16|M16)            r95.mme4:f    r21.nomme:f       -r39.nomme:f      r99.mme1:f        //  ALU pipe: float; $262 R{} IR{}{O:2,O:3,O:1,},  {BC=1}
        madm (16|M16)            r99.mme5:f    r99.mme1:f        r95.mme4:f        r105.mme3:f      {F@1} //  ALU pipe: float; $262 R{} IR{}{O:1,O:7,O:4,},  {BC=1}
        madm (16|M16)            r103.mme6:f   r21.nomme:f       -r39.nomme:f      r99.mme5:f       {F@1} //  ALU pipe: float; $262 R{} IR{}{O:2,O:3,O:1,},  {BC=1}
        madm (16|M16)            r101.nomme:f  r99.mme5:f        r103.mme6:f       r105.mme3:f      {F@1} //  ALU pipe: float; $262 R{} IR{}{O:1,O:3,O:4,},  {BC=1}
// B040: [inDivergent],  Preds:{B039, B038},  Succs:{B041}
_L_k0_5_macro:
        join (32|M0)                         _0_059                                                  // 
L4840:
(W)     mul (16|M0)              acc0.0<1>:d   r42.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $263
        macl (16|M0)             r58.0<1>:d    r42.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $263
(W)     mul (16|M16)             acc0.0<1>:d   r43.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $263
        mov (32|M0)              r60.0<1>:f    r100.0<1;1,0>:f                  {Compacted,F@1}      //  ALU pipe: float; $262
        macl (16|M16)            r59.0<1>:d    r43.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $264
(W)     mul (16|M0)              acc0.0<1>:d   r80.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $264
        macl (16|M0)             r62.0<1>:d    r80.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $264
(W)     mul (16|M16)             acc0.0<1>:d   r81.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $264
        macl (16|M16)            r63.0<1>:d    r81.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; 
// B041: [inDivergent],  Preds:{B047, B040},  Succs:{B042, B043}
_0_085:
        sync.nop                             null                             {Compacted,$15.src}    // $266
        add (32|M0)              r8.0<1>:d     r58.0<1;1,0>:d    r40.0<1;1,0>:d   {Compacted,@5,$14.src} //  ALU pipe: int; $266
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $268
        mov (16|M16)             r12.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $268
        shl (16|M0)              r84.0<1>:q    r10.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $268
        shl (16|M16)             r82.0<1>:q    r12.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $268
        add (16|M0)              r14.0<1>:q    r84.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $269
        add (16|M16)             r16.0<1>:q    r82.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $269
        load.ugm.d16u32.a64 (32|M0)  r18:2      [r14:4]            {I@1,$0} // ex_desc:0x0; desc:0x8200B80 // $271
        add (32|M0)              r22.0<1>:d    r62.0<1;1,0>:d    r40.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $274
        mov (16|M0)              r24.0<2>:ud   r22.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $275
        mov (16|M16)             r26.0<2>:ud   r23.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $275
        mov (16|M0)              r1.0<1>:q     r24.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $275
        mov (16|M16)             r126.0<1>:q   r26.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $275
        shl (32|M0)              r20.0<1>:d    r18.0<1;1,0>:ud   16:w               {$0.dst}         //  ALU pipe: int; $272
        mul (32|M0)              r74.0<1>:f    r60.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,A@1}    //  ALU pipe: float; $273
(W&f1.0) jmpi                                _0_086                                                  //  ALU pipe: int; $276
// B042: [inDivergent],  Preds:{B041},  Succs:{B044}
_0_087:
        shl (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     2:w               {Compacted}       //  ALU pipe: int; $278
        shl (16|M16)             r9.0<1>:q     r126.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $278
        add (16|M0)              r11.0<1>:q    r7.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $279
        add (16|M16)             r13.0<1>:q    r9.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $279
        load.ugm.d32.a64 (32|M0)  r86:2         [r11:4]            {I@1,$1} // ex_desc:0x0; desc:0x8200580 // $281
(W)     jmpi                                 _0_088                                                  // $282
// B043: [inDivergent],  Preds:{B041},  Succs:{B044}
_0_086:
        shl (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     1:w               {Compacted}       //  ALU pipe: int; $284
        shl (16|M16)             r9.0<1>:q     r126.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $284
        add (16|M0)              r11.0<1>:q    r7.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $285
        add (16|M16)             r13.0<1>:q    r9.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $285
        load.ugm.d16u32.a64 (32|M0)  r16:2      [r11:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200B80 // $287
        shl (32|M0)              r86.0<1>:d    r16.0<1;1,0>:ud   16:w               {$5.dst}         //  ALU pipe: int; $288
// B044: [inDivergent],  Preds:{B043, B042},  Succs:{B045, B046}
_0_088:
        sync.nop                             null                             {Compacted,I@1}        // $290
        add (32|M0)              acc0.0<1>:f   r86.0<1;1,0>:f    r64.6<0;1,0>:f   {Compacted,$1.dst} //  ALU pipe: float; $290
        mul (32|M0)              r92.0<1>:f    r74.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $291
        and (32|M0)              r8.0<1>:d     r92.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $292
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r8.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $293
(f3.0)  goto (32|M0)                         _0_089            _0_089                                //  ALU pipe: int; $294
// B045: [inDivergent],  Preds:{B044},  Succs:{B047}
_0_090:
        shr (32|M0)              r8.0<1>:ud    r92.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $296
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $297
        add3 (32|M0)             r12.0<1>:d    r10.0<1;0>:d      r92.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $298
        shr (32|M0)              r14.0<1>:ud   r12.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $299
        mov (32|M0)              r26.0<1>:w    r14.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $300
        goto (32|M0)                         _0_089            _0_091                                // $301
// B046: [inDivergent],  Preds:{B044},  Succs:{B047}
_0_089:
        join (32|M0)                         _0_091                                                  // 
L5440:
        shr (32|M0)              r8.0<1>:ud    r92.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $303
        or (32|M0)               r26.0<1>:w    r8.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $305
// B047: [inDivergent],  Preds:{B046, B045},  Succs:{B048, B041}
_0_091:
        join (32|M0)                         _L_k0_12_                                               // 
L5488:
        add (32|M0)              r40.0<1>:d    r40.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $311
        cmp (32|M0)   (lt)f3.0   null<1>:d     r40.0<1;1,0>:d    r36.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $312
        add (16|M0)              r7.0<1>:q     r84.0<1;1,0>:q    r3.6<0;1,0>:q                       //  ALU pipe: int; $307
        add (16|M16)             r9.0<1>:q     r82.0<1;1,0>:q    r3.6<0;1,0>:q                       //  ALU pipe: int; $307
        mov (32|M0)              r12.0<1>:ud   r26.0<1;1,0>:uw                                       //  ALU pipe: int; $309
        store.ugm.d16u32.a64 (32|M0)  [r7:4]    r12:2              {I@1,$15} // ex_desc:0x0; desc:0x8000B84 // $310
(f3.0)  goto.b (32|M0)                       _L_k0_12_         _0_085                                //  ALU pipe: int; $313
// B048: [inDivergent],  Preds:{B047},  Succs:{B051}
_L_k0_12_:
        join (32|M0)                         _0_059                                                  // 
L5608:
        goto (32|M0)                         _0_059            _0_059                                // $314
// B049: [inDivergent],  Preds:{B007},  Succs:{B050, B051}
_0_063:
        cmp (32|M0)   (eq)f3.0   null<1>:d     r72.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $316
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r70.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $317
(~f3.0) goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $319
// B050: [inDivergent],  Preds:{B049},  Succs:{B051}
_0_092:
        mov (16|M0)              r7.0<2>:f     r64.0<0;1,0>:f                   {$15.src}            //  ALU pipe: float; $321
        mov (16|M16)             r9.0<2>:f     r64.0<0;1,0>:f                                        //  ALU pipe: float; $321
        mov (32|M0)              r12.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $323
        mov (16|M0)              r7.1<2>:f     r64.1<0;1,0>:f                                        //  ALU pipe: float; $322
        mov (16|M16)             r9.1<2>:ud    r64.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $322
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r7:4]           r12:2              {A@1,$6} // ex_desc:0x0; desc:0x800058B // $324
// B051: [inDivergent],  Preds:{B050, B049, B048, B032, B006, B005, B004},  Succs:{B052, B053}
_0_059:
        join (32|M0)                         _0_056                                                  // 
L5776:
        sync.allrd                           ($6,$14,$15)                                            // $326
        add (16|M0)              r7.0<1>:q     r56.0<1;1,0>:q    r64.4<0;1,0>:q   {Compacted,$10.src} //  ALU pipe: int; $326
        add (16|M16)             r9.0<1>:q     r54.0<1;1,0>:q    r64.4<0;1,0>:q   {Compacted}        //  ALU pipe: int; $326
        mov (16|M0)              r18.0<1>:d    r7.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $327
        mov (16|M16)             r19.0<1>:d    r9.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $328
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r18.0<1;1,0>:ud   r64.2<0;1,0>:ud  {I@1}              //  ALU pipe: int; $331
        mov (16|M0)              r16.0<1>:d    r7.1<2;1,0>:d                    {Compacted,$8.src}   //  ALU pipe: int; $329
        mov (16|M16)             r17.0<1>:d    r9.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $330
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r16.0<1;1,0>:d    r64.3<0;1,0>:d   {I@1}              //  ALU pipe: int; $332 R{} IR{}{E:0,E:0,},  R{r64,} IR{} {BC=1}
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r16.0<1;1,0>:ud   r64.3<0;1,0>:ud                     //  ALU pipe: int; $334
(~f3.0) goto (32|M0)                         _0_056            _0_056                                //  ALU pipe: int; $336
// B052: [inDivergent],  Preds:{B051},  Succs:{B004}
_0_093:
(f3.0)  sel (32|M0)              r8.0<1>:d     r18.0<1;1,0>:d    r52.0<1;1,0>:d                      //  ALU pipe: int; $338
(f3.0)  sel (32|M0)              r10.0<1>:d    r16.0<1;1,0>:d    r48.0<1;1,0>:d                      //  ALU pipe: int; $339 R{} IR{}{E:0,E:0,},  R{} IR{}{O:8,O:8,},  {BC=2}
        mov (16|M0)              r56.0<2>:d    r8.0<1;1,0>:d                    {I@2}                //  ALU pipe: int; $342
        mov (16|M16)             r54.0<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $343
        mov (16|M0)              r56.1<2>:d    r10.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $344
        mov (16|M16)             r54.1<2>:d    r11.0<1;1,0>:d                                        //  ALU pipe: int; $345
(W)     jmpi                                 _0_058                                                  // $346
// B053: Preds:{B051, B002},  Succs:{}
_0_056:
        join (32|M0)                         L6032                                                   // 
L6032:
        sync.nop                             null                             {Compacted,$3.src}     // $348
(W)     mov (16|M0)              r127.0<1>:f   r88.0<1;1,0>:f                   {Compacted,$2.src}   //  ALU pipe: float; $348
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$7} // wr:1+0, rd:0; end of thread // $348
L6064:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0xB:ud                                                // 


//.BankConflicts: 36
//.ByteRMWs: 2
//


//.numALUInst: 383
//.accSubDef: 7
//.accSubUse: 7
//.accSubCandidateDef: 7
//.accSubCandidateUse: 7
//
//
//.singlePipeAtOneDistNum: 107
//.allAtOneDistNum: 21
//.syncInstCount: 6
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 15
//.AfterReadTokenDepCount: 18
