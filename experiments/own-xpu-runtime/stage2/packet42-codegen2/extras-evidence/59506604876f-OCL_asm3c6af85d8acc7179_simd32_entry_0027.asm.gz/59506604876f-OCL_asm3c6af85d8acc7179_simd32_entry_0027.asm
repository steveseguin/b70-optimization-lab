//.kernel _ZTSN4sycl3_V16detail19__pf_kernel_wrapperIN9p42extras8FlatNameILNS3_4KindE5ELi0EEEEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 27 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 27 -GRFBumpUpNumber 2 "
//.instCount 82
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r3.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.9)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.10)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.6)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.7)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.8)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r3.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r3.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r5.2)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r5.0)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.10)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r4.6)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.14)
//.declare V0061 (71)  rf=r size=4 type=d align=2 words (r4.15)
//.declare V0063 (73)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0064 (74)  rf=r size=8 type=d alias=V0044+0 align=4 words (r2.6)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0066 (76)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.3)
//.declare V0067 (77)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r3.0)
//.declare V0068 (78)  rf=r size=8 type=ud alias=V0065+0 align=4 words (r2.10)
//.declare V0069 (79)  rf=r size=8 type=d alias=V0065+0 align=4 words (r2.10)
//.declare V0070 (80)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0073 (83)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0076 (86)  rf=r size=12 type=ud alias=V0036+0 align=2 words (r2.0)
//.declare V0080 (90)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0081 (91)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P01 (92)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0082 (93)  rf=r size=128 type=ud alias=V0080+0 align=32 words (r6.0)
//.declare V0083 (94)  rf=r size=8 type=ud alias=V0063+0 align=2 words (r2.8)
//.declare P02 (95)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P03 (96)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0084 (97)  rf=r size=128 type=ud alias=V0081+0 align=32 words (r8.0)
//.declare V0085 (98)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r4.4)
//.declare V0086 (99)  rf=r size=8 type=uq alias=V0058+0 align=4 words (r4.5)
//.declare V0087 (100)  rf=r size=8 type=uq alias=V0059+0 align=4 words (r4.6)
//.declare V0088 (101)  rf=r size=8 type=uq align=32 words (r10.0)
//.declare V0089 (102)  rf=r size=8 type=uq align=32 words (r12.0)
//.declare V0090 (103)  rf=r size=8 type=uq align=32 words (r14.0)
//.declare V0091 (104)  rf=r size=8 type=q align=4 words (r2.6)
//.declare V0092 (105)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r5.2)
//.declare V0094 (107)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0095 (108)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0096 (109)  rf=r size=4 type=d align=32 words (r5.0)
//.declare P04 (110)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P05 (111)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P06 (112)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0097 (113)  rf=r size=4 type=d align=32 words (r11.0)
//.declare P07 (114)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0098 (115)  rf=r size=4 type=ud alias=V0097+0 align=32 words (r11.0)
//.declare V0099 (116)  rf=r size=4 type=ud alias=V0061+0 align=2 words (r4.15)
//.declare V0101 (118)  rf=r size=256 type=uq align=32 words (r19.0)
//.declare V0102 (119)  rf=r size=256 type=ud alias=V0101+0 align=32 words (r19.0)
//.declare V0103 (120)  rf=r size=8 type=ud alias=V0088+0 align=32 words (r10.0)
//.declare V0104 (121)  rf=r size=128 type=d align=32 words (r23.0)
//.declare V0108 (125)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0109 (126)  rf=r size=128 type=d align=32 words (r27.0)
//.declare P08 (127)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0110 (128)  rf=r size=128 type=ud alias=V0108+0 align=32 words (r25.0)
//.declare P09 (129)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P10 (130)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0111 (131)  rf=r size=128 type=ud alias=V0109+0 align=32 words (r27.0)
//.declare  (135)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (136)  rf=r size=4 type=ud align=32 words (r13.0)
//.declare  (137)  rf=r size=128 type=uw align=32 words (r29.0)
//.declare  (138)  rf=r size=128 type=uw align=32 words (r31.0)
//.declare  (141)  rf=r size=128 type=q align=32 words (r33.0)
//.declare  (142)  rf=r size=128 type=q align=32 words (r35.0)
//.declare  (143)  rf=r size=128 type=q align=32 words (r37.0)
//.declare  (144)  rf=r size=128 type=q align=32 words (r39.0)
//.declare  (149)  rf=r size=128 type=q align=32 words (r41.0)
//.declare  (150)  rf=r size=128 type=q align=32 words (r43.0)
//.declare  (153)  rf=r size=128 type=d align=32 words (r45.0)
//.declare  (154)  rf=r size=128 type=d align=32 words (r47.0)
//.declare  (155)  rf=r size=128 type=d alias=+0 align=32 words (r37.0)
//.declare  (156)  rf=r size=128 type=d alias=+0 align=32 words (r39.0)
//.declare  (157)  rf=r size=128 type=d alias=+0 align=32 words (r41.0)
//.declare  (158)  rf=r size=128 type=d alias=+0 align=32 words (r43.0)
//.declare r0 (159)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (160)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (161)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (162)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (163)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (164)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (165)  rf=r size=32 type=ud align=2 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0045    | :q       |    0x8 | r3       | cti+0x20         |
// | V0046    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0049    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0050    | :d       |    0x4 | r3+0x28  | cti+0x48         |
// | V0051    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0052    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0053    | :d       |    0x4 | r4       | cti+0x60         |
// | V0054    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0055    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0056    | :d       |    0x4 | r4+0x18  | cti+0x78         |
// | V0057    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0058    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0059    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0060    | :d       |    0x4 | r4+0x38  | cti+0x98         |
// | V0061    | :d       |    0x4 | r4+0x3C  | cti+0x9C         |
// | V0042    | :uq      |    0x8 | r5       | cti+0xA0         |
// | V0037    | :d x 3   |    0xC | r5+0x8   | cti+0xA8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xA0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r5:1  bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B009}
// _main:
(W)     mov (16|M0)              r3.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted,$1.dst}   //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r3.2<0;1,0>:uw   {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r13.0<1>:ud   r2.3<0;1,0>:ud    r3.1<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r3.2<0;1,0>:uw                      //  ALU pipe: int; $4
(W)     mach (1|M0)              r4.0<1>:d     r2.3<0;1,0>:ud    r3.1<0;1,0>:ud                      //  ALU pipe: int; 
        mov (16|M0)              r29.0<4>:uw   r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r31.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.10<2>:ud   r13.0<0;1,0>:ud                  {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.11<2>:d    r4.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r2.8<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r33.0<1>:q    r2.5<0;1,0>:q     r29.0<4;1,0>:uw  {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r35.0<1>:q    r2.5<0;1,0>:q     r31.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r37.0<1>:q    r33.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r39.0<1>:q    r35.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r6.0<1>:d     r37.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r7.0<1>:d     r39.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r6.0<1;1,0>:ud    r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r8.0<1>:d     r37.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r9.0<1>:d     r39.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r8.0<1;1,0>:d     r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $18
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r8.0<1;1,0>:ud    r2.9<0;1,0>:ud                      //  ALU pipe: int; $20
(~f3.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_013:
(W)     mov (1|M0)               r10.0<1>:uq   r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $24
(W)     mov (1|M0)               r12.0<1>:uq   r4.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $25
(W)     mov (1|M0)               r14.0<1>:uq   r4.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $26
(W)     mov (1|M0)               r2.6<1>:q     r5.2<0;1,0>:ud                   {$2.dst}             //  ALU pipe: int; $27
// B004: [inDivergent],  Preds:{B008, B003},  Succs:{B005, B007}
_0_014:
(W)     load.ugm.d32x1t.a64 (1|M0)  r5:1        [r12:1]            {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $33
        mov (16|M0)              r15.0<1>:d    r37.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $29
        mov (16|M16)             r16.0<1>:d    r39.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $30
        cmp (32|M0)   (eq)f1.0   null<1>:d     r15.0<1;1,0>:d    0:w               {I@1}             //  ALU pipe: int; $34
        mov (16|M0)              r17.0<1>:d    r37.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $31
        mov (16|M16)             r18.0<1>:d    r39.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $32
(f1.0)  cmp (32|M0)   (eq)f1.0   null<1>:d     r17.0<1;1,0>:d    0:w               {I@1}             //  ALU pipe: int; $35
(f1.0)  cmp (32|M0)   (ne)f1.0   null<1>:d     r5.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $37
(~f1.0) goto (32|M0)                         _0_015            _0_015                                //  ALU pipe: int; $39
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B007}
_0_016:
(W)     load.ugm.d32x1t.a64 (1|M0)  r11:1       [r14:1]            {$5} // ex_desc:0x0; desc:0x2108580 // $41
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r11.0<0;1,0>:ud   r4.15<0;1,0>:ud  {$5.dst}           //  ALU pipe: int; $42
(f2.0)  goto (32|M0)                         _0_015            _0_015                                //  ALU pipe: int; $43
// B006: [inDivergent],  Preds:{B005},  Succs:{B007}
_0_017:
        mov (16|M0)              r19.0<2>:f    r10.0<0;1,0>:f                   {$4.src}             //  ALU pipe: float; $45
        mov (16|M16)             r21.0<2>:f    r10.0<0;1,0>:f                                        //  ALU pipe: float; $45
        mov (32|M0)              r23.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $47
        mov (16|M0)              r19.1<2>:f    r10.1<0;1,0>:f                                        //  ALU pipe: float; $46
        mov (16|M16)             r21.1<2>:ud   r10.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $46
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r19:4]          r23:2              {A@1,$4} // ex_desc:0x0; desc:0x800058B // $48
// B007: [inDivergent],  Preds:{B006, B005, B004},  Succs:{B008, B009}
_0_015:
        join (32|M0)                         _0_012                                                  // 
L816:
        add (16|M0)              r41.0<1>:q    r37.0<1;1,0>:q    r2.6<0;1,0>:q                       //  ALU pipe: int; $50
        add (16|M16)             r43.0<1>:q    r39.0<1;1,0>:q    r2.6<0;1,0>:q                       //  ALU pipe: int; $50
        mov (16|M0)              r25.0<1>:d    r41.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $51
        mov (16|M16)             r26.0<1>:d    r43.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $52
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r25.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $55
        mov (16|M0)              r27.0<1>:d    r41.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $53
        mov (16|M16)             r28.0<1>:d    r43.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $54
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r27.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $56
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r27.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $58
(~f0.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $60
// B008: [inDivergent],  Preds:{B007},  Succs:{B004}
_0_018:
(f0.0)  sel (32|M0)              r45.0<1>:d    r25.0<1;1,0>:d    r6.0<1;1,0>:d                       //  ALU pipe: int; $62
(f0.0)  sel (32|M0)              r47.0<1>:d    r27.0<1;1,0>:d    r8.0<1;1,0>:d                       //  ALU pipe: int; $63
        mov (16|M0)              r37.0<2>:d    r45.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $66
        mov (16|M16)             r39.0<2>:d    r46.0<1;1,0>:d                                        //  ALU pipe: int; $67
        mov (16|M0)              r37.1<2>:d    r47.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $68
        mov (16|M16)             r39.1<2>:d    r48.0<1;1,0>:d                                        //  ALU pipe: int; $69
(W)     jmpi                                 _0_014                                                  // $70
// B009: Preds:{B007, B002},  Succs:{}
_0_012:
        join (32|M0)                         L1072                                                   // 
L1072:
(W)     mov (16|M0)              r127.0<1>:f   r3.0<1;1,0>:f                    {Compacted,$2.src}   //  ALU pipe: float; $72
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$6} // wr:1+0, rd:0; end of thread // $72
L1096:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1B:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 68
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 12
//.allAtOneDistNum: 4
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 5
//.AfterReadTokenDepCount: 3
