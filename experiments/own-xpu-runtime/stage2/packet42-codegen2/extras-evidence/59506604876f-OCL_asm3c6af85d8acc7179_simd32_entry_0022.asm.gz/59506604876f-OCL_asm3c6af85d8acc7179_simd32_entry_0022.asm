//.kernel _ZTSN9p42extras8FlatNameILNS_4KindE2ELi0EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 1013643357 2328654201 -hashmovs1 0 22 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 1013643357 2328654201 -hashmovs1 0 22 -GRFBumpUpNumber 2 "
//.instCount 279
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r23.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.4)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r23.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r23.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=uq align=4 words (r4.7)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.8)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r4.4)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r4.12)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.13)
//.declare V0061 (71)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r4.5)
//.declare V0062 (72)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0063 (73)  rf=r size=4 type=d align=32 words (r7.0)
//.declare P01 (74)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0064 (75)  rf=r size=8 type=uq alias=V0055+0 align=4 words (r4.3)
//.declare V0065 (76)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0067 (78)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0068 (79)  rf=r size=256 type=ud alias=V0067+0 align=32 words (r7.0)
//.declare V0069 (80)  rf=r size=8 type=ud alias=V0065+0 align=32 words (r6.0)
//.declare V0070 (81)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0071 (82)  rf=r size=128 type=ud align=32 words (r13.0)
//.declare P02 (84)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0073 (85)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0075 (87)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0076 (88)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0078 (90)  rf=r size=128 type=ud alias=V0076+0 align=32 words (r5.0)
//.declare P03 (91)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P04 (92)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P05 (93)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0079 (94)  rf=r size=4 type=ud alias=V0045+0 align=2 words (r3.2)
//.declare P06 (95)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0083 (99)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0084 (100)  rf=r size=256 type=q align=32 words (r13.0)
//.declare V0085 (101)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0089 (105)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0090 (106)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0091 (107)  rf=r size=128 type=ud alias=V0090+0 align=32 words (r13.0)
//.declare V0095 (111)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0096 (112)  rf=r size=128 type=d align=32 words (r13.0)
//.declare P07 (113)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0100 (117)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare P08 (118)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0104 (122)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0106 (124)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0107 (125)  rf=r size=128 type=w alias=V0106+0 align=32 words (r14.0)
//.declare V0109 (127)  rf=r size=128 type=d alias=V0085+0 align=32 words (r24.0)
//.declare P09 (128)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P10 (129)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P11 (130)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0110 (131)  rf=r size=4 type=ud alias=V0048+0 align=2 words (r3.8)
//.declare P12 (132)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0114 (136)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0115 (137)  rf=r size=256 type=q align=32 words (r11.0)
//.declare V0116 (138)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0120 (142)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0121 (143)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0122 (144)  rf=r size=128 type=ud alias=V0121+0 align=32 words (r11.0)
//.declare V0126 (148)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0127 (149)  rf=r size=128 type=d align=32 words (r11.0)
//.declare P13 (150)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0131 (154)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare P14 (155)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0135 (159)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0137 (161)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare V0138 (162)  rf=r size=128 type=w alias=V0137+0 align=32 words (r12.0)
//.declare V0140 (164)  rf=r size=128 type=d alias=V0116+0 align=32 words (r26.0)
//.declare P15 (165)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P16 (166)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P17 (167)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0141 (168)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r3.14)
//.declare P18 (169)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0145 (173)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0146 (174)  rf=r size=256 type=q align=32 words (r11.0)
//.declare V0147 (175)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0151 (179)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0152 (180)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0153 (181)  rf=r size=128 type=ud alias=V0152+0 align=32 words (r11.0)
//.declare V0157 (185)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0158 (186)  rf=r size=128 type=d align=32 words (r11.0)
//.declare P19 (187)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0162 (191)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare P20 (192)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0166 (196)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0168 (198)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare V0169 (199)  rf=r size=128 type=w alias=V0168+0 align=32 words (r12.0)
//.declare V0171 (201)  rf=r size=128 type=d alias=V0147+0 align=32 words (r28.0)
//.declare V0172 (202)  rf=r size=128 type=f align=32 words (r41.0)
//.declare V0173 (203)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0174 (204)  rf=r size=128 type=d alias=V0172+0 align=32 words (r41.0)
//.declare P21 (205)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0175 (206)  rf=r size=128 type=ud alias=V0173+0 align=32 words (r1.0)
//.declare V0176 (207)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0177 (208)  rf=r size=128 type=ud alias=V0172+0 align=32 words (r41.0)
//.declare V0178 (209)  rf=r size=128 type=ud alias=V0176+0 align=32 words (r1.0)
//.declare V0179 (210)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0180 (211)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0181 (212)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0184 (215)  rf=r size=128 type=f align=32 words (r33.0)
//.declare V0185 (216)  rf=r size=128 type=f alias=V0181+0 align=32 words (r30.0)
//.declare P22 (217)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P23 (218)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P24 (219)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0186 (220)  rf=r size=4 type=ud alias=V0054+0 align=2 words (r4.4)
//.declare P25 (221)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0190 (225)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0192 (227)  rf=r size=256 type=d align=32 words (r19.0)
//.declare V0194 (229)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0195 (230)  rf=r size=128 type=ud alias=V0194+0 align=32 words (r1.0)
//.declare V0199 (234)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0200 (235)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0204 (239)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare P26 (240)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0208 (244)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare P27 (245)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0209 (246)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0210 (247)  rf=r size=128 type=d alias=V0184+0 align=32 words (r33.0)
//.declare P28 (248)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0211 (249)  rf=r size=128 type=ud alias=V0209+0 align=32 words (r1.0)
//.declare V0212 (250)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0213 (251)  rf=r size=128 type=ud alias=V0184+0 align=32 words (r33.0)
//.declare V0214 (252)  rf=r size=128 type=ud alias=V0212+0 align=32 words (r1.0)
//.declare V0215 (253)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0216 (254)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0217 (255)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0218 (256)  rf=r size=128 type=ud alias=V0216+0 align=32 words (r8.0)
//.declare V0219 (257)  rf=r size=128 type=ud alias=V0217+0 align=32 words (r10.0)
//.declare V0220 (258)  rf=r size=64 type=w align=32 words (r32.0)
//.declare V0221 (259)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0222 (260)  rf=r size=128 type=ud alias=V0221+0 align=32 words (r1.0)
//.declare V0227 (265)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0228 (266)  rf=r size=64 type=uw alias=V0220+0 align=32 words (r32.0)
//.declare V0229 (267)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (268)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (269)  rf=r size=128 type=w alias=V0221+0 align=32 words (r1.0)
//.declare  (270)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (271)  rf=r size=128 type=ud align=32 words (r9.0)
//.declare  (272)  rf=r size=128 type=f align=32 words (r17.0)
//.declare  (273)  rf=r size=128 type=f align=32 words (r19.0)
//.declare  (274)  rf=r size=128 type=f align=32 words (r15.0)
//.declare  (275)  rf=r size=128 type=f align=32 words (r17.0)
//.declare  (276)  rf=r size=128 type=f align=32 words (r15.0)
//.declare  (277)  rf=r size=128 type=f align=32 words (r17.0)
//.declare  (278)  rf=r size=4 type=d align=2 words (r1.0)
//.declare  (279)  rf=r size=4 type=d align=32 words (r2.0)
//.declare  (280)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (281)  rf=r size=128 type=ud align=32 words (r15.0)
//.declare  (282)  rf=r size=128 type=w alias=V0217+0 align=32 words (r10.0)
//.declare  (283)  rf=r size=128 type=q align=32 words (r35.0)
//.declare  (284)  rf=r size=128 type=q align=32 words (r37.0)
//.declare  (285)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (286)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (289)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (290)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (293)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (294)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (297)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (298)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (301)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (302)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (305)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (306)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (309)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (310)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (313)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (314)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (317)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (318)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (321)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (322)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (325)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (326)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (329)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (330)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (333)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (334)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (337)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (338)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (341)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (342)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (345)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (346)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (349)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (350)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (351)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (352)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (355)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (356)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (359)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (360)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (363)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (364)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (367)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare  (368)  rf=r size=128 type=d alias=+0 align=32 words (r17.0)
//.declare r0 (369)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (370)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (371)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (372)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (373)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (374)  rf=r size=128 type=ud align=32 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0037    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0048    | :d       |    0x4 | r3+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0050    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0051    | :d       |    0x4 | r3+0x38  | cti+0x58         |
// | V0052    | :q       |    0x8 | r4       | cti+0x60         |
// | V0053    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0054    | :d       |    0x4 | r4+0x10  | cti+0x70         |
// | V0055    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0056    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0057    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0058    | :d       |    0x4 | r4+0x30  | cti+0x90         |
// | V0059    | :d       |    0x4 | r4+0x34  | cti+0x94         |
// | V0041    | :uq      |    0x8 | r4+0x38  | cti+0x98         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B060}
// _main:
(W)     mov (16|M0)              r23.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r6.0<1>:uq    r4.5<0;1,0>:uq                   {Compacted,A@1,$1.dst} //  ALU pipe: int; $2
(W)     load.ugm.d32x1t.a64 (1|M0)  r7:1        [r6:1]             {I@1,$2} // ex_desc:0x0; desc:0x2108580 // $3
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r7.0<0;1,0>:d     0:w               {$2.dst}          //  ALU pipe: int; $4
(W&f3.0) jmpi                                _0_067                                                  //  ALU pipe: int; $5
// B003: Preds:{B002},  Succs:{B004, B060}
_0_068:
(W)     mov (1|M0)               r6.0<1>:uq    r4.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $7
        mov (32|M0)              r11.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $10
        mov (16|M0)              r7.0<2>:f     r6.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $8
        mov (16|M16)             r9.0<2>:f     r6.0<0;1,0>:f                                         //  ALU pipe: float; $8
        mov (16|M0)              r7.1<2>:f     r6.1<0;1,0>:f                                         //  ALU pipe: float; $9
        mov (16|M16)             r9.1<2>:ud    r6.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $9
        atomic_or.ugm.d32.a64 (32|M0)  r13:2    [r7:4]            r11:2              {A@1,$3} // ex_desc:0x0; desc:0x8200599 // $11
        cmp (32|M0)   (eq)f2.0   null<1>:d     r13.0<1;1,0>:d    0:w               {$3.dst}          //  ALU pipe: int; $13
(~f2.0) goto (32|M0)                         _0_067            _0_067                                //  ALU pipe: int; $14
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B012}
_0_069:
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r23.2<0;1,0>:uw                     //  ALU pipe: int; $16
(W)     macl (1|M0)              r3.0<1>:d     r2.3<0;1,0>:d     r23.1<0;1,0>:d   {Compacted}        //  ALU pipe: int; $18
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $20
        add3 (32|M0)             r5.0<1>:d     r3.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {@2,$0.dst} //  ALU pipe: int; $18
        mov (16|M0)              r7.0<2>:ud    r5.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $19
        mov (16|M16)             r9.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $19
        mov (16|M0)              r35.0<1>:q    r7.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $19
        mov (16|M16)             r37.0<1>:q    r9.0<2;1,0>:ud                   {I@2}                //  ALU pipe: int; $19
(W&f1.0) jmpi                                _0_070                                                  //  ALU pipe: int; $21
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B011}
_0_071:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.2<0;1,0>:d     2:w                                 //  ALU pipe: int; $23
(W&f0.0) jmpi                                _0_072                                                  //  ALU pipe: int; $24
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B010}
_0_073:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r3.2<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $26
(W&f3.0) jmpi                                _0_074                                                  //  ALU pipe: int; $27
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B009}
_0_075:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.2<0;1,0>:d     4:w                                 //  ALU pipe: int; $29
(W&~f2.0) jmpi                               _0_076                                                  //  ALU pipe: int; $30
// B008: [inDivergent],  Preds:{B007},  Succs:{B017}
_0_077:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    3:w               {Compacted,I@7}   //  ALU pipe: int; $32
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    3:w               {Compacted,I@7}   //  ALU pipe: int; $32
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $33
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $33
        load.ugm.d64.a64 (32|M0)  r13:4         [r9:4]             {I@1,$4} // ex_desc:0x0; desc:0x8400780 // $35
        mov (16|M0)              r17.0<2>:f    r13.0<1;1,0>:q                   {$4.dst}             //  ALU pipe: float; $36
        mov (16|M16)             r19.0<2>:f    r15.0<1;1,0>:q                                        //  ALU pipe: float; $36
        mov (16|M0)              r24.0<1>:ud   r17.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $36
        mov (16|M16)             r25.0<1>:ud   r19.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $36
(W)     jmpi                                 _0_078                                                  // $37
// B009: [inDivergent],  Preds:{B007},  Succs:{B017}
_0_076:
        mov (32|M0)              r24.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $39
(W)     jmpi                                 _0_078                                                  // $40
// B010: [inDivergent],  Preds:{B006},  Succs:{B017}
_0_074:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $42
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $42
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $43
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $43
        load.ugm.d32.a64 (32|M0)  r13:2         [r9:4]             {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $45
        mov (32|M0)              r24.0<1>:f    r13.0<1;1,0>:ud                  {$5.dst}             //  ALU pipe: float; $46
(W)     jmpi                                 _0_078                                                  // $47
// B011: [inDivergent],  Preds:{B005},  Succs:{B017}
_0_072:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $49
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $49
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $50
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $50
        load.ugm.d32.a64 (32|M0)  r13:2         [r9:4]             {A@1,$6} // ex_desc:0x0; desc:0x8200580 // $52
        mov (32|M0)              r24.0<1>:f    r13.0<1;1,0>:d                   {$6.dst}             //  ALU pipe: float; $53
(W)     jmpi                                 _0_078                                                  // $54
// B012: [inDivergent],  Preds:{B004},  Succs:{B013, B014}
_0_070:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.2<0;1,0>:d     1:w                                 //  ALU pipe: int; $56
(W&f1.0) jmpi                                _0_079                                                  //  ALU pipe: int; $57
// B013: [inDivergent],  Preds:{B012},  Succs:{B017}
_0_080:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $59
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $59
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $60
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $60
        load.ugm.d32.a64 (32|M0)  r24:2         [r9:4]             {A@1,$7} // ex_desc:0x0; desc:0x8200580 // $62
(W)     jmpi                                 _0_078                                                  // $63
// B014: [inDivergent],  Preds:{B012},  Succs:{B015, B016}
_0_079:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $65
(W&~f0.0) jmpi                               _0_081                                                  //  ALU pipe: int; $66
// B015: [inDivergent],  Preds:{B014},  Succs:{B017}
_0_082:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $68
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $68
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $69
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $69
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r9:4]             {I@1,$8} // ex_desc:0x0; desc:0x8200B80 // $71
        shl (32|M0)              r24.0<1>:d    r14.0<1;1,0>:ud   16:w               {$8.dst}         //  ALU pipe: int; $72
(W)     jmpi                                 _0_078                                                  // $73
// B016: [inDivergent],  Preds:{B014},  Succs:{B017}
_0_081:
        mov (32|M0)              r24.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $75
// B017: [inDivergent],  Preds:{B016, B015, B013, B011, B010, B009, B008},  Succs:{B018, B025}
_0_078:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.8<0;1,0>:d     2:w                                 //  ALU pipe: int; $77
(W&f3.0) jmpi                                _0_083                                                  //  ALU pipe: int; $78
// B018: [inDivergent],  Preds:{B017},  Succs:{B019, B024}
_0_084:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.8<0;1,0>:d     2:w                                 //  ALU pipe: int; $80
(W&f2.0) jmpi                                _0_085                                                  //  ALU pipe: int; $81
// B019: [inDivergent],  Preds:{B018},  Succs:{B020, B023}
_0_086:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r3.8<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $83
(W&f1.0) jmpi                                _0_087                                                  //  ALU pipe: int; $84
// B020: [inDivergent],  Preds:{B019},  Succs:{B021, B022}
_0_088:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.8<0;1,0>:d     4:w                                 //  ALU pipe: int; $86
(W&~f0.0) jmpi                               _0_089                                                  //  ALU pipe: int; $87
// B021: [inDivergent],  Preds:{B020},  Succs:{B030}
_0_090:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $89
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $89
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $90
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $90
        load.ugm.d64.a64 (32|M0)  r11:4         [r7:4]             {I@1,$9} // ex_desc:0x0; desc:0x8400780 // $92
        mov (16|M0)              r15.0<2>:f    r11.0<1;1,0>:q                   {$9.dst}             //  ALU pipe: float; $93
        mov (16|M16)             r17.0<2>:f    r13.0<1;1,0>:q                                        //  ALU pipe: float; $93
        mov (16|M0)              r26.0<1>:ud   r15.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $93
        mov (16|M16)             r27.0<1>:ud   r17.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $93
(W)     jmpi                                 _0_091                                                  // $94
// B022: [inDivergent],  Preds:{B020},  Succs:{B030}
_0_089:
        mov (32|M0)              r26.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $96
(W)     jmpi                                 _0_091                                                  // $97
// B023: [inDivergent],  Preds:{B019},  Succs:{B030}
_0_087:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $99
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $99
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $100
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $100
        load.ugm.d32.a64 (32|M0)  r11:2         [r7:4]             {I@1,$10} // ex_desc:0x0; desc:0x8200580 // $102
        mov (32|M0)              r26.0<1>:f    r11.0<1;1,0>:ud                  {$10.dst}            //  ALU pipe: float; $103
(W)     jmpi                                 _0_091                                                  // $104
// B024: [inDivergent],  Preds:{B018},  Succs:{B030}
_0_085:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $106
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $106
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $107
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $107
        load.ugm.d32.a64 (32|M0)  r11:2         [r7:4]             {A@1,$11} // ex_desc:0x0; desc:0x8200580 // $109
        mov (32|M0)              r26.0<1>:f    r11.0<1;1,0>:d                   {$11.dst}            //  ALU pipe: float; $110
(W)     jmpi                                 _0_091                                                  // $111
// B025: [inDivergent],  Preds:{B017},  Succs:{B026, B027}
_0_083:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.8<0;1,0>:d     1:w                                 //  ALU pipe: int; $113
(W&f3.0) jmpi                                _0_092                                                  //  ALU pipe: int; $114
// B026: [inDivergent],  Preds:{B025},  Succs:{B030}
_0_093:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $116
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $116
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $117
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $117
        load.ugm.d32.a64 (32|M0)  r26:2         [r7:4]             {A@1,$12} // ex_desc:0x0; desc:0x8200580 // $119
(W)     jmpi                                 _0_091                                                  // $120
// B027: [inDivergent],  Preds:{B025},  Succs:{B028, B029}
_0_092:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.8<0;1,0>:d     0:w                                 //  ALU pipe: int; $122
(W&~f2.0) jmpi                               _0_094                                                  //  ALU pipe: int; $123
// B028: [inDivergent],  Preds:{B027},  Succs:{B030}
_0_095:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $125
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $125
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $126
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.2<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $126
        load.ugm.d16u32.a64 (32|M0)  r12:2      [r7:4]             {I@1,$13} // ex_desc:0x0; desc:0x8200B80 // $128
        shl (32|M0)              r26.0<1>:d    r12.0<1;1,0>:ud   16:w               {$13.dst}        //  ALU pipe: int; $129
(W)     jmpi                                 _0_091                                                  // $130
// B029: [inDivergent],  Preds:{B027},  Succs:{B030}
_0_094:
        mov (32|M0)              r26.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $132
// B030: [inDivergent],  Preds:{B029, B028, B026, B024, B023, B022, B021},  Succs:{B031, B038}
_0_091:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.14<0;1,0>:d    2:w                                 //  ALU pipe: int; $134
(W&f1.0) jmpi                                _0_096                                                  //  ALU pipe: int; $135
// B031: [inDivergent],  Preds:{B030},  Succs:{B032, B037}
_0_097:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.14<0;1,0>:d    2:w                                 //  ALU pipe: int; $137
(W&f0.0) jmpi                                _0_098                                                  //  ALU pipe: int; $138
// B032: [inDivergent],  Preds:{B031},  Succs:{B033, B036}
_0_099:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:ud    r3.14<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $140
(W&f3.0) jmpi                                _0_100                                                  //  ALU pipe: int; $141
// B033: [inDivergent],  Preds:{B032},  Succs:{B034, B035}
_0_101:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.14<0;1,0>:d    4:w                                 //  ALU pipe: int; $143
(W&~f2.0) jmpi                               _0_102                                                  //  ALU pipe: int; $144
// B034: [inDivergent],  Preds:{B033},  Succs:{B043}
_0_103:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $146
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $146
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $147
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $147
        load.ugm.d64.a64 (32|M0)  r11:4         [r7:4]             {I@1,$14} // ex_desc:0x0; desc:0x8400780 // $149
        mov (16|M0)              r15.0<2>:f    r11.0<1;1,0>:q                   {$14.dst}            //  ALU pipe: float; $150
        mov (16|M16)             r17.0<2>:f    r13.0<1;1,0>:q                                        //  ALU pipe: float; $150
        mov (16|M0)              r28.0<1>:ud   r15.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $150
        mov (16|M16)             r29.0<1>:ud   r17.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $150
(W)     jmpi                                 _0_104                                                  // $151
// B035: [inDivergent],  Preds:{B033},  Succs:{B043}
_0_102:
        mov (32|M0)              r28.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $153
(W)     jmpi                                 _0_104                                                  // $154
// B036: [inDivergent],  Preds:{B032},  Succs:{B043}
_0_100:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $156
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $156
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $157
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $157
        load.ugm.d32.a64 (32|M0)  r11:2         [r7:4]             {I@1,$15} // ex_desc:0x0; desc:0x8200580 // $159
        mov (32|M0)              r28.0<1>:f    r11.0<1;1,0>:ud                  {$15.dst}            //  ALU pipe: float; $160
(W)     jmpi                                 _0_104                                                  // $161
// B037: [inDivergent],  Preds:{B031},  Succs:{B043}
_0_098:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $163
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $163
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $164
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $164
        load.ugm.d32.a64 (32|M0)  r11:2         [r7:4]             {A@1,$0} // ex_desc:0x0; desc:0x8200580 // $166
        mov (32|M0)              r28.0<1>:f    r11.0<1;1,0>:d                   {$0.dst}             //  ALU pipe: float; $167
(W)     jmpi                                 _0_104                                                  // $168
// B038: [inDivergent],  Preds:{B030},  Succs:{B039, B040}
_0_096:
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.14<0;1,0>:d    1:w                                 //  ALU pipe: int; $170
(W&f1.0) jmpi                                _0_105                                                  //  ALU pipe: int; $171
// B039: [inDivergent],  Preds:{B038},  Succs:{B043}
_0_106:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $173
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $173
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $174
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $174
        load.ugm.d32.a64 (32|M0)  r28:2         [r7:4]             {A@1,$1} // ex_desc:0x0; desc:0x8200580 // $176
(W)     jmpi                                 _0_104                                                  // $177
// B040: [inDivergent],  Preds:{B038},  Succs:{B041, B042}
_0_105:
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $179
(W&~f0.0) jmpi                               _0_107                                                  //  ALU pipe: int; $180
// B041: [inDivergent],  Preds:{B040},  Succs:{B043}
_0_108:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $182
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $182
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$12.src} //  ALU pipe: int; $183
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,@2,$7.src} //  ALU pipe: int; $183
        load.ugm.d16u32.a64 (32|M0)  r12:2      [r7:4]             {I@1,$2} // ex_desc:0x0; desc:0x8200B80 // $185
        shl (32|M0)              r28.0<1>:d    r12.0<1;1,0>:ud   16:w               {$2.dst}         //  ALU pipe: int; $186
(W)     jmpi                                 _0_104                                                  // $187
// B042: [inDivergent],  Preds:{B040},  Succs:{B043}
_0_107:
        mov (32|M0)              r28.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $189
// B043: [inDivergent],  Preds:{B042, B041, B039, B037, B036, B035, B034},  Succs:{B044, B045}
_0_104:
        sync.nop                             null                             {Compacted,I@1}        // $191
        sync.nop                             null                             {Compacted,$1.dst}     // $191
        add (32|M0)              r41.0<1>:f    r26.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,$12.dst} //  ALU pipe: float; $191
        and (32|M0)              r1.0<1>:d     r41.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $192
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $193
(f3.0)  goto (32|M0)                         _0_109            _0_109                                //  ALU pipe: int; $194
// B044: [inDivergent],  Preds:{B043},  Succs:{B046}
_0_110:
        shr (32|M0)              r1.0<1>:ud    r41.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $196
        and (32|M0)              r6.0<1>:d     r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $197
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r41.0<1;0>:d      32767:w               {@1,$7.src} //  ALU pipe: int; $198
        and (32|M0)              r30.0<1>:d    r8.0<1;1,0>:d     -65536:d               {I@1}        //  ALU pipe: int; $199
        goto (32|M0)                         _0_109            _0_111                                // $200
// B045: [inDivergent],  Preds:{B043},  Succs:{B046}
_0_109:
        join (32|M0)                         _0_111                                                  // 
L2552:
(W)     mov (1|M0)               r1.0<1>:f     0xFFBF0000:f                                          //  (0xffbf0000:f); ALU pipe: float; $204
(W)     mov (1|M0)               r2.0<1>:f     0x400000:f                               {Compacted}  //  (0x00400000:f); ALU pipe: float; $204
        bfn.(s0&s1|s2) (32|M0)   r30.0<1>:ud   r41.0<1;0>:ud     r1.0<0;0>:d       r2.0<0>:d        {F@1} //  ALU pipe: int; $204
// B046: [inDivergent],  Preds:{B045, B044},  Succs:{B047, B053}
_0_111:
        join (32|M0)                         _0_067                                                  // 
L2608:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $207
        sync.nop                             null                             {Compacted,I@3}        // $206
        add (32|M0)              r33.0<1>:f    r24.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,$7.dst} //  ALU pipe: float; $206
(W&f2.0) jmpi                                _0_112                                                  //  ALU pipe: int; $208
// B047: [inDivergent],  Preds:{B046},  Succs:{B048, B052}
_0_113:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.4<0;1,0>:d     2:w                                 //  ALU pipe: int; $210
(W&f1.0) jmpi                                _0_114                                                  //  ALU pipe: int; $211
// B048: [inDivergent],  Preds:{B047},  Succs:{B049, B051}
_0_115:
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r4.4<0;1,0>:ud    0x4:uw                              //  ALU pipe: int; $213
(W&f0.0) jmpi                                _0_116                                                  //  ALU pipe: int; $214
// B049: [inDivergent],  Preds:{B048},  Succs:{B050, B060}
_0_117:
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r4.4<0;1,0>:d     4:w                                 //  ALU pipe: int; $216
(~f3.0) goto (32|M0)                         _0_067            _0_067                                //  ALU pipe: int; $217
// B050: [inDivergent],  Preds:{B049},  Succs:{B060}
_0_118:
        mov (16|M0)              r11.0<2>:ud   r33.0<1;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $222
        mov (16|M16)             r15.0<2>:ud   r34.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $222
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $219
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    3:w               {Compacted}       //  ALU pipe: int; $219
        mov (16|M0)              r13.0<1>:q    r11.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $222
        mov (16|M16)             r17.0<1>:q    r15.0<2;1,0>:f                   {I@4}                //  ALU pipe: int; $222
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $220
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $220
        mov (16|M0)              r19.0<1>:d    r13.0<2;1,0>:d                   {Compacted,I@4}      //  ALU pipe: int; $223
        mov (16|M0)              r21.0<1>:d    r13.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $225
        mov (16|M16)             r20.0<1>:d    r17.0<2;1,0>:d                   {Compacted,I@5}      //  ALU pipe: int; $224
        mov (16|M16)             r22.0<1>:d    r17.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $226
        store.ugm.d32x2.a64 (32|M0)  [r7:4]     r19:4              {I@1,$3} // ex_desc:0x0; desc:0x8001584 // $227
        goto (32|M0)                         _0_067            _0_067                                // $228
// B051: [inDivergent],  Preds:{B048},  Succs:{B060}
_0_116:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $231
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted,$3.src} //  ALU pipe: int; $231
        mov (32|M0)              r1.0<1>:ud    r33.0<1;1,0>:f                                        //  ALU pipe: int; $230
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $232
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $232
        store.ugm.d32.a64 (32|M0)  [r9:4]       r1:2               {I@1,$4} // ex_desc:0x0; desc:0x8000584 // $234
        goto (32|M0)                         _0_067            _0_067                                // $235
// B052: [inDivergent],  Preds:{B047},  Succs:{B060}
_0_114:
        shl (16|M0)              r5.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $238
        shl (16|M16)             r7.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $238
        mov (32|M0)              r1.0<1>:d     r33.0<1;1,0>:f                   {$4.src}             //  ALU pipe: int; $237
        add (16|M0)              r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $239
        add (16|M16)             r11.0<1>:q    r7.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $239
        store.ugm.d32.a64 (32|M0)  [r9:4]       r1:2               {I@1,$5} // ex_desc:0x0; desc:0x8000584 // $241
        goto (32|M0)                         _0_067            _0_067                                // $242
// B053: [inDivergent],  Preds:{B046},  Succs:{B054, B055}
_0_112:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r4.4<0;1,0>:d     1:w                                 //  ALU pipe: int; $244
(W&f2.0) jmpi                                _0_119                                                  //  ALU pipe: int; $245
// B054: [inDivergent],  Preds:{B053},  Succs:{B060}
_0_120:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    2:w               {Compacted,$5.src} //  ALU pipe: int; $247
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $247
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $248
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $248
        store.ugm.d32.a64 (32|M0)  [r7:4]       r33:2              {I@1,$6} // ex_desc:0x0; desc:0x8000584 // $250
        goto (32|M0)                         _0_067            _0_067                                // $251
// B055: [inDivergent],  Preds:{B053},  Succs:{B056, B060}
_0_119:
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r4.4<0;1,0>:d     0:w                                 //  ALU pipe: int; $253
(~f1.0) goto (32|M0)                         _0_067            _0_067                                //  ALU pipe: int; $254
// B056: [inDivergent],  Preds:{B055},  Succs:{B057, B058}
_0_121:
        and (32|M0)              r1.0<1>:d     r33.0<1;1,0>:d    2147483647:d               {$5.src} //  ALU pipe: int; $256
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $257
(f0.0)  goto (32|M0)                         _0_122            _0_122                                //  ALU pipe: int; $258
// B057: [inDivergent],  Preds:{B056},  Succs:{B059}
_0_123:
        shr (32|M0)              r1.0<1>:ud    r33.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $260
        and (32|M0)              r6.0<1>:d     r1.0<1;1,0>:d     1:w               {Compacted,@1,$6.src} //  ALU pipe: int; $261
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r33.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $262
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $263
        mov (32|M0)              r32.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $264
        goto (32|M0)                         _0_122            _0_124                                // $265
// B058: [inDivergent],  Preds:{B056},  Succs:{B059}
_0_122:
        join (32|M0)                         _0_124                                                  // 
L3336:
        shr (32|M0)              r1.0<1>:ud    r33.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $267
        or (32|M0)               r32.0<1>:w    r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $269
// B059: [inDivergent],  Preds:{B058, B057},  Succs:{B060}
_0_124:
        join (32|M0)                         _0_067                                                  // 
L3384:
        shl (16|M0)              r1.0<1>:q     r35.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $271
        shl (16|M16)             r5.0<1>:q     r37.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $271
        mov (32|M0)              r11.0<1>:ud   r32.0<1;1,0>:uw                  {I@4}                //  ALU pipe: int; $274
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,@3,$6.src} //  ALU pipe: int; $272
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r4.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $272
        store.ugm.d16u32.a64 (32|M0)  [r7:4]    r11:2              {I@1,$7} // ex_desc:0x0; desc:0x8000B84 // $275
// B060: Preds:{B059, B055, B054, B052, B051, B050, B049, B003, B002},  Succs:{}
_0_067:
        join (32|M0)                         L3464                                                   // 
L3464:
(W)     mov (16|M0)              r127.0<1>:f   r23.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $277
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$8} // wr:1+0, rd:0; end of thread // $277
L3488:
(W)     mov (16|M0)              null<1>:ud    0x3C6AF85D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x8ACC7179:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x16:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 197
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 38
//.allAtOneDistNum: 10
//.syncInstCount: 3
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 19
//.AfterReadTokenDepCount: 23
