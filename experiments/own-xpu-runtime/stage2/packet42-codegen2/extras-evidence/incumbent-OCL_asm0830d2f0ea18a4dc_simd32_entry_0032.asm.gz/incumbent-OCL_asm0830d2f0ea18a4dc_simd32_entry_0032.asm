//.kernel _ZTSZZNK11specialised6KernelILN2ng2OpE2ELi1ELi0ELi0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_2idILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 137417456 3927483612 -hashmovs1 0 32 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 137417456 3927483612 -hashmovs1 0 32 -GRFBumpUpNumber 2 "
//.instCount 382
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.private memory size 65664

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r46.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r46.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r46.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0072 (82)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0074 (84)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0075 (85)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0076 (86)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0077 (87)  rf=r size=4 type=d align=2 words (r2.8)
//.declare P01 (88)  rf=f1  size=2 type=uw align=1 words (f2.0)
//.declare V0078 (89)  rf=r size=2 type=w align=1 words (r4.2)
//.declare V0079 (90)  rf=r size=2 type=b align=1 words (r5.0)
//.declare V0080 (91)  rf=r size=4 type=d align=2 words (r6.0)
//.declare V0081 (92)  rf=r size=2 type=ub alias=V0079+0 align=1 words (r5.0)
//.declare V0082 (93)  rf=r size=4 type=d align=2 words (r32.4)
//.declare V0083 (94)  rf=r size=4 type=d align=2 words (r32.3)
//.declare V0084 (95)  rf=r size=4 type=d align=2 words (r7.0)
//.declare V0085 (96)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0086 (97)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0087 (98)  rf=r size=4 type=ud alias=V0085+0 align=2 words (r3.0)
//.declare V0088 (99)  rf=r size=4 type=ud alias=V0076+0 align=2 words (r4.0)
//.declare V0089 (100)  rf=r size=4 type=ud alias=V0083+0 align=2 words (r32.3)
//.declare V0090 (101)  rf=r size=4 type=d align=32 words (r8.0)
//.declare V0092 (103)  rf=r size=4 type=d align=32 words (r9.0)
//.declare P02 (104)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0093 (105)  rf=r size=128 type=ud alias=V0075+0 align=32 words (r30.0)
//.declare P03 (106)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P04 (107)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0094 (108)  rf=r size=4 type=ud alias=V0086+0 align=2 words (r3.4)
//.declare V0095 (109)  rf=r size=8 type=uq alias=V0069+0 align=32 words (r5.6)
//.declare V0096 (110)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0097 (111)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P05 (112)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0098 (113)  rf=r size=8 type=uq alias=V0066+0 align=32 words (r5.3)
//.declare V0099 (114)  rf=r size=8 type=uq align=32 words (r32.0)
//.declare V0101 (116)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0102 (117)  rf=r size=256 type=ud alias=V0101+0 align=32 words (r6.0)
//.declare V0103 (118)  rf=r size=8 type=ud alias=V0099+0 align=32 words (r32.0)
//.declare V0104 (119)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0105 (120)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P06 (122)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0107 (123)  rf=r size=8 type=uq alias=V0068+0 align=32 words (r5.5)
//.declare V0108 (124)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0109 (125)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0110 (126)  rf=r size=4 type=d align=2 words (r2.8)
//.declare P07 (127)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P08 (128)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0111 (129)  rf=r size=64 type=w align=32 words (r127.0)
//.declare P09 (130)  rf=f1  size=2 type=uw align=1 words (f1.0)
//.declare V0112 (131)  rf=r size=2 type=w align=1 words (r3.0)
//.declare V0113 (132)  rf=r size=2 type=b align=1 words (r4.0)
//.declare V0114 (133)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0115 (134)  rf=r size=2 type=ub alias=V0113+0 align=1 words (r4.0)
//.declare V0116 (135)  rf=r size=4 type=d align=2 words (r6.0)
//.declare V0117 (136)  rf=r size=4 type=d align=2 words (r32.2)
//.declare P10 (137)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0118 (138)  rf=r size=4 type=ud alias=V0082+0 align=2 words (r32.4)
//.declare V0119 (139)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0120 (140)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0121 (141)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0122 (142)  rf=r size=128 type=ud alias=V0121+0 align=32 words (r6.0)
//.declare V0123 (143)  rf=r size=4 type=d align=2 words (r2.9)
//.declare V0124 (144)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0125 (145)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0126 (146)  rf=r size=4 type=ud alias=V0124+0 align=2 words (r3.0)
//.declare V0127 (147)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0128 (148)  rf=r size=4 type=ud alias=V0127+0 align=2 words (r3.4)
//.declare V0129 (149)  rf=r size=4 type=d align=2 words (r4.1)
//.declare V0130 (150)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0131 (151)  rf=r size=4 type=f align=2 words (r4.2)
//.declare V0132 (152)  rf=r size=4 type=f align=2 words (r10.0)
//.declare V0133 (153)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0134 (154)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0135 (155)  rf=r size=128 type=ud alias=V0134+0 align=32 words (r14.0)
//.declare V0136 (156)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0137 (157)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0138 (158)  rf=r size=128 type=ud alias=V0137+0 align=32 words (r18.0)
//.declare V0139 (159)  rf=r size=4 type=f align=2 words (r2.9)
//.declare V0140 (160)  rf=r size=4 type=ud alias=V0129+0 align=2 words (r4.1)
//.declare V0141 (161)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0142 (162)  rf=r size=128 type=ud alias=V0136+0 align=32 words (r16.0)
//.declare V0143 (163)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0149 (169)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0150 (170)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0151 (171)  rf=r size=128 type=ud alias=V0150+0 align=32 words (r26.0)
//.declare V0152 (172)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0153 (173)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0154 (174)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0155 (175)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0156 (176)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0157 (177)  rf=r size=128 type=ud alias=V0155+0 align=32 words (r8.0)
//.declare V0158 (178)  rf=r size=128 type=ud alias=V0156+0 align=32 words (r16.0)
//.declare  (179)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0159 (180)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0160 (181)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0161 (182)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0162 (183)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0163 (184)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0164 (185)  rf=r size=64 type=uw alias=V0111+0 align=32 words (r127.0)
//.declare V0165 (186)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0166 (187)  rf=r size=128 type=d align=32 words (r96.0)
//.declare P11 (188)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0167 (189)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0168 (190)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.3)
//.declare V0172 (194)  rf=r size=4 type=d align=2 words (r32.3)
//.declare V0174 (196)  rf=r size=4 type=ud alias=V0172+0 align=2 words (r32.3)
//.declare V0175 (197)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0176 (198)  rf=r size=256 type=q align=32 words (r6.0)
//.declare V0177 (199)  rf=r size=256 type=uq alias=V0176+0 align=32 words (r6.0)
//.declare V0178 (200)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0179 (201)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0180 (202)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0181 (203)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r12.0)
//.declare  (205)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare P12 (206)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P13 (207)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0183 (208)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0184 (209)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0185 (210)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0186 (211)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0187 (212)  rf=r size=128 type=d align=32 words (r94.0)
//.declare V0188 (213)  rf=r size=128 type=ud alias=V0187+0 align=32 words (r94.0)
//.declare V0189 (214)  rf=r size=128 type=f align=32 words (r98.0)
//.declare  (216)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0191 (217)  rf=r size=4 type=d align=2 words (r3.1)
//.declare P14 (218)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0192 (219)  rf=r size=128 type=f align=32 words (r92.0)
//.declare V0193 (220)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0194 (221)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0195 (222)  rf=r size=128 type=ud alias=V0194+0 align=32 words (r6.0)
//.declare  (224)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0197 (225)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (227)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare P15 (228)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P16 (229)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0199 (230)  rf=r size=128 type=ud alias=V0166+0 align=32 words (r96.0)
//.declare V0200 (231)  rf=r size=128 type=f align=32 words (r114.0)
//.declare  (233)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0202 (234)  rf=r size=4 type=f align=2 words (r2.8)
//.declare  (236)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (237)  rf=r size=128 type=f align=32 words (r90.0)
//.declare  (238)  rf=r size=128 type=f align=32 words (r88.0)
//.declare  (239)  rf=r size=128 type=f align=32 words (r86.0)
//.declare  (240)  rf=r size=128 type=f align=32 words (r84.0)
//.declare  (241)  rf=r size=128 type=f align=32 words (r82.0)
//.declare  (242)  rf=r size=128 type=f align=32 words (r80.0)
//.declare  (243)  rf=r size=128 type=f align=32 words (r78.0)
//.declare  (244)  rf=r size=64 type=f align=32 words (r122.0)
//.declare  (245)  rf=r size=64 type=f align=32 words (r42.0)
//.declare V0204 (248)  rf=r size=128 type=f align=32 words (r116.0)
//.declare V0205 (249)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0206 (250)  rf=r size=128 type=ud alias=V0205+0 align=32 words (r4.0)
//.declare V0207 (251)  rf=r size=128 type=f align=32 words (r6.0)
//.declare  (252)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (253)  rf=r size=128 type=f align=32 words (r76.0)
//.declare  (254)  rf=r size=128 type=f align=32 words (r74.0)
//.declare  (255)  rf=r size=128 type=f align=32 words (r72.0)
//.declare  (256)  rf=r size=128 type=f align=32 words (r70.0)
//.declare  (257)  rf=r size=128 type=f align=32 words (r68.0)
//.declare  (258)  rf=r size=64 type=f align=32 words (r33.0)
//.declare V0208 (261)  rf=r size=128 type=d alias=V0207+0 align=32 words (r6.0)
//.declare  (263)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0210 (264)  rf=r size=128 type=d align=32 words (r40.0)
//.declare  (266)  rf=a size=4 type=ud align=4 words (a0.0)
//.declare V0212 (267)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0213 (268)  rf=r size=128 type=d align=32 words (r38.0)
//.declare P17 (269)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P18 (270)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0214 (271)  rf=r size=128 type=d align=32 words (r120.0)
//.declare V0215 (272)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0216 (273)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0217 (274)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0218 (275)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0219 (276)  rf=r size=4 type=f align=2 words (r2.9)
//.declare V0220 (277)  rf=r size=4 type=ud alias=V0216+0 align=2 words (r2.8)
//.declare V0221 (278)  rf=r size=4 type=d align=2 words (r2.10)
//.declare V0222 (279)  rf=r size=4 type=ud alias=V0221+0 align=2 words (r2.10)
//.declare V0223 (280)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0224 (281)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0225 (282)  rf=r size=128 type=ud alias=V0218+0 align=32 words (r10.0)
//.declare V0226 (283)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0227 (284)  rf=r size=4 type=f align=2 words (r5.0)
//.declare V0228 (285)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0229 (286)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0230 (287)  rf=r size=128 type=ud alias=V0229+0 align=32 words (r16.0)
//.declare V0231 (288)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0232 (289)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0233 (290)  rf=r size=128 type=ud alias=V0232+0 align=32 words (r8.0)
//.declare V0234 (291)  rf=r size=4 type=f align=2 words (r20.0)
//.declare V0235 (292)  rf=r size=4 type=ud alias=V0223+0 align=2 words (r3.0)
//.declare V0236 (293)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0237 (294)  rf=r size=128 type=ud alias=V0231+0 align=32 words (r18.0)
//.declare V0238 (295)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0244 (301)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0245 (302)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0246 (303)  rf=r size=128 type=ud alias=V0245+0 align=32 words (r28.0)
//.declare V0247 (304)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0248 (305)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0249 (306)  rf=r size=128 type=d align=32 words (r12.0)
//.declare P19 (307)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0250 (308)  rf=r size=128 type=ud alias=V0249+0 align=32 words (r12.0)
//.declare V0251 (309)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0252 (310)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0253 (311)  rf=r size=128 type=f align=32 words (r44.0)
//.declare V0254 (312)  rf=r size=128 type=f alias=V0210+0 align=32 words (r40.0)
//.declare  (313)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (314)  rf=r size=128 type=f align=32 words (r66.0)
//.declare  (315)  rf=r size=128 type=f align=32 words (r64.0)
//.declare  (316)  rf=r size=128 type=f align=32 words (r62.0)
//.declare  (317)  rf=r size=128 type=f align=32 words (r60.0)
//.declare  (318)  rf=r size=128 type=f align=32 words (r58.0)
//.declare  (319)  rf=r size=128 type=f align=32 words (r56.0)
//.declare  (320)  rf=r size=128 type=f align=32 words (r54.0)
//.declare  (321)  rf=r size=128 type=f align=32 words (r52.0)
//.declare V0255 (324)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0256 (325)  rf=r size=4 type=d align=2 words (r2.8)
//.declare V0257 (326)  rf=r size=4 type=f align=2 words (r32.2)
//.declare V0258 (327)  rf=r size=4 type=ud alias=V0256+0 align=2 words (r2.8)
//.declare V0259 (328)  rf=r size=128 type=d align=32 words (r48.0)
//.declare P20 (329)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0260 (330)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0261 (331)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0266 (336)  rf=r size=256 type=uq align=32 words (r12.0)
//.declare V0268 (338)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare V0269 (339)  rf=r size=128 type=w alias=V0268+0 align=32 words (r16.0)
//.declare V0271 (341)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0272 (342)  rf=r size=128 type=f align=32 words (r118.0)
//.declare V0273 (343)  rf=r size=128 type=f alias=V0271+0 align=32 words (r18.0)
//.declare V0274 (344)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0279 (349)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0280 (350)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0284 (354)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0286 (356)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0287 (357)  rf=r size=128 type=w alias=V0286+0 align=32 words (r14.0)
//.declare V0289 (359)  rf=r size=128 type=d alias=V0280+0 align=32 words (r106.0)
//.declare V0291 (361)  rf=r size=128 type=f align=32 words (r100.0)
//.declare V0292 (362)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0293 (363)  rf=r size=128 type=d alias=V0291+0 align=32 words (r100.0)
//.declare P21 (364)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0294 (365)  rf=r size=128 type=ud alias=V0292+0 align=32 words (r6.0)
//.declare V0295 (366)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0296 (367)  rf=r size=128 type=ud alias=V0291+0 align=32 words (r100.0)
//.declare V0297 (368)  rf=r size=128 type=ud alias=V0295+0 align=32 words (r6.0)
//.declare V0298 (369)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0299 (370)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0300 (371)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0301 (372)  rf=r size=128 type=ud alias=V0299+0 align=32 words (r10.0)
//.declare V0302 (373)  rf=r size=128 type=ud alias=V0300+0 align=32 words (r12.0)
//.declare V0303 (374)  rf=r size=64 type=w align=32 words (r112.0)
//.declare V0304 (375)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0305 (376)  rf=r size=128 type=ud alias=V0304+0 align=32 words (r6.0)
//.declare V0309 (380)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0310 (381)  rf=r size=64 type=uw alias=V0303+0 align=32 words (r112.0)
//.declare V0311 (382)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare P22 (383)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P23 (384)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0313 (386)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0314 (387)  rf=r size=256 type=ud alias=V0313+0 align=32 words (r6.0)
//.declare V0315 (388)  rf=r size=128 type=d align=32 words (r10.0)
//.declare  (389)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (390)  rf=r size=128 type=w alias=V0304+0 align=32 words (r6.0)
//.declare  (391)  rf=r size=2 type=w align=1 words (r2.18)
//.declare  (392)  rf=r size=2 type=w align=1 words (r2.16)
//.declare  (393)  rf=r size=4 type=f align=2 words (r5.0)
//.declare  (394)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (395)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (396)  rf=r size=4 type=f align=2 words (r3.4)
//.declare  (397)  rf=r size=4 type=d align=2 words (r4.0)
//.declare  (399)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (400)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (401)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare  (402)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (403)  rf=r size=128 type=w alias=V0300+0 align=32 words (r12.0)
//.declare  (406)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (407)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (408)  rf=r size=128 type=q align=32 words (r125.0)
//.declare  (409)  rf=r size=128 type=q align=32 words (r123.0)
//.declare  (412)  rf=r size=128 type=q align=32 words (r110.0)
//.declare  (413)  rf=r size=128 type=q align=32 words (r108.0)
//.declare  (416)  rf=r size=128 type=q align=32 words (r104.0)
//.declare  (417)  rf=r size=128 type=q align=32 words (r102.0)
//.declare  (418)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (419)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (422)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (423)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (428)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (429)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (430)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (431)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (432)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (433)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (434)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (435)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (436)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (437)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (438)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (439)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (440)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (441)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (442)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (443)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (444)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (445)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (446)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (447)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (448)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (449)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (450)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (451)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (452)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (453)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (454)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (455)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (456)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (457)  rf=r size=64 type=d align=32 words (r31.0)
//.declare r0 (458)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (459)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (460)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (461)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (462)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (463)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (464)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0034    | :uq      |    0x8 | r2+0x18  | inline+0x18      |
// | V0043    | :d       |    0x4 | r3       | cti+0x20         |
// | V0044    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0051    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0052    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0053    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0054    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0055    | :q       |    0x8 | r4       | cti+0x60         |
// | V0056    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0057    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0058    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0059    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0060    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0061    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0062    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0063    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0064    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0065    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0066    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0067    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0068    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0069    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B048}
// _main:
(W)     mov (16|M0)              r46.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              r33.0<1>:f    0x3F000000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r42.0<1>:f    0x3F800000:f                               {Compacted} //  ALU pipe: float; $1
(W)     mov (16|M0)              r122.0<1>:f   0x0:f                               {Compacted}       //  ALU pipe: float; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     cmp (1|M0)    (lt)f2.0   null<1>:d     r3.2<0;1,0>:d     -3:w               {A@1,$1.dst}     //  ALU pipe: int; $7
(W)     mov (1|M0)               r2.18<1>:hf   0x6:hf                                                //  ALU pipe: float; $8
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r46.2<0;1,0>:uw  {I@3}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r3.0<1>:d     r2.3<0;1,0>:d     r46.1<0;1,0>:d   {Compacted}        //  ALU pipe: int; $4
(W&f2.0) sel (1|M0)              r4.2<1>:w     r2.18<0;1,0>:w    3:w               {F@1}             //  ALU pipe: int; $8
(W)     mul (1|M0)               acc0.0<1>:d   r3.3<0;1,0>:d     r3.2<0;1,0>:uw                      //  ALU pipe: int; $5
(W)     mov (1|M0)               r5.0<2>:b     r4.2<0;1,0>:w                    {@2,$2.dst}          //  ALU pipe: int; $9
(W)     macl (1|M0)              r4.0<1>:d     r3.3<0;1,0>:d     r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $6
(W)     mov (1|M0)               r6.0<1>:d     r5.0<0;1,0>:ub                   {I@2}                //  ALU pipe: int; $10
        add3 (32|M0)             r30.0<1>:d    r3.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {$0.dst} //  ALU pipe: int; $4
(W)     add (1|M0)               r32.4<1>:d    r6.0<0;1,0>:d     r3.2<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $11
(W)     asr (1|M0)               r2.8<1>:d     r4.0<0;1,0>:d     31:w                                //  ALU pipe: int; $6
(W)     asr (1|M0)               r32.3<1>:d    r32.4<0;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $12
(W)     asr (1|M0)               r7.0<1>:d     r32.3<0;1,0>:d    31:w               {Compacted,I@1}  //  ALU pipe: int; $13
(W)     mul (1|M0)               acc0.0<1>:ud  r4.0<0;1,0>:ud    r32.6<0;1,0>:uw                     //  ALU pipe: int; $14
(W)     macl (1|M0)              r3.0<1>:ud    r4.0<0;1,0>:ud    r32.3<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $15
(W)     mul (1|M0)               acc0.0<1>:ud  r4.0<0;1,0>:ud    r32.6<0;1,0>:uw                     //  ALU pipe: int; $15
(W)     mach (1|M0)              r8.0<1>:d     r4.0<0;1,0>:ud    r32.3<0;1,0>:ud                     //  ALU pipe: int; 
(W)     mul (1|M0)               acc0.0<1>:d   r4.0<0;1,0>:ud    r7.0<0;1,0>:uw   {I@5}              //  ALU pipe: int; $16
(W)     macl (1|M0)              r9.0<1>:d     r4.0<0;1,0>:ud    r7.0<0;1,0>:d                       //  ALU pipe: int; $17
(W)     mul (1|M0)               acc0.0<1>:d   r32.3<0;1,0>:ud   r2.16<0;1,0>:uw                     //  ALU pipe: int; $18
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r3.0<0;1,0>:ud    r30.0<1;1,0>:ud  {I@6}              //  ALU pipe: int; $21
(W)     add (1|M0)               r8.0<1>:d     r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@3}    //  ALU pipe: int; $17
(W)     macl (1|M0)              r9.0<1>:d     r32.3<0;1,0>:ud   r2.8<0;1,0>:d                       //  ALU pipe: int; $20
(W)     add (1|M0)               r3.4<1>:d     r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $20
(f2.0)  cmp (32|M0)   (eq)f2.0   null<1>:d     r3.4<0;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $22
(~f2.0) cmp (32|M0)   (gt)f2.0   null<1>:ud    r3.4<0;1,0>:ud    0x0:uw                              //  ALU pipe: int; $24
(~f2.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $26
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B048}
_0_048:
(W)     mov (1|M0)               r4.0<1>:uq    r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $28
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $29
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $30
(f0.0)  goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $31
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B048}
_0_049:
(W)     mov (1|M0)               r32.0<1>:uq   r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $33
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $36
        mov (16|M0)              r6.0<2>:f     r32.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $34
        mov (16|M16)             r8.0<2>:f     r32.0<0;1,0>:f                                        //  ALU pipe: float; $34
        mov (16|M0)              r6.1<2>:f     r32.1<0;1,0>:f                                        //  ALU pipe: float; $35
        mov (16|M16)             r8.1<2>:ud    r32.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $35
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$4} // ex_desc:0x0; desc:0x8200599 // $37
        cmp (32|M0)   (eq)f3.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$4.dst}          //  ALU pipe: int; $39
(~f3.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $40
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B046}
_0_050:
(W)     mov (1|M0)               r4.0<1>:uq    r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $42
(W)     add (1|M0)               r2.8<1>:d     r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $44
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$5} // ex_desc:0x0; desc:0x2108580 // $43
(W)     cmp (32|M0)   (gt)f3.0   null<1>:d     r3.0<0;1,0>:d     r2.8<0;1,0>:d    {$5.dst}           //  ALU pipe: int; $45
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $46
(W&f3.0) jmpi                                _0_051                                                  //  ALU pipe: int; $48
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_052:
(W)     cmp (1|M0)    (lt)f1.0   null<1>:d     r3.2<0;1,0>:d     -31:w                               //  ALU pipe: int; $53
(W)     mov (1|M0)               r2.16<1>:hf   0x3E:hf                              {I@4}            //  ALU pipe: float; $54
(W)     mov (8|M0)               r127.0<1>:w   0x76543210:v                                          //  ALU pipe: int; $50
(W)     cmp (32|M0)   (lt)f2.0   null<1>:ud    r32.4<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $59
(W&f1.0) sel (1|M0)              r3.0<1>:w     r2.16<0;1,0>:w    31:w               {F@1}            //  ALU pipe: int; $54
(W)     add (8|M0)               r127.8<1>:w   r127.0<1;1,0>:w   8:w               {I@3}             //  ALU pipe: int; $51
(W)     mov (1|M0)               r4.0<2>:b     r3.0<0;1,0>:w                    {I@2}                //  ALU pipe: int; $55
(W)     add (16|M0)              r127.16<1>:w  r127.0<1;1,0>:w   16:w               {I@2}            //  ALU pipe: int; $52
(W)     mov (1|M0)               r5.0<1>:d     r4.0<0;1,0>:ub                   {I@2}                //  ALU pipe: int; $56
(W)     add (1|M0)               r6.0<1>:d     r5.0<0;1,0>:d     r3.2<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $57
(W)     asr (1|M0)               r32.2<1>:d    r6.0<0;1,0>:d     5:w               {Compacted,I@1}   //  ALU pipe: int; $58
(W&~f2.0) jmpi                               _0_053                                                  //  ALU pipe: int; $60
// B007: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_054:
        mov (32|M0)              r36.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $62
(W)     jmpi                                 _0_055                                                  // $63
// B008: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_053:
(W)     asr (1|M0)               r2.8<1>:d     r32.4<0;1,0>:d    31:w                                //  ALU pipe: int; $65
        shr (32|M0)              r6.0<1>:ud    r30.0<1;1,0>:ud   31:w                                //  ALU pipe: int; $66
(W)     add (1|M0)               r2.9<1>:d     r2.8<0;1,0>:d     r32.3<0;1,0>:d   {I@2}              //  ALU pipe: int; $67
(W)     xor (1|M0)               r3.0<1>:d     r2.9<0;1,0>:d     r2.8<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $68
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $69
(W)     mov (1|M0)               r4.0<1>:f     r3.0<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $70
(W)     mov (1|M0)               r5.0<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $75
(W)     math.inv (1|M0)          r4.2<1>:f     r4.0<0;1,0>:f                    {F@2}                //  ALU pipe: math; $74
        mov (32|M0)              r8.0<1>:f     r30.0<1;1,0>:ud                                       //  ALU pipe: float; $73
(W)     mad (1|M0)               r10.0<1>:f    r4.2<0;0>:f       r5.0<0;0>:f       r4.2<0>:f        {Compacted,A@1} //  ALU pipe: float; $75
        mov (32|M0)              r14.0<1>:ud   r8.0<1;1,0>:f                    {F@2}                //  ALU pipe: int; $77
        mul (32|M0)              r12.0<1>:f    r8.0<1;1,0>:f     r10.0<0;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $76
(W)     mov (1|M0)               r3.4<1>:ud    r4.0<0;1,0>:f                                         //  ALU pipe: int; $71
        add (32|M0)              r16.0<1>:d    r30.0<1;1,0>:d    -r14.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $78 R{} IR{}{E:7,E:7,},  R{} IR{}{O:15,O:7,},  {BC=1}
        mov (32|M0)              r18.0<1>:ud   r12.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $79
(W)     add (1|M0)               r4.1<1>:d     r3.0<0;1,0>:d     -r3.4<0;1,0>:d   {I@3}              //  ALU pipe: int; $72
        mov (32|M0)              r22.0<1>:f    r18.0<1;1,0>:ud                  {I@2}                //  ALU pipe: float; $82
        mov (32|M0)              r20.0<1>:f    r16.0<1;1,0>:ud                                       //  ALU pipe: float; $81
(W)     mov (1|M0)               r2.9<1>:f     r4.1<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $80
        mad (32|M0)              acc0.0<1>:f   r8.0<1;0>:f       r22.0<1;0>:f      -r4.0<0>:f       {F@3} //  ALU pipe: float; $84 R{} IR{}{E:4,E:3,E:2,},  R{r4,} IR{}{O:4,O:11,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r20.0<1;0>:f      r22.0<1;0>:f      -r2.9<0>:f       {F@2} //  ALU pipe: float; $86 R{} IR{}{E:2,E:3,E:1,},  R{r2,} IR{}{O:10,O:11,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $87
        mul (32|M0)              r24.0<1>:f    r10.0<0;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $88
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $89
        mov (32|M0)              r26.0<1>:ud   r24.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $90
        add (32|M0)              r28.0<1>:d    r26.0<1;1,0>:d    r18.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $91
(W)     mul (16|M0)              acc0.0<1>:d   r28.0<1;1,0>:d    r3.0<0;1,0>:uw   {I@1}              //  ALU pipe: int; $93
        macl (16|M0)             r12.0<1>:d    r28.0<1;1,0>:d    r3.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $93
(W)     mul (16|M16)             acc0.0<1>:d   r29.0<1;1,0>:d    r3.0<0;1,0>:uw                      //  ALU pipe: int; $93
        macl (16|M16)            r13.0<1>:d    r29.0<1;1,0>:d    r3.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $94
        add (32|M0)              r8.0<1>:d     r30.0<1;1,0>:d    -r12.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $94
        cmp (32|M0)   (ge)f3.0   r16.0<1>:ud   r8.0<1;1,0>:ud    r3.0<0;1,0>:ud   {I@1}              //  ALU pipe: int; $95
        xor (32|M0)              r14.0<1>:d    r6.0<1;1,0>:d     r2.8<0;1,0>:d    {Compacted}        //  ALU pipe: int; $92
        add3 (32|M0)             r20.0<1>:d    r28.0<1;0>:d      r14.0<1;0>:d      -r16.0<1>:d      {Compacted,I@1} //  ALU pipe: int; $96 R{} IR{}{E:6,E:7,E:0,},  R{} IR{}{O:14,O:7,O:8,},  {BC=2}
        xor (32|M0)              r36.0<1>:d    r20.0<1;1,0>:d    r2.8<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $97
// B009: [inDivergent],  Preds:{B008, B007},  Succs:{B010, B012}
_0_055:
(W)     mul (16|M0)              acc0.0<1>:d   r36.0<1;1,0>:d    r32.6<0;1,0>:uw  {I@1}              //  ALU pipe: int; $99
        macl (16|M0)             r6.0<1>:d     r36.0<1;1,0>:d    r32.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $99
(W)     mul (16|M16)             acc0.0<1>:d   r37.0<1;1,0>:d    r32.6<0;1,0>:uw                     //  ALU pipe: int; $99
        mov (32|M0)              r50.0<1>:d    r127.0<1;1,0>:uw                                      //  ALU pipe: int; $102
        macl (16|M16)            r7.0<1>:d     r37.0<1;1,0>:d    r32.3<0;1,0>:d   {Compacted}        //  ALU pipe: int; $100
        add (32|M0)              r10.0<1>:d    r50.0<1;1,0>:d    32:w               {Compacted,I@2}  //  ALU pipe: int; $103
        add (32|M0)              r8.0<1>:d     r30.0<1;1,0>:d    -r6.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $100
(W)     cmp (32|M0)   (gt)f1.0   null<1>:d     r3.2<0;1,0>:d     0:w                                 //  ALU pipe: int; $105
        shl (32|M0)              r96.0<1>:d    r10.0<1;1,0>:d    2:w               {Compacted,I@3}   //  ALU pipe: int; $104
        shl (32|M0)              r34.0<1>:d    r8.0<1;1,0>:d     2:w               {Compacted,I@3}   //  ALU pipe: int; $101
(W&~f1.0) jmpi                               _0_056                                                  //  ALU pipe: int; $106
// B010: [inDivergent],  Preds:{B009},  Succs:{B011}
_0_057:
(W)     mul (16|M0)              acc0.0<1>:d   r36.0<1;1,0>:d    r32.4<0;1,0>:uw                     //  ALU pipe: int; $108
        macl (16|M0)             r6.0<1>:d     r36.0<1;1,0>:d    r32.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $108
(W)     mul (16|M16)             acc0.0<1>:d   r37.0<1;1,0>:d    r32.4<0;1,0>:uw                     //  ALU pipe: int; $108
        macl (16|M16)            r7.0<1>:d     r37.0<1;1,0>:d    r32.2<0;1,0>:d   {Compacted}        //  ALU pipe: int; $110
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@3}      //  ALU pipe: int; $110
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $110
        shl (16|M0)              r10.0<1>:q    r8.0<2;1,0>:d     2:w               {I@2}             //  ALU pipe: int; $110
        shl (16|M16)             r14.0<1>:q    r12.0<2;1,0>:d    2:w               {I@2}             //  ALU pipe: int; $110
        add (16|M0)              r125.0<1>:q   r10.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $111
        add (16|M16)             r123.0<1>:q   r14.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $111
(W)     mov (1|M0)               r32.3<1>:d    0:w                                                   //  ALU pipe: int; $112
// B011: [inDivergent],  Preds:{B011, B010},  Succs:{B012, B011}
_0_058:
(W)     shl (1|M0)               r2.4<1>:q     r32.3<0;1,0>:ud   2:w               {I@1}             //  ALU pipe: int; $115
(W)     mul (1|M0)               r3.0<1>:d     r32.3<0;1,0>:d    128:w               {Compacted}     //  ALU pipe: int; $118
        add (16|M0)              r6.0<1>:q     r125.0<1;1,0>:q   r2.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $116
        add (16|M16)             r8.0<1>:q     r123.0<1;1,0>:q   r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $116
        load.ugm.d32.a64 (32|M0)  r10:2         [r6:4]             {I@1,$7} // ex_desc:0x0; desc:0x8200580 // $117
        sync.nop                             null                             {Compacted,F@1}        // $120
(W)     shr (1|M0)               a0.0<1>:ud    r46.5<0;1,0>:ud   0x4:uw              {$6.src}        //  ALU pipe: int; $120
(W)     add (1|M0)               r32.3<1>:d    r32.3<0;1,0>:d    1:w                                 //  ALU pipe: int; $122
        add (32|M0)              r12.0<1>:d    r96.0<1;1,0>:d    r3.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $119
(W)     cmp (32|M0)   (lt)f0.0   null<1>:d     r32.3<0;1,0>:d    r32.2<0;1,0>:d   {I@2}              //  ALU pipe: int; $123
        sync.nop                             null                             {Compacted,$7.dst}     // $121
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r12:2] r10:2     {I@2,$6} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $121
(W&f0.0) jmpi                                _0_058                                                  //  ALU pipe: int; $124
// B012: [inDivergent],  Preds:{B011, B009},  Succs:{B013, B021}
_0_056:
(W)     cmp (32|M0)   (gt)f0.0   null<1>:d     r3.2<0;1,0>:d     32:w                                //  ALU pipe: int; $126
(W&~f0.0) jmpi                               _0_059                                                  //  ALU pipe: int; $127
// B013: [inDivergent],  Preds:{B012},  Succs:{B014}
_0_060:
(W)     mov (1|M0)               r3.6<1>:d     1:w                                                   //  ALU pipe: int; $129
// B014: [inDivergent],  Preds:{B020, B013},  Succs:{B015}
_0_061:
(W)     shl (1|M0)               r3.4<1>:d     r3.6<0;1,0>:d     1:w               {I@1}             //  ALU pipe: int; $131
(W)     mov (1|M0)               r3.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $132
// B015: [inDivergent],  Preds:{B018, B014},  Succs:{B016, B017}
_0_062:
(W)     mul (1|M0)               r2.8<1>:d     r3.0<0;1,0>:d     128:w               {I@1}           //  ALU pipe: int; $134
        sync.nop                             null                             {Compacted,$8.src}     // $136
(W)     shr (1|M0)               a0.0<1>:ud    r46.5<0;1,0>:ud   0x4:uw              {$6.src}        //  ALU pipe: int; $136
        add (32|M0)              r94.0<1>:d    r96.0<1;1,0>:d    r2.8<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $135
        load.ugm.d32.a32.ca.ca (32|M0)  r98:2   ss[a0.0][r94:2]    {I@1,$9} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $137
(W)     add (1|M0)               r3.1<1>:d     r3.0<0;1,0>:d     r3.6<0;1,0>:d    {Compacted}        //  ALU pipe: int; $138
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r3.1<0;1,0>:d     r32.2<0;1,0>:d   {I@1}              //  ALU pipe: int; $139
(W&f2.0) jmpi                                _0_063                                                  //  ALU pipe: int; $140
// B016: [inDivergent],  Preds:{B015},  Succs:{B018}
_0_064:
        mov (32|M0)              r92.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $142
(W)     jmpi                                 _0_065                                                  // $143
// B017: [inDivergent],  Preds:{B015},  Succs:{B018}
_0_063:
(W)     mul (1|M0)               r2.8<1>:d     r3.1<0;1,0>:d     128:w                               //  ALU pipe: int; $145
(W)     shr (1|M0)               a0.0<1>:ud    r46.5<0;1,0>:ud   0x4:uw              {$9.src}        //  ALU pipe: int; $147
        add (32|M0)              r6.0<1>:d     r96.0<1;1,0>:d    r2.8<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $146
        load.ugm.d32.a32.ca.ca (32|M0)  r92:2   ss[a0.0][r6:2]     {I@1,$10} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $148
// B018: [inDivergent],  Preds:{B017, B016},  Succs:{B019, B015}
_0_065:
        sync.nop                             null                             {Compacted,$10.src}    // $151
(W)     shr (1|M0)               a0.0<1>:ud    r46.5<0;1,0>:ud   0x4:uw              {$9.src}        //  ALU pipe: int; $151
        sync.nop                             null                             {Compacted,$10.dst}    // $150
        add (32|M0)              r6.0<1>:f     r98.0<1;1,0>:f    r92.0<1;1,0>:f   {Compacted,$9.dst} //  ALU pipe: float; $150
(W)     add (1|M0)               r3.0<1>:d     r3.0<0;1,0>:d     r3.4<0;1,0>:d    {Compacted}        //  ALU pipe: int; $153
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r94:2] r6:2      {F@1,$8} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $152
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.0<0;1,0>:d     r32.2<0;1,0>:d   {I@1}              //  ALU pipe: int; $154
(W&f1.0) jmpi                                _0_062                                                  //  ALU pipe: int; $155
// B019: [inDivergent],  Preds:{B018},  Succs:{B020, B021}
_0_066:
(W)     cmp (32|M0)   (lt)f3.0   null<1>:d     r3.4<0;1,0>:d     r32.2<0;1,0>:d                      //  ALU pipe: int; $157
(W&~f3.0) jmpi                               _0_059                                                  //  ALU pipe: int; $158
// B020: [inDivergent],  Preds:{B019},  Succs:{B014}
_0_067:
(W)     mov (1|M0)               r3.6<1>:d     r3.4<0;1,0>:d                                         //  ALU pipe: int; $160
(W)     jmpi                                 _0_061                                                  // $161
// B021: [inDivergent],  Preds:{B019, B012},  Succs:{B022, B023}
_0_059:
        sync.nop                             null                             {Compacted,$8.src}     // $163
(W)     shr (1|M0)               a0.0<1>:ud    r46.5<0;1,0>:ud   0x4:uw              {$6.src}        //  ALU pipe: int; $163
(W)     mov (1|M0)               r2.8<1>:f     r3.2<0;1,0>:d                                         //  ALU pipe: float; $165
(W)     mov (1|M0)               f1.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $166
        mov (32|M0)              r88.0<1>:f    r2.8<0;1,0>:f                    {Compacted,F@1}      //  ALU pipe: float; $166
        load.ugm.d32.a32.ca.ca (32|M0)  r114:2  ss[a0.0][r96:2]    {$11} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $164
        math.invm (16|M0) (eo)f1.0  r84.mme0:f  r114.nomme<1;1,0>:f  r88.nomme<1;1,0>:f {A@1,$11.dst} //  ALU pipe: math; $166
(f1.0)  goto (32|M0)                         _L_k0_0_macro     _L_k0_0_macro                         //  ALU pipe: int; $166
// B022: [inDivergent],  Preds:{B021},  Succs:{B023}
_L_k0_6_:
        madm (16|M0)             r82.mme1:f    r122.nomme:f      r114.nomme:f      r84.mme0:f       {M@1} //  ALU pipe: float; $166 R{} IR{}{E:5,E:1,E:2,},  {BC=1}
        madm (16|M0)             r80.mme2:f    r42.nomme:f       -r88.nomme:f      r84.mme0:f        //  ALU pipe: float; $166
        madm (16|M0)             r90.mme3:f    r84.mme0:f        r80.mme2:f        r84.mme0:f       {F@1} //  ALU pipe: float; $166
        madm (16|M0)             r78.mme4:f    r114.nomme:f      -r88.nomme:f      r82.mme1:f        //  ALU pipe: float; $166 R{} IR{}{E:1,E:4,E:1,},  {BC=1}
        madm (16|M0)             r82.mme5:f    r82.mme1:f        r78.mme4:f        r90.mme3:f       {F@1} //  ALU pipe: float; $166 R{} IR{}{E:1,E:7,E:5,},  {BC=1}
        madm (16|M0)             r86.mme6:f    r114.nomme:f      -r88.nomme:f      r82.mme5:f       {F@1} //  ALU pipe: float; $166 R{} IR{}{E:1,E:4,E:1,},  {BC=1}
        madm (16|M0)             r84.nomme:f   r82.mme5:f        r86.mme6:f        r90.mme3:f       {F@1} //  ALU pipe: float; $166 R{} IR{}{E:1,E:3,E:5,},  {BC=1}
// B023: [inDivergent],  Preds:{B022, B021},  Succs:{B024, B025}
_L_k0_0_macro:
        join (32|M0)                         _0_047                                                  // 
L2624:
(W)     mov (1|M0)               f1.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $166
        math.invm (16|M16) (eo)f1.0  r85.mme0:f  r115.nomme<1;1,0>:f  r89.nomme<1;1,0>:f {I@1}       //  ALU pipe: math; $166
(f1.0)  goto (32|M0)                         _L_k0_1_macro     _L_k0_1_macro                         //  ALU pipe: int; $166
// B024: [inDivergent],  Preds:{B023},  Succs:{B025}
_L_k0_7_:
        madm (16|M16)            r83.mme1:f    r122.nomme:f      r115.nomme:f      r85.mme0:f       {M@1} //  ALU pipe: float; $166
        madm (16|M16)            r81.mme2:f    r42.nomme:f       -r89.nomme:f      r85.mme0:f        //  ALU pipe: float; $166
        madm (16|M16)            r91.mme3:f    r85.mme0:f        r81.mme2:f        r85.mme0:f       {F@1} //  ALU pipe: float; $166
        madm (16|M16)            r79.mme4:f    r115.nomme:f      -r89.nomme:f      r83.mme1:f        //  ALU pipe: float; $166 R{} IR{}{O:1,O:4,O:1,},  {BC=1}
        madm (16|M16)            r83.mme5:f    r83.mme1:f        r79.mme4:f        r91.mme3:f       {F@1} //  ALU pipe: float; $166 R{} IR{}{O:1,O:7,O:5,},  {BC=1}
        madm (16|M16)            r87.mme6:f    r115.nomme:f      -r89.nomme:f      r83.mme5:f       {F@1} //  ALU pipe: float; $166 R{} IR{}{O:1,O:4,O:1,},  {BC=1}
        madm (16|M16)            r85.nomme:f   r83.mme5:f        r87.mme6:f        r91.mme3:f       {F@1} //  ALU pipe: float; $166 R{} IR{}{O:1,O:3,O:5,},  {BC=1}
// B025: [inDivergent],  Preds:{B024, B023},  Succs:{B026, B027}
_L_k0_1_macro:
        join (32|M0)                         _0_047                                                  // 
L2800:
        add (32|M0)              r116.0<1>:f   r84.0<1;1,0>:f    0x358637BD:f               {F@1}    //  ALU pipe: float; $167
        shl (32|M0)              r4.0<1>:d     r50.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $168
(W)     mov (1|M0)               f0.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $169
        math.rsqtm (16|M0) (eo)f0.0  r74.mme0:f  r116.nomme<1;1,0>:f            {A@1}                //  ALU pipe: math; $169
(f0.0)  goto (32|M0)                         _L_k0_2_macro     _L_k0_2_macro                         //  ALU pipe: int; $169
// B026: [inDivergent],  Preds:{B025},  Succs:{B027}
_L_k0_8_:
        madm (16|M0)             r72.mme1:f    r122.nomme:f      r33.nomme:f       r74.mme0:f       {M@1} //  ALU pipe: float; $169 R{} IR{}{E:5,O:0,E:5,},  {BC=1}
        madm (16|M0)             r68.mme2:f    r122.nomme:f      r116.nomme:f      r74.mme0:f        //  ALU pipe: float; $169
        madm (16|M0)             r70.mme3:f    r33.nomme:f       -r68.mme2:f       r72.mme1:f       {F@1} //  ALU pipe: float; $169
        madm (16|M0)             r72.mme4:f    r72.mme1:f        r70.mme3:f        r72.mme1:f       {F@1} //  ALU pipe: float; $169
        madm (16|M0)             r74.mme5:f    r68.mme2:f        r70.mme3:f        r68.mme2:f        //  ALU pipe: float; $169
        madm (16|M0)             r70.mme6:f    r116.nomme:f      -r74.mme5:f       r74.mme5:f       {F@1} //  ALU pipe: float; $169
        madm (16|M0)             r74.nomme:f   r74.mme5:f        r72.mme4:f        r70.mme6:f       {F@1} //  ALU pipe: float; $169 R{} IR{}{E:5,E:4,E:3,},  {BC=1}
// B027: [inDivergent],  Preds:{B026, B025},  Succs:{B028, B029}
_L_k0_2_macro:
        join (32|M0)                         _0_047                                                  // 
L3000:
(W)     mov (1|M0)               f0.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $169
        math.rsqtm (16|M16) (eo)f0.0  r75.mme0:f  r117.nomme<1;1,0>:f           {I@1}                //  ALU pipe: math; $169
(f0.0)  goto (32|M0)                         _L_k0_3_macro     _L_k0_3_macro                         //  ALU pipe: int; $169
// B028: [inDivergent],  Preds:{B027},  Succs:{B029}
_L_k0_9_:
        madm (16|M16)            r73.mme1:f    r122.nomme:f      r33.nomme:f       r75.mme0:f       {M@1} //  ALU pipe: float; $169
        madm (16|M16)            r69.mme2:f    r122.nomme:f      r117.nomme:f      r75.mme0:f        //  ALU pipe: float; $169
        madm (16|M16)            r71.mme3:f    r33.nomme:f       -r69.mme2:f       r73.mme1:f       {F@1} //  ALU pipe: float; $169 R{} IR{}{O:0,O:2,O:4,},  {BC=1}
        madm (16|M16)            r73.mme4:f    r73.mme1:f        r71.mme3:f        r73.mme1:f       {F@1} //  ALU pipe: float; $169
        madm (16|M16)            r75.mme5:f    r69.mme2:f        r71.mme3:f        r69.mme2:f        //  ALU pipe: float; $169
        madm (16|M16)            r71.mme6:f    r117.nomme:f      -r75.mme5:f       r75.mme5:f       {F@1} //  ALU pipe: float; $169
        madm (16|M16)            r75.nomme:f   r75.mme5:f        r73.mme4:f        r71.mme6:f       {F@1} //  ALU pipe: float; $169 R{} IR{}{O:5,O:4,O:3,},  {BC=1}
// B029: [inDivergent],  Preds:{B028, B027},  Succs:{B030, B048}
_L_k0_3_macro:
        join (32|M0)                         _0_047                                                  // 
L3176:
(W)     shr (1|M0)               a0.0<1>:ud    r46.5<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $170
        mov (32|M0)              r6.0<1>:f     r74.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $169
        store.ugm.d32.a32.wb.wb (32|M0)  ss[a0.0][r4:2] r6:2       {F@1,$12} // ex_desc:a0.0; desc:0x440E0504 //  address space: private; ; $171
        add (32|M0)              r8.0<1>:d     r34.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $174
        sel (32|M0)   (lt)f0.0   r38.0<1>:d    r8.0<1;1,0>:d     r3.2<0;1,0>:d    {I@1}              //  ALU pipe: int; $175
        cmp (32|M0)   (lt)f3.0   null<1>:d     r34.0<1;1,0>:d    r38.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $176
        load.ugm.d32.a32.ca.ca (32|M0)  r40:2   ss[a0.0][r4:2]     {$13} // ex_desc:a0.0; desc:0x44280500 //  address space: private; ; $173
(~f3.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $177
// B030: [inDivergent],  Preds:{B029},  Succs:{B031, B032}
_0_068:
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.3<0;1,0>:d     0:w                                 //  ALU pipe: int; $179
(W&~f2.0) jmpi                               _0_069                                                  //  ALU pipe: int; $180
// B031: [inDivergent],  Preds:{B030},  Succs:{B033}
_0_070:
        mov (32|M0)              r120.0<1>:d   -1:w                               {Compacted}        //  ALU pipe: int; $182
(W)     jmpi                                 _0_071                                                  // $183
// B032: [inDivergent],  Preds:{B030},  Succs:{B033}
_0_069:
        asr (32|M0)              r6.0<1>:d     r36.0<1;1,0>:d    31:w               {Compacted,$12.src} //  ALU pipe: int; $185
        add (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     r36.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $187
        xor (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     r6.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $188
(W)     mov (1|M0)               r2.8<1>:d     (abs)r3.3<0;1,0>:d                                    //  ALU pipe: int; $186
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $189
(W)     mov (1|M0)               r2.9<1>:f     r2.8<0;1,0>:ud                   {A@1}                //  ALU pipe: float; $190
(W)     mov (1|M0)               r3.4<1>:f     0xB4C00000:f                               {Compacted} //  ALU pipe: float; $195
(W)     math.inv (1|M0)          r4.0<1>:f     r2.9<0;1,0>:f                    {@2,$13.src}         //  ALU pipe: math; $194
        mov (32|M0)              r12.0<1>:f    r10.0<1;1,0>:ud                                       //  ALU pipe: float; $193
(W)     mad (1|M0)               r5.0<1>:f     r4.0<0;0>:f       r3.4<0;0>:f       r4.0<0>:f        {A@1} //  ALU pipe: float; $195
        mov (32|M0)              r16.0<1>:ud   r12.0<1;1,0>:f                   {F@2}                //  ALU pipe: int; $197
        mul (32|M0)              r14.0<1>:f    r12.0<1;1,0>:f    r5.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $196
(W)     mov (1|M0)               r2.10<1>:ud   r2.9<0;1,0>:f                                         //  ALU pipe: int; $191
        add (32|M0)              r18.0<1>:d    r10.0<1;1,0>:d    -r16.0<1;1,0>:d  {Compacted,I@2}    //  ALU pipe: int; $198
        mov (32|M0)              r8.0<1>:ud    r14.0<1;1,0>:f                   {F@1}                //  ALU pipe: int; $199
(W)     add (1|M0)               r3.0<1>:d     (abs)r3.3<0;1,0>:d  -r2.10<0;1,0>:d {I@3}             //  ALU pipe: int; $192
        mov (32|M0)              r24.0<1>:f    r8.0<1;1,0>:ud                   {I@2}                //  ALU pipe: float; $202
        mov (32|M0)              r22.0<1>:f    r18.0<1;1,0>:ud                                       //  ALU pipe: float; $201
(W)     mov (1|M0)               r20.0<1>:f    r3.0<0;1,0>:ud                   {I@1}                //  ALU pipe: float; $200
        mad (32|M0)              acc0.0<1>:f   r12.0<1;0>:f      r24.0<1;0>:f      -r2.9<0>:f       {F@3} //  ALU pipe: float; $204 R{} IR{}{E:6,E:4,E:1,},  R{r2,} IR{}{O:6,O:12,},  {BC=1}
        mad (32|M0)              acc2.0<1>:f   r22.0<1;0>:f      r24.0<1;0>:f      -r20.0<0>:f      {F@2} //  ALU pipe: float; $206 R{} IR{}{E:3,E:4,E:2,},  R{r20,} IR{}{O:11,O:12,},  {BC=1}
        add (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $207
        mul (32|M0)              r26.0<1>:f    r5.0<0;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $208
(W)     xor (1|M0)               cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x30:uw              {A@1}          // $209
        mov (32|M0)              r28.0<1>:ud   r26.0<1;1,0>:f                   {A@1}                //  ALU pipe: int; $210
        add (32|M0)              r30.0<1>:d    r28.0<1;1,0>:d    r8.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $211
(W)     mov (1|M0)               r4.0<1>:d     (abs)r3.3<0;1,0>:d                                    //  ALU pipe: int; $212
(W)     mul (16|M0)              acc0.0<1>:d   r30.0<1;1,0>:d    r4.0<0;1,0>:uw   {I@1}              //  ALU pipe: int; $212
        macl (16|M0)             r14.0<1>:d    r30.0<1;1,0>:d    r4.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $212
(W)     mul (16|M16)             acc0.0<1>:d   r31.0<1;1,0>:d    r4.0<0;1,0>:uw                      //  ALU pipe: int; $212
        macl (16|M16)            r15.0<1>:d    r31.0<1;1,0>:d    r4.0<0;1,0>:d    {Compacted}        //  ALU pipe: int; $213
        add (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    -r14.0<1;1,0>:d  {Compacted,I@1}    //  ALU pipe: int; $213
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r12.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $214
(~f1.0) sel (32|M0)              r16.0<1>:d    (abs)r3.3<0;1,0>:d  0:w                               //  ALU pipe: int; $215
        add3 (32|M0)             r18.0<1>:d    r12.0<1;0>:d      r6.0<1;0>:d       -r16.0<1>:d      {Compacted,I@1} //  ALU pipe: int; $216 R{} IR{}{E:6,E:3,E:0,},  R{} IR{}{O:6,O:3,O:8,},  {BC=2}
        xor (32|M0)              r120.0<1>:d   r18.0<1;1,0>:d    r6.0<1;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $217
// B033: [inDivergent],  Preds:{B032, B031},  Succs:{B034, B035}
_0_071:
(W)     mov (32|M0)              r52.0<1>:f    0x3F800000:f                                          //  ALU pipe: float; $219
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $219
        math.invm (16|M0) (eo)f3.0  r60.mme0:f  r52.nomme<1;1,0>:f  r40.nomme<1;1,0>:f {A@1,$13.dst} //  ALU pipe: math; $219
(f3.0)  goto (32|M0)                         _L_k0_4_macro     _L_k0_4_macro                         //  ALU pipe: int; $219
// B034: [inDivergent],  Preds:{B033},  Succs:{B035}
_L_k0_10_:
        madm (16|M0)             r58.mme1:f    r122.nomme:f      r52.nomme:f       r60.mme0:f       {M@1} //  ALU pipe: float; $219 R{} IR{}{E:5,E:2,E:6,},  {BC=1}
        madm (16|M0)             r56.mme2:f    r42.nomme:f       -r40.nomme:f      r60.mme0:f        //  ALU pipe: float; $219
        madm (16|M0)             r66.mme3:f    r60.mme0:f        r56.mme2:f        r60.mme0:f       {F@1} //  ALU pipe: float; $219
        madm (16|M0)             r54.mme4:f    r52.nomme:f       -r40.nomme:f      r58.mme1:f        //  ALU pipe: float; $219 R{} IR{}{E:2,E:4,E:5,},  {BC=1}
        madm (16|M0)             r58.mme5:f    r58.mme1:f        r54.mme4:f        r66.mme3:f       {F@1} //  ALU pipe: float; $219 R{} IR{}{E:5,E:3,E:1,},  {BC=1}
        madm (16|M0)             r62.mme6:f    r52.nomme:f       -r40.nomme:f      r58.mme5:f       {F@1} //  ALU pipe: float; $219 R{} IR{}{E:2,E:4,E:5,},  {BC=1}
        madm (16|M0)             r60.nomme:f   r58.mme5:f        r62.mme6:f        r66.mme3:f       {F@1} //  ALU pipe: float; $219 R{} IR{}{E:5,E:7,E:1,},  {BC=1}
// B035: [inDivergent],  Preds:{B034, B033},  Succs:{B036, B037}
_L_k0_4_macro:
        join (32|M0)                         _0_047                                                  // 
L4000:
(W)     mov (1|M0)               f3.0<1>:ud    0xFFFFFFFF:ud                                         //  ALU pipe: int; $219
        math.invm (16|M16) (eo)f3.0  r61.mme0:f  r53.nomme<1;1,0>:f  r41.nomme<1;1,0>:f {I@1}        //  ALU pipe: math; $219
(f3.0)  goto (32|M0)                         _L_k0_5_macro     _L_k0_5_macro                         //  ALU pipe: int; $219
// B036: [inDivergent],  Preds:{B035},  Succs:{B037}
_L_k0_11_:
        madm (16|M16)            r59.mme1:f    r122.nomme:f      r53.nomme:f       r61.mme0:f       {M@1} //  ALU pipe: float; $219
        madm (16|M16)            r57.mme2:f    r42.nomme:f       -r41.nomme:f      r61.mme0:f        //  ALU pipe: float; $219
        madm (16|M16)            r67.mme3:f    r61.mme0:f        r57.mme2:f        r61.mme0:f       {F@1} //  ALU pipe: float; $219
        madm (16|M16)            r55.mme4:f    r53.nomme:f       -r41.nomme:f      r59.mme1:f        //  ALU pipe: float; $219 R{} IR{}{O:2,O:4,O:5,},  {BC=1}
        madm (16|M16)            r59.mme5:f    r59.mme1:f        r55.mme4:f        r67.mme3:f       {F@1} //  ALU pipe: float; $219 R{} IR{}{O:5,O:3,O:1,},  {BC=1}
        madm (16|M16)            r63.mme6:f    r53.nomme:f       -r41.nomme:f      r59.mme5:f       {F@1} //  ALU pipe: float; $219 R{} IR{}{O:2,O:4,O:5,},  {BC=1}
        madm (16|M16)            r61.nomme:f   r59.mme5:f        r63.mme6:f        r67.mme3:f       {F@1} //  ALU pipe: float; $219 R{} IR{}{O:5,O:7,O:1,},  {BC=1}
// B037: [inDivergent],  Preds:{B036, B035},  Succs:{B038}
_L_k0_5_macro:
        join (32|M0)                         _0_047                                                  // 
L4176:
(W)     mul (16|M0)              acc0.0<1>:d   r36.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $220
(W)     and (1|M0)               r3.0<1>:d     r3.5<0;1,0>:d     8:w                                 //  ALU pipe: int; $224
        macl (16|M0)             r42.0<1>:d    r36.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $220
(W)     mul (16|M16)             acc0.0<1>:d   r37.0<1;1,0>:d    r3.4<0;1,0>:uw                      //  ALU pipe: int; $220
        mov (32|M0)              r44.0<1>:f    r60.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $219
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.0<0;1,0>:d     0:w               {I@3}             //  ALU pipe: int; $225
        macl (16|M16)            r43.0<1>:d    r37.0<1;1,0>:d    r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $221
(W)     mul (16|M0)              acc0.0<1>:d   r120.0<1;1,0>:d   r3.4<0;1,0>:uw                      //  ALU pipe: int; $223
(W)     and (1|M0)               r2.8<1>:d     r3.5<0;1,0>:d     1:w                                 //  ALU pipe: int; $221
        macl (16|M0)             r48.0<1>:d    r120.0<1;1,0>:d   r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $223
(W)     mul (16|M16)             acc0.0<1>:d   r121.0<1;1,0>:d   r3.4<0;1,0>:uw                      //  ALU pipe: int; $223
        macl (16|M16)            r49.0<1>:d    r121.0<1;1,0>:d   r3.2<0;1,0>:d    {Compacted}        //  ALU pipe: int; $224
(W)     mov (1|M0)               r32.2<1>:f    r2.8<0;1,0>:ud                   {I@4}                //  ALU pipe: float; $222
// B038: [inDivergent],  Preds:{B044, B037},  Succs:{B039, B040}
_0_072:
        sync.nop                             null                             {Compacted,$14.src}    // $227
        add (32|M0)              r6.0<1>:d     r42.0<1;1,0>:d    r34.0<1;1,0>:d   {Compacted,$12.src} //  ALU pipe: int; $227
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $229
        mov (16|M16)             r10.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $229
        shl (16|M0)              r110.0<1>:q   r8.0<2;1,0>:d     1:w               {I@2}             //  ALU pipe: int; $229
        shl (16|M16)             r108.0<1>:q   r10.0<2;1,0>:d    1:w               {I@2}             //  ALU pipe: int; $229
        add (16|M0)              r12.0<1>:q    r110.0<1;1,0>:q   r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $230
        add (16|M16)             r14.0<1>:q    r108.0<1;1,0>:q   r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $230
        load.ugm.d16u32.a64 (32|M0)  r16:2      [r12:4]            {I@1,$15} // ex_desc:0x0; desc:0x8200B80 // $232
        add (32|M0)              r20.0<1>:d    r48.0<1;1,0>:d    r34.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $235
        mov (16|M0)              r22.0<2>:ud   r20.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $236
        mov (16|M16)             r24.0<2>:ud   r21.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $236
        mov (16|M0)              r104.0<1>:q   r22.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $236
        mov (16|M16)             r102.0<1>:q   r24.0<2;1,0>:d                   {I@2}                //  ALU pipe: int; $236
        shl (32|M0)              r18.0<1>:d    r16.0<1;1,0>:ud   16:w               {$15.dst}        //  ALU pipe: int; $233
        mul (32|M0)              r118.0<1>:f   r44.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,A@1}    //  ALU pipe: float; $234
(W&f0.0) jmpi                                _0_073                                                  //  ALU pipe: int; $237
// B039: [inDivergent],  Preds:{B038},  Succs:{B041}
_0_074:
        shl (16|M0)              r6.0<1>:q     r104.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $239
        shl (16|M16)             r8.0<1>:q     r102.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $239
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $240
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $240
        load.ugm.d32.a64 (32|M0)  r106:2        [r10:4]            {I@1,$0} // ex_desc:0x0; desc:0x8200580 // $242
(W)     jmpi                                 _0_075                                                  // $243
// B040: [inDivergent],  Preds:{B038},  Succs:{B041}
_0_073:
        shl (16|M0)              r6.0<1>:q     r104.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $245
        shl (16|M16)             r8.0<1>:q     r102.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $245
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $246
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r3.5<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $246
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r10:4]            {I@1,$1} // ex_desc:0x0; desc:0x8200B80 // $248
        shl (32|M0)              r106.0<1>:d   r14.0<1;1,0>:ud   16:w               {$1.dst}         //  ALU pipe: int; $249
// B041: [inDivergent],  Preds:{B040, B039},  Succs:{B042, B043}
_0_075:
        add (32|M0)              acc0.0<1>:f   r106.0<1;1,0>:f   r32.2<0;1,0>:f   {Compacted,A@1,$0.dst} //  ALU pipe: float; $251
        mul (32|M0)              r100.0<1>:f   r118.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $252
        and (32|M0)              r6.0<1>:d     r100.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $253
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r6.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $254
(f2.0)  goto (32|M0)                         _0_076            _0_076                                //  ALU pipe: int; $255
// B042: [inDivergent],  Preds:{B041},  Succs:{B044}
_0_077:
        shr (32|M0)              r6.0<1>:ud    r100.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $257
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $258
        add3 (32|M0)             r10.0<1>:d    r8.0<1;0>:d       r100.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $259
        shr (32|M0)              r12.0<1>:ud   r10.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $260
        mov (32|M0)              r112.0<1>:w   r12.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $261
        goto (32|M0)                         _0_076            _0_078                                // $262
// B043: [inDivergent],  Preds:{B041},  Succs:{B044}
_0_076:
        join (32|M0)                         _0_078                                                  // 
L4832:
        shr (32|M0)              r6.0<1>:ud    r100.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $264
        or (32|M0)               r112.0<1>:w   r6.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $266
// B044: [inDivergent],  Preds:{B043, B042},  Succs:{B045, B038}
_0_078:
        join (32|M0)                         _L_k0_12_                                               // 
L4880:
        add (32|M0)              r34.0<1>:d    r34.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $272
        cmp (32|M0)   (lt)f1.0   null<1>:d     r34.0<1;1,0>:d    r38.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $273
        add (16|M0)              r6.0<1>:q     r110.0<1;1,0>:q   r3.6<0;1,0>:q                       //  ALU pipe: int; $268
        add (16|M16)             r8.0<1>:q     r108.0<1;1,0>:q   r3.6<0;1,0>:q                       //  ALU pipe: int; $268
        mov (32|M0)              r10.0<1>:ud   r112.0<1;1,0>:uw                                      //  ALU pipe: int; $270
        store.ugm.d16u32.a64 (32|M0)  [r6:4]    r10:2              {I@1,$14} // ex_desc:0x0; desc:0x8000B84 // $271
(f1.0)  goto.b (32|M0)                       _L_k0_12_         _0_072                                //  ALU pipe: int; $274
// B045: [inDivergent],  Preds:{B044},  Succs:{B048}
_L_k0_12_:
        join (32|M0)                         _0_047                                                  // 
L5000:
        goto (32|M0)                         _0_047            _0_047                                // $275
// B046: [inDivergent],  Preds:{B005},  Succs:{B047, B048}
_0_051:
        cmp (32|M0)   (eq)f0.0   null<1>:d     r30.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $277
(~f0.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $278
// B047: [inDivergent],  Preds:{B046},  Succs:{B048}
_0_079:
        mov (16|M0)              r6.0<2>:f     r32.0<0;1,0>:f                   {$14.src}            //  ALU pipe: float; $280
        mov (16|M16)             r8.0<2>:f     r32.0<0;1,0>:f                                        //  ALU pipe: float; $280
        mov (32|M0)              r10.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $282
        mov (16|M0)              r6.1<2>:f     r32.1<0;1,0>:f                                        //  ALU pipe: float; $281
        mov (16|M16)             r8.1<2>:ud    r32.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $281
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r6:4]           r10:2              {A@1,$2} // ex_desc:0x0; desc:0x800058B // $283
// B048: Preds:{B047, B046, B045, B029, B004, B003, B002},  Succs:{}
_0_047:
        join (32|M0)                         L5152                                                   // 
L5152:
(W)     mov (16|M0)              r127.0<1>:f   r46.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $285
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$3} // wr:1+0, rd:0; end of thread // $285
L5176:
(W)     mov (16|M0)              null<1>:ud    0x830D2F0:ud                                          // 
(W)     mov (16|M0)              null<1>:ud    0xEA18A4DC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x20:ud                                               // 


//.BankConflicts: 31
//.ByteRMWs: 2
//


//.numALUInst: 322
//.accSubDef: 7
//.accSubUse: 7
//.accSubCandidateDef: 7
//.accSubCandidateUse: 7
//
//
//.singlePipeAtOneDistNum: 100
//.allAtOneDistNum: 20
//.syncInstCount: 7
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 14
//.AfterReadTokenDepCount: 14
