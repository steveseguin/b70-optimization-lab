//.kernel _ZTSN9p42extras8FlatNameILNS_4KindE5ELi32EEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 604709628 1620024839 -hashmovs1 0 28 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 604709628 1620024839 -hashmovs1 0 28 -GRFBumpUpNumber 2 "
//.instCount 55
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r3.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r0.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r0.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r3.0)
//.declare V0034 (44)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r3.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r4.6)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r3.12)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.10)
//.declare V0060 (70)  rf=r size=4 type=d align=2 words (r4.11)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0063 (73)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.0)
//.declare V0064 (74)  rf=r size=32 type=ud alias=V0036+0 align=16 words (r3.0)
//.declare V0065 (75)  rf=r size=8 type=ud alias=V0062+0 align=4 words (r2.4)
//.declare V0066 (76)  rf=r size=8 type=d alias=V0062+0 align=4 words (r2.4)
//.declare V0067 (77)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0070 (80)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0072 (82)  rf=r size=128 type=d align=32 words (r5.0)
//.declare P01 (83)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0073 (84)  rf=r size=128 type=ud alias=V0072+0 align=32 words (r5.0)
//.declare V0074 (85)  rf=r size=4 type=ud alias=V0034+0 align=2 words (r2.3)
//.declare V0075 (86)  rf=r size=8 type=uq alias=V0058+0 align=4 words (r4.4)
//.declare V0078 (89)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0079 (90)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0080 (91)  rf=r size=8 type=uq align=32 words (r12.0)
//.declare V0081 (92)  rf=r size=4 type=d align=32 words (r11.0)
//.declare P02 (93)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P03 (94)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P04 (95)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0082 (96)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r4.3)
//.declare V0083 (97)  rf=r size=8 type=uq align=32 words (r14.0)
//.declare V0084 (98)  rf=r size=4 type=d align=32 words (r13.0)
//.declare P05 (99)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0085 (100)  rf=r size=4 type=ud alias=V0084+0 align=32 words (r13.0)
//.declare V0086 (101)  rf=r size=4 type=ud alias=V0060+0 align=2 words (r4.11)
//.declare V0087 (102)  rf=r size=8 type=uq alias=V0056+0 align=4 words (r4.2)
//.declare V0088 (103)  rf=r size=8 type=uq align=32 words (r16.0)
//.declare V0090 (105)  rf=r size=256 type=uq align=32 words (r17.0)
//.declare V0091 (106)  rf=r size=256 type=ud alias=V0090+0 align=32 words (r17.0)
//.declare V0092 (107)  rf=r size=8 type=ud alias=V0088+0 align=32 words (r16.0)
//.declare V0093 (108)  rf=r size=128 type=d align=32 words (r21.0)
//.declare  (109)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (112)  rf=r size=4 type=ud align=32 words (r15.0)
//.declare  (113)  rf=r size=128 type=uw align=32 words (r23.0)
//.declare  (114)  rf=r size=128 type=uw align=32 words (r25.0)
//.declare  (117)  rf=r size=128 type=q align=32 words (r27.0)
//.declare  (118)  rf=r size=128 type=q align=32 words (r29.0)
//.declare  (121)  rf=r size=128 type=d alias=+0 align=32 words (r27.0)
//.declare  (122)  rf=r size=128 type=d alias=+0 align=32 words (r29.0)
//.declare r0 (123)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (124)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (125)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (126)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (127)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (128)  rf=r size=128 type=ud align=32 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0038    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0034    | :d       |    0x4 | r2+0xC   | inline+0xC       |
// | V0044    | :q       |    0x8 | r2+0x10  | inline+0x10      |
// | V0045    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0046    | :d       |    0x4 | r3       | cti+0x20         |
// | V0047    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0048    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0051    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0052    | :d       |    0x4 | r3+0x30  | cti+0x50         |
// | V0053    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0054    | :q       |    0x8 | r4       | cti+0x60         |
// | V0055    | :d       |    0x4 | r4+0x8   | cti+0x68         |
// | V0056    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0057    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0058    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0059    | :d       |    0x4 | r4+0x28  | cti+0x88         |
// | V0060    | :d       |    0x4 | r4+0x2C  | cti+0x8C         |
// | V0042    | :uq      |    0x8 | r4+0x30  | cti+0x90         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x80:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
// B002: Preds:{B001},  Succs:{B003, B006}
// _main:
(W)     mov (16|M0)              r3.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted,$1.dst}   //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r3.2<0;1,0>:uw   {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r15.0<1>:ud   r2.0<0;1,0>:ud    r3.1<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $3
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r3.2<0;1,0>:uw                      //  ALU pipe: int; $3
(W)     mach (1|M0)              r4.0<1>:d     r2.0<0;1,0>:ud    r3.1<0;1,0>:ud                      //  ALU pipe: int; 
        mov (16|M0)              r23.0<4>:uw   r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $9
        mov (16|M16)             r25.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $9
(W)     mov (1|M0)               r2.4<2>:ud    r15.0<0;1,0>:ud                  {Compacted,I@5}      //  ALU pipe: int; $3
(W)     mov (1|M0)               r2.5<2>:d     r4.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $7
        add (16|M0)              r27.0<1>:q    r2.2<0;1,0>:q     r23.0<4;1,0>:uw  {I@1}              //  ALU pipe: int; $9
        add (16|M16)             r29.0<1>:q    r2.2<0;1,0>:q     r25.0<4;1,0>:uw                     //  ALU pipe: int; $9
        mov (16|M0)              r5.0<1>:d     r27.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $10
        mov (16|M16)             r6.0<1>:d     r29.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $10
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r5.0<1;1,0>:ud    r2.3<0;1,0>:ud   {I@1}              //  ALU pipe: int; $11
(~f1.0) goto (32|M0)                         _0_008            _0_008                                //  ALU pipe: int; $12
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B006}
_0_009:
(W)     mov (1|M0)               r12.0<1>:uq   r4.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $18
        mov (16|M0)              r7.0<1>:d     r27.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $14
(W)     load.ugm.d32x1t.a64 (1|M0)  r11:1       [r12:1]            {I@2,$2} // ex_desc:0x0; desc:0x2108580 // $19
        mov (16|M16)             r8.0<1>:d     r29.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        cmp (32|M0)   (eq)f2.0   null<1>:d     r7.0<1;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $20
        mov (16|M0)              r9.0<1>:d     r27.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
        mov (16|M16)             r10.0<1>:d    r29.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $17
(f2.0)  cmp (32|M0)   (eq)f2.0   null<1>:d     r9.0<1;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $21
(f2.0)  cmp (32|M0)   (ne)f2.0   null<1>:d     r11.0<0;1,0>:d    0:w               {$2.dst}          //  ALU pipe: int; $23
(~f2.0) goto (32|M0)                         _0_008            _0_008                                //  ALU pipe: int; $25
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B006}
_0_010:
(W)     mov (1|M0)               r14.0<1>:uq   r4.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $27
(W)     load.ugm.d32x1t.a64 (1|M0)  r13:1       [r14:1]            {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $28
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r13.0<0;1,0>:ud   r4.11<0;1,0>:ud  {$3.dst}           //  ALU pipe: int; $29
(f0.0)  goto (32|M0)                         _0_008            _0_008                                //  ALU pipe: int; $30
// B005: [inDivergent],  Preds:{B004},  Succs:{B006}
_0_011:
(W)     mov (1|M0)               r16.0<1>:uq   r4.2<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $32
        mov (32|M0)              r21.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $35
        mov (16|M0)              r17.0<2>:f    r16.0<0;1,0>:f                   {I@2}                //  ALU pipe: float; $33
        mov (16|M16)             r19.0<2>:f    r16.0<0;1,0>:f                                        //  ALU pipe: float; $33
        mov (16|M0)              r17.1<2>:f    r16.1<0;1,0>:f                                        //  ALU pipe: float; $34
        mov (16|M16)             r19.1<2>:ud   r16.1<0;1,0>:ud                  {F@2}                //  ALU pipe: int; $34
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r17:4]          r21:2              {A@1,$4} // ex_desc:0x0; desc:0x800058B // $36
// B006: Preds:{B005, B004, B003, B002},  Succs:{}
_0_008:
        join (32|M0)                         L680                                                    // 
L680:
(W)     mov (16|M0)              r127.0<1>:f   r3.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $38
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$5} // wr:1+0, rd:0; end of thread // $38
L704:
(W)     mov (16|M0)              null<1>:ud    0x240B22FC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x608F9E07:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1C:ud                                               // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 45
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 10
//.allAtOneDistNum: 4
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 4
//.AfterReadTokenDepCount: 1
