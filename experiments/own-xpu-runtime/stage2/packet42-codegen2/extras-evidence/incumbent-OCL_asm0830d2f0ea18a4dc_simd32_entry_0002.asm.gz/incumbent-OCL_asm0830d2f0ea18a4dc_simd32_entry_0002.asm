//.kernel _ZTSZZNK11specialised6KernelILN2ng2OpE2ELi0ELi2560ELi4EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS5_5eventESaISD_EEENKUlRNS5_7handlerEE_clESJ_EUlNS5_2idILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 137417456 3927483612 -hashmovs1 0 2 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 137417456 3927483612 -hashmovs1 0 2 -GRFBumpUpNumber 2 "
//.instCount 415
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 20
//.spill flag load 20

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r123.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.2)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.1)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r123.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.3)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r123.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0046 (56)  rf=r size=4 type=d align=2 words (r3.3)
//.declare V0047 (57)  rf=r size=4 type=d align=2 words (r3.4)
//.declare V0048 (58)  rf=r size=4 type=d align=2 words (r3.5)
//.declare V0049 (59)  rf=r size=4 type=d align=2 words (r3.6)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.7)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0063 (73)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0064 (74)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0065 (75)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0066 (76)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0067 (77)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0069 (79)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0072 (82)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0074 (84)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0075 (85)  rf=r size=128 type=d align=32 words (r124.0)
//.declare V0076 (86)  rf=r size=4 type=d align=2 words (r5.0)
//.declare V0077 (87)  rf=r size=4 type=d align=2 words (r6.0)
//.declare V0078 (88)  rf=r size=4 type=d align=2 words (r7.0)
//.declare V0079 (89)  rf=r size=4 type=d align=2 words (r10.0)
//.declare V0080 (90)  rf=r size=4 type=ud alias=V0078+0 align=2 words (r7.0)
//.declare V0081 (91)  rf=r size=4 type=ud alias=V0076+0 align=2 words (r5.0)
//.declare V0082 (92)  rf=r size=4 type=d align=32 words (r8.0)
//.declare V0084 (94)  rf=r size=4 type=d align=2 words (r9.0)
//.declare P01 (95)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0085 (96)  rf=r size=128 type=ud alias=V0075+0 align=32 words (r124.0)
//.declare P02 (97)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P03 (98)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0086 (99)  rf=r size=4 type=ud alias=V0079+0 align=2 words (r10.0)
//.declare V0087 (100)  rf=r size=8 type=uq alias=V0069+0 align=4 words (r5.6)
//.declare V0088 (101)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0089 (102)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P04 (103)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0090 (104)  rf=r size=8 type=uq alias=V0066+0 align=4 words (r5.3)
//.declare V0091 (105)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare V0093 (107)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0094 (108)  rf=r size=256 type=ud alias=V0093+0 align=32 words (r6.0)
//.declare V0095 (109)  rf=r size=8 type=ud alias=V0091+0 align=32 words (r126.0)
//.declare V0096 (110)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0097 (111)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P05 (113)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0099 (114)  rf=r size=8 type=uq alias=V0068+0 align=4 words (r5.5)
//.declare V0100 (115)  rf=r size=8 type=uq align=32 words (r2.0)
//.declare V0101 (116)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0102 (117)  rf=r size=4 type=d align=2 words (r4.0)
//.declare P06 (118)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P07 (119)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0103 (120)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0104 (121)  rf=r size=128 type=ud alias=V0103+0 align=32 words (r4.0)
//.declare V0105 (122)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0106 (123)  rf=r size=128 type=ud alias=V0105+0 align=32 words (r6.0)
//.declare V0107 (124)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0108 (125)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0109 (126)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0111 (128)  rf=r size=128 type=ud alias=V0109+0 align=32 words (r13.0)
//.declare V0115 (132)  rf=r size=256 type=uq align=32 words (r62.0)
//.declare V0117 (134)  rf=r size=128 type=ud align=32 words (r72.0)
//.declare V0118 (135)  rf=r size=128 type=w alias=V0117+0 align=32 words (r72.0)
//.declare V0121 (138)  rf=r size=256 type=uq align=32 words (r110.0)
//.declare V0123 (140)  rf=r size=128 type=ud align=32 words (r52.0)
//.declare V0124 (141)  rf=r size=128 type=w alias=V0123+0 align=32 words (r52.0)
//.declare V0127 (144)  rf=r size=256 type=uq align=32 words (r114.0)
//.declare V0129 (146)  rf=r size=128 type=ud align=32 words (r54.0)
//.declare V0130 (147)  rf=r size=128 type=w alias=V0129+0 align=32 words (r54.0)
//.declare V0133 (150)  rf=r size=256 type=uq align=32 words (r68.0)
//.declare V0135 (152)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare V0136 (153)  rf=r size=128 type=w alias=V0135+0 align=32 words (r14.0)
//.declare V0139 (156)  rf=r size=256 type=uq align=32 words (r118.0)
//.declare V0141 (158)  rf=r size=128 type=ud align=32 words (r56.0)
//.declare V0142 (159)  rf=r size=128 type=w alias=V0141+0 align=32 words (r56.0)
//.declare V0145 (162)  rf=r size=256 type=uq align=32 words (r72.0)
//.declare V0147 (164)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare V0148 (165)  rf=r size=128 type=w alias=V0147+0 align=32 words (r20.0)
//.declare V0151 (168)  rf=r size=256 type=uq align=32 words (r76.0)
//.declare V0153 (170)  rf=r size=128 type=ud align=32 words (r28.0)
//.declare V0154 (171)  rf=r size=128 type=w alias=V0153+0 align=32 words (r28.0)
//.declare V0157 (174)  rf=r size=256 type=uq align=32 words (r46.0)
//.declare V0159 (176)  rf=r size=128 type=ud align=32 words (r100.0)
//.declare V0160 (177)  rf=r size=128 type=w alias=V0159+0 align=32 words (r100.0)
//.declare V0162 (179)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0163 (180)  rf=r size=128 type=f align=32 words (r113.0)
//.declare V0164 (181)  rf=r size=128 type=f alias=V0162+0 align=32 words (r76.0)
//.declare V0165 (182)  rf=r size=128 type=d align=32 words (r79.0)
//.declare V0167 (184)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0168 (185)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0169 (186)  rf=r size=128 type=f alias=V0167+0 align=32 words (r42.0)
//.declare V0170 (187)  rf=r size=128 type=d align=32 words (r85.0)
//.declare V0172 (189)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0173 (190)  rf=r size=128 type=f align=32 words (r82.0)
//.declare V0174 (191)  rf=r size=128 type=f alias=V0172+0 align=32 words (r44.0)
//.declare V0175 (192)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0177 (194)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0179 (196)  rf=r size=128 type=f alias=V0177+0 align=32 words (r22.0)
//.declare V0180 (197)  rf=r size=128 type=d align=32 words (r89.0)
//.declare V0182 (199)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0183 (200)  rf=r size=128 type=f align=32 words (r93.0)
//.declare V0184 (201)  rf=r size=128 type=f alias=V0182+0 align=32 words (r46.0)
//.declare V0185 (202)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0187 (204)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0188 (205)  rf=r size=128 type=f align=32 words (r54.0)
//.declare V0189 (206)  rf=r size=128 type=f alias=V0187+0 align=32 words (r24.0)
//.declare V0190 (207)  rf=r size=128 type=d align=32 words (r81.0)
//.declare V0192 (209)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0193 (210)  rf=r size=128 type=f align=32 words (r56.0)
//.declare V0194 (211)  rf=r size=128 type=f alias=V0192+0 align=32 words (r26.0)
//.declare V0195 (212)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0197 (214)  rf=r size=128 type=d align=32 words (r113.0)
//.declare V0199 (216)  rf=r size=128 type=f alias=V0197+0 align=32 words (r113.0)
//.declare V0200 (217)  rf=r size=128 type=d align=32 words (r91.0)
//.declare V0203 (220)  rf=r size=256 type=uq align=32 words (r3.0)
//.declare V0205 (222)  rf=r size=128 type=ud align=32 words (r58.0)
//.declare V0206 (223)  rf=r size=128 type=w alias=V0205+0 align=32 words (r58.0)
//.declare V0209 (226)  rf=r size=256 type=uq align=32 words (r80.0)
//.declare V0211 (228)  rf=r size=128 type=ud align=32 words (r42.0)
//.declare V0212 (229)  rf=r size=128 type=w alias=V0211+0 align=32 words (r42.0)
//.declare V0215 (232)  rf=r size=256 type=uq align=32 words (r84.0)
//.declare V0217 (234)  rf=r size=128 type=ud align=32 words (r44.0)
//.declare V0218 (235)  rf=r size=128 type=w alias=V0217+0 align=32 words (r44.0)
//.declare V0221 (238)  rf=r size=256 type=uq align=32 words (r50.0)
//.declare V0223 (240)  rf=r size=128 type=ud align=32 words (r102.0)
//.declare V0224 (241)  rf=r size=128 type=w alias=V0223+0 align=32 words (r102.0)
//.declare V0227 (244)  rf=r size=256 type=uq align=32 words (r88.0)
//.declare V0229 (246)  rf=r size=128 type=ud align=32 words (r46.0)
//.declare V0230 (247)  rf=r size=128 type=w alias=V0229+0 align=32 words (r46.0)
//.declare V0233 (250)  rf=r size=256 type=uq align=32 words (r54.0)
//.declare V0235 (252)  rf=r size=128 type=ud align=32 words (r104.0)
//.declare V0236 (253)  rf=r size=128 type=w alias=V0235+0 align=32 words (r104.0)
//.declare V0239 (256)  rf=r size=256 type=uq align=32 words (r58.0)
//.declare V0241 (258)  rf=r size=128 type=ud align=32 words (r106.0)
//.declare V0242 (259)  rf=r size=128 type=w alias=V0241+0 align=32 words (r106.0)
//.declare V0245 (262)  rf=r size=256 type=uq align=32 words (r42.0)
//.declare V0247 (264)  rf=r size=128 type=ud align=32 words (r66.0)
//.declare V0248 (265)  rf=r size=128 type=w alias=V0247+0 align=32 words (r66.0)
//.declare V0250 (267)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0251 (268)  rf=r size=128 type=f align=32 words (r95.0)
//.declare V0252 (269)  rf=r size=128 type=f alias=V0250+0 align=32 words (r50.0)
//.declare V0253 (270)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0255 (272)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0256 (273)  rf=r size=128 type=f align=32 words (r58.0)
//.declare V0257 (274)  rf=r size=128 type=f alias=V0255+0 align=32 words (r28.0)
//.declare V0258 (275)  rf=r size=128 type=d align=32 words (r83.0)
//.declare V0260 (277)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0261 (278)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0262 (279)  rf=r size=128 type=f alias=V0260+0 align=32 words (r30.0)
//.declare V0263 (280)  rf=r size=128 type=d align=32 words (r23.0)
//.declare V0265 (282)  rf=r size=128 type=d align=32 words (r115.0)
//.declare V0266 (283)  rf=r size=128 type=f align=32 words (r3.0)
//.declare V0267 (284)  rf=r size=128 type=f alias=V0265+0 align=32 words (r115.0)
//.declare V0268 (285)  rf=r size=128 type=d align=32 words (r87.0)
//.declare V0270 (287)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0271 (288)  rf=r size=128 type=f align=32 words (r68.0)
//.declare V0272 (289)  rf=r size=128 type=f alias=V0270+0 align=32 words (r32.0)
//.declare V0273 (290)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0275 (292)  rf=r size=128 type=d align=32 words (r117.0)
//.declare V0276 (293)  rf=r size=128 type=f align=32 words (r5.0)
//.declare V0277 (294)  rf=r size=128 type=f alias=V0275+0 align=32 words (r117.0)
//.declare V0278 (295)  rf=r size=128 type=d align=32 words (r77.0)
//.declare V0280 (297)  rf=r size=128 type=d align=32 words (r119.0)
//.declare V0281 (298)  rf=r size=128 type=f align=32 words (r7.0)
//.declare V0282 (299)  rf=r size=128 type=f alias=V0280+0 align=32 words (r119.0)
//.declare V0283 (300)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0285 (302)  rf=r size=128 type=d align=32 words (r95.0)
//.declare V0287 (304)  rf=r size=128 type=f alias=V0285+0 align=32 words (r95.0)
//.declare V0288 (305)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0291 (308)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0293 (310)  rf=r size=128 type=ud align=32 words (r60.0)
//.declare V0294 (311)  rf=r size=128 type=w alias=V0293+0 align=32 words (r60.0)
//.declare V0297 (314)  rf=r size=256 type=uq align=32 words (r92.0)
//.declare V0299 (316)  rf=r size=128 type=ud align=32 words (r48.0)
//.declare V0300 (317)  rf=r size=128 type=w alias=V0299+0 align=32 words (r48.0)
//.declare V0303 (320)  rf=r size=256 type=uq align=32 words (r96.0)
//.declare V0305 (322)  rf=r size=128 type=ud align=32 words (r50.0)
//.declare V0306 (323)  rf=r size=128 type=w alias=V0305+0 align=32 words (r50.0)
//.declare V0309 (326)  rf=r size=256 type=uq align=32 words (r62.0)
//.declare V0311 (328)  rf=r size=128 type=ud align=32 words (r108.0)
//.declare V0312 (329)  rf=r size=128 type=w alias=V0311+0 align=32 words (r108.0)
//.declare V0315 (332)  rf=r size=256 type=uq align=32 words (r84.0)
//.declare V0317 (334)  rf=r size=128 type=ud align=32 words (r102.0)
//.declare V0318 (335)  rf=r size=128 type=w alias=V0317+0 align=32 words (r102.0)
//.declare V0321 (338)  rf=r size=256 type=uq align=32 words (r56.0)
//.declare V0323 (340)  rf=r size=128 type=ud align=32 words (r92.0)
//.declare V0324 (341)  rf=r size=128 type=w alias=V0323+0 align=32 words (r92.0)
//.declare V0327 (344)  rf=r size=256 type=uq align=32 words (r60.0)
//.declare V0329 (346)  rf=r size=128 type=ud align=32 words (r94.0)
//.declare V0330 (347)  rf=r size=128 type=w alias=V0329+0 align=32 words (r94.0)
//.declare V0333 (350)  rf=r size=256 type=uq align=32 words (r38.0)
//.declare V0335 (352)  rf=r size=128 type=ud align=32 words (r76.0)
//.declare V0336 (353)  rf=r size=128 type=w alias=V0335+0 align=32 words (r76.0)
//.declare V0338 (355)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0339 (356)  rf=r size=128 type=f align=32 words (r100.0)
//.declare V0340 (357)  rf=r size=128 type=f alias=V0338+0 align=32 words (r52.0)
//.declare V0341 (358)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0343 (360)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0345 (362)  rf=r size=128 type=f alias=V0343+0 align=32 words (r38.0)
//.declare V0346 (363)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0348 (365)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0349 (366)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0350 (367)  rf=r size=128 type=f alias=V0348+0 align=32 words (r40.0)
//.declare V0351 (368)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0353 (370)  rf=r size=128 type=d align=32 words (r121.0)
//.declare V0355 (372)  rf=r size=128 type=f alias=V0353+0 align=32 words (r121.0)
//.declare V0356 (373)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0358 (375)  rf=r size=128 type=d align=32 words (r73.0)
//.declare V0359 (376)  rf=r size=128 type=f align=32 words (r93.0)
//.declare V0360 (377)  rf=r size=128 type=f alias=V0358+0 align=32 words (r73.0)
//.declare V0361 (378)  rf=r size=128 type=d align=32 words (r117.0)
//.declare V0363 (380)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0365 (382)  rf=r size=128 type=f alias=V0363+0 align=32 words (r57.0)
//.declare V0366 (383)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0368 (385)  rf=r size=128 type=d align=32 words (r59.0)
//.declare V0369 (386)  rf=r size=128 type=f align=32 words (r81.0)
//.declare V0370 (387)  rf=r size=128 type=f alias=V0368+0 align=32 words (r59.0)
//.declare V0371 (388)  rf=r size=128 type=d align=32 words (r110.0)
//.declare V0373 (390)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0375 (392)  rf=r size=128 type=f alias=V0373+0 align=32 words (r47.0)
//.declare V0376 (393)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0379 (396)  rf=r size=256 type=uq align=32 words (r88.0)
//.declare V0381 (398)  rf=r size=128 type=ud align=32 words (r104.0)
//.declare V0382 (399)  rf=r size=128 type=w alias=V0381+0 align=32 words (r104.0)
//.declare V0385 (402)  rf=r size=256 type=uq align=32 words (r64.0)
//.declare V0387 (404)  rf=r size=128 type=ud align=32 words (r96.0)
//.declare V0388 (405)  rf=r size=128 type=w alias=V0387+0 align=32 words (r96.0)
//.declare V0391 (408)  rf=r size=256 type=uq align=32 words (r68.0)
//.declare V0393 (410)  rf=r size=128 type=ud align=32 words (r98.0)
//.declare V0394 (411)  rf=r size=128 type=w alias=V0393+0 align=32 words (r98.0)
//.declare V0397 (414)  rf=r size=256 type=uq align=32 words (r42.0)
//.declare V0399 (416)  rf=r size=128 type=ud align=32 words (r78.0)
//.declare V0400 (417)  rf=r size=128 type=w alias=V0399+0 align=32 words (r78.0)
//.declare V0403 (420)  rf=r size=256 type=uq align=32 words (r72.0)
//.declare V0405 (422)  rf=r size=128 type=ud align=32 words (r100.0)
//.declare V0406 (423)  rf=r size=128 type=w alias=V0405+0 align=32 words (r100.0)
//.declare V0409 (426)  rf=r size=256 type=uq align=32 words (r46.0)
//.declare V0411 (428)  rf=r size=128 type=ud align=32 words (r80.0)
//.declare V0412 (429)  rf=r size=128 type=w alias=V0411+0 align=32 words (r80.0)
//.declare V0415 (432)  rf=r size=256 type=uq align=32 words (r50.0)
//.declare V0417 (434)  rf=r size=128 type=ud align=32 words (r82.0)
//.declare V0418 (435)  rf=r size=128 type=w alias=V0417+0 align=32 words (r82.0)
//.declare V0421 (438)  rf=r size=256 type=uq align=32 words (r29.0)
//.declare V0423 (440)  rf=r size=128 type=ud align=32 words (r54.0)
//.declare V0424 (441)  rf=r size=128 type=w alias=V0423+0 align=32 words (r54.0)
//.declare V0426 (443)  rf=r size=128 type=d align=32 words (r79.0)
//.declare V0427 (444)  rf=r size=128 type=f align=32 words (r95.0)
//.declare V0428 (445)  rf=r size=128 type=f alias=V0426+0 align=32 words (r79.0)
//.declare V0429 (446)  rf=r size=128 type=d align=32 words (r119.0)
//.declare V0431 (448)  rf=r size=128 type=d align=32 words (r61.0)
//.declare V0432 (449)  rf=r size=128 type=f align=32 words (r83.0)
//.declare V0433 (450)  rf=r size=128 type=f alias=V0431+0 align=32 words (r61.0)
//.declare V0434 (451)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0436 (453)  rf=r size=128 type=d align=32 words (r65.0)
//.declare V0437 (454)  rf=r size=128 type=f align=32 words (r85.0)
//.declare V0438 (455)  rf=r size=128 type=f alias=V0436+0 align=32 words (r65.0)
//.declare V0439 (456)  rf=r size=128 type=d align=32 words (r112.0)
//.declare V0441 (458)  rf=r size=128 type=d align=32 words (r51.0)
//.declare V0443 (460)  rf=r size=128 type=f alias=V0441+0 align=32 words (r51.0)
//.declare V0444 (461)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0446 (463)  rf=r size=128 type=d align=32 words (r67.0)
//.declare V0447 (464)  rf=r size=128 type=f align=32 words (r89.0)
//.declare V0448 (465)  rf=r size=128 type=f alias=V0446+0 align=32 words (r67.0)
//.declare V0449 (466)  rf=r size=128 type=d align=32 words (r114.0)
//.declare V0451 (468)  rf=r size=128 type=d align=32 words (r53.0)
//.declare V0452 (469)  rf=r size=128 type=f align=32 words (r69.0)
//.declare V0453 (470)  rf=r size=128 type=f alias=V0451+0 align=32 words (r53.0)
//.declare V0454 (471)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0456 (473)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0457 (474)  rf=r size=128 type=f align=32 words (r71.0)
//.declare V0458 (475)  rf=r size=128 type=f alias=V0456+0 align=32 words (r55.0)
//.declare V0459 (476)  rf=r size=128 type=d align=32 words (r106.0)
//.declare V0461 (478)  rf=r size=128 type=d align=32 words (r43.0)
//.declare V0463 (480)  rf=r size=128 type=f alias=V0461+0 align=32 words (r43.0)
//.declare P08 (481)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0464 (482)  rf=r size=128 type=f align=32 words (r115.0)
//.declare V0465 (483)  rf=r size=128 type=f align=32 words (r13.0)
//.declare P09 (484)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0466 (485)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0467 (486)  rf=r size=128 type=f align=32 words (r117.0)
//.declare P10 (487)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0468 (488)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0469 (489)  rf=r size=128 type=f align=32 words (r119.0)
//.declare P11 (490)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0470 (491)  rf=r size=128 type=f align=32 words (r9.0)
//.declare V0471 (492)  rf=r size=128 type=f align=32 words (r102.0)
//.declare P12 (493)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0472 (494)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0473 (495)  rf=r size=128 type=f align=32 words (r121.0)
//.declare P13 (496)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0474 (497)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0475 (498)  rf=r size=128 type=f align=32 words (r104.0)
//.declare P14 (499)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0476 (500)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0477 (501)  rf=r size=128 type=f align=32 words (r106.0)
//.declare P15 (502)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0478 (503)  rf=r size=128 type=f align=32 words (r111.0)
//.declare V0479 (504)  rf=r size=128 type=f align=32 words (r74.0)
//.declare P16 (505)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0480 (506)  rf=r size=128 type=f align=32 words (r78.0)
//.declare V0481 (507)  rf=r size=128 type=f align=32 words (r3.0)
//.declare P17 (508)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0482 (509)  rf=r size=128 type=f align=32 words (r48.0)
//.declare V0483 (510)  rf=r size=128 type=f align=32 words (r108.0)
//.declare P18 (511)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0484 (512)  rf=r size=128 type=f align=32 words (r87.0)
//.declare V0485 (513)  rf=r size=128 type=f align=32 words (r105.0)
//.declare P19 (514)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0486 (515)  rf=r size=128 type=f align=32 words (r63.0)
//.declare V0487 (516)  rf=r size=128 type=f align=32 words (r97.0)
//.declare P20 (517)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0488 (518)  rf=r size=128 type=f align=32 words (r91.0)
//.declare P21 (520)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0490 (521)  rf=r size=128 type=f align=32 words (r75.0)
//.declare P22 (523)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0492 (524)  rf=r size=128 type=f align=32 words (r77.0)
//.declare V0493 (525)  rf=r size=128 type=f align=32 words (r101.0)
//.declare P23 (526)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0494 (527)  rf=r size=128 type=f align=32 words (r49.0)
//.declare P24 (529)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0497 (531)  rf=r size=128 type=f align=32 words (r21.0)
//.declare P25 (532)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0498 (533)  rf=r size=128 type=f align=32 words (r5.0)
//.declare V0499 (534)  rf=r size=128 type=f align=32 words (r15.0)
//.declare P26 (535)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0500 (536)  rf=r size=128 type=f align=32 words (r7.0)
//.declare V0501 (537)  rf=r size=128 type=f align=32 words (r17.0)
//.declare P27 (538)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0502 (539)  rf=r size=128 type=f align=32 words (r111.0)
//.declare V0503 (540)  rf=r size=128 type=f align=32 words (r9.0)
//.declare P28 (541)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0505 (543)  rf=r size=128 type=f align=32 words (r45.0)
//.declare P29 (544)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0506 (545)  rf=r size=128 type=f align=32 words (r103.0)
//.declare V0507 (546)  rf=r size=128 type=f align=32 words (r111.0)
//.declare P30 (547)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0508 (548)  rf=r size=128 type=f align=32 words (r107.0)
//.declare V0509 (549)  rf=r size=128 type=f align=32 words (r113.0)
//.declare P31 (550)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0510 (551)  rf=r size=128 type=f align=32 words (r99.0)
//.declare V0511 (552)  rf=r size=128 type=f align=32 words (r109.0)
//.declare P32 (553)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0513 (555)  rf=r size=128 type=f align=32 words (r25.0)
//.declare P33 (556)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0514 (557)  rf=r size=128 type=f align=32 words (r19.0)
//.declare V0515 (558)  rf=r size=128 type=f align=32 words (r23.0)
//.declare P34 (559)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0516 (560)  rf=r size=128 type=f align=32 words (r115.0)
//.declare V0517 (561)  rf=r size=128 type=f align=32 words (r117.0)
//.declare P35 (562)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P36 (565)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0521 (567)  rf=r size=128 type=f align=32 words (r27.0)
//.declare P37 (568)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P38 (571)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0525 (573)  rf=r size=128 type=f align=32 words (r119.0)
//.declare V0526 (574)  rf=r size=8 type=q alias=V0034+0 align=4 words (r2.3)
//.declare V0529 (577)  rf=r size=256 type=q align=32 words (r37.0)
//.declare V0530 (578)  rf=r size=256 type=uq alias=V0529+0 align=32 words (r37.0)
//.declare P39 (579)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0532 (581)  rf=r size=256 type=uq align=32 words (r1.0)
//.declare V0533 (582)  rf=r size=256 type=ud alias=V0532+0 align=32 words (r1.0)
//.declare V0534 (583)  rf=r size=128 type=d align=32 words (r5.0)
//.declare  (584)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (585)  rf=r size=128 type=ud align=32 words (r21.0)
//.declare  (586)  rf=r size=128 type=ud align=32 words (r19.0)
//.declare  (587)  rf=r size=128 type=ud align=32 words (r25.0)
//.declare  (588)  rf=r size=128 type=ud align=32 words (r23.0)
//.declare  (591)  rf=r size=128 type=q align=32 words (r29.0)
//.declare  (592)  rf=r size=128 type=q align=32 words (r27.0)
//.declare  (593)  rf=r size=128 type=q align=32 words (r36.0)
//.declare  (594)  rf=r size=128 type=q align=32 words (r34.0)
//.declare  (659)  rf=r size=128 type=q align=32 words (r33.0)
//.declare  (660)  rf=r size=128 type=q align=32 words (r31.0)
//.declare  (661)  rf=r size=128 type=uq alias=+0 align=32 words (r36.0)
//.declare  (662)  rf=r size=128 type=uq alias=+0 align=32 words (r34.0)
//.declare  (663)  rf=r size=4 type=uw align=2 words (r76.0)
//.declare  (664)  rf=r size=4 type=uw align=2 words (r75.0)
//.declare  (665)  rf=r size=4 type=uw align=2 words (r97.0)
//.declare  (666)  rf=r size=4 type=uw align=2 words (r74.0)
//.declare  (667)  rf=r size=4 type=uw align=2 words (r94.0)
//.declare  (668)  rf=r size=4 type=uw align=2 words (r93.0)
//.declare  (669)  rf=r size=4 type=uw align=2 words (r35.0)
//.declare  (670)  rf=r size=4 type=uw align=2 words (r41.0)
//.declare  (671)  rf=r size=4 type=uw align=2 words (r36.0)
//.declare  (672)  rf=r size=4 type=uw align=2 words (r116.0)
//.declare  (673)  rf=r size=4 type=uw align=2 words (r2.0)
//.declare  (674)  rf=r size=4 type=uw align=2 words (r1.0)
//.declare  (675)  rf=r size=4 type=uw align=2 words (r30.0)
//.declare  (676)  rf=r size=4 type=uw align=2 words (r121.0)
//.declare  (677)  rf=r size=4 type=uw align=2 words (r29.0)
//.declare  (678)  rf=r size=4 type=uw align=2 words (r98.0)
//.declare  (679)  rf=r size=4 type=uw align=2 words (r110.0)
//.declare  (680)  rf=r size=4 type=uw align=2 words (r99.0)
//.declare  (681)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (682)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (683)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (684)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (685)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (686)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (687)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (688)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (689)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (690)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (691)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (692)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (693)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (694)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (695)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (696)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (697)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (698)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (699)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (700)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (701)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (702)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (703)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (704)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (705)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (706)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (707)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (708)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (709)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (710)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (711)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (712)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (713)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (714)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (715)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (716)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (717)  rf=r size=4 type=uw align=2 words (r33.0)
//.declare  (718)  rf=r size=4 type=uw align=2 words (r42.0)
//.declare  (719)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (720)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (721)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (722)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare r0 (723)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (724)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (725)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (726)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (727)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (728)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (729)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0034    | :uq      |    0x8 | r2+0x18  | inline+0x18      |
// | V0043    | :d       |    0x4 | r3       | cti+0x20         |
// | V0044    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// | V0045    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// | V0046    | :d       |    0x4 | r3+0xC   | cti+0x2C         |
// | V0047    | :d       |    0x4 | r3+0x10  | cti+0x30         |
// | V0048    | :d       |    0x4 | r3+0x14  | cti+0x34         |
// | V0049    | :d       |    0x4 | r3+0x18  | cti+0x38         |
// | V0050    | :d       |    0x4 | r3+0x1C  | cti+0x3C         |
// | V0051    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0052    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0053    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0054    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0055    | :q       |    0x8 | r4       | cti+0x60         |
// | V0056    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0057    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0058    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0059    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0060    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0061    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0062    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0063    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0064    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0065    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0066    | :q       |    0x8 | r5+0x18  | cti+0xB8         |
// | V0067    | :q       |    0x8 | r5+0x20  | cti+0xC0         |
// | V0068    | :q       |    0x8 | r5+0x28  | cti+0xC8         |
// | V0069    | :q       |    0x8 | r5+0x30  | cti+0xD0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B009}
// _main:
(W)     mov (16|M0)              r123.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r123.2<0;1,0>:uw {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r4.0<1>:d     r2.3<0;1,0>:d     r123.1<0;1,0>:d  {Compacted,$1.dst} //  ALU pipe: int; $4
(W)     shl (1|M0)               r5.0<1>:d     r3.1<0;1,0>:d     2:w               {Compacted,$2.dst} //  ALU pipe: int; $5
        add3 (32|M0)             r124.0<1>:d   r4.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {@2,$0.dst} //  ALU pipe: int; $4
(W)     asr (1|M0)               r6.0<1>:d     r5.0<0;1,0>:d     31:w               {Compacted,I@2}  //  ALU pipe: int; $6
(W)     mul (1|M0)               r7.0<1>:ud    r5.0<0;1,0>:ud    0x50:uw              {Compacted}    //  ALU pipe: int; $7
(W)     mul (1|M0)               acc0.0<1>:ud  r5.0<0;1,0>:ud    0x50:uw                             //  ALU pipe: int; $8
(W)     mul (1|M0)               r9.0<1>:d     r6.0<0;1,0>:d     0x50:uw              {I@3}          //  ALU pipe: int; $11
(W)     mach (1|M0)              r8.0<1>:d     r5.0<0;1,0>:ud    0x50:ud                             //  ALU pipe: int; 
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r7.0<0;1,0>:ud    r124.0<1;1,0>:ud {I@4}              //  ALU pipe: int; $14
(W)     add (1|M0)               r10.0<1>:d    r8.0<0;1,0>:d     r9.0<0;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $13
(f2.0)  cmp (32|M0)   (eq)f2.0   null<1>:d     r10.0<0;1,0>:d    0:w               {I@1}             //  ALU pipe: int; $15
(~f2.0) cmp (32|M0)   (gt)f2.0   null<1>:ud    r10.0<0;1,0>:ud   0x0:uw                              //  ALU pipe: int; $17
(~f2.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $19
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B009}
_0_013:
(W)     mov (1|M0)               r2.0<1>:uq    r5.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $21
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r2:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $22
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $23
(f1.0)  goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $24
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B009}
_0_014:
(W)     mov (1|M0)               r126.0<1>:uq  r5.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $26
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $29
        mov (16|M0)              r6.0<2>:f     r126.0<0;1,0>:f                  {I@2}                //  ALU pipe: float; $27
        mov (16|M16)             r8.0<2>:f     r126.0<0;1,0>:f                                       //  ALU pipe: float; $27
        mov (16|M0)              r6.1<2>:f     r126.1<0;1,0>:f                                       //  ALU pipe: float; $28
        mov (16|M16)             r8.1<2>:ud    r126.1<0;1,0>:ud                 {F@2}                //  ALU pipe: int; $28
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$4} // ex_desc:0x0; desc:0x8200599 // $30
        cmp (32|M0)   (eq)f0.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$4.dst}          //  ALU pipe: int; $32
(~f0.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $33
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B007}
_0_015:
(W)     mov (1|M0)               r2.0<1>:uq    r5.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $35
(W)     add (1|M0)               r4.0<1>:d     r3.6<0;1,0>:d     -r3.1<0;1,0>:d                      //  ALU pipe: int; $37
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r2:1]             {I@1,$5} // ex_desc:0x0; desc:0x2108580 // $36
(W)     cmp (32|M0)   (gt)f3.0   null<1>:d     r3.0<0;1,0>:d     r4.0<0;1,0>:d    {$5.dst}           //  ALU pipe: int; $38
(W&~f3.0) cmp (32|M0) (lt)f3.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $39
(W&f3.0) jmpi                                _0_016                                                  //  ALU pipe: int; $41
// B006: [inDivergent],  Preds:{B005},  Succs:{B009}
_0_017:
(W)     mul (16|M0)              acc0.0<1>:ud  r124.0<1;1,0>:ud  0xCCCD:uw                           //  ALU pipe: int; $43
        mach (16|M0)             r4.0<1>:ud    r124.0<1;1,0>:ud  0xCCCCCCCD:ud                       //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r125.0<1;1,0>:ud  0xCCCD:uw                           //  ALU pipe: int; $43
        mach (16|M16)            r5.0<1>:ud    r125.0<1;1,0>:ud  0xCCCCCCCD:ud                       //  ALU pipe: int; $44
        shr (32|M0)              r6.0<1>:ud    r4.0<1;1,0>:ud    6:w               {I@1}             //  ALU pipe: int; $44
        mad (32|M0)              r8.0<1>:d     r124.0<1;0>:d     r6.0<1;0>:d       -80:w               {I@1} //  ALU pipe: int; $45
        shl (32|M0)              r11.0<1>:d    r8.0<1;1,0>:d     5:w               {Compacted,I@1}   //  ALU pipe: int; $46
        mad (32|M0)              r13.0<1>:d    r11.0<1;0>:d      r6.0<1;0>:d       2560:w               {I@1} //  ALU pipe: int; $47
        mov (16|M16)             r19.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $49
        mov (16|M0)              r21.0<2>:ud   r13.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $49
        shl (16|M16)             r27.0<1>:q    r19.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $49
        shl (16|M0)              r29.0<1>:q    r21.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $49
        add (16|M16)             r34.0<1>:q    r27.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $50
        add (16|M0)              r36.0<1>:q    r29.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $50
        add (16|M16)             r44.0<1>:q    r34.0<1;1,0>:q    30:w               {Compacted,I@2}  //  ALU pipe: int; $119
        add (16|M0)              r42.0<1>:q    r36.0<1;1,0>:q    30:w               {Compacted,I@2}  //  ALU pipe: int; $119
        load.ugm.d16u32.a64 (32|M0)  r66:2      [r42:4]            {I@1,$6} // ex_desc:0x0; desc:0x8200B80 // $121
        add (16|M16)             r48.0<1>:q    r34.0<1;1,0>:q    14:w               {Compacted}      //  ALU pipe: int; $71
        add (16|M0)              r46.0<1>:q    r36.0<1;1,0>:q    14:w               {Compacted}      //  ALU pipe: int; $71
        load.ugm.d16u32.a64 (32|M0)  r100:2     [r46:4]            {I@1,$7} // ex_desc:0x0; desc:0x8200B80 // $73
        add (16|M16)             r52.0<1>:q    r34.0<1;1,0>:q    22:w               {Compacted}      //  ALU pipe: int; $107
        add (16|M0)              r50.0<1>:q    r36.0<1;1,0>:q    22:w               {Compacted}      //  ALU pipe: int; $107
        load.ugm.d16u32.a64 (32|M0)  r102:2     [r50:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200B80 // $109
        add (16|M16)             r56.0<1>:q    r34.0<1;1,0>:q    26:w               {Compacted}      //  ALU pipe: int; $113
        add (16|M0)              r54.0<1>:q    r36.0<1;1,0>:q    26:w               {Compacted}      //  ALU pipe: int; $113
        load.ugm.d16u32.a64 (32|M0)  r104:2     [r54:4]            {I@1,$9} // ex_desc:0x0; desc:0x8200B80 // $115
        add (16|M16)             r64.0<1>:q    r34.0<1;1,0>:q    38:w               {Compacted}      //  ALU pipe: int; $155
        add (16|M0)              r62.0<1>:q    r36.0<1;1,0>:q    38:w               {Compacted}      //  ALU pipe: int; $155
        load.ugm.d16u32.a64 (32|M0)  r108:2     [r62:4]            {I@1,$10} // ex_desc:0x0; desc:0x8200B80 // $157
        add (16|M16)             r74.0<1>:q    r34.0<1;1,0>:q    10:w               {Compacted}      //  ALU pipe: int; $65
        add (16|M16)             r78.0<1>:q    r34.0<1;1,0>:q    12:w               {Compacted}      //  ALU pipe: int; $68
        add (16|M0)              r72.0<1>:q    r36.0<1;1,0>:q    10:w               {Compacted}      //  ALU pipe: int; $65
        add (16|M0)              r76.0<1>:q    r36.0<1;1,0>:q    12:w               {Compacted}      //  ALU pipe: int; $68
        add (32|M0)              r15.0<1>:d    r11.0<1;1,0>:d    15:w               {Compacted}      //  ALU pipe: int; $142
        add (16|M16)             r82.0<1>:q    r34.0<1;1,0>:q    18:w               {Compacted}      //  ALU pipe: int; $101
        add (16|M16)             r86.0<1>:q    r34.0<1;1,0>:q    20:w               {Compacted}      //  ALU pipe: int; $104
        add (16|M16)             r90.0<1>:q    r34.0<1;1,0>:q    24:w               {Compacted}      //  ALU pipe: int; $110
        add (16|M0)              r80.0<1>:q    r36.0<1;1,0>:q    18:w               {Compacted}      //  ALU pipe: int; $101
        add (16|M0)              r84.0<1>:q    r36.0<1;1,0>:q    20:w               {Compacted}      //  ALU pipe: int; $104
        add (16|M0)              r88.0<1>:q    r36.0<1;1,0>:q    24:w               {Compacted}      //  ALU pipe: int; $110
        load.ugm.d16u32.a64 (32|M0)  r20:2      [r72:4]            {I@7,$11} // ex_desc:0x0; desc:0x8200B80 // $67
        load.ugm.d16u32.a64 (32|M0)  r28:2      [r76:4]            {I@7,$12} // ex_desc:0x0; desc:0x8200B80 // $70
        add (16|M16)             r60.0<1>:q    r34.0<1;1,0>:q    28:w               {Compacted}      //  ALU pipe: int; $116
        add (16|M16)             r94.0<1>:q    r34.0<1;1,0>:q    34:w               {Compacted}      //  ALU pipe: int; $149
        add (16|M16)             r98.0<1>:q    r34.0<1;1,0>:q    36:w               {Compacted}      //  ALU pipe: int; $152
        add (16|M16)             r116.0<1>:q   r34.0<1;1,0>:q    4:w               {Compacted}       //  ALU pipe: int; $56
        add (16|M0)              r58.0<1>:q    r36.0<1;1,0>:q    28:w               {Compacted}      //  ALU pipe: int; $116
        add (16|M0)              r92.0<1>:q    r36.0<1;1,0>:q    34:w               {Compacted}      //  ALU pipe: int; $149
        add (16|M0)              r96.0<1>:q    r36.0<1;1,0>:q    36:w               {Compacted}      //  ALU pipe: int; $152
        add (16|M0)              r114.0<1>:q   r36.0<1;1,0>:q    4:w               {Compacted}       //  ALU pipe: int; $56
        load.ugm.d16u32.a64 (32|M0)  r42:2      [r80:4]            {I@7,$13} // ex_desc:0x0; desc:0x8200B80 // $103
        load.ugm.d16u32.a64 (32|M0)  r44:2      [r84:4]            {I@7,$14} // ex_desc:0x0; desc:0x8200B80 // $106
        load.ugm.d16u32.a64 (32|M0)  r46:2      [r88:4]            {I@7,$15} // ex_desc:0x0; desc:0x8200B80 // $112
        add (16|M16)             r70.0<1>:q    r34.0<1;1,0>:q    6:w               {Compacted}       //  ALU pipe: int; $59
        add (16|M16)             r5.0<1>:q     r34.0<1;1,0>:q    16:w               {Compacted}      //  ALU pipe: int; $98
        add (16|M0)              r68.0<1>:q    r36.0<1;1,0>:q    6:w               {Compacted}       //  ALU pipe: int; $59
        add (16|M0)              r3.0<1>:q     r36.0<1;1,0>:q    16:w               {Compacted}      //  ALU pipe: int; $98
        load.ugm.d16u32.a64 (32|M0)  r106:2     [r58:4]            {I@7,$0} // ex_desc:0x0; desc:0x8200B80 // $118
        load.ugm.d16u32.a64 (32|M0)  r48:2      [r92:4]            {I@7,$1} // ex_desc:0x0; desc:0x8200B80 // $151
        load.ugm.d16u32.a64 (32|M0)  r50:2      [r96:4]            {I@6,$2} // ex_desc:0x0; desc:0x8200B80 // $154
        load.ugm.d16u32.a64 (32|M0)  r54:2      [r114:4]           {I@5,$3} // ex_desc:0x0; desc:0x8200B80 // $58
        cmp (32|M0)   (lt)f0.0   null<1>:d     r15.0<1;1,0>:d    2560:w                              //  ALU pipe: int; $262
        load.ugm.d16u32.a64 (32|M0)  r58:2      [r3:4]             {I@2,$4} // ex_desc:0x0; desc:0x8200B80 // $100
        load.ugm.d16u32.a64 (32|M0)  r14:2      [r68:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200B80 // $61
        add (16|M16)             r112.0<1>:q   r34.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $53
        add (16|M0)              r110.0<1>:q   r36.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $53
        add (16|M16)             r9.0<1>:q     r34.0<1;1,0>:q    32:w               {Compacted}      //  ALU pipe: int; $146
        add (16|M0)              r7.0<1>:q     r36.0<1;1,0>:q    32:w               {Compacted}      //  ALU pipe: int; $146
        load.ugm.d16u32.a64 (32|M0)  r52:2      [r110:4]           {I@3,$6} // ex_desc:0x0; desc:0x8200B80 // $55
        mov (16|M16)             r64.0<1>:uq   r34.0<1;1,0>:uq                  {Compacted,$10.src}  //  ALU pipe: int; $51
        mov (16|M0)              r62.0<1>:uq   r36.0<1;1,0>:uq                  {Compacted}          //  ALU pipe: int; $51
        load.ugm.d16u32.a64 (32|M0)  r60:2      [r7:4]             {I@3,$7} // ex_desc:0x0; desc:0x8200B80 // $148
        load.ugm.d16u32.a64 (32|M0)  r72:2      [r62:4]            {I@1,$9} // ex_desc:0x0; desc:0x8200B80 // $52
        add (32|M0)              r38.0<1>:d    r11.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $82
        add (16|M16)             r120.0<1>:q   r34.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $62
        add (16|M0)              r118.0<1>:q   r36.0<1;1,0>:q    8:w               {Compacted}       //  ALU pipe: int; $62
        load.ugm.d16u32.a64 (32|M0)  r56:2      [r118:4]           {I@1,$8} // ex_desc:0x0; desc:0x8200B80 // $64
        cmp (32|M0)   (lt)f3.0   null<1>:d     r38.0<1;1,0>:d    2560:w                              //  ALU pipe: int; $244
        sync.nop                             null                             {Compacted,$13.src}    // $76
        add (32|M0)              r79.0<1>:d    r11.0<1;1,0>:d    1:w               {Compacted,$12.src} //  ALU pipe: int; $76
(W)     mov (1|M0)               r93.0<1>:ud   f3.0<0;1,0>:ud                   {Compacted,$1.src}   //  ALU pipe: int; $244
        cmp (32|M0)   (lt)f3.0   null<1>:d     r79.0<1;1,0>:d    2560:w               {I@2}          //  ALU pipe: int; $241
        add (32|M0)              r81.0<1>:d    r11.0<1;1,0>:d    6:w               {Compacted}       //  ALU pipe: int; $91
(W)     mov (1|M0)               r98.0<1>:ud   f3.0<0;1,0>:ud                   {Compacted,$2.src}   //  ALU pipe: int; $241
        cmp (32|M0)   (lt)f3.0   null<1>:d     r81.0<1;1,0>:d    2560:w               {I@2}          //  ALU pipe: int; $292
        add (32|M0)              r83.0<1>:d    r11.0<1;1,0>:d    10:w               {Compacted,$14.src} //  ALU pipe: int; $127
        add (32|M0)              r17.0<1>:d    r11.0<1;1,0>:d    7:w               {Compacted}       //  ALU pipe: int; $94
(W)     mov (1|M0)               r99.0<1>:ud   f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $292
        cmp (32|M0)   (lt)f3.0   null<1>:d     r83.0<1;1,0>:d    2560:w               {I@3}          //  ALU pipe: int; $295
(W)     mov (1|M0)               r33.0<1>:ud   f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $262
        shl (32|M0)              r95.0<1>:d    r66.0<1;1,0>:ud   16:w               {$6.dst}         //  ALU pipe: int; $143
        cmp (32|M0)   (lt)f2.0   null<1>:d     r17.0<1;1,0>:d    2560:w               {I@5}          //  ALU pipe: int; $250
(W)     mov (1|M0)               r110.0<1>:ud  f3.0<0;1,0>:ud                   {Compacted,$6.src}   //  ALU pipe: int; $295
(W)     mov (1|M0)               f3.0<1>:ud    r33.0<0;1,0>:ud                  {Compacted,I@4}      //  ALU pipe: int; $263
        add (32|M0)              r23.0<1>:d    r11.0<1;1,0>:d    11:w               {Compacted}      //  ALU pipe: int; $130
        mul (32|M0)              acc2.0<1>:f   r95.0<1;1,0>:f    r95.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $144
(W)     mov (1|M0)               r74.0<1>:ud   f2.0<0;1,0>:ud                   {Compacted,$11.src}  //  ALU pipe: int; $250
        sync.nop                             null                             {Compacted,$3.src}     // $95
        shl (32|M0)              r113.0<1>:d   r100.0<1;1,0>:ud  16:w               {$7.dst}         //  ALU pipe: int; $95
        cmp (32|M0)   (lt)f1.0   null<1>:d     r23.0<1;1,0>:d    2560:w               {I@3}          //  ALU pipe: int; $256
(f3.0)  sel (32|M0)              r111.0<1>:f   acc2.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $263
(W)     mov (1|M0)               f3.0<1>:ud    r74.0<0;1,0>:ud                  {Compacted,A@1}      //  ALU pipe: int; $251
        add (32|M0)              r25.0<1>:d    r11.0<1;1,0>:d    13:w               {Compacted}      //  ALU pipe: int; $136
        mul (32|M0)              acc2.0<1>:f   r113.0<1;1,0>:f   r113.0<1;1,0>:f  {Compacted,I@4}    //  ALU pipe: float; $96
        shl (32|M0)              r115.0<1>:d   r102.0<1;1,0>:ud  16:w               {$8.dst}         //  ALU pipe: int; $131
(W)     mov (1|M0)               r75.0<1>:ud   f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $256
        cmp (32|M0)   (lt)f0.0   null<1>:d     r25.0<1;1,0>:d    2560:w               {I@3}          //  ALU pipe: int; $259
(f3.0)  sel (32|M0)              r9.0<1>:f     acc2.0<1;1,0>:f   0x0:f               {$7.src}        //  ALU pipe: float; $251
(W)     mov (1|M0)               f3.0<1>:ud    r75.0<0;1,0>:ud                  {Compacted,A@1}      //  ALU pipe: int; $257
        add (32|M0)              r40.0<1>:d    r11.0<1;1,0>:d    5:w               {Compacted}       //  ALU pipe: int; $88
        mul (32|M0)              r3.0<1>:f     r115.0<1;1,0>:f   r115.0<1;1,0>:f  {Compacted,$4.src} //  ALU pipe: float; $132
        sync.nop                             null                             {Compacted,$8.src}     // $137
        shl (32|M0)              r117.0<1>:d   r104.0<1;1,0>:ud  16:w               {$9.dst}         //  ALU pipe: int; $137
(W)     mov (1|M0)               r76.0<1>:ud   f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $259
        add (32|M0)              r31.0<1>:d    r11.0<1;1,0>:d    19:w               {Compacted}      //  ALU pipe: int; $178
        cmp (32|M0)   (lt)f1.0   null<1>:d     r40.0<1;1,0>:d    2560:w               {I@4}          //  ALU pipe: int; $247
(f3.0)  sel (32|M0)              r16.0<1>:f    r3.0<1;1,0>:f     0x0:f               {F@1}           //  ALU pipe: float; $257
(W)     mov (1|M0)               f3.0<1>:ud    r76.0<0;1,0>:ud                  {Compacted,A@1}      //  ALU pipe: int; $260
        shl (32|M0)              r121.0<1>:d   r108.0<1;1,0>:ud  16:w               {$10.dst}        //  ALU pipe: int; $179
        mul (32|M0)              r5.0<1>:f     r117.0<1;1,0>:f   r117.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $138
        cmp (32|M0)   (lt)f2.0   null<1>:d     r31.0<1;1,0>:d    2560:w               {I@4}          //  ALU pipe: int; $268
        add (32|M0)              r68.0<1>:d    r11.0<1;1,0>:d    9:w               {Compacted,$5.src} //  ALU pipe: int; $124
        shl (32|M0)              r24.0<1>:d    r20.0<1;1,0>:ud   16:w               {$11.dst}        //  ALU pipe: int; $89
        shl (32|M0)              r26.0<1>:d    r28.0<1;1,0>:ud   16:w               {$12.dst}        //  ALU pipe: int; $92
(W)     mov (1|M0)               r94.0<1>:ud   f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $247
        mul (32|M0)              acc2.0<1>:f   r121.0<1;1,0>:f   r121.0<1;1,0>:f  {Compacted,I@6}    //  ALU pipe: float; $180
(f3.0)  sel (32|M0)              r18.0<1>:f    r5.0<1;1,0>:f     0x0:f               {F@2}           //  ALU pipe: float; $260
        shl (32|M0)              r30.0<1>:d    r44.0<1;1,0>:ud   16:w               {$14.dst}        //  ALU pipe: int; $128
        shl (32|M0)              r32.0<1>:d    r46.0<1;1,0>:ud   16:w               {$15.dst}        //  ALU pipe: int; $134
        shl (32|M0)              r28.0<1>:d    r42.0<1;1,0>:ud   16:w               {$13.dst}        //  ALU pipe: int; $125
        shl (32|M0)              r38.0<1>:d    r48.0<1;1,0>:ud   16:w               {$1.dst}         //  ALU pipe: int; $173
        shl (32|M0)              r40.0<1>:d    r50.0<1;1,0>:ud   16:w               {$2.dst}         //  ALU pipe: int; $176
(W)     mov (1|M0)               f3.0<1>:ud    r94.0<0;1,0>:ud                  {Compacted,A@1}      //  ALU pipe: int; $248
        shl (32|M0)              r44.0<1>:d    r54.0<1;1,0>:ud   16:w               {$3.dst}         //  ALU pipe: int; $80
        shl (32|M0)              r22.0<1>:d    r14.0<1;1,0>:ud   16:w               {$5.dst}         //  ALU pipe: int; $83
        cmp (32|M0)   (lt)f0.0   null<1>:d     r68.0<1;1,0>:d    2560:w                              //  ALU pipe: int; $253
(f2.0)  sel (32|M0)              r48.0<1>:f    acc2.0<1;1,0>:f   0x0:f               {I@6}           //  ALU pipe: float; $269
        shl (32|M0)              r50.0<1>:d    r58.0<1;1,0>:ud   16:w               {$4.dst}         //  ALU pipe: int; $122
        mul (32|M0)              r54.0<1>:f    r24.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted,I@4}    //  ALU pipe: float; $90
        add (32|M0)              r77.0<1>:d    r11.0<1;1,0>:d    14:w               {Compacted}      //  ALU pipe: int; $139
        mul (32|M0)              r64.0<1>:f    r30.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,$9.src} //  ALU pipe: float; $129
        mul (32|M0)              r68.0<1>:f    r32.0<1;1,0>:f    r32.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $135
(W)     mov (1|M0)               f2.0<1>:ud    r93.0<0;1,0>:ud                  {Compacted,F@4}      //  ALU pipe: int; $245
        sync.nop                             null                             {Compacted,I@3}        // $126
        mul (32|M0)              r58.0<1>:f    r28.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,$0.src} //  ALU pipe: float; $126
        add (32|M0)              r70.0<1>:d    r11.0<1;1,0>:d    17:w               {Compacted}      //  ALU pipe: int; $172
        add (16|M16)             r31.0<1>:q    r34.0<1;1,0>:q    62:w               {Compacted,F@2}  //  ALU pipe: int; $215
        add (16|M0)              r29.0<1>:q    r36.0<1;1,0>:q    62:w               {Compacted,F@1}  //  ALU pipe: int; $215
        shl (32|M0)              r119.0<1>:d   r106.0<1;1,0>:ud  16:w               {$0.dst}         //  ALU pipe: int; $140
        shl (32|M0)              r42.0<1>:d    r52.0<1;1,0>:ud   16:w               {$6.dst}         //  ALU pipe: int; $77
        mul (32|M0)              acc2.0<1>:f   r22.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $84
(f3.0)  sel (32|M0)              r62.0<1>:f    r54.0<1;1,0>:f    0x0:f                               //  ALU pipe: float; $248
        load.ugm.d16u32.a64 (32|M0)  r54:2      [r29:4]            {A@1,$10} // ex_desc:0x0; desc:0x8200B80 // $217
(W)     mov (1|M0)               r97.0<1>:ud   f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $253
        shl (32|M0)              r52.0<1>:d    r60.0<1;1,0>:ud   16:w               {$7.dst}         //  ALU pipe: int; $170
        cmp (32|M0)   (lt)f0.0   null<1>:d     r77.0<1;1,0>:d    2560:w                              //  ALU pipe: int; $298
        cmp (32|M0)   (lt)f1.0   null<1>:d     r70.0<1;1,0>:d    2560:w                              //  ALU pipe: int; $265
(f2.0)  sel (32|M0)              r60.0<1>:f    acc2.0<1;1,0>:f   0x0:f               {I@3}           //  ALU pipe: float; $245
        shl (32|M0)              r76.0<1>:d    r72.0<1;1,0>:ud   16:w               {$9.dst}         //  ALU pipe: int; $74
        mul (32|M0)              r7.0<1>:f     r119.0<1;1,0>:f   r119.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $141
        mul (32|M0)              r70.0<1>:f    r40.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $177
        mul (32|M0)              acc2.0<1>:f   r38.0<1;1,0>:f    r38.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $174
        add (16|M16)             r40.0<1>:q    r34.0<1;1,0>:q    46:w               {Compacted,F@2}  //  ALU pipe: int; $167
        add (16|M0)              r38.0<1>:q    r36.0<1;1,0>:q    46:w               {Compacted,F@1}  //  ALU pipe: int; $167
        mul (32|M0)              r113.0<1>:f   r76.0<1;1,0>:f    r76.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $75
        load.ugm.d16u32.a64 (32|M0)  r76:2      [r38:4]            {A@1,$11} // ex_desc:0x0; desc:0x8200B80 // $169
        add (32|M0)              r74.0<1>:f    r7.0<1;1,0>:f     r111.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $264
        mul (32|M0)              r100.0<1>:f   r52.0<1;1,0>:f    r52.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $171
        mul (32|M0)              r82.0<1>:f    r44.0<1;1,0>:f    r44.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $81
        mul (32|M0)              r80.0<1>:f    r42.0<1;1,0>:f    r42.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $78
(f1.0)  sel (32|M0)              r78.0<1>:f    acc2.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $266
        shl (32|M0)              r46.0<1>:d    r56.0<1;1,0>:ud   16:w               {$8.dst}         //  ALU pipe: int; $86
(f0.0)  sel (32|M0)              r111.0<1>:f   r74.0<1;1,0>:f    0x0:f               {F@5}           //  ALU pipe: float; $299
        add (16|M16)             r44.0<1>:q    r34.0<1;1,0>:q    54:w               {Compacted,F@4}  //  ALU pipe: int; $203
        add (16|M0)              r42.0<1>:q    r36.0<1;1,0>:q    54:w               {Compacted,F@3}  //  ALU pipe: int; $203
        add (32|M0)              r3.0<1>:f     r100.0<1;1,0>:f   r78.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $267
(W)     mov (1|M0)               f0.0<1>:ud    r98.0<0;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $242
        load.ugm.d16u32.a64 (32|M0)  r78:2      [r42:4]            {A@1,$12} // ex_desc:0x0; desc:0x8200B80 // $205
        add (32|M0)              r87.0<1>:d    r11.0<1;1,0>:d    12:w               {Compacted}      //  ALU pipe: int; $133
        add (32|M0)              r108.0<1>:f   r70.0<1;1,0>:f    r48.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $270
        mul (32|M0)              r56.0<1>:f    r26.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $93
        mul (32|M0)              r93.0<1>:f    r46.0<1;1,0>:f    r46.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $87
        add (32|M0)              r106.0<1>:f   r68.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $261
        add (16|M16)             r48.0<1>:q    r34.0<1;1,0>:q    58:w               {Compacted,F@4}  //  ALU pipe: int; $209
        add (16|M0)              r46.0<1>:q    r36.0<1;1,0>:q    58:w               {Compacted,F@2}  //  ALU pipe: int; $209
(W)     mov (1|M0)               f2.0<1>:ud    r97.0<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $254
(f0.0)  sel (32|M0)              r115.0<1>:f   r80.0<1;1,0>:f    0x0:f                               //  ALU pipe: float; $242
        load.ugm.d16u32.a64 (32|M0)  r80:2      [r46:4]            {A@1,$13} // ex_desc:0x0; desc:0x8200B80 // $211
        add (32|M0)              r102.0<1>:f   r56.0<1;1,0>:f    r9.0<1;1,0>:f    {Compacted}        //  ALU pipe: float; $252
        cmp (32|M0)   (lt)f0.0   null<1>:d     r87.0<1;1,0>:d    2560:w                              //  ALU pipe: int; $316
        add (32|M0)              r9.0<1>:f     r106.0<1;1,0>:f   r111.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $300
        add (32|M0)              r91.0<1>:d    r11.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $97
(f2.0)  sel (32|M0)              r66.0<1>:f    r58.0<1;1,0>:f    0x0:f                               //  ALU pipe: float; $254
        mul (32|M0)              r95.0<1>:f    r50.0<1;1,0>:f    r50.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $123
        add (16|M0)              r56.0<1>:q    r36.0<1;1,0>:q    42:w               {Compacted,F@4}  //  ALU pipe: int; $161
(f0.0)  sel (32|M0)              r19.0<1>:f    r9.0<1;1,0>:f     0x0:f               {F@3}           //  ALU pipe: float; $317
        add (16|M16)             r58.0<1>:q    r34.0<1;1,0>:q    42:w               {Compacted,F@3}  //  ALU pipe: int; $161
        add (32|M0)              r119.0<1>:f   r93.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $249
        cmp (32|M0)   (lt)f0.0   null<1>:d     r91.0<1;1,0>:d    2560:w               {A@2}          //  ALU pipe: int; $325
        load.ugm.d16u32.a64 (32|M0)  r92:2      [r56:4]            {A@1,$14} // ex_desc:0x0; desc:0x8200B80 // $163
        add (32|M0)              r85.0<1>:d    r11.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $79
        add (32|M0)              r104.0<1>:f   r64.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $258 R{} IR{}{E:0,E:0,},  R{} IR{}{O:0,O:8,},  {BC=1}
(W)     mov (1|M0)               f1.0<1>:ud    r110.0<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $296
(W)     mov (1|M0)               f2.0<1>:ud    r99.0<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $293
        add (32|M0)              r121.0<1>:f   r95.0<1;1,0>:f    r66.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $255
        add (16|M0)              r64.0<1>:q    r36.0<1;1,0>:q    50:w               {Compacted,F@2}  //  ALU pipe: int; $197
        add (16|M16)             r66.0<1>:q    r34.0<1;1,0>:q    50:w               {Compacted,F@1}  //  ALU pipe: int; $197
        add (32|M0)              r89.0<1>:d    r11.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $85
        cmp (32|M0)   (lt)f3.0   null<1>:d     r85.0<1;1,0>:d    2560:w               {I@6}          //  ALU pipe: int; $289
        load.ugm.d16u32.a64 (32|M0)  r96:2      [r64:4]            {I@3,$15} // ex_desc:0x0; desc:0x8200B80 // $199
        add (16|M16)             r52.0<1>:q    r34.0<1;1,0>:q    60:w               {Compacted}      //  ALU pipe: int; $212
        add (32|M0)              r117.0<1>:f   r82.0<1;1,0>:f    r60.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $246
        add (16|M0)              r50.0<1>:q    r36.0<1;1,0>:q    60:w               {Compacted}      //  ALU pipe: int; $212
(f1.0)  sel (32|M0)              r7.0<1>:f     r104.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $296
(f2.0)  sel (32|M0)              r5.0<1>:f     r102.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $293
        load.ugm.d16u32.a64 (32|M0)  r82:2      [r50:4]            {A@1,$0} // ex_desc:0x0; desc:0x8200B80 // $214
        add (32|M0)              r13.0<1>:f    r113.0<1;1,0>:f   r115.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $243
        cmp (32|M0)   (lt)f1.0   null<1>:d     r89.0<1;1,0>:d    2560:w               {F@3}          //  ALU pipe: int; $313
(f3.0)  sel (32|M0)              acc2.0<1>:f   r117.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $290
        add (32|M0)              r17.0<1>:f    r121.0<1;1,0>:f   r7.0<1;1,0>:f    {Compacted}        //  ALU pipe: float; $297
        add (32|M0)              r15.0<1>:f    r119.0<1;1,0>:f   r5.0<1;1,0>:f    {Compacted,F@4}    //  ALU pipe: float; $294
        add (16|M16)             r62.0<1>:q    r34.0<1;1,0>:q    44:w               {Compacted}      //  ALU pipe: int; $164
        add (16|M0)              r60.0<1>:q    r36.0<1;1,0>:q    44:w               {Compacted}      //  ALU pipe: int; $164
        add (32|M0)              r21.0<1>:f    r13.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $291
        add (32|M0)              r23.0<1>:f    r17.0<1;1,0>:f    r19.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $318
(f1.0)  sel (32|M0)              acc2.0<1>:f   r15.0<1;1,0>:f    0x0:f               {F@3}           //  ALU pipe: float; $314
        load.ugm.d16u32.a64 (32|M0)  r94:2      [r60:4]            {I@1,$1} // ex_desc:0x0; desc:0x8200B80 // $166
        add (32|M0)              r106.0<1>:d   r11.0<1;1,0>:d    31:w               {Compacted}      //  ALU pipe: int; $238
        add (16|M0)              r72.0<1>:q    r36.0<1;1,0>:q    56:w               {Compacted}      //  ALU pipe: int; $206
        add (16|M16)             r74.0<1>:q    r34.0<1;1,0>:q    56:w               {Compacted}      //  ALU pipe: int; $206
        add (16|M16)             r70.0<1>:q    r34.0<1;1,0>:q    52:w               {Compacted}      //  ALU pipe: int; $200
        add (16|M0)              r68.0<1>:q    r36.0<1;1,0>:q    52:w               {Compacted}      //  ALU pipe: int; $200
        add (32|M0)              r25.0<1>:f    r21.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $315
(f0.0)  sel (32|M0)              acc2.0<1>:f   r23.0<1;1,0>:f    0x0:f               {F@3}           //  ALU pipe: float; $326
        load.ugm.d16u32.a64 (32|M0)  r100:2     [r72:4]            {I@3,$2} // ex_desc:0x0; desc:0x8200B80 // $208
        load.ugm.d16u32.a64 (32|M0)  r98:2      [r68:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200B80 // $202
        cmp (32|M0)   (lt)f0.0   null<1>:d     r106.0<1;1,0>:d   2560:w               {F@1}          //  ALU pipe: int; $286
        add (32|M0)              r117.0<1>:d   r11.0<1;1,0>:d    21:w               {Compacted}      //  ALU pipe: int; $184
        add (32|M0)              r110.0<1>:d   r11.0<1;1,0>:d    23:w               {Compacted}      //  ALU pipe: int; $190
        add (16|M16)             r86.0<1>:q    r34.0<1;1,0>:q    40:w               {Compacted}      //  ALU pipe: int; $158
        add (16|M0)              r84.0<1>:q    r36.0<1;1,0>:q    40:w               {Compacted}      //  ALU pipe: int; $158
        add (16|M16)             r90.0<1>:q    r34.0<1;1,0>:q    48:w               {Compacted}      //  ALU pipe: int; $194
        add (16|M0)              r88.0<1>:q    r36.0<1;1,0>:q    48:w               {Compacted}      //  ALU pipe: int; $194
(W)     mov (1|M0)               r116.0<1>:ud  f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $286
        cmp (32|M0)   (lt)f0.0   null<1>:d     r117.0<1;1,0>:d   2560:w               {I@7}          //  ALU pipe: int; $271
        load.ugm.d16u32.a64 (32|M0)  r102:2     [r84:4]            {I@5,$4} // ex_desc:0x0; desc:0x8200B80 // $160
        load.ugm.d16u32.a64 (32|M0)  r104:2     [r88:4]            {I@3,$5} // ex_desc:0x0; desc:0x8200B80 // $196
        add (32|M0)              r9.0<1>:d     r11.0<1;1,0>:d    26:w               {Compacted}      //  ALU pipe: int; $223
        cmp (32|M0)   (lt)f3.0   null<1>:d     r110.0<1;1,0>:d   2560:w                              //  ALU pipe: int; $274
        add (32|M0)              r119.0<1>:d   r11.0<1;1,0>:d    25:w               {Compacted}      //  ALU pipe: int; $220
(W)     mov (1|M0)               r29.0<1>:ud   f0.0<0;1,0>:ud                   {Compacted,$10.src}  //  ALU pipe: int; $271
        cmp (32|M0)   (lt)f0.0   null<1>:d     r9.0<1;1,0>:d     2560:w               {I@4}          //  ALU pipe: int; $307
        add (32|M0)              r13.0<1>:d    r11.0<1;1,0>:d    18:w               {Compacted}      //  ALU pipe: int; $175
(W)     mov (1|M0)               r121.0<1>:ud  f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $274
        cmp (32|M0)   (lt)f3.0   null<1>:d     r119.0<1;1,0>:d   2560:w               {I@5}          //  ALU pipe: int; $277
        add (32|M0)              r17.0<1>:d    r11.0<1;1,0>:d    20:w               {Compacted}      //  ALU pipe: int; $181
(W)     mov (1|M0)               r41.0<1>:ud   f0.0<0;1,0>:ud                   {Compacted,$11.src}  //  ALU pipe: int; $307
        cmp (32|M0)   (lt)f0.0   null<1>:d     r13.0<1;1,0>:d    2560:w               {I@5}          //  ALU pipe: int; $301
(W)     mov (1|M0)               r30.0<1>:ud   f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $277
        cmp (32|M0)   (lt)f3.0   null<1>:d     r17.0<1;1,0>:d    2560:w               {I@4}          //  ALU pipe: int; $319
        add (32|M0)              r27.0<1>:f    r25.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $327
        sync.nop                             null                             {Compacted,$12.src}    // $239
        shl (32|M0)              r43.0<1>:d    r54.0<1;1,0>:ud   16:w               {$10.dst}        //  ALU pipe: int; $239
(f0.0)  sel (32|M0)              acc2.0<1>:f   r108.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $302
(W)     mov (1|M0)               r42.0<1>:ud   f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $319
(W)     mov (1|M0)               f3.0<1>:ud    r116.0<0;1,0>:ud                 {Compacted}          //  ALU pipe: int; $287
        add (32|M0)              r112.0<1>:d   r11.0<1;1,0>:d    27:w               {Compacted}      //  ALU pipe: int; $226
        add (32|M0)              r45.0<1>:f    r3.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,$13.src} //  ALU pipe: float; $303
        mul (32|M0)              acc2.0<1>:f   r43.0<1;1,0>:f    r43.0<1;1,0>:f   {Compacted,I@4}    //  ALU pipe: float; $240
        shl (32|M0)              r47.0<1>:d    r76.0<1;1,0>:ud   16:w               {$11.dst}        //  ALU pipe: int; $191
        cmp (32|M0)   (lt)f2.0   null<1>:d     r112.0<1;1,0>:d   2560:w               {I@2}          //  ALU pipe: int; $280
(f3.0)  sel (32|M0)              r49.0<1>:f    acc2.0<1;1,0>:f   0x0:f               {$0.src}        //  ALU pipe: float; $287
(W)     mov (1|M0)               f3.0<1>:ud    r121.0<0;1,0>:ud                 {Compacted,F@1}      //  ALU pipe: int; $275
        add (32|M0)              r114.0<1>:d   r11.0<1;1,0>:d    29:w               {Compacted}      //  ALU pipe: int; $232
        mul (32|M0)              acc2.0<1>:f   r47.0<1;1,0>:f    r47.0<1;1,0>:f   {Compacted,I@4}    //  ALU pipe: float; $192
(W)     mov (1|M0)               r1.0<1>:ud    f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $280
        shl (32|M0)              r51.0<1>:d    r78.0<1;1,0>:ud   16:w               {$12.dst}        //  ALU pipe: int; $227
        cmp (32|M0)   (lt)f1.0   null<1>:d     r114.0<1;1,0>:d   2560:w               {I@3}          //  ALU pipe: int; $283
        sync.nop                             null                             {Compacted,$1.src}     // $275
(f3.0)  sel (32|M0)              r63.0<1>:f    acc2.0<1;1,0>:f   0x0:f               {$15.src}       //  ALU pipe: float; $275
(W)     mov (1|M0)               f3.0<1>:ud    r1.0<0;1,0>:ud                   {Compacted,A@1}      //  ALU pipe: int; $281
        mul (32|M0)              acc2.0<1>:f   r51.0<1;1,0>:f    r51.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $228
        shl (32|M0)              r53.0<1>:d    r80.0<1;1,0>:ud   16:w               {$13.dst}        //  ALU pipe: int; $233
(W)     mov (1|M0)               r2.0<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $283
(f3.0)  sel (32|M0)              r75.0<1>:f    acc2.0<1;1,0>:f   0x0:f               {$2.src}        //  ALU pipe: float; $281
(W)     mov (1|M0)               f3.0<1>:ud    r2.0<0;1,0>:ud                   {Compacted,A@1}      //  ALU pipe: int; $284
        mul (32|M0)              r69.0<1>:f    r53.0<1;1,0>:f    r53.0<1;1,0>:f   {Compacted,$3.src} //  ALU pipe: float; $234
        shl (32|M0)              r57.0<1>:d    r92.0<1;1,0>:ud   16:w               {$14.dst}        //  ALU pipe: int; $185
(f3.0)  sel (32|M0)              r77.0<1>:f    r69.0<1;1,0>:f    0x0:f               {F@1}           //  ALU pipe: float; $284
(W)     mov (1|M0)               f3.0<1>:ud    r29.0<0;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $272
        add (32|M0)              r5.0<1>:d     r11.0<1;1,0>:d    30:w               {Compacted}      //  ALU pipe: int; $235
        mul (32|M0)              acc2.0<1>:f   r57.0<1;1,0>:f    r57.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $186
        shl (32|M0)              r61.0<1>:d    r96.0<1;1,0>:ud   16:w               {$15.dst}        //  ALU pipe: int; $221
        cmp (32|M0)   (lt)f2.0   null<1>:d     r5.0<1;1,0>:d     2560:w               {I@2}          //  ALU pipe: int; $310
        sync.nop                             null                             {Compacted,$5.src}     // $272
(f3.0)  sel (32|M0)              r87.0<1>:f    acc2.0<1;1,0>:f   0x0:f               {$4.src}        //  ALU pipe: float; $272
        shl (32|M0)              r55.0<1>:d    r82.0<1;1,0>:ud   16:w               {$0.dst}         //  ALU pipe: int; $236
(W)     mov (1|M0)               f3.0<1>:ud    r30.0<0;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $278
        add (32|M0)              r7.0<1>:d     r11.0<1;1,0>:d    22:w               {Compacted}      //  ALU pipe: int; $187
        mul (32|M0)              r83.0<1>:f    r61.0<1;1,0>:f    r61.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $222
(W)     mov (1|M0)               r35.0<1>:ud   f2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $310
        mul (32|M0)              r71.0<1>:f    r55.0<1;1,0>:f    r55.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $237
        cmp (32|M0)   (lt)f1.0   null<1>:d     r7.0<1;1,0>:d     2560:w               {I@2}          //  ALU pipe: int; $304
(f3.0)  sel (32|M0)              r91.0<1>:f    r83.0<1;1,0>:f    0x0:f               {F@2}           //  ALU pipe: float; $278
        shl (32|M0)              r59.0<1>:d    r94.0<1;1,0>:ud   16:w               {$1.dst}         //  ALU pipe: int; $188
(W)     mov (1|M0)               f3.0<1>:ud    r35.0<0;1,0>:ud                  {Compacted,A@1}      //  ALU pipe: int; $311
        add (32|M0)              acc2.0<1>:f   r71.0<1;1,0>:f    r49.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $288
        shl (32|M0)              r67.0<1>:d    r100.0<1;1,0>:ud  16:w               {$2.dst}         //  ALU pipe: int; $230
        shl (32|M0)              r65.0<1>:d    r98.0<1;1,0>:ud   16:w               {$3.dst}         //  ALU pipe: int; $224
(W)     mov (1|M0)               r36.0<1>:ud   f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $304
        mul (32|M0)              r81.0<1>:f    r59.0<1;1,0>:f    r59.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $189
(f3.0)  sel (32|M0)              r99.0<1>:f    acc2.0<1;1,0>:f   0x0:f               {I@2}           //  ALU pipe: float; $311
(W)     mov (1|M0)               f3.0<1>:ud    r36.0<0;1,0>:ud                  {Compacted,A@1}      //  ALU pipe: int; $305
        add (32|M0)              r97.0<1>:f    r81.0<1;1,0>:f    r63.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $276
        shl (32|M0)              r73.0<1>:d    r102.0<1;1,0>:ud  16:w               {$4.dst}         //  ALU pipe: int; $182
        shl (32|M0)              r79.0<1>:d    r104.0<1;1,0>:ud  16:w               {$5.dst}         //  ALU pipe: int; $218
        mul (32|M0)              r89.0<1>:f    r67.0<1;1,0>:f    r67.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $231
        mul (32|M0)              r85.0<1>:f    r65.0<1;1,0>:f    r65.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $225
(f3.0)  sel (32|M0)              r103.0<1>:f   r97.0<1;1,0>:f    0x0:f               {A@1}           //  ALU pipe: float; $305
(W)     mov (1|M0)               f3.0<1>:ud    r41.0<0;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $308
        add (32|M0)              r15.0<1>:d    r11.0<1;1,0>:d    28:w               {Compacted}      //  ALU pipe: int; $229
        mul (32|M0)              r95.0<1>:f    r79.0<1;1,0>:f    r79.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $219
        add (32|M0)              r101.0<1>:f   r89.0<1;1,0>:f    r77.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $285
        add (32|M0)              acc2.0<1>:f   r85.0<1;1,0>:f    r75.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $282
        mul (32|M0)              r93.0<1>:f    r73.0<1;1,0>:f    r73.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $183
        cmp (32|M0)   (lt)f2.0   null<1>:d     r15.0<1;1,0>:d    2560:w               {I@1}          //  ALU pipe: int; $322
(f3.0)  sel (32|M0)              r107.0<1>:f   acc2.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $308
        add (32|M0)              r109.0<1>:f   r101.0<1;1,0>:f   r99.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $312
        add (32|M0)              acc2.0<1>:f   r95.0<1;1,0>:f    r91.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $279
        add (32|M0)              r105.0<1>:f   r93.0<1;1,0>:f    r87.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $273
        add (32|M0)              r113.0<1>:f   acc2.0<1;1,0>:f   r107.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $309
(f2.0)  sel (32|M0)              acc2.0<1>:f   r109.0<1;1,0>:f   0x0:f               {F@4}           //  ALU pipe: float; $323
        add (32|M0)              r19.0<1>:d    r11.0<1;1,0>:d    24:w               {Compacted}      //  ALU pipe: int; $193
(W)     mov (1|M0)               f2.0<1>:ud    r42.0<0;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $320
        add (32|M0)              r111.0<1>:f   r105.0<1;1,0>:f   r103.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $306
        cmp (32|M0)   (lt)f1.0   null<1>:d     r19.0<1;1,0>:d    2560:w               {I@2}          //  ALU pipe: int; $328
        add (32|M0)              r21.0<1>:d    r11.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $145
(f2.0)  sel (32|M0)              r115.0<1>:f   r111.0<1;1,0>:f   0x0:f               {F@1}           //  ALU pipe: float; $320
        add (32|M0)              acc2.0<1>:f   r113.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $324
        add (32|M0)              r117.0<1>:f   r45.0<1;1,0>:f    r115.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $321
        cmp (32|M0)   (lt)f0.0   null<1>:d     r21.0<1;1,0>:d    2560:w               {I@1}          //  ALU pipe: int; $331
(f1.0)  sel (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $329
        add (32|M0)              acc2.0<1>:f   r117.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $330
        mov (16|M16)             r23.0<2>:ud   r125.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $335
        mov (16|M0)              r25.0<2>:ud   r124.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $335
(f0.0)  sel (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   0x0:f                               //  ALU pipe: float; $332
        shl (16|M16)             r31.0<1>:q    r23.0<2;1,0>:ud   2:w               {I@2}             //  ALU pipe: int; $335
        shl (16|M0)              r33.0<1>:q    r25.0<2;1,0>:ud   2:w               {I@2}             //  ALU pipe: int; $335
        add (32|M0)              r119.0<1>:f   r27.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $333
        add (16|M16)             r39.0<1>:q    r31.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $336
        add (16|M0)              r37.0<1>:q    r33.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $336
        store.ugm.d32.a64 (32|M0)  [r37:4]      r119:2             {A@1,$6} // ex_desc:0x0; desc:0x8000584 // $337
        goto (32|M0)                         _0_012            _0_012                                // $338
// B007: [inDivergent],  Preds:{B005},  Succs:{B008, B009}
_0_016:
        cmp (32|M0)   (eq)f3.0   null<1>:d     r124.0<1;1,0>:d   0:w                                 //  ALU pipe: int; $340
(~f3.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $341
// B008: [inDivergent],  Preds:{B007},  Succs:{B009}
_0_018:
        mov (16|M0)              r1.0<2>:f     r126.0<0;1,0>:f                                       //  ALU pipe: float; $343
        mov (16|M16)             r3.0<2>:f     r126.0<0;1,0>:f                                       //  ALU pipe: float; $343
        mov (32|M0)              r5.0<1>:d     1:w                               {Compacted}         //  ALU pipe: int; $345
        mov (16|M0)              r1.1<2>:f     r126.1<0;1,0>:f                                       //  ALU pipe: float; $344
        mov (16|M16)             r3.1<2>:ud    r126.1<0;1,0>:ud                 {F@2}                //  ALU pipe: int; $344
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r1:4]           r5:2               {A@1,$7} // ex_desc:0x0; desc:0x800058B // $346
// B009: Preds:{B008, B007, B006, B004, B003, B002},  Succs:{}
_0_012:
        join (32|M0)                         L4744                                                   // 
L4744:
(W)     mov (16|M0)              r127.0<1>:f   r123.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $348
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$8} // wr:1+0, rd:0; end of thread // $348
L4768:
(W)     mov (16|M0)              null<1>:ud    0x830D2F0:ud                                          // 
(W)     mov (16|M0)              null<1>:ud    0xEA18A4DC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x2:ud                                                // 


//.BankConflicts: 1
//.ByteRMWs: 0
//


//.numALUInst: 367
//.accSubDef: 21
//.accSubUse: 21
//.accSubCandidateDef: 93
//.accSubCandidateUse: 93
//
//
//.singlePipeAtOneDistNum: 37
//.allAtOneDistNum: 21
//.syncInstCount: 7
//.tokenReuseCount: 4
//.AfterWriteTokenDepCount: 38
//.AfterReadTokenDepCount: 27
