//.kernel _ZTSN4sycl3_V16detail19__pf_kernel_wrapperI11FloorKernelILi0ELb0ELb0ELb0ELb1EEEE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 418947230 4257068557 -hashmovs1 0 3 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 418947230 4257068557 -hashmovs1 0 3 -GRFBumpUpNumber 2 "
//.instCount 96
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r4.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.9)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.10)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.5)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r4.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r4.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r3.2)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=8 type=d align=2 words (r2.8)
//.declare V0046 (56)  rf=r size=8 type=d alias=V0043+0 align=4 words (r2.6)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0048 (58)  rf=r size=12 type=ud alias=V0038+0 align=2 words (r2.3)
//.declare V0049 (59)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r4.0)
//.declare V0050 (60)  rf=r size=8 type=ud alias=V0047+0 align=4 words (r2.10)
//.declare V0051 (61)  rf=r size=8 type=d alias=V0047+0 align=4 words (r2.10)
//.declare V0052 (62)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0055 (65)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0058 (68)  rf=r size=12 type=ud alias=V0036+0 align=2 words (r2.0)
//.declare V0062 (72)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0063 (73)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P01 (74)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0064 (75)  rf=r size=128 type=ud alias=V0062+0 align=32 words (r6.0)
//.declare V0065 (76)  rf=r size=8 type=ud alias=V0045+0 align=2 words (r2.8)
//.declare P02 (77)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P03 (78)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0066 (79)  rf=r size=128 type=ud alias=V0063+0 align=32 words (r8.0)
//.declare V0069 (82)  rf=r size=8 type=uq align=32 words (r10.0)
//.declare V0070 (83)  rf=r size=8 type=uq alias=V0044+0 align=4 words (r3.0)
//.declare V0071 (84)  rf=r size=8 type=q align=4 words (r2.6)
//.declare V0072 (85)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r3.2)
//.declare V0073 (86)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0074 (87)  rf=r size=8 type=d align=32 words (r13.0)
//.declare V0075 (88)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P04 (89)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0076 (90)  rf=r size=128 type=ud alias=V0075+0 align=32 words (r14.0)
//.declare V0077 (91)  rf=r size=8 type=ud alias=V0074+0 align=32 words (r13.0)
//.declare V0078 (92)  rf=r size=16 type=uq align=32 words (r16.0)
//.declare V0079 (93)  rf=r size=8 type=uq align=32 words (r17.0)
//.declare V0086 (100)  rf=r size=256 type=uq align=32 words (r18.0)
//.declare V0088 (102)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare V0089 (103)  rf=r size=128 type=w alias=V0088+0 align=32 words (r22.0)
//.declare V0090 (104)  rf=r size=8 type=uq align=4 words (r2.7)
//.declare V0092 (106)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0093 (107)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0094 (108)  rf=r size=128 type=f alias=V0092+0 align=32 words (r24.0)
//.declare V0095 (109)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0096 (110)  rf=r size=128 type=d alias=V0093+0 align=32 words (r27.0)
//.declare P05 (111)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0097 (112)  rf=r size=128 type=ud alias=V0095+0 align=32 words (r29.0)
//.declare V0098 (113)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0099 (114)  rf=r size=128 type=ud alias=V0093+0 align=32 words (r27.0)
//.declare V0100 (115)  rf=r size=128 type=ud alias=V0098+0 align=32 words (r31.0)
//.declare V0101 (116)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0102 (117)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0103 (118)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0104 (119)  rf=r size=128 type=ud alias=V0102+0 align=32 words (r36.0)
//.declare V0105 (120)  rf=r size=128 type=ud alias=V0103+0 align=32 words (r38.0)
//.declare V0106 (121)  rf=r size=64 type=w align=32 words (r26.0)
//.declare V0107 (122)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0108 (123)  rf=r size=128 type=ud alias=V0107+0 align=32 words (r40.0)
//.declare V0110 (125)  rf=r size=8 type=q alias=V0090+0 align=4 words (r2.7)
//.declare V0113 (128)  rf=r size=256 type=uq align=32 words (r42.0)
//.declare V0114 (129)  rf=r size=64 type=uw alias=V0106+0 align=32 words (r26.0)
//.declare V0115 (130)  rf=r size=128 type=ud align=32 words (r46.0)
//.declare V0119 (134)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0120 (135)  rf=r size=128 type=d align=32 words (r50.0)
//.declare P06 (136)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0121 (137)  rf=r size=128 type=ud alias=V0119+0 align=32 words (r48.0)
//.declare P07 (138)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P08 (139)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0122 (140)  rf=r size=128 type=ud alias=V0120+0 align=32 words (r50.0)
//.declare  (144)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (145)  rf=r size=128 type=w alias=V0107+0 align=32 words (r40.0)
//.declare  (146)  rf=r size=4 type=ud align=32 words (r33.0)
//.declare  (147)  rf=r size=128 type=uw align=32 words (r52.0)
//.declare  (148)  rf=r size=128 type=uw align=32 words (r54.0)
//.declare  (151)  rf=r size=128 type=ud align=32 words (r56.0)
//.declare  (152)  rf=r size=128 type=ud align=32 words (r58.0)
//.declare  (153)  rf=r size=128 type=w alias=V0103+0 align=32 words (r38.0)
//.declare  (156)  rf=r size=128 type=q align=32 words (r60.0)
//.declare  (157)  rf=r size=128 type=q align=32 words (r62.0)
//.declare  (158)  rf=r size=128 type=q align=32 words (r64.0)
//.declare  (159)  rf=r size=128 type=q align=32 words (r66.0)
//.declare  (164)  rf=r size=128 type=q align=32 words (r68.0)
//.declare  (165)  rf=r size=128 type=q align=32 words (r70.0)
//.declare  (170)  rf=r size=128 type=q align=32 words (r72.0)
//.declare  (171)  rf=r size=128 type=q align=32 words (r74.0)
//.declare  (174)  rf=r size=128 type=d align=32 words (r76.0)
//.declare  (175)  rf=r size=128 type=d align=32 words (r78.0)
//.declare  (176)  rf=r size=128 type=d alias=+0 align=32 words (r64.0)
//.declare  (177)  rf=r size=128 type=d alias=+0 align=32 words (r66.0)
//.declare  (178)  rf=r size=128 type=d alias=+0 align=32 words (r72.0)
//.declare  (179)  rf=r size=128 type=d alias=+0 align=32 words (r74.0)
//.declare r0 (180)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (181)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (182)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (183)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (184)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (185)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0038    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0037    | :d x 3   |    0xC | r3+0x8   | cti+0x28         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x20:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B011}
// _main:
(W)     mov (16|M0)              r4.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r4.2<0;1,0>:uw   {A@1}              //  ALU pipe: int; $3
(W)     macl (1|M0)              r33.0<1>:ud   r2.3<0;1,0>:ud    r4.1<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $4
(W)     mul (1|M0)               acc0.0<1>:ud  r2.3<0;1,0>:ud    r4.2<0;1,0>:uw                      //  ALU pipe: int; $4
(W)     mach (1|M0)              r5.0<1>:d     r2.3<0;1,0>:ud    r4.1<0;1,0>:ud                      //  ALU pipe: int; 
        mov (16|M0)              r52.0<4>:uw   r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $10
        mov (16|M16)             r54.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $10
(W)     mov (1|M0)               r2.10<2>:ud   r33.0<0;1,0>:ud                  {I@5}                //  ALU pipe: int; $4
(W)     mov (1|M0)               r2.11<2>:d    r5.0<0;1,0>:d                    {I@4}                //  ALU pipe: int; $8
(W)     mov (2|M0)               r2.8<1>:d     r2.6<1;1,0>:d                                         //  ALU pipe: int; $2
        add (16|M0)              r60.0<1>:q    r2.5<0;1,0>:q     r52.0<4;1,0>:uw  {I@2}              //  ALU pipe: int; $10
        add (16|M16)             r62.0<1>:q    r2.5<0;1,0>:q     r54.0<4;1,0>:uw                     //  ALU pipe: int; $10
        add (16|M0)              r64.0<1>:q    r60.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        add (16|M16)             r66.0<1>:q    r62.0<1;1,0>:q    r2.0<0;1,0>:ud   {I@2}              //  ALU pipe: int; $12
        mov (16|M0)              r6.0<1>:d     r64.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $13
        mov (16|M16)             r7.0<1>:d     r66.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $14
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r6.0<1;1,0>:ud    r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $17
        mov (16|M0)              r8.0<1>:d     r64.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r9.0<1>:d     r66.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $16
(f3.0)  cmp (32|M0)   (eq)f3.0   null<1>:d     r8.0<1;1,0>:d     r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $18
(~f3.0) cmp (32|M0)   (lt)f3.0   null<1>:ud    r8.0<1;1,0>:ud    r2.9<0;1,0>:ud                      //  ALU pipe: int; $20
(~f3.0) goto (32|M0)                         _0_013            _0_013                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004}
_0_014:
(W)     add (1|M0)               r10.0<1>:q    r3.0<0;1,0>:q     16:w               {Compacted,$1.dst} //  ALU pipe: int; $24
(W)     mov (1|M0)               r2.6<1>:q     r3.2<0;1,0>:ud                                        //  ALU pipe: int; $26
// B004: [inDivergent],  Preds:{B010, B003},  Succs:{B005, B009}
_0_015:
(W)     load.ugm.d32x2t.a64 (1|M0)  r13:1       [r10:1]            {I@2,$3} // ex_desc:0x0; desc:0x2109580 // $29
        mov (16|M0)              r11.0<1>:d    r64.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $28
        mov (16|M16)             r12.0<1>:d    r66.0<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $28
        add (32|M0)              r14.0<1>:d    r13.0<0;1,0>:d    r11.0<1;1,0>:d   {Compacted,@1,$3.dst} //  ALU pipe: int; $30
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r14.0<1;1,0>:ud   r13.1<0;1,0>:ud  {I@1}              //  ALU pipe: int; $31
(~f2.0) goto (32|M0)                         _0_016            _0_016                                //  ALU pipe: int; $32
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B007}
_0_017:
(W)     mov (1|M0)               r17.0<1>:uq   r3.0<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $34
        mov (16|M0)              r56.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $37
(W)     load.ugm.d64x2t.a64 (1|M0)  r16:1       [r17:1]            {I@2,$4} // ex_desc:0x0; desc:0x2109780 // $35
        mov (16|M16)             r58.0<2>:ud   r15.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $37
        shl (16|M0)              r68.0<1>:q    r56.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $37
        shl (16|M16)             r70.0<1>:q    r58.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $37
        add (16|M0)              r18.0<1>:q    r68.0<1;1,0>:q    r16.0<0;1,0>:q   {Compacted,@2,$4.dst} //  ALU pipe: int; $39
        add (16|M16)             r20.0<1>:q    r70.0<1;1,0>:q    r16.0<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $39
        load.ugm.d16u32.a64 (32|M0)  r22:2      [r18:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200B80 // $41
(W)     mov (1|M0)               r2.7<1>:uq    r16.1<0;1,0>:uq                                       //  ALU pipe: int; $42
        shl (32|M0)              r24.0<1>:d    r22.0<1;1,0>:ud   16:w               {$5.dst}         //  ALU pipe: int; $43
        add (32|M0)              r27.0<1>:f    r24.0<1;1,0>:f    0x3F800000:f               {Compacted,I@1} //  ALU pipe: float; $44
        and (32|M0)              r29.0<1>:d    r27.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $45
        cmp (32|M0)   (gt)f1.0   null<1>:ud    r29.0<1;1,0>:ud   0x7F800000:ud              {I@1}    //  ALU pipe: int; $46
(f1.0)  goto (32|M0)                         _0_018            _0_018                                //  ALU pipe: int; $47
// B006: [inDivergent],  Preds:{B005},  Succs:{B008}
_0_019:
        shr (32|M0)              r31.0<1>:ud   r27.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $49
        and (32|M0)              r34.0<1>:d    r31.0<1;1,0>:d    1:w               {Compacted,I@1}   //  ALU pipe: int; $50
        add3 (32|M0)             r36.0<1>:d    r34.0<1;0>:d      r27.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $51
        shr (32|M0)              r38.0<1>:ud   r36.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $52
        mov (32|M0)              r26.0<1>:w    r38.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $53
        goto (32|M0)                         _0_018            _0_020                                // $54
// B007: [inDivergent],  Preds:{B005},  Succs:{B008}
_0_018:
        join (32|M0)                         _0_020                                                  // 
L888:
        shr (32|M0)              r40.0<1>:ud   r27.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $56
        or (32|M0)               r26.0<1>:w    r40.0<2;1,0>:w    64:w               {I@1}            //  ALU pipe: int; $58
// B008: [inDivergent],  Preds:{B007, B006},  Succs:{B009}
_0_020:
        join (32|M0)                         _0_016                                                  // 
L936:
        add (16|M0)              r42.0<1>:q    r68.0<1;1,0>:q    r2.7<0;1,0>:q    {Compacted,$2.src} //  ALU pipe: int; $60
        add (16|M16)             r44.0<1>:q    r70.0<1;1,0>:q    r2.7<0;1,0>:q    {Compacted}        //  ALU pipe: int; $60
        mov (32|M0)              r46.0<1>:ud   r26.0<1;1,0>:uw                  {I@4}                //  ALU pipe: int; $62
        store.ugm.d16u32.a64 (32|M0)  [r42:4]   r46:2              {I@1,$2} // ex_desc:0x0; desc:0x8000B84 // $63
// B009: [inDivergent],  Preds:{B008, B004},  Succs:{B010, B011}
_0_016:
        join (32|M0)                         _0_013                                                  // 
L1000:
        add (16|M0)              r72.0<1>:q    r64.0<1;1,0>:q    r2.6<0;1,0>:q                       //  ALU pipe: int; $65
        add (16|M16)             r74.0<1>:q    r66.0<1;1,0>:q    r2.6<0;1,0>:q                       //  ALU pipe: int; $65
        mov (16|M0)              r48.0<1>:d    r72.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $66
        mov (16|M16)             r49.0<1>:d    r74.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $67
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r48.0<1;1,0>:ud   r2.8<0;1,0>:ud   {I@1}              //  ALU pipe: int; $70
        mov (16|M0)              r50.0<1>:d    r72.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $68
        mov (16|M16)             r51.0<1>:d    r74.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $69
(f0.0)  cmp (32|M0)   (eq)f0.0   null<1>:d     r50.0<1;1,0>:d    r2.9<0;1,0>:d    {I@1}              //  ALU pipe: int; $71 R{} IR{}{E:1,E:1,},  R{r2,} IR{} {BC=1}
(~f0.0) cmp (32|M0)   (lt)f0.0   null<1>:ud    r50.0<1;1,0>:ud   r2.9<0;1,0>:ud                      //  ALU pipe: int; $73
(~f0.0) goto (32|M0)                         _0_013            _0_013                                //  ALU pipe: int; $75
// B010: [inDivergent],  Preds:{B009},  Succs:{B004}
_0_021:
(f0.0)  sel (32|M0)              r76.0<1>:d    r48.0<1;1,0>:d    r6.0<1;1,0>:d                       //  ALU pipe: int; $77
(f0.0)  sel (32|M0)              r78.0<1>:d    r50.0<1;1,0>:d    r8.0<1;1,0>:d                       //  ALU pipe: int; $78
        mov (16|M0)              r64.0<2>:d    r76.0<1;1,0>:d                   {I@2}                //  ALU pipe: int; $81
        mov (16|M16)             r66.0<2>:d    r77.0<1;1,0>:d                                        //  ALU pipe: int; $82
        mov (16|M0)              r64.1<2>:d    r78.0<1;1,0>:d                   {I@3}                //  ALU pipe: int; $83
        mov (16|M16)             r66.1<2>:d    r79.0<1;1,0>:d                                        //  ALU pipe: int; $84
(W)     jmpi                                 _0_015                                                  // $85
// B011: Preds:{B009, B002},  Succs:{}
_0_013:
        join (32|M0)                         L1256                                                   // 
L1256:
(W)     mov (16|M0)              r127.0<1>:f   r4.0<1;1,0>:f                    {Compacted,$1.src}   //  ALU pipe: float; $87
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$6} // wr:1+0, rd:0; end of thread // $87
L1280:
(W)     mov (16|M0)              null<1>:ud    0x18F8A09E:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xFDBDB60D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x3:ud                                                // 


//.BankConflicts: 1
//.ByteRMWs: 0
//


//.numALUInst: 79
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 21
//.allAtOneDistNum: 3
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 5
//.AfterReadTokenDepCount: 3
