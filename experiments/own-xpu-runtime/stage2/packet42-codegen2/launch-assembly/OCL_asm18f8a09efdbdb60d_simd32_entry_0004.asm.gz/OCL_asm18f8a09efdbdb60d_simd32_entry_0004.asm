//.kernel _ZTS11FloorKernelILi0ELb0ELb0ELb0ELb1EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 418947230 4257068557 -hashmovs1 0 4 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 418947230 4257068557 -hashmovs1 0 4 -GRFBumpUpNumber 2 "
//.instCount 56
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r3.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.12)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.13)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r3.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r3.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0043 (53)  rf=r size=4 type=d align=32 words (r4.0)
//.declare V0045 (55)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0046 (56)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0049 (59)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0050 (60)  rf=r size=8 type=d align=32 words (r7.0)
//.declare V0051 (61)  rf=r size=128 type=d align=32 words (r9.0)
//.declare P01 (62)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0052 (63)  rf=r size=128 type=ud alias=V0051+0 align=32 words (r9.0)
//.declare V0053 (64)  rf=r size=8 type=ud alias=V0050+0 align=32 words (r7.0)
//.declare V0054 (65)  rf=r size=8 type=uq alias=V0042+0 align=4 words (r2.3)
//.declare V0055 (66)  rf=r size=16 type=uq align=32 words (r11.0)
//.declare V0056 (67)  rf=r size=8 type=uq align=32 words (r12.0)
//.declare V0063 (74)  rf=r size=256 type=uq align=32 words (r13.0)
//.declare V0065 (76)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare V0066 (77)  rf=r size=128 type=w alias=V0065+0 align=32 words (r18.0)
//.declare V0067 (78)  rf=r size=8 type=uq align=4 words (r2.4)
//.declare V0069 (80)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0070 (81)  rf=r size=128 type=f align=32 words (r23.0)
//.declare V0071 (82)  rf=r size=128 type=f alias=V0069+0 align=32 words (r20.0)
//.declare V0072 (83)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0073 (84)  rf=r size=128 type=d alias=V0070+0 align=32 words (r23.0)
//.declare P02 (85)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0074 (86)  rf=r size=128 type=ud alias=V0072+0 align=32 words (r25.0)
//.declare V0075 (87)  rf=r size=128 type=d align=32 words (r27.0)
//.declare V0076 (88)  rf=r size=128 type=ud alias=V0070+0 align=32 words (r23.0)
//.declare V0077 (89)  rf=r size=128 type=ud alias=V0075+0 align=32 words (r27.0)
//.declare V0078 (90)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0079 (91)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0080 (92)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0081 (93)  rf=r size=128 type=ud alias=V0079+0 align=32 words (r32.0)
//.declare V0082 (94)  rf=r size=128 type=ud alias=V0080+0 align=32 words (r34.0)
//.declare V0083 (95)  rf=r size=64 type=w align=32 words (r17.0)
//.declare V0084 (96)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0085 (97)  rf=r size=128 type=ud alias=V0084+0 align=32 words (r36.0)
//.declare V0087 (99)  rf=r size=8 type=q alias=V0067+0 align=4 words (r2.4)
//.declare V0090 (102)  rf=r size=256 type=uq align=32 words (r38.0)
//.declare V0091 (103)  rf=r size=64 type=uw alias=V0083+0 align=32 words (r17.0)
//.declare V0092 (104)  rf=r size=128 type=ud align=32 words (r42.0)
//.declare  (105)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (106)  rf=r size=128 type=w alias=V0084+0 align=32 words (r36.0)
//.declare  (107)  rf=r size=128 type=ud align=32 words (r44.0)
//.declare  (108)  rf=r size=128 type=ud align=32 words (r46.0)
//.declare  (109)  rf=r size=128 type=w alias=V0080+0 align=32 words (r34.0)
//.declare  (112)  rf=r size=128 type=q align=32 words (r48.0)
//.declare  (113)  rf=r size=128 type=q align=32 words (r50.0)
//.declare r0 (118)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (119)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (120)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (121)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (122)  rf=r size=64 type=ud align=32 words (r1.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0037    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0042    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@2}           //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
// B002: Preds:{B001},  Succs:{B003, B007}
// _main:
(W)     mov (16|M0)              r3.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     add (1|M0)               r8.0<1>:q     r2.3<0;1,0>:q     16:w               {Compacted,A@1}  //  ALU pipe: int; $5
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r3.2<0;1,0>:uw   {I@3}              //  ALU pipe: int; $2
(W)     load.ugm.d32x2t.a64 (1|M0)  r7:1        [r8:1]             {I@2,$1} // ex_desc:0x0; desc:0x2109580 // $7
(W)     macl (1|M0)              r4.0<1>:d     r2.3<0;1,0>:d     r3.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $4
        add (32|M0)              r5.0<1>:d     r4.0<0;1,0>:d     r1.0<1;1,0>:uw   {@1,$0.dst}        //  ALU pipe: int; $4
        add3 (32|M0)             r9.0<1>:d     r7.0<0;0>:d       r5.0<1;0>:d       r2.0<0>:d        {Compacted,@1,$1.dst} //  ALU pipe: int; $8
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r9.0<1;1,0>:ud    r7.1<0;1,0>:ud   {I@1}              //  ALU pipe: int; $9
(~f1.0) goto (32|M0)                         _0_007            _0_007                                //  ALU pipe: int; $10
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_008:
(W)     mov (1|M0)               r12.0<1>:uq   r2.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $12
        mov (16|M0)              r44.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $15
(W)     load.ugm.d64x2t.a64 (1|M0)  r11:1       [r12:1]            {I@2,$2} // ex_desc:0x0; desc:0x2109780 // $13
        mov (16|M16)             r46.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $15
        shl (16|M0)              r48.0<1>:q    r44.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $15
        shl (16|M16)             r50.0<1>:q    r46.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $15
        add (16|M0)              r13.0<1>:q    r48.0<1;1,0>:q    r11.0<0;1,0>:q   {Compacted,@2,$2.dst} //  ALU pipe: int; $17
        add (16|M16)             r15.0<1>:q    r50.0<1;1,0>:q    r11.0<0;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $17
        load.ugm.d16u32.a64 (32|M0)  r18:2      [r13:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200B80 // $19
(W)     mov (1|M0)               r2.4<1>:uq    r11.1<0;1,0>:uq                                       //  ALU pipe: int; $20
        shl (32|M0)              r20.0<1>:d    r18.0<1;1,0>:ud   16:w               {$3.dst}         //  ALU pipe: int; $21
        add (32|M0)              r23.0<1>:f    r20.0<1;1,0>:f    0x3F800000:f               {Compacted,I@1} //  ALU pipe: float; $22
        and (32|M0)              r25.0<1>:d    r23.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $23
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r25.0<1;1,0>:ud   0x7F800000:ud              {I@1}    //  ALU pipe: int; $24
(f0.0)  goto (32|M0)                         _0_009            _0_009                                //  ALU pipe: int; $25
// B004: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_010:
        shr (32|M0)              r27.0<1>:ud   r23.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $27
        and (32|M0)              r30.0<1>:d    r27.0<1;1,0>:d    1:w               {Compacted,I@1}   //  ALU pipe: int; $28
        add3 (32|M0)             r32.0<1>:d    r30.0<1;0>:d      r23.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $29
        shr (32|M0)              r34.0<1>:ud   r32.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $30
        mov (32|M0)              r17.0<1>:w    r34.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $31
        goto (32|M0)                         _0_009            _0_011                                // $32
// B005: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_009:
        join (32|M0)                         _0_011                                                  // 
L584:
        shr (32|M0)              r36.0<1>:ud   r23.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $34
        or (32|M0)               r17.0<1>:w    r36.0<2;1,0>:w    64:w               {I@1}            //  ALU pipe: int; $36
// B006: [inDivergent],  Preds:{B005, B004},  Succs:{B007}
_0_011:
        join (32|M0)                         _0_007                                                  // 
L632:
        add (16|M0)              r38.0<1>:q    r48.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $38
        add (16|M16)             r40.0<1>:q    r50.0<1;1,0>:q    r2.4<0;1,0>:q    {Compacted}        //  ALU pipe: int; $38
        mov (32|M0)              r42.0<1>:ud   r17.0<1;1,0>:uw                  {I@4}                //  ALU pipe: int; $40
        store.ugm.d16u32.a64 (32|M0)  [r38:4]   r42:2              {I@1,$4} // ex_desc:0x0; desc:0x8000B84 // $41
// B007: Preds:{B006, B002},  Succs:{}
_0_007:
        join (32|M0)                         L696                                                    // 
L696:
(W)     mov (16|M0)              r127.0<1>:f   r3.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $43
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$5} // wr:1+0, rd:0; end of thread // $43
L720:
(W)     mov (16|M0)              null<1>:ud    0x18F8A09E:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xFDBDB60D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x4:ud                                                // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 44
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 17
//.allAtOneDistNum: 3
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 4
//.AfterReadTokenDepCount: 1
