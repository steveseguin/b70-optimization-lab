//.kernel _ZTS11FloorKernelILi3ELb0ELb1ELb0ELb0EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 418947230 4257068557 -hashmovs1 0 29 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 418947230 4257068557 -hashmovs1 0 29 -GRFBumpUpNumber 2 "
//.instCount 52
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r4.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.2)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.3)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.4)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.5)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r4.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r4.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0045 (55)  rf=r size=4 type=d align=2 words (r3.1)
//.declare V0046 (56)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0048 (58)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0049 (59)  rf=r size=128 type=d align=32 words (r6.0)
//.declare P01 (60)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0050 (61)  rf=r size=128 type=ud alias=V0049+0 align=32 words (r6.0)
//.declare V0051 (62)  rf=r size=4 type=ud alias=V0045+0 align=2 words (r3.1)
//.declare V0056 (67)  rf=r size=256 type=uq align=32 words (r8.0)
//.declare V0058 (69)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare V0059 (70)  rf=r size=128 type=w alias=V0058+0 align=32 words (r12.0)
//.declare V0061 (72)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0062 (73)  rf=r size=128 type=f align=32 words (r17.0)
//.declare V0063 (74)  rf=r size=128 type=f alias=V0061+0 align=32 words (r14.0)
//.declare V0064 (75)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0065 (76)  rf=r size=128 type=d alias=V0062+0 align=32 words (r17.0)
//.declare P02 (77)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0066 (78)  rf=r size=128 type=ud alias=V0064+0 align=32 words (r19.0)
//.declare V0067 (79)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0068 (80)  rf=r size=128 type=ud alias=V0062+0 align=32 words (r17.0)
//.declare V0069 (81)  rf=r size=128 type=ud alias=V0067+0 align=32 words (r21.0)
//.declare V0070 (82)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0071 (83)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0072 (84)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0073 (85)  rf=r size=128 type=ud alias=V0071+0 align=32 words (r26.0)
//.declare V0074 (86)  rf=r size=128 type=ud alias=V0072+0 align=32 words (r28.0)
//.declare V0075 (87)  rf=r size=64 type=w align=32 words (r16.0)
//.declare V0076 (88)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0077 (89)  rf=r size=128 type=ud alias=V0076+0 align=32 words (r30.0)
//.declare V0081 (93)  rf=r size=256 type=uq align=32 words (r32.0)
//.declare V0082 (94)  rf=r size=64 type=uw alias=V0075+0 align=32 words (r16.0)
//.declare V0083 (95)  rf=r size=128 type=ud align=32 words (r36.0)
//.declare  (96)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (97)  rf=r size=128 type=w alias=V0076+0 align=32 words (r30.0)
//.declare  (98)  rf=r size=128 type=ud align=32 words (r38.0)
//.declare  (99)  rf=r size=128 type=ud align=32 words (r40.0)
//.declare  (100)  rf=r size=128 type=w alias=V0072+0 align=32 words (r28.0)
//.declare  (103)  rf=r size=128 type=q align=32 words (r42.0)
//.declare  (104)  rf=r size=128 type=q align=32 words (r44.0)
//.declare r0 (109)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (110)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (111)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (112)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (113)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (114)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0042    | :q       |    0x8 | r2+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :d       |    0x4 | r3       | cti+0x20         |
// | V0045    | :d       |    0x4 | r3+0x4   | cti+0x24         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x20:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B007}
// _main:
(W)     mov (16|M0)              r4.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:d   r2.0<0;1,0>:d     r4.2<0;1,0>:uw   {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r5.0<1>:d     r2.0<0;1,0>:d     r4.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $4
        sync.nop                             null                             {Compacted,$1.dst}     // $4
        add3 (32|M0)             r6.0<1>:d     r5.0<0;0>:d       r1.0<1;0>:uw      r3.0<0>:d        {@1,$0.dst} //  ALU pipe: int; $4 R{} IR{}{O:2,O:0,O:1,},  R{r5,r1,r3,} IR{} {BC=1}
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r6.0<1;1,0>:ud    r3.1<0;1,0>:ud   {I@1}              //  ALU pipe: int; $5
(~f1.0) goto (32|M0)                         _0_007            _0_007                                //  ALU pipe: int; $6
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_008:
        mov (16|M0)              r38.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $9
        mov (16|M16)             r40.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $9
        shl (16|M0)              r42.0<1>:q    r38.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $9
        shl (16|M16)             r44.0<1>:q    r40.0<2;1,0>:ud   1:w               {I@2}             //  ALU pipe: int; $9
        add (16|M0)              r8.0<1>:q     r42.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $10
        add (16|M16)             r10.0<1>:q    r44.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $10
        load.ugm.d16u32.a64 (32|M0)  r12:2      [r8:4]             {I@1,$2} // ex_desc:0x0; desc:0x8200B80 // $12
        shl (32|M0)              r14.0<1>:d    r12.0<1;1,0>:ud   16:w               {$2.dst}         //  ALU pipe: int; $13
        add (32|M0)              r17.0<1>:f    r14.0<1;1,0>:f    0x3F800000:f               {Compacted,I@1} //  ALU pipe: float; $14
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $15
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r19.0<1;1,0>:ud   0x7F800000:ud              {I@1}    //  ALU pipe: int; $16
(f0.0)  goto (32|M0)                         _0_009            _0_009                                //  ALU pipe: int; $17
// B004: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_010:
        shr (32|M0)              r21.0<1>:ud   r17.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $19
        and (32|M0)              r24.0<1>:d    r21.0<1;1,0>:d    1:w               {Compacted,I@1}   //  ALU pipe: int; $20
        add3 (32|M0)             r26.0<1>:d    r24.0<1;0>:d      r17.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $21
        shr (32|M0)              r28.0<1>:ud   r26.0<1;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $22
        mov (32|M0)              r16.0<1>:w    r28.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $23
        goto (32|M0)                         _0_009            _0_011                                // $24
// B005: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_009:
        join (32|M0)                         _0_011                                                  // 
L536:
        shr (32|M0)              r30.0<1>:ud   r17.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $26
        or (32|M0)               r16.0<1>:w    r30.0<2;1,0>:w    64:w               {I@1}            //  ALU pipe: int; $28
// B006: [inDivergent],  Preds:{B005, B004},  Succs:{B007}
_0_011:
        join (32|M0)                         _0_007                                                  // 
L584:
        add (16|M0)              r32.0<1>:q    r42.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted}        //  ALU pipe: int; $30
        add (16|M16)             r34.0<1>:q    r44.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted}        //  ALU pipe: int; $30
        mov (32|M0)              r36.0<1>:ud   r16.0<1;1,0>:uw                  {I@4}                //  ALU pipe: int; $32
        store.ugm.d16u32.a64 (32|M0)  [r32:4]   r36:2              {I@1,$3} // ex_desc:0x0; desc:0x8000B84 // $33
// B007: Preds:{B006, B002},  Succs:{}
_0_007:
        join (32|M0)                         L648                                                    // 
L648:
(W)     mov (16|M0)              r127.0<1>:f   r4.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $35
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$4} // wr:1+0, rd:0; end of thread // $35
L672:
(W)     mov (16|M0)              null<1>:ud    0x18F8A09E:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xFDBDB60D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1D:ud                                               // 


//.BankConflicts: 1
//.ByteRMWs: 0
//


//.numALUInst: 41
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 17
//.allAtOneDistNum: 3
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 3
//.AfterReadTokenDepCount: 1
