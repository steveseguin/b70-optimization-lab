//.kernel _ZTS11FloorKernelILi1ELb1ELb1ELb0ELb0EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 2601501411 2721796171 -hashmovs1 0 13 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 2601501411 2721796171 -hashmovs1 0 13 -GRFBumpUpNumber 2 "
//.instCount 43
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r3.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r3.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r3.0)
//.declare V0037 (47)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0041 (51)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r2.1)
//.declare V0043 (53)  rf=r size=4 type=d align=2 words (r2.4)
//.declare V0044 (54)  rf=r size=4 type=d align=2 words (r2.5)
//.declare P01 (55)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0045 (56)  rf=r size=4 type=d align=2 words (r2.6)
//.declare P02 (57)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0046 (58)  rf=r size=4 type=ud alias=V0045+0 align=2 words (r2.6)
//.declare V0047 (59)  rf=r size=4 type=ud alias=V0044+0 align=2 words (r2.5)
//.declare V0049 (61)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0052 (64)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0054 (66)  rf=r size=4 type=ud align=32 words (r5.0)
//.declare V0055 (67)  rf=r size=4 type=w alias=V0054+0 align=32 words (r5.0)
//.declare V0057 (69)  rf=r size=4 type=d align=2 words (r2.7)
//.declare V0058 (70)  rf=r size=4 type=f align=2 words (r5.1)
//.declare V0059 (71)  rf=r size=4 type=f alias=V0057+0 align=2 words (r2.7)
//.declare V0060 (72)  rf=r size=4 type=d align=2 words (r2.10)
//.declare V0061 (73)  rf=r size=4 type=d alias=V0058+0 align=2 words (r5.1)
//.declare P03 (74)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0062 (75)  rf=r size=4 type=ud alias=V0060+0 align=2 words (r2.10)
//.declare V0063 (76)  rf=r size=4 type=d align=2 words (r2.11)
//.declare V0064 (77)  rf=r size=4 type=ud alias=V0058+0 align=2 words (r5.1)
//.declare V0065 (78)  rf=r size=4 type=ud alias=V0063+0 align=2 words (r2.11)
//.declare V0066 (79)  rf=r size=4 type=d align=2 words (r2.12)
//.declare V0067 (80)  rf=r size=4 type=d align=2 words (r2.13)
//.declare V0068 (81)  rf=r size=4 type=d align=2 words (r2.14)
//.declare V0069 (82)  rf=r size=4 type=ud alias=V0067+0 align=2 words (r2.13)
//.declare V0070 (83)  rf=r size=4 type=ud alias=V0068+0 align=2 words (r2.14)
//.declare V0071 (84)  rf=r size=2 type=w align=32 words (r6.0)
//.declare V0072 (85)  rf=r size=4 type=d align=2 words (r2.15)
//.declare V0073 (86)  rf=r size=4 type=ud alias=V0072+0 align=2 words (r2.15)
//.declare V0077 (90)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0078 (91)  rf=r size=4 type=ud align=32 words (r10.0)
//.declare V0079 (92)  rf=r size=2 type=uw alias=V0071+0 align=32 words (r6.0)
//.declare  (93)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (94)  rf=r size=2 type=w alias=V0072+0 align=1 words (r2.30)
//.declare r0 (95)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (96)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (97)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (98)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (99)  rf=r size=64 type=ud align=32 words (r1.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0037    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0041    | :q       |    0x8 | r2       | inline+0x0       |
// | V0042    | :q       |    0x8 | r2+0x8   | inline+0x8       |
// | V0043    | :d       |    0x4 | r2+0x10  | inline+0x10      |
// | V0044    | :d       |    0x4 | r2+0x14  | inline+0x14      |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@2}           //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
// B002: Preds:{B001},  Succs:{B003, B008}
// _main:
(W)     mov (16|M0)              r3.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
        cmp (32|M0)   (eq)f2.0   null<2>:w     r1.0<1;1,0>:w     0:w               {A@1,$0.dst}      //  ALU pipe: int; $2
(~f2.0) goto (32|M0)                         _0_009            _0_009                                //  ALU pipe: int; $3
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B008}
_0_010:
(W)     add (1|M0)               r2.6<1>:d     r3.1<0;1,0>:d     r2.4<0;1,0>:d    {I@4}              //  ALU pipe: int; $5
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r2.6<0;1,0>:ud    r2.5<0;1,0>:ud   {I@1}              //  ALU pipe: int; $6
(~f1.0) goto (32|M0)                         _0_009            _0_009                                //  ALU pipe: int; $7
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B006}
_0_011:
(W)     shl (1|M0)               r2.4<1>:q     r2.6<0;1,0>:ud    1:w                                 //  ALU pipe: int; $10
(W)     add (1|M0)               r4.0<1>:q     r2.4<0;1,0>:q     r2.0<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $11
(W)     load.ugm.d16u32.a64 (1|M0)  r5:1        [r4:2]             {I@1,$1} // ex_desc:0x0; desc:0x4100B80 // $13
(W)     shl (1|M0)               r2.7<1>:d     r5.0<0;1,0>:ud    16:w               {$1.dst}         //  ALU pipe: int; $14
(W)     add (1|M0)               r5.1<1>:f     r2.7<0;1,0>:f     0x3F800000:f               {I@1}    //  ALU pipe: float; $15
(W)     and (1|M0)               r2.10<1>:d    r5.1<0;1,0>:d     2147483647:d               {F@1}    //  ALU pipe: int; $16
(W)     cmp (32|M0)   (gt)f0.0   null<1>:ud    r2.10<0;1,0>:ud   0x7F800000:ud              {I@1}    //  ALU pipe: int; $17
(W&f0.0) jmpi                                _0_012                                                  //  ALU pipe: int; $18
// B005: [inDivergent],  Preds:{B004},  Succs:{B007}
_0_013:
(W)     shr (1|M0)               r2.11<1>:ud   r5.1<0;1,0>:ud    16:w                                //  ALU pipe: int; $20
(W)     and (1|M0)               r2.12<1>:d    r2.11<0;1,0>:d    1:w               {I@1}             //  ALU pipe: int; $21
(W)     add3 (1|M0)              r2.13<1>:d    r2.12<0;0>:d      r5.1<0;0>:d       32767:w               {I@1} //  ALU pipe: int; $22
(W)     shr (1|M0)               r2.14<1>:ud   r2.13<0;1,0>:ud   16:w               {I@1}            //  ALU pipe: int; $23
(W)     mov (1|M0)               r6.0<2>:w     r2.14<0;1,0>:d                   {I@1}                //  ALU pipe: int; $24
(W)     jmpi                                 _0_014                                                  // $25
// B006: [inDivergent],  Preds:{B004},  Succs:{B007}
_0_012:
(W)     shr (1|M0)               r2.15<1>:ud   r5.1<0;1,0>:ud    16:w                                //  ALU pipe: int; $27
(W)     or (1|M0)                r6.0<1>:w     r2.30<0;1,0>:w    64:w               {I@1}            //  ALU pipe: int; $29
// B007: [inDivergent],  Preds:{B006, B005},  Succs:{B008}
_0_014:
(W)     add (1|M0)               r8.0<1>:q     r2.4<0;1,0>:q     r2.1<0;1,0>:q    {Compacted}        //  ALU pipe: int; $31
(W)     mov (1|M0)               r10.0<1>:ud   r6.0<0;1,0>:uw                   {I@2}                //  ALU pipe: int; $33
(W)     store.ugm.d16u32.a64 (1|M0)  [r8:2]     r10:1              {I@1,$2} // ex_desc:0x0; desc:0x4000B84 // $34
// B008: Preds:{B007, B003, B002},  Succs:{}
_0_009:
        join (32|M0)                         L568                                                    // 
L568:
(W)     mov (16|M0)              r127.0<1>:f   r3.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $36
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$3} // wr:1+0, rd:0; end of thread // $36
L592:
(W)     mov (16|M0)              null<1>:ud    0x9B0FC2E3:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xA23B504B:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0xD:ud                                                // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 34
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 16
//.allAtOneDistNum: 3
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 2
//.AfterReadTokenDepCount: 1
