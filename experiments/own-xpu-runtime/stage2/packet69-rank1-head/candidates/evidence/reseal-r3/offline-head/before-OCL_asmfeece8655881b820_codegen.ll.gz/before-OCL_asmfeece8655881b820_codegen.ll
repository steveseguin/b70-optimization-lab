; ------------------------------------------------
; OCL_asmfeece8655881b820_codegen.ll
; ------------------------------------------------
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v16:16:16-v24:32:32-v32:32:32-v48:64:64-v64:64:64-v96:128:128-v128:128:128-v192:256:256-v256:256:256-v512:512:512-v1024:1024:1024-n8:16:32"
target triple = "spir64-unknown-unknown"

; Function Attrs: convergent nounwind null_pointer_is_valid
define spir_kernel void @_ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_(i32 %0, ptr addrspace(1) align 1 %1, ptr addrspace(1) align 2 %2, ptr addrspace(1) align 2 %3, <8 x i32> %r0, <3 x i32> %globalOffset, <3 x i32> %enqueuedLocalSize, i16 %localIdX, i16 %localIdY, i16 %localIdZ, ptr %privateBase, i32 %bufferOffset, i32 %bufferOffset1, i32 %bufferOffset2, i32 %bindlessOffset, i32 %bindlessOffset3, i32 %bindlessOffset4) #0 {
  %5 = extractelement <3 x i32> %enqueuedLocalSize, i32 0
  %6 = extractelement <8 x i32> %r0, i32 1
  %simdLaneId16 = call i16 @llvm.genx.GenISA.simdLaneId()
  %simdLaneId = zext i16 %simdLaneId16 to i32
  %7 = call { i32, i32 } @llvm.genx.GenISA.mul.pair(i32 %5, i32 0, i32 %6, i32 0)
  %8 = extractvalue { i32, i32 } %7, 0
  %9 = extractvalue { i32, i32 } %7, 1
  %10 = insertelement <2 x i32> undef, i32 %8, i32 0
  %11 = insertelement <2 x i32> %10, i32 %9, i32 1
  %12 = bitcast <2 x i32> %11 to i64
  %13 = zext i16 %localIdX to i64
  %14 = add nuw i64 %12, %13
  %15 = lshr i64 %14, 5
  %16 = trunc i64 %15 to i32
  %17 = icmp uge i32 %16, %0
  %18 = icmp uge i32 %16, %0
  br i1 %18, label %..loopexit_crit_edge, label %.lr.ph, !stats.blockFrequency.digits !427, !stats.blockFrequency.scale !428

..loopexit_crit_edge:                             ; preds = %4
  br label %.loopexit, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

.lr.ph:                                           ; preds = %4
  %19 = bitcast i64 %15 to <2 x i32>
  %20 = extractelement <2 x i32> %19, i32 0
  %21 = extractelement <2 x i32> %19, i32 1
  %22 = call { i32, i32 } @llvm.genx.GenISA.mul.pair(i32 %20, i32 %21, i32 3200, i32 0)
  %23 = extractvalue { i32, i32 } %22, 0
  %24 = extractvalue { i32, i32 } %22, 1
  %25 = insertelement <2 x i32> undef, i32 %23, i32 0
  %26 = insertelement <2 x i32> %25, i32 %24, i32 1
  %27 = bitcast <2 x i32> %26 to i64
  %28 = ptrtoint ptr addrspace(1) %1 to i64
  %29 = add i64 %27, %28
  %30 = shl nuw nsw i32 %simdLaneId, 3
  %31 = add i64 %29, 2560
  %32 = ptrtoint ptr addrspace(1) %2 to i64
  br label %.preheader.preheader, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

.preheader.preheader:                             ; preds = %.preheader.preheader..preheader.preheader_crit_edge, %.lr.ph
  %33 = phi float [ 0.000000e+00, %.lr.ph ], [ %150, %.preheader.preheader..preheader.preheader_crit_edge ]
  %34 = phi i32 [ %30, %.lr.ph ], [ %152, %.preheader.preheader..preheader.preheader_crit_edge ]
  %35 = lshr exact i32 %34, 2
  %36 = and i32 %35, 1020
  %37 = zext i32 %36 to i64
  %38 = add i64 %31, %37
  %39 = inttoptr i64 %38 to ptr addrspace(1)
  %40 = load float, ptr addrspace(1) %39, align 1
  %41 = zext i32 %34 to i64
  %42 = add i64 %29, %41
  %IntToPtr2 = inttoptr i64 %42 to ptr addrspace(1)
  %vCastload = load i32, ptr addrspace(1) %IntToPtr2, align 1
  %43 = add i64 %42, 4
  %IntToPtr254 = inttoptr i64 %43 to ptr addrspace(1)
  %vCastload55 = load i32, ptr addrspace(1) %IntToPtr254, align 1
  %44 = shl nuw nsw i64 %41, 1
  %45 = add i64 %44, %32
  %IntToPtr256 = inttoptr i64 %45 to ptr addrspace(1)
  %vCastload57 = load i32, ptr addrspace(1) %IntToPtr256, align 2
  %46 = bitcast i32 %vCastload to <4 x i8>
  %47 = bitcast i32 %vCastload55 to <4 x i8>
  %48 = extractelement <4 x i8> %46, i32 0
  %49 = extractelement <4 x i8> %46, i32 1
  %50 = extractelement <4 x i8> %46, i32 2
  %51 = extractelement <4 x i8> %46, i32 3
  %52 = extractelement <4 x i8> %47, i32 0
  %53 = extractelement <4 x i8> %47, i32 1
  %54 = extractelement <4 x i8> %47, i32 2
  %55 = extractelement <4 x i8> %47, i32 3
  %56 = bitcast i32 %vCastload57 to <2 x i16>
  %57 = add i64 %45, 4
  %IntToPtr258 = inttoptr i64 %57 to ptr addrspace(1)
  %vCastload59 = load i32, ptr addrspace(1) %IntToPtr258, align 2
  %58 = add i64 %45, 8
  %IntToPtr260 = inttoptr i64 %58 to ptr addrspace(1)
  %vCastload61 = load i32, ptr addrspace(1) %IntToPtr260, align 2
  %59 = add i64 %45, 12
  %IntToPtr262 = inttoptr i64 %59 to ptr addrspace(1)
  %vCastload63 = load i32, ptr addrspace(1) %IntToPtr262, align 2
  %60 = bitcast i32 %vCastload59 to <2 x i16>
  %61 = extractelement <2 x i16> %56, i32 0
  %62 = extractelement <2 x i16> %56, i32 1
  %63 = extractelement <2 x i16> %60, i32 0
  %64 = extractelement <2 x i16> %60, i32 1
  %65 = bitcast i32 %vCastload61 to <2 x i16>
  %66 = bitcast i32 %vCastload63 to <2 x i16>
  %67 = extractelement <2 x i16> %65, i32 0
  %68 = extractelement <2 x i16> %65, i32 1
  %69 = extractelement <2 x i16> %66, i32 0
  %70 = extractelement <2 x i16> %66, i32 1
  %71 = zext i8 %48 to i32
  %72 = or i32 %71, -256
  %b2s = sext i8 %48 to i16
  %b2s64 = icmp slt i16 %b2s, 0
  %73 = select i1 %b2s64, i32 %72, i32 %71
  %74 = sitofp i32 %73 to float
  %75 = fmul float %40, %74
  %76 = zext i16 %61 to i32
  %77 = shl nuw i32 %76, 16, !spirv.Decorations !430
  %78 = bitcast i32 %77 to float
  %79 = fmul float %75, %78
  %80 = fadd float %33, %79
  %81 = zext i8 %49 to i32
  %82 = or i32 %81, -256
  %b2s65 = sext i8 %49 to i16
  %b2s66 = icmp slt i16 %b2s65, 0
  %83 = select i1 %b2s66, i32 %82, i32 %81
  %84 = sitofp i32 %83 to float
  %85 = fmul float %40, %84
  %86 = zext i16 %62 to i32
  %87 = shl nuw i32 %86, 16, !spirv.Decorations !430
  %88 = bitcast i32 %87 to float
  %89 = fmul float %85, %88
  %90 = fadd float %80, %89
  %91 = zext i8 %50 to i32
  %92 = or i32 %91, -256
  %b2s67 = sext i8 %50 to i16
  %b2s68 = icmp slt i16 %b2s67, 0
  %93 = select i1 %b2s68, i32 %92, i32 %91
  %94 = sitofp i32 %93 to float
  %95 = fmul float %40, %94
  %96 = zext i16 %63 to i32
  %97 = shl nuw i32 %96, 16, !spirv.Decorations !430
  %98 = bitcast i32 %97 to float
  %99 = fmul float %95, %98
  %100 = fadd float %90, %99
  %101 = zext i8 %51 to i32
  %102 = or i32 %101, -256
  %b2s69 = sext i8 %51 to i16
  %b2s70 = icmp slt i16 %b2s69, 0
  %103 = select i1 %b2s70, i32 %102, i32 %101
  %104 = sitofp i32 %103 to float
  %105 = fmul float %40, %104
  %106 = zext i16 %64 to i32
  %107 = shl nuw i32 %106, 16, !spirv.Decorations !430
  %108 = bitcast i32 %107 to float
  %109 = fmul float %105, %108
  %110 = fadd float %100, %109
  %111 = zext i8 %52 to i32
  %112 = or i32 %111, -256
  %b2s71 = sext i8 %52 to i16
  %b2s72 = icmp slt i16 %b2s71, 0
  %113 = select i1 %b2s72, i32 %112, i32 %111
  %114 = sitofp i32 %113 to float
  %115 = fmul float %40, %114
  %116 = zext i16 %67 to i32
  %117 = shl nuw i32 %116, 16, !spirv.Decorations !430
  %118 = bitcast i32 %117 to float
  %119 = fmul float %115, %118
  %120 = fadd float %110, %119
  %121 = zext i8 %53 to i32
  %122 = or i32 %121, -256
  %b2s73 = sext i8 %53 to i16
  %b2s74 = icmp slt i16 %b2s73, 0
  %123 = select i1 %b2s74, i32 %122, i32 %121
  %124 = sitofp i32 %123 to float
  %125 = fmul float %40, %124
  %126 = zext i16 %68 to i32
  %127 = shl nuw i32 %126, 16, !spirv.Decorations !430
  %128 = bitcast i32 %127 to float
  %129 = fmul float %125, %128
  %130 = fadd float %120, %129
  %131 = zext i8 %54 to i32
  %132 = or i32 %131, -256
  %b2s75 = sext i8 %54 to i16
  %b2s76 = icmp slt i16 %b2s75, 0
  %133 = select i1 %b2s76, i32 %132, i32 %131
  %134 = sitofp i32 %133 to float
  %135 = fmul float %40, %134
  %136 = zext i16 %69 to i32
  %137 = shl nuw i32 %136, 16, !spirv.Decorations !430
  %138 = bitcast i32 %137 to float
  %139 = fmul float %135, %138
  %140 = fadd float %130, %139
  %141 = zext i8 %55 to i32
  %142 = or i32 %141, -256
  %b2s77 = sext i8 %55 to i16
  %b2s78 = icmp slt i16 %b2s77, 0
  %143 = select i1 %b2s78, i32 %142, i32 %141
  %144 = sitofp i32 %143 to float
  %145 = fmul float %40, %144
  %146 = zext i16 %70 to i32
  %147 = shl nuw i32 %146, 16, !spirv.Decorations !430
  %148 = bitcast i32 %147 to float
  %149 = fmul float %145, %148
  %150 = fadd float %140, %149
  %151 = icmp ult i32 %34, 2304
  br i1 %151, label %.preheader.preheader..preheader.preheader_crit_edge, label %.loopexit.loopexit, !stats.blockFrequency.digits !432, !stats.blockFrequency.scale !428

.loopexit.loopexit:                               ; preds = %.preheader.preheader
  %.lcssa = phi float [ %150, %.preheader.preheader ]
  br label %.loopexit, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

.preheader.preheader..preheader.preheader_crit_edge: ; preds = %.preheader.preheader
  %152 = add nuw nsw i32 %34, 256, !spirv.Decorations !433
  br label %.preheader.preheader, !stats.blockFrequency.digits !435, !stats.blockFrequency.scale !428

.loopexit:                                        ; preds = %..loopexit_crit_edge, %.loopexit.loopexit
  %153 = phi float [ 0.000000e+00, %..loopexit_crit_edge ], [ %.lcssa, %.loopexit.loopexit ]
  %154 = add nuw nsw i32 %simdLaneId, 1
  %155 = and i32 %154, 31
  %simdShuffle = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %153, i32 %155, i32 0)
  %156 = and i32 %simdLaneId, 1
  %157 = icmp eq i32 %156, 0
  %158 = select i1 %157, float %simdShuffle, float -0.000000e+00
  %159 = fadd float %153, %158
  %160 = add nuw nsw i32 %simdLaneId, 2
  %161 = and i32 %160, 31
  %simdShuffle.1 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %159, i32 %161, i32 0)
  %162 = and i32 %simdLaneId, 3
  %163 = icmp eq i32 %162, 0
  %164 = select i1 %163, float %simdShuffle.1, float -0.000000e+00
  %165 = fadd float %159, %164
  %166 = add nuw nsw i32 %simdLaneId, 4
  %167 = and i32 %166, 31
  %simdShuffle.2 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %165, i32 %167, i32 0)
  %168 = and i32 %simdLaneId, 7
  %169 = icmp eq i32 %168, 0
  %170 = select i1 %169, float %simdShuffle.2, float -0.000000e+00
  %171 = fadd float %165, %170
  %172 = add nuw nsw i32 %simdLaneId, 8
  %173 = and i32 %172, 31
  %simdShuffle.3 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %171, i32 %173, i32 0)
  %174 = and i32 %simdLaneId, 15
  %175 = icmp eq i32 %174, 0
  %176 = select i1 %175, float %simdShuffle.3, float -0.000000e+00
  %177 = fadd float %171, %176
  %178 = add nuw nsw i32 %simdLaneId, 16
  %179 = and i32 %178, 31
  %simdShuffle.4 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %177, i32 %179, i32 0)
  %180 = icmp ne i16 %simdLaneId16, 0
  %181 = or i1 %180, %17
  br i1 %181, label %.loopexit.._crit_edge_crit_edge, label %182, !stats.blockFrequency.digits !427, !stats.blockFrequency.scale !428

.loopexit.._crit_edge_crit_edge:                  ; preds = %.loopexit
  br label %._crit_edge, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

182:                                              ; preds = %.loopexit
  %183 = icmp eq i16 %simdLaneId16, 0
  %184 = select i1 %183, float %simdShuffle.4, float -0.000000e+00
  %185 = fadd float %177, %184
  %186 = bitcast float %185 to i32
  %187 = and i32 %186, 2147483647
  %188 = icmp ugt i32 %187, 2139095040
  br i1 %188, label %196, label %189, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

189:                                              ; preds = %182
  %190 = lshr i32 %186, 16
  %191 = and i32 %190, 1
  %192 = add i32 %191, %186
  %193 = add i32 %192, 32767
  %194 = lshr i32 %193, 16
  %195 = trunc i32 %194 to i16
  br label %200, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !428

196:                                              ; preds = %182
  %197 = lshr i32 %186, 16
  %198 = trunc i32 %197 to i16
  %199 = or i16 %198, 64
  br label %200, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !428

200:                                              ; preds = %189, %196
  %201 = phi i16 [ %199, %196 ], [ %195, %189 ]
  %202 = ptrtoint ptr addrspace(1) %3 to i64
  %203 = shl nuw nsw i64 %15, 1
  %204 = add i64 %203, %202
  %205 = inttoptr i64 %204 to ptr addrspace(1)
  store i16 %201, ptr addrspace(1) %205, align 2
  br label %._crit_edge, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

._crit_edge:                                      ; preds = %.loopexit.._crit_edge_crit_edge, %200
  ret void, !stats.blockFrequency.digits !427, !stats.blockFrequency.scale !428
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.assume(i1 noundef) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: convergent nounwind null_pointer_is_valid
define spir_kernel void @_ZTSZZNK3p694HeadILj128EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_(i32 %0, ptr addrspace(1) align 1 %1, ptr addrspace(1) align 2 %2, ptr addrspace(1) align 2 %3, <8 x i32> %r0, <3 x i32> %globalOffset, <3 x i32> %enqueuedLocalSize, i16 %localIdX, i16 %localIdY, i16 %localIdZ, ptr %privateBase, i32 %bufferOffset, i32 %bufferOffset1, i32 %bufferOffset2, i32 %bindlessOffset, i32 %bindlessOffset3, i32 %bindlessOffset4) #0 {
  %5 = extractelement <3 x i32> %enqueuedLocalSize, i32 0
  %6 = extractelement <8 x i32> %r0, i32 1
  %simdLaneId16 = call i16 @llvm.genx.GenISA.simdLaneId()
  %simdLaneId = zext i16 %simdLaneId16 to i32
  %7 = call { i32, i32 } @llvm.genx.GenISA.mul.pair(i32 %5, i32 0, i32 %6, i32 0)
  %8 = extractvalue { i32, i32 } %7, 0
  %9 = extractvalue { i32, i32 } %7, 1
  %10 = insertelement <2 x i32> undef, i32 %8, i32 0
  %11 = insertelement <2 x i32> %10, i32 %9, i32 1
  %12 = bitcast <2 x i32> %11 to i64
  %13 = zext i16 %localIdX to i64
  %14 = add nuw i64 %12, %13
  %15 = lshr i64 %14, 5
  %16 = trunc i64 %15 to i32
  %17 = icmp uge i32 %16, %0
  %18 = icmp uge i32 %16, %0
  br i1 %18, label %..loopexit_crit_edge, label %.lr.ph, !stats.blockFrequency.digits !427, !stats.blockFrequency.scale !428

..loopexit_crit_edge:                             ; preds = %4
  br label %.loopexit, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

.lr.ph:                                           ; preds = %4
  %19 = bitcast i64 %15 to <2 x i32>
  %20 = extractelement <2 x i32> %19, i32 0
  %21 = extractelement <2 x i32> %19, i32 1
  %22 = call { i32, i32 } @llvm.genx.GenISA.mul.pair(i32 %20, i32 %21, i32 3200, i32 0)
  %23 = extractvalue { i32, i32 } %22, 0
  %24 = extractvalue { i32, i32 } %22, 1
  %25 = insertelement <2 x i32> undef, i32 %23, i32 0
  %26 = insertelement <2 x i32> %25, i32 %24, i32 1
  %27 = bitcast <2 x i32> %26 to i64
  %28 = ptrtoint ptr addrspace(1) %1 to i64
  %29 = add i64 %27, %28
  %30 = shl nuw nsw i32 %simdLaneId, 3
  %31 = add i64 %29, 2560
  %32 = ptrtoint ptr addrspace(1) %2 to i64
  br label %.preheader.preheader, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

.preheader.preheader:                             ; preds = %.preheader.preheader..preheader.preheader_crit_edge, %.lr.ph
  %33 = phi float [ 0.000000e+00, %.lr.ph ], [ %150, %.preheader.preheader..preheader.preheader_crit_edge ]
  %34 = phi i32 [ %30, %.lr.ph ], [ %152, %.preheader.preheader..preheader.preheader_crit_edge ]
  %35 = lshr exact i32 %34, 2
  %36 = and i32 %35, 1020
  %37 = zext i32 %36 to i64
  %38 = add i64 %31, %37
  %39 = inttoptr i64 %38 to ptr addrspace(1)
  %40 = load float, ptr addrspace(1) %39, align 1
  %41 = zext i32 %34 to i64
  %42 = add i64 %29, %41
  %IntToPtr2 = inttoptr i64 %42 to ptr addrspace(1)
  %vCastload = load i32, ptr addrspace(1) %IntToPtr2, align 1
  %43 = add i64 %42, 4
  %IntToPtr254 = inttoptr i64 %43 to ptr addrspace(1)
  %vCastload55 = load i32, ptr addrspace(1) %IntToPtr254, align 1
  %44 = shl nuw nsw i64 %41, 1
  %45 = add i64 %44, %32
  %IntToPtr256 = inttoptr i64 %45 to ptr addrspace(1)
  %vCastload57 = load i32, ptr addrspace(1) %IntToPtr256, align 2
  %46 = bitcast i32 %vCastload to <4 x i8>
  %47 = bitcast i32 %vCastload55 to <4 x i8>
  %48 = extractelement <4 x i8> %46, i32 0
  %49 = extractelement <4 x i8> %46, i32 1
  %50 = extractelement <4 x i8> %46, i32 2
  %51 = extractelement <4 x i8> %46, i32 3
  %52 = extractelement <4 x i8> %47, i32 0
  %53 = extractelement <4 x i8> %47, i32 1
  %54 = extractelement <4 x i8> %47, i32 2
  %55 = extractelement <4 x i8> %47, i32 3
  %56 = bitcast i32 %vCastload57 to <2 x i16>
  %57 = add i64 %45, 4
  %IntToPtr258 = inttoptr i64 %57 to ptr addrspace(1)
  %vCastload59 = load i32, ptr addrspace(1) %IntToPtr258, align 2
  %58 = add i64 %45, 8
  %IntToPtr260 = inttoptr i64 %58 to ptr addrspace(1)
  %vCastload61 = load i32, ptr addrspace(1) %IntToPtr260, align 2
  %59 = add i64 %45, 12
  %IntToPtr262 = inttoptr i64 %59 to ptr addrspace(1)
  %vCastload63 = load i32, ptr addrspace(1) %IntToPtr262, align 2
  %60 = bitcast i32 %vCastload59 to <2 x i16>
  %61 = extractelement <2 x i16> %56, i32 0
  %62 = extractelement <2 x i16> %56, i32 1
  %63 = extractelement <2 x i16> %60, i32 0
  %64 = extractelement <2 x i16> %60, i32 1
  %65 = bitcast i32 %vCastload61 to <2 x i16>
  %66 = bitcast i32 %vCastload63 to <2 x i16>
  %67 = extractelement <2 x i16> %65, i32 0
  %68 = extractelement <2 x i16> %65, i32 1
  %69 = extractelement <2 x i16> %66, i32 0
  %70 = extractelement <2 x i16> %66, i32 1
  %71 = zext i8 %48 to i32
  %72 = or i32 %71, -256
  %b2s = sext i8 %48 to i16
  %b2s64 = icmp slt i16 %b2s, 0
  %73 = select i1 %b2s64, i32 %72, i32 %71
  %74 = sitofp i32 %73 to float
  %75 = fmul float %40, %74
  %76 = zext i16 %61 to i32
  %77 = shl nuw i32 %76, 16, !spirv.Decorations !430
  %78 = bitcast i32 %77 to float
  %79 = fmul float %75, %78
  %80 = fadd float %33, %79
  %81 = zext i8 %49 to i32
  %82 = or i32 %81, -256
  %b2s65 = sext i8 %49 to i16
  %b2s66 = icmp slt i16 %b2s65, 0
  %83 = select i1 %b2s66, i32 %82, i32 %81
  %84 = sitofp i32 %83 to float
  %85 = fmul float %40, %84
  %86 = zext i16 %62 to i32
  %87 = shl nuw i32 %86, 16, !spirv.Decorations !430
  %88 = bitcast i32 %87 to float
  %89 = fmul float %85, %88
  %90 = fadd float %80, %89
  %91 = zext i8 %50 to i32
  %92 = or i32 %91, -256
  %b2s67 = sext i8 %50 to i16
  %b2s68 = icmp slt i16 %b2s67, 0
  %93 = select i1 %b2s68, i32 %92, i32 %91
  %94 = sitofp i32 %93 to float
  %95 = fmul float %40, %94
  %96 = zext i16 %63 to i32
  %97 = shl nuw i32 %96, 16, !spirv.Decorations !430
  %98 = bitcast i32 %97 to float
  %99 = fmul float %95, %98
  %100 = fadd float %90, %99
  %101 = zext i8 %51 to i32
  %102 = or i32 %101, -256
  %b2s69 = sext i8 %51 to i16
  %b2s70 = icmp slt i16 %b2s69, 0
  %103 = select i1 %b2s70, i32 %102, i32 %101
  %104 = sitofp i32 %103 to float
  %105 = fmul float %40, %104
  %106 = zext i16 %64 to i32
  %107 = shl nuw i32 %106, 16, !spirv.Decorations !430
  %108 = bitcast i32 %107 to float
  %109 = fmul float %105, %108
  %110 = fadd float %100, %109
  %111 = zext i8 %52 to i32
  %112 = or i32 %111, -256
  %b2s71 = sext i8 %52 to i16
  %b2s72 = icmp slt i16 %b2s71, 0
  %113 = select i1 %b2s72, i32 %112, i32 %111
  %114 = sitofp i32 %113 to float
  %115 = fmul float %40, %114
  %116 = zext i16 %67 to i32
  %117 = shl nuw i32 %116, 16, !spirv.Decorations !430
  %118 = bitcast i32 %117 to float
  %119 = fmul float %115, %118
  %120 = fadd float %110, %119
  %121 = zext i8 %53 to i32
  %122 = or i32 %121, -256
  %b2s73 = sext i8 %53 to i16
  %b2s74 = icmp slt i16 %b2s73, 0
  %123 = select i1 %b2s74, i32 %122, i32 %121
  %124 = sitofp i32 %123 to float
  %125 = fmul float %40, %124
  %126 = zext i16 %68 to i32
  %127 = shl nuw i32 %126, 16, !spirv.Decorations !430
  %128 = bitcast i32 %127 to float
  %129 = fmul float %125, %128
  %130 = fadd float %120, %129
  %131 = zext i8 %54 to i32
  %132 = or i32 %131, -256
  %b2s75 = sext i8 %54 to i16
  %b2s76 = icmp slt i16 %b2s75, 0
  %133 = select i1 %b2s76, i32 %132, i32 %131
  %134 = sitofp i32 %133 to float
  %135 = fmul float %40, %134
  %136 = zext i16 %69 to i32
  %137 = shl nuw i32 %136, 16, !spirv.Decorations !430
  %138 = bitcast i32 %137 to float
  %139 = fmul float %135, %138
  %140 = fadd float %130, %139
  %141 = zext i8 %55 to i32
  %142 = or i32 %141, -256
  %b2s77 = sext i8 %55 to i16
  %b2s78 = icmp slt i16 %b2s77, 0
  %143 = select i1 %b2s78, i32 %142, i32 %141
  %144 = sitofp i32 %143 to float
  %145 = fmul float %40, %144
  %146 = zext i16 %70 to i32
  %147 = shl nuw i32 %146, 16, !spirv.Decorations !430
  %148 = bitcast i32 %147 to float
  %149 = fmul float %145, %148
  %150 = fadd float %140, %149
  %151 = icmp ult i32 %34, 2304
  br i1 %151, label %.preheader.preheader..preheader.preheader_crit_edge, label %.loopexit.loopexit, !stats.blockFrequency.digits !432, !stats.blockFrequency.scale !428

.loopexit.loopexit:                               ; preds = %.preheader.preheader
  %.lcssa = phi float [ %150, %.preheader.preheader ]
  br label %.loopexit, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

.preheader.preheader..preheader.preheader_crit_edge: ; preds = %.preheader.preheader
  %152 = add nuw nsw i32 %34, 256, !spirv.Decorations !433
  br label %.preheader.preheader, !stats.blockFrequency.digits !435, !stats.blockFrequency.scale !428

.loopexit:                                        ; preds = %..loopexit_crit_edge, %.loopexit.loopexit
  %153 = phi float [ 0.000000e+00, %..loopexit_crit_edge ], [ %.lcssa, %.loopexit.loopexit ]
  %154 = add nuw nsw i32 %simdLaneId, 1
  %155 = and i32 %154, 31
  %simdShuffle = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %153, i32 %155, i32 0)
  %156 = and i32 %simdLaneId, 1
  %157 = icmp eq i32 %156, 0
  %158 = select i1 %157, float %simdShuffle, float -0.000000e+00
  %159 = fadd float %153, %158
  %160 = add nuw nsw i32 %simdLaneId, 2
  %161 = and i32 %160, 31
  %simdShuffle.1 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %159, i32 %161, i32 0)
  %162 = and i32 %simdLaneId, 3
  %163 = icmp eq i32 %162, 0
  %164 = select i1 %163, float %simdShuffle.1, float -0.000000e+00
  %165 = fadd float %159, %164
  %166 = add nuw nsw i32 %simdLaneId, 4
  %167 = and i32 %166, 31
  %simdShuffle.2 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %165, i32 %167, i32 0)
  %168 = and i32 %simdLaneId, 7
  %169 = icmp eq i32 %168, 0
  %170 = select i1 %169, float %simdShuffle.2, float -0.000000e+00
  %171 = fadd float %165, %170
  %172 = add nuw nsw i32 %simdLaneId, 8
  %173 = and i32 %172, 31
  %simdShuffle.3 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %171, i32 %173, i32 0)
  %174 = and i32 %simdLaneId, 15
  %175 = icmp eq i32 %174, 0
  %176 = select i1 %175, float %simdShuffle.3, float -0.000000e+00
  %177 = fadd float %171, %176
  %178 = add nuw nsw i32 %simdLaneId, 16
  %179 = and i32 %178, 31
  %simdShuffle.4 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %177, i32 %179, i32 0)
  %180 = icmp ne i16 %simdLaneId16, 0
  %181 = or i1 %180, %17
  br i1 %181, label %.loopexit.._crit_edge_crit_edge, label %182, !stats.blockFrequency.digits !427, !stats.blockFrequency.scale !428

.loopexit.._crit_edge_crit_edge:                  ; preds = %.loopexit
  br label %._crit_edge, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

182:                                              ; preds = %.loopexit
  %183 = icmp eq i16 %simdLaneId16, 0
  %184 = select i1 %183, float %simdShuffle.4, float -0.000000e+00
  %185 = fadd float %177, %184
  %186 = bitcast float %185 to i32
  %187 = and i32 %186, 2147483647
  %188 = icmp ugt i32 %187, 2139095040
  br i1 %188, label %196, label %189, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

189:                                              ; preds = %182
  %190 = lshr i32 %186, 16
  %191 = and i32 %190, 1
  %192 = add i32 %191, %186
  %193 = add i32 %192, 32767
  %194 = lshr i32 %193, 16
  %195 = trunc i32 %194 to i16
  br label %200, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !428

196:                                              ; preds = %182
  %197 = lshr i32 %186, 16
  %198 = trunc i32 %197 to i16
  %199 = or i16 %198, 64
  br label %200, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !428

200:                                              ; preds = %189, %196
  %201 = phi i16 [ %199, %196 ], [ %195, %189 ]
  %202 = ptrtoint ptr addrspace(1) %3 to i64
  %203 = shl nuw nsw i64 %15, 1
  %204 = add i64 %203, %202
  %205 = inttoptr i64 %204 to ptr addrspace(1)
  store i16 %201, ptr addrspace(1) %205, align 2
  br label %._crit_edge, !stats.blockFrequency.digits !429, !stats.blockFrequency.scale !428

._crit_edge:                                      ; preds = %.loopexit.._crit_edge_crit_edge, %200
  ret void, !stats.blockFrequency.digits !427, !stats.blockFrequency.scale !428
}

; Function Attrs: convergent nounwind
declare spir_func float @__builtin_IB_simd_shuffle_f(float noundef, i32 noundef) local_unnamed_addr #3

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_group_id(i32 noundef) local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_enqueued_local_size(i32 noundef) local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_local_id_x() local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_local_id_y() local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_local_id_z() local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_global_offset(i32 noundef) local_unnamed_addr #4

; Function Attrs: convergent nounwind
declare spir_func i32 @__builtin_IB_get_simd_id() local_unnamed_addr #3

declare i32 @printf(ptr addrspace(2), ...)

; Function Desc: 
; Output: 
; Function Attrs: nounwind willreturn memory(none)
declare i16 @llvm.genx.GenISA.simdLaneId() #5

; Function Desc: 
; Output: 
; Arg 0: 
; Arg 1: 
; Arg 2: 
; Function Attrs: convergent nounwind willreturn memory(none)
declare float @llvm.genx.GenISA.WaveShuffleIndex.f32(float, i32, i32) #6

; Function Desc: 
; Output: 
; Arg 0: 
; Arg 1: 
; Arg 2: 
; Arg 3: 
; Function Attrs: nounwind willreturn memory(none)
declare { i32, i32 } @llvm.genx.GenISA.mul.pair(i32, i32, i32, i32) #5

attributes #0 = { convergent nounwind null_pointer_is_valid }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { convergent nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #4 = { convergent mustprogress nofree nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #5 = { nounwind willreturn memory(none) }
attributes #6 = { convergent nounwind willreturn memory(none) }

!spirv.MemoryModel = !{!0}
!spirv.Source = !{!1}
!spirv.Generator = !{!2}
!igc.functions = !{!3, !25}
!IGCMetadata = !{!26}
!opencl.ocl.version = !{!424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424}
!opencl.spir.version = !{!424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424, !424}
!llvm.ident = !{!425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425, !425}
!llvm.module.flags = !{!426}

!0 = !{i32 2, i32 2}
!1 = !{i32 4, i32 100000}
!2 = !{i16 6, i16 14}
!3 = !{ptr @_ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_, !4}
!4 = !{!5, !6, !23, !24}
!5 = !{!"function_type", i32 0}
!6 = !{!"implicit_arg_desc", !7, !8, !9, !10, !11, !12, !13, !14, !16, !18, !20, !21, !22}
!7 = !{i32 0}
!8 = !{i32 2}
!9 = !{i32 7}
!10 = !{i32 8}
!11 = !{i32 9}
!12 = !{i32 10}
!13 = !{i32 13}
!14 = !{i32 15, !15}
!15 = !{!"explicit_arg_num", i32 1}
!16 = !{i32 15, !17}
!17 = !{!"explicit_arg_num", i32 2}
!18 = !{i32 15, !19}
!19 = !{!"explicit_arg_num", i32 3}
!20 = !{i32 54, !15}
!21 = !{i32 54, !17}
!22 = !{i32 54, !19}
!23 = !{!"sub_group_size", i32 32}
!24 = !{!"max_reg_pressure", i32 39}
!25 = !{ptr @_ZTSZZNK3p694HeadILj128EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_, !4}
!26 = !{!"ModuleMD", !27, !28, !137, !253, !284, !302, !323, !333, !335, !336, !351, !352, !353, !354, !358, !359, !366, !367, !368, !369, !370, !371, !372, !373, !374, !375, !376, !378, !382, !383, !384, !385, !386, !387, !388, !389, !390, !391, !392, !393, !394, !395, !204, !396, !401, !402, !404, !406, !409, !410, !411, !413, !414, !415, !420, !421, !422, !423}
!27 = !{!"isPrecise", i1 false}
!28 = !{!"compOpt", !29, !30, !31, !32, !33, !34, !35, !36, !37, !38, !39, !40, !41, !42, !43, !44, !45, !46, !47, !48, !49, !50, !51, !52, !53, !54, !55, !56, !57, !58, !59, !60, !61, !62, !63, !64, !65, !66, !67, !68, !69, !70, !71, !72, !73, !74, !75, !76, !77, !78, !79, !80, !81, !82, !83, !84, !85, !86, !87, !88, !89, !90, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108, !109, !110, !111, !112, !113, !114, !115, !116, !117, !118, !119, !120, !121, !122, !123, !124, !125, !126, !127, !128, !129, !130, !131, !132, !133, !134, !135, !136}
!29 = !{!"DenormsAreZero", i1 false}
!30 = !{!"BFTFDenormsAreZero", i1 false}
!31 = !{!"CorrectlyRoundedDivSqrt", i1 false}
!32 = !{!"OptDisable", i1 false}
!33 = !{!"MadEnable", i1 false}
!34 = !{!"NoSignedZeros", i1 false}
!35 = !{!"NoNaNs", i1 false}
!36 = !{!"FloatDenormMode16", !"FLOAT_DENORM_RETAIN"}
!37 = !{!"FloatDenormMode32", !"FLOAT_DENORM_RETAIN"}
!38 = !{!"FloatDenormMode64", !"FLOAT_DENORM_RETAIN"}
!39 = !{!"FloatDenormModeBFTF", !"FLOAT_DENORM_RETAIN"}
!40 = !{!"FloatRoundingMode", i32 0}
!41 = !{!"FloatCvtIntRoundingMode", i32 3}
!42 = !{!"LoadCacheDefault", i32 4}
!43 = !{!"StoreCacheDefault", i32 2}
!44 = !{!"VISAPreSchedRPThreshold", i32 0}
!45 = !{!"VISAPreSchedCtrl", i32 0}
!46 = !{!"SetLoopUnrollThreshold", i32 0}
!47 = !{!"UnsafeMathOptimizations", i1 false}
!48 = !{!"disableCustomUnsafeOpts", i1 false}
!49 = !{!"disableReducePow", i1 false}
!50 = !{!"disableSqrtOpt", i1 false}
!51 = !{!"FiniteMathOnly", i1 false}
!52 = !{!"FastRelaxedMath", i1 false}
!53 = !{!"DashGSpecified", i1 false}
!54 = !{!"FastCompilation", i1 false}
!55 = !{!"UseScratchSpacePrivateMemory", i1 true}
!56 = !{!"RelaxedBuiltins", i1 false}
!57 = !{!"SubgroupIndependentForwardProgressRequired", i1 true}
!58 = !{!"GreaterThan2GBBufferRequired", i1 true}
!59 = !{!"GreaterThan4GBBufferRequired", i1 true}
!60 = !{!"DisableA64WA", i1 false}
!61 = !{!"ForceEnableA64WA", i1 false}
!62 = !{!"PushConstantsEnable", i1 true}
!63 = !{!"HasPositivePointerOffset", i1 false}
!64 = !{!"HasBufferOffsetArg", i1 true}
!65 = !{!"BufferOffsetArgOptional", i1 true}
!66 = !{!"replaceGlobalOffsetsByZero", i1 false}
!67 = !{!"forcePixelShaderSIMDMode", i32 0}
!68 = !{!"forceTotalGRFNum", i32 0}
!69 = !{!"ForceGeomFFShaderSIMDMode", i32 0}
!70 = !{!"pixelShaderDoNotAbortOnSpill", i1 false}
!71 = !{!"UniformWGS", i1 false}
!72 = !{!"disableVertexComponentPacking", i1 false}
!73 = !{!"disablePartialVertexComponentPacking", i1 false}
!74 = !{!"PreferBindlessImages", i1 true}
!75 = !{!"UseBindlessMode", i1 true}
!76 = !{!"UseLegacyBindlessMode", i1 false}
!77 = !{!"disableMathRefactoring", i1 false}
!78 = !{!"atomicBranch", i1 false}
!79 = !{!"spillCompression", i1 false}
!80 = !{!"AllowLICM", i1 true}
!81 = !{!"DisableEarlyOut", i1 false}
!82 = !{!"ForceInt32DivRemEmu", i1 false}
!83 = !{!"ForceInt32DivRemEmuSP", i1 false}
!84 = !{!"DisableIntDivRemIncrementReduction", i1 false}
!85 = !{!"DisableFastestSingleCSSIMD", i1 false}
!86 = !{!"DisableFastestLinearScan", i1 false}
!87 = !{!"UseStatelessforPrivateMemory", i1 false}
!88 = !{!"EnableTakeGlobalAddress", i1 false}
!89 = !{!"IsLibraryCompilation", i1 false}
!90 = !{!"LibraryCompileSIMDSize", i32 0}
!91 = !{!"FastVISACompile", i1 false}
!92 = !{!"MatchSinCosPi", i1 false}
!93 = !{!"ExcludeIRFromZEBinary", i1 false}
!94 = !{!"EmitZeBinVISASections", i1 false}
!95 = !{!"FP64GenEmulationEnabled", i1 false}
!96 = !{!"FP64GenConvEmulationEnabled", i1 false}
!97 = !{!"allowDisableRematforCS", i1 false}
!98 = !{!"DisableIncSpillCostAllAddrTaken", i1 false}
!99 = !{!"DisableCPSOmaskWA", i1 false}
!100 = !{!"DisableFastestGopt", i1 false}
!101 = !{!"WaForceHalfPromotionComputeShader", i1 false}
!102 = !{!"WaForceHalfPromotionPixelVertexShader", i1 false}
!103 = !{!"DisableConstantCoalescing", i1 false}
!104 = !{!"EnableUndefAlphaOutputAsRed", i1 true}
!105 = !{!"WaEnableALTModeVisaWA", i1 false}
!106 = !{!"EnableLdStCombineforLoad", i1 false}
!107 = !{!"EnableLdStCombinewithDummyLoad", i1 false}
!108 = !{!"ForceUniformBuffer", i1 false}
!109 = !{!"ForceUniformSurfaceSampler", i1 false}
!110 = !{!"EnableIndependentSharedMemoryFenceFunctionality", i1 false}
!111 = !{!"NewSpillCostFunction", i1 false}
!112 = !{!"EnableVRT", i1 true}
!113 = !{!"ForceLargeGRFNum4RQ", i1 false}
!114 = !{!"DisableEUFusion", i1 false}
!115 = !{!"DisableFDivToFMulInvOpt", i1 false}
!116 = !{!"initializePhiSampleSourceWA", i1 false}
!117 = !{!"WaDisableSubspanUseNoMaskForCB", i1 false}
!118 = !{!"DisableLoosenSimd32Occu", i1 false}
!119 = !{!"FastestS1Options", i32 0}
!120 = !{!"DisableFastestForWaveIntrinsicsCS", i1 false}
!121 = !{!"ForceLinearWalkOnLinearUAV", i1 false}
!122 = !{!"LscSamplerRouting", i32 0}
!123 = !{!"UseBarrierControlFlowOptimization", i1 false}
!124 = !{!"EnableDynamicRQManagement", i1 false}
!125 = !{!"WaDisablePayloadCoalescing", i1 false}
!126 = !{!"Quad8InputThreshold", i32 0}
!127 = !{!"UseResourceLoopUnrollNested", i1 false}
!128 = !{!"DisableLoopUnroll", i1 false}
!129 = !{!"ForcePushConstantMode", i32 0}
!130 = !{!"UseInstructionHoistingOptimization", i1 false}
!131 = !{!"DisableResourceLoopDestLifeTimeStart", i1 false}
!132 = !{!"ForceVRTGRFCeiling", i32 0}
!133 = !{!"DisableSamplerBackingByLSC", i32 0}
!134 = !{!"UseLinearScanRA", i1 false}
!135 = !{!"DisableConvertingAtomicIAddToIncDec", i1 false}
!136 = !{!"ZeroInitRegistersBeforeExecution", i1 false}
!137 = !{!"FuncMD", !138, !139, !251, !252}
!138 = !{!"FuncMDMap[0]", ptr @_ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_}
!139 = !{!"FuncMDValue[0]", !140, !141, !145, !146, !147, !170, !196, !197, !198, !199, !200, !201, !202, !203, !204, !205, !206, !207, !208, !209, !210, !211, !212, !213, !214, !215, !216, !221, !226, !231, !236, !241, !246, !247}
!140 = !{!"localOffsets"}
!141 = !{!"workGroupWalkOrder", !142, !143, !144}
!142 = !{!"dim0", i32 0}
!143 = !{!"dim1", i32 1}
!144 = !{!"dim2", i32 2}
!145 = !{!"funcArgs"}
!146 = !{!"functionType", !"KernelFunction"}
!147 = !{!"rtInfo", !148, !149, !150, !151, !152, !153, !154, !155, !156, !157, !158, !159, !160, !161, !162, !163, !165, !166, !167, !168, !169}
!148 = !{!"callableShaderType", !"NumberOfCallableShaderTypes"}
!149 = !{!"isContinuation", i1 false}
!150 = !{!"hasTraceRayPayload", i1 false}
!151 = !{!"hasHitAttributes", i1 false}
!152 = !{!"hasCallableData", i1 false}
!153 = !{!"ShaderStackSize", i32 0}
!154 = !{!"ShaderHash", i64 0}
!155 = !{!"ShaderName", !""}
!156 = !{!"ParentName", !""}
!157 = !{!"SlotNum", ptr null}
!158 = !{!"NOSSize", i32 0}
!159 = !{!"globalRootSignatureSize", i32 0}
!160 = !{!"Entries"}
!161 = !{!"SpillUnions"}
!162 = !{!"CustomHitAttrSizeInBytes", i32 0}
!163 = !{!"Types", !164}
!164 = !{!"FullFrameTys"}
!165 = !{!"Aliases"}
!166 = !{!"numSyncRTStacks", i32 0}
!167 = !{!"NumCoherenceHintBits", i32 0}
!168 = !{!"useSyncHWStack", i1 false}
!169 = !{!"OriginatingShaderName", !""}
!170 = !{!"resAllocMD", !171, !172, !173, !174, !195}
!171 = !{!"uavsNumType", i32 0}
!172 = !{!"srvsNumType", i32 0}
!173 = !{!"samplersNumType", i32 0}
!174 = !{!"argAllocMDList", !175, !179, !180, !181, !182, !183, !184, !185, !186, !187, !188, !189, !190, !191, !192, !193, !194}
!175 = !{!"argAllocMDListVec[0]", !176, !177, !178}
!176 = !{!"type", i32 0}
!177 = !{!"extensionType", i32 -1}
!178 = !{!"indexType", i32 -1}
!179 = !{!"argAllocMDListVec[1]", !176, !177, !178}
!180 = !{!"argAllocMDListVec[2]", !176, !177, !178}
!181 = !{!"argAllocMDListVec[3]", !176, !177, !178}
!182 = !{!"argAllocMDListVec[4]", !176, !177, !178}
!183 = !{!"argAllocMDListVec[5]", !176, !177, !178}
!184 = !{!"argAllocMDListVec[6]", !176, !177, !178}
!185 = !{!"argAllocMDListVec[7]", !176, !177, !178}
!186 = !{!"argAllocMDListVec[8]", !176, !177, !178}
!187 = !{!"argAllocMDListVec[9]", !176, !177, !178}
!188 = !{!"argAllocMDListVec[10]", !176, !177, !178}
!189 = !{!"argAllocMDListVec[11]", !176, !177, !178}
!190 = !{!"argAllocMDListVec[12]", !176, !177, !178}
!191 = !{!"argAllocMDListVec[13]", !176, !177, !178}
!192 = !{!"argAllocMDListVec[14]", !176, !177, !178}
!193 = !{!"argAllocMDListVec[15]", !176, !177, !178}
!194 = !{!"argAllocMDListVec[16]", !176, !177, !178}
!195 = !{!"inlineSamplersMD"}
!196 = !{!"maxByteOffsets"}
!197 = !{!"IsInitializer", i1 false}
!198 = !{!"IsFinalizer", i1 false}
!199 = !{!"CompiledSubGroupsNumber", i32 0}
!200 = !{!"hasInlineVmeSamplers", i1 false}
!201 = !{!"localSize", i32 0}
!202 = !{!"localIDPresent", i1 false}
!203 = !{!"groupIDPresent", i1 false}
!204 = !{!"privateMemoryPerWI", i32 0}
!205 = !{!"prevFPOffset", i32 0}
!206 = !{!"globalIDPresent", i1 false}
!207 = !{!"hasSyncRTCalls", i1 false}
!208 = !{!"hasPrintfCalls", i1 false}
!209 = !{!"requireAssertBuffer", i1 false}
!210 = !{!"requireSyncBuffer", i1 false}
!211 = !{!"hasIndirectCalls", i1 false}
!212 = !{!"hasNonKernelArgLoad", i1 false}
!213 = !{!"hasNonKernelArgStore", i1 false}
!214 = !{!"hasNonKernelArgAtomic", i1 false}
!215 = !{!"UserAnnotations"}
!216 = !{!"m_OpenCLArgAddressSpaces", !217, !218, !219, !220}
!217 = !{!"m_OpenCLArgAddressSpacesVec[0]", i32 0}
!218 = !{!"m_OpenCLArgAddressSpacesVec[1]", i32 1}
!219 = !{!"m_OpenCLArgAddressSpacesVec[2]", i32 1}
!220 = !{!"m_OpenCLArgAddressSpacesVec[3]", i32 1}
!221 = !{!"m_OpenCLArgAccessQualifiers", !222, !223, !224, !225}
!222 = !{!"m_OpenCLArgAccessQualifiersVec[0]", !"none"}
!223 = !{!"m_OpenCLArgAccessQualifiersVec[1]", !"none"}
!224 = !{!"m_OpenCLArgAccessQualifiersVec[2]", !"none"}
!225 = !{!"m_OpenCLArgAccessQualifiersVec[3]", !"none"}
!226 = !{!"m_OpenCLArgTypes", !227, !228, !229, !230}
!227 = !{!"m_OpenCLArgTypesVec[0]", !"int"}
!228 = !{!"m_OpenCLArgTypesVec[1]", !"char*"}
!229 = !{!"m_OpenCLArgTypesVec[2]", !"short*"}
!230 = !{!"m_OpenCLArgTypesVec[3]", !"short*"}
!231 = !{!"m_OpenCLArgBaseTypes", !232, !233, !234, !235}
!232 = !{!"m_OpenCLArgBaseTypesVec[0]", !"int"}
!233 = !{!"m_OpenCLArgBaseTypesVec[1]", !"char*"}
!234 = !{!"m_OpenCLArgBaseTypesVec[2]", !"short*"}
!235 = !{!"m_OpenCLArgBaseTypesVec[3]", !"short*"}
!236 = !{!"m_OpenCLArgTypeQualifiers", !237, !238, !239, !240}
!237 = !{!"m_OpenCLArgTypeQualifiersVec[0]", !""}
!238 = !{!"m_OpenCLArgTypeQualifiersVec[1]", !""}
!239 = !{!"m_OpenCLArgTypeQualifiersVec[2]", !""}
!240 = !{!"m_OpenCLArgTypeQualifiersVec[3]", !""}
!241 = !{!"m_OpenCLArgNames", !242, !243, !244, !245}
!242 = !{!"m_OpenCLArgNamesVec[0]", !""}
!243 = !{!"m_OpenCLArgNamesVec[1]", !""}
!244 = !{!"m_OpenCLArgNamesVec[2]", !""}
!245 = !{!"m_OpenCLArgNamesVec[3]", !""}
!246 = !{!"m_OpenCLArgScalarAsPointers"}
!247 = !{!"m_OptsToDisablePerFunc", !248, !249, !250}
!248 = !{!"m_OptsToDisablePerFuncSet[0]", !"IGC-AddressArithmeticSinking"}
!249 = !{!"m_OptsToDisablePerFuncSet[1]", !"IGC-AllowSimd32Slicing"}
!250 = !{!"m_OptsToDisablePerFuncSet[2]", !"IGC-SinkLoadOpt"}
!251 = !{!"FuncMDMap[1]", ptr @_ZTSZZNK3p694HeadILj128EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_}
!252 = !{!"FuncMDValue[1]", !140, !141, !145, !146, !147, !170, !196, !197, !198, !199, !200, !201, !202, !203, !204, !205, !206, !207, !208, !209, !210, !211, !212, !213, !214, !215, !216, !221, !226, !231, !236, !241, !246, !247}
!253 = !{!"pushInfo", !254, !255, !256, !260, !261, !262, !263, !264, !265, !266, !267, !280, !281, !282, !283}
!254 = !{!"pushableAddresses"}
!255 = !{!"bindlessPushInfo"}
!256 = !{!"dynamicBufferInfo", !257, !258, !259}
!257 = !{!"firstIndex", i32 0}
!258 = !{!"numOffsets", i32 0}
!259 = !{!"forceDisabled", i1 false}
!260 = !{!"MaxNumberOfPushedBuffers", i32 0}
!261 = !{!"inlineConstantBufferSlot", i32 -1}
!262 = !{!"inlineConstantBufferOffset", i32 -1}
!263 = !{!"inlineConstantBufferGRFOffset", i32 -1}
!264 = !{!"constants"}
!265 = !{!"inputs"}
!266 = !{!"constantReg"}
!267 = !{!"simplePushInfoArr", !268, !277, !278, !279}
!268 = !{!"simplePushInfoArrVec[0]", !269, !270, !271, !272, !273, !274, !275, !276}
!269 = !{!"cbIdx", i32 0}
!270 = !{!"pushableAddressGrfOffset", i32 -1}
!271 = !{!"pushableOffsetGrfOffset", i32 -1}
!272 = !{!"offset", i32 0}
!273 = !{!"size", i32 0}
!274 = !{!"isStateless", i1 false}
!275 = !{!"isBindless", i1 false}
!276 = !{!"simplePushLoads"}
!277 = !{!"simplePushInfoArrVec[1]", !269, !270, !271, !272, !273, !274, !275, !276}
!278 = !{!"simplePushInfoArrVec[2]", !269, !270, !271, !272, !273, !274, !275, !276}
!279 = !{!"simplePushInfoArrVec[3]", !269, !270, !271, !272, !273, !274, !275, !276}
!280 = !{!"simplePushBufferUsed", i32 0}
!281 = !{!"pushAnalysisWIInfos"}
!282 = !{!"inlineRTGlobalPtrOffset", i32 0}
!283 = !{!"rtSyncSurfPtrOffset", i32 0}
!284 = !{!"psInfo", !285, !286, !287, !288, !289, !290, !291, !292, !293, !294, !295, !296, !297, !298, !299, !300, !301}
!285 = !{!"BlendStateDisabledMask", i8 0}
!286 = !{!"SkipSrc0Alpha", i1 false}
!287 = !{!"DualSourceBlendingDisabled", i1 false}
!288 = !{!"ForceEnableSimd32", i1 false}
!289 = !{!"DisableSimd32WithDiscard", i1 false}
!290 = !{!"outputDepth", i1 false}
!291 = !{!"outputStencil", i1 false}
!292 = !{!"outputMask", i1 false}
!293 = !{!"blendToFillEnabled", i1 false}
!294 = !{!"forceEarlyZ", i1 false}
!295 = !{!"hasVersionedLoop", i1 false}
!296 = !{!"forceSingleSourceRTWAfterDualSourceRTW", i1 false}
!297 = !{!"NumSamples", i8 0}
!298 = !{!"blendOptimizationMode"}
!299 = !{!"colorOutputMask"}
!300 = !{!"isBlendEnabled"}
!301 = !{!"WaDisableVRS", i1 false}
!302 = !{!"csInfo", !303, !304, !305, !306, !68, !44, !45, !307, !46, !308, !309, !310, !311, !312, !313, !314, !315, !316, !317, !318, !79, !319, !320, !321, !322}
!303 = !{!"maxWorkGroupSize", i32 0}
!304 = !{!"waveSize", i32 0}
!305 = !{!"ComputeShaderSecondCompile"}
!306 = !{!"forcedSIMDSize", i8 0}
!307 = !{!"VISAPreSchedScheduleExtraGRF", i32 0}
!308 = !{!"forceSpillCompression", i1 false}
!309 = !{!"allowLowerSimd", i1 false}
!310 = !{!"disableSimd32Slicing", i1 false}
!311 = !{!"disableSplitOnSpill", i1 false}
!312 = !{!"enableNewSpillCostFunction", i1 false}
!313 = !{!"forceVISAPreSched", i1 false}
!314 = !{!"disableLocalIdOrderOptimizations", i1 false}
!315 = !{!"disableDispatchAlongY", i1 false}
!316 = !{!"neededThreadIdLayout", ptr null}
!317 = !{!"forceTileYWalk", i1 false}
!318 = !{!"atomicBranch", i32 0}
!319 = !{!"disableEarlyOut", i1 false}
!320 = !{!"walkOrderEnabled", i1 false}
!321 = !{!"walkOrderOverride", i32 0}
!322 = !{!"ResForHfPacking"}
!323 = !{!"msInfo", !324, !325, !326, !327, !328, !329, !330, !331, !332}
!324 = !{!"PrimitiveTopology", i32 3}
!325 = !{!"MaxNumOfPrimitives", i32 0}
!326 = !{!"MaxNumOfVertices", i32 0}
!327 = !{!"MaxNumOfPerPrimitiveOutputs", i32 0}
!328 = !{!"MaxNumOfPerVertexOutputs", i32 0}
!329 = !{!"WorkGroupSize", i32 0}
!330 = !{!"WorkGroupMemorySizeInBytes", i32 0}
!331 = !{!"IndexFormat", i32 6}
!332 = !{!"SubgroupSize", i32 0}
!333 = !{!"taskInfo", !334, !329, !330, !332}
!334 = !{!"MaxNumOfOutputs", i32 0}
!335 = !{!"NBarrierCnt", i32 0}
!336 = !{!"rtInfo", !337, !338, !339, !340, !341, !342, !343, !344, !345, !346, !347, !348, !349, !350, !166}
!337 = !{!"RayQueryAllocSizeInBytes", i32 0}
!338 = !{!"NumContinuations", i32 0}
!339 = !{!"RTAsyncStackAddrspace", i32 -1}
!340 = !{!"RTAsyncStackSurfaceStateOffset", ptr null}
!341 = !{!"SWHotZoneAddrspace", i32 -1}
!342 = !{!"SWHotZoneSurfaceStateOffset", ptr null}
!343 = !{!"SWStackAddrspace", i32 -1}
!344 = !{!"SWStackSurfaceStateOffset", ptr null}
!345 = !{!"RTSyncStackAddrspace", i32 -1}
!346 = !{!"RTSyncStackSurfaceStateOffset", ptr null}
!347 = !{!"doSyncDispatchRays", i1 false}
!348 = !{!"MemStyle", !"Xe"}
!349 = !{!"GlobalDataStyle", !"Xe"}
!350 = !{!"uberTileDimensions", ptr null}
!351 = !{!"CurUniqueIndirectIdx", i32 0}
!352 = !{!"inlineDynTextures"}
!353 = !{!"inlineResInfoData"}
!354 = !{!"immConstant", !355, !356, !357}
!355 = !{!"data"}
!356 = !{!"sizes"}
!357 = !{!"zeroIdxs"}
!358 = !{!"stringConstants"}
!359 = !{!"inlineBuffers", !360, !364, !365}
!360 = !{!"inlineBuffersVec[0]", !361, !362, !363}
!361 = !{!"alignment", i32 0}
!362 = !{!"allocSize", i64 0}
!363 = !{!"Buffer"}
!364 = !{!"inlineBuffersVec[1]", !361, !362, !363}
!365 = !{!"inlineBuffersVec[2]", !361, !362, !363}
!366 = !{!"GlobalPointerProgramBinaryInfos"}
!367 = !{!"ConstantPointerProgramBinaryInfos"}
!368 = !{!"GlobalBufferAddressRelocInfo"}
!369 = !{!"ConstantBufferAddressRelocInfo"}
!370 = !{!"forceLscCacheList"}
!371 = !{!"SrvMap"}
!372 = !{!"RasterizerOrderedByteAddressBuffer"}
!373 = !{!"RasterizerOrderedViews"}
!374 = !{!"MinNOSPushConstantSize", i32 0}
!375 = !{!"inlineProgramScopeOffsets"}
!376 = !{!"shaderData", !377}
!377 = !{!"numReplicas", i32 0}
!378 = !{!"URBInfo", !379, !380, !381}
!379 = !{!"has64BVertexHeaderInput", i1 false}
!380 = !{!"has64BVertexHeaderOutput", i1 false}
!381 = !{!"hasVertexHeader", i1 true}
!382 = !{!"UseBindlessImage", i1 true}
!383 = !{!"HasBindlessImageRead", i1 false}
!384 = !{!"enableRangeReduce", i1 false}
!385 = !{!"allowMatchMadOptimizationforVS", i1 false}
!386 = !{!"disableMatchMadOptimizationForCS", i1 false}
!387 = !{!"disableMemOptforNegativeOffsetLoads", i1 false}
!388 = !{!"enableThreeWayLoadSpiltOpt", i1 false}
!389 = !{!"statefulResourcesNotAliased", i1 false}
!390 = !{!"disableMixMode", i1 false}
!391 = !{!"genericAccessesResolved", i1 false}
!392 = !{!"disableSeparateSpillPvtScratchSpace", i1 false}
!393 = !{!"enableSeparateSpillPvtScratchSpace", i1 false}
!394 = !{!"disableSeparateScratchWA", i1 false}
!395 = !{!"enableRemoveUnusedTGMFence", i1 false}
!396 = !{!"PrivateMemoryPerFG", !397, !398, !399, !400}
!397 = !{!"PrivateMemoryPerFGMap[0]", ptr @_ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_}
!398 = !{!"PrivateMemoryPerFGValue[0]", i32 0}
!399 = !{!"PrivateMemoryPerFGMap[1]", ptr @_ZTSZZNK3p694HeadILj128EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_}
!400 = !{!"PrivateMemoryPerFGValue[1]", i32 0}
!401 = !{!"m_OptsToDisable"}
!402 = !{!"capabilities", !403}
!403 = !{!"globalVariableDecorationsINTEL", i1 false}
!404 = !{!"extensions", !405}
!405 = !{!"spvINTELBindlessImages", i1 false}
!406 = !{!"m_ShaderResourceViewMcsMask", !407, !408}
!407 = !{!"m_ShaderResourceViewMcsMaskVec[0]", i64 0}
!408 = !{!"m_ShaderResourceViewMcsMaskVec[1]", i64 0}
!409 = !{!"computedDepthMode", i32 0}
!410 = !{!"isHDCFastClearShader", i1 false}
!411 = !{!"argRegisterReservations", !412}
!412 = !{!"argRegisterReservationsVec[0]", i32 0}
!413 = !{!"SIMD16_SpillThreshold", i8 0}
!414 = !{!"SIMD32_SpillThreshold", i8 0}
!415 = !{!"m_CacheControlOption", !416, !417, !418, !419}
!416 = !{!"LscLoadCacheControlOverride", i8 0}
!417 = !{!"LscStoreCacheControlOverride", i8 0}
!418 = !{!"TgmLoadCacheControlOverride", i8 0}
!419 = !{!"TgmStoreCacheControlOverride", i8 0}
!420 = !{!"ModuleUsesBindless", i1 false}
!421 = !{!"predicationMap"}
!422 = !{!"lifeTimeStartMap"}
!423 = !{!"HitGroups"}
!424 = !{i32 2, i32 0}
!425 = !{!"clang version 16.0.6"}
!426 = !{i32 1, !"wchar_size", i32 4}
!427 = !{!"320"}
!428 = !{!"-5"}
!429 = !{!"160"}
!430 = !{!431}
!431 = !{i32 4470}
!432 = !{!"5120"}
!433 = !{!434, !431}
!434 = !{i32 4469}
!435 = !{!"4960"}
!436 = !{!"80"}
