//.kernel _ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 4276938853 1484896288 -hashmovs1 0 1 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 4276938853 1484896288 -hashmovs1 0 1 -GRFBumpUpNumber 2 "
//.instCount 263
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r94.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.8)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.3)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.4)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.5)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r94.0)
//.declare V0034 (44)  rf=r size=4 type=d align=2 words (r3.2)
//.declare V0035 (45)  rf=r size=8 type=uq align=4 words (r2.2)
//.declare V0036 (46)  rf=r size=8 type=uq align=4 words (r2.3)
//.declare V0037 (47)  rf=r size=8 type=uq align=4 words (r3.0)
//.declare V0039 (49)  rf=r size=32 type=d alias=+0 align=32 words (r94.0)
//.declare V0041 (51)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0042 (52)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0052 (62)  rf=r size=64 type=w align=32 words (r95.0)
//.declare V0053 (63)  rf=r size=128 type=d align=32 words (r96.0)
//.declare V0054 (64)  rf=r size=64 type=uw alias=V0052+0 align=32 words (r95.0)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0056 (66)  rf=r size=12 type=ud alias=V0041+0 align=2 words (r2.0)
//.declare V0057 (67)  rf=r size=32 type=ud alias=V0039+0 align=16 words (r94.0)
//.declare V0058 (68)  rf=r size=8 type=ud alias=V0055+0 align=4 words (r5.0)
//.declare V0059 (69)  rf=r size=8 type=d alias=V0055+0 align=4 words (r5.0)
//.declare V0060 (70)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0063 (73)  rf=r size=64 type=uw alias=V0042+0 align=32 words (r1.0)
//.declare V0068 (78)  rf=r size=128 type=d align=32 words (r15.0)
//.declare P01 (79)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0069 (80)  rf=r size=128 type=ud alias=V0068+0 align=32 words (r15.0)
//.declare V0070 (81)  rf=r size=4 type=ud alias=V0034+0 align=2 words (r3.2)
//.declare P02 (82)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0071 (83)  rf=r size=128 type=f align=32 words (r98.0)
//.declare V0074 (86)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0075 (87)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0077 (89)  rf=r size=128 type=ud alias=V0074+0 align=32 words (r4.0)
//.declare V0080 (92)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0081 (93)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0082 (94)  rf=r size=8 type=q alias=V0035+0 align=4 words (r2.2)
//.declare V0084 (96)  rf=r size=128 type=d align=32 words (r100.0)
//.declare V0086 (98)  rf=r size=8 type=q alias=V0036+0 align=4 words (r2.3)
//.declare V0087 (99)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0088 (100)  rf=r size=128 type=ud alias=V0084+0 align=32 words (r100.0)
//.declare V0089 (101)  rf=r size=128 type=ud alias=V0087+0 align=32 words (r8.0)
//.declare V0090 (102)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0092 (104)  rf=r size=128 type=ud alias=V0090+0 align=32 words (r18.0)
//.declare V0093 (105)  rf=r size=256 type=q align=32 words (r32.0)
//.declare V0094 (106)  rf=r size=256 type=uq alias=V0093+0 align=32 words (r32.0)
//.declare V0095 (107)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0097 (109)  rf=r size=256 type=q align=32 words (r10.0)
//.declare V0098 (110)  rf=r size=256 type=uq alias=V0097+0 align=32 words (r10.0)
//.declare V0099 (111)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0100 (112)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0102 (114)  rf=r size=256 type=q align=32 words (r22.0)
//.declare V0103 (115)  rf=r size=256 type=uq alias=V0102+0 align=32 words (r22.0)
//.declare V0104 (116)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0106 (118)  rf=r size=128 type=b alias=V0099+0 align=32 words (r20.0)
//.declare V0107 (119)  rf=r size=32 type=b align=32 words (r46.0)
//.declare V0108 (120)  rf=r size=32 type=b align=32 words (r49.0)
//.declare V0109 (121)  rf=r size=32 type=b align=32 words (r54.0)
//.declare V0110 (122)  rf=r size=32 type=b align=32 words (r65.0)
//.declare V0112 (124)  rf=r size=128 type=b alias=V0100+0 align=32 words (r30.0)
//.declare V0113 (125)  rf=r size=32 type=b align=32 words (r78.0)
//.declare V0114 (126)  rf=r size=32 type=b align=32 words (r91.0)
//.declare V0115 (127)  rf=r size=32 type=b align=32 words (r16.0)
//.declare V0116 (128)  rf=r size=32 type=b align=32 words (r34.0)
//.declare V0118 (130)  rf=r size=128 type=w alias=V0104+0 align=32 words (r36.0)
//.declare V0121 (133)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0122 (134)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0123 (135)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0125 (137)  rf=r size=128 type=w alias=V0121+0 align=32 words (r38.0)
//.declare V0129 (141)  rf=r size=128 type=w alias=V0122+0 align=32 words (r42.0)
//.declare V0133 (145)  rf=r size=128 type=w alias=V0123+0 align=32 words (r44.0)
//.declare V0136 (148)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0137 (149)  rf=r size=128 type=ub alias=V0099+0 align=32 words (r20.0)
//.declare V0138 (150)  rf=r size=128 type=ud alias=V0136+0 align=32 words (r47.0)
//.declare V0139 (151)  rf=r size=128 type=d align=32 words (r50.0)
//.declare P03 (153)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0141 (154)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0142 (155)  rf=r size=128 type=f align=32 words (r61.0)
//.declare V0144 (157)  rf=r size=128 type=d align=32 words (r63.0)
//.declare V0146 (159)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0148 (161)  rf=r size=128 type=f alias=V0146+0 align=32 words (r72.0)
//.declare V0149 (162)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0150 (163)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0151 (164)  rf=r size=128 type=ud alias=V0150+0 align=32 words (r52.0)
//.declare V0152 (165)  rf=r size=128 type=d align=32 words (r57.0)
//.declare P04 (167)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0154 (168)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0155 (169)  rf=r size=128 type=f align=32 words (r74.0)
//.declare V0157 (171)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0159 (173)  rf=r size=128 type=d align=32 words (r85.0)
//.declare V0161 (175)  rf=r size=128 type=f alias=V0159+0 align=32 words (r85.0)
//.declare V0162 (176)  rf=r size=128 type=f align=32 words (r23.0)
//.declare V0163 (177)  rf=r size=128 type=d align=32 words (r59.0)
//.declare V0164 (178)  rf=r size=128 type=ud alias=V0163+0 align=32 words (r59.0)
//.declare V0165 (179)  rf=r size=128 type=d align=32 words (r68.0)
//.declare P05 (181)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0167 (182)  rf=r size=128 type=d align=32 words (r79.0)
//.declare V0168 (183)  rf=r size=128 type=f align=32 words (r87.0)
//.declare V0170 (185)  rf=r size=128 type=d align=32 words (r89.0)
//.declare V0172 (187)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0174 (189)  rf=r size=128 type=f alias=V0172+0 align=32 words (r10.0)
//.declare V0175 (190)  rf=r size=128 type=f align=32 words (r48.0)
//.declare V0176 (191)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0177 (192)  rf=r size=128 type=ud alias=V0176+0 align=32 words (r70.0)
//.declare V0178 (193)  rf=r size=128 type=d align=32 words (r81.0)
//.declare P06 (195)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0180 (196)  rf=r size=128 type=d align=32 words (r92.0)
//.declare V0181 (197)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0183 (199)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0185 (201)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0187 (203)  rf=r size=128 type=f alias=V0185+0 align=32 words (r25.0)
//.declare V0188 (204)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0189 (205)  rf=r size=128 type=d align=32 words (r83.0)
//.declare V0190 (206)  rf=r size=128 type=ub alias=V0100+0 align=32 words (r30.0)
//.declare V0191 (207)  rf=r size=128 type=ud alias=V0189+0 align=32 words (r83.0)
//.declare V0192 (208)  rf=r size=128 type=d align=32 words (r4.0)
//.declare P07 (210)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0194 (211)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0195 (212)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0197 (214)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0199 (216)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0201 (218)  rf=r size=128 type=f alias=V0199+0 align=32 words (r50.0)
//.declare V0202 (219)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0203 (220)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0204 (221)  rf=r size=128 type=ud alias=V0203+0 align=32 words (r6.0)
//.declare V0205 (222)  rf=r size=128 type=d align=32 words (r19.0)
//.declare P08 (224)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0207 (225)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0208 (226)  rf=r size=128 type=f align=32 words (r52.0)
//.declare V0210 (228)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0212 (230)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0214 (232)  rf=r size=128 type=f alias=V0212+0 align=32 words (r62.0)
//.declare V0215 (233)  rf=r size=128 type=f align=32 words (r78.0)
//.declare V0216 (234)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0217 (235)  rf=r size=128 type=ud alias=V0216+0 align=32 words (r21.0)
//.declare V0218 (236)  rf=r size=128 type=d align=32 words (r37.0)
//.declare P09 (238)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0220 (239)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0221 (240)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0223 (242)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0225 (244)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0227 (246)  rf=r size=128 type=f alias=V0225+0 align=32 words (r72.0)
//.declare V0229 (248)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0230 (249)  rf=r size=128 type=ud alias=V0229+0 align=32 words (r46.0)
//.declare V0231 (250)  rf=r size=128 type=d align=32 words (r58.0)
//.declare P10 (252)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0233 (253)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0234 (254)  rf=r size=128 type=f align=32 words (r74.0)
//.declare V0236 (256)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0238 (258)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0240 (260)  rf=r size=128 type=f alias=V0238+0 align=32 words (r80.0)
//.declare P11 (261)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0241 (262)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0242 (263)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0243 (264)  rf=r size=128 type=f align=32 words (r9.0)
//.declare V0244 (265)  rf=r size=128 type=uw alias=V0242+0 align=32 words (r6.0)
//.declare V0245 (266)  rf=r size=64 type=uw align=32 words (r8.0)
//.declare A00 (267)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P12 (268)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0248 (271)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0249 (272)  rf=r size=128 type=d align=32 words (r11.0)
//.declare V0250 (273)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0251 (274)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0252 (275)  rf=r size=128 type=uw alias=V0250+0 align=32 words (r13.0)
//.declare V0253 (276)  rf=r size=64 type=uw align=32 words (r15.0)
//.declare A01 (277)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P13 (278)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0256 (281)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0257 (282)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0258 (283)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0259 (284)  rf=r size=128 type=f align=32 words (r23.0)
//.declare V0260 (285)  rf=r size=128 type=uw alias=V0258+0 align=32 words (r20.0)
//.declare V0261 (286)  rf=r size=64 type=uw align=32 words (r22.0)
//.declare A02 (287)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P14 (288)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0264 (291)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0265 (292)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0266 (293)  rf=r size=128 type=d align=32 words (r27.0)
//.declare V0267 (294)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0268 (295)  rf=r size=128 type=uw alias=V0266+0 align=32 words (r27.0)
//.declare V0269 (296)  rf=r size=64 type=uw align=32 words (r29.0)
//.declare A03 (297)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P15 (298)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0272 (301)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0273 (302)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0274 (303)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0275 (304)  rf=r size=128 type=f align=32 words (r110.0)
//.declare V0276 (305)  rf=r size=128 type=uw alias=V0274+0 align=32 words (r34.0)
//.declare V0277 (306)  rf=r size=64 type=uw align=32 words (r36.0)
//.declare A04 (307)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P16 (308)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P17 (309)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0279 (311)  rf=r size=128 type=f align=32 words (r113.0)
//.declare V0280 (312)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0281 (313)  rf=r size=128 type=d alias=V0279+0 align=32 words (r113.0)
//.declare P18 (314)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0282 (315)  rf=r size=128 type=ud alias=V0280+0 align=32 words (r4.0)
//.declare V0283 (316)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0284 (317)  rf=r size=128 type=ud alias=V0279+0 align=32 words (r113.0)
//.declare V0285 (318)  rf=r size=128 type=ud alias=V0283+0 align=32 words (r4.0)
//.declare V0286 (319)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0287 (320)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0288 (321)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0289 (322)  rf=r size=128 type=ud alias=V0287+0 align=32 words (r8.0)
//.declare V0290 (323)  rf=r size=128 type=ud alias=V0288+0 align=32 words (r10.0)
//.declare V0291 (324)  rf=r size=64 type=w align=32 words (r112.0)
//.declare V0292 (325)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0293 (326)  rf=r size=128 type=ud alias=V0292+0 align=32 words (r4.0)
//.declare V0295 (328)  rf=r size=8 type=q alias=V0037+0 align=4 words (r3.0)
//.declare V0297 (330)  rf=r size=256 type=q align=32 words (r8.0)
//.declare V0298 (331)  rf=r size=256 type=uq alias=V0297+0 align=32 words (r8.0)
//.declare V0299 (332)  rf=r size=64 type=uw alias=V0291+0 align=32 words (r112.0)
//.declare V0300 (333)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (334)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (335)  rf=r size=128 type=w alias=V0292+0 align=32 words (r4.0)
//.declare  (336)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare  (337)  rf=r size=64 type=uw align=32 words (r39.0)
//.declare  (340)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (341)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (342)  rf=r size=128 type=uw align=32 words (r11.0)
//.declare  (343)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (344)  rf=r size=128 type=ud align=32 words (r28.0)
//.declare  (345)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (346)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (349)  rf=r size=2 type=uw align=1 words (r37.0)
//.declare  (351)  rf=r size=128 type=w alias=V0288+0 align=32 words (r10.0)
//.declare  (354)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (355)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (356)  rf=r size=128 type=q align=32 words (r115.0)
//.declare  (357)  rf=r size=128 type=q align=32 words (r117.0)
//.declare  (360)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (361)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (362)  rf=r size=128 type=q align=32 words (r119.0)
//.declare  (363)  rf=r size=128 type=q align=32 words (r121.0)
//.declare  (364)  rf=r size=128 type=q align=32 words (r123.0)
//.declare  (365)  rf=r size=128 type=q align=32 words (r125.0)
//.declare  (370)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (371)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (372)  rf=r size=128 type=q align=32 words (r4.0)
//.declare  (373)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (374)  rf=r size=128 type=uq alias=+0 align=32 words (r115.0)
//.declare  (375)  rf=r size=128 type=uq alias=+0 align=32 words (r9.0)
//.declare  (376)  rf=r size=128 type=uq alias=+0 align=32 words (r117.0)
//.declare  (377)  rf=r size=128 type=uq alias=+0 align=32 words (r13.0)
//.declare  (378)  rf=r size=128 type=d alias=+0 align=32 words (r115.0)
//.declare  (379)  rf=r size=128 type=d alias=+0 align=32 words (r117.0)
//.declare  (380)  rf=r size=128 type=ud alias=+0 align=32 words (r8.0)
//.declare  (381)  rf=r size=128 type=ud alias=+0 align=32 words (r10.0)
//.declare  (382)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (383)  rf=r size=128 type=d alias=+0 align=32 words (r10.0)
//.declare r0 (384)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (385)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (386)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (387)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (388)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (389)  rf=r size=32 type=ud align=2 words (r3.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0042    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0041    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0035    | :uq      |    0x8 | r2+0x10  | inline+0x10      |
// | V0036    | :uq      |    0x8 | r2+0x18  | inline+0x18      |
// | V0037    | :uq      |    0x8 | r3       | cti+0x20         |
// | V0034    | :d       |    0x4 | r3+0x8   | cti+0x28         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x20:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r3:1  bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B004}
// _main:
(W)     mov (16|M0)              r94.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r94.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $6
(W)     macl (1|M0)              r4.0<1>:ud    r2.0<0;1,0>:ud    r94.1<0;1,0>:ud  {Compacted}        //  ALU pipe: int; $7
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r94.2<0;1,0>:uw                     //  ALU pipe: int; $7
(W)     mach (1|M0)              r6.0<1>:d     r2.0<0;1,0>:ud    r94.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $13
        mov (16|M16)             r11.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $13
(W)     mov (1|M0)               r5.0<2>:f     r4.0<0;1,0>:f                    {I@5}                //  ALU pipe: float; $7
(W)     mov (1|M0)               r5.1<2>:d     r6.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $11
(W)     mov (8|M0)               r95.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $2
        add (16|M0)              r9.0<1>:q     r5.0<0;1,0>:q     r7.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $13
        add (16|M16)             r13.0<1>:q    r5.0<0;1,0>:q     r11.0<4;1,0>:uw                     //  ALU pipe: int; $13
        shr (16|M0)              r115.0<1>:uq  r9.0<1;1,0>:uq    5:w               {I@2}             //  ALU pipe: int; $14
        shr (16|M16)             r117.0<1>:uq  r13.0<1;1,0>:uq   5:w               {I@2}             //  ALU pipe: int; $14
        mov (16|M0)              r15.0<1>:d    r115.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $15
        mov (16|M16)             r16.0<1>:d    r117.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $15
(W)     add (8|M0)               r95.8<1>:w    r95.0<1;1,0>:w    8:w                                 //  ALU pipe: int; $3
        cmp (32|M0)   (ge)f0.0   null<1>:ud    r15.0<1;1,0>:ud   r3.2<0;1,0>:ud   {@2,$1.dst}        //  ALU pipe: int; $17
(W)     add (16|M0)              r95.16<1>:w   r95.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $4
        cmp (32|M0)   (ge)f2.0   null<1>:ud    r15.0<1;1,0>:ud   r3.2<0;1,0>:ud                      //  ALU pipe: int; $16
        mov (32|M0)              r96.0<1>:d    r95.0<1;1,0>:uw                  {I@2}                //  ALU pipe: int; $5
(~f0.0) goto (32|M0)                         _0_013            _0_013                                //  ALU pipe: int; $18
// B003: [inDivergent],  Preds:{B002},  Succs:{B007}
_0_014:
        mov (32|M0)              r98.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $20
        goto (32|M0)                         _0_013            _0_015                                // $21
// B004: [inDivergent],  Preds:{B002},  Succs:{B005}
_0_013:
        join (32|M0)                         _0_015                                                  // 
L568:
        mov (16|M0)              r4.0<1>:d     r115.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $23
        mov (16|M16)             r5.0<1>:d     r117.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $24
(W)     mul (16|M0)              acc0.0<1>:ud  r4.0<1;1,0>:ud    0xC80:uw              {I@2}         //  ALU pipe: int; $29
        mov (16|M0)              r6.0<1>:d     r115.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $25
        mov (16|M16)             r7.0<1>:d     r117.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $26
        mach (16|M0)             r12.0<1>:d    r4.0<1;1,0>:ud    0xC80:ud                            //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r5.0<1;1,0>:ud    0xC80:uw              {I@5}         //  ALU pipe: int; $29
        mach (16|M16)            r13.0<1>:d    r5.0<1;1,0>:ud    0xC80:ud                            //  ALU pipe: int; $31
        mul (32|M0)              r14.0<1>:d    r6.0<1;1,0>:d     0xC80:uw              {I@4}         //  ALU pipe: int; $32
        mul (16|M0)              r8.0<2>:ud    r4.0<1;1,0>:ud    0xC80:uw                            //  ALU pipe: int; $27
        mul (16|M16)             r10.0<2>:ud   r5.0<1;1,0>:ud    0xC80:uw                            //  ALU pipe: int; $28
        add (16|M0)              r8.1<2>:d     r12.0<1;1,0>:d    r14.0<1;1,0>:d   {I@3}              //  ALU pipe: int; $33
        add (16|M16)             r10.1<2>:d    r13.0<1;1,0>:d    r15.0<1;1,0>:d                      //  ALU pipe: int; $34
        shl (32|M0)              r100.0<1>:d   r96.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $36
        mov (32|M0)              r98.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $38
        add (16|M0)              r119.0<1>:q   r8.0<1;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $35
        add (16|M16)             r121.0<1>:q   r10.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $35
        add (16|M0)              r123.0<1>:q   r119.0<1;1,0>:q   2560:w               {I@2}          //  ALU pipe: int; $37
        add (16|M16)             r125.0<1>:q   r121.0<1;1,0>:q   2560:w               {I@2}          //  ALU pipe: int; $37
// B005: [inDivergent],  Preds:{B006, B004},  Succs:{B006, B007}
_0_016:
        mov (16|M0)              r4.0<2>:ud    r100.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $46
        mov (16|M16)             r6.0<2>:ud    r101.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $46
        add (16|M0)              r10.0<1>:q    r119.0<1;1,0>:q   r4.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $46
        add (16|M16)             r12.0<1>:q    r121.0<1;1,0>:q   r6.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $46
        load.ugm.d32.a64 (32|M0)  r20:2         [r10:4]            {I@1,$2} // ex_desc:0x0; desc:0x8200580 // $47
        shr (32|M0)              r8.0<1>:ud    r100.0<1;1,0>:ud  2:w                                 //  ALU pipe: int; $40
        shl (16|M0)              r14.0<1>:q    r4.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $49
        shl (16|M16)             r16.0<1>:q    r6.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $49
        and (32|M0)              r18.0<1>:d    r8.0<1;1,0>:d     1020:w               {Compacted,I@3} //  ALU pipe: int; $41
        add (16|M0)              r22.0<1>:q    r14.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $50
        add (16|M16)             r24.0<1>:q    r16.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $50
        mov (16|M0)              r26.0<2>:ud   r18.0<1;1,0>:ud                  {Compacted,I@3}      //  ALU pipe: int; $43
        mov (16|M16)             r28.0<2>:ud   r19.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $43
        load.ugm.d32.a64 (32|M0)  r36:2         [r22:4]            {I@3,$3} // ex_desc:0x0; desc:0x8200580 // $51
        add (16|M0)              r32.0<1>:q    r123.0<1;1,0>:q   r26.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $43
        add (16|M16)             r34.0<1>:q    r125.0<1;1,0>:q   r28.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $43
        load.ugm.d32.a64 (32|M0)  r40:2         [r32:4]            {I@1,$4} // ex_desc:0x0; desc:0x8200580 // $44
        load.ugm.d32.a64 (32|M0)  r30:2         [r10:4+0x4]        {$5} // ex_desc:0x4000; desc:0x8200580 // $48
        load.ugm.d32.a64 (32|M0)  r38:2         [r22:4+0x4]        {$6} // ex_desc:0x4000; desc:0x8200580 // $62
        load.ugm.d32.a64 (32|M0)  r42:2         [r22:4+0x8]        {$7} // ex_desc:0x8000; desc:0x8200580 // $63
        load.ugm.d32.a64 (32|M0)  r44:2         [r22:4+0xC]        {$8} // ex_desc:0xC000; desc:0x8200580 // $64
        mov (32|M0)              r46.0<1>:b    r20.0<4;1,0>:b                   {$2.dst}             //  ALU pipe: int; $52
        mov (32|M0)              r47.0<1>:ud   r20.0<4;1,0>:ub                                       //  ALU pipe: int; $71
        mov (32|M0)   (lt)f1.0   null<2>:w     r46.0<1;1,0>:b                   {I@2}                //  ALU pipe: int; $73
        mov (32|M0)              r49.0<1>:b    r20.1<4;1,0>:b                                        //  ALU pipe: int; $53
        or (32|M0)               r50.0<1>:d    r47.0<1;1,0>:d    -256:w               {Compacted,I@3} //  ALU pipe: int; $72
        mov (32|M0)              r52.0<1>:ud   r20.1<4;1,0>:ub                                       //  ALU pipe: int; $82
        mov (32|M0)   (lt)f3.0   null<2>:w     r49.0<1;1,0>:b                   {I@3}                //  ALU pipe: int; $84
(f1.0)  sel (32|M0)              r55.0<1>:d    r50.0<1;1,0>:d    r47.0<1;1,0>:d   {I@3}              //  ALU pipe: int; $75
        mov (32|M0)              r54.0<1>:b    r20.2<4;1,0>:b                                        //  ALU pipe: int; $54
        mov (32|M0)              r63.0<1>:d    r36.0<2;1,0>:uw                  {$3.dst}             //  ALU pipe: int; $78
        or (32|M0)               r57.0<1>:d    r52.0<1;1,0>:d    -256:w               {Compacted,I@5} //  ALU pipe: int; $83
        mov (32|M0)              r61.0<1>:f    r55.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $76
        mov (32|M0)              r59.0<1>:ud   r20.2<4;1,0>:ub                                       //  ALU pipe: int; $93
        mov (32|M0)   (lt)f1.0   null<2>:w     r54.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $95
        shl (32|M0)              r72.0<1>:d    r63.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $79
(f3.0)  sel (32|M0)              r66.0<1>:d    r57.0<1;1,0>:d    r52.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $86
        mul (32|M0)              acc0.0<1>:f   r40.0<1;1,0>:f    r61.0<1;1,0>:f   {Compacted,@1,$4.dst} //  ALU pipe: float; $77
        mov (32|M0)              r65.0<1>:b    r20.3<4;1,0>:b                                        //  ALU pipe: int; $55
        mov (32|M0)              r76.0<1>:d    r36.1<2;1,0>:uw                                       //  ALU pipe: int; $89
        or (32|M0)               r68.0<1>:d    r59.0<1;1,0>:d    -256:w               {Compacted,I@6} //  ALU pipe: int; $94
        mov (32|M0)              r74.0<1>:f    r66.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $87
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r72.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $80
        mov (32|M0)              r70.0<1>:ud   r20.3<4;1,0>:ub                                       //  ALU pipe: int; $104
        mov (32|M0)   (lt)f3.0   null<2>:w     r65.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $106
        shl (32|M0)              r85.0<1>:d    r76.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $90
(f1.0)  sel (32|M0)              r79.0<1>:d    r68.0<1;1,0>:d    r59.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $97
        mul (32|M0)              acc2.0<1>:f   r40.0<1;1,0>:f    r74.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $88
        mov (32|M0)              r78.0<1>:b    r30.0<4;1,0>:b                   {$5.dst}             //  ALU pipe: int; $56
        mov (32|M0)              r89.0<1>:d    r38.0<2;1,0>:uw                  {$6.dst}             //  ALU pipe: int; $100
        or (32|M0)               r81.0<1>:d    r70.0<1;1,0>:d    -256:w               {Compacted,I@6} //  ALU pipe: int; $105
        mov (32|M0)              r87.0<1>:f    r79.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $98
        add (32|M0)              r8.0<1>:f     r98.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $81
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r85.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $91
        mov (32|M0)              r83.0<1>:ud   r30.0<4;1,0>:ub                                       //  ALU pipe: int; $115
        mov (32|M0)   (lt)f1.0   null<2>:w     r78.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $117
        shl (32|M0)              r10.0<1>:d    r89.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $101
(f3.0)  sel (32|M0)              r92.0<1>:d    r81.0<1;1,0>:d    r70.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $108
        mul (32|M0)              acc0.0<1>:f   r40.0<1;1,0>:f    r87.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $99
        mov (32|M0)              r91.0<1>:b    r30.1<4;1,0>:b                                        //  ALU pipe: int; $57
        mov (32|M0)              r14.0<1>:d    r38.1<2;1,0>:uw                                       //  ALU pipe: int; $111
        or (32|M0)               r4.0<1>:d     r83.0<1;1,0>:d    -256:w               {Compacted,I@6} //  ALU pipe: int; $116
        mov (32|M0)              r12.0<1>:f    r92.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $109
        add (32|M0)              r23.0<1>:f    r8.0<1;1,0>:f     acc2.0<1;1,0>:f  {Compacted,@4,$8.src} //  ALU pipe: float; $92
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $102
        mov (32|M0)              r6.0<1>:ud    r30.1<4;1,0>:ub                                       //  ALU pipe: int; $126
        mov (32|M0)   (lt)f3.0   null<2>:w     r91.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $128
        shl (32|M0)              r25.0<1>:d    r14.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $112
(f1.0)  sel (32|M0)              r17.0<1>:d    r4.0<1;1,0>:d     r83.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $119
        mul (32|M0)              acc2.0<1>:f   r40.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $110
        mov (32|M0)              r16.0<1>:b    r30.2<4;1,0>:b                                        //  ALU pipe: int; $58
        mov (32|M0)              r32.0<1>:d    r42.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $122
        or (32|M0)               r19.0<1>:d    r6.0<1;1,0>:d     -256:w               {Compacted,I@6} //  ALU pipe: int; $127
        mov (32|M0)              r27.0<1>:f    r17.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $120
        add (32|M0)              r48.0<1>:f    r23.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $103
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r25.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $113
        mov (32|M0)              r21.0<1>:ud   r30.2<4;1,0>:ub                                       //  ALU pipe: int; $137
        mov (32|M0)   (lt)f1.0   null<2>:w     r16.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $139
        shl (32|M0)              r50.0<1>:d    r32.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $123
(f3.0)  sel (32|M0)              r35.0<1>:d    r19.0<1;1,0>:d    r6.0<1;1,0>:d    {I@4}              //  ALU pipe: int; $130
        mul (32|M0)              acc0.0<1>:f   r40.0<1;1,0>:f    r27.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $121
        mov (32|M0)              r34.0<1>:b    r30.3<4;1,0>:b                                        //  ALU pipe: int; $59
        mov (32|M0)              r54.0<1>:d    r42.1<2;1,0>:uw                                       //  ALU pipe: int; $133
        or (32|M0)               r37.0<1>:d    r21.0<1;1,0>:d    -256:w               {Compacted,I@6} //  ALU pipe: int; $138
        mov (32|M0)              r52.0<1>:f    r35.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $131
        add (32|M0)              r60.0<1>:f    r48.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $114
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r50.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $124
        mov (32|M0)              r46.0<1>:ud   r30.3<4;1,0>:ub                                       //  ALU pipe: int; $148
        mov (32|M0)   (lt)f3.0   null<2>:w     r34.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $150
        shl (32|M0)              r62.0<1>:d    r54.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $134
(f1.0)  sel (32|M0)              r56.0<1>:d    r37.0<1;1,0>:d    r21.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $141 R{} IR{}{O:2,O:2,},  R{} IR{}{E:3,E:11,},  {BC=1}
        mul (32|M0)              acc2.0<1>:f   r40.0<1;1,0>:f    r52.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $132
        mov (32|M0)              r66.0<1>:d    r44.0<2;1,0>:uw                  {$8.dst}             //  ALU pipe: int; $144
        or (32|M0)               r58.0<1>:d    r46.0<1;1,0>:d    -256:w               {Compacted,I@5} //  ALU pipe: int; $149
        mov (32|M0)              r64.0<1>:f    r56.0<1;1,0>:d                   {I@3}                //  ALU pipe: float; $142
        add (32|M0)              r70.0<1>:f    r60.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $125
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $135
        shl (32|M0)              r72.0<1>:d    r66.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $145
(f3.0)  sel (32|M0)              r68.0<1>:d    r58.0<1;1,0>:d    r46.0<1;1,0>:d   {I@2}              //  ALU pipe: int; $152
        mul (32|M0)              acc0.0<1>:f   r40.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $143
        mov (32|M0)              r74.0<1>:f    r68.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $153
        add (32|M0)              r78.0<1>:f    r70.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $136
        mov (32|M0)              r76.0<1>:d    r44.1<2;1,0>:uw                                       //  ALU pipe: int; $155
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r72.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $146
        mul (32|M0)              acc2.0<1>:f   r40.0<1;1,0>:f    r74.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $154
        shl (32|M0)              r80.0<1>:d    r76.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $156
        add (32|M0)              acc0.0<1>:f   r78.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $147
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r100.0<1;1,0>:ud  0x900:uw                            //  ALU pipe: int; $159
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r80.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $157
        add (32|M0)              r98.0<1>:f    acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $158
(~f0.0) goto (32|M0)                         _0_015            _0_015                                //  ALU pipe: int; $160
// B006: [inDivergent],  Preds:{B005},  Succs:{B005}
_0_017:
        add (32|M0)              r100.0<1>:d   r100.0<1;1,0>:d   256:w               {Compacted}     //  ALU pipe: int; $162
(W)     jmpi                                 _0_016                                                  // $163
// B007: Preds:{B005, B003},  Succs:{B008, B012}
_0_015:
        join (32|M0)                         L2248                                                   // 
L2248:
        add (32|M0)              r4.0<1>:d     r96.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $165
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $166
        shl (32|M0)              r8.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $167
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $168
        add (16|M0)              a0.0<1>:uw    r8.0<1;1,0>:uw    0x1880:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0071(r98.0:f); $169
        add (32|M0)              r11.0<1>:d    r96.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $178
        mov (16|M0)              r9.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $170
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $171
        add (16|M16)             a0.0<1>:uw    r8.16<1;1,0>:uw   0x1880:uw                           //  ALU pipe: int; src1 is addr of V0071(r98.0:f); $172
        and (32|M0)   (eq)f3.0   null<1>:d     r96.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $174
        and (32|M0)              r13.0<1>:d    r11.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $179
        mov (16|M16)             r10.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $173
        shl (32|M0)              r15.0<1>:uw   r13.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $180
(f3.0)  sel (32|M0)              acc0.0<1>:f   r9.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $176
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $181
        add (16|M0)              a0.0<1>:uw    r15.0<1;1,0>:uw   0x1980:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0248(r102.0:f); $182
        add (32|M0)              r102.0<1>:f   r98.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $177
        add (32|M0)              r18.0<1>:d    r96.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $191
        mov (16|M0)              r16.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $183
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $184
        add (16|M16)             a0.0<1>:uw    r15.16<1;1,0>:uw  0x1980:uw                           //  ALU pipe: int; src1 is addr of V0248(r102.0:f); $185
        and (32|M0)   (eq)f1.0   null<1>:d     r96.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $187
        and (32|M0)              r20.0<1>:d    r18.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $192
        mov (16|M16)             r17.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $186
        shl (32|M0)              r22.0<1>:uw   r20.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $193
(f1.0)  sel (32|M0)              acc0.0<1>:f   r16.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $189
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $194
        add (16|M0)              a0.0<1>:uw    r22.0<1;1,0>:uw   0x1A00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0256(r104.0:f); $195
        add (32|M0)              r104.0<1>:f   r102.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $190
        add (32|M0)              r25.0<1>:d    r96.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $204
        mov (16|M0)              r23.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $196
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $197
        add (16|M16)             a0.0<1>:uw    r22.16<1;1,0>:uw  0x1A00:uw                           //  ALU pipe: int; src1 is addr of V0256(r104.0:f); $198
        and (32|M0)   (eq)f0.0   null<1>:d     r96.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $200
        and (32|M0)              r27.0<1>:d    r25.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $205
        mov (16|M16)             r24.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $199
        shl (32|M0)              r29.0<1>:uw   r27.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $206
(f0.0)  sel (32|M0)              acc0.0<1>:f   r23.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $202
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $207
        add (16|M0)              a0.0<1>:uw    r29.0<1;1,0>:uw   0x1A80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0264(r106.0:f); $208
        add (32|M0)              r106.0<1>:f   r104.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $203
        mov (16|M0)              r30.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $209
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $210
        add (16|M16)             a0.0<1>:uw    r29.16<1;1,0>:uw  0x1A80:uw                           //  ALU pipe: int; src1 is addr of V0264(r106.0:f); $211
        add (32|M0)              r32.0<1>:d    r96.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $217
        and (32|M0)   (eq)f3.0   null<1>:d     r96.0<1;1,0>:d    15:w                                //  ALU pipe: int; $213
        mov (16|M16)             r31.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $212
        and (32|M0)              r34.0<1>:d    r32.0<1;1,0>:d    31:w               {Compacted,I@3}  //  ALU pipe: int; $218
(f3.0)  sel (32|M0)              acc0.0<1>:f   r30.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $215
        shl (32|M0)              r36.0<1>:uw   r34.0<2;1,0>:uw   0x2:uw              {I@1}           //  ALU pipe: int; $219
        cmp (32|M0)   (ne)f3.0   null<2>:w     r95.0<1;1,0>:w    0:w               {F@1}             //  ALU pipe: int; $226
(W)     mov (1|M0)               r37.0<1>:hf   0x1:hf                                                //  ALU pipe: float; $227
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $220
        add (16|M0)              a0.0<1>:uw    r36.0<1;1,0>:uw   0x1B00:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0272(r108.0:f); $221
        add (32|M0)              r108.0<1>:f   r106.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $216
(f3.0)  sel (32|M0)              r38.0<1>:uw   r37.0<0;1,0>:uw   0x0:uw              {F@2}           //  ALU pipe: int; $227
(f2.0)  sel (32|M0)              r39.0<1>:uw   r37.0<0;1,0>:uw   0x0:uw                              //  ALU pipe: int; $227
        mov (16|M0)              r110.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $222
        or (32|M0)    (ne)f3.0   null<2>:uw    r38.0<1;1,0>:uw   r39.0<1;1,0>:uw  {I@2}              //  ALU pipe: int; $227
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $223
        add (16|M16)             a0.0<1>:uw    r36.16<1;1,0>:uw  0x1B00:uw                           //  ALU pipe: int; src1 is addr of V0272(r108.0:f); $224
        mov (16|M16)             r111.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $225
(f3.0)  goto (32|M0)                         _0_018            _0_018                                //  ALU pipe: int; $228
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B010}
_0_019:
        cmp (32|M0)   (eq)f1.0   null<2>:w     r95.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $230
(f1.0)  sel (32|M0)              acc0.0<1>:f   r110.0<1;1,0>:f   0x80000000:f               {I@3}    //  ALU pipe: float; $231
        add (32|M0)              r113.0<1>:f   r108.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $232
        and (32|M0)              r4.0<1>:d     r113.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $233
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r4.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $234
(f0.0)  goto (32|M0)                         _0_020            _0_020                                //  ALU pipe: int; $235
// B009: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_021:
        shr (32|M0)              r4.0<1>:ud    r113.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $237
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $238
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r113.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $239
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $240
        mov (32|M0)              r112.0<1>:w   r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $241
        goto (32|M0)                         _0_020            _0_022                                // $242
// B010: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_020:
        join (32|M0)                         _0_022                                                  // 
L3336:
        shr (32|M0)              r4.0<1>:ud    r113.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $244
        or (32|M0)               r112.0<1>:w   r4.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $246
// B011: [inDivergent],  Preds:{B010, B009},  Succs:{B012}
_0_022:
        join (32|M0)                         _0_018                                                  // 
L3384:
        shl (16|M0)              r4.0<1>:q     r115.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $248
        shl (16|M16)             r6.0<1>:q     r117.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $248
        mov (32|M0)              r12.0<1>:ud   r112.0<1;1,0>:uw                 {I@4}                //  ALU pipe: int; $250
        add (16|M0)              r8.0<1>:q     r4.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $249
        add (16|M16)             r10.0<1>:q    r6.0<1;1,0>:q     r3.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $249
        store.ugm.d16u32.a64 (32|M0)  [r8:4]    r12:2              {I@1,$9} // ex_desc:0x0; desc:0x8000B84 // $251
// B012: Preds:{B011, B007},  Succs:{}
_0_018:
        join (32|M0)                         L3464                                                   // 
L3464:
(W)     mov (16|M0)              r127.0<1>:f   r94.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $253
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$10} // wr:1+0, rd:0; end of thread // $253
L3488:
(W)     mov (16|M0)              null<1>:ud    0xFEECE865:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x5881B820:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1:ud                                                // 


//.BankConflicts: 1
//.ByteRMWs: 0
//


//.numALUInst: 240
//.accSubDef: 22
//.accSubUse: 22
//.accSubCandidateDef: 28
//.accSubCandidateUse: 28
//
//
//.singlePipeAtOneDistNum: 28
//.allAtOneDistNum: 4
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 9
//.AfterReadTokenDepCount: 2
