; ------------------------------------------------
; OCL_asm1190705249d3e737_codegen.ll
; ------------------------------------------------
target datalayout = "e-p:64:64:64-i1:8:8-i8:8:8-i16:16:16-i32:32:32-i64:64:64-f32:32:32-f64:64:64-v16:16:16-v24:32:32-v32:32:32-v48:64:64-v64:64:64-v96:128:128-v128:128:128-v192:256:256-v256:256:256-v512:512:512-v1024:1024:1024-n8:16:32"
target triple = "spir64-unknown-unknown"

; Function Attrs: convergent nounwind null_pointer_is_valid
define spir_kernel void @_ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_(i32 %0, ptr addrspace(1) align 1 %1, i64 %2, ptr addrspace(1) align 2 %3, ptr addrspace(1) align 2 %4, <8 x i32> %r0, <3 x i32> %globalOffset, <3 x i32> %enqueuedLocalSize, i16 %localIdX, i16 %localIdY, i16 %localIdZ, ptr %privateBase, i32 %bufferOffset, i32 %bufferOffset1, i32 %bufferOffset2, i32 %bindlessOffset, i32 %bindlessOffset3, i32 %bindlessOffset4) #0 {
  %6 = extractelement <3 x i32> %enqueuedLocalSize, i32 0
  %7 = extractelement <8 x i32> %r0, i32 1
  %simdLaneId16 = call i16 @llvm.genx.GenISA.simdLaneId()
  %simdLaneId = zext i16 %simdLaneId16 to i32
  %8 = call { i32, i32 } @llvm.genx.GenISA.mul.pair(i32 %6, i32 0, i32 %7, i32 0)
  %9 = extractvalue { i32, i32 } %8, 0
  %10 = extractvalue { i32, i32 } %8, 1
  %11 = insertelement <2 x i32> undef, i32 %9, i32 0
  %12 = insertelement <2 x i32> %11, i32 %10, i32 1
  %13 = bitcast <2 x i32> %12 to i64
  %14 = zext i16 %localIdX to i64
  %15 = add nuw i64 %13, %14
  %16 = lshr i64 %15, 5
  %17 = trunc i64 %16 to i32
  %18 = icmp uge i32 %17, %0
  %19 = icmp uge i32 %17, %0
  br i1 %19, label %..loopexit_crit_edge, label %.lr.ph, !stats.blockFrequency.digits !434, !stats.blockFrequency.scale !435

..loopexit_crit_edge:                             ; preds = %5
  br label %.loopexit, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

.lr.ph:                                           ; preds = %5
  %20 = bitcast i64 %2 to <2 x i32>
  %21 = extractelement <2 x i32> %20, i32 0
  %22 = extractelement <2 x i32> %20, i32 1
  %23 = bitcast i64 %16 to <2 x i32>
  %24 = extractelement <2 x i32> %23, i32 0
  %25 = extractelement <2 x i32> %23, i32 1
  %26 = call { i32, i32 } @llvm.genx.GenISA.mul.pair(i32 %24, i32 %25, i32 %21, i32 %22)
  %27 = extractvalue { i32, i32 } %26, 0
  %28 = extractvalue { i32, i32 } %26, 1
  %29 = insertelement <2 x i32> undef, i32 %27, i32 0
  %30 = insertelement <2 x i32> %29, i32 %28, i32 1
  %31 = bitcast <2 x i32> %30 to i64
  %32 = ptrtoint ptr addrspace(1) %1 to i64
  %33 = add i64 %31, %32
  %34 = shl nuw nsw i32 %simdLaneId, 3
  %35 = add i64 %33, 2560
  %36 = ptrtoint ptr addrspace(1) %3 to i64
  br label %.preheader.preheader, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

.preheader.preheader:                             ; preds = %.preheader.preheader..preheader.preheader_crit_edge, %.lr.ph
  %37 = phi float [ 0.000000e+00, %.lr.ph ], [ %154, %.preheader.preheader..preheader.preheader_crit_edge ]
  %38 = phi i32 [ %34, %.lr.ph ], [ %156, %.preheader.preheader..preheader.preheader_crit_edge ]
  %39 = lshr exact i32 %38, 2
  %40 = and i32 %39, 1020
  %41 = zext i32 %40 to i64
  %42 = add i64 %35, %41
  %43 = inttoptr i64 %42 to ptr addrspace(1)
  %44 = load float, ptr addrspace(1) %43, align 1
  %45 = zext i32 %38 to i64
  %46 = add i64 %33, %45
  %IntToPtr2 = inttoptr i64 %46 to ptr addrspace(1)
  %vCastload = load i32, ptr addrspace(1) %IntToPtr2, align 1
  %47 = add i64 %46, 4
  %IntToPtr254 = inttoptr i64 %47 to ptr addrspace(1)
  %vCastload55 = load i32, ptr addrspace(1) %IntToPtr254, align 1
  %48 = shl nuw nsw i64 %45, 1
  %49 = add i64 %48, %36
  %IntToPtr256 = inttoptr i64 %49 to ptr addrspace(1)
  %vCastload57 = load i32, ptr addrspace(1) %IntToPtr256, align 2
  %50 = bitcast i32 %vCastload to <4 x i8>
  %51 = bitcast i32 %vCastload55 to <4 x i8>
  %52 = extractelement <4 x i8> %50, i32 0
  %53 = extractelement <4 x i8> %50, i32 1
  %54 = extractelement <4 x i8> %50, i32 2
  %55 = extractelement <4 x i8> %50, i32 3
  %56 = extractelement <4 x i8> %51, i32 0
  %57 = extractelement <4 x i8> %51, i32 1
  %58 = extractelement <4 x i8> %51, i32 2
  %59 = extractelement <4 x i8> %51, i32 3
  %60 = bitcast i32 %vCastload57 to <2 x i16>
  %61 = add i64 %49, 4
  %IntToPtr258 = inttoptr i64 %61 to ptr addrspace(1)
  %vCastload59 = load i32, ptr addrspace(1) %IntToPtr258, align 2
  %62 = add i64 %49, 8
  %IntToPtr260 = inttoptr i64 %62 to ptr addrspace(1)
  %vCastload61 = load i32, ptr addrspace(1) %IntToPtr260, align 2
  %63 = add i64 %49, 12
  %IntToPtr262 = inttoptr i64 %63 to ptr addrspace(1)
  %vCastload63 = load i32, ptr addrspace(1) %IntToPtr262, align 2
  %64 = bitcast i32 %vCastload59 to <2 x i16>
  %65 = extractelement <2 x i16> %60, i32 0
  %66 = extractelement <2 x i16> %60, i32 1
  %67 = extractelement <2 x i16> %64, i32 0
  %68 = extractelement <2 x i16> %64, i32 1
  %69 = bitcast i32 %vCastload61 to <2 x i16>
  %70 = bitcast i32 %vCastload63 to <2 x i16>
  %71 = extractelement <2 x i16> %69, i32 0
  %72 = extractelement <2 x i16> %69, i32 1
  %73 = extractelement <2 x i16> %70, i32 0
  %74 = extractelement <2 x i16> %70, i32 1
  %75 = zext i8 %52 to i32
  %76 = or i32 %75, -256
  %b2s = sext i8 %52 to i16
  %b2s64 = icmp slt i16 %b2s, 0
  %77 = select i1 %b2s64, i32 %76, i32 %75
  %78 = sitofp i32 %77 to float
  %79 = fmul float %44, %78
  %80 = zext i16 %65 to i32
  %81 = shl nuw i32 %80, 16, !spirv.Decorations !437
  %82 = bitcast i32 %81 to float
  %83 = fmul float %79, %82
  %84 = fadd float %37, %83
  %85 = zext i8 %53 to i32
  %86 = or i32 %85, -256
  %b2s65 = sext i8 %53 to i16
  %b2s66 = icmp slt i16 %b2s65, 0
  %87 = select i1 %b2s66, i32 %86, i32 %85
  %88 = sitofp i32 %87 to float
  %89 = fmul float %44, %88
  %90 = zext i16 %66 to i32
  %91 = shl nuw i32 %90, 16, !spirv.Decorations !437
  %92 = bitcast i32 %91 to float
  %93 = fmul float %89, %92
  %94 = fadd float %84, %93
  %95 = zext i8 %54 to i32
  %96 = or i32 %95, -256
  %b2s67 = sext i8 %54 to i16
  %b2s68 = icmp slt i16 %b2s67, 0
  %97 = select i1 %b2s68, i32 %96, i32 %95
  %98 = sitofp i32 %97 to float
  %99 = fmul float %44, %98
  %100 = zext i16 %67 to i32
  %101 = shl nuw i32 %100, 16, !spirv.Decorations !437
  %102 = bitcast i32 %101 to float
  %103 = fmul float %99, %102
  %104 = fadd float %94, %103
  %105 = zext i8 %55 to i32
  %106 = or i32 %105, -256
  %b2s69 = sext i8 %55 to i16
  %b2s70 = icmp slt i16 %b2s69, 0
  %107 = select i1 %b2s70, i32 %106, i32 %105
  %108 = sitofp i32 %107 to float
  %109 = fmul float %44, %108
  %110 = zext i16 %68 to i32
  %111 = shl nuw i32 %110, 16, !spirv.Decorations !437
  %112 = bitcast i32 %111 to float
  %113 = fmul float %109, %112
  %114 = fadd float %104, %113
  %115 = zext i8 %56 to i32
  %116 = or i32 %115, -256
  %b2s71 = sext i8 %56 to i16
  %b2s72 = icmp slt i16 %b2s71, 0
  %117 = select i1 %b2s72, i32 %116, i32 %115
  %118 = sitofp i32 %117 to float
  %119 = fmul float %44, %118
  %120 = zext i16 %71 to i32
  %121 = shl nuw i32 %120, 16, !spirv.Decorations !437
  %122 = bitcast i32 %121 to float
  %123 = fmul float %119, %122
  %124 = fadd float %114, %123
  %125 = zext i8 %57 to i32
  %126 = or i32 %125, -256
  %b2s73 = sext i8 %57 to i16
  %b2s74 = icmp slt i16 %b2s73, 0
  %127 = select i1 %b2s74, i32 %126, i32 %125
  %128 = sitofp i32 %127 to float
  %129 = fmul float %44, %128
  %130 = zext i16 %72 to i32
  %131 = shl nuw i32 %130, 16, !spirv.Decorations !437
  %132 = bitcast i32 %131 to float
  %133 = fmul float %129, %132
  %134 = fadd float %124, %133
  %135 = zext i8 %58 to i32
  %136 = or i32 %135, -256
  %b2s75 = sext i8 %58 to i16
  %b2s76 = icmp slt i16 %b2s75, 0
  %137 = select i1 %b2s76, i32 %136, i32 %135
  %138 = sitofp i32 %137 to float
  %139 = fmul float %44, %138
  %140 = zext i16 %73 to i32
  %141 = shl nuw i32 %140, 16, !spirv.Decorations !437
  %142 = bitcast i32 %141 to float
  %143 = fmul float %139, %142
  %144 = fadd float %134, %143
  %145 = zext i8 %59 to i32
  %146 = or i32 %145, -256
  %b2s77 = sext i8 %59 to i16
  %b2s78 = icmp slt i16 %b2s77, 0
  %147 = select i1 %b2s78, i32 %146, i32 %145
  %148 = sitofp i32 %147 to float
  %149 = fmul float %44, %148
  %150 = zext i16 %74 to i32
  %151 = shl nuw i32 %150, 16, !spirv.Decorations !437
  %152 = bitcast i32 %151 to float
  %153 = fmul float %149, %152
  %154 = fadd float %144, %153
  %155 = icmp ult i32 %38, 2304
  br i1 %155, label %.preheader.preheader..preheader.preheader_crit_edge, label %.loopexit.loopexit, !stats.blockFrequency.digits !439, !stats.blockFrequency.scale !435

.loopexit.loopexit:                               ; preds = %.preheader.preheader
  %.lcssa = phi float [ %154, %.preheader.preheader ]
  br label %.loopexit, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

.preheader.preheader..preheader.preheader_crit_edge: ; preds = %.preheader.preheader
  %156 = add nuw nsw i32 %38, 256, !spirv.Decorations !440
  br label %.preheader.preheader, !stats.blockFrequency.digits !442, !stats.blockFrequency.scale !435

.loopexit:                                        ; preds = %..loopexit_crit_edge, %.loopexit.loopexit
  %157 = phi float [ 0.000000e+00, %..loopexit_crit_edge ], [ %.lcssa, %.loopexit.loopexit ]
  %158 = add nuw nsw i32 %simdLaneId, 1
  %159 = and i32 %158, 31
  %simdShuffle = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %157, i32 %159, i32 0)
  %160 = and i32 %simdLaneId, 1
  %161 = icmp eq i32 %160, 0
  %162 = select i1 %161, float %simdShuffle, float -0.000000e+00
  %163 = fadd float %157, %162
  %164 = add nuw nsw i32 %simdLaneId, 2
  %165 = and i32 %164, 31
  %simdShuffle.1 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %163, i32 %165, i32 0)
  %166 = and i32 %simdLaneId, 3
  %167 = icmp eq i32 %166, 0
  %168 = select i1 %167, float %simdShuffle.1, float -0.000000e+00
  %169 = fadd float %163, %168
  %170 = add nuw nsw i32 %simdLaneId, 4
  %171 = and i32 %170, 31
  %simdShuffle.2 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %169, i32 %171, i32 0)
  %172 = and i32 %simdLaneId, 7
  %173 = icmp eq i32 %172, 0
  %174 = select i1 %173, float %simdShuffle.2, float -0.000000e+00
  %175 = fadd float %169, %174
  %176 = add nuw nsw i32 %simdLaneId, 8
  %177 = and i32 %176, 31
  %simdShuffle.3 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %175, i32 %177, i32 0)
  %178 = and i32 %simdLaneId, 15
  %179 = icmp eq i32 %178, 0
  %180 = select i1 %179, float %simdShuffle.3, float -0.000000e+00
  %181 = fadd float %175, %180
  %182 = add nuw nsw i32 %simdLaneId, 16
  %183 = and i32 %182, 31
  %simdShuffle.4 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %181, i32 %183, i32 0)
  %184 = icmp ne i16 %simdLaneId16, 0
  %185 = or i1 %184, %18
  br i1 %185, label %.loopexit.._crit_edge_crit_edge, label %186, !stats.blockFrequency.digits !434, !stats.blockFrequency.scale !435

.loopexit.._crit_edge_crit_edge:                  ; preds = %.loopexit
  br label %._crit_edge, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

186:                                              ; preds = %.loopexit
  %187 = icmp eq i16 %simdLaneId16, 0
  %188 = select i1 %187, float %simdShuffle.4, float -0.000000e+00
  %189 = fadd float %181, %188
  %190 = bitcast float %189 to i32
  %191 = and i32 %190, 2147483647
  %192 = icmp ugt i32 %191, 2139095040
  br i1 %192, label %200, label %193, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

193:                                              ; preds = %186
  %194 = lshr i32 %190, 16
  %195 = and i32 %194, 1
  %196 = add i32 %195, %190
  %197 = add i32 %196, 32767
  %198 = lshr i32 %197, 16
  %199 = trunc i32 %198 to i16
  br label %204, !stats.blockFrequency.digits !443, !stats.blockFrequency.scale !435

200:                                              ; preds = %186
  %201 = lshr i32 %190, 16
  %202 = trunc i32 %201 to i16
  %203 = or i16 %202, 64
  br label %204, !stats.blockFrequency.digits !443, !stats.blockFrequency.scale !435

204:                                              ; preds = %193, %200
  %205 = phi i16 [ %203, %200 ], [ %199, %193 ]
  %206 = ptrtoint ptr addrspace(1) %4 to i64
  %207 = shl nuw nsw i64 %16, 1
  %208 = add i64 %207, %206
  %209 = inttoptr i64 %208 to ptr addrspace(1)
  store i16 %205, ptr addrspace(1) %209, align 2
  br label %._crit_edge, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

._crit_edge:                                      ; preds = %.loopexit.._crit_edge_crit_edge, %204
  ret void, !stats.blockFrequency.digits !434, !stats.blockFrequency.scale !435
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.assume(i1 noundef) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: convergent nounwind null_pointer_is_valid
define spir_kernel void @_ZTSZZNK3p694HeadILj128EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_(i32 %0, ptr addrspace(1) align 1 %1, i64 %2, ptr addrspace(1) align 2 %3, ptr addrspace(1) align 2 %4, <8 x i32> %r0, <3 x i32> %globalOffset, <3 x i32> %enqueuedLocalSize, i16 %localIdX, i16 %localIdY, i16 %localIdZ, ptr %privateBase, i32 %bufferOffset, i32 %bufferOffset1, i32 %bufferOffset2, i32 %bindlessOffset, i32 %bindlessOffset3, i32 %bindlessOffset4) #0 {
  %6 = extractelement <3 x i32> %enqueuedLocalSize, i32 0
  %7 = extractelement <8 x i32> %r0, i32 1
  %simdLaneId16 = call i16 @llvm.genx.GenISA.simdLaneId()
  %simdLaneId = zext i16 %simdLaneId16 to i32
  %8 = call { i32, i32 } @llvm.genx.GenISA.mul.pair(i32 %6, i32 0, i32 %7, i32 0)
  %9 = extractvalue { i32, i32 } %8, 0
  %10 = extractvalue { i32, i32 } %8, 1
  %11 = insertelement <2 x i32> undef, i32 %9, i32 0
  %12 = insertelement <2 x i32> %11, i32 %10, i32 1
  %13 = bitcast <2 x i32> %12 to i64
  %14 = zext i16 %localIdX to i64
  %15 = add nuw i64 %13, %14
  %16 = lshr i64 %15, 5
  %17 = trunc i64 %16 to i32
  %18 = icmp uge i32 %17, %0
  %19 = icmp uge i32 %17, %0
  br i1 %19, label %..loopexit_crit_edge, label %.lr.ph, !stats.blockFrequency.digits !434, !stats.blockFrequency.scale !435

..loopexit_crit_edge:                             ; preds = %5
  br label %.loopexit, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

.lr.ph:                                           ; preds = %5
  %20 = bitcast i64 %2 to <2 x i32>
  %21 = extractelement <2 x i32> %20, i32 0
  %22 = extractelement <2 x i32> %20, i32 1
  %23 = bitcast i64 %16 to <2 x i32>
  %24 = extractelement <2 x i32> %23, i32 0
  %25 = extractelement <2 x i32> %23, i32 1
  %26 = call { i32, i32 } @llvm.genx.GenISA.mul.pair(i32 %24, i32 %25, i32 %21, i32 %22)
  %27 = extractvalue { i32, i32 } %26, 0
  %28 = extractvalue { i32, i32 } %26, 1
  %29 = insertelement <2 x i32> undef, i32 %27, i32 0
  %30 = insertelement <2 x i32> %29, i32 %28, i32 1
  %31 = bitcast <2 x i32> %30 to i64
  %32 = ptrtoint ptr addrspace(1) %1 to i64
  %33 = add i64 %31, %32
  %34 = shl nuw nsw i32 %simdLaneId, 3
  %35 = add i64 %33, 2560
  %36 = ptrtoint ptr addrspace(1) %3 to i64
  br label %.preheader.preheader, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

.preheader.preheader:                             ; preds = %.preheader.preheader..preheader.preheader_crit_edge, %.lr.ph
  %37 = phi float [ 0.000000e+00, %.lr.ph ], [ %154, %.preheader.preheader..preheader.preheader_crit_edge ]
  %38 = phi i32 [ %34, %.lr.ph ], [ %156, %.preheader.preheader..preheader.preheader_crit_edge ]
  %39 = lshr exact i32 %38, 2
  %40 = and i32 %39, 1020
  %41 = zext i32 %40 to i64
  %42 = add i64 %35, %41
  %43 = inttoptr i64 %42 to ptr addrspace(1)
  %44 = load float, ptr addrspace(1) %43, align 1
  %45 = zext i32 %38 to i64
  %46 = add i64 %33, %45
  %IntToPtr2 = inttoptr i64 %46 to ptr addrspace(1)
  %vCastload = load i32, ptr addrspace(1) %IntToPtr2, align 1
  %47 = add i64 %46, 4
  %IntToPtr254 = inttoptr i64 %47 to ptr addrspace(1)
  %vCastload55 = load i32, ptr addrspace(1) %IntToPtr254, align 1
  %48 = shl nuw nsw i64 %45, 1
  %49 = add i64 %48, %36
  %IntToPtr256 = inttoptr i64 %49 to ptr addrspace(1)
  %vCastload57 = load i32, ptr addrspace(1) %IntToPtr256, align 2
  %50 = bitcast i32 %vCastload to <4 x i8>
  %51 = bitcast i32 %vCastload55 to <4 x i8>
  %52 = extractelement <4 x i8> %50, i32 0
  %53 = extractelement <4 x i8> %50, i32 1
  %54 = extractelement <4 x i8> %50, i32 2
  %55 = extractelement <4 x i8> %50, i32 3
  %56 = extractelement <4 x i8> %51, i32 0
  %57 = extractelement <4 x i8> %51, i32 1
  %58 = extractelement <4 x i8> %51, i32 2
  %59 = extractelement <4 x i8> %51, i32 3
  %60 = bitcast i32 %vCastload57 to <2 x i16>
  %61 = add i64 %49, 4
  %IntToPtr258 = inttoptr i64 %61 to ptr addrspace(1)
  %vCastload59 = load i32, ptr addrspace(1) %IntToPtr258, align 2
  %62 = add i64 %49, 8
  %IntToPtr260 = inttoptr i64 %62 to ptr addrspace(1)
  %vCastload61 = load i32, ptr addrspace(1) %IntToPtr260, align 2
  %63 = add i64 %49, 12
  %IntToPtr262 = inttoptr i64 %63 to ptr addrspace(1)
  %vCastload63 = load i32, ptr addrspace(1) %IntToPtr262, align 2
  %64 = bitcast i32 %vCastload59 to <2 x i16>
  %65 = extractelement <2 x i16> %60, i32 0
  %66 = extractelement <2 x i16> %60, i32 1
  %67 = extractelement <2 x i16> %64, i32 0
  %68 = extractelement <2 x i16> %64, i32 1
  %69 = bitcast i32 %vCastload61 to <2 x i16>
  %70 = bitcast i32 %vCastload63 to <2 x i16>
  %71 = extractelement <2 x i16> %69, i32 0
  %72 = extractelement <2 x i16> %69, i32 1
  %73 = extractelement <2 x i16> %70, i32 0
  %74 = extractelement <2 x i16> %70, i32 1
  %75 = zext i8 %52 to i32
  %76 = or i32 %75, -256
  %b2s = sext i8 %52 to i16
  %b2s64 = icmp slt i16 %b2s, 0
  %77 = select i1 %b2s64, i32 %76, i32 %75
  %78 = sitofp i32 %77 to float
  %79 = fmul float %44, %78
  %80 = zext i16 %65 to i32
  %81 = shl nuw i32 %80, 16, !spirv.Decorations !437
  %82 = bitcast i32 %81 to float
  %83 = fmul float %79, %82
  %84 = fadd float %37, %83
  %85 = zext i8 %53 to i32
  %86 = or i32 %85, -256
  %b2s65 = sext i8 %53 to i16
  %b2s66 = icmp slt i16 %b2s65, 0
  %87 = select i1 %b2s66, i32 %86, i32 %85
  %88 = sitofp i32 %87 to float
  %89 = fmul float %44, %88
  %90 = zext i16 %66 to i32
  %91 = shl nuw i32 %90, 16, !spirv.Decorations !437
  %92 = bitcast i32 %91 to float
  %93 = fmul float %89, %92
  %94 = fadd float %84, %93
  %95 = zext i8 %54 to i32
  %96 = or i32 %95, -256
  %b2s67 = sext i8 %54 to i16
  %b2s68 = icmp slt i16 %b2s67, 0
  %97 = select i1 %b2s68, i32 %96, i32 %95
  %98 = sitofp i32 %97 to float
  %99 = fmul float %44, %98
  %100 = zext i16 %67 to i32
  %101 = shl nuw i32 %100, 16, !spirv.Decorations !437
  %102 = bitcast i32 %101 to float
  %103 = fmul float %99, %102
  %104 = fadd float %94, %103
  %105 = zext i8 %55 to i32
  %106 = or i32 %105, -256
  %b2s69 = sext i8 %55 to i16
  %b2s70 = icmp slt i16 %b2s69, 0
  %107 = select i1 %b2s70, i32 %106, i32 %105
  %108 = sitofp i32 %107 to float
  %109 = fmul float %44, %108
  %110 = zext i16 %68 to i32
  %111 = shl nuw i32 %110, 16, !spirv.Decorations !437
  %112 = bitcast i32 %111 to float
  %113 = fmul float %109, %112
  %114 = fadd float %104, %113
  %115 = zext i8 %56 to i32
  %116 = or i32 %115, -256
  %b2s71 = sext i8 %56 to i16
  %b2s72 = icmp slt i16 %b2s71, 0
  %117 = select i1 %b2s72, i32 %116, i32 %115
  %118 = sitofp i32 %117 to float
  %119 = fmul float %44, %118
  %120 = zext i16 %71 to i32
  %121 = shl nuw i32 %120, 16, !spirv.Decorations !437
  %122 = bitcast i32 %121 to float
  %123 = fmul float %119, %122
  %124 = fadd float %114, %123
  %125 = zext i8 %57 to i32
  %126 = or i32 %125, -256
  %b2s73 = sext i8 %57 to i16
  %b2s74 = icmp slt i16 %b2s73, 0
  %127 = select i1 %b2s74, i32 %126, i32 %125
  %128 = sitofp i32 %127 to float
  %129 = fmul float %44, %128
  %130 = zext i16 %72 to i32
  %131 = shl nuw i32 %130, 16, !spirv.Decorations !437
  %132 = bitcast i32 %131 to float
  %133 = fmul float %129, %132
  %134 = fadd float %124, %133
  %135 = zext i8 %58 to i32
  %136 = or i32 %135, -256
  %b2s75 = sext i8 %58 to i16
  %b2s76 = icmp slt i16 %b2s75, 0
  %137 = select i1 %b2s76, i32 %136, i32 %135
  %138 = sitofp i32 %137 to float
  %139 = fmul float %44, %138
  %140 = zext i16 %73 to i32
  %141 = shl nuw i32 %140, 16, !spirv.Decorations !437
  %142 = bitcast i32 %141 to float
  %143 = fmul float %139, %142
  %144 = fadd float %134, %143
  %145 = zext i8 %59 to i32
  %146 = or i32 %145, -256
  %b2s77 = sext i8 %59 to i16
  %b2s78 = icmp slt i16 %b2s77, 0
  %147 = select i1 %b2s78, i32 %146, i32 %145
  %148 = sitofp i32 %147 to float
  %149 = fmul float %44, %148
  %150 = zext i16 %74 to i32
  %151 = shl nuw i32 %150, 16, !spirv.Decorations !437
  %152 = bitcast i32 %151 to float
  %153 = fmul float %149, %152
  %154 = fadd float %144, %153
  %155 = icmp ult i32 %38, 2304
  br i1 %155, label %.preheader.preheader..preheader.preheader_crit_edge, label %.loopexit.loopexit, !stats.blockFrequency.digits !439, !stats.blockFrequency.scale !435

.loopexit.loopexit:                               ; preds = %.preheader.preheader
  %.lcssa = phi float [ %154, %.preheader.preheader ]
  br label %.loopexit, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

.preheader.preheader..preheader.preheader_crit_edge: ; preds = %.preheader.preheader
  %156 = add nuw nsw i32 %38, 256, !spirv.Decorations !440
  br label %.preheader.preheader, !stats.blockFrequency.digits !442, !stats.blockFrequency.scale !435

.loopexit:                                        ; preds = %..loopexit_crit_edge, %.loopexit.loopexit
  %157 = phi float [ 0.000000e+00, %..loopexit_crit_edge ], [ %.lcssa, %.loopexit.loopexit ]
  %158 = add nuw nsw i32 %simdLaneId, 1
  %159 = and i32 %158, 31
  %simdShuffle = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %157, i32 %159, i32 0)
  %160 = and i32 %simdLaneId, 1
  %161 = icmp eq i32 %160, 0
  %162 = select i1 %161, float %simdShuffle, float -0.000000e+00
  %163 = fadd float %157, %162
  %164 = add nuw nsw i32 %simdLaneId, 2
  %165 = and i32 %164, 31
  %simdShuffle.1 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %163, i32 %165, i32 0)
  %166 = and i32 %simdLaneId, 3
  %167 = icmp eq i32 %166, 0
  %168 = select i1 %167, float %simdShuffle.1, float -0.000000e+00
  %169 = fadd float %163, %168
  %170 = add nuw nsw i32 %simdLaneId, 4
  %171 = and i32 %170, 31
  %simdShuffle.2 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %169, i32 %171, i32 0)
  %172 = and i32 %simdLaneId, 7
  %173 = icmp eq i32 %172, 0
  %174 = select i1 %173, float %simdShuffle.2, float -0.000000e+00
  %175 = fadd float %169, %174
  %176 = add nuw nsw i32 %simdLaneId, 8
  %177 = and i32 %176, 31
  %simdShuffle.3 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %175, i32 %177, i32 0)
  %178 = and i32 %simdLaneId, 15
  %179 = icmp eq i32 %178, 0
  %180 = select i1 %179, float %simdShuffle.3, float -0.000000e+00
  %181 = fadd float %175, %180
  %182 = add nuw nsw i32 %simdLaneId, 16
  %183 = and i32 %182, 31
  %simdShuffle.4 = call float @llvm.genx.GenISA.WaveShuffleIndex.f32(float %181, i32 %183, i32 0)
  %184 = icmp ne i16 %simdLaneId16, 0
  %185 = or i1 %184, %18
  br i1 %185, label %.loopexit.._crit_edge_crit_edge, label %186, !stats.blockFrequency.digits !434, !stats.blockFrequency.scale !435

.loopexit.._crit_edge_crit_edge:                  ; preds = %.loopexit
  br label %._crit_edge, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

186:                                              ; preds = %.loopexit
  %187 = icmp eq i16 %simdLaneId16, 0
  %188 = select i1 %187, float %simdShuffle.4, float -0.000000e+00
  %189 = fadd float %181, %188
  %190 = bitcast float %189 to i32
  %191 = and i32 %190, 2147483647
  %192 = icmp ugt i32 %191, 2139095040
  br i1 %192, label %200, label %193, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

193:                                              ; preds = %186
  %194 = lshr i32 %190, 16
  %195 = and i32 %194, 1
  %196 = add i32 %195, %190
  %197 = add i32 %196, 32767
  %198 = lshr i32 %197, 16
  %199 = trunc i32 %198 to i16
  br label %204, !stats.blockFrequency.digits !443, !stats.blockFrequency.scale !435

200:                                              ; preds = %186
  %201 = lshr i32 %190, 16
  %202 = trunc i32 %201 to i16
  %203 = or i16 %202, 64
  br label %204, !stats.blockFrequency.digits !443, !stats.blockFrequency.scale !435

204:                                              ; preds = %193, %200
  %205 = phi i16 [ %203, %200 ], [ %199, %193 ]
  %206 = ptrtoint ptr addrspace(1) %4 to i64
  %207 = shl nuw nsw i64 %16, 1
  %208 = add i64 %207, %206
  %209 = inttoptr i64 %208 to ptr addrspace(1)
  store i16 %205, ptr addrspace(1) %209, align 2
  br label %._crit_edge, !stats.blockFrequency.digits !436, !stats.blockFrequency.scale !435

._crit_edge:                                      ; preds = %.loopexit.._crit_edge_crit_edge, %204
  ret void, !stats.blockFrequency.digits !434, !stats.blockFrequency.scale !435
}

; Function Attrs: convergent nounwind
declare spir_func float @__builtin_IB_simd_shuffle_f(float noundef, i32 noundef) local_unnamed_addr #3

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_group_id(i32 noundef) local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_enqueued_local_size(i32 noundef) local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_local_id_x() local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_local_id_y() local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_local_id_z() local_unnamed_addr #4

; Function Attrs: convergent mustprogress nofree nounwind willreturn memory(none)
declare spir_func i32 @__builtin_IB_get_global_offset(i32 noundef) local_unnamed_addr #4

; Function Attrs: convergent nounwind
declare spir_func i32 @__builtin_IB_get_simd_id() local_unnamed_addr #3

declare i32 @printf(ptr addrspace(2), ...)

; Function Desc: 
; Output: 
; Function Attrs: nounwind willreturn memory(none)
declare i16 @llvm.genx.GenISA.simdLaneId() #5

; Function Desc: 
; Output: 
; Arg 0: 
; Arg 1: 
; Arg 2: 
; Function Attrs: convergent nounwind willreturn memory(none)
declare float @llvm.genx.GenISA.WaveShuffleIndex.f32(float, i32, i32) #6

; Function Desc: 
; Output: 
; Arg 0: 
; Arg 1: 
; Arg 2: 
; Arg 3: 
; Function Attrs: nounwind willreturn memory(none)
declare { i32, i32 } @llvm.genx.GenISA.mul.pair(i32, i32, i32, i32) #5

attributes #0 = { convergent nounwind null_pointer_is_valid }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { convergent nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #4 = { convergent mustprogress nofree nounwind willreturn memory(none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" }
attributes #5 = { nounwind willreturn memory(none) }
attributes #6 = { convergent nounwind willreturn memory(none) }

!spirv.MemoryModel = !{!0}
!spirv.Source = !{!1}
!spirv.Generator = !{!2}
!igc.functions = !{!3, !25}
!IGCMetadata = !{!26}
!opencl.ocl.version = !{!431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431}
!opencl.spir.version = !{!431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431, !431}
!llvm.ident = !{!432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432, !432}
!llvm.module.flags = !{!433}

!0 = !{i32 2, i32 2}
!1 = !{i32 4, i32 100000}
!2 = !{i16 6, i16 14}
!3 = !{ptr @_ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_, !4}
!4 = !{!5, !6, !23, !24}
!5 = !{!"function_type", i32 0}
!6 = !{!"implicit_arg_desc", !7, !8, !9, !10, !11, !12, !13, !14, !16, !18, !20, !21, !22}
!7 = !{i32 0}
!8 = !{i32 2}
!9 = !{i32 7}
!10 = !{i32 8}
!11 = !{i32 9}
!12 = !{i32 10}
!13 = !{i32 13}
!14 = !{i32 15, !15}
!15 = !{!"explicit_arg_num", i32 1}
!16 = !{i32 15, !17}
!17 = !{!"explicit_arg_num", i32 3}
!18 = !{i32 15, !19}
!19 = !{!"explicit_arg_num", i32 4}
!20 = !{i32 54, !15}
!21 = !{i32 54, !17}
!22 = !{i32 54, !19}
!23 = !{!"sub_group_size", i32 32}
!24 = !{!"max_reg_pressure", i32 39}
!25 = !{ptr @_ZTSZZNK3p694HeadILj128EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_, !4}
!26 = !{!"ModuleMD", !27, !28, !137, !260, !291, !309, !330, !340, !342, !343, !358, !359, !360, !361, !365, !366, !373, !374, !375, !376, !377, !378, !379, !380, !381, !382, !383, !385, !389, !390, !391, !392, !393, !394, !395, !396, !397, !398, !399, !400, !401, !402, !205, !403, !408, !409, !411, !413, !416, !417, !418, !420, !421, !422, !427, !428, !429, !430}
!27 = !{!"isPrecise", i1 false}
!28 = !{!"compOpt", !29, !30, !31, !32, !33, !34, !35, !36, !37, !38, !39, !40, !41, !42, !43, !44, !45, !46, !47, !48, !49, !50, !51, !52, !53, !54, !55, !56, !57, !58, !59, !60, !61, !62, !63, !64, !65, !66, !67, !68, !69, !70, !71, !72, !73, !74, !75, !76, !77, !78, !79, !80, !81, !82, !83, !84, !85, !86, !87, !88, !89, !90, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !106, !107, !108, !109, !110, !111, !112, !113, !114, !115, !116, !117, !118, !119, !120, !121, !122, !123, !124, !125, !126, !127, !128, !129, !130, !131, !132, !133, !134, !135, !136}
!29 = !{!"DenormsAreZero", i1 false}
!30 = !{!"BFTFDenormsAreZero", i1 false}
!31 = !{!"CorrectlyRoundedDivSqrt", i1 false}
!32 = !{!"OptDisable", i1 false}
!33 = !{!"MadEnable", i1 false}
!34 = !{!"NoSignedZeros", i1 false}
!35 = !{!"NoNaNs", i1 false}
!36 = !{!"FloatDenormMode16", !"FLOAT_DENORM_RETAIN"}
!37 = !{!"FloatDenormMode32", !"FLOAT_DENORM_RETAIN"}
!38 = !{!"FloatDenormMode64", !"FLOAT_DENORM_RETAIN"}
!39 = !{!"FloatDenormModeBFTF", !"FLOAT_DENORM_RETAIN"}
!40 = !{!"FloatRoundingMode", i32 0}
!41 = !{!"FloatCvtIntRoundingMode", i32 3}
!42 = !{!"LoadCacheDefault", i32 4}
!43 = !{!"StoreCacheDefault", i32 2}
!44 = !{!"VISAPreSchedRPThreshold", i32 0}
!45 = !{!"VISAPreSchedCtrl", i32 0}
!46 = !{!"SetLoopUnrollThreshold", i32 0}
!47 = !{!"UnsafeMathOptimizations", i1 false}
!48 = !{!"disableCustomUnsafeOpts", i1 false}
!49 = !{!"disableReducePow", i1 false}
!50 = !{!"disableSqrtOpt", i1 false}
!51 = !{!"FiniteMathOnly", i1 false}
!52 = !{!"FastRelaxedMath", i1 false}
!53 = !{!"DashGSpecified", i1 false}
!54 = !{!"FastCompilation", i1 false}
!55 = !{!"UseScratchSpacePrivateMemory", i1 true}
!56 = !{!"RelaxedBuiltins", i1 false}
!57 = !{!"SubgroupIndependentForwardProgressRequired", i1 true}
!58 = !{!"GreaterThan2GBBufferRequired", i1 true}
!59 = !{!"GreaterThan4GBBufferRequired", i1 true}
!60 = !{!"DisableA64WA", i1 false}
!61 = !{!"ForceEnableA64WA", i1 false}
!62 = !{!"PushConstantsEnable", i1 true}
!63 = !{!"HasPositivePointerOffset", i1 false}
!64 = !{!"HasBufferOffsetArg", i1 true}
!65 = !{!"BufferOffsetArgOptional", i1 true}
!66 = !{!"replaceGlobalOffsetsByZero", i1 false}
!67 = !{!"forcePixelShaderSIMDMode", i32 0}
!68 = !{!"forceTotalGRFNum", i32 0}
!69 = !{!"ForceGeomFFShaderSIMDMode", i32 0}
!70 = !{!"pixelShaderDoNotAbortOnSpill", i1 false}
!71 = !{!"UniformWGS", i1 false}
!72 = !{!"disableVertexComponentPacking", i1 false}
!73 = !{!"disablePartialVertexComponentPacking", i1 false}
!74 = !{!"PreferBindlessImages", i1 true}
!75 = !{!"UseBindlessMode", i1 true}
!76 = !{!"UseLegacyBindlessMode", i1 false}
!77 = !{!"disableMathRefactoring", i1 false}
!78 = !{!"atomicBranch", i1 false}
!79 = !{!"spillCompression", i1 false}
!80 = !{!"AllowLICM", i1 true}
!81 = !{!"DisableEarlyOut", i1 false}
!82 = !{!"ForceInt32DivRemEmu", i1 false}
!83 = !{!"ForceInt32DivRemEmuSP", i1 false}
!84 = !{!"DisableIntDivRemIncrementReduction", i1 false}
!85 = !{!"DisableFastestSingleCSSIMD", i1 false}
!86 = !{!"DisableFastestLinearScan", i1 false}
!87 = !{!"UseStatelessforPrivateMemory", i1 false}
!88 = !{!"EnableTakeGlobalAddress", i1 false}
!89 = !{!"IsLibraryCompilation", i1 false}
!90 = !{!"LibraryCompileSIMDSize", i32 0}
!91 = !{!"FastVISACompile", i1 false}
!92 = !{!"MatchSinCosPi", i1 false}
!93 = !{!"ExcludeIRFromZEBinary", i1 false}
!94 = !{!"EmitZeBinVISASections", i1 false}
!95 = !{!"FP64GenEmulationEnabled", i1 false}
!96 = !{!"FP64GenConvEmulationEnabled", i1 false}
!97 = !{!"allowDisableRematforCS", i1 false}
!98 = !{!"DisableIncSpillCostAllAddrTaken", i1 false}
!99 = !{!"DisableCPSOmaskWA", i1 false}
!100 = !{!"DisableFastestGopt", i1 false}
!101 = !{!"WaForceHalfPromotionComputeShader", i1 false}
!102 = !{!"WaForceHalfPromotionPixelVertexShader", i1 false}
!103 = !{!"DisableConstantCoalescing", i1 false}
!104 = !{!"EnableUndefAlphaOutputAsRed", i1 true}
!105 = !{!"WaEnableALTModeVisaWA", i1 false}
!106 = !{!"EnableLdStCombineforLoad", i1 false}
!107 = !{!"EnableLdStCombinewithDummyLoad", i1 false}
!108 = !{!"ForceUniformBuffer", i1 false}
!109 = !{!"ForceUniformSurfaceSampler", i1 false}
!110 = !{!"EnableIndependentSharedMemoryFenceFunctionality", i1 false}
!111 = !{!"NewSpillCostFunction", i1 false}
!112 = !{!"EnableVRT", i1 true}
!113 = !{!"ForceLargeGRFNum4RQ", i1 false}
!114 = !{!"DisableEUFusion", i1 false}
!115 = !{!"DisableFDivToFMulInvOpt", i1 false}
!116 = !{!"initializePhiSampleSourceWA", i1 false}
!117 = !{!"WaDisableSubspanUseNoMaskForCB", i1 false}
!118 = !{!"DisableLoosenSimd32Occu", i1 false}
!119 = !{!"FastestS1Options", i32 0}
!120 = !{!"DisableFastestForWaveIntrinsicsCS", i1 false}
!121 = !{!"ForceLinearWalkOnLinearUAV", i1 false}
!122 = !{!"LscSamplerRouting", i32 0}
!123 = !{!"UseBarrierControlFlowOptimization", i1 false}
!124 = !{!"EnableDynamicRQManagement", i1 false}
!125 = !{!"WaDisablePayloadCoalescing", i1 false}
!126 = !{!"Quad8InputThreshold", i32 0}
!127 = !{!"UseResourceLoopUnrollNested", i1 false}
!128 = !{!"DisableLoopUnroll", i1 false}
!129 = !{!"ForcePushConstantMode", i32 0}
!130 = !{!"UseInstructionHoistingOptimization", i1 false}
!131 = !{!"DisableResourceLoopDestLifeTimeStart", i1 false}
!132 = !{!"ForceVRTGRFCeiling", i32 0}
!133 = !{!"DisableSamplerBackingByLSC", i32 0}
!134 = !{!"UseLinearScanRA", i1 false}
!135 = !{!"DisableConvertingAtomicIAddToIncDec", i1 false}
!136 = !{!"ZeroInitRegistersBeforeExecution", i1 false}
!137 = !{!"FuncMD", !138, !139, !258, !259}
!138 = !{!"FuncMDMap[0]", ptr @_ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_}
!139 = !{!"FuncMDValue[0]", !140, !141, !145, !146, !147, !170, !197, !198, !199, !200, !201, !202, !203, !204, !205, !206, !207, !208, !209, !210, !211, !212, !213, !214, !215, !216, !217, !223, !229, !235, !241, !247, !253, !254}
!140 = !{!"localOffsets"}
!141 = !{!"workGroupWalkOrder", !142, !143, !144}
!142 = !{!"dim0", i32 0}
!143 = !{!"dim1", i32 1}
!144 = !{!"dim2", i32 2}
!145 = !{!"funcArgs"}
!146 = !{!"functionType", !"KernelFunction"}
!147 = !{!"rtInfo", !148, !149, !150, !151, !152, !153, !154, !155, !156, !157, !158, !159, !160, !161, !162, !163, !165, !166, !167, !168, !169}
!148 = !{!"callableShaderType", !"NumberOfCallableShaderTypes"}
!149 = !{!"isContinuation", i1 false}
!150 = !{!"hasTraceRayPayload", i1 false}
!151 = !{!"hasHitAttributes", i1 false}
!152 = !{!"hasCallableData", i1 false}
!153 = !{!"ShaderStackSize", i32 0}
!154 = !{!"ShaderHash", i64 0}
!155 = !{!"ShaderName", !""}
!156 = !{!"ParentName", !""}
!157 = !{!"SlotNum", ptr null}
!158 = !{!"NOSSize", i32 0}
!159 = !{!"globalRootSignatureSize", i32 0}
!160 = !{!"Entries"}
!161 = !{!"SpillUnions"}
!162 = !{!"CustomHitAttrSizeInBytes", i32 0}
!163 = !{!"Types", !164}
!164 = !{!"FullFrameTys"}
!165 = !{!"Aliases"}
!166 = !{!"numSyncRTStacks", i32 0}
!167 = !{!"NumCoherenceHintBits", i32 0}
!168 = !{!"useSyncHWStack", i1 false}
!169 = !{!"OriginatingShaderName", !""}
!170 = !{!"resAllocMD", !171, !172, !173, !174, !196}
!171 = !{!"uavsNumType", i32 0}
!172 = !{!"srvsNumType", i32 0}
!173 = !{!"samplersNumType", i32 0}
!174 = !{!"argAllocMDList", !175, !179, !180, !181, !182, !183, !184, !185, !186, !187, !188, !189, !190, !191, !192, !193, !194, !195}
!175 = !{!"argAllocMDListVec[0]", !176, !177, !178}
!176 = !{!"type", i32 0}
!177 = !{!"extensionType", i32 -1}
!178 = !{!"indexType", i32 -1}
!179 = !{!"argAllocMDListVec[1]", !176, !177, !178}
!180 = !{!"argAllocMDListVec[2]", !176, !177, !178}
!181 = !{!"argAllocMDListVec[3]", !176, !177, !178}
!182 = !{!"argAllocMDListVec[4]", !176, !177, !178}
!183 = !{!"argAllocMDListVec[5]", !176, !177, !178}
!184 = !{!"argAllocMDListVec[6]", !176, !177, !178}
!185 = !{!"argAllocMDListVec[7]", !176, !177, !178}
!186 = !{!"argAllocMDListVec[8]", !176, !177, !178}
!187 = !{!"argAllocMDListVec[9]", !176, !177, !178}
!188 = !{!"argAllocMDListVec[10]", !176, !177, !178}
!189 = !{!"argAllocMDListVec[11]", !176, !177, !178}
!190 = !{!"argAllocMDListVec[12]", !176, !177, !178}
!191 = !{!"argAllocMDListVec[13]", !176, !177, !178}
!192 = !{!"argAllocMDListVec[14]", !176, !177, !178}
!193 = !{!"argAllocMDListVec[15]", !176, !177, !178}
!194 = !{!"argAllocMDListVec[16]", !176, !177, !178}
!195 = !{!"argAllocMDListVec[17]", !176, !177, !178}
!196 = !{!"inlineSamplersMD"}
!197 = !{!"maxByteOffsets"}
!198 = !{!"IsInitializer", i1 false}
!199 = !{!"IsFinalizer", i1 false}
!200 = !{!"CompiledSubGroupsNumber", i32 0}
!201 = !{!"hasInlineVmeSamplers", i1 false}
!202 = !{!"localSize", i32 0}
!203 = !{!"localIDPresent", i1 false}
!204 = !{!"groupIDPresent", i1 false}
!205 = !{!"privateMemoryPerWI", i32 0}
!206 = !{!"prevFPOffset", i32 0}
!207 = !{!"globalIDPresent", i1 false}
!208 = !{!"hasSyncRTCalls", i1 false}
!209 = !{!"hasPrintfCalls", i1 false}
!210 = !{!"requireAssertBuffer", i1 false}
!211 = !{!"requireSyncBuffer", i1 false}
!212 = !{!"hasIndirectCalls", i1 false}
!213 = !{!"hasNonKernelArgLoad", i1 false}
!214 = !{!"hasNonKernelArgStore", i1 false}
!215 = !{!"hasNonKernelArgAtomic", i1 false}
!216 = !{!"UserAnnotations"}
!217 = !{!"m_OpenCLArgAddressSpaces", !218, !219, !220, !221, !222}
!218 = !{!"m_OpenCLArgAddressSpacesVec[0]", i32 0}
!219 = !{!"m_OpenCLArgAddressSpacesVec[1]", i32 1}
!220 = !{!"m_OpenCLArgAddressSpacesVec[2]", i32 0}
!221 = !{!"m_OpenCLArgAddressSpacesVec[3]", i32 1}
!222 = !{!"m_OpenCLArgAddressSpacesVec[4]", i32 1}
!223 = !{!"m_OpenCLArgAccessQualifiers", !224, !225, !226, !227, !228}
!224 = !{!"m_OpenCLArgAccessQualifiersVec[0]", !"none"}
!225 = !{!"m_OpenCLArgAccessQualifiersVec[1]", !"none"}
!226 = !{!"m_OpenCLArgAccessQualifiersVec[2]", !"none"}
!227 = !{!"m_OpenCLArgAccessQualifiersVec[3]", !"none"}
!228 = !{!"m_OpenCLArgAccessQualifiersVec[4]", !"none"}
!229 = !{!"m_OpenCLArgTypes", !230, !231, !232, !233, !234}
!230 = !{!"m_OpenCLArgTypesVec[0]", !"int"}
!231 = !{!"m_OpenCLArgTypesVec[1]", !"char*"}
!232 = !{!"m_OpenCLArgTypesVec[2]", !"long"}
!233 = !{!"m_OpenCLArgTypesVec[3]", !"short*"}
!234 = !{!"m_OpenCLArgTypesVec[4]", !"short*"}
!235 = !{!"m_OpenCLArgBaseTypes", !236, !237, !238, !239, !240}
!236 = !{!"m_OpenCLArgBaseTypesVec[0]", !"int"}
!237 = !{!"m_OpenCLArgBaseTypesVec[1]", !"char*"}
!238 = !{!"m_OpenCLArgBaseTypesVec[2]", !"long"}
!239 = !{!"m_OpenCLArgBaseTypesVec[3]", !"short*"}
!240 = !{!"m_OpenCLArgBaseTypesVec[4]", !"short*"}
!241 = !{!"m_OpenCLArgTypeQualifiers", !242, !243, !244, !245, !246}
!242 = !{!"m_OpenCLArgTypeQualifiersVec[0]", !""}
!243 = !{!"m_OpenCLArgTypeQualifiersVec[1]", !""}
!244 = !{!"m_OpenCLArgTypeQualifiersVec[2]", !""}
!245 = !{!"m_OpenCLArgTypeQualifiersVec[3]", !""}
!246 = !{!"m_OpenCLArgTypeQualifiersVec[4]", !""}
!247 = !{!"m_OpenCLArgNames", !248, !249, !250, !251, !252}
!248 = !{!"m_OpenCLArgNamesVec[0]", !""}
!249 = !{!"m_OpenCLArgNamesVec[1]", !""}
!250 = !{!"m_OpenCLArgNamesVec[2]", !""}
!251 = !{!"m_OpenCLArgNamesVec[3]", !""}
!252 = !{!"m_OpenCLArgNamesVec[4]", !""}
!253 = !{!"m_OpenCLArgScalarAsPointers"}
!254 = !{!"m_OptsToDisablePerFunc", !255, !256, !257}
!255 = !{!"m_OptsToDisablePerFuncSet[0]", !"IGC-AddressArithmeticSinking"}
!256 = !{!"m_OptsToDisablePerFuncSet[1]", !"IGC-AllowSimd32Slicing"}
!257 = !{!"m_OptsToDisablePerFuncSet[2]", !"IGC-SinkLoadOpt"}
!258 = !{!"FuncMDMap[1]", ptr @_ZTSZZNK3p694HeadILj128EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_}
!259 = !{!"FuncMDValue[1]", !140, !141, !145, !146, !147, !170, !197, !198, !199, !200, !201, !202, !203, !204, !205, !206, !207, !208, !209, !210, !211, !212, !213, !214, !215, !216, !217, !223, !229, !235, !241, !247, !253, !254}
!260 = !{!"pushInfo", !261, !262, !263, !267, !268, !269, !270, !271, !272, !273, !274, !287, !288, !289, !290}
!261 = !{!"pushableAddresses"}
!262 = !{!"bindlessPushInfo"}
!263 = !{!"dynamicBufferInfo", !264, !265, !266}
!264 = !{!"firstIndex", i32 0}
!265 = !{!"numOffsets", i32 0}
!266 = !{!"forceDisabled", i1 false}
!267 = !{!"MaxNumberOfPushedBuffers", i32 0}
!268 = !{!"inlineConstantBufferSlot", i32 -1}
!269 = !{!"inlineConstantBufferOffset", i32 -1}
!270 = !{!"inlineConstantBufferGRFOffset", i32 -1}
!271 = !{!"constants"}
!272 = !{!"inputs"}
!273 = !{!"constantReg"}
!274 = !{!"simplePushInfoArr", !275, !284, !285, !286}
!275 = !{!"simplePushInfoArrVec[0]", !276, !277, !278, !279, !280, !281, !282, !283}
!276 = !{!"cbIdx", i32 0}
!277 = !{!"pushableAddressGrfOffset", i32 -1}
!278 = !{!"pushableOffsetGrfOffset", i32 -1}
!279 = !{!"offset", i32 0}
!280 = !{!"size", i32 0}
!281 = !{!"isStateless", i1 false}
!282 = !{!"isBindless", i1 false}
!283 = !{!"simplePushLoads"}
!284 = !{!"simplePushInfoArrVec[1]", !276, !277, !278, !279, !280, !281, !282, !283}
!285 = !{!"simplePushInfoArrVec[2]", !276, !277, !278, !279, !280, !281, !282, !283}
!286 = !{!"simplePushInfoArrVec[3]", !276, !277, !278, !279, !280, !281, !282, !283}
!287 = !{!"simplePushBufferUsed", i32 0}
!288 = !{!"pushAnalysisWIInfos"}
!289 = !{!"inlineRTGlobalPtrOffset", i32 0}
!290 = !{!"rtSyncSurfPtrOffset", i32 0}
!291 = !{!"psInfo", !292, !293, !294, !295, !296, !297, !298, !299, !300, !301, !302, !303, !304, !305, !306, !307, !308}
!292 = !{!"BlendStateDisabledMask", i8 0}
!293 = !{!"SkipSrc0Alpha", i1 false}
!294 = !{!"DualSourceBlendingDisabled", i1 false}
!295 = !{!"ForceEnableSimd32", i1 false}
!296 = !{!"DisableSimd32WithDiscard", i1 false}
!297 = !{!"outputDepth", i1 false}
!298 = !{!"outputStencil", i1 false}
!299 = !{!"outputMask", i1 false}
!300 = !{!"blendToFillEnabled", i1 false}
!301 = !{!"forceEarlyZ", i1 false}
!302 = !{!"hasVersionedLoop", i1 false}
!303 = !{!"forceSingleSourceRTWAfterDualSourceRTW", i1 false}
!304 = !{!"NumSamples", i8 0}
!305 = !{!"blendOptimizationMode"}
!306 = !{!"colorOutputMask"}
!307 = !{!"isBlendEnabled"}
!308 = !{!"WaDisableVRS", i1 false}
!309 = !{!"csInfo", !310, !311, !312, !313, !68, !44, !45, !314, !46, !315, !316, !317, !318, !319, !320, !321, !322, !323, !324, !325, !79, !326, !327, !328, !329}
!310 = !{!"maxWorkGroupSize", i32 0}
!311 = !{!"waveSize", i32 0}
!312 = !{!"ComputeShaderSecondCompile"}
!313 = !{!"forcedSIMDSize", i8 0}
!314 = !{!"VISAPreSchedScheduleExtraGRF", i32 0}
!315 = !{!"forceSpillCompression", i1 false}
!316 = !{!"allowLowerSimd", i1 false}
!317 = !{!"disableSimd32Slicing", i1 false}
!318 = !{!"disableSplitOnSpill", i1 false}
!319 = !{!"enableNewSpillCostFunction", i1 false}
!320 = !{!"forceVISAPreSched", i1 false}
!321 = !{!"disableLocalIdOrderOptimizations", i1 false}
!322 = !{!"disableDispatchAlongY", i1 false}
!323 = !{!"neededThreadIdLayout", ptr null}
!324 = !{!"forceTileYWalk", i1 false}
!325 = !{!"atomicBranch", i32 0}
!326 = !{!"disableEarlyOut", i1 false}
!327 = !{!"walkOrderEnabled", i1 false}
!328 = !{!"walkOrderOverride", i32 0}
!329 = !{!"ResForHfPacking"}
!330 = !{!"msInfo", !331, !332, !333, !334, !335, !336, !337, !338, !339}
!331 = !{!"PrimitiveTopology", i32 3}
!332 = !{!"MaxNumOfPrimitives", i32 0}
!333 = !{!"MaxNumOfVertices", i32 0}
!334 = !{!"MaxNumOfPerPrimitiveOutputs", i32 0}
!335 = !{!"MaxNumOfPerVertexOutputs", i32 0}
!336 = !{!"WorkGroupSize", i32 0}
!337 = !{!"WorkGroupMemorySizeInBytes", i32 0}
!338 = !{!"IndexFormat", i32 6}
!339 = !{!"SubgroupSize", i32 0}
!340 = !{!"taskInfo", !341, !336, !337, !339}
!341 = !{!"MaxNumOfOutputs", i32 0}
!342 = !{!"NBarrierCnt", i32 0}
!343 = !{!"rtInfo", !344, !345, !346, !347, !348, !349, !350, !351, !352, !353, !354, !355, !356, !357, !166}
!344 = !{!"RayQueryAllocSizeInBytes", i32 0}
!345 = !{!"NumContinuations", i32 0}
!346 = !{!"RTAsyncStackAddrspace", i32 -1}
!347 = !{!"RTAsyncStackSurfaceStateOffset", ptr null}
!348 = !{!"SWHotZoneAddrspace", i32 -1}
!349 = !{!"SWHotZoneSurfaceStateOffset", ptr null}
!350 = !{!"SWStackAddrspace", i32 -1}
!351 = !{!"SWStackSurfaceStateOffset", ptr null}
!352 = !{!"RTSyncStackAddrspace", i32 -1}
!353 = !{!"RTSyncStackSurfaceStateOffset", ptr null}
!354 = !{!"doSyncDispatchRays", i1 false}
!355 = !{!"MemStyle", !"Xe"}
!356 = !{!"GlobalDataStyle", !"Xe"}
!357 = !{!"uberTileDimensions", ptr null}
!358 = !{!"CurUniqueIndirectIdx", i32 0}
!359 = !{!"inlineDynTextures"}
!360 = !{!"inlineResInfoData"}
!361 = !{!"immConstant", !362, !363, !364}
!362 = !{!"data"}
!363 = !{!"sizes"}
!364 = !{!"zeroIdxs"}
!365 = !{!"stringConstants"}
!366 = !{!"inlineBuffers", !367, !371, !372}
!367 = !{!"inlineBuffersVec[0]", !368, !369, !370}
!368 = !{!"alignment", i32 0}
!369 = !{!"allocSize", i64 0}
!370 = !{!"Buffer"}
!371 = !{!"inlineBuffersVec[1]", !368, !369, !370}
!372 = !{!"inlineBuffersVec[2]", !368, !369, !370}
!373 = !{!"GlobalPointerProgramBinaryInfos"}
!374 = !{!"ConstantPointerProgramBinaryInfos"}
!375 = !{!"GlobalBufferAddressRelocInfo"}
!376 = !{!"ConstantBufferAddressRelocInfo"}
!377 = !{!"forceLscCacheList"}
!378 = !{!"SrvMap"}
!379 = !{!"RasterizerOrderedByteAddressBuffer"}
!380 = !{!"RasterizerOrderedViews"}
!381 = !{!"MinNOSPushConstantSize", i32 0}
!382 = !{!"inlineProgramScopeOffsets"}
!383 = !{!"shaderData", !384}
!384 = !{!"numReplicas", i32 0}
!385 = !{!"URBInfo", !386, !387, !388}
!386 = !{!"has64BVertexHeaderInput", i1 false}
!387 = !{!"has64BVertexHeaderOutput", i1 false}
!388 = !{!"hasVertexHeader", i1 true}
!389 = !{!"UseBindlessImage", i1 true}
!390 = !{!"HasBindlessImageRead", i1 false}
!391 = !{!"enableRangeReduce", i1 false}
!392 = !{!"allowMatchMadOptimizationforVS", i1 false}
!393 = !{!"disableMatchMadOptimizationForCS", i1 false}
!394 = !{!"disableMemOptforNegativeOffsetLoads", i1 false}
!395 = !{!"enableThreeWayLoadSpiltOpt", i1 false}
!396 = !{!"statefulResourcesNotAliased", i1 false}
!397 = !{!"disableMixMode", i1 false}
!398 = !{!"genericAccessesResolved", i1 false}
!399 = !{!"disableSeparateSpillPvtScratchSpace", i1 false}
!400 = !{!"enableSeparateSpillPvtScratchSpace", i1 false}
!401 = !{!"disableSeparateScratchWA", i1 false}
!402 = !{!"enableRemoveUnusedTGMFence", i1 false}
!403 = !{!"PrivateMemoryPerFG", !404, !405, !406, !407}
!404 = !{!"PrivateMemoryPerFGMap[0]", ptr @_ZTSZZNK3p694HeadILj64EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_}
!405 = !{!"PrivateMemoryPerFGValue[0]", i32 0}
!406 = !{!"PrivateMemoryPerFGMap[1]", ptr @_ZTSZZNK3p694HeadILj128EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_}
!407 = !{!"PrivateMemoryPerFGValue[1]", i32 0}
!408 = !{!"m_OptsToDisable"}
!409 = !{!"capabilities", !410}
!410 = !{!"globalVariableDecorationsINTEL", i1 false}
!411 = !{!"extensions", !412}
!412 = !{!"spvINTELBindlessImages", i1 false}
!413 = !{!"m_ShaderResourceViewMcsMask", !414, !415}
!414 = !{!"m_ShaderResourceViewMcsMaskVec[0]", i64 0}
!415 = !{!"m_ShaderResourceViewMcsMaskVec[1]", i64 0}
!416 = !{!"computedDepthMode", i32 0}
!417 = !{!"isHDCFastClearShader", i1 false}
!418 = !{!"argRegisterReservations", !419}
!419 = !{!"argRegisterReservationsVec[0]", i32 0}
!420 = !{!"SIMD16_SpillThreshold", i8 0}
!421 = !{!"SIMD32_SpillThreshold", i8 0}
!422 = !{!"m_CacheControlOption", !423, !424, !425, !426}
!423 = !{!"LscLoadCacheControlOverride", i8 0}
!424 = !{!"LscStoreCacheControlOverride", i8 0}
!425 = !{!"TgmLoadCacheControlOverride", i8 0}
!426 = !{!"TgmStoreCacheControlOverride", i8 0}
!427 = !{!"ModuleUsesBindless", i1 false}
!428 = !{!"predicationMap"}
!429 = !{!"lifeTimeStartMap"}
!430 = !{!"HitGroups"}
!431 = !{i32 2, i32 0}
!432 = !{!"clang version 16.0.6"}
!433 = !{i32 1, !"wchar_size", i32 4}
!434 = !{!"320"}
!435 = !{!"-5"}
!436 = !{!"160"}
!437 = !{!438}
!438 = !{i32 4470}
!439 = !{!"5120"}
!440 = !{!441, !438}
!441 = !{i32 4469}
!442 = !{!"4960"}
!443 = !{!"80"}
