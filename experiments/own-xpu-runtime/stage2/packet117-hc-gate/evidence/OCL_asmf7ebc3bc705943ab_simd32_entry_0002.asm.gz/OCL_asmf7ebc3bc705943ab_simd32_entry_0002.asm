//.kernel _ZTSZZNK4p49c11RouteKernelILj0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_2idILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 4159423420 1884898219 -hashmovs1 0 2 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortonspill -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 4159423420 1884898219 -hashmovs1 0 2 -GRFBumpUpNumber 2 "
//.instCount 133
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 3
//.spill flag load 3

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r4.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r0.12)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r0.13)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r0.8)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r0.9)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r0.10)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r0.11)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r4.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r4.0)
//.declare V0036 (46)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.3)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0050 (60)  rf=r size=4 type=d align=2 words (r3.14)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r3.15)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r4.1)
//.declare V0054 (64)  rf=r size=4 type=d align=2 words (r4.2)
//.declare V0055 (65)  rf=r size=4 type=d align=2 words (r4.3)
//.declare V0056 (66)  rf=r size=4 type=d align=2 words (r4.4)
//.declare V0057 (67)  rf=r size=4 type=d align=2 words (r4.5)
//.declare V0058 (68)  rf=r size=4 type=d align=2 words (r4.6)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r4.7)
//.declare V0060 (70)  rf=r size=8 type=uq alias=V0049+0 align=4 words (r3.6)
//.declare V0061 (71)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0062 (72)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P01 (73)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0063 (74)  rf=r size=8 type=uq alias=V0048+0 align=4 words (r3.5)
//.declare V0064 (75)  rf=r size=8 type=uq align=32 words (r8.0)
//.declare V0066 (77)  rf=r size=256 type=uq align=32 words (r9.0)
//.declare V0067 (78)  rf=r size=256 type=ud alias=V0066+0 align=32 words (r9.0)
//.declare V0068 (79)  rf=r size=8 type=ud alias=V0064+0 align=32 words (r8.0)
//.declare V0069 (80)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0070 (81)  rf=r size=128 type=ud align=32 words (r15.0)
//.declare P02 (83)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0072 (84)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0074 (86)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0075 (87)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0076 (88)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0077 (89)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0078 (90)  rf=r size=128 type=d align=32 words (r23.0)
//.declare V0079 (91)  rf=r size=128 type=ud alias=V0077+0 align=32 words (r21.0)
//.declare V0080 (92)  rf=r size=128 type=ud alias=V0078+0 align=32 words (r23.0)
//.declare P03 (93)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0081 (94)  rf=r size=128 type=ud alias=V0076+0 align=32 words (r19.0)
//.declare V0082 (95)  rf=r size=128 type=f align=32 words (r25.0)
//.declare P04 (96)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P05 (97)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare P06 (98)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0083 (99)  rf=r size=4 type=ud alias=V0050+0 align=2 words (r3.14)
//.declare P07 (100)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P08 (101)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare P09 (102)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0085 (104)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0089 (108)  rf=r size=256 type=uq align=32 words (r29.0)
//.declare V0090 (109)  rf=r size=256 type=q align=32 words (r33.0)
//.declare V0094 (113)  rf=r size=256 type=uq align=32 words (r37.0)
//.declare V0095 (114)  rf=r size=128 type=d align=32 words (r41.0)
//.declare V0096 (115)  rf=r size=128 type=ud alias=V0095+0 align=32 words (r41.0)
//.declare V0100 (119)  rf=r size=256 type=uq align=32 words (r43.0)
//.declare V0101 (120)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0105 (124)  rf=r size=256 type=uq align=32 words (r49.0)
//.declare V0107 (126)  rf=r size=128 type=ud align=32 words (r54.0)
//.declare V0108 (127)  rf=r size=128 type=w alias=V0107+0 align=32 words (r54.0)
//.declare V0110 (129)  rf=r size=128 type=d alias=V0085+0 align=32 words (r27.0)
//.declare V0114 (133)  rf=r size=256 type=uq align=32 words (r56.0)
//.declare V0115 (134)  rf=r size=128 type=d align=32 words (r60.0)
//.declare P10 (135)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0116 (136)  rf=r size=128 type=f alias=V0115+0 align=32 words (r60.0)
//.declare P11 (137)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0118 (139)  rf=r size=256 type=uq align=32 words (r62.0)
//.declare V0119 (140)  rf=r size=256 type=ud alias=V0118+0 align=32 words (r62.0)
//.declare V0120 (141)  rf=r size=128 type=d align=32 words (r66.0)
//.declare P12 (142)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P13 (143)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0122 (145)  rf=r size=128 type=ud alias=V0075+0 align=32 words (r17.0)
//.declare V0126 (149)  rf=r size=256 type=uq align=32 words (r68.0)
//.declare  (150)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (151)  rf=r size=128 type=ud align=32 words (r72.0)
//.declare  (152)  rf=r size=128 type=ud align=32 words (r74.0)
//.declare  (153)  rf=r size=128 type=f align=32 words (r76.0)
//.declare  (154)  rf=r size=128 type=f align=32 words (r78.0)
//.declare  (155)  rf=r size=128 type=ud align=32 words (r80.0)
//.declare  (156)  rf=r size=128 type=ud align=32 words (r82.0)
//.declare  (157)  rf=r size=128 type=q align=32 words (r84.0)
//.declare  (158)  rf=r size=128 type=q align=32 words (r86.0)
//.declare  (159)  rf=r size=128 type=q align=32 words (r88.0)
//.declare  (160)  rf=r size=128 type=q align=32 words (r90.0)
//.declare  (163)  rf=r size=128 type=q align=32 words (r92.0)
//.declare  (164)  rf=r size=128 type=q align=32 words (r94.0)
//.declare  (167)  rf=r size=128 type=q align=32 words (r96.0)
//.declare  (168)  rf=r size=128 type=q align=32 words (r98.0)
//.declare  (171)  rf=r size=128 type=q align=32 words (r100.0)
//.declare  (172)  rf=r size=128 type=q align=32 words (r102.0)
//.declare  (175)  rf=r size=128 type=q align=32 words (r104.0)
//.declare  (176)  rf=r size=128 type=q align=32 words (r106.0)
//.declare  (181)  rf=r size=128 type=q align=32 words (r108.0)
//.declare  (182)  rf=r size=128 type=q align=32 words (r110.0)
//.declare  (185)  rf=r size=4 type=uw align=2 words (r2.16)
//.declare  (186)  rf=r size=4 type=uw align=2 words (r2.18)
//.declare  (187)  rf=r size=4 type=uw align=2 words (r2.20)
//.declare  (188)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (189)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (190)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (191)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (192)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (193)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare r0 (194)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (195)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (196)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (197)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (198)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (199)  rf=r size=64 type=ud align=32 words (r3.0)
//.declare  (200)  rf=r size=32 type=ud align=2 words (r4.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0036    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0037    | :d x 3   |    0xC | r2+0xC   | inline+0xC       |
// | V0042    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0043    | :q       |    0x8 | r3       | cti+0x20         |
// | V0044    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0045    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0046    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0047    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0048    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0049    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0050    | :d       |    0x4 | r3+0x38  | cti+0x58         |
// | V0051    | :d       |    0x4 | r3+0x3C  | cti+0x5C         |
// | V0052    | :d       |    0x4 | r4       | cti+0x60         |
// | V0053    | :d       |    0x4 | r4+0x4   | cti+0x64         |
// | V0054    | :d       |    0x4 | r4+0x8   | cti+0x68         |
// | V0055    | :d       |    0x4 | r4+0xC   | cti+0x6C         |
// | V0056    | :d       |    0x4 | r4+0x10  | cti+0x70         |
// | V0057    | :d       |    0x4 | r4+0x14  | cti+0x74         |
// | V0058    | :d       |    0x4 | r4+0x18  | cti+0x78         |
// | V0059    | :d       |    0x4 | r4+0x1C  | cti+0x7C         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x60:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r3:1 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6219D500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r4:1  bti[255][r127:1+0x40]  {$2} // ex_desc:0xFF040000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B024}
// _main:
(W)     mov (16|M0)              r4.0<1>:ud    r0.0<1;1,0>:ud                   {Compacted,$2.dst}   //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mov (1|M0)               r6.0<1>:uq    r3.6<0;1,0>:uq                   {Compacted,A@1,$1.dst} //  ALU pipe: int; $2
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r6:1]             {I@1,$3} // ex_desc:0x0; desc:0x2108580 // $3
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $4
(W&f1.0) jmpi                                _0_028                                                  //  ALU pipe: int; $5
// B003: Preds:{B002},  Succs:{B004, B024}
_0_029:
(W)     mov (1|M0)               r8.0<1>:uq    r3.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $7
        mov (32|M0)              r13.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $10
        mov (16|M0)              r9.0<2>:f     r8.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $8
        mov (16|M16)             r11.0<2>:f    r8.0<0;1,0>:f                                         //  ALU pipe: float; $8
        mov (16|M0)              r9.1<2>:f     r8.1<0;1,0>:f                                         //  ALU pipe: float; $9
        mov (16|M16)             r11.1<2>:ud   r8.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $9
        atomic_or.ugm.d32.a64 (32|M0)  r15:2    [r9:4]            r13:2              {A@1,$4} // ex_desc:0x0; desc:0x8200599 // $11
        cmp (32|M0)   (eq)f0.0   null<1>:d     r15.0<1;1,0>:d    0:w               {$4.dst}          //  ALU pipe: int; $13
(~f0.0) goto (32|M0)                         _0_028            _0_028                                //  ALU pipe: int; $14
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B006}
_0_030:
(W)     mul (1|M0)               acc0.0<1>:d   r2.3<0;1,0>:d     r4.2<0;1,0>:uw                      //  ALU pipe: int; $16
(W)     macl (1|M0)              r5.0<1>:d     r2.3<0;1,0>:d     r4.1<0;1,0>:d    {Compacted}        //  ALU pipe: int; $18
        add3 (32|M0)             r17.0<1>:d    r5.0<0;0>:d       r1.0<1;0>:uw      r2.0<0>:d        {@1,$0.dst} //  ALU pipe: int; $18
        shl (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    4:w               {Compacted,I@1}   //  ALU pipe: int; $19
        add (32|M0)              r21.0<1>:d    r19.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $20
        sel (32|M0)   (lt)f0.0   r23.0<1>:ud   r21.0<1;1,0>:ud   0x200:uw              {I@1}         //  ALU pipe: int; $21
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r19.0<1;1,0>:ud   r23.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $22
(f3.0)  goto (32|M0)                         _0_031            _0_031                                //  ALU pipe: int; $23
// B005: [inDivergent],  Preds:{B004},  Succs:{B023}
_0_032:
        mov (32|M0)              r25.0<1>:ud   0xFF800000:ud                                         //  ALU pipe: int; $25
        goto (32|M0)                         _0_031            _0_033                                // $26
// B006: [inDivergent],  Preds:{B004},  Succs:{B007}
_0_031:
        join (32|M0)                         _0_033                                                  // 
L552:
(W)     cmp (32|M0)   (lt)f2.0   null<1>:d     r3.14<0;1,0>:d    2:w                                 //  ALU pipe: int; $28
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r3.14<0;1,0>:d    2:w                                 //  ALU pipe: int; $29
(W)     cmp (32|M0)   (lt)f0.0   null<1>:ud    r3.14<0;1,0>:ud   0x4:uw                              //  ALU pipe: int; $30
        mov (32|M0)              r25.0<1>:f    0xFF800000:f                               {Compacted,I@6} //  ALU pipe: float; $34
(W)     mov (1|M0)               r2.10<1>:ud   f2.0<0;1,0>:ud                                        //  ALU pipe: int; $28
(W)     mov (1|M0)               r2.9<1>:ud    f1.0<0;1,0>:ud                                        //  ALU pipe: int; $29
(W)     mov (1|M0)               r2.8<1>:ud    f0.0<0;1,0>:ud                                        //  ALU pipe: int; $30
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r3.14<0;1,0>:d    4:w                                 //  ALU pipe: int; $31
(W)     cmp (32|M0)   (lt)f1.0   null<1>:d     r3.14<0;1,0>:d    1:w                                 //  ALU pipe: int; $32
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r3.14<0;1,0>:d    0:w                                 //  ALU pipe: int; $33
// B007: [inDivergent],  Preds:{B022, B006},  Succs:{B008, B015}
_0_034:
(W)     mov (1|M0)               f3.0<1>:ud    r2.10<0;1,0>:ud                  {Compacted,I@6}      //  ALU pipe: int; $37
        mov (16|M0)              r72.0<2>:ud   r19.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $36
        mov (16|M16)             r74.0<2>:ud   r20.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $36
        mov (16|M0)              r84.0<1>:q    r72.0<2;1,0>:ud                  {I@2}                //  ALU pipe: int; $36
        mov (16|M16)             r86.0<1>:q    r74.0<2;1,0>:ud                  {I@2}                //  ALU pipe: int; $36
(W&f3.0) jmpi                                _0_035                                                  //  ALU pipe: int; $37
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B014}
_0_036:
(W)     mov (1|M0)               f3.0<1>:ud    r2.9<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $39
(W&f3.0) jmpi                                _0_037                                                  //  ALU pipe: int; $39
// B009: [inDivergent],  Preds:{B008},  Succs:{B010, B013}
_0_038:
(W)     mov (1|M0)               f3.0<1>:ud    r2.8<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $41
(W&f3.0) jmpi                                _0_039                                                  //  ALU pipe: int; $41
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B012}
_0_040:
(W&f2.0) jmpi                                _0_041                                                  //  ALU pipe: int; $43
// B011: [inDivergent],  Preds:{B010},  Succs:{B020}
_0_042:
        mov (32|M0)              r27.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $45
(W)     jmpi                                 _0_043                                                  // $46
// B012: [inDivergent],  Preds:{B010},  Succs:{B020}
_0_041:
        shl (16|M0)              r88.0<1>:q    r84.0<1;1,0>:q    3:w               {Compacted,I@7}   //  ALU pipe: int; $48
        shl (16|M16)             r90.0<1>:q    r86.0<1;1,0>:q    3:w               {Compacted,I@7}   //  ALU pipe: int; $48
        add (16|M0)              r29.0<1>:q    r88.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $49
        add (16|M16)             r31.0<1>:q    r90.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $49
        load.ugm.d64.a64 (32|M0)  r33:4         [r29:4]            {I@1,$6} // ex_desc:0x0; desc:0x8400780 // $51
        mov (16|M0)              r76.0<2>:f    r33.0<1;1,0>:q                   {$6.dst}             //  ALU pipe: float; $52
        mov (16|M16)             r78.0<2>:f    r35.0<1;1,0>:q                                        //  ALU pipe: float; $52
        mov (16|M0)              r27.0<1>:ud   r76.0<2;1,0>:ud                  {Compacted,F@2}      //  ALU pipe: int; $52
        mov (16|M16)             r28.0<1>:ud   r78.0<2;1,0>:ud                  {Compacted,F@1}      //  ALU pipe: int; $52
(W)     jmpi                                 _0_043                                                  // $53
// B013: [inDivergent],  Preds:{B009},  Succs:{B020}
_0_039:
        shl (16|M0)              r92.0<1>:q    r84.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $55
        shl (16|M16)             r94.0<1>:q    r86.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $55
        add (16|M0)              r37.0<1>:q    r92.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $56
        add (16|M16)             r39.0<1>:q    r94.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $56
        load.ugm.d32.a64 (32|M0)  r41:2         [r37:4]            {I@1,$7} // ex_desc:0x0; desc:0x8200580 // $58
        mov (32|M0)              r27.0<1>:f    r41.0<1;1,0>:ud                  {$7.dst}             //  ALU pipe: float; $59
(W)     jmpi                                 _0_043                                                  // $60
// B014: [inDivergent],  Preds:{B008},  Succs:{B020}
_0_037:
        shl (16|M0)              r96.0<1>:q    r84.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $62
        shl (16|M16)             r98.0<1>:q    r86.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $62
        add (16|M0)              r43.0<1>:q    r96.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $63
        add (16|M16)             r45.0<1>:q    r98.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $63
        load.ugm.d32.a64 (32|M0)  r47:2         [r43:4]            {I@1,$8} // ex_desc:0x0; desc:0x8200580 // $65
        mov (32|M0)              r27.0<1>:f    r47.0<1;1,0>:d                   {$8.dst}             //  ALU pipe: float; $66
(W)     jmpi                                 _0_043                                                  // $67
// B015: [inDivergent],  Preds:{B007},  Succs:{B016, B019}
_0_035:
(W&~f1.0) jmpi                               _0_044                                                  //  ALU pipe: int; $69
// B016: [inDivergent],  Preds:{B015},  Succs:{B017, B018}
_0_045:
(W&f0.0) jmpi                                _0_046                                                  //  ALU pipe: int; $71
// B017: [inDivergent],  Preds:{B016},  Succs:{B020}
_0_047:
        mov (32|M0)              r27.0<1>:ud   0x0:ud                              {Compacted,F@1}   //  ALU pipe: int; $73
(W)     jmpi                                 _0_043                                                  // $74
// B018: [inDivergent],  Preds:{B016},  Succs:{B020}
_0_046:
        shl (16|M0)              r100.0<1>:q   r84.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $76
        shl (16|M16)             r102.0<1>:q   r86.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $76
        add (16|M0)              r49.0<1>:q    r100.0<1;1,0>:q   r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $77
        add (16|M16)             r51.0<1>:q    r102.0<1;1,0>:q   r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $77
        load.ugm.d16u32.a64 (32|M0)  r54:2      [r49:4]            {I@1,$9} // ex_desc:0x0; desc:0x8200B80 // $79
        shl (32|M0)              r27.0<1>:d    r54.0<1;1,0>:ud   16:w               {$9.dst}         //  ALU pipe: int; $80
(W)     jmpi                                 _0_043                                                  // $81
// B019: [inDivergent],  Preds:{B015},  Succs:{B020}
_0_044:
        shl (16|M0)              r104.0<1>:q   r84.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $83
        shl (16|M16)             r106.0<1>:q   r86.0<1;1,0>:q    2:w               {Compacted}       //  ALU pipe: int; $83
        add (16|M0)              r56.0<1>:q    r104.0<1;1,0>:q   r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $84
        add (16|M16)             r58.0<1>:q    r106.0<1;1,0>:q   r2.3<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $84
        load.ugm.d32.a64 (32|M0)  r27:2         [r56:4]            {I@1,$10} // ex_desc:0x0; desc:0x8200580 // $86
// B020: [inDivergent],  Preds:{B019, B018, B017, B014, B013, B012, B011},  Succs:{B021, B022}
_0_043:
        and (32|M0)              r60.0<1>:d    r27.0<1;1,0>:d    2147483647:d               {$10.dst} //  ALU pipe: int; $88
        cmp (32|M0)   (eq)f3.0   null<1>:f     r60.0<1;1,0>:f    0x7F800000:f               {I@1}    //  ALU pipe: float; $89
(~f3.0) cmp (32|M0)   (ne)f3.0   null<1>:f     r60.0<1;1,0>:f    r60.0<1;1,0>:f                      //  ALU pipe: float; $90
(~f3.0) goto (32|M0)                         _0_048            _0_048                                //  ALU pipe: int; $92
// B021: [inDivergent],  Preds:{B020},  Succs:{B024}
_0_049:
        mov (16|M0)              r62.0<2>:f    r8.0<0;1,0>:f                    {$5.src}             //  ALU pipe: float; $94
        mov (16|M16)             r64.0<2>:f    r8.0<0;1,0>:f                                         //  ALU pipe: float; $94
        mov (32|M0)              r66.0<1>:d    1:w                               {Compacted}         //  ALU pipe: int; $96
        mov (16|M0)              r62.1<2>:f    r8.1<0;1,0>:f                                         //  ALU pipe: float; $95
        mov (16|M16)             r64.1<2>:ud   r8.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $95
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r62:4]          r66:2              {A@1,$5} // ex_desc:0x0; desc:0x800058B // $97
        goto (32|M0)                         _0_048            _0_028                                // $98
// B022: [inDivergent],  Preds:{B020},  Succs:{B023, B007}
_0_048:
        join (32|M0)                         _0_033                                                  // 
L1504:
        cmp (32|M0)   (lt)f3.0   null<1>:f     r25.0<1;1,0>:f    r27.0<1;1,0>:f                      //  ALU pipe: float; $100
        add (32|M0)              r19.0<1>:d    r19.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $102
(f3.0)  mov (32|M0)              r25.0<1>:f    r27.0<1;1,0>:f                                        //  ALU pipe: float; $101
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r19.0<1;1,0>:ud   r23.0<1;1,0>:ud  {A@1}              //  ALU pipe: int; $103
(f3.0)  goto.b (32|M0)                       _0_033            _0_034                                //  ALU pipe: int; $104
// B023: [inDivergent],  Preds:{B022, B005},  Succs:{B024}
_0_033:
        join (32|M0)                         _0_028                                                  // 
L1592:
        mov (16|M0)              r80.0<2>:ud   r17.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $107
        mov (16|M16)             r82.0<2>:ud   r18.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $107
        shl (16|M0)              r108.0<1>:q   r80.0<2;1,0>:ud   2:w               {I@2}             //  ALU pipe: int; $107
        shl (16|M16)             r110.0<1>:q   r82.0<2;1,0>:ud   2:w               {I@2}             //  ALU pipe: int; $107
        add (16|M0)              r68.0<1>:q    r108.0<1;1,0>:q   r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $108
        add (16|M16)             r70.0<1>:q    r110.0<1;1,0>:q   r3.4<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $108
        store.ugm.d32.a64 (32|M0)  [r68:4]      r25:2              {I@1,$11} // ex_desc:0x0; desc:0x8000584 // $110
// B024: Preds:{B023, B021, B003, B002},  Succs:{}
_0_028:
        join (32|M0)                         L1688                                                   // 
L1688:
(W)     mov (16|M0)              r127.0<1>:f   r4.0<1;1,0>:f                    {Compacted}          //  ALU pipe: float; $112
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$12} // wr:1+0, rd:0; end of thread // $112
L1712:
(W)     mov (16|M0)              null<1>:ud    0xF7EBC3BC:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x705943AB:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x2:ud                                                // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 97
//.accSubDef: 0
//.accSubUse: 0
//.accSubCandidateDef: 0
//.accSubCandidateUse: 0
//
//
//.singlePipeAtOneDistNum: 20
//.allAtOneDistNum: 6
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 10
//.AfterReadTokenDepCount: 2
