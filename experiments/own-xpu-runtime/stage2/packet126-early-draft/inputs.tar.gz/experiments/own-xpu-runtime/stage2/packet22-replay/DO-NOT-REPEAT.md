# Packet 22 negative results and boundaries

| Attempt or shortcut | Evidence / outcome | Revisit condition |
| --- | --- | --- |
| Re-submit the exported graph compute list directly | Public native-graph export exists, but graph replay also owns reset-list/event state. Replaying only its compute list omits that state. [Backend review](backend-notes.md). | Use the implemented independent regular list with explicit typed kernel bindings; qualify raw R0 first. |
| Guess native arguments from capture size alone | Local accessors expand into four native arguments, and dead arguments can disappear. Resolved using named functors, pinned compiler metadata, disabled dead-argument elimination and final embedded SPIR-V checks (8 model classes + R0). | Every compiler change must pass the same ABI gate, followed by raw R0. |
| One independent pool per recording | Forbidden. One card allocation set; reject graph-owned USM allocation. Opaque driver reserve remains unmeasured. | Device memory proof of sharing/reserve. |
| Capture H2D/D2H, host callbacks or lookups | Rejected by native node allowlist and allocation leases. | None; retain explicit outside-capture copies and waits. |
| Same addresses imply same recording | False. Added padding-free operation signatures after independent review. | None; keep shape/dispatch/parameter key checks. |
| Create remaining GEMV descriptor tables during first recorded token | Changed first-token segment topology. Prebuild all resident tables before recording. | Explicit separate memory-admitted graph identity. |
| Release an allocation before recording ends | Owner rejects pending and finalized recording references; sanitizer emits violation. | Drain and destroy all referencing recordings first. |
| R0 scratch category with graph lifetime | CPU owner rejected it before arithmetic. Corrected to graph_static category; 100-case rerun passed. | None. |
| Base-system Python for NumPy integration runner | Missing NumPy; no integration computation ran. Use existing vllm-xpu Python with -B. | A suitably provisioned CPU Python. |
| Timing entire replay as non-GEMV work | Review rejected misleading breakdown. Native replay uses null category fields plus combined segment duration. | Per-node graph profiling that preserves measurement meaning. |
| Accept metadata offset without its extent | Negative tests found that offset alone was insufficient; the gate now also bounds offset + capture size. Sealed ELF hashes cover in-range mutations. | Keep compiler metadata and final-SPIR-V proof boundaries explicit. |
| Native execution on sealed boot | All prepared windows refuse. No device ran. | Owner-authorized reboot and explicit new admission. |

No lane is declared finished and no speed winner is chosen. Both backends are
integrated; native exactness, memory reserve and timing remain open.
