#define main packet26_model_entry
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106-draft-split/build/checked/experiments/own-xpu-runtime/stage2/packet106-draft-split/main.cpp"
#undef main
