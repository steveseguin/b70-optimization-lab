#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106-draft-split/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106-draft-split/small_gemv_fixture.hpp"
#pragma once
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106-draft-split/build/checked/experiments/own-xpu-runtime/stage2/packet106-draft-split/adapter_fixture.hpp"
AdapterFixtureReceipt small_gemv_fixture_gate(unsigned,const std::filesystem::path&);
AdapterFixtureReceipt small_gemv_timing_gate(unsigned,const std::filesystem::path&);
