#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106-draft-split/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106-draft-split/k2_fixture.cpp"
#define PACKET26_K2
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet106-draft-split/build/checked/experiments/own-xpu-runtime/stage2/packet106-draft-split/fixture_driver.cpp"
