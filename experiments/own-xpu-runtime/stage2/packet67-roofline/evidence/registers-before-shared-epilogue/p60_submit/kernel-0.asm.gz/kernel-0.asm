//.kernel _ZTSZZN3p6011norm_kernelERN4sycl3_V15queueENS_5BoundERKSt6vectorINS1_5eventESaIS6_EEENKUlRNS1_7handlerEE_clESC_EUlNS1_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 3399278705 1325551824 -hashmovs1 0 1 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 3399278705 1325551824 -hashmovs1 0 1 -GRFBumpUpNumber 2 "
//.instCount 386
//.RA type	GRAPH_COLORING_FF_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill size 128
//.spill flag store 3
//.spill flag load 3

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r125.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r3.6)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r3.7)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r3.2)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r3.3)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r3.4)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r3.5)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=128 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r125.0)
//.declare V0034 (44)  rf=r size=4 type=ud align=2 words (r4.2)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r125.0)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r2.0)
//.declare V0040 (50)  rf=r size=64 type=w align=32 words (r3.0)
//.declare V0041 (51)  rf=r size=8 type=uq align=4 words (r6.7)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r7.0)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r5.7)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r6.1)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r6.2)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r6.3)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r6.4)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r6.5)
//.declare V0059 (69)  rf=r size=4 type=d align=2 words (r6.12)
//.declare V0062 (72)  rf=r size=768 type=d alias=%arg+0 align=32 words (r26.0)
//.declare V0064 (74)  rf=r size=512 type=d alias=%retval+0 align=32 words (r26.0)
//.declare V0066 (76)  rf=r size=8 type=uq alias=%sp+0 align=32 words (r127.3)
//.declare V0068 (78)  rf=r size=8 type=uq alias=%fp+0 align=32 words (r127.2)
//.declare V0069 (79)  rf=r size=4 type=ud align=2 words (r4.1)
//.declare V0071 (81)  rf=r size=4 type=ud align=2 words (r4.3)
//.declare V0073 (83)  rf=r size=4 type=ud align=2 words (r4.9)
//.declare V0074 (84)  rf=r size=4 type=ud align=2 words (r4.8)
//.declare V0075 (85)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare V0077 (87)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0078 (88)  rf=r size=8 type=uq align=32 words (r5.0)
//.declare V0079 (89)  rf=r size=4 type=ud align=2 words (r4.0)
//.declare V0080 (90)  rf=r size=8 type=uq align=4 words (r4.0)
//.declare V0081 (91)  rf=r size=64 type=w align=32 words (r7.0)
//.declare V0082 (92)  rf=r size=8 type=uq alias=V0056+0 align=4 words (r6.3)
//.declare P01 (93)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0083 (94)  rf=r size=8 type=uq alias=V0057+0 align=4 words (r6.4)
//.declare V0084 (95)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0085 (96)  rf=r size=4 type=d align=32 words (r5.0)
//.declare P02 (97)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0086 (98)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0087 (99)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0089 (101)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0090 (102)  rf=r size=256 type=ud alias=V0089+0 align=32 words (r10.0)
//.declare V0091 (103)  rf=r size=8 type=ud alias=V0087+0 align=32 words (r6.0)
//.declare V0092 (104)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0093 (105)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare V0095 (107)  rf=r size=128 type=d align=32 words (r2.0)
//.declare  (108)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0097 (110)  rf=r size=128 type=ud align=32 words (r2.0)
//.declare  (111)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare  (112)  rf=r size=32 type=ud align=32 words (r2.0)
//.declare V0098 (113)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0099 (114)  rf=r size=4 type=ud align=32 words (r5.0)
//.declare P03 (115)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0100 (116)  rf=r size=8 type=uq alias=V0058+0 align=4 words (r6.5)
//.declare V0101 (117)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0102 (118)  rf=r size=32 type=ud alias=V0036+0 align=16 words (r125.0)
//.declare V0103 (119)  rf=r size=4 type=ud alias=V0101+0 align=2 words (r5.0)
//.declare V0104 (120)  rf=r size=4 type=d align=2 words (r4.3)
//.declare V0105 (121)  rf=r size=4 type=ud alias=V0104+0 align=2 words (r4.3)
//.declare V0106 (122)  rf=r size=4 type=d align=2 words (r66.0)
//.declare V0107 (123)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0108 (124)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0109 (125)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0110 (126)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare P04 (127)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0111 (128)  rf=r size=4 type=ud alias=V0108+0 align=32 words (r5.0)
//.declare V0112 (129)  rf=r size=4 type=ud alias=V0059+0 align=2 words (r6.12)
//.declare P05 (130)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0113 (131)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0114 (132)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0116 (134)  rf=r size=256 type=uq align=32 words (r8.0)
//.declare V0117 (135)  rf=r size=256 type=ud alias=V0116+0 align=32 words (r8.0)
//.declare V0118 (136)  rf=r size=8 type=ud alias=V0114+0 align=32 words (r6.0)
//.declare V0119 (137)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0120 (138)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0121 (139)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0122 (140)  rf=r size=128 type=ud alias=V0109+0 align=32 words (r60.0)
//.declare V0123 (141)  rf=r size=128 type=ud alias=V0121+0 align=32 words (r8.0)
//.declare V0124 (142)  rf=r size=4 type=d align=2 words (r66.1)
//.declare V0125 (143)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0126 (144)  rf=r size=64 type=uw alias=V0081+0 align=32 words (r7.0)
//.declare P06 (145)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0127 (146)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0128 (147)  rf=r size=128 type=d align=32 words (r12.0)
//.declare P07 (148)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0130 (150)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0131 (151)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P08 (152)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0133 (154)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0134 (155)  rf=r size=128 type=d align=32 words (r16.0)
//.declare P09 (156)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0136 (158)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0137 (159)  rf=r size=128 type=d align=32 words (r18.0)
//.declare P10 (160)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0139 (162)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0140 (163)  rf=r size=128 type=d align=32 words (r20.0)
//.declare P11 (164)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0143 (167)  rf=r size=4 type=d align=2 words (r4.9)
//.declare P12 (168)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0144 (169)  rf=r size=4 type=d align=2 words (r4.8)
//.declare V0145 (170)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0146 (171)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0147 (172)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0148 (173)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0150 (175)  rf=r size=128 type=ud alias=V0148+0 align=32 words (r24.0)
//.declare V0154 (179)  rf=r size=256 type=uq align=32 words (r24.0)
//.declare V0156 (181)  rf=r size=128 type=ud align=32 words (r28.0)
//.declare V0157 (182)  rf=r size=128 type=w alias=V0156+0 align=32 words (r28.0)
//.declare V0159 (184)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0160 (185)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0161 (186)  rf=r size=128 type=f alias=V0159+0 align=32 words (r24.0)
//.declare V0162 (187)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0163 (188)  rf=r size=128 type=uw alias=V0128+0 align=32 words (r12.0)
//.declare V0164 (189)  rf=r size=64 type=uw align=32 words (r26.0)
//.declare A00 (190)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0166 (192)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0167 (193)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0168 (194)  rf=r size=128 type=uw alias=V0131+0 align=32 words (r14.0)
//.declare V0169 (195)  rf=r size=64 type=uw align=32 words (r26.0)
//.declare A01 (196)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0171 (198)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0172 (199)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0173 (200)  rf=r size=128 type=uw alias=V0134+0 align=32 words (r16.0)
//.declare V0174 (201)  rf=r size=64 type=uw align=32 words (r26.0)
//.declare A02 (202)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0176 (204)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0177 (205)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0178 (206)  rf=r size=128 type=uw alias=V0137+0 align=32 words (r18.0)
//.declare V0179 (207)  rf=r size=64 type=uw align=32 words (r26.0)
//.declare A03 (208)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0181 (210)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0182 (211)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0183 (212)  rf=r size=128 type=uw alias=V0140+0 align=32 words (r20.0)
//.declare V0184 (213)  rf=r size=64 type=uw align=32 words (r26.0)
//.declare A04 (214)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P13 (215)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0186 (217)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0187 (218)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0188 (219)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0189 (220)  rf=r size=128 type=ud alias=V0188+0 align=32 words (r24.0)
//.declare V0190 (221)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0192 (223)  rf=r size=128 type=ud alias=V0190+0 align=32 words (r24.0)
//.declare V0196 (227)  rf=r size=256 type=uq align=32 words (r24.0)
//.declare P14 (228)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0197 (229)  rf=r size=128 type=ud alias=V0145+0 align=32 words (r22.0)
//.declare V0199 (231)  rf=r size=128 type=d align=32 words (r12.0)
//.declare P15 (232)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0200 (233)  rf=r size=128 type=ud alias=V0199+0 align=32 words (r12.0)
//.declare V0204 (237)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0205 (238)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0206 (239)  rf=r size=128 type=ud alias=V0205+0 align=32 words (r14.0)
//.declare V0207 (240)  rf=r size=128 type=f align=32 words (r12.0)
//.declare  (241)  rf=r size=64 type=ud align=32 words (r6.0)
//.declare  (242)  rf=r size=32 type=ud align=32 words (r6.0)
//.declare P16 (243)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P17 (244)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0208 (245)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0212 (249)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0213 (250)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0214 (251)  rf=r size=128 type=ud alias=V0213+0 align=32 words (r12.0)
//.declare V0215 (252)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0216 (253)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0217 (254)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0218 (255)  rf=r size=128 type=uw alias=V0216+0 align=32 words (r12.0)
//.declare V0219 (256)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare A05 (257)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P18 (258)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0222 (261)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0223 (262)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0224 (263)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0225 (264)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0226 (265)  rf=r size=128 type=uw alias=V0224+0 align=32 words (r12.0)
//.declare V0227 (266)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare A06 (267)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P19 (268)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0230 (271)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0231 (272)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0232 (273)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0233 (274)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0234 (275)  rf=r size=128 type=uw alias=V0232+0 align=32 words (r12.0)
//.declare V0235 (276)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare A07 (277)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P20 (278)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0238 (281)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0239 (282)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0240 (283)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0241 (284)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0242 (285)  rf=r size=128 type=uw alias=V0240+0 align=32 words (r12.0)
//.declare V0243 (286)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare A08 (287)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P21 (288)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0246 (291)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0247 (292)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0248 (293)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0249 (294)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0250 (295)  rf=r size=128 type=uw alias=V0248+0 align=32 words (r12.0)
//.declare V0251 (296)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare A09 (297)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P22 (298)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P23 (299)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0253 (301)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0257 (305)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0258 (306)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0259 (307)  rf=r size=128 type=ud alias=V0258+0 align=32 words (r6.0)
//.declare  (308)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (309)  rf=r size=32 type=ud align=32 words (r1.0)
//.declare V0263 (313)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0264 (314)  rf=r size=4 type=ud alias=V0263+0 align=32 words (r5.0)
//.declare V0265 (315)  rf=r size=16 type=f align=32 words (r4.0)
//.declare V0266 (316)  rf=r size=4 type=f align=2 words (r4.8)
//.declare V0267 (317)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0268 (318)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0269 (319)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0270 (320)  rf=r size=4 type=f align=2 words (r4.0)
//.declare V0271 (321)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0272 (322)  rf=r size=256 type=uq align=32 words (r62.0)
//.declare V0273 (323)  rf=r size=8 type=uq align=4 words (r4.4)
//.declare V0274 (324)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0275 (325)  rf=r size=768 type=f alias=V0062+0 align=32 words (r26.0)
//.declare V0276 (326)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0277 (327)  rf=r size=512 type=f alias=V0064+0 align=32 words (r26.0)
//.declare V0278 (328)  rf=r size=128 type=d alias=V0274+0 align=32 words (r2.0)
//.declare V0279 (329)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0280 (330)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0281 (331)  rf=r size=128 type=f alias=V0279+0 align=32 words (r2.0)
//.declare V0282 (332)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0283 (333)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0285 (335)  rf=r size=128 type=ud alias=V0283+0 align=32 words (r8.0)
//.declare V0289 (339)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0291 (341)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare V0292 (342)  rf=r size=128 type=w alias=V0291+0 align=32 words (r20.0)
//.declare V0296 (346)  rf=r size=256 type=uq align=32 words (r10.0)
//.declare V0297 (347)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0299 (349)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0300 (350)  rf=r size=128 type=f align=32 words (r2.0)
//.declare V0301 (351)  rf=r size=128 type=f alias=V0299+0 align=32 words (r6.0)
//.declare V0303 (353)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0304 (354)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0305 (355)  rf=r size=128 type=d alias=V0303+0 align=32 words (r8.0)
//.declare P24 (356)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0306 (357)  rf=r size=128 type=ud alias=V0304+0 align=32 words (r2.0)
//.declare V0307 (358)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0308 (359)  rf=r size=128 type=ud alias=V0303+0 align=32 words (r8.0)
//.declare V0309 (360)  rf=r size=128 type=ud alias=V0307+0 align=32 words (r6.0)
//.declare V0310 (361)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0311 (362)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0312 (363)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0313 (364)  rf=r size=128 type=ud alias=V0311+0 align=32 words (r6.0)
//.declare V0314 (365)  rf=r size=128 type=ud alias=V0312+0 align=32 words (r2.0)
//.declare V0315 (366)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0316 (367)  rf=r size=128 type=d align=32 words (r2.0)
//.declare V0317 (368)  rf=r size=128 type=ud alias=V0316+0 align=32 words (r2.0)
//.declare V0321 (372)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0322 (373)  rf=r size=64 type=uw alias=V0315+0 align=32 words (r1.0)
//.declare V0323 (374)  rf=r size=128 type=ud align=32 words (r2.0)
//.declare  (375)  rf=r size=4 type=ud alias=SR+28 align=2 words (r126.7) Output
//.declare  (376)  rf=r size=64 type=ud align=32 words (r112.0)
//.declare  (377)  rf=r size=128 type=w alias=V0316+0 align=32 words (r2.0)
//.declare  (378)  rf=r size=64 type=uw align=32 words (r6.0)
//.declare  (379)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare  (380)  rf=r size=4 type=d align=2 words (r4.0)
//.declare  (381)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (382)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (383)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (384)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (385)  rf=r size=2 type=uw align=1 words (r4.6)
//.declare  (387)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (388)  rf=r size=128 type=ud align=32 words (r1.0)
//.declare  (389)  rf=r size=128 type=ud align=32 words (r1.0)
//.declare  (390)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (393)  rf=r size=128 type=w alias=V0312+0 align=32 words (r2.0)
//.declare  (396)  rf=r size=128 type=q align=32 words (r30.0)
//.declare  (397)  rf=r size=128 type=q align=32 words (r28.0)
//.declare  (402)  rf=r size=128 type=q align=32 words (r32.0)
//.declare  (403)  rf=r size=128 type=q align=32 words (r30.0)
//.declare  (408)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (409)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (412)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (413)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (418)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare be_fp (419)  rf=r size=4 type=ud align=2 words (r127.3)
//.declare be_sp (420)  rf=r size=4 type=ud align=2 words (r127.2)
//.declare SR (421)  rf=r size=64 type=ud align=32 words (r126.0)
//.declare VCE_SAVE (422)  rf=r size=4160 type=ud align=32 words (r60.0)
//.declare  (423)  rf=r size=3776 type=ud align=32 words
//.declare  (424)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (425)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (426)  rf=r size=4 type=uw align=2 words (r4.20)
//.declare  (427)  rf=r size=4 type=uw align=2 words (r4.22)
//.declare  (428)  rf=r size=4 type=uw align=2 words (r4.24)
//.declare  (429)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (430)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (431)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (432)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (433)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (434)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (435)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (436)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (437)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (438)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (439)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (450)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (451)  rf=r size=4 type=ud align=32 words NoSpill Input_Output
//.declare  (452)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare r0 (453)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (454)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (455)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (456)  rf=r size=32 type=ud align=2 words (r4.0)
//.declare  (457)  rf=r size=128 type=ud align=32 words (r1.0)
//.declare  (458)  rf=r size=64 type=ud align=32 words (r3.0)
//.declare  (459)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (460)  rf=r size=32 type=ud align=2 words (r7.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0039    | :w x 32  |   0x40 | r2       | pti[tid]+0x40    |
// | V0040    | :w x 32  |   0x40 | r3       | pti[tid]+0x80    |
// | V0079    | :ud      |    0x4 | r4       | inline+0x0       |
// | V0034    | :ud      |    0x4 | r4+0x8   | inline+0x8       |
// | V0043    | :q       |    0x8 | r4+0x10  | inline+0x10      |
// | V0044    | :q       |    0x8 | r4+0x18  | inline+0x18      |
// | V0045    | :q       |    0x8 | r5       | cti+0x20         |
// | V0046    | :q       |    0x8 | r5+0x8   | cti+0x28         |
// | V0047    | :q       |    0x8 | r5+0x10  | cti+0x30         |
// | V0048    | :q       |    0x8 | r5+0x18  | cti+0x38         |
// | V0049    | :q       |    0x8 | r5+0x20  | cti+0x40         |
// | V0050    | :q       |    0x8 | r5+0x28  | cti+0x48         |
// | V0051    | :q       |    0x8 | r5+0x30  | cti+0x50         |
// | V0052    | :q       |    0x8 | r5+0x38  | cti+0x58         |
// | V0053    | :q       |    0x8 | r6       | cti+0x60         |
// | V0054    | :q       |    0x8 | r6+0x8   | cti+0x68         |
// | V0055    | :q       |    0x8 | r6+0x10  | cti+0x70         |
// | V0056    | :q       |    0x8 | r6+0x18  | cti+0x78         |
// | V0057    | :q       |    0x8 | r6+0x20  | cti+0x80         |
// | V0058    | :q       |    0x8 | r6+0x28  | cti+0x88         |
// | V0059    | :d       |    0x4 | r6+0x30  | cti+0x90         |
// | V0041    | :uq      |    0x8 | r6+0x38  | cti+0x98         |
// | V0042    | :uq      |    0x8 | r7       | cti+0xA0         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xA0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0xC0:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r4.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r1:2 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r3:1 bti[255][r127:1+0x80]  {$1} // ex_desc:0xFF080000; desc:0x6219D500 // 
        nop                                                                                          // 
        nop                                                                                          // 
        nop                                                                                          // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
        sync.nop                             null                             {Compacted,$1.src}     // 
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r5:2 bti[255][r127:1]   {I@1,$2} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x8t.a32.ca.cc (1|M0)  r7:1  bti[255][r127:1+0x80]  {$3} // ex_desc:0xFF080000; desc:0x6219C500 // 
// B002: Preds:{B001},  Succs:{B003, B007}
// _main:
(W)     mov (16|M0)              r125.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; 
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; 
        sync.nop                             null                             {Compacted,$3.src}     // 
(W)     mov (1|M0)               r127.3<1>:f   0x0:f                               {$2.src}          //  (0x00000000:f); ALU pipe: float; 
(W)     mov (16|M0)              r126.0<1>:f   r125.0<1;1,0>:f                  {Compacted,I@2}      //  ALU pipe: float; 
(W)     mov (1|M0)               r127.2<1>:f   0x80:f                                                //  (0x00000080:f); ALU pipe: float; 
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud              {F@2}       //  ALU pipe: int; 
(W)     and (1|M0)               r126.7<1>:ud  r125.5<0;1,0>:ud  0xFFFFFC00:ud                       //  ALU pipe: int; 
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     and (1|M0)               r4.1<1>:ud    msg0.0<0;1,0>:ud  0xFF:uw              {A@1}          //  ALU pipe: int; $2
(W)     and (1|M0)               r4.3<1>:ud    sr0.0<0;1,0>:ud   0x7F:uw              {A@1}          //  ALU pipe: int; $3
(W)     and (1|M0)               r4.8<1>:ud    r4.3<0;1,0>:ud    7:w               {A@1}             //  ALU pipe: int; $5
(W)     asr (1|M0)               r4.9<1>:ud    r4.3<0;1,0>:ud    1:w                                 //  ALU pipe: int; $6
(W)     mov (1|M0)               r4.0<1>:d     -8:w                               {Compacted}        //  ALU pipe: int; $7
(W)     shl (1|M0)               r4.1<1>:ud    r4.1<0;1,0>:ud    0x6:uw                              //  ALU pipe: int; $4
(W)     bfn.(s0&s1|s2) (1|M0)    r4.3<1>:ud    r4.9<0;0>:ud      r4.0<0;0>:ud      r4.8<0>:ud       {I@2} //  ALU pipe: int; $7
        cmp (32|M0)   (eq)f0.0   null<2>:w     r1.0<1;1,0>:w     0:w               {$0.dst}          //  ALU pipe: int; $21
(W)     or (1|M0)                r4.1<1>:ud    r4.1<0;1,0>:ud    r4.3<0;1,0>:ud   {I@2}              //  ALU pipe: int; $8
(W)     mov (1|M0)               r5.0<1>:uq    0x0:uw                              {$2.dst}          //  ALU pipe: int; $13
(W)     mul (1|M0)               acc0.0<1>:ud  r4.1<0;1,0>:ud    0x1480:uw              {I@2}        //  ALU pipe: int; $9
(W)     macl (1|M0)              r4.0<1>:ud    r4.1<0;1,0>:ud    0x21480:ud                          //  ALU pipe: int; $10
(W)     add (1|M0)               r127.3<1>:uq  r7.0<0;1,0>:uq    r4.0<0;1,0>:ud   {@1,$3.dst}        //  ALU pipe: int; $10
(W)     mov (8|M0)               r7.0<1>:w     0x76543210:v                                          //  ALU pipe: int; $18
(W)     mov (1|M0)               r127.2<1>:uq  r127.3<0;1,0>:uq                 {I@2}                //  ALU pipe: int; $11
(W)     add (8|M0)               r7.8<1>:w     r7.0<1;1,0>:w     8:w               {I@2}             //  ALU pipe: int; $19
(W)     mov (1|M0)               r4.0<1>:uq    r127.2<0;1,0>:uq                 {Compacted,I@2}      //  ALU pipe: int; $14
(W)     add (1|M0)               r127.3<1>:uq  r127.3<0;1,0>:uq  0x90:uw                             //  ALU pipe: int; $12
(W)     store.ugm.d64x1t.a64 (1|M0)  [r4:1]     r5:1               {I@2,$4} // ex_desc:0x0; desc:0x2008784 // $16
(W)     add (16|M0)              r7.16<1>:w    r7.0<1;1,0>:w     16:w                                //  ALU pipe: int; $20
(W)     mov (1|M0)               r4.0<1>:ud    0x6E10CA2E:ud                              {$4.src}   //  R_SYM_ADDR_32: sqrtf; ALU pipe: int; $17
(W)     mov (1|M0)               r4.1<1>:ud    0x6E10CA2E:ud                                         //  R_SYM_ADDR_32_HI: sqrtf; ALU pipe: int; $17
(~f0.0) goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $22
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_038:
(W)     mov (1|M0)               r6.0<1>:uq    r6.4<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $24
(W)     load.ugm.d32x1t.a64 (1|M0)  r5:1        [r6:1]             {I@1,$5} // ex_desc:0x0; desc:0x2108580 // $25
(W)     cmp (32|M0)   (eq)f3.0   null<1>:d     r5.0<0;1,0>:d     0:w               {$5.dst}          //  ALU pipe: int; $26
(W&~f3.0) jmpi                               _0_039                                                  //  ALU pipe: int; $27
// B004: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_040:
        mov (32|M0)              r8.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $29
(W)     jmpi                                 _0_041                                                  // $30
// B005: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_039:
(W)     mov (1|M0)               r6.0<1>:uq    r6.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $32
        mov (32|M0)              r2.0<1>:d     0:w                               {Compacted,$1.dst}  //  ALU pipe: int; $35
        mov (16|M0)              r10.0<2>:f    r6.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $33
        mov (16|M16)             r12.0<2>:f    r6.0<0;1,0>:f                                         //  ALU pipe: float; $33
        mov (16|M0)              r10.1<2>:f    r6.1<0;1,0>:f                                         //  ALU pipe: float; $34
        mov (16|M16)             r12.1<2>:f    r6.1<0;1,0>:f                                         //  ALU pipe: float; $34
        atomic_or.ugm.d32.a64 (32|M0)  r8:2     [r10:4]           r2:2               {A@1,$6} // ex_desc:0x0; desc:0x8200599 // $36
        cmp (32|M0)   (eq)f2.0   r2.0<1>:d     r8.0<1;1,0>:d     0:w               {$6.dst}          //  ALU pipe: int; $38
        mov (32|M0)              r8.0<1>:d     -r2.0<1;1,0>:d                   {Compacted,I@1}      //  ALU pipe: int; $39
// B006: [inDivergent],  Preds:{B005, B004},  Succs:{B007}
_0_041:
        mov (32|M0)              r2.0<1>:ud    0x0:uw                              {$1.dst}          //  ALU pipe: int; $42
        store.slm.d32.a32 (32|M0)  [r2:2]       r8:2               {I@1,$7} // ex_desc:0x0; desc:0x4000504 // $43
// B007: Preds:{B006, B002},  Succs:{B008, B030}
_0_037:
        join (32|M0)                         L984                                                    // 
L984:
        sync.nop                             null                             {Compacted,$7.src}     // $45
(W)     send.slm (1|M0)          r2       r125  null:0  0x0            0x0210001F           {$8} // wr:1+0, rd:1; fence.slm.none.group // $45
(W)     mov (8|M0)               null<1>:ud    r2.0<1;1,0>:ud                   {Compacted,$8.dst}   //  memory fence commit; ALU pipe: int; $46
(W)     mov (1|M0)               r2.2<1>:f     0x100:f                               {I@1}           //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $46
(W)     mov (2|M0)               r2.10<1>:ub   r125.11<0;1,0>:ub                {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $46
(W)     send.gtwy (1|M0)         null     r2  null:0  0x0            0x02000004           {I@1,$9} // wr:1+0, rd:0; signal barrier // $46
(W)     sync.bar                             0x0                                                     // $46
(W)     mov (1|M0)               r5.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $47
(W)     load.slm.d32x1t.a32 (1|M0)  r5:1        [r5:1]             {I@1,$10} // ex_desc:0x0; desc:0x2108500 // $48
(W)     cmp (32|M0)   (eq)f2.0   null<1>:d     r5.0<0;1,0>:d     0:w               {$10.dst}         //  ALU pipe: int; $49
(W&f2.0) jmpi                                _0_042                                                  //  ALU pipe: int; $50
// B008: Preds:{B007},  Succs:{B009, B011}
_0_043:
(W)     mul (1|M0)               acc0.0<1>:ud  r125.1<0;1,0>:ud  0xCCCD:uw                           //  ALU pipe: int; $52
(W)     mov (1|M0)               r6.0<1>:uq    r6.5<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $55
(W)     mach (1|M0)              r5.0<1>:ud    r125.1<0;1,0>:ud  0xCCCCCCCD:ud                       //  ALU pipe: int; 
        mov (32|M0)              r60.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $57
(W)     shr (1|M0)               r4.3<1>:ud    r5.0<0;1,0>:ud    3:w               {I@2}             //  ALU pipe: int; $53
(W)     load.ugm.d32x1t.a64 (1|M0)  r5:1        [r6:1]             {I@1,$11} // ex_desc:0x0; desc:0x2108580 // $56
(W)     mad (1|M0)               r66.0<1>:d    r125.1<0;0>:d     r4.3<0;0>:d       -10:w               //  ALU pipe: int; $54
(W)     cmp (32|M0)   (lt)f1.0   null<1>:ud    r5.0<0;1,0>:ud    r6.12<0;1,0>:ud  {$11.dst}          //  ALU pipe: int; $58
(W&f1.0) jmpi                                _0_044                                                  //  ALU pipe: int; $59
// B009: Preds:{B008},  Succs:{B010, B030}
_0_045:
        sync.nop                             null                             {Compacted,$9.src}     // $61
        bfn.(s0|s1|s2) (32|M0)   r2.0<1>:ud    r4.3<0;0>:ud      r60.0<1;0>:ud     r66.0<0>:ud      {@3,$1.dst} //  ALU pipe: int; $61 R{} IR{}{E:2,E:6,E:1,},  R{r4,r66,} IR{} {BC=1}
        cmp (32|M0)   (eq)f0.0   null<1>:d     r2.0<1;1,0>:d     0:w               {I@1}             //  ALU pipe: int; $62
(~f0.0) goto (32|M0)                         _0_042            _0_042                                //  ALU pipe: int; $63
// B010: [inDivergent],  Preds:{B009},  Succs:{B030}
_0_046:
(W)     mov (1|M0)               r6.0<1>:uq    r6.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $65
        mov (32|M0)              r2.0<1>:d     1:w                               {Compacted}         //  ALU pipe: int; $68
        mov (16|M0)              r8.0<2>:f     r6.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $66
        mov (16|M16)             r10.0<2>:f    r6.0<0;1,0>:f                                         //  ALU pipe: float; $66
        mov (16|M0)              r8.1<2>:f     r6.1<0;1,0>:f                                         //  ALU pipe: float; $67
        mov (16|M16)             r10.1<2>:ud   r6.1<0;1,0>:ud                   {F@2}                //  ALU pipe: int; $67
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r8:4]           r2:2               {A@1,$12} // ex_desc:0x0; desc:0x800058B // $69
        goto (32|M0)                         _0_042            _0_042                                // $70
// B011: [inDivergent],  Preds:{B008},  Succs:{B012, B018}
_0_044:
        cmp (32|M0)   (lt)f3.0   null<2>:uw    r1.0<1;1,0>:uw    0xA00:uw                            //  ALU pipe: int; $76
        and (32|M0)              r10.0<1>:d    r60.0<1;1,0>:d    31:w               {Compacted,$12.src} //  ALU pipe: int; $72
        shr (32|M0)              r8.0<1>:ud    r60.0<1;1,0>:ud   5:w                                 //  ALU pipe: int; $73
        sync.nop                             null                             {Compacted,$9.src}     // $75
        mov (32|M0)              r2.0<1>:d     r7.0<1;1,0>:uw                   {$1.dst}             //  ALU pipe: int; $75
(W)     mul (1|M0)               r66.1<1>:d    r4.3<0;1,0>:d     2560:w                              //  ALU pipe: int; $74
(~f3.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $77
// B012: [inDivergent],  Preds:{B011},  Succs:{B013}
_0_048:
        add (32|M0)              r14.0<1>:d    r2.0<1;1,0>:d     1:w               {Compacted,I@3}   //  ALU pipe: int; $79
        add (32|M0)              r16.0<1>:d    r2.0<1;1,0>:d     2:w               {Compacted}       //  ALU pipe: int; $83
        add (32|M0)              r18.0<1>:d    r2.0<1;1,0>:d     4:w               {Compacted}       //  ALU pipe: int; $87
        add (32|M0)              r20.0<1>:d    r2.0<1;1,0>:d     8:w               {Compacted}       //  ALU pipe: int; $91
        and (32|M0)              r12.0<1>:d    r14.0<1;1,0>:d    31:w               {Compacted,I@4}  //  ALU pipe: int; $80
        and (32|M0)   (eq)f2.0   null<1>:d     r2.0<1;1,0>:d     1:w                                 //  ALU pipe: int; $81
        and (32|M0)   (eq)f1.0   null<1>:d     r2.0<1;1,0>:d     3:w                                 //  ALU pipe: int; $85
        and (32|M0)   (eq)f0.0   null<1>:d     r2.0<1;1,0>:d     7:w                                 //  ALU pipe: int; $89
        add (32|M0)              r22.0<1>:d    r2.0<1;1,0>:d     16:w               {Compacted}      //  ALU pipe: int; $95
        and (32|M0)              r14.0<1>:d    r16.0<1;1,0>:d    31:w               {Compacted,I@7}  //  ALU pipe: int; $84
        and (32|M0)              r16.0<1>:d    r18.0<1;1,0>:d    31:w               {Compacted,I@7}  //  ALU pipe: int; $88
        and (32|M0)              r18.0<1>:d    r20.0<1;1,0>:d    31:w               {Compacted,I@7}  //  ALU pipe: int; $92
        and (32|M0)              r20.0<1>:d    r22.0<1;1,0>:d    31:w               {Compacted,I@4}  //  ALU pipe: int; $96
(W)     mov (1|M0)               r4.12<1>:ud   f2.0<0;1,0>:ud                                        //  ALU pipe: int; $81
(W)     mov (1|M0)               r4.11<1>:ud   f1.0<0;1,0>:ud                                        //  ALU pipe: int; $85
(W)     mov (1|M0)               r4.10<1>:ud   f0.0<0;1,0>:ud                                        //  ALU pipe: int; $89
        mov (32|M0)              r22.0<1>:f    r8.0<1;1,0>:f                    {Compacted,I@4}      //  ALU pipe: float; $102
        and (32|M0)   (eq)f2.0   null<1>:d     r2.0<1;1,0>:d     15:w                                //  ALU pipe: int; $93
        cmp (32|M0)   (eq)f1.0   null<2>:w     r7.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $97
(W)     cmp (32|M0)   (eq)f0.0   null<1>:d     r66.0<0;1,0>:d    0:w                                 //  ALU pipe: int; $100
(W)     mov (1|M0)               r4.9<1>:d     r4.2<0;1,0>:ud                                        //  ALU pipe: int; $99
(W)     mov (1|M0)               r4.8<1>:d     31:w                                                  //  ALU pipe: int; $101
// B013: [inDivergent],  Preds:{B017, B012},  Succs:{B014, B016}
_0_049:
        sync.nop                             null                             {Compacted,F@1}        // $104
        sync.nop                             null                             {Compacted,$13.src}    // $104
        shl (32|M0)              r24.0<1>:d    r22.0<1;1,0>:d    5:w               {Compacted,$14.src} //  ALU pipe: int; $104
        add (32|M0)              r26.0<1>:d    r66.1<0;1,0>:d    r24.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $105
        bfn.(s0|s1&s2) (32|M0)   r24.0<1>:ud   r26.0<1;0>:ud     r60.0<1;0>:ud     r4.8<0>:ud       {I@1} //  ALU pipe: int; $106 R{} IR{}{E:5,E:6,E:2,},  R{r4,} IR{}{O:13,O:14,},  {BC=1}
        mov (16|M0)              r26.0<2>:ud   r24.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $108
        shl (16|M0)              r30.0<1>:q    r26.0<2;1,0>:ud   1:w               {I@1}             //  ALU pipe: int; $108
        mov (16|M16)             r26.0<2>:ud   r25.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $108
        shl (16|M16)             r28.0<1>:q    r26.0<2;1,0>:ud   1:w               {I@1}             //  ALU pipe: int; $108
        add (16|M0)              r24.0<1>:q    r30.0<1;1,0>:q    r4.2<0;1,0>:q    {Compacted}        //  ALU pipe: int; $109
        add (16|M16)             r26.0<1>:q    r28.0<1;1,0>:q    r4.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $109
        load.ugm.d16u32.a64 (32|M0)  r28:2      [r24:4]            {I@1,$15} // ex_desc:0x0; desc:0x8200B80 // $111
        shl (32|M0)              r26.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {$15.src}       //  ALU pipe: int; $114
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $115
        add (16|M0)              a0.0<1>:uw    r26.0<1;1,0>:uw   0x740:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0160(r29.0:f); $116
(W)     mov (1|M0)               f3.0<1>:ud    r4.12<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $121
        shl (32|M0)              r24.0<1>:d    r28.0<1;1,0>:ud   16:w               {$15.dst}        //  ALU pipe: int; $112
        mul (32|M0)              r29.0<1>:f    r24.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $113
        mov (16|M0)              r24.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $117
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $118
        add (16|M16)             a0.0<1>:uw    r26.16<1;1,0>:uw  0x740:uw                            //  ALU pipe: int; src1 is addr of V0160(r29.0:f); $119
        shl (32|M0)              r26.0<1>:uw   r14.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $123
        mov (16|M16)             r25.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $120
(f3.0)  sel (32|M0)              acc0.0<1>:f   r24.0<1;1,0>:f    0x80000000:f               {I@1}    //  ALU pipe: float; $121
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $124
        add (16|M0)              a0.0<1>:uw    r26.0<1;1,0>:uw   0x6C0:uw                            //  ALU pipe: int; src1 is addr of V0166(r27.0:f); $125
        add (32|M0)              r27.0<1>:f    r29.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $122
        mov (16|M0)              r24.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $126
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $127
        add (16|M16)             a0.0<1>:uw    r26.16<1;1,0>:uw  0x6C0:uw                            //  ALU pipe: int; src1 is addr of V0166(r27.0:f); $128
(W)     mov (1|M0)               f3.0<1>:ud    r4.11<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $130
        shl (32|M0)              r26.0<1>:uw   r16.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $132
        mov (16|M16)             r25.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $129
(f3.0)  sel (32|M0)              acc0.0<1>:f   r24.0<1;1,0>:f    0x80000000:f               {I@1}    //  ALU pipe: float; $130
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $133
        add (16|M0)              a0.0<1>:uw    r26.0<1;1,0>:uw   0x740:uw                            //  ALU pipe: int; src1 is addr of V0171(r29.0:f); $134
        add (32|M0)              r29.0<1>:f    r27.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $131
        mov (16|M0)              r24.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $135
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $136
        add (16|M16)             a0.0<1>:uw    r26.16<1;1,0>:uw  0x740:uw                            //  ALU pipe: int; src1 is addr of V0171(r29.0:f); $137
(W)     mov (1|M0)               f3.0<1>:ud    r4.10<0;1,0>:ud                  {Compacted}          //  ALU pipe: int; $139
        shl (32|M0)              r26.0<1>:uw   r18.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $141
        mov (16|M16)             r25.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $138
(f3.0)  sel (32|M0)              acc0.0<1>:f   r24.0<1;1,0>:f    0x80000000:f               {I@1}    //  ALU pipe: float; $139
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $142
        add (16|M0)              a0.0<1>:uw    r26.0<1;1,0>:uw   0x6C0:uw                            //  ALU pipe: int; src1 is addr of V0176(r27.0:f); $143
        add (32|M0)              r27.0<1>:f    r29.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $140
        mov (16|M0)              r24.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $144
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $145
        add (16|M16)             a0.0<1>:uw    r26.16<1;1,0>:uw  0x6C0:uw                            //  ALU pipe: int; src1 is addr of V0176(r27.0:f); $146
        shl (32|M0)              r26.0<1>:uw   r20.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $150
        mov (16|M16)             r25.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $147
(f2.0)  sel (32|M0)              acc0.0<1>:f   r24.0<1;1,0>:f    0x80000000:f               {I@1}    //  ALU pipe: float; $148
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $151
        add (16|M0)              a0.0<1>:uw    r26.0<1;1,0>:uw   0x780:uw                            //  ALU pipe: int; src1 is addr of V0181(r30.0:f); $152
        add (32|M0)              r30.0<1>:f    r27.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $149
        cmp (32|M0)   (eq)f3.0   null<1>:d     r10.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $157
        mov (16|M0)              r24.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $153
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $154
        add (16|M16)             a0.0<1>:uw    r26.16<1;1,0>:uw  0x780:uw                            //  ALU pipe: int; src1 is addr of V0181(r30.0:f); $155
        mov (16|M16)             r25.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $156
(~f3.0) goto (32|M0)                         _0_050            _0_050                                //  ALU pipe: int; $158
// B014: [inDivergent],  Preds:{B013},  Succs:{B015, B016}
_0_051:
        shl (32|M0)              r26.0<1>:d    r22.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $162
(f1.0)  sel (32|M0)              acc0.0<1>:f   r24.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $160
        add (32|M0)              r28.0<1>:f    r30.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $161
        add (32|M0)              r24.0<1>:d    r26.0<1;1,0>:d    r4.9<0;1,0>:d    {Compacted,A@1}    //  ALU pipe: int; $163
        store.slm.d32.a32 (32|M0)  [r24:2]      r28:2              {A@1,$14} // ex_desc:0x0; desc:0x4000504 // $164
(~f0.0) goto (32|M0)                         _0_050            _0_050                                //  ALU pipe: int; $165
// B015: [inDivergent],  Preds:{B014},  Succs:{B016}
_0_052:
        mad (32|M0)              r24.0<1>:d    r22.0<1;0>:d      r4.3<0;0>:d       80:w               {$14.src} //  ALU pipe: int; $167
        mov (16|M0)              r26.0<2>:ud   r24.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $169
        shl (16|M0)              r32.0<1>:q    r26.0<2;1,0>:ud   2:w               {I@1}             //  ALU pipe: int; $169
        mov (16|M16)             r26.0<2>:ud   r25.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $169
        shl (16|M16)             r30.0<1>:q    r26.0<2;1,0>:ud   2:w               {I@1}             //  ALU pipe: int; $169
        add (16|M0)              r24.0<1>:q    r32.0<1;1,0>:q    r6.1<0;1,0>:q    {Compacted}        //  ALU pipe: int; $170
        add (16|M16)             r26.0<1>:q    r30.0<1;1,0>:q    r6.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $170
        store.ugm.d32.a64 (32|M0)  [r24:4]      r28:2              {I@1,$13} // ex_desc:0x0; desc:0x8000584 // $172
// B016: [inDivergent],  Preds:{B015, B014, B013},  Succs:{B017, B018}
_0_050:
        join (32|M0)                         _0_047                                                  // 
L2856:
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r22.0<1;1,0>:ud   0x48:uw                             //  ALU pipe: int; $174
(~f3.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $175
// B017: [inDivergent],  Preds:{B016},  Succs:{B013}
_0_053:
        add (32|M0)              r22.0<1>:d    r22.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $177
(W)     jmpi                                 _0_049                                                  // $179
// B018: [inDivergent],  Preds:{B016, B011},  Succs:{B019, B020}
_0_047:
        join (32|M0)                         _0_042                                                  // 
L2928:
        add (32|M0)              r12.0<1>:d    r60.0<1;1,0>:d    -80:w               {Compacted}     //  ALU pipe: int; $181
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r12.0<1;1,0>:ud   0x30:uw              {I@1}          //  ALU pipe: int; $182
(~f2.0) goto (32|M0)                         _0_054            _0_054                                //  ALU pipe: int; $183
// B019: [inDivergent],  Preds:{B018},  Succs:{B020}
_0_055:
        shl (32|M0)              r12.0<1>:d    r60.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $187
        add (32|M0)              r14.0<1>:d    r12.0<1;1,0>:d    r4.2<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $188
        mov (32|M0)              r12.0<1>:f    0x0:f                               {Compacted,I@1}   //  ALU pipe: float; $189
        store.slm.d32.a32 (32|M0)  [r14:2]      r12:2              {F@1,$0} // ex_desc:0x0; desc:0x4000504 // $190
// B020: [inDivergent],  Preds:{B019, B018},  Succs:{B021, B022}
_0_054:
        join (32|M0)                         _0_042                                                  // 
L3024:
(W)     send.slm (1|M0)          r6       r125  null:0  0x0            0x0210001F           {$1} // wr:1+0, rd:1; fence.slm.none.group // $192
(W)     mov (8|M0)               null<1>:ud    r6.0<1;1,0>:ud                   {Compacted,$1.dst}   //  memory fence commit; ALU pipe: int; $193
(W)     mov (1|M0)               r6.2<1>:f     0x100:f                               {I@1}           //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $193
(W)     mov (2|M0)               r6.10<1>:ub   r125.11<0;1,0>:ub                {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $193
(W)     send.gtwy (1|M0)         null     r6  null:0  0x0            0x02000004           {I@1,$2} // wr:1+0, rd:0; signal barrier // $193
(W)     sync.bar                             0x0                                                     // $193
        cmp (32|M0)   (lt)f1.0   null<2>:uw    r1.0<1;1,0>:uw    0x80:uw                             //  ALU pipe: int; $195
        cmp (32|M0)   (lt)f3.0   null<2>:uw    r1.0<1;1,0>:uw    0x80:uw                             //  ALU pipe: int; $194
(f1.0)  goto (32|M0)                         _0_056            _0_056                                //  ALU pipe: int; $196
// B021: [inDivergent],  Preds:{B020},  Succs:{B023}
_0_057:
        mov (32|M0)              r16.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $198
        goto (32|M0)                         _0_056            _0_058                                // $199
// B022: [inDivergent],  Preds:{B020},  Succs:{B023}
_0_056:
        join (32|M0)                         _0_058                                                  // 
L3200:
        shl (32|M0)              r14.0<1>:d    r60.0<1;1,0>:d    2:w               {Compacted,$0.src} //  ALU pipe: int; $203
        add (32|M0)              r12.0<1>:d    r14.0<1;1,0>:d    r4.2<0;1,0>:d    {Compacted,I@1}    //  ALU pipe: int; $204
        load.slm.d32.a32 (32|M0)  r16:2         [r12:2]            {I@1,$3} // ex_desc:0x0; desc:0x4200500 // $205
// B023: [inDivergent],  Preds:{B022, B021},  Succs:{B024, B025}
_0_058:
        join (32|M0)                         _0_042                                                  // 
L3248:
        add (32|M0)              r14.0<1>:d    r2.0<1;1,0>:d     1:w               {Compacted,$0.src} //  ALU pipe: int; $207
        and (32|M0)              r12.0<1>:d    r14.0<1;1,0>:d    31:w               {Compacted,@1,$3.src} //  ALU pipe: int; $208
        shl (32|M0)              r1.0<1>:uw    r12.0<2;1,0>:uw   0x2:uw              {I@1}           //  ALU pipe: int; $209
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $210
        add (16|M0)              a0.0<1>:uw    r1.0<1;1,0>:uw    0x400:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0208(r16.0:f); $211
        and (32|M0)   (eq)f1.0   null<1>:d     r2.0<1;1,0>:d     1:w                                 //  ALU pipe: int; $216
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {$3.dst}             //  ALU pipe: int; $212
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $213
        add (16|M16)             a0.0<1>:uw    r1.16<1;1,0>:uw   0x400:uw                            //  ALU pipe: int; src1 is addr of V0208(r16.0:f); $214
        add (32|M0)              r14.0<1>:d    r2.0<1;1,0>:d     2:w               {Compacted}       //  ALU pipe: int; $220
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $215
(f1.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@1}    //  ALU pipe: float; $218
        and (32|M0)              r12.0<1>:d    r14.0<1;1,0>:d    31:w               {Compacted,F@1}  //  ALU pipe: int; $221
        shl (32|M0)              r1.0<1>:uw    r12.0<2;1,0>:uw   0x2:uw              {I@1}           //  ALU pipe: int; $222
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $223
        add (16|M0)              a0.0<1>:uw    r1.0<1;1,0>:uw    0x500:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0222(r20.0:f); $224
        add (32|M0)              r20.0<1>:f    r16.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $219
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $225
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $226
        add (16|M16)             a0.0<1>:uw    r1.16<1;1,0>:uw   0x500:uw                            //  ALU pipe: int; src1 is addr of V0222(r20.0:f); $227
        and (32|M0)   (eq)f0.0   null<1>:d     r2.0<1;1,0>:d     3:w                                 //  ALU pipe: int; $229
        add (32|M0)              r14.0<1>:d    r2.0<1;1,0>:d     4:w               {Compacted}       //  ALU pipe: int; $233
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $228
(f0.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@1}    //  ALU pipe: float; $231
        and (32|M0)              r12.0<1>:d    r14.0<1;1,0>:d    31:w               {Compacted,F@1}  //  ALU pipe: int; $234
        shl (32|M0)              r1.0<1>:uw    r12.0<2;1,0>:uw   0x2:uw              {I@1}           //  ALU pipe: int; $235
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $236
        add (16|M0)              a0.0<1>:uw    r1.0<1;1,0>:uw    0x480:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0230(r18.0:f); $237
        add (32|M0)              r18.0<1>:f    r20.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $232
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $238
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $239
        add (16|M16)             a0.0<1>:uw    r1.16<1;1,0>:uw   0x480:uw                            //  ALU pipe: int; src1 is addr of V0230(r18.0:f); $240
        and (32|M0)   (eq)f2.0   null<1>:d     r2.0<1;1,0>:d     7:w                                 //  ALU pipe: int; $242
        add (32|M0)              r14.0<1>:d    r2.0<1;1,0>:d     8:w               {Compacted}       //  ALU pipe: int; $246
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $241
(f2.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@1}    //  ALU pipe: float; $244
        and (32|M0)              r12.0<1>:d    r14.0<1;1,0>:d    31:w               {Compacted,F@1}  //  ALU pipe: int; $247
        shl (32|M0)              r1.0<1>:uw    r12.0<2;1,0>:uw   0x2:uw              {I@1}           //  ALU pipe: int; $248
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $249
        add (16|M0)              a0.0<1>:uw    r1.0<1;1,0>:uw    0x400:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0238(r16.0:f); $250
        add (32|M0)              r16.0<1>:f    r18.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $245
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $251
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $252
        add (16|M16)             a0.0<1>:uw    r1.16<1;1,0>:uw   0x400:uw                            //  ALU pipe: int; src1 is addr of V0238(r16.0:f); $253
        and (32|M0)   (eq)f1.0   null<1>:d     r2.0<1;1,0>:d     15:w                                //  ALU pipe: int; $255
        add (32|M0)              r14.0<1>:d    r2.0<1;1,0>:d     16:w               {Compacted}      //  ALU pipe: int; $259
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $254
(f1.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@1}    //  ALU pipe: float; $257
        and (32|M0)              r12.0<1>:d    r14.0<1;1,0>:d    31:w               {Compacted,F@1}  //  ALU pipe: int; $260
        shl (32|M0)              r1.0<1>:uw    r12.0<2;1,0>:uw   0x2:uw              {I@1}           //  ALU pipe: int; $261
        cmp (32|M0)   (eq)f0.0   null<1>:d     r10.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $268
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $262
        add (16|M0)              a0.0<1>:uw    r1.0<1;1,0>:uw    0x480:uw              {I@3}         //  ALU pipe: int; src1 is addr of V0246(r18.0:f); $263
        add (32|M0)              r18.0<1>:f    r16.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $258
(W)     mov (1|M0)               r4.6<1>:hf    0x1:hf                                                //  ALU pipe: float; $269
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {F@2}                //  ALU pipe: int; $264
        sync.nop                             null                             {Compacted,F@1}        // $269
(f0.0)  sel (32|M0)              r6.0<1>:uw    r4.6<0;1,0>:uw    0x0:uw              {$2.src}        //  ALU pipe: int; $269
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $265
        add (16|M16)             a0.0<1>:uw    r1.16<1;1,0>:uw   0x480:uw                            //  ALU pipe: int; src1 is addr of V0246(r18.0:f); $266
(f3.0)  sel (32|M0)              r1.0<1>:uw    r4.6<0;1,0>:uw    0x0:uw                              //  ALU pipe: int; $269
        and (32|M0)   (ne)f0.0   null<2>:uw    r6.0<1;1,0>:uw    r1.0<1;1,0>:uw   {I@1}              //  ALU pipe: int; $269
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $267
(~f0.0) goto (32|M0)                         _0_059            _0_059                                //  ALU pipe: int; $270
// B024: [inDivergent],  Preds:{B023},  Succs:{B025}
_0_060:
        cmp (32|M0)   (eq)f0.0   null<2>:w     r7.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $272
        shl (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     2:w               {Compacted}       //  ALU pipe: int; $277
(f0.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@4}    //  ALU pipe: float; $273
        add3 (32|M0)             r6.0<1>:d     r10.0<1;0>:d      r4.2<0;0>:d       512:w               {I@1} //  ALU pipe: int; $278
        add (32|M0)              r12.0<1>:f    r18.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $274
        store.slm.d32.a32 (32|M0)  [r6:2]       r12:2              {A@1,$4} // ex_desc:0x0; desc:0x4000504 // $279
// B025: [FCALL],  [inDivergent],  Preds:{B024, B023},  Succs:{B026}
_0_059:
        join (32|M0)                         _0_042                                                  // 
L4248:
(W)     send.slm (1|M0)          r1       r125  null:0  0x0            0x0210001F           {$5} // wr:1+0, rd:1; fence.slm.none.group // $281
(W)     mov (8|M0)               null<1>:ud    r1.0<1;1,0>:ud                   {Compacted,$5.dst}   //  memory fence commit; ALU pipe: int; $282
(W)     mov (1|M0)               r1.2<1>:f     0x100:f                               {I@1}           //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $282
(W)     mov (2|M0)               r1.10<1>:ub   r125.11<0;1,0>:ub                {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $282
(W)     send.gtwy (1|M0)         null     r1  null:0  0x0            0x02000004           {I@1,$6} // wr:1+0, rd:0; signal barrier // $282
(W)     sync.bar                             0x0                                                     // $282
(W)     add (1|M0)               r5.0<1>:d     r4.2<0;1,0>:d     512:w               {Compacted}     //  ALU pipe: int; $285
(W)     mov (1|M0)               r127.0<2>:ud  r4.0<0;1,0>:uq                                        //  ALU pipe: int; $296
(W)     load.slm.d32x4t.a32 (1|M0)  r4:1        [r5:1]             {I@1,$7} // ex_desc:0x0; desc:0x210B500 // $286
        shl (32|M0)              r6.0<1>:d     r2.0<1;1,0>:d     2:w               {Compacted,$4.src} //  ALU pipe: int; $292
(W)     add (1|M0)               r4.4<1>:uq    r127.2<0;1,0>:uq  0x10:uw              {$7.dst}       //  ALU pipe: int; $293
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $294
        mov (16|M16)             r1.0<2>:ud    r7.0<1;1,0>:ud                   {Compacted,$6.src}   //  ALU pipe: int; $294
        add (16|M0)              r62.0<1>:uq   r4.4<0;1,0>:uq    r8.0<2;1,0>:d    {I@2}              //  ALU pipe: int; $294
        add (16|M16)             r64.0<1>:uq   r4.4<0;1,0>:uq    r1.0<2;1,0>:d    {I@2}              //  ALU pipe: int; $294
(W)     add (1|M0)               r4.8<1>:f     r4.0<0;1,0>:f     r4.1<0;1,0>:f    {I@1}              //  ALU pipe: float; $287
(W)     add (1|M0)               r4.0<1>:f     r4.2<0;1,0>:f     r4.3<0;1,0>:f    {Compacted}        //  ALU pipe: float; $288
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $297
(W)     add (1|M0)               r4.0<1>:f     r4.8<0;1,0>:f     r4.0<0;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $289
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $297
(W)     mul (1|M0)               r4.0<1>:f     r4.0<0;1,0>:f     0x39CCCCCD:f               {F@1}    //  ALU pipe: float; $290
(W)     add (1|M0)               r4.0<1>:f     r4.0<0;1,0>:f     0x358637BD:f               {F@1}    //  ALU pipe: float; $291
        mov (32|M0)              r26.0<1>:f    r4.0<0;1,0>:f                    {Compacted,@1,$13.src} //  ALU pipe: float; $295
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r4:2  {I@2,$8} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[0*64] of ?; ; $297
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $297
        sync.allrd                           null                             {A@1}                  // $297
        sync.allwr                           null                                                    // $297
        calla (32|M0)            r127.0        r127.0                           {A@1}                // $297
// B026: [inDivergent],  Preds:{B025},  Succs:{B027, B028}
_L_k0_0_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $297
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $297
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $297
        mov (32|M0)              r2.0<1>:f     r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $298
(W)     load.ugm.d32x32t.a32 (1|M0)  r4:2       ss[a0.2][r126:1-0x10000]  {I@1,$9} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[0*64] of ?; ; $297
        sync.nop                             null                             {Compacted,$9.dst}     // $299
        store.ugm.d32.a64.wb.wb (32|M0)  [r62:4] r2:2              {F@1,$10} // ex_desc:0x0; desc:0x80E0584 // $299
(W)     shl (1|M0)               r4.0<1>:d     r66.0<0;1,0>:d    8:w               {Compacted,$9.dst} //  ALU pipe: int; $302
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                                      //  ALU pipe: int; $319
        add3 (32|M0)             r8.0<1>:d     r66.1<0;0>:d      r4.0<0;0>:d       r60.0<1>:d       {I@2} //  ALU pipe: int; $303 R{} IR{}{E:1,E:2,E:6,},  R{r66,r4,} IR{} {BC=1}
        mov (16|M0)              r1.0<2>:ud    r8.0<1;1,0>:ud                   {Compacted,@1,$10.src} //  ALU pipe: int; $305
        mov (16|M16)             r6.0<2>:ud    r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $305
        shl (16|M0)              r16.0<1>:q    r1.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $305
        shl (16|M16)             r14.0<1>:q    r6.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $305
        shl (16|M0)              r18.0<1>:q    r1.0<2;1,0>:ud    2:w                                 //  ALU pipe: int; $309
        shl (16|M16)             r1.0<1>:q     r6.0<2;1,0>:ud    2:w                                 //  ALU pipe: int; $309
        add (16|M0)              r6.0<1>:q     r16.0<1;1,0>:q    r4.2<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $306
        add (16|M16)             r8.0<1>:q     r14.0<1;1,0>:q    r4.2<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $306
        load.ugm.d16u32.a64 (32|M0)  r20:2      [r6:4]             {I@1,$11} // ex_desc:0x0; desc:0x8200B80 // $308
        add (16|M0)              r10.0<1>:q    r18.0<1;1,0>:q    r4.3<0;1,0>:q    {Compacted}        //  ALU pipe: int; $310
        add (16|M16)             r12.0<1>:q    r1.0<1;1,0>:q     r4.3<0;1,0>:q    {Compacted}        //  ALU pipe: int; $310
        load.ugm.d32.a64 (32|M0)  r18:2         [r10:4]            {I@1,$12} // ex_desc:0x0; desc:0x8200580 // $312
        load.ugm.d32.a64.ca.ca (32|M0)  r2:2    [r62:4]            {$15} // ex_desc:0x0; desc:0x8280580 // $300
        sync.nop                             null                             {Compacted,$11.src}    // $301
        math.inv (32|M0)         r8.0<1>:f     r2.0<1;1,0>:f                    {$15.dst}            //  ALU pipe: math; $301
        shl (32|M0)              r6.0<1>:d     r20.0<1;1,0>:ud   16:w               {$11.dst}        //  ALU pipe: int; $313
        mul (32|M0)              r2.0<1>:f     r8.0<1;1,0>:f     r6.0<1;1,0>:f    {Compacted,A@1}    //  ALU pipe: float; $314
        add (32|M0)              acc0.0<1>:f   r18.0<1;1,0>:f    0x0:f               {Compacted,$12.dst} //  ALU pipe: float; $315
        mul (32|M0)              r8.0<1>:f     r2.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $316
        and (32|M0)              r2.0<1>:d     r8.0<1;1,0>:d     2147483647:d               {F@1}    //  ALU pipe: int; $317
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r2.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $318
(f3.0)  goto (32|M0)                         _0_061            _0_061                                //  ALU pipe: int; $319
// B027: [inDivergent],  Preds:{B026},  Succs:{B029}
_0_062:
        shr (32|M0)              r6.0<1>:ud    r8.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $321
        and (32|M0)              r2.0<1>:d     r6.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $322
        add3 (32|M0)             r6.0<1>:d     r2.0<1;0>:d       r8.0<1;0>:d       32767:w               {I@1} //  ALU pipe: int; $323
        shr (32|M0)              r2.0<1>:ud    r6.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $324
        mov (32|M0)              r1.0<1>:w     r2.0<2;1,0>:w                    {I@1}                //  ALU pipe: int; $325
        goto (32|M0)                         _0_061            _0_063                                // $326
// B028: [inDivergent],  Preds:{B026},  Succs:{B029}
_0_061:
        join (32|M0)                         _0_063                                                  // 
L5144:
        shr (32|M0)              r2.0<1>:ud    r8.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $328
        or (32|M0)               r1.0<1>:w     r2.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $330
// B029: [inDivergent],  Preds:{B028, B027},  Succs:{B030}
_0_063:
        join (32|M0)                         _0_042                                                  // 
L5192:
        add (16|M0)              r6.0<1>:q     r16.0<1;1,0>:q    r5.3<0;1,0>:q    {Compacted}        //  ALU pipe: int; $332
        add (16|M16)             r8.0<1>:q     r14.0<1;1,0>:q    r5.3<0;1,0>:q    {Compacted}        //  ALU pipe: int; $332
        mov (32|M0)              r2.0<1>:ud    r1.0<1;1,0>:uw                   {I@4}                //  ALU pipe: int; $334
        store.ugm.d16u32.a64 (32|M0)  [r6:4]    r2:2               {I@1,$0} // ex_desc:0x0; desc:0x8000B84 // $335
// B030: Preds:{B029, B010, B009, B007},  Succs:{}
_0_042:
        join (32|M0)                         L5256                                                   // 
L5256:
(W)     mov (16|M0)              r112.0<1>:f   r125.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $337
(W)     send.gtwy (1|M0)         null     r112  null:0  0x0            0x02000010           {EOT,F@1,$1} // wr:1+0, rd:0; end of thread // $337
L5280:
(W)     mov (16|M0)              null<1>:ud    0xCA9CE071:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x4F0250D0:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1:ud                                                // 


//.BankConflicts: 3
//.ByteRMWs: 0
//


//.numALUInst: 322
//.accSubDef: 11
//.accSubUse: 11
//.accSubCandidateDef: 12
//.accSubCandidateUse: 12
//
//
//.singlePipeAtOneDistNum: 89
//.allAtOneDistNum: 12
//.syncInstCount: 10
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 21
//.AfterReadTokenDepCount: 23
