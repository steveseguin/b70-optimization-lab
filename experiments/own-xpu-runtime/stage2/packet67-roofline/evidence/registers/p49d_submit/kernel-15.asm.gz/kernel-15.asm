//.kernel _ZTSZZNK6p67rec6KernelILb0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS3_5eventESaISB_EEENKUlRNS3_7handlerEE_clESH_EUlNS3_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 2159650845 3140365237 -hashmovs1 0 16 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 2159650845 3140365237 -hashmovs1 0 16 -GRFBumpUpNumber 2 "
//.instCount 363
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill flag store 2
//.spill flag load 4

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r110.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.4)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.5)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.1)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.2)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.3)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r110.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.2)
//.declare V0036 (46)  rf=r size=32 type=d alias=+0 align=32 words (r110.0)
//.declare V0038 (48)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0039 (49)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=uq align=4 words (r5.7)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0063 (73)  rf=r size=4 type=d align=2 words (r5.4)
//.declare V0064 (74)  rf=r size=4 type=d align=2 words (r5.5)
//.declare V0065 (75)  rf=r size=4 type=d align=2 words (r5.6)
//.declare V0066 (76)  rf=r size=4 type=d align=2 words (r5.7)
//.declare V0067 (77)  rf=r size=4 type=d align=2 words (r5.8)
//.declare V0068 (78)  rf=r size=4 type=d align=2 words (r5.9)
//.declare V0069 (79)  rf=r size=4 type=d align=2 words (r5.10)
//.declare V0070 (80)  rf=r size=4 type=d align=2 words (r5.11)
//.declare V0071 (81)  rf=r size=4 type=d align=2 words (r5.12)
//.declare V0075 (85)  rf=r size=8 type=uq alias=V0062+0 align=32 words (r5.1)
//.declare V0076 (86)  rf=r size=4 type=d align=32 words (r14.0)
//.declare V0077 (87)  rf=r size=4 type=d align=2 words (r5.4)
//.declare V0078 (88)  rf=r size=4 type=ud alias=V0076+0 align=2 words (r14.0)
//.declare V0079 (89)  rf=r size=12 type=ud alias=V0038+0 align=32 words (r2.0)
//.declare V0080 (90)  rf=r size=32 type=ud alias=V0036+0 align=32 words (r110.0)
//.declare V0081 (91)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0084 (94)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0085 (95)  rf=r size=4 type=d align=32 words (r6.0)
//.declare P01 (96)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0086 (97)  rf=r size=8 type=uq alias=V0059+0 align=32 words (r4.6)
//.declare V0087 (98)  rf=r size=8 type=uq align=32 words (r106.0)
//.declare V0089 (100)  rf=r size=256 type=uq align=32 words (r6.0)
//.declare V0090 (101)  rf=r size=256 type=ud alias=V0089+0 align=32 words (r6.0)
//.declare V0091 (102)  rf=r size=8 type=ud alias=V0087+0 align=32 words (r106.0)
//.declare V0092 (103)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0093 (104)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare P02 (106)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0095 (107)  rf=r size=8 type=uq alias=V0061+0 align=32 words (r5.0)
//.declare V0097 (109)  rf=r size=8 type=q align=4 words (r2.0)
//.declare V0098 (110)  rf=r size=8 type=d alias=V0097+0 align=4 words (r2.0)
//.declare V0100 (112)  rf=r size=64 type=uw alias=V0039+0 align=32 words (r1.0)
//.declare V0105 (117)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0106 (118)  rf=r size=64 type=w align=32 words (r111.0)
//.declare V0107 (119)  rf=r size=8 type=uq align=32 words (r4.0)
//.declare V0108 (120)  rf=r size=4 type=d align=32 words (r3.0)
//.declare V0109 (121)  rf=r size=4 type=d align=2 words (r3.1)
//.declare P03 (122)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P04 (123)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0110 (124)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0111 (125)  rf=r size=64 type=uw alias=V0106+0 align=32 words (r111.0)
//.declare V0112 (126)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0113 (127)  rf=r size=128 type=ud alias=V0105+0 align=32 words (r64.0)
//.declare V0114 (128)  rf=r size=128 type=ud alias=V0112+0 align=32 words (r18.0)
//.declare V0116 (130)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0117 (131)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.2)
//.declare V0119 (133)  rf=r size=128 type=ud alias=V0116+0 align=32 words (r26.0)
//.declare V0121 (135)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0122 (136)  rf=r size=256 type=f align=32 words (r36.0)
//.declare V0123 (137)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0130 (144)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0132 (146)  rf=r size=128 type=ud alias=V0130+0 align=32 words (r10.0)
//.declare V0134 (148)  rf=r size=256 type=q align=32 words (r32.0)
//.declare V0135 (149)  rf=r size=256 type=uq alias=V0134+0 align=32 words (r32.0)
//.declare V0136 (150)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0137 (151)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0139 (153)  rf=r size=128 type=w alias=V0136+0 align=32 words (r24.0)
//.declare V0143 (157)  rf=r size=128 type=w alias=V0137+0 align=32 words (r6.0)
//.declare V0147 (161)  rf=r size=256 type=q align=32 words (r40.0)
//.declare V0148 (162)  rf=r size=256 type=uq alias=V0147+0 align=32 words (r40.0)
//.declare V0149 (163)  rf=r size=512 type=f align=32 words (r52.0)
//.declare V0150 (164)  rf=r size=512 type=f align=32 words (r44.0)
//.declare V0151 (165)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0153 (167)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0154 (168)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0155 (169)  rf=r size=128 type=f alias=V0153+0 align=32 words (r20.0)
//.declare V0158 (172)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0160 (174)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0161 (175)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0162 (176)  rf=r size=128 type=f alias=V0160+0 align=32 words (r26.0)
//.declare V0163 (177)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0165 (179)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0167 (181)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0168 (182)  rf=r size=128 type=f align=32 words (r82.0)
//.declare V0169 (183)  rf=r size=128 type=f alias=V0167+0 align=32 words (r16.0)
//.declare V0172 (186)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0174 (188)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0175 (189)  rf=r size=128 type=f align=32 words (r84.0)
//.declare V0176 (190)  rf=r size=128 type=f alias=V0174+0 align=32 words (r22.0)
//.declare V0177 (191)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0178 (192)  rf=r size=128 type=f align=32 words (r96.0)
//.declare V0179 (193)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0181 (195)  rf=r size=64 type=uw alias=V0179+0 align=32 words (r1.0)
//.declare V0182 (196)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0183 (197)  rf=r size=128 type=d align=32 words (r86.0)
//.declare V0184 (198)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0185 (199)  rf=r size=128 type=uw alias=V0183+0 align=32 words (r86.0)
//.declare V0186 (200)  rf=r size=64 type=uw align=32 words (r10.0)
//.declare A00 (201)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P05 (202)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0189 (205)  rf=r size=128 type=f align=32 words (r98.0)
//.declare V0190 (206)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0191 (207)  rf=r size=128 type=d align=32 words (r94.0)
//.declare V0192 (208)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0193 (209)  rf=r size=128 type=uw alias=V0191+0 align=32 words (r94.0)
//.declare V0194 (210)  rf=r size=64 type=uw align=32 words (r11.0)
//.declare A01 (211)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P06 (212)  rf=f32  size=4 type=uw align=2 words (spilled -> )
//.declare V0197 (215)  rf=r size=128 type=f align=32 words (r100.0)
//.declare V0198 (216)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0199 (217)  rf=r size=128 type=d align=32 words (r92.0)
//.declare V0200 (218)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0201 (219)  rf=r size=128 type=uw alias=V0199+0 align=32 words (r92.0)
//.declare V0202 (220)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare A02 (221)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P07 (222)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0205 (225)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0206 (226)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0207 (227)  rf=r size=128 type=d align=32 words (r90.0)
//.declare V0208 (228)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0209 (229)  rf=r size=128 type=uw alias=V0207+0 align=32 words (r90.0)
//.declare V0210 (230)  rf=r size=64 type=uw align=32 words (r5.0)
//.declare A03 (231)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P08 (232)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0213 (235)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0214 (236)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0215 (237)  rf=r size=128 type=d align=32 words (r88.0)
//.declare V0216 (238)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0217 (239)  rf=r size=128 type=uw alias=V0215+0 align=32 words (r88.0)
//.declare V0218 (240)  rf=r size=64 type=uw align=32 words (r4.0)
//.declare A04 (241)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P09 (242)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0220 (244)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0223 (247)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0229 (253)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0236 (260)  rf=r size=256 type=uq align=32 words (r40.0)
//.declare V0238 (262)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare V0239 (263)  rf=r size=128 type=w alias=V0238+0 align=32 words (r20.0)
//.declare V0241 (265)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0243 (267)  rf=r size=128 type=f alias=V0241+0 align=32 words (r4.0)
//.declare V0244 (268)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0246 (270)  rf=r size=128 type=f align=32 words (r120.0)
//.declare V0248 (272)  rf=r size=128 type=f align=32 words (r112.0)
//.declare V0249 (273)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0250 (274)  rf=r size=128 type=d alias=V0246+0 align=32 words (r120.0)
//.declare P10 (275)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0251 (276)  rf=r size=128 type=ud alias=V0249+0 align=32 words (r6.0)
//.declare V0252 (277)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0253 (278)  rf=r size=128 type=ud alias=V0246+0 align=32 words (r120.0)
//.declare V0254 (279)  rf=r size=128 type=ud alias=V0252+0 align=32 words (r4.0)
//.declare V0255 (280)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0256 (281)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0257 (282)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0258 (283)  rf=r size=128 type=ud alias=V0256+0 align=32 words (r8.0)
//.declare V0259 (284)  rf=r size=128 type=ud alias=V0257+0 align=32 words (r10.0)
//.declare V0260 (285)  rf=r size=64 type=w align=32 words (r26.0)
//.declare V0261 (286)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0262 (287)  rf=r size=128 type=ud alias=V0261+0 align=32 words (r4.0)
//.declare V0265 (290)  rf=r size=128 type=f align=32 words (r124.0)
//.declare V0267 (292)  rf=r size=128 type=f align=32 words (r116.0)
//.declare V0268 (293)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0269 (294)  rf=r size=128 type=d alias=V0265+0 align=32 words (r124.0)
//.declare P11 (295)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0270 (296)  rf=r size=128 type=ud alias=V0268+0 align=32 words (r4.0)
//.declare V0271 (297)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0272 (298)  rf=r size=128 type=ud alias=V0265+0 align=32 words (r124.0)
//.declare V0273 (299)  rf=r size=128 type=ud alias=V0271+0 align=32 words (r4.0)
//.declare V0274 (300)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0275 (301)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0276 (302)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0277 (303)  rf=r size=128 type=ud alias=V0275+0 align=32 words (r8.0)
//.declare V0278 (304)  rf=r size=128 type=ud alias=V0276+0 align=32 words (r10.0)
//.declare V0279 (305)  rf=r size=64 type=w align=32 words (r25.0)
//.declare V0280 (306)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0281 (307)  rf=r size=128 type=ud alias=V0280+0 align=32 words (r4.0)
//.declare V0284 (310)  rf=r size=128 type=f align=32 words (r122.0)
//.declare V0286 (312)  rf=r size=128 type=f align=32 words (r114.0)
//.declare V0287 (313)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0288 (314)  rf=r size=128 type=d alias=V0284+0 align=32 words (r122.0)
//.declare P12 (315)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0289 (316)  rf=r size=128 type=ud alias=V0287+0 align=32 words (r4.0)
//.declare V0290 (317)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0291 (318)  rf=r size=128 type=ud alias=V0284+0 align=32 words (r122.0)
//.declare V0292 (319)  rf=r size=128 type=ud alias=V0290+0 align=32 words (r4.0)
//.declare V0293 (320)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0294 (321)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0295 (322)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0296 (323)  rf=r size=128 type=ud alias=V0294+0 align=32 words (r8.0)
//.declare V0297 (324)  rf=r size=128 type=ud alias=V0295+0 align=32 words (r10.0)
//.declare V0298 (325)  rf=r size=64 type=w align=32 words (r24.0)
//.declare V0299 (326)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0300 (327)  rf=r size=128 type=ud alias=V0299+0 align=32 words (r4.0)
//.declare V0303 (330)  rf=r size=128 type=f align=32 words (r118.0)
//.declare V0305 (332)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0306 (333)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0307 (334)  rf=r size=128 type=d alias=V0303+0 align=32 words (r118.0)
//.declare P13 (335)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0308 (336)  rf=r size=128 type=ud alias=V0306+0 align=32 words (r4.0)
//.declare V0309 (337)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0310 (338)  rf=r size=128 type=ud alias=V0303+0 align=32 words (r118.0)
//.declare V0311 (339)  rf=r size=128 type=ud alias=V0309+0 align=32 words (r4.0)
//.declare V0312 (340)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0313 (341)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0314 (342)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0315 (343)  rf=r size=128 type=ud alias=V0313+0 align=32 words (r8.0)
//.declare V0316 (344)  rf=r size=128 type=ud alias=V0314+0 align=32 words (r10.0)
//.declare V0317 (345)  rf=r size=64 type=w align=32 words (r14.0)
//.declare V0318 (346)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0319 (347)  rf=r size=128 type=ud alias=V0318+0 align=32 words (r4.0)
//.declare V0321 (349)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0322 (350)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare A05 (351)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0324 (353)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0325 (354)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0326 (355)  rf=r size=64 type=uw align=32 words (r2.0)
//.declare A06 (356)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0328 (358)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0329 (359)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0330 (360)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare A07 (361)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0332 (363)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0333 (364)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0334 (365)  rf=r size=64 type=uw align=32 words (r2.0)
//.declare A08 (366)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0336 (368)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0337 (369)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0338 (370)  rf=r size=64 type=uw align=32 words (r1.0)
//.declare A09 (371)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare V0340 (373)  rf=r size=128 type=f align=32 words (r126.0)
//.declare P14 (374)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0341 (375)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0342 (376)  rf=r size=128 type=d alias=V0340+0 align=32 words (r126.0)
//.declare P15 (377)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0343 (378)  rf=r size=4 type=ud alias=V0341+0 align=2 words (r1.0)
//.declare V0344 (379)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0345 (380)  rf=r size=128 type=ud alias=V0340+0 align=32 words (r126.0)
//.declare V0346 (381)  rf=r size=4 type=ud alias=V0344+0 align=2 words (r1.0)
//.declare V0347 (382)  rf=r size=4 type=d align=2 words (r2.0)
//.declare V0348 (383)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0349 (384)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0350 (385)  rf=r size=4 type=ud alias=V0348+0 align=2 words (r3.0)
//.declare V0351 (386)  rf=r size=4 type=ud alias=V0349+0 align=2 words (r4.0)
//.declare V0352 (387)  rf=r size=2 type=w align=2 words (r3.0)
//.declare V0353 (388)  rf=r size=4 type=d align=2 words (r1.0)
//.declare V0354 (389)  rf=r size=4 type=ud alias=V0353+0 align=2 words (r1.0)
//.declare V0358 (393)  rf=r size=256 type=uq align=32 words (r4.0)
//.declare V0359 (394)  rf=r size=2 type=uw alias=V0352+0 align=1 words (r3.0)
//.declare V0360 (395)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare V0362 (397)  rf=r size=256 type=q align=32 words (r6.0)
//.declare V0365 (400)  rf=r size=256 type=uq alias=V0362+0 align=32 words (r6.0)
//.declare V0366 (401)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0367 (402)  rf=r size=128 type=w alias=V0366+0 align=32 words (r10.0)
//.declare V0368 (403)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0369 (404)  rf=r size=128 type=w alias=V0368+0 align=32 words (r12.0)
//.declare P16 (405)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0372 (408)  rf=r size=256 type=uq align=32 words (r1.0)
//.declare V0373 (409)  rf=r size=256 type=ud alias=V0372+0 align=32 words (r1.0)
//.declare V0374 (410)  rf=r size=128 type=d align=32 words (r6.0)
//.declare  (411)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (412)  rf=r size=128 type=w alias=V0261+0 align=32 words (r4.0)
//.declare  (413)  rf=r size=128 type=w alias=V0280+0 align=32 words (r4.0)
//.declare  (414)  rf=r size=128 type=w alias=V0299+0 align=32 words (r4.0)
//.declare  (415)  rf=r size=128 type=w alias=V0318+0 align=32 words (r4.0)
//.declare  (416)  rf=r size=2 type=w alias=V0353+0 align=1 words (r1.0)
//.declare  (419)  rf=r size=128 type=uw align=32 words (r6.0)
//.declare  (420)  rf=r size=128 type=uw align=32 words (r10.0)
//.declare  (421)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (422)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (423)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare  (424)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (427)  rf=r size=128 type=w alias=V0257+0 align=32 words (r10.0)
//.declare  (428)  rf=r size=128 type=w alias=V0276+0 align=32 words (r10.0)
//.declare  (429)  rf=r size=128 type=w alias=V0295+0 align=32 words (r10.0)
//.declare  (430)  rf=r size=128 type=w alias=V0314+0 align=32 words (r10.0)
//.declare  (433)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (434)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (435)  rf=r size=128 type=q align=32 words (r62.0)
//.declare  (436)  rf=r size=128 type=q align=32 words (r60.0)
//.declare  (437)  rf=r size=128 type=q align=32 words (r4.0)
//.declare  (438)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (441)  rf=r size=128 type=q align=32 words (r30.0)
//.declare  (442)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (443)  rf=r size=128 type=d align=32 words (r20.0)
//.declare  (444)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (445)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (446)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (447)  rf=r size=128 type=q align=32 words (r78.0)
//.declare  (448)  rf=r size=128 type=q align=32 words (r76.0)
//.declare  (449)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (450)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (453)  rf=r size=128 type=q align=32 words (r70.0)
//.declare  (454)  rf=r size=128 type=q align=32 words (r68.0)
//.declare  (455)  rf=r size=128 type=q align=32 words (r4.0)
//.declare  (456)  rf=r size=128 type=q align=32 words (r28.0)
//.declare  (457)  rf=r size=128 type=q align=32 words (r72.0)
//.declare  (458)  rf=r size=128 type=q align=32 words (r74.0)
//.declare  (459)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (460)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (461)  rf=r size=128 type=d align=32 words (r28.0)
//.declare  (463)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (464)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (465)  rf=r size=128 type=q align=32 words (r30.0)
//.declare  (466)  rf=r size=128 type=q align=32 words (r32.0)
//.declare  (467)  rf=r size=128 type=d align=32 words (r26.0)
//.declare  (469)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (470)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (475)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (476)  rf=r size=128 type=q align=32 words (r4.0)
//.declare  (477)  rf=r size=128 type=uq alias=+0 align=32 words (r62.0)
//.declare  (478)  rf=r size=128 type=uq alias=+0 align=32 words (r8.0)
//.declare  (479)  rf=r size=128 type=uq alias=+0 align=32 words (r60.0)
//.declare  (480)  rf=r size=128 type=uq alias=+0 align=32 words (r12.0)
//.declare  (481)  rf=r size=128 type=d alias=+0 align=32 words (r62.0)
//.declare  (482)  rf=r size=128 type=d alias=+0 align=32 words (r60.0)
//.declare  (483)  rf=r size=128 type=d alias=+0 align=32 words (r4.0)
//.declare  (484)  rf=r size=128 type=d alias=+0 align=32 words (r6.0)
//.declare  (485)  rf=r size=128 type=d alias=+0 align=32 words (r14.0)
//.declare  (486)  rf=r size=128 type=d alias=+0 align=32 words (r16.0)
//.declare  (487)  rf=r size=128 type=d alias=+0 align=32 words (r20.0)
//.declare  (488)  rf=r size=128 type=d alias=+0 align=32 words (r22.0)
//.declare  (489)  rf=r size=128 type=d alias=+0 align=32 words (r10.0)
//.declare  (490)  rf=r size=128 type=d alias=+0 align=32 words (r16.0)
//.declare  (491)  rf=r size=128 type=d alias=+0 align=32 words (r72.0)
//.declare  (492)  rf=r size=128 type=d alias=+0 align=32 words (r74.0)
//.declare  (493)  rf=r size=128 type=d alias=+0 align=32 words (r12.0)
//.declare  (494)  rf=r size=128 type=d alias=+0 align=32 words (r18.0)
//.declare  (495)  rf=r size=4 type=uw align=2 words (r3.0)
//.declare  (496)  rf=r size=4 type=uw align=2 words (r2.0)
//.declare  (497)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (498)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (499)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (500)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (501)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (502)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (503)  rf=r size=64 type=d align=32 words (r1.0)
//.declare  (504)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (505)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (506)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (507)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (508)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (509)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (510)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (511)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (512)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (513)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (514)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (515)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (516)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (517)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (518)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (519)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (520)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (521)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (522)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (523)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (524)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (525)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (526)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (527)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (528)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (529)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (530)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (531)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (532)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (533)  rf=r size=64 type=d align=32 words (r31.0)
//.declare  (534)  rf=r size=64 type=d align=32 words (r32.0)
//.declare  (535)  rf=r size=64 type=d align=32 words (r33.0)
//.declare  (536)  rf=r size=64 type=d align=32 words (r34.0)
//.declare  (537)  rf=r size=64 type=d align=32 words (r35.0)
//.declare  (538)  rf=r size=64 type=d align=32 words (r36.0)
//.declare  (539)  rf=r size=64 type=d align=32 words (r37.0)
//.declare  (540)  rf=r size=64 type=d align=32 words (r38.0)
//.declare  (541)  rf=r size=64 type=d align=32 words (r39.0)
//.declare  (542)  rf=r size=64 type=d align=32 words (r40.0)
//.declare  (543)  rf=r size=64 type=d align=32 words (r41.0)
//.declare  (544)  rf=r size=64 type=d align=32 words (r42.0)
//.declare  (545)  rf=r size=64 type=d align=32 words (r43.0)
//.declare r0 (546)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (547)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (548)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (549)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (550)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (551)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (552)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0039    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0038    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0034    | :uq      |    0x8 | r2+0x10  | inline+0x10      |
// | V0044    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0045    | :q       |    0x8 | r3       | cti+0x20         |
// | V0046    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0047    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0048    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0049    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0050    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0051    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0052    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0053    | :q       |    0x8 | r4       | cti+0x60         |
// | V0054    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0055    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0056    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0057    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0058    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0059    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0060    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0061    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0062    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0063    | :d       |    0x4 | r5+0x10  | cti+0xB0         |
// | V0064    | :d       |    0x4 | r5+0x14  | cti+0xB4         |
// | V0065    | :d       |    0x4 | r5+0x18  | cti+0xB8         |
// | V0066    | :d       |    0x4 | r5+0x1C  | cti+0xBC         |
// | V0067    | :d       |    0x4 | r5+0x20  | cti+0xC0         |
// | V0068    | :d       |    0x4 | r5+0x24  | cti+0xC4         |
// | V0069    | :d       |    0x4 | r5+0x28  | cti+0xC8         |
// | V0070    | :d       |    0x4 | r5+0x2C  | cti+0xCC         |
// | V0071    | :d       |    0x4 | r5+0x30  | cti+0xD0         |
// | V0042    | :uq      |    0x8 | r5+0x38  | cti+0xD8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B025}
// _main:
(W)     mov (16|M0)              r110.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
        sync.nop                             null                             {Compacted,A@1}        // $9
        sync.nop                             null                             {Compacted,$2.dst}     // $9
(W)     mov (1|M0)               r4.0<1>:uq    r5.1<0;1,0>:uq                   {Compacted,A@1,$1.dst} //  ALU pipe: int; $9
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r110.2<0;1,0>:uw {I@4}              //  ALU pipe: int; $2
(W)     load.ugm.d32x1t.a64 (1|M0)  r6:1        [r4:1]             {I@2,$3} // ex_desc:0x0; desc:0x2108580 // $10
(W)     macl (1|M0)              r14.0<1>:ud   r2.0<0;1,0>:ud    r110.1<0;1,0>:ud {Compacted}        //  ALU pipe: int; $3
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r110.2<0;1,0>:uw                    //  ALU pipe: int; $3
(W)     mach (1|M0)              r3.0<1>:d     r2.0<0;1,0>:ud    r110.1<0;1,0>:ud                    //  ALU pipe: int; 
(W)     mov (1|M0)               r5.4<1>:d     r3.0<0;1,0>:d                    {Compacted,I@1}      //  ALU pipe: int; $8
(W)     cmp (32|M0)   (eq)f1.0   null<1>:d     r6.0<0;1,0>:d     0:w               {$3.dst}          //  ALU pipe: int; $11
(W&f1.0) jmpi                                _0_028                                                  //  ALU pipe: int; $12
// B003: Preds:{B002},  Succs:{B004, B025}
_0_029:
(W)     mov (1|M0)               r106.0<1>:uq  r4.6<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $14
        mov (32|M0)              r10.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $17
        mov (16|M0)              r6.0<2>:f     r106.0<0;1,0>:f                  {I@2}                //  ALU pipe: float; $15
        mov (16|M16)             r8.0<2>:f     r106.0<0;1,0>:f                                       //  ALU pipe: float; $15
        mov (16|M0)              r6.1<2>:f     r106.1<0;1,0>:f                                       //  ALU pipe: float; $16
        mov (16|M16)             r8.1<2>:ud    r106.1<0;1,0>:ud                 {F@2}                //  ALU pipe: int; $16
        atomic_or.ugm.d32.a64 (32|M0)  r12:2    [r6:4]            r10:2              {A@1,$4} // ex_desc:0x0; desc:0x8200599 // $18
        cmp (32|M0)   (eq)f0.0   null<1>:d     r12.0<1;1,0>:d    0:w               {$4.dst}          //  ALU pipe: int; $20
(~f0.0) goto (32|M0)                         _0_028            _0_028                                //  ALU pipe: int; $21
// B004: [inDivergent],  Preds:{B003},  Succs:{B005, B023}
_0_030:
(W)     mov (1|M0)               r4.0<1>:uq    r5.0<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $32
(W)     add (1|M0)               r3.1<1>:d     r5.10<0;1,0>:d    -r5.5<0;1,0>:d                      //  ALU pipe: int; $34
(W)     load.ugm.d32x1t.a64 (1|M0)  r3:1        [r4:1]             {I@1,$5} // ex_desc:0x0; desc:0x2108580 // $33
(W)     mov (1|M0)               r2.0<1>:f     r14.0<0;1,0>:f                   {Compacted}          //  ALU pipe: float; $23
(W)     mov (1|M0)               r2.1<1>:d     r5.4<0;1,0>:d                                         //  ALU pipe: int; $24
        mov (16|M0)              r6.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $28
        mov (16|M16)             r10.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $28
        and (32|M0)              r111.0<1>:w   r1.0<1;1,0>:w     31:w                                //  ALU pipe: int; $31
        add (16|M0)              r8.0<1>:q     r2.0<0;1,0>:q     r6.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $28
        add (16|M16)             r12.0<1>:q    r2.0<0;1,0>:q     r10.0<4;1,0>:uw  {I@3}              //  ALU pipe: int; $28
        mov (32|M0)              r66.0<1>:d    r111.0<1;1,0>:uw                 {I@3}                //  ALU pipe: int; $38
        shr (16|M0)              r62.0<1>:uq   r8.0<1;1,0>:uq    5:w               {I@3}             //  ALU pipe: int; $29
        shr (16|M16)             r60.0<1>:uq   r12.0<1;1,0>:uq   5:w               {I@3}             //  ALU pipe: int; $29
        mov (16|M0)              r64.0<1>:d    r62.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $30
        mov (16|M16)             r65.0<1>:d    r60.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $30
(W)     cmp (32|M0)   (gt)f2.0   null<1>:d     r3.0<0;1,0>:d     r3.1<0;1,0>:d    {$5.dst}           //  ALU pipe: int; $35
(W&~f2.0) cmp (32|M0) (lt)f2.0   null<1>:d     r3.0<0;1,0>:d     0:w                                 //  ALU pipe: int; $36
(W&f2.0) jmpi                                _0_031                                                  //  ALU pipe: int; $39
// B005: [inDivergent],  Preds:{B004},  Succs:{B006, B007}
_0_032:
        shl (16|M0)              r4.0<1>:q     r62.0<1;1,0>:q    7:w               {Compacted}       //  ALU pipe: int; $42
        shl (16|M16)             r6.0<1>:q     r60.0<1;1,0>:q    7:w               {Compacted}       //  ALU pipe: int; $42
        and (16|M0)              r12.0<1>:d    r4.0<2;1,0>:d     -128:w               {Compacted,I@2} //  ALU pipe: int; $48
        and (16|M16)             r13.0<1>:d    r6.0<2;1,0>:d     -128:w               {Compacted,I@2} //  ALU pipe: int; $49
        mov (32|M0)              r8.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $51
        mov (32|M0)              r20.0<1>:f    r12.0<1;1,0>:f                   {Compacted,I@2}      //  ALU pipe: float; $50
        shl (32|M0)              r10.0<1>:d    r66.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $58
        shr (32|M0)              r18.0<1>:ud   r64.0<1;1,0>:ud   7:w                                 //  ALU pipe: int; $41
        mov (16|M0)              r14.1<2>:d    r8.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $54
        mov (16|M16)             r16.1<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $55
        mov (16|M0)              r14.0<2>:d    r20.0<1;1,0>:d                   {F@1}                //  ALU pipe: int; $52
        mov (16|M16)             r16.0<2>:d    r21.0<1;1,0>:d                                        //  ALU pipe: int; $53
        mov (16|M0)              r22.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted,I@6}      //  ALU pipe: int; $60
        mov (16|M16)             r24.0<2>:ud   r11.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $60
        shl (16|M0)              r78.0<1>:q    r14.0<1;1,0>:q    1:w               {Compacted,I@4}   //  ALU pipe: int; $56
        shl (16|M16)             r76.0<1>:q    r16.0<1;1,0>:q    1:w               {Compacted,I@4}   //  ALU pipe: int; $56
        mul (32|M0)              r26.0<1>:d    r18.0<1;1,0>:d    260:w               {Compacted}     //  ALU pipe: int; $43
        shl (16|M0)              r70.0<1>:q    r22.0<2;1,0>:ud   1:w               {I@5}             //  ALU pipe: int; $60
        shl (16|M16)             r68.0<1>:q    r24.0<2;1,0>:ud   1:w               {I@5}             //  ALU pipe: int; $60
        add (16|M0)              r10.0<1>:q    r78.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@5}    //  ALU pipe: int; $57
        add (16|M16)             r18.0<1>:q    r76.0<1;1,0>:q    r3.4<0;1,0>:q    {Compacted,I@5}    //  ALU pipe: int; $57
        add (16|M0)              r32.0<1>:q    r10.0<1;1,0>:q    r70.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $61
        add (16|M16)             r34.0<1>:q    r18.0<1;1,0>:q    r68.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $61
        mov (16|M0)              r6.0<2>:ud    r26.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $45
        mov (16|M16)             r12.0<2>:ud   r27.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $45
        shl (16|M16)             r28.0<1>:q    r24.0<2;1,0>:ud   2:w                                 //  ALU pipe: int; $68
        load.ugm.d32.a64 (32|M0)  r24:2         [r32:4]            {I@1,$6} // ex_desc:0x0; desc:0x8200580 // $62
        shl (16|M0)              r30.0<1>:q    r6.0<2;1,0>:ud    2:w                                 //  ALU pipe: int; $45
        shl (16|M16)             r20.0<1>:q    r12.0<2;1,0>:ud   2:w                                 //  ALU pipe: int; $45
        load.ugm.d32.a64 (32|M0)  r6:2          [r32:4+0x4]        {I@2,$7} // ex_desc:0x4000; desc:0x8200580 // $63
        add (16|M0)              r14.0<1>:q    r30.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted}        //  ALU pipe: int; $46
        add (16|M16)             r16.0<1>:q    r20.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $46
        shl (16|M0)              r4.0<1>:q     r22.0<2;1,0>:ud   2:w                                 //  ALU pipe: int; $68
        load.ugm.d32x2.a64 (32|M0)  r36:4       [r14:4+0x400]      {I@2,$8} // ex_desc:0x400000; desc:0x8401580 // $47
        add (16|M16)             r42.0<1>:q    r16.0<1;1,0>:q    r28.0<1;1,0>:q   {Compacted}        //  ALU pipe: int; $69
        add (16|M0)              r40.0<1>:q    r14.0<1;1,0>:q    r4.0<1;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $69
        load.ugm.d32x4.a64 (32|M0)  r44:8       [r40:4+0x200]      {I@1,$9} // ex_desc:0x200000; desc:0x8803580 // $71
(W)     mov (8|M0)               r1.0<1>:w     0x76543210:v                                          //  ALU pipe: int; $92
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $99
(W)     add (8|M0)               r1.8<1>:w     r1.0<1;1,0>:w     8:w               {I@2}             //  ALU pipe: int; $93
        shl (16|M0)              r72.0<1>:q    r62.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $160
(W)     add (16|M0)              r1.16<1>:w    r1.0<1;1,0>:w     16:w               {I@2}            //  ALU pipe: int; $94
        add (32|M0)              r22.0<1>:d    r1.0<1;1,0>:uw    1:w               {I@1}             //  ALU pipe: int; $96
        and (32|M0)              r86.0<1>:d    r22.0<1;1,0>:d    31:w               {Compacted,I@1}  //  ALU pipe: int; $97
        shl (32|M0)              r10.0<1>:uw   r86.0<2;1,0>:uw   0x2:uw              {I@1}           //  ALU pipe: int; $98
        mov (32|M0)              r12.0<1>:d    r24.0<2;1,0>:uw                  {$6.dst}             //  ALU pipe: int; $72
        mov (32|M0)              r18.0<1>:d    r24.1<2;1,0>:uw                                       //  ALU pipe: int; $77
        shl (32|M0)              r20.0<1>:d    r12.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $73
        mov (32|M0)              r30.0<1>:d    r6.0<2;1,0>:uw                   {$7.dst}             //  ALU pipe: int; $82
        shl (32|M0)              r26.0<1>:d    r18.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $78
        shl (32|M0)              r16.0<1>:d    r30.0<1;1,0>:d    16:w               {Compacted,@2,$8.src} //  ALU pipe: int; $83
        mul (32|M0)              r14.0<1>:f    r36.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,$8.dst} //  ALU pipe: float; $74 R{} IR{}{E:2,E:2,},  R{} IR{}{O:2,O:10,},  {BC=1}
        mov (32|M0)              r4.0<1>:d     r6.1<2;1,0>:uw                                        //  ALU pipe: int; $87
        mul (32|M0)              r80.0<1>:f    r36.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $79
        mul (32|M0)              r82.0<1>:f    r36.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $84
        mul (32|M0)              acc2.0<1>:f   r14.0<1;1,0>:f    r44.0<1;1,0>:f   {Compacted,@3,$9.dst} //  ALU pipe: float; $75
        shl (32|M0)              r22.0<1>:d    r4.0<1;1,0>:d     16:w               {Compacted,I@1}  //  ALU pipe: int; $88
        mul (32|M0)              r28.0<1>:f    r80.0<1;1,0>:f    r46.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $80
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   0x0:f               {Compacted}     //  ALU pipe: float; $76
        mul (32|M0)              r84.0<1>:f    r36.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $89
        mul (32|M0)              acc0.0<1>:f   r82.0<1;1,0>:f    r48.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $85
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r28.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $81
        mul (32|M0)              r12.0<1>:f    r84.0<1;1,0>:f    r50.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $90
        add (32|M0)              acc0.0<1>:f   acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $86
        and (32|M0)   (eq)f3.0   null<1>:d     r1.0<1;1,0>:uw    1:w                                 //  ALU pipe: int; $105
        add (16|M0)              a0.0<1>:uw    r10.0<1;1,0>:uw   0x1800:uw                           //  ALU pipe: int; src1 is addr of V0178(r96.0:f); $100
        add (32|M0)              r96.0<1>:f    acc0.0<1;1,0>:f   r12.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $91
        add (32|M0)              r4.0<1>:d     r1.0<1;1,0>:uw    2:w                                 //  ALU pipe: int; $109
(W)     mov (1|M0)               r2.0<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $105
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $101
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $102
        add (16|M16)             a0.0<1>:uw    r10.16<1;1,0>:uw  0x1800:uw                           //  ALU pipe: int; src1 is addr of V0178(r96.0:f); $103
        and (32|M0)              r94.0<1>:d    r4.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $110
(W)     mov (1|M0)               f2.0<1>:ud    r2.0<0;1,0>:ud                   {Compacted,I@5}      //  ALU pipe: int; $107
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $104
        shl (32|M0)              r11.0<1>:uw   r94.0<2;1,0>:uw   0x2:uw              {I@3}           //  ALU pipe: int; $111
(f2.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $107
        and (32|M0)   (eq)f1.0   null<1>:d     r1.0<1;1,0>:uw    3:w                                 //  ALU pipe: int; $118
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $112
        add (16|M0)              a0.0<1>:uw    r11.0<1;1,0>:uw   0x1880:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0189(r98.0:f); $113
        add (32|M0)              r98.0<1>:f    r96.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $108
        add (32|M0)              r16.0<1>:d    r1.0<1;1,0>:uw    4:w                                 //  ALU pipe: int; $122
(W)     mov (1|M0)               r3.0<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $118
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $114
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $115
        add (16|M16)             a0.0<1>:uw    r11.16<1;1,0>:uw  0x1880:uw                           //  ALU pipe: int; src1 is addr of V0189(r98.0:f); $116
        and (32|M0)              r92.0<1>:d    r16.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $123
(W)     mov (1|M0)               f0.0<1>:ud    r3.0<0;1,0>:ud                   {Compacted,I@5}      //  ALU pipe: int; $120
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $117
        shl (32|M0)              r4.0<1>:uw    r92.0<2;1,0>:uw   0x2:uw              {I@3}           //  ALU pipe: int; $124
(f0.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $120
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $125
        add (16|M0)              a0.0<1>:uw    r4.0<1;1,0>:uw    0x1900:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0197(r100.0:f); $126
        add (32|M0)              r100.0<1>:f   r98.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $121
        add (32|M0)              r10.0<1>:d    r1.0<1;1,0>:uw    8:w                                 //  ALU pipe: int; $135
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $127
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $128
        add (16|M16)             a0.0<1>:uw    r4.16<1;1,0>:uw   0x1900:uw                           //  ALU pipe: int; src1 is addr of V0197(r100.0:f); $129
        and (32|M0)   (eq)f2.0   null<1>:d     r1.0<1;1,0>:uw    7:w                                 //  ALU pipe: int; $131
        and (32|M0)              r90.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $136
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $130
        shl (32|M0)              r5.0<1>:uw    r90.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $137
(f2.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $133
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $138
        add (16|M0)              a0.0<1>:uw    r5.0<1;1,0>:uw    0x1980:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0205(r102.0:f); $139
        add (32|M0)              r102.0<1>:f   r100.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $134
        add (32|M0)              r16.0<1>:d    r1.0<1;1,0>:uw    16:w                                //  ALU pipe: int; $148
        mov (16|M0)              r12.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $140
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $141
        add (16|M16)             a0.0<1>:uw    r5.16<1;1,0>:uw   0x1980:uw                           //  ALU pipe: int; src1 is addr of V0205(r102.0:f); $142
        and (32|M0)   (eq)f1.0   null<1>:d     r1.0<1;1,0>:uw    15:w                                //  ALU pipe: int; $144
        and (32|M0)              r88.0<1>:d    r16.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $149
        mov (16|M16)             r13.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $143
        shl (32|M0)              r4.0<1>:uw    r88.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $150
(f1.0)  sel (32|M0)              acc0.0<1>:f   r12.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $146
        shl (16|M16)             r74.0<1>:q    r60.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $160
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $151
        add (16|M0)              a0.0<1>:uw    r4.0<1;1,0>:uw    0x1A00:uw              {I@3}        //  ALU pipe: int; src1 is addr of V0213(r104.0:f); $152
        add (32|M0)              r104.0<1>:f   r102.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $147
        add (16|M0)              r20.0<1>:q    r72.0<1;1,0>:q    8192:w                              //  ALU pipe: int; $161
        add (16|M16)             r22.0<1>:q    r74.0<1;1,0>:q    8192:w               {I@4}          //  ALU pipe: int; $161
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $153
        and (16|M16)             r5.0<1>:d     r22.0<2;1,0>:d    268435200:d               {I@2}     //  ALU pipe: int; $163
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $154
        add (16|M16)             a0.0<1>:uw    r4.16<1;1,0>:uw   0x1A00:uw                           //  ALU pipe: int; src1 is addr of V0213(r104.0:f); $155
        and (16|M0)              r4.0<1>:d     r20.0<2;1,0>:d    268435200:d                         //  ALU pipe: int; $162
        and (16|M0)              r24.0<1>:d    r72.0<2;1,0>:d    254:w               {Compacted}     //  ALU pipe: int; $171
        and (16|M16)             r25.0<1>:d    r74.0<2;1,0>:d    254:w               {Compacted}     //  ALU pipe: int; $172
        mov (32|M0)              r28.0<1>:f    r4.0<1;1,0>:f                    {Compacted,I@3}      //  ALU pipe: float; $164
        mov (16|M0)              r10.1<2>:d    r8.0<1;1,0>:d                                         //  ALU pipe: int; $168
        mov (16|M16)             r16.1<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $169
        mov (32|M0)              r26.0<1>:f    r24.0<1;1,0>:f                   {Compacted,I@3}      //  ALU pipe: float; $173
        mov (16|M0)              r10.0<2>:d    r28.0<1;1,0>:d                   {F@2}                //  ALU pipe: int; $166
        mov (16|M16)             r16.0<2>:d    r29.0<1;1,0>:d                                        //  ALU pipe: int; $167
        mov (16|M16)             r18.1<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $178
        mov (16|M0)              r12.1<2>:d    r8.0<1;1,0>:d                                         //  ALU pipe: int; $177
        add (16|M0)              r30.0<1>:q    r10.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $170
        add (16|M16)             r32.0<1>:q    r16.0<1;1,0>:q    r2.3<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $170
        mov (16|M16)             r18.0<2>:d    r27.0<1;1,0>:d                   {F@1}                //  ALU pipe: int; $176
        mov (16|M0)              r12.0<2>:d    r26.0<1;1,0>:d                                        //  ALU pipe: int; $175
        load.ugm.d32x4.a64 (32|M0)  r52:8       [r40:4]            {$10} // ex_desc:0x0; desc:0x8803580 // $70
        add (16|M0)              r40.0<1>:q    r30.0<1;1,0>:q    r12.0<1;1,0>:q   {Compacted,@1,$10.src} //  ALU pipe: int; $179
        add (16|M16)             r42.0<1>:q    r32.0<1;1,0>:q    r18.0<1;1,0>:q   {Compacted}        //  ALU pipe: int; $179
        load.ugm.d16u32.a64 (32|M0)  r20:2      [r40:4]            {I@1,$11} // ex_desc:0x0; desc:0x8200B80 // $181
        cmp (32|M0)   (eq)f0.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $157
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $156
(f0.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $158
        add (32|M0)              r8.0<1>:f     r104.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $159
        shl (32|M0)              r4.0<1>:d     r20.0<1;1,0>:ud   16:w               {$11.dst}        //  ALU pipe: int; $182
        add (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     -r8.0<0;1,0>:f   {A@1}              //  ALU pipe: float; $183
        mul (32|M0)              r108.0<1>:f   acc0.0<1;1,0>:f   r38.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $184
        mul (32|M0)              acc0.0<1>:f   r108.0<1;1,0>:f   r44.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $185 R{} IR{}{E:6,E:6,},  R{} IR{}{O:6,O:6,},  {BC=2}
        add (32|M0)              r120.0<1>:f   r14.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $186
        and (32|M0)              r6.0<1>:d     r120.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $189
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r6.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $190
        mul (32|M0)              acc0.0<1>:f   r120.0<1;1,0>:f   r52.0<1;1,0>:f   {Compacted,$10.dst} //  ALU pipe: float; $187
        add (32|M0)              r112.0<1>:f   acc0.0<1;1,0>:f   0x0:f               {Compacted}     //  ALU pipe: float; $188
(f3.0)  goto (32|M0)                         _0_033            _0_033                                //  ALU pipe: int; $191
// B006: [inDivergent],  Preds:{B005},  Succs:{B008}
_0_034:
        shr (32|M0)              r4.0<1>:ud    r120.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $193
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $194
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r120.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $195
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $196
        mov (32|M0)              r26.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $197
        goto (32|M0)                         _0_033            _0_035                                // $198
// B007: [inDivergent],  Preds:{B005},  Succs:{B008}
_0_033:
        join (32|M0)                         _0_035                                                  // 
L2848:
        shr (32|M0)              r4.0<1>:ud    r120.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $200
        or (32|M0)               r26.0<1>:w    r4.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $202
// B008: [inDivergent],  Preds:{B007, B006},  Succs:{B009, B010}
_0_035:
        join (32|M0)                         _0_028                                                  // 
L2896:
        mul (32|M0)              acc0.0<1>:f   r108.0<1;1,0>:f   r46.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $204
        add (32|M0)              r124.0<1>:f   r80.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $205
        and (32|M0)              r4.0<1>:d     r124.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $208
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r4.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $209
        mul (32|M0)              acc0.0<1>:f   r124.0<1;1,0>:f   r54.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $206
        add (32|M0)              r116.0<1>:f   r112.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $207
(f3.0)  goto (32|M0)                         _0_036            _0_036                                //  ALU pipe: int; $210
// B009: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_037:
        shr (32|M0)              r4.0<1>:ud    r124.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $212
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $213
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r124.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $214
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $215
        mov (32|M0)              r25.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $216
        goto (32|M0)                         _0_036            _0_038                                // $217
// B010: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_036:
        join (32|M0)                         _0_038                                                  // 
L3080:
        shr (32|M0)              r4.0<1>:ud    r124.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $219
        or (32|M0)               r25.0<1>:w    r4.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $221
// B011: [inDivergent],  Preds:{B010, B009},  Succs:{B012, B013}
_0_038:
        join (32|M0)                         _0_028                                                  // 
L3128:
        mul (32|M0)              acc0.0<1>:f   r108.0<1;1,0>:f   r48.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $223
        add (32|M0)              r122.0<1>:f   r82.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $224
        and (32|M0)              r4.0<1>:d     r122.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $227
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r4.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $228
        mul (32|M0)              acc0.0<1>:f   r122.0<1;1,0>:f   r56.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $225
        add (32|M0)              r114.0<1>:f   r116.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $226
(f3.0)  goto (32|M0)                         _0_039            _0_039                                //  ALU pipe: int; $229
// B012: [inDivergent],  Preds:{B011},  Succs:{B014}
_0_040:
        shr (32|M0)              r4.0<1>:ud    r122.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $231
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $232
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r122.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $233
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $234
        mov (32|M0)              r24.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $235
        goto (32|M0)                         _0_039            _0_041                                // $236
// B013: [inDivergent],  Preds:{B011},  Succs:{B014}
_0_039:
        join (32|M0)                         _0_041                                                  // 
L3312:
        shr (32|M0)              r4.0<1>:ud    r122.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $238
        or (32|M0)               r24.0<1>:w    r4.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $240
// B014: [inDivergent],  Preds:{B013, B012},  Succs:{B015, B016}
_0_041:
        join (32|M0)                         _0_028                                                  // 
L3360:
        mul (32|M0)              acc0.0<1>:f   r108.0<1;1,0>:f   r50.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $242
        add (32|M0)              r118.0<1>:f   r84.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $243
        and (32|M0)              r4.0<1>:d     r118.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $246
        cmp (32|M0)   (gt)f3.0   null<1>:ud    r4.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $247
        mul (32|M0)              acc0.0<1>:f   r118.0<1;1,0>:f   r58.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $244
        add (32|M0)              r28.0<1>:f    r114.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $245
(f3.0)  goto (32|M0)                         _0_042            _0_042                                //  ALU pipe: int; $248
// B015: [inDivergent],  Preds:{B014},  Succs:{B017}
_0_043:
        shr (32|M0)              r4.0<1>:ud    r118.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $250
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $251
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r118.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $252 R{} IR{}{E:3,E:3,},  R{} IR{}{O:3,O:11,},  {BC=1}
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $253
        mov (32|M0)              r14.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $254
        goto (32|M0)                         _0_042            _0_044                                // $255
// B016: [inDivergent],  Preds:{B014},  Succs:{B017}
_0_042:
        join (32|M0)                         _0_044                                                  // 
L3544:
        shr (32|M0)              r4.0<1>:ud    r118.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $257
        or (32|M0)               r14.0<1>:w    r4.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $259
// B017: [inDivergent],  Preds:{B016, B015},  Succs:{B018, B022}
_0_044:
        join (32|M0)                         _0_028                                                  // 
L3592:
        shl (32|M0)              r1.0<1>:uw    r86.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $261
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $262
        add (16|M0)              a0.0<1>:uw    r1.0<1;1,0>:uw    0x700:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0305(r28.0:f); $263
(W)     mov (1|M0)               f3.0<1>:ud    r2.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $268
        shl (32|M0)              r2.0<1>:uw    r94.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $270
        mov (16|M0)              r4.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $264
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $265
        add (16|M16)             a0.0<1>:uw    r1.16<1;1,0>:uw   0x700:uw                            //  ALU pipe: int; src1 is addr of V0305(r28.0:f); $266
        shl (32|M0)              r1.0<1>:uw    r92.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $279
        mov (16|M16)             r5.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $267
(f3.0)  sel (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $268
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $271
        add (16|M0)              a0.0<1>:uw    r2.0<1;1,0>:uw    0x580:uw                            //  ALU pipe: int; src1 is addr of V0324(r22.0:f); $272
        add (32|M0)              r22.0<1>:f    r28.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $269
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $273
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $274
        add (16|M16)             a0.0<1>:uw    r2.16<1;1,0>:uw   0x580:uw                            //  ALU pipe: int; src1 is addr of V0324(r22.0:f); $275
(W)     mov (1|M0)               f3.0<1>:ud    r3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $277
        shl (32|M0)              r2.0<1>:uw    r90.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $288
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $276
(f3.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $277
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $280
        add (16|M0)              a0.0<1>:uw    r1.0<1;1,0>:uw    0x500:uw                            //  ALU pipe: int; src1 is addr of V0328(r20.0:f); $281
        add (32|M0)              r20.0<1>:f    r22.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $278
        mov (16|M0)              r4.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $282
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $283
        add (16|M16)             a0.0<1>:uw    r1.16<1;1,0>:uw   0x500:uw                            //  ALU pipe: int; src1 is addr of V0328(r20.0:f); $284
        shl (32|M0)              r1.0<1>:uw    r88.0<2;1,0>:uw   0x2:uw                              //  ALU pipe: int; $297
        mov (16|M16)             r5.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $285
(f2.0)  sel (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $286
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $289
        add (16|M0)              a0.0<1>:uw    r2.0<1;1,0>:uw    0x480:uw                            //  ALU pipe: int; src1 is addr of V0332(r18.0:f); $290
        add (32|M0)              r18.0<1>:f    r20.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $287
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $291
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $292
        add (16|M16)             a0.0<1>:uw    r2.16<1;1,0>:uw   0x480:uw                            //  ALU pipe: int; src1 is addr of V0332(r18.0:f); $293
        cmp (32|M0)   (eq)f2.0   null<2>:w     r111.0<1;1,0>:w   0:w                                 //  ALU pipe: int; $306
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $294
(f1.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $295
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $298
        add (16|M0)              a0.0<1>:uw    r1.0<1;1,0>:uw    0x400:uw                            //  ALU pipe: int; src1 is addr of V0336(r16.0:f); $299
        add (32|M0)              r16.0<1>:f    r18.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $296
        mov (16|M0)              r4.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $300
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $301
        add (16|M16)             a0.0<1>:uw    r1.16<1;1,0>:uw   0x400:uw                            //  ALU pipe: int; src1 is addr of V0336(r16.0:f); $302
        mov (16|M16)             r5.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $303
(f0.0)  sel (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     0x80000000:f               {I@1}    //  ALU pipe: float; $304
        add (32|M0)              r126.0<1>:f   r16.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $305
(~f2.0) goto (32|M0)                         _0_045            _0_045                                //  ALU pipe: int; $307
// B018: [inDivergent],  Preds:{B017},  Succs:{B019, B020}
_0_046:
(W)     and (1|M0)               r1.0<1>:d     r126.0<0;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $309
(W)     cmp (32|M0)   (gt)f1.0   null<1>:ud    r1.0<0;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $310
(W&f1.0) jmpi                                _0_047                                                  //  ALU pipe: int; $311
// B019: [inDivergent],  Preds:{B018},  Succs:{B021}
_0_048:
(W)     shr (1|M0)               r1.0<1>:ud    r126.0<0;1,0>:ud  16:w                                //  ALU pipe: int; $313
(W)     and (1|M0)               r2.0<1>:d     r1.0<0;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $314
(W)     add3 (1|M0)              r3.0<1>:d     r2.0<0;0>:d       r126.0<0;0>:d     32767:w               {I@1} //  ALU pipe: int; $315
(W)     shr (1|M0)               r4.0<1>:ud    r3.0<0;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $316
(W)     mov (1|M0)               r3.0<2>:w     r4.0<0;1,0>:d                    {I@1}                //  ALU pipe: int; $317
(W)     jmpi                                 _0_049                                                  // $318
// B020: [inDivergent],  Preds:{B018},  Succs:{B021}
_0_047:
(W)     shr (1|M0)               r1.0<1>:ud    r126.0<0;1,0>:ud  16:w                                //  ALU pipe: int; $320
(W)     or (1|M0)                r3.0<1>:w     r1.0<0;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $322
// B021: [inDivergent],  Preds:{B020, B019},  Succs:{B022}
_0_049:
        add (16|M0)              r4.0<1>:q     r72.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted}        //  ALU pipe: int; $324
        add (16|M16)             r6.0<1>:q     r74.0<1;1,0>:q    r3.5<0;1,0>:q    {Compacted}        //  ALU pipe: int; $324
        mov (32|M0)              r8.0<1>:ud    r3.0<0;1,0>:uw                   {I@3}                //  ALU pipe: int; $326
        store.ugm.d16u32.a64 (32|M0)  [r4:4]    r8:2               {I@1,$12} // ex_desc:0x0; desc:0x8000B84 // $327
// B022: [inDivergent],  Preds:{B021, B017},  Succs:{B025}
_0_045:
        join (32|M0)                         _0_028                                                  // 
L4552:
        add (16|M0)              r1.0<1>:q     r78.0<1;1,0>:q    r3.6<0;1,0>:q                       //  ALU pipe: int; $329
        add (16|M16)             r4.0<1>:q     r76.0<1;1,0>:q    r3.6<0;1,0>:q    {$12.src}          //  ALU pipe: int; $329
        mov (32|M0)              r10.0<2>:w    r26.0<1;1,0>:w                                        //  ALU pipe: int; $331
        mov (32|M0)              r12.0<2>:w    r24.0<1;1,0>:w                                        //  ALU pipe: int; $333
        add (16|M0)              r6.0<1>:q     r1.0<1;1,0>:q     r70.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $330
        add (16|M16)             r8.0<1>:q     r4.0<1;1,0>:q     r68.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $330 R{} IR{}{E:2,E:2,},  R{} IR{}{O:2,O:2,},  {BC=2}
        mov (32|M0)              r10.1<2>:w    r25.0<1;1,0>:w                                        //  ALU pipe: int; $332
        mov (32|M0)              r12.1<2>:w    r14.0<1;1,0>:w                                        //  ALU pipe: int; $334
        store.ugm.d32.a64 (32|M0)  [r6:4]       r10:2              {I@2,$13} // ex_desc:0x0; desc:0x8000584 // $337
        store.ugm.d32.a64 (32|M0)  [r6:4+0x4]   r12:2              {I@1,$14} // ex_desc:0x4000; desc:0x8000584 // $340
        goto (32|M0)                         _0_028            _0_028                                // $341
// B023: [inDivergent],  Preds:{B004},  Succs:{B024, B025}
_0_031:
        or (32|M0)    (eq)f0.0   null<1>:d     r66.0<1;1,0>:d    r64.0<1;1,0>:d                      //  ALU pipe: int; $343
(~f0.0) goto (32|M0)                         _0_028            _0_028                                //  ALU pipe: int; $345
// B024: [inDivergent],  Preds:{B023},  Succs:{B025}
_0_050:
        mov (16|M0)              r1.0<2>:f     r106.0<0;1,0>:f                                       //  ALU pipe: float; $347
        mov (16|M16)             r3.0<2>:f     r106.0<0;1,0>:f                                       //  ALU pipe: float; $347
        mov (32|M0)              r6.0<1>:d     1:w                               {Compacted,$14.src} //  ALU pipe: int; $349
        mov (16|M0)              r1.1<2>:f     r106.1<0;1,0>:f                                       //  ALU pipe: float; $348
        mov (16|M16)             r3.1<2>:ud    r106.1<0;1,0>:ud                 {F@2}                //  ALU pipe: int; $348
        atomic_store.ugm.d32.a64 (32|M0)  null:0 [r1:4]           r6:2               {A@1,$15} // ex_desc:0x0; desc:0x800058B // $350
// B025: Preds:{B024, B023, B022, B003, B002},  Succs:{}
_0_028:
        join (32|M0)                         L4848                                                   // 
L4848:
(W)     mov (16|M0)              r127.0<1>:f   r110.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $352
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$0} // wr:1+0, rd:0; end of thread // $352
L4872:
(W)     mov (16|M0)              null<1>:ud    0x80B9A81D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0xBB2E2BB5:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x10:ud                                               // 


//.BankConflicts: 6
//.ByteRMWs: 0
//


//.numALUInst: 320
//.accSubDef: 24
//.accSubUse: 24
//.accSubCandidateDef: 27
//.accSubCandidateUse: 28
//
//
//.singlePipeAtOneDistNum: 73
//.allAtOneDistNum: 7
//.syncInstCount: 2
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 12
//.AfterReadTokenDepCount: 5
