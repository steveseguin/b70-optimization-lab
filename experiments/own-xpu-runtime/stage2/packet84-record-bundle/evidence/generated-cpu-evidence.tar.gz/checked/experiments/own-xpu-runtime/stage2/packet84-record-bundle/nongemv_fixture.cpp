#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet84-record-bundle/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet84-record-bundle/nongemv_fixture.cpp"
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet84-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet84-record-bundle/fixture_driver.cpp"
