#include <cxxabi.h>
#define main packet75_unexecuted_model_entry
#include "main.cpp"
#undef main
int main(int argc,char**argv){std::unique_ptr<Engine> e;std::unique_ptr<mtp36::DraftRuntime> draft;try{
 require(argc==8,"view hash rank output negative draft_rank split");Options a;a.context=4096;a.cards=1;a.card=0;a.rank=std::stoi(argv[3]);a.draft_rank=std::stoi(argv[6]);a.target_split=std::stoi(argv[7]);a.mtp=true;a.memory="resident";a.gemv="r5";a.nongemv="parallel";a.selection=argv[1];a.selection_sha256=argv[2];a.output=argv[4];fs::create_directories(a.output);
 a.plan=fs::path("/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet84-record-bundle")/"../suite-inputs-20261012/code-review/plan.tsv";a.draft_manifest=fs::path("/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet84-record-bundle")/"mtp-manifest.tsv";
 packet26::dispatch.load((fs::path("/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet84-record-bundle")/"dispatch-speed6.json").string());Weights w(a);auto p=pipeline::split(plan(w,a),a.rank,false,a.draft_rank,a.target_split);
 require(arithmetic::row_bytes(iq3::Type::Q6_K,2560,6)==3380,"real expanded Q6 head stride");
 e=std::make_unique<Engine>(w,a,p);e->initialize();
 if(std::string(argv[5])=="negative"&&a.rank==1){auto id=e->weights[0].at("output.weight");auto &r=const_cast<std::remove_const_t<std::remove_reference_t<decltype(e->dev(0).arena.row(id))>>&>(e->dev(0).arena.row(id));r.bytes-=2100;}
 if(a.rank==0)pipeline::banks(*e);else{e->prepare_plan();e->prepare_commands();}
 {pipeline::SpeculativeImage image(*e);if(a.rank==a.draft_rank)draft=std::make_unique<mtp36::DraftRuntime>(*e);
 auto count=[](const std::string& key){unsigned n=0;for(const auto&[name,value]:p80_operations)if(name.find(key)!=std::string::npos)n+=value;return n;};
 const auto& choice=e->sealed_selection.choices;
 const auto& rec=choice.at("recurrence");
 require(count(rec=="rows4-shared"?"p49drec::RecurrenceKernel<4u>":rec=="rec-gates"?"p82rec::Kernel<false>":"p82rec::Kernel<true>")>0,"recurrence selection consumer");
 const auto& expert=choice.at("experts");unsigned follow=expert=="wide64"?0:expert=="input-packed"?3:expert=="gate-input-packed"?4:5;
 require(count("p65::Kernel<(iq3::Type)22, 2560u, 64u, false, true, "+std::to_string(follow)+"u>")>0,"gate expert selection consumer");
 require(count("p65::Kernel<(iq3::Type)20, 640u, 64u, false, true, "+std::to_string(follow)+"u>")>0,"down expert selection consumer");
 if(draft){require((count("p83::Head<2560u>")>0)==(e->sealed_selection.draft.at("head_format")=="q4-g32"),"draft head selection consumer");}
 require((count("p78route::Kernel")>0)==(choice.at("route")=="route-fast"),"route selection consumer");
 require((count("p60::Kernel<0, false, true>")>0)==(choice.at("hc_norm")=="subgroup"),"norm selection consumer");
 require((count("p60::Kernel<2, true, false>")>0)==(choice.at("hc_gate")=="wide"),"HC wide selection consumer");
 std::ofstream selected(a.output/"selected-operations.txt");for(const auto&[name,value]:p80_operations)selected<<name<<" "<<value<<"\n";selected.close();
 require(e->ordered_retirement==(a.rank==1&&choice.at("host_retire")=="ordered"),"host retirement selection consumer");
 save(a.output/"census.json",e->dev(0).arena.census());save(a.output/"result.json","{\"passed\":true,\"device_executed\":false,\"rank\":"+std::to_string(a.rank)+",\"postload_device_bytes\":"+std::to_string(e->owned_bytes[0])+",\"expanded_head_stride\":3380}");draft.reset();}
 e->shutdown();e.reset();return 0;
 }catch(const std::exception&x){std::cerr<<x.what()<<'\n';draft.reset();if(e){try{e->shutdown();}catch(...){}e.reset();}return 1;}}
