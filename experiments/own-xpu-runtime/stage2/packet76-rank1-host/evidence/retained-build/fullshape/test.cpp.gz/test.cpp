#define main p76_unused_model_entry
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet76-rank1-host/build/fullshape/main.cpp"
#undef main
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet76-rank1-host/fullshape_test.cpp"
