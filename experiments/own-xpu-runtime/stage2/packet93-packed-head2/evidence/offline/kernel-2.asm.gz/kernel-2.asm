//.kernel _ZTS19Packet93OfflineHeadILj2EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 126206512 1489720022 -hashmovs1 0 3 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 126206512 1489720022 -hashmovs1 0 3 -GRFBumpUpNumber 2 "
//.instCount 366
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r104.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r104.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.0)
//.declare V0035 (45)  rf=r size=8 type=uq align=4 words (r2.1)
//.declare V0036 (46)  rf=r size=8 type=uq align=4 words (r2.2)
//.declare V0038 (48)  rf=r size=32 type=d alias=+0 align=32 words (r104.0)
//.declare V0040 (50)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0050 (60)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0051 (61)  rf=r size=64 type=uw alias=V0040+0 align=32 words (r1.0)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r2.7)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r2.6)
//.declare V0054 (64)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r2.7)
//.declare V0055 (65)  rf=r size=32 type=ud alias=V0038+0 align=32 words (r104.0)
//.declare V0056 (66)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P01 (69)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0059 (70)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0060 (71)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0062 (73)  rf=r size=8 type=q align=4 words (r105.0)
//.declare V0063 (74)  rf=r size=8 type=d alias=V0062+0 align=4 words (r105.0)
//.declare V0064 (75)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0065 (76)  rf=r size=128 type=ud alias=V0050+0 align=32 words (r60.0)
//.declare V0066 (77)  rf=r size=128 type=ud alias=V0064+0 align=32 words (r4.0)
//.declare V0067 (78)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0068 (79)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0069 (80)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0070 (81)  rf=r size=64 type=w align=32 words (r3.0)
//.declare V0071 (82)  rf=r size=64 type=w align=32 words (r8.0)
//.declare V0073 (84)  rf=r size=64 type=uw alias=V0070+0 align=32 words (r3.0)
//.declare V0074 (85)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0076 (87)  rf=r size=128 type=ud alias=V0074+0 align=32 words (r10.0)
//.declare V0077 (88)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0079 (90)  rf=r size=128 type=ud alias=V0077+0 align=32 words (r12.0)
//.declare V0081 (92)  rf=r size=128 type=ud alias=V0069+0 align=32 words (r6.0)
//.declare V0083 (94)  rf=r size=64 type=uw alias=V0071+0 align=32 words (r8.0)
//.declare V0084 (95)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0086 (97)  rf=r size=128 type=ud alias=V0084+0 align=32 words (r24.0)
//.declare V0087 (98)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0088 (99)  rf=r size=128 type=ud alias=V0087+0 align=32 words (r14.0)
//.declare V0090 (101)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.0)
//.declare V0091 (102)  rf=r size=8 type=q alias=V0035+0 align=32 words (r2.1)
//.declare V0092 (103)  rf=r size=4 type=d align=2 words (r105.3)
//.declare V0093 (104)  rf=r size=4 type=d align=2 words (r105.2)
//.declare V0094 (105)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0095 (106)  rf=r size=128 type=ud alias=V0060+0 align=32 words (r54.0)
//.declare V0096 (107)  rf=r size=128 type=ud alias=V0094+0 align=32 words (r4.0)
//.declare V0101 (112)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0102 (113)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0104 (115)  rf=r size=128 type=ud alias=V0101+0 align=32 words (r14.0)
//.declare V0107 (118)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0108 (119)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0109 (120)  rf=r size=256 type=q align=32 words (r34.0)
//.declare V0116 (127)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0117 (128)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0118 (129)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0119 (130)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0120 (131)  rf=r size=128 type=ud alias=V0118+0 align=32 words (r28.0)
//.declare V0121 (132)  rf=r size=128 type=ud alias=V0119+0 align=32 words (r4.0)
//.declare V0123 (134)  rf=r size=256 type=q align=32 words (r72.0)
//.declare V0124 (135)  rf=r size=256 type=uq alias=V0123+0 align=32 words (r72.0)
//.declare V0125 (136)  rf=r size=256 type=d align=32 words (r30.0)
//.declare V0126 (137)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0127 (138)  rf=r size=128 type=d align=32 words (r70.0)
//.declare P02 (139)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0128 (140)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0129 (141)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0130 (142)  rf=r size=128 type=ud alias=V0126+0 align=32 words (r68.0)
//.declare V0131 (143)  rf=r size=128 type=ud alias=V0129+0 align=32 words (r6.0)
//.declare V0132 (144)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0133 (145)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0134 (146)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0135 (147)  rf=r size=128 type=ud alias=V0127+0 align=32 words (r70.0)
//.declare V0136 (148)  rf=r size=128 type=ud alias=V0134+0 align=32 words (r12.0)
//.declare V0143 (155)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0144 (156)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0145 (157)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0146 (158)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0147 (159)  rf=r size=128 type=ud alias=V0145+0 align=32 words (r20.0)
//.declare V0148 (160)  rf=r size=128 type=ud alias=V0146+0 align=32 words (r22.0)
//.declare V0150 (162)  rf=r size=256 type=q align=32 words (r64.0)
//.declare V0151 (163)  rf=r size=256 type=uq alias=V0150+0 align=32 words (r64.0)
//.declare V0152 (164)  rf=r size=256 type=d align=32 words (r28.0)
//.declare V0153 (165)  rf=r size=128 type=d align=32 words (r96.0)
//.declare V0154 (166)  rf=r size=128 type=d align=32 words (r98.0)
//.declare P03 (167)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0155 (168)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0156 (169)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0157 (170)  rf=r size=128 type=ud alias=V0153+0 align=32 words (r96.0)
//.declare V0158 (171)  rf=r size=128 type=ud alias=V0156+0 align=32 words (r6.0)
//.declare V0159 (172)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0160 (173)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0161 (174)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0162 (175)  rf=r size=128 type=ud alias=V0154+0 align=32 words (r98.0)
//.declare V0163 (176)  rf=r size=128 type=ud alias=V0161+0 align=32 words (r12.0)
//.declare V0164 (177)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0165 (178)  rf=r size=128 type=ud alias=V0164+0 align=32 words (r4.0)
//.declare V0166 (179)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0167 (180)  rf=r size=128 type=ud alias=V0166+0 align=32 words (r6.0)
//.declare V0168 (181)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0169 (182)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0170 (183)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0171 (184)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0172 (185)  rf=r size=128 type=ud alias=V0171+0 align=32 words (r12.0)
//.declare V0173 (186)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0174 (187)  rf=r size=128 type=ud alias=V0173+0 align=32 words (r14.0)
//.declare V0175 (188)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0176 (189)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0177 (190)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0179 (192)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare V0180 (193)  rf=r size=128 type=w alias=V0179+0 align=32 words (r20.0)
//.declare V0182 (195)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0184 (197)  rf=r size=128 type=d align=32 words (r106.0)
//.declare V0185 (198)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0186 (199)  rf=r size=128 type=ud alias=V0185+0 align=32 words (r22.0)
//.declare V0187 (200)  rf=r size=128 type=d align=32 words (r110.0)
//.declare P04 (201)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P05 (202)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0188 (203)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0189 (204)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0190 (205)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P06 (206)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0191 (207)  rf=r size=4 type=d align=2 words (r2.6)
//.declare P07 (208)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0193 (210)  rf=r size=128 type=d align=32 words (r108.0)
//.declare V0194 (211)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0195 (212)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0196 (213)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0197 (214)  rf=r size=128 type=d align=32 words (r10.0)
//.declare P08 (215)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0198 (216)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0200 (218)  rf=r size=256 type=q align=32 words (r12.0)
//.declare V0201 (219)  rf=r size=256 type=uq alias=V0200+0 align=32 words (r12.0)
//.declare V0202 (220)  rf=r size=32 type=b align=32 words (r3.0)
//.declare V0203 (221)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0204 (222)  rf=r size=128 type=b alias=V0203+0 align=32 words (r24.0)
//.declare V0205 (223)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0207 (225)  rf=r size=128 type=ud alias=V0205+0 align=32 words (r8.0)
//.declare V0208 (226)  rf=r size=256 type=q align=32 words (r26.0)
//.declare V0209 (227)  rf=r size=256 type=uq alias=V0208+0 align=32 words (r26.0)
//.declare V0210 (228)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0211 (229)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0212 (230)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0214 (232)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0215 (233)  rf=r size=128 type=d align=32 words (r20.0)
//.declare P09 (235)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0217 (236)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0219 (238)  rf=r size=128 type=f alias=V0182+0 align=32 words (r50.0)
//.declare V0220 (239)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0221 (240)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0222 (241)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0224 (243)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0225 (244)  rf=r size=128 type=ud alias=V0170+0 align=32 words (r56.0)
//.declare V0226 (245)  rf=r size=128 type=ud alias=V0224+0 align=32 words (r16.0)
//.declare V0227 (246)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0228 (247)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0229 (248)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0230 (249)  rf=r size=128 type=f align=32 words (r36.0)
//.declare V0231 (250)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0232 (251)  rf=r size=128 type=ud alias=V0231+0 align=32 words (r32.0)
//.declare V0233 (252)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0234 (253)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0235 (254)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0236 (255)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0237 (256)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0238 (257)  rf=r size=128 type=ud alias=V0237+0 align=32 words (r10.0)
//.declare V0239 (258)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0240 (259)  rf=r size=128 type=f align=32 words (r44.0)
//.declare V0241 (260)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0242 (261)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0243 (262)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0244 (263)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0245 (264)  rf=r size=128 type=f align=32 words (r38.0)
//.declare V0246 (265)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0247 (266)  rf=r size=128 type=ud alias=V0177+0 align=32 words (r58.0)
//.declare V0248 (267)  rf=r size=128 type=ud alias=V0246+0 align=32 words (r20.0)
//.declare V0249 (268)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0250 (269)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0251 (270)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0252 (271)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0253 (272)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0254 (273)  rf=r size=128 type=ud alias=V0253+0 align=32 words (r26.0)
//.declare V0255 (274)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0256 (275)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0257 (276)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0258 (277)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0259 (278)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0260 (279)  rf=r size=128 type=ud alias=V0259+0 align=32 words (r32.0)
//.declare V0261 (280)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0262 (281)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0263 (282)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0265 (284)  rf=r size=128 type=w alias=V0210+0 align=32 words (r36.0)
//.declare V0269 (288)  rf=r size=128 type=w alias=V0211+0 align=32 words (r38.0)
//.declare V0273 (292)  rf=r size=128 type=w alias=V0212+0 align=32 words (r4.0)
//.declare V0276 (295)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0278 (297)  rf=r size=128 type=w alias=V0276+0 align=32 words (r6.0)
//.declare V0281 (300)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0283 (302)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0285 (304)  rf=r size=128 type=f alias=V0283+0 align=32 words (r48.0)
//.declare V0287 (306)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0289 (308)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0290 (309)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0291 (310)  rf=r size=128 type=f alias=V0289+0 align=32 words (r30.0)
//.declare V0293 (312)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0295 (314)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0296 (315)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0297 (316)  rf=r size=128 type=f alias=V0295+0 align=32 words (r12.0)
//.declare V0299 (318)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0301 (320)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0302 (321)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0303 (322)  rf=r size=128 type=f alias=V0301+0 align=32 words (r50.0)
//.declare V0305 (324)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0307 (326)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0308 (327)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0309 (328)  rf=r size=128 type=f alias=V0307+0 align=32 words (r10.0)
//.declare V0311 (330)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0313 (332)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0314 (333)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0315 (334)  rf=r size=128 type=f alias=V0313+0 align=32 words (r42.0)
//.declare V0317 (336)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0319 (338)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0320 (339)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0321 (340)  rf=r size=128 type=f alias=V0319+0 align=32 words (r22.0)
//.declare V0323 (342)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0325 (344)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0327 (346)  rf=r size=128 type=f alias=V0325+0 align=32 words (r10.0)
//.declare P10 (347)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0328 (348)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0329 (349)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0330 (350)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0331 (351)  rf=r size=128 type=uw alias=V0329+0 align=32 words (r6.0)
//.declare V0332 (352)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A00 (353)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P11 (354)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0335 (357)  rf=r size=128 type=f align=32 words (r120.0)
//.declare V0336 (358)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0337 (359)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0338 (360)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0339 (361)  rf=r size=128 type=uw alias=V0337+0 align=32 words (r4.0)
//.declare V0340 (362)  rf=r size=64 type=uw align=32 words (r12.0)
//.declare A01 (363)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P12 (364)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0343 (367)  rf=r size=128 type=f align=32 words (r118.0)
//.declare V0344 (368)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0345 (369)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0346 (370)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0347 (371)  rf=r size=128 type=uw alias=V0345+0 align=32 words (r10.0)
//.declare V0348 (372)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A02 (373)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P13 (374)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0351 (377)  rf=r size=128 type=f align=32 words (r116.0)
//.declare V0352 (378)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0353 (379)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0354 (380)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0355 (381)  rf=r size=128 type=uw alias=V0353+0 align=32 words (r8.0)
//.declare V0356 (382)  rf=r size=64 type=uw align=32 words (r12.0)
//.declare A03 (383)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P14 (384)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0359 (387)  rf=r size=128 type=f align=32 words (r122.0)
//.declare V0360 (388)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0361 (389)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0362 (390)  rf=r size=128 type=f align=32 words (r114.0)
//.declare V0363 (391)  rf=r size=128 type=uw alias=V0361+0 align=32 words (r6.0)
//.declare V0364 (392)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A04 (393)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P15 (394)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P16 (395)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0367 (398)  rf=r size=128 type=f align=32 words (r112.0)
//.declare V0368 (399)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0369 (400)  rf=r size=128 type=d alias=V0367+0 align=32 words (r112.0)
//.declare P17 (401)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0370 (402)  rf=r size=128 type=ud alias=V0368+0 align=32 words (r4.0)
//.declare V0371 (403)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0372 (404)  rf=r size=128 type=ud alias=V0367+0 align=32 words (r112.0)
//.declare V0373 (405)  rf=r size=128 type=ud alias=V0371+0 align=32 words (r4.0)
//.declare V0374 (406)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0375 (407)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0376 (408)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0377 (409)  rf=r size=128 type=ud alias=V0375+0 align=32 words (r8.0)
//.declare V0378 (410)  rf=r size=128 type=ud alias=V0376+0 align=32 words (r10.0)
//.declare V0379 (411)  rf=r size=64 type=w align=32 words (r124.0)
//.declare V0380 (412)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0381 (413)  rf=r size=128 type=ud alias=V0380+0 align=32 words (r4.0)
//.declare V0383 (415)  rf=r size=8 type=q alias=V0036+0 align=32 words (r2.2)
//.declare V0385 (417)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0386 (418)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0387 (419)  rf=r size=8 type=uq alias=V0386+0 align=32 words (r4.0)
//.declare P18 (420)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0388 (421)  rf=r size=2 type=uw align=32 words (r1.0)
//.declare V0390 (423)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare V0391 (424)  rf=r size=4 type=uw alias=V0390+0 align=2 words (r3.0)
//.declare A05 (425)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0393 (427)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare  (429)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (430)  rf=r size=128 type=w alias=V0380+0 align=32 words (r4.0)
//.declare  (431)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (432)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (433)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (434)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (435)  rf=r size=128 type=uw align=32 words (r20.0)
//.declare  (436)  rf=r size=128 type=uw align=32 words (r22.0)
//.declare  (437)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (438)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (439)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (440)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (443)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (444)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (445)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (446)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare  (449)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (450)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (451)  rf=r size=2 type=w align=1 words (r2.12)
//.declare  (452)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (453)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare  (454)  rf=r size=128 type=w alias=V0376+0 align=32 words (r10.0)
//.declare  (455)  rf=r size=128 type=q align=32 words (r102.0)
//.declare  (456)  rf=r size=128 type=q align=32 words (r100.0)
//.declare  (457)  rf=r size=128 type=q align=32 words (r94.0)
//.declare  (458)  rf=r size=128 type=q align=32 words (r92.0)
//.declare  (459)  rf=r size=128 type=q align=32 words (r78.0)
//.declare  (460)  rf=r size=128 type=q align=32 words (r76.0)
//.declare  (461)  rf=r size=128 type=q align=32 words (r90.0)
//.declare  (462)  rf=r size=128 type=q align=32 words (r88.0)
//.declare  (463)  rf=r size=128 type=q align=32 words (r86.0)
//.declare  (464)  rf=r size=128 type=q align=32 words (r84.0)
//.declare  (467)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (468)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (471)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (472)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (473)  rf=r size=128 type=q align=32 words (r6.0)
//.declare  (474)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (475)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (476)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (477)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (478)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (483)  rf=r size=128 type=q align=32 words (r3.0)
//.declare  (484)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (485)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (486)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (487)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (488)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (493)  rf=r size=128 type=q align=32 words (r3.0)
//.declare  (494)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (497)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (498)  rf=r size=128 type=d alias=+0 align=32 words (r12.0)
//.declare  (499)  rf=r size=128 type=ud alias=+0 align=32 words (r18.0)
//.declare  (500)  rf=r size=128 type=ud alias=+0 align=32 words (r20.0)
//.declare  (501)  rf=r size=128 type=d alias=+0 align=32 words (r18.0)
//.declare  (502)  rf=r size=128 type=d alias=+0 align=32 words (r20.0)
//.declare  (503)  rf=r size=128 type=d alias=+0 align=32 words (r24.0)
//.declare  (504)  rf=r size=128 type=d alias=+0 align=32 words (r14.0)
//.declare  (505)  rf=r size=128 type=d alias=+0 align=32 words (r11.0)
//.declare  (506)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare  (507)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (508)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (509)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (510)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (511)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (512)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (513)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (514)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (515)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (516)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (517)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (518)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (519)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (520)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (521)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (522)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (523)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (524)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (525)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (526)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (527)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (528)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (529)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (530)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (531)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (532)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (533)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (534)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (535)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (536)  rf=r size=64 type=d align=32 words (r31.0)
//.declare  (537)  rf=r size=64 type=d align=32 words (r32.0)
//.declare  (538)  rf=r size=64 type=d align=32 words (r33.0)
//.declare  (539)  rf=r size=64 type=d align=32 words (r34.0)
//.declare  (540)  rf=r size=64 type=d align=32 words (r35.0)
//.declare  (541)  rf=r size=64 type=d align=32 words (r36.0)
//.declare  (542)  rf=r size=64 type=d align=32 words (r37.0)
//.declare  (543)  rf=r size=64 type=d align=32 words (r38.0)
//.declare  (544)  rf=r size=64 type=d align=32 words (r39.0)
//.declare  (545)  rf=r size=64 type=d align=32 words (r40.0)
//.declare  (546)  rf=r size=64 type=d align=32 words (r41.0)
//.declare  (547)  rf=r size=64 type=d align=32 words (r42.0)
//.declare  (548)  rf=r size=64 type=d align=32 words (r43.0)
//.declare  (549)  rf=r size=64 type=d align=32 words (r44.0)
//.declare  (550)  rf=r size=64 type=d align=32 words (r45.0)
//.declare  (551)  rf=r size=64 type=d align=32 words (r46.0)
//.declare  (552)  rf=r size=64 type=d align=32 words (r47.0)
//.declare  (553)  rf=r size=64 type=d align=32 words (r48.0)
//.declare  (554)  rf=r size=64 type=d align=32 words (r49.0)
//.declare  (555)  rf=r size=64 type=d align=32 words (r50.0)
//.declare  (556)  rf=r size=64 type=d align=32 words (r51.0)
//.declare  (557)  rf=r size=64 type=d align=32 words (r52.0)
//.declare  (558)  rf=r size=64 type=d align=32 words (r53.0)
//.declare r0 (559)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (560)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (561)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (562)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (563)  rf=r size=64 type=ud align=32 words (r1.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0034    | :uq      |    0x8 | r2       | inline+0x0       |
// | V0035    | :uq      |    0x8 | r2+0x8   | inline+0x8       |
// | V0036    | :uq      |    0x8 | r2+0x10  | inline+0x10      |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@2}           //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
// B002: Preds:{B001},  Succs:{B003, B004}
// _main:
(W)     mov (16|M0)              r104.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
        cmp (32|M0)   (lt)f3.0   null<2>:uw    r1.0<1;1,0>:uw    0x140:uw              {A@1,$0.dst}  //  ALU pipe: int; $10
(W)     mul (1|M0)               acc0.0<1>:ud  r104.1<0;1,0>:ud  0xA:uw              {I@4}           //  ALU pipe: int; $4
(W)     mach (1|M0)              r3.0<1>:d     r104.1<0;1,0>:ud  0xA:ud                              //  ALU pipe: int; 
        mov (32|M0)              r60.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $2
(W)     mul (1|M0)               r2.7<1>:ud    r104.1<0;1,0>:ud  0xA:uw                              //  ALU pipe: int; $3
(W)     mov (1|M0)               r2.6<1>:d     r3.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $9
(f3.0)  goto (32|M0)                         _0_029            _0_029                                //  ALU pipe: int; $11
// B003: [inDivergent],  Preds:{B002},  Succs:{B020}
_0_030:
        mov (32|M0)              r62.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $13
        goto (32|M0)                         _0_029            _0_031                                // $14
// B004: [inDivergent],  Preds:{B002},  Succs:{B005}
_0_029:
        join (32|M0)                         _0_031                                                  // 
L352:
        shl (32|M0)              r3.0<1>:w     r1.0<1;1,0>:w     3:w                                 //  ALU pipe: int; $25
        and (32|M0)              r8.0<1>:w     r3.0<1;1,0>:w     24:w               {I@1}            //  ALU pipe: int; $26
        and (32|M0)              r3.0<1>:w     r3.0<1;1,0>:w     248:w                               //  ALU pipe: int; $27
        shr (32|M0)              r10.0<1>:ud   r3.0<1;1,0>:uw    7:w               {I@1}             //  ALU pipe: int; $29
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    6:w               {Compacted,I@1}   //  ALU pipe: int; $30
        shl (32|M0)              r54.0<1>:d    r60.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $16
        shr (32|M0)              r4.0<1>:ud    r60.0<1;1,0>:ud   1:w                                 //  ALU pipe: int; $21
        mov (16|M0)              r14.0<2>:ud   r12.0<1;1,0>:ud                  {Compacted,I@3}      //  ALU pipe: int; $31
        and (32|M0)              r6.0<1>:d     r54.0<1;1,0>:d    32:w               {Compacted,I@3}  //  ALU pipe: int; $24
        shl (32|M0)              r24.0<1>:d    r10.0<1;1,0>:d    5:w               {Compacted}       //  ALU pipe: int; $34
        and (32|M0)              r82.0<1>:d    r4.0<1;1,0>:d     4:w               {Compacted,I@4}   //  ALU pipe: int; $22
        and (32|M0)              r80.0<1>:d    r4.0<1;1,0>:d     6:w               {Compacted}       //  ALU pipe: int; $23
        mov (16|M0)              r102.0<1>:q   r14.0<2;1,0>:ud                  {I@5}                //  ALU pipe: int; $31
        shr (32|M0)              r14.0<1>:ud   r3.0<1;1,0>:uw    4:w                                 //  ALU pipe: int; $36
        mov (16|M16)             r16.0<2>:ud   r13.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $31
        mov (16|M16)             r4.0<2>:ud    r7.0<1;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $32
        mov (32|M0)              r62.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $40
        mov (16|M0)              r20.0<4>:uw   r8.0<1;1,0>:uw                                        //  ALU pipe: int; $33
        mov (16|M16)             r22.0<4>:uw   r8.16<1;1,0>:uw                                       //  ALU pipe: int; $33
        mov (16|M0)              r18.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $32
        mov (16|M0)              r26.0<2>:ud   r24.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $35
        mov (16|M16)             r100.0<1>:q   r16.0<2;1,0>:ud                  {I@6}                //  ALU pipe: int; $31
        mov (16|M16)             r12.0<2>:ud   r25.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $35
        mov (16|M16)             r92.0<1>:q    r4.0<2;1,0>:ud                   {I@7}                //  ALU pipe: int; $32
        mov (16|M0)              r16.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $37
        mov (16|M16)             r4.0<2>:ud    r15.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $37
        mov (16|M0)              r78.0<1>:q    r20.0<4;1,0>:uw                  {I@7}                //  ALU pipe: int; $33
        mov (16|M16)             r76.0<1>:q    r22.0<4;1,0>:uw                  {I@7}                //  ALU pipe: int; $33
        mov (16|M0)              r94.0<1>:q    r18.0<2;1,0>:ud                  {I@7}                //  ALU pipe: int; $32
        mov (16|M0)              r90.0<1>:q    r26.0<2;1,0>:ud                  {I@7}                //  ALU pipe: int; $35
        mov (16|M16)             r88.0<1>:q    r12.0<2;1,0>:ud                  {I@7}                //  ALU pipe: int; $35
        mov (16|M0)              r86.0<1>:q    r16.0<2;1,0>:ud                  {I@7}                //  ALU pipe: int; $37
        mov (16|M16)             r84.0<1>:q    r4.0<2;1,0>:ud                   {I@7}                //  ALU pipe: int; $37
(W)     mov (1|M0)               r105.0<1>:d   r2.7<0;1,0>:d                                         //  ALU pipe: int; $17
(W)     mov (1|M0)               r105.1<1>:d   r2.6<0;1,0>:d                                         //  ALU pipe: int; $18
(W)     mov (1|M0)               r105.3<1>:f   0x7F800000:f                                          //  (0x7f800000:f); ALU pipe: float; $38
(W)     mov (1|M0)               r105.2<1>:f   0xF0F0F0F:f                                           //  (0x0f0f0f0f:f); ALU pipe: float; $39
// B005: [inDivergent],  Preds:{B019, B004},  Succs:{B006, B007}
_0_032:
        shr (32|M0)              r4.0<1>:ud    r54.0<1;1,0>:ud   8:w                                 //  ALU pipe: int; $42
        mov (16|M0)              r6.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $44
        mov (16|M16)             r10.0<2>:ud   r5.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $44
        add (16|M0)              r8.0<1>:q     r105.0<0;1,0>:q   r6.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $44
        add (16|M16)             r12.0<1>:q    r105.0<0;1,0>:q   r10.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $44
        mov (16|M0)              r14.0<1>:d    r8.0<2;1,0>:d                    {Compacted,I@2}      //  ALU pipe: int; $45
        mov (16|M16)             r15.0<1>:d    r12.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $46
(W)     mul (16|M0)              acc0.0<1>:ud  r14.0<1;1,0>:ud   0xD2:uw              {I@2}          //  ALU pipe: int; $51
        mov (16|M0)              r16.0<1>:d    r8.1<2;1,0>:d                    {Compacted}          //  ALU pipe: int; $47
        mov (16|M16)             r17.0<1>:d    r12.1<2;1,0>:d                   {Compacted}          //  ALU pipe: int; $48
        mach (16|M0)             r22.0<1>:d    r14.0<1;1,0>:ud   0xD2:ud                             //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r15.0<1;1,0>:ud   0xD2:uw              {I@5}          //  ALU pipe: int; $51
        mach (16|M16)            r23.0<1>:d    r15.0<1;1,0>:ud   0xD2:ud                             //  ALU pipe: int; $53
        mul (32|M0)              r4.0<1>:d     r16.0<1;1,0>:d    0xD2:uw              {I@4}          //  ALU pipe: int; $54
        mul (16|M0)              r18.0<2>:ud   r14.0<1;1,0>:ud   0xD2:uw                             //  ALU pipe: int; $49
        mul (16|M16)             r20.0<2>:ud   r15.0<1;1,0>:ud   0xD2:uw                             //  ALU pipe: int; $50
        add (16|M0)              r18.1<2>:d    r22.0<1;1,0>:d    r4.0<1;1,0>:d    {I@3}              //  ALU pipe: int; $55
        add (16|M16)             r20.1<2>:d    r23.0<1;1,0>:d    r5.0<1;1,0>:d                       //  ALU pipe: int; $56
        add (16|M0)              r34.0<1>:q    r18.0<1;1,0>:q    r2.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $57 R{} IR{}{E:1,E:1,},  R{r2,} IR{} {BC=1}
        add (16|M16)             r36.0<1>:q    r20.0<1;1,0>:q    r2.0<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $57
        add (16|M0)              r6.0<1>:q     r34.0<1;1,0>:q    r102.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $58
        add (16|M16)             r8.0<1>:q     r36.0<1;1,0>:q    r100.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $58 R{} IR{}{E:2,E:2,},  R{} IR{}{O:2,O:2,},  {BC=2}
        add (16|M0)              r10.0<1>:q    r6.0<1;1,0>:q     r94.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $59
        add (16|M16)             r12.0<1>:q    r8.0<1;1,0>:q     r92.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $59
        add (16|M0)              r24.0<1>:q    r10.0<1;1,0>:q    r78.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $60
        add (16|M16)             r14.0<1>:q    r12.0<1;1,0>:q    r76.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $60 R{} IR{}{E:6,E:6,},  R{} IR{}{O:6,O:6,},  {BC=2}
        mov (16|M0)              r26.0<1>:d    r24.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $62
        mov (16|M16)             r27.0<1>:d    r14.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $62
        shl (32|M0)              r16.0<1>:d    r26.0<1;1,0>:d    3:w               {Compacted,I@1}   //  ALU pipe: int; $63
        and (32|M0)   (eq)f2.0   r28.0<1>:d    r16.0<1;1,0>:d    24:w               {I@1}            //  ALU pipe: int; $64
        shr (32|M0)              r4.0<1>:ud    r28.0<1;1,0>:ud   3:w               {I@1}             //  ALU pipe: int; $65
        mov (16|M0)              r18.0<2>:ud   r4.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $67
        mov (16|M16)             r20.0<2>:ud   r5.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $67
        add (16|M0)              r72.0<1>:q    r24.0<1;1,0>:q    -r18.0<2;1,0>:ud {I@2}              //  ALU pipe: int; $67
        add (16|M16)             r74.0<1>:q    r14.0<1;1,0>:q    -r20.0<2;1,0>:ud {I@2}              //  ALU pipe: int; $67
        load.ugm.d32x2.a64 (32|M0)  r30:4       [r72:4]            {I@1,$1} // ex_desc:0x0; desc:0x8401580 // $68
        mov (32|M0)              r68.0<1>:f    r30.0<1;1,0>:f                   {Compacted,$1.dst}   //  ALU pipe: float; $69
        mov (32|M0)              r70.0<1>:f    r32.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $70
(f2.0)  goto (32|M0)                         _0_033            _0_033                                //  ALU pipe: int; $72
// B006: [inDivergent],  Preds:{B005},  Succs:{B007}
_0_034:
        load.ugm.d32.a64 (32|M0)  r8:2          [r72:4+0x8]        {$2} // ex_desc:0x8000; desc:0x8200580 // $77
        shl (32|M0)              r4.0<1>:d     r70.0<1;1,0>:d    16:w               {Compacted,F@1}  //  ALU pipe: int; $74
        shr (32|M0)              r6.0<1>:ud    r68.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $75
        shr (32|M0)              r12.0<1>:ud   r70.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $79
        or (32|M0)               r68.0<1>:d    r4.0<1;1,0>:d     r6.0<1;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $76
        shl (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     16:w               {Compacted,$2.dst} //  ALU pipe: int; $78
        or (32|M0)               r70.0<1>:d    r10.0<1;1,0>:d    r12.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $80
// B007: [inDivergent],  Preds:{B006, B005},  Succs:{B008, B009}
_0_033:
        join (32|M0)                         _0_031                                                  // 
L1376:
        add (16|M0)              r3.0<1>:q     r34.0<1;1,0>:q    128:w               {Compacted}     //  ALU pipe: int; $82
        add (16|M16)             r5.0<1>:q     r36.0<1;1,0>:q    128:w               {Compacted}     //  ALU pipe: int; $82
        add (16|M0)              r7.0<1>:q     r3.0<1;1,0>:q     r90.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $83
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r88.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $83
        add (16|M0)              r11.0<1>:q    r7.0<1;1,0>:q     r78.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $84
        add (16|M16)             r13.0<1>:q    r9.0<1;1,0>:q     r76.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $84
        mov (16|M0)              r16.0<1>:d    r11.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $86
        mov (16|M16)             r17.0<1>:d    r13.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $86
        shl (32|M0)              r18.0<1>:d    r16.0<1;1,0>:d    3:w               {Compacted,I@1}   //  ALU pipe: int; $87
        and (32|M0)   (eq)f1.0   r20.0<1>:d    r18.0<1;1,0>:d    24:w               {I@1}            //  ALU pipe: int; $88
        shr (32|M0)              r22.0<1>:ud   r20.0<1;1,0>:ud   3:w               {I@1}             //  ALU pipe: int; $89
        mov (16|M0)              r24.0<2>:ud   r22.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $91
        mov (16|M16)             r26.0<2>:ud   r23.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $91
        add (16|M0)              r64.0<1>:q    r11.0<1;1,0>:q    -r24.0<2;1,0>:ud {I@2}              //  ALU pipe: int; $91
        add (16|M16)             r66.0<1>:q    r13.0<1;1,0>:q    -r26.0<2;1,0>:ud {I@2}              //  ALU pipe: int; $91
        load.ugm.d32x2.a64 (32|M0)  r28:4       [r64:4]            {I@1,$3} // ex_desc:0x0; desc:0x8401580 // $92
        mov (32|M0)              r96.0<1>:f    r28.0<1;1,0>:f                   {Compacted,$3.dst}   //  ALU pipe: float; $93
        mov (32|M0)              r98.0<1>:d    r30.0<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $94
(f1.0)  goto (32|M0)                         _0_035            _0_035                                //  ALU pipe: int; $96
// B008: [inDivergent],  Preds:{B007},  Succs:{B009}
_0_036:
        load.ugm.d32.a64 (32|M0)  r8:2          [r64:4+0x8]        {$4} // ex_desc:0x8000; desc:0x8200580 // $101
        shl (32|M0)              r4.0<1>:d     r98.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $98
        shr (32|M0)              r6.0<1>:ud    r96.0<1;1,0>:ud   16:w               {F@1}            //  ALU pipe: int; $99
        shr (32|M0)              r12.0<1>:ud   r98.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $103
        or (32|M0)               r96.0<1>:d    r4.0<1;1,0>:d     r6.0<1;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $100
        shl (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     16:w               {Compacted,$4.dst} //  ALU pipe: int; $102
        or (32|M0)               r98.0<1>:d    r10.0<1;1,0>:d    r12.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $104
// B009: [inDivergent],  Preds:{B008, B007},  Succs:{B010, B017}
_0_035:
        join (32|M0)                         _0_031                                                  // 
L1672:
        load.ugm.d16u32.a64 (32|M0)  r20:2      [r34:4+0xD0]       {$5} // ex_desc:0xD0000; desc:0x8200B80 // $116
        shr (32|M0)              r6.0<1>:ud    r96.0<1;1,0>:ud   r80.0<1;1,0>:d                      //  ALU pipe: int; $107 R{} IR{}{E:0,E:0,},  R{} IR{}{O:0,O:8,},  {BC=1}
        shr (32|M0)              r14.0<1>:ud   r98.0<1;1,0>:ud   r80.0<1;1,0>:d   {I@3}              //  ALU pipe: int; $112
        shl (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     4:w               {Compacted,I@2}   //  ALU pipe: int; $108
        shl (32|M0)              r16.0<1>:d    r14.0<1;1,0>:d    4:w               {Compacted,I@2}   //  ALU pipe: int; $113
        shr (32|M0)              r4.0<1>:ud    r68.0<1;1,0>:ud   r82.0<1;1,0>:d                      //  ALU pipe: int; $106
        shr (32|M0)              r12.0<1>:ud   r70.0<1;1,0>:ud   r82.0<1;1,0>:d                      //  ALU pipe: int; $111
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     808464432:d               {I@4}     //  ALU pipe: int; $109
        and (32|M0)              r18.0<1>:d    r16.0<1;1,0>:d    808464432:d               {I@4}     //  ALU pipe: int; $114
        bfn.(s0&s1|s2) (32|M0)   r56.0<1>:ud   r4.0<1;0>:ud      r105.2<0;0>:ud    r10.0<1>:ud      {I@2} //  ALU pipe: int; $110
        bfn.(s0&s1|s2) (32|M0)   r58.0<1>:ud   r12.0<1;0>:ud     r105.2<0;0>:ud    r18.0<1>:ud      {I@2} //  ALU pipe: int; $115
        shr (32|M0)              r22.0<1>:ud   r20.0<1;1,0>:ud   10:w               {$5.dst}         //  ALU pipe: int; $120
        and (32|M0)              r110.0<1>:d   r22.0<1;1,0>:d    31:w               {Compacted,I@1}  //  ALU pipe: int; $121
        cmp (32|M0)   (eq)f0.0   null<1>:d     r110.0<1;1,0>:d   31:w               {I@1}            //  ALU pipe: int; $123
        and (32|M0)              r50.0<1>:d    r20.0<2;1,0>:w    -2147483648:d                       //  ALU pipe: int; $119
        and (32|M0)              r106.0<1>:d   r20.0<1;1,0>:ud   1023:w                              //  ALU pipe: int; $122
(f0.0)  goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $124
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B012}
_0_038:
        cmp (32|M0)   (eq)f3.0   null<1>:d     r110.0<1;1,0>:d   0:w                                 //  ALU pipe: int; $126
(f3.0)  goto (32|M0)                         _0_039            _0_039                                //  ALU pipe: int; $127
// B011: [inDivergent],  Preds:{B010},  Succs:{B018}
_0_040:
        shl (32|M0)              r4.0<1>:d     r110.0<1;1,0>:d   23:w               {Compacted}      //  ALU pipe: int; $129
        shl (32|M0)              r8.0<1>:d     r106.0<1;1,0>:d   13:w               {Compacted,I@5}  //  ALU pipe: int; $131
        add (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     939524096:d               {I@2}     //  ALU pipe: int; $130
        bfn.(s0|s1|s2) (32|M0)   r50.0<1>:ud   r6.0<1;0>:ud      r8.0<1;0>:ud      r50.0<1>:ud      {I@1} //  ALU pipe: int; $132 R{} IR{}{E:3,E:4,E:1,},  R{} IR{}{O:3,O:4,O:9,},  {BC=2}
        goto (32|M0)                         _0_039            _0_041                                // $133
// B012: [inDivergent],  Preds:{B010},  Succs:{B013, B018}
_0_039:
        join (32|M0)                         _0_037                                                  // 
L2032:
        cmp (32|M0)   (eq)f2.0   null<1>:d     r106.0<1;1,0>:d   0:w                                 //  ALU pipe: int; $135
(f2.0)  goto (32|M0)                         _0_037            _0_041                                //  ALU pipe: int; $136
// B013: [inDivergent],  Preds:{B012},  Succs:{B014}
_0_042:
(W)     mov (1|M0)               r2.6<1>:d     -14:w                                                 //  ALU pipe: int; $138
// B014: [inDivergent],  Preds:{B015, B013},  Succs:{B015, B016}
_0_043:
        and (32|M0)   (eq)f0.0   null<1>:d     r106.0<1;1,0>:d   512:w                               //  ALU pipe: int; $141
(W)     add (1|M0)               r2.6<1>:d     r2.6<0;1,0>:d     -1:w               {I@2}            //  ALU pipe: int; $140
        mov (32|M0)              r108.0<1>:d   r2.6<0;1,0>:d                    {Compacted,I@1}      //  ALU pipe: int; $143
(~f0.0) goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $144
// B015: [inDivergent],  Preds:{B014},  Succs:{B014}
_0_045:
        shl (32|M0)              r106.0<1>:d   r106.0<1;1,0>:d   1:w               {Compacted}       //  ALU pipe: int; $146
(W)     jmpi                                 _0_043                                                  // $147
// B016: [inDivergent],  Preds:{B014},  Succs:{B018}
_0_044:
        join (32|M0)                         _0_037                                                  // 
L2176:
        shl (32|M0)              r4.0<1>:d     r108.0<1;1,0>:d   23:w               {Compacted,I@5}  //  ALU pipe: int; $149
        shl (32|M0)              r8.0<1>:d     r106.0<1;1,0>:d   14:w               {Compacted,I@4}  //  ALU pipe: int; $151
        add (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1065353216:d               {I@2}    //  ALU pipe: int; $150
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     8372224:d               {I@2}       //  ALU pipe: int; $152
        bfn.(s0|s1|s2) (32|M0)   r50.0<1>:ud   r6.0<1;0>:ud      r10.0<1;0>:ud     r50.0<1>:ud      {I@1} //  ALU pipe: int; $153 R{} IR{}{E:3,E:5,E:1,},  R{} IR{}{O:3,O:5,O:9,},  {BC=2}
        goto (32|M0)                         _0_037            _0_041                                // $154
// B017: [inDivergent],  Preds:{B009},  Succs:{B018}
_0_037:
        join (32|M0)                         _0_041                                                  // 
L2272:
        cmp (32|M0)   (eq)f1.0   null<1>:d     r106.0<1;1,0>:d   0:w                                 //  ALU pipe: int; $156
(W)     mov (1|M0)               r2.12<1>:hf   0x0:hf                                                //  ALU pipe: float; $157
(f1.0)  sel (32|M0)              r4.0<1>:d     r2.12<0;1,0>:w    4194304:d               {F@1}       //  ALU pipe: int; $157
        bfn.(s0|s1|s2) (32|M0)   r50.0<1>:ud   r50.0<1;0>:ud     r4.0<1;0>:ud      r105.3<0>:ud     {I@1} //  ALU pipe: int; $158
// B018: [inDivergent],  Preds:{B017, B016, B012, B011},  Succs:{B019, B020}
_0_041:
        join (32|M0)                         _0_031                                                  // 
L2352:
        add (16|M0)              r3.0<1>:q     r34.0<1;1,0>:q    192:w               {Compacted}     //  ALU pipe: int; $160
        add (16|M16)             r5.0<1>:q     r36.0<1;1,0>:q    192:w               {Compacted}     //  ALU pipe: int; $160
        add (16|M0)              r12.0<1>:q    r3.0<1;1,0>:q     r86.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $161
        add (16|M16)             r14.0<1>:q    r5.0<1;1,0>:q     r84.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $161
        load.ugm.d8u32.a64 (32|M0)  r24:2       [r12:4]            {I@1,$6} // ex_desc:0x0; desc:0x8200980 // $162
        shl (32|M0)              r8.0<1>:d     r54.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $164
        mov (16|M0)              r18.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $166
        mov (16|M16)             r20.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $166
        add (16|M0)              r26.0<1>:q    r2.1<0;1,0>:q     r18.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $166 R{} IR{}{E:1,E:1,},  R{r2,} IR{} {BC=1}
        add (16|M16)             r28.0<1>:q    r2.1<0;1,0>:q     r20.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $166
        load.ugm.d32.a64 (32|M0)  r36:2         [r26:4]            {I@1,$7} // ex_desc:0x0; desc:0x8200580 // $167
        load.ugm.d32.a64 (32|M0)  r38:2         [r26:4+0x4]        {$8} // ex_desc:0x4000; desc:0x8200580 // $168
        load.ugm.d32.a64 (32|M0)  r4:2          [r26:4+0x8]        {$9} // ex_desc:0x8000; desc:0x8200580 // $169
        load.ugm.d32.a64 (32|M0)  r6:2          [r26:4+0xC]        {$10} // ex_desc:0xC000; desc:0x8200580 // $218
        shr (32|M0)              r16.0<1>:ud   r56.0<1;1,0>:ud   8:w                                 //  ALU pipe: int; $180
        and (32|M0)              r30.0<1>:d    r16.0<1;1,0>:d    63:w               {Compacted,I@1}  //  ALU pipe: int; $181
        and (32|M0)              r10.0<1>:d    r56.0<1;1,0>:d    63:w               {Compacted}      //  ALU pipe: int; $176
        shr (32|M0)              r20.0<1>:ud   r58.0<1;1,0>:ud   8:w                                 //  ALU pipe: int; $198
        add (32|M0)              r40.0<1>:d    r30.0<1;1,0>:d    -32:w               {Compacted,I@3} //  ALU pipe: int; $182
        mov (32|M0)              r3.0<1>:b     r24.0<4;1,0>:b                   {$6.dst}             //  ALU pipe: int; $163
        shr (32|M0)              r26.0<1>:ud   r58.0<1;1,0>:ud   16:w               {$10.src}        //  ALU pipe: int; $203
        add (32|M0)              r22.0<1>:d    r10.0<1;1,0>:d    -32:w               {Compacted,I@5} //  ALU pipe: int; $177
        mov (32|M0)   (lt)f0.0   null<2>:w     r3.0<1;1,0>:b                    {I@3}                //  ALU pipe: int; $171
        and (32|M0)              r46.0<1>:d    r20.0<1;1,0>:d    63:w               {Compacted}      //  ALU pipe: int; $199
        shr (32|M0)              r10.0<1>:ud   r56.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $190
        shr (32|M0)              r32.0<1>:ud   r56.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $185
        and (32|M0)              r12.0<1>:d    r58.0<1;1,0>:d    63:w               {Compacted}      //  ALU pipe: int; $194
        mov (32|M0)              r14.0<1>:f    r40.0<1;1,0>:d                                        //  ALU pipe: float; $183
        or (32|M0)               r20.0<1>:d    r24.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $170
        mov (32|M0)              r34.0<1>:f    r22.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $178
        and (32|M0)              r40.0<1>:d    r26.0<1;1,0>:d    63:w               {Compacted,F@2}  //  ALU pipe: int; $204
        add (32|M0)              r18.0<1>:d    r10.0<1;1,0>:d    -32:w               {Compacted,I@5} //  ALU pipe: int; $191
        add (32|M0)              r22.0<1>:d    r12.0<1;1,0>:d    -32:w               {Compacted,A@1} //  ALU pipe: int; $195
(f0.0)  sel (32|M0)              r26.0<1>:d    r20.0<1;1,0>:d    r24.0<1;1,0>:ud  {I@4}              //  ALU pipe: int; $173
        and (32|M0)              r8.0<1>:d     r32.0<1;1,0>:d    63:w               {Compacted}      //  ALU pipe: int; $186
        add (32|M0)              r10.0<1>:d    r40.0<1;1,0>:d    -32:w               {Compacted,I@5} //  ALU pipe: int; $205
        mov (32|M0)              r40.0<1>:f    r26.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $174
        mov (32|M0)              r28.0<1>:f    r22.0<1;1,0>:d                                        //  ALU pipe: float; $196
        add (32|M0)              r16.0<1>:d    r8.0<1;1,0>:d     -32:w               {Compacted}     //  ALU pipe: int; $187
        add (32|M0)              r30.0<1>:d    r46.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $200
        shr (32|M0)              r32.0<1>:ud   r58.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $208
        mul (32|M0)              acc0.0<1>:f   r50.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $175
        sync.nop                             null                             {Compacted,F@2}        // $221
        mov (32|M0)              r22.0<1>:d    r36.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $221
        mov (32|M0)              r44.0<1>:f    r18.0<1;1,0>:d                                        //  ALU pipe: float; $192
        mov (32|M0)              r42.0<1>:f    r16.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $188
        mov (32|M0)              r46.0<1>:d    r36.1<2;1,0>:uw                                       //  ALU pipe: int; $225
        mul (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   r34.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $179
        shl (32|M0)              r48.0<1>:d    r22.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $222
        mov (32|M0)              r8.0<1>:f     r30.0<1;1,0>:d                                        //  ALU pipe: float; $201
        add (32|M0)              r12.0<1>:d    r32.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $209
        mul (32|M0)              r36.0<1>:f    acc0.0<1;1,0>:f   r14.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $184
        mul (32|M0)              r20.0<1>:f    acc0.0<1;1,0>:f   r42.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $189
        mul (32|M0)              r22.0<1>:f    acc0.0<1;1,0>:f   r44.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $193
        shl (32|M0)              r30.0<1>:d    r46.0<1;1,0>:d    16:w               {Compacted,F@4}  //  ALU pipe: int; $226
        mov (32|M0)              r16.0<1>:f    r10.0<1;1,0>:d                                        //  ALU pipe: float; $206
        mov (32|M0)              r32.0<1>:d    r38.0<2;1,0>:uw                  {$8.dst}             //  ALU pipe: int; $229
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r48.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $223
        mov (32|M0)              r18.0<1>:f    r12.0<1;1,0>:d                   {I@3}                //  ALU pipe: float; $210
        mov (32|M0)              r10.0<1>:d    r38.1<2;1,0>:uw                  {F@3}                //  ALU pipe: int; $233
        mul (32|M0)              r24.0<1>:f    r36.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $227
        shl (32|M0)              r12.0<1>:d    r32.0<1;1,0>:d    16:w               {Compacted,A@2}  //  ALU pipe: int; $230
        mul (32|M0)              r38.0<1>:f    acc0.0<1;1,0>:f   r28.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $197
        add (32|M0)              acc2.0<1>:f   r62.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $224
        shl (32|M0)              r50.0<1>:d    r10.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $234
        mul (32|M0)              r26.0<1>:f    r20.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $231
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r24.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $228
        mov (32|M0)              r52.0<1>:d    r4.0<2;1,0>:uw                   {$9.dst}             //  ALU pipe: int; $237
        mul (32|M0)              r14.0<1>:f    acc0.0<1;1,0>:f   r8.0<1;1,0>:f    {Compacted}        //  ALU pipe: float; $202
        mov (32|M0)              r40.0<1>:d    r4.1<2;1,0>:uw                                        //  ALU pipe: int; $241
        mul (32|M0)              r32.0<1>:f    r22.0<1;1,0>:f    r50.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $235
        shl (32|M0)              r10.0<1>:d    r52.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $238
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r26.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $232
        shl (32|M0)              r42.0<1>:d    r40.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $242
        mul (32|M0)              r12.0<1>:f    acc0.0<1;1,0>:f   r16.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $207
        mov (32|M0)              r30.0<1>:d    r6.0<2;1,0>:uw                   {$10.dst}            //  ALU pipe: int; $245
        mul (32|M0)              r34.0<1>:f    r38.0<1;1,0>:f    r10.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $239
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r32.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $236
        mov (32|M0)              r28.0<1>:d    r6.1<2;1,0>:uw                                        //  ALU pipe: int; $249
        mul (32|M0)              r20.0<1>:f    r14.0<1;1,0>:f    r42.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $243
        shl (32|M0)              r22.0<1>:d    r30.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $246
        mul (32|M0)              r4.0<1>:f     acc0.0<1;1,0>:f   r18.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $211
        shl (32|M0)              r10.0<1>:d    r28.0<1;1,0>:d    16:w               {Compacted,A@2}  //  ALU pipe: int; $250
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r34.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $240
        mul (32|M0)              r8.0<1>:f     r12.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $247
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r20.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $244
        mul (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     r10.0<1;1,0>:f   {Compacted,A@1}    //  ALU pipe: float; $251
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r54.0<1;1,0>:ud   0x900:uw                            //  ALU pipe: int; $253
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r8.0<1;1,0>:f    {Compacted,F@3}    //  ALU pipe: float; $248
        add (32|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $252
(~f3.0) goto (32|M0)                         _0_031            _0_031                                //  ALU pipe: int; $254
// B019: [inDivergent],  Preds:{B018},  Succs:{B005}
_0_046:
        add (32|M0)              r54.0<1>:d    r54.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $256
(W)     jmpi                                 _0_032                                                  // $257
// B020: Preds:{B018, B003},  Succs:{B021, B025}
_0_031:
        join (32|M0)                         L3408                                                   // 
L3408:
        add (32|M0)              r4.0<1>:d     r60.0<1;1,0>:d    1:w               {Compacted,F@3}   //  ALU pipe: int; $259
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $260
        shl (32|M0)              r3.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $261
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $262
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0xF80:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0059(r62.0:f); $263
        add (32|M0)              r10.0<1>:d    r60.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $272
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $264
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $265
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0xF80:uw                            //  ALU pipe: int; src1 is addr of V0059(r62.0:f); $266
        and (32|M0)   (eq)f2.0   null<1>:d     r60.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $268
        and (32|M0)              r4.0<1>:d     r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $273
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $267
        shl (32|M0)              r12.0<1>:uw   r4.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $274
(f2.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $270
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $275
        add (16|M0)              a0.0<1>:uw    r12.0<1;1,0>:uw   0x1E00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0335(r120.0:f); $276
        add (32|M0)              r120.0<1>:f   r62.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $271
        add (32|M0)              r8.0<1>:d     r60.0<1;1,0>:d    4:w               {Compacted,F@2}   //  ALU pipe: int; $285
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $277
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $278
        add (16|M16)             a0.0<1>:uw    r12.16<1;1,0>:uw  0x1E00:uw                           //  ALU pipe: int; src1 is addr of V0335(r120.0:f); $279
        and (32|M0)   (eq)f1.0   null<1>:d     r60.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $281
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $286
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $280
        shl (32|M0)              r3.0<1>:uw    r10.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $287
(f1.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $283
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $288
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0x1D80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0343(r118.0:f); $289
        add (32|M0)              r118.0<1>:f   r120.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $284
        add (32|M0)              r6.0<1>:d     r60.0<1;1,0>:d    8:w               {Compacted,F@2}   //  ALU pipe: int; $298
        mov (16|M0)              r4.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $290
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $291
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0x1D80:uw                           //  ALU pipe: int; src1 is addr of V0343(r118.0:f); $292
        and (32|M0)   (eq)f0.0   null<1>:d     r60.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $294
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $299
        mov (16|M16)             r5.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $293
        shl (32|M0)              r12.0<1>:uw   r8.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $300
(f0.0)  sel (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $296
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $301
        add (16|M0)              a0.0<1>:uw    r12.0<1;1,0>:uw   0x1D00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0351(r116.0:f); $302
        add (32|M0)              r116.0<1>:f   r118.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $297
        add (32|M0)              r4.0<1>:d     r60.0<1;1,0>:d    16:w               {Compacted,F@2}  //  ALU pipe: int; $311
        mov (16|M0)              r10.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $303
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $304
        add (16|M16)             a0.0<1>:uw    r12.16<1;1,0>:uw  0x1D00:uw                           //  ALU pipe: int; src1 is addr of V0351(r116.0:f); $305
        and (32|M0)   (eq)f3.0   null<1>:d     r60.0<1;1,0>:d    15:w                                //  ALU pipe: int; $307
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $312
        mov (16|M16)             r11.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $306
        shl (32|M0)              r3.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $313
(f3.0)  sel (32|M0)              acc0.0<1>:f   r10.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $309
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $314
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0x1E80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0359(r122.0:f); $315
        add (32|M0)              r122.0<1>:f   r116.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $310
        cmp (32|M0)   (eq)f2.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $320
        mov (16|M0)              r114.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $316
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $317
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0x1E80:uw                           //  ALU pipe: int; src1 is addr of V0359(r122.0:f); $318
        mov (16|M16)             r115.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $319
(~f2.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $321
// B021: [inDivergent],  Preds:{B020},  Succs:{B022, B023}
_0_048:
        and (32|M0)   (eq)f1.0   null<1>:d     r60.0<1;1,0>:d    31:w                                //  ALU pipe: int; $323
(f1.0)  sel (32|M0)              acc0.0<1>:f   r114.0<1;1,0>:f   0x80000000:f               {I@3}    //  ALU pipe: float; $325
        add (32|M0)              r112.0<1>:f   r122.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $326
        and (32|M0)              r4.0<1>:d     r112.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $327
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r4.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $328
(f0.0)  goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $329
// B022: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_050:
        shr (32|M0)              r4.0<1>:ud    r112.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $331
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $332
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r112.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $333
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $334
        mov (32|M0)              r124.0<1>:w   r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $335
        goto (32|M0)                         _0_049            _0_051                                // $336
// B023: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_049:
        join (32|M0)                         _0_051                                                  // 
L4432:
        shr (32|M0)              r4.0<1>:ud    r112.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $338
        or (32|M0)               r124.0<1>:w   r4.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $340
// B024: [inDivergent],  Preds:{B023, B022},  Succs:{B025}
_0_051:
        join (32|M0)                         _0_047                                                  // 
L4480:
(W)     mov (1|M0)               f1.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $345
        cmp (32|M0)   (eq)f1.0   null<2>:uw    r1.0<0;1,0>:uw    r1.0<0;1,0>:uw                      //  ALU pipe: int; $346
(W)     fbl (1|M0)               r3.0<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $348
(W)     shl (1|M0)               r2.3<1>:q     r104.1<0;1,0>:ud  1:w                                 //  ALU pipe: int; $343
(W)     shl (1|M0)               r3.0<1>:ud    r3.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $349
(W)     add (1|M0)               r4.0<1>:q     r2.3<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $344
(W)     add (1|M0)               a0.0<1>:uw    r3.0<0;1,0>:uw    0x1F00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0379(r124.0:w); $350
(W)     mov (1|M0)               r6.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $352
(W)     store.ugm.d16u32.a64 (1|M0)  [r4:2]     r6:1               {I@1,$11} // ex_desc:0x0; desc:0x4000B84 // $353
// B025: Preds:{B024, B020},  Succs:{}
_0_047:
        join (32|M0)                         L4624                                                   // 
L4624:
(W)     mov (16|M0)              r127.0<1>:f   r104.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $355
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$12} // wr:1+0, rd:0; end of thread // $355
L4648:
(W)     mov (16|M0)              null<1>:ud    0x785C230:ud                                          // 
(W)     mov (16|M0)              null<1>:ud    0x58CB52D6:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x3:ud                                                // 


//.BankConflicts: 11
//.ByteRMWs: 0
//


//.numALUInst: 326
//.accSubDef: 16
//.accSubUse: 23
//.accSubCandidateDef: 29
//.accSubCandidateUse: 36
//
//
//.singlePipeAtOneDistNum: 50
//.allAtOneDistNum: 5
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 11
//.AfterReadTokenDepCount: 2
