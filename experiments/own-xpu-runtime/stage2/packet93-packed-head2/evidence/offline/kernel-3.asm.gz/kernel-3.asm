//.kernel _ZTS19Packet93OfflineHeadILj3EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 126206512 1489720022 -hashmovs1 0 4 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 126206512 1489720022 -hashmovs1 0 4 -GRFBumpUpNumber 2 "
//.instCount 314
//.RA type	LOCAL_FIRST_FIT_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r54.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r54.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.0)
//.declare V0035 (45)  rf=r size=8 type=uq align=4 words (r2.1)
//.declare V0036 (46)  rf=r size=8 type=uq align=4 words (r2.2)
//.declare V0038 (48)  rf=r size=32 type=d alias=+0 align=32 words (r54.0)
//.declare V0040 (50)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0050 (60)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0051 (61)  rf=r size=64 type=uw alias=V0040+0 align=32 words (r1.0)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r55.0)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r55.1)
//.declare V0054 (64)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r55.0)
//.declare V0055 (65)  rf=r size=32 type=ud alias=V0038+0 align=32 words (r54.0)
//.declare V0056 (66)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P01 (69)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0059 (70)  rf=r size=128 type=f align=32 words (r58.0)
//.declare V0060 (71)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0062 (73)  rf=r size=8 type=q align=4 words (r55.1)
//.declare V0063 (74)  rf=r size=8 type=d alias=V0062+0 align=4 words (r55.2)
//.declare V0064 (75)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.0)
//.declare V0065 (76)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0066 (77)  rf=r size=8 type=q align=4 words (r2.4)
//.declare V0067 (78)  rf=r size=8 type=q align=4 words (r2.5)
//.declare V0068 (79)  rf=r size=64 type=w align=32 words (r3.0)
//.declare V0070 (81)  rf=r size=64 type=uw alias=V0068+0 align=32 words (r3.0)
//.declare V0071 (82)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0073 (84)  rf=r size=128 type=ud alias=V0071+0 align=32 words (r4.0)
//.declare V0074 (85)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0075 (86)  rf=r size=128 type=ud alias=V0074+0 align=32 words (r6.0)
//.declare V0076 (87)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0077 (88)  rf=r size=128 type=ud alias=V0076+0 align=32 words (r8.0)
//.declare V0082 (93)  rf=r size=8 type=q align=4 words (r18.0)
//.declare V0083 (94)  rf=r size=8 type=ud alias=V0082+0 align=4 words (r18.0)
//.declare V0084 (95)  rf=r size=8 type=d alias=V0082+0 align=4 words (r18.0)
//.declare V0085 (96)  rf=r size=4 type=d align=32 words (r19.0)
//.declare V0087 (98)  rf=r size=8 type=q align=4 words (r55.2)
//.declare V0090 (101)  rf=r size=8 type=q alias=V0035+0 align=32 words (r2.1)
//.declare V0091 (102)  rf=r size=4 type=d align=2 words (r55.6)
//.declare V0092 (103)  rf=r size=4 type=d align=2 words (r55.7)
//.declare V0093 (104)  rf=r size=4 type=d align=2 words (r55.8)
//.declare V0094 (105)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0095 (106)  rf=r size=128 type=ud alias=V0060+0 align=32 words (r60.0)
//.declare V0096 (107)  rf=r size=128 type=ud alias=V0094+0 align=32 words (r4.0)
//.declare V0100 (111)  rf=r size=256 type=q align=32 words (r32.0)
//.declare V0101 (112)  rf=r size=256 type=uq alias=V0100+0 align=32 words (r32.0)
//.declare V0102 (113)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0104 (115)  rf=r size=256 type=q align=32 words (r28.0)
//.declare V0105 (116)  rf=r size=256 type=uq alias=V0104+0 align=32 words (r28.0)
//.declare V0106 (117)  rf=r size=64 type=w align=32 words (r64.0)
//.declare V0107 (118)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare V0108 (119)  rf=r size=128 type=w alias=V0107+0 align=32 words (r4.0)
//.declare V0110 (121)  rf=r size=256 type=q align=32 words (r14.0)
//.declare V0111 (122)  rf=r size=256 type=uq alias=V0110+0 align=32 words (r14.0)
//.declare V0113 (124)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare V0114 (125)  rf=r size=128 type=w alias=V0113+0 align=32 words (r26.0)
//.declare V0116 (127)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0118 (129)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0119 (130)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0120 (131)  rf=r size=128 type=ud alias=V0119+0 align=32 words (r6.0)
//.declare V0121 (132)  rf=r size=128 type=d align=32 words (r70.0)
//.declare P02 (133)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare P03 (134)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0122 (135)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0123 (136)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0124 (137)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P04 (138)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0125 (139)  rf=r size=4 type=d align=2 words (r55.9)
//.declare P05 (140)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0127 (142)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0128 (143)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0129 (144)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0130 (145)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0131 (146)  rf=r size=128 type=d align=32 words (r10.0)
//.declare P06 (147)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0132 (148)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0134 (150)  rf=r size=256 type=q align=32 words (r12.0)
//.declare V0135 (151)  rf=r size=256 type=uq alias=V0134+0 align=32 words (r12.0)
//.declare V0136 (152)  rf=r size=32 type=b align=32 words (r3.0)
//.declare V0137 (153)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0138 (154)  rf=r size=128 type=b alias=V0137+0 align=32 words (r24.0)
//.declare V0139 (155)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0141 (157)  rf=r size=128 type=ud alias=V0139+0 align=32 words (r8.0)
//.declare V0142 (158)  rf=r size=256 type=q align=32 words (r26.0)
//.declare V0143 (159)  rf=r size=256 type=uq alias=V0142+0 align=32 words (r26.0)
//.declare V0144 (160)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0145 (161)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0146 (162)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0148 (164)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0149 (165)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P07 (167)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0151 (168)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0153 (170)  rf=r size=128 type=f alias=V0116+0 align=32 words (r66.0)
//.declare V0155 (172)  rf=r size=64 type=uw alias=V0106+0 align=32 words (r64.0)
//.declare V0156 (173)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0157 (174)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0158 (175)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0159 (176)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0160 (177)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0162 (179)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0163 (180)  rf=r size=128 type=ud alias=V0102+0 align=32 words (r62.0)
//.declare V0164 (181)  rf=r size=128 type=ud alias=V0162+0 align=32 words (r32.0)
//.declare V0165 (182)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0166 (183)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0167 (184)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0168 (185)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0169 (186)  rf=r size=128 type=f align=32 words (r46.0)
//.declare V0170 (187)  rf=r size=128 type=f align=32 words (r36.0)
//.declare V0171 (188)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0172 (189)  rf=r size=128 type=ud alias=V0171+0 align=32 words (r10.0)
//.declare V0173 (190)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0174 (191)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0175 (192)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0176 (193)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0177 (194)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0178 (195)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0179 (196)  rf=r size=128 type=ud alias=V0178+0 align=32 words (r22.0)
//.declare V0180 (197)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0182 (199)  rf=r size=128 type=ud alias=V0180+0 align=32 words (r14.0)
//.declare V0183 (200)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0184 (201)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0185 (202)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0186 (203)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0187 (204)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0188 (205)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0189 (206)  rf=r size=128 type=ud alias=V0188+0 align=32 words (r30.0)
//.declare V0190 (207)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0191 (208)  rf=r size=128 type=ud alias=V0190+0 align=32 words (r44.0)
//.declare V0192 (209)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0193 (210)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0194 (211)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0195 (212)  rf=r size=128 type=f align=32 words (r50.0)
//.declare V0196 (213)  rf=r size=128 type=f align=32 words (r38.0)
//.declare V0197 (214)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0198 (215)  rf=r size=128 type=ud alias=V0197+0 align=32 words (r12.0)
//.declare V0199 (216)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0200 (217)  rf=r size=128 type=ud alias=V0199+0 align=32 words (r34.0)
//.declare V0201 (218)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0202 (219)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0203 (220)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0204 (221)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0205 (222)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0206 (223)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0207 (224)  rf=r size=128 type=ud alias=V0206+0 align=32 words (r42.0)
//.declare V0208 (225)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0209 (226)  rf=r size=128 type=ud alias=V0208+0 align=32 words (r48.0)
//.declare V0210 (227)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0211 (228)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0212 (229)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0213 (230)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0214 (231)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0215 (232)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0216 (233)  rf=r size=128 type=ud alias=V0215+0 align=32 words (r30.0)
//.declare V0217 (234)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0218 (235)  rf=r size=128 type=ud alias=V0217+0 align=32 words (r32.0)
//.declare V0219 (236)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0220 (237)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0221 (238)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0222 (239)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0224 (241)  rf=r size=128 type=w alias=V0144+0 align=32 words (r36.0)
//.declare V0228 (245)  rf=r size=128 type=w alias=V0145+0 align=32 words (r38.0)
//.declare V0232 (249)  rf=r size=128 type=w alias=V0146+0 align=32 words (r4.0)
//.declare V0235 (252)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0237 (254)  rf=r size=128 type=w alias=V0235+0 align=32 words (r6.0)
//.declare V0240 (257)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0242 (259)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0244 (261)  rf=r size=128 type=f alias=V0242+0 align=32 words (r28.0)
//.declare V0246 (263)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0248 (265)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0249 (266)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0250 (267)  rf=r size=128 type=f alias=V0248+0 align=32 words (r44.0)
//.declare V0252 (269)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0254 (271)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0255 (272)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0256 (273)  rf=r size=128 type=f alias=V0254+0 align=32 words (r48.0)
//.declare V0258 (275)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0260 (277)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0261 (278)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0262 (279)  rf=r size=128 type=f alias=V0260+0 align=32 words (r12.0)
//.declare V0264 (281)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0266 (283)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0267 (284)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0268 (285)  rf=r size=128 type=f alias=V0266+0 align=32 words (r8.0)
//.declare V0270 (287)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0272 (289)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0273 (290)  rf=r size=128 type=f align=32 words (r36.0)
//.declare V0274 (291)  rf=r size=128 type=f alias=V0272+0 align=32 words (r20.0)
//.declare V0276 (293)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0278 (295)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0279 (296)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0280 (297)  rf=r size=128 type=f alias=V0278+0 align=32 words (r12.0)
//.declare V0282 (299)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0284 (301)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0286 (303)  rf=r size=128 type=f alias=V0284+0 align=32 words (r8.0)
//.declare P08 (304)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0287 (305)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0288 (306)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0289 (307)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0290 (308)  rf=r size=128 type=uw alias=V0288+0 align=32 words (r6.0)
//.declare V0291 (309)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A00 (310)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P09 (311)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0294 (314)  rf=r size=128 type=f align=32 words (r74.0)
//.declare V0295 (315)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0296 (316)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0297 (317)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0298 (318)  rf=r size=128 type=uw alias=V0296+0 align=32 words (r4.0)
//.declare V0299 (319)  rf=r size=64 type=uw align=32 words (r12.0)
//.declare A01 (320)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P10 (321)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0302 (324)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0303 (325)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0304 (326)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0305 (327)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0306 (328)  rf=r size=128 type=uw alias=V0304+0 align=32 words (r10.0)
//.declare V0307 (329)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A02 (330)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P11 (331)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0310 (334)  rf=r size=128 type=f align=32 words (r78.0)
//.declare V0311 (335)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0312 (336)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0313 (337)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0314 (338)  rf=r size=128 type=uw alias=V0312+0 align=32 words (r8.0)
//.declare V0315 (339)  rf=r size=64 type=uw align=32 words (r12.0)
//.declare A03 (340)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P12 (341)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0318 (344)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0319 (345)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0320 (346)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0321 (347)  rf=r size=128 type=f align=32 words (r82.0)
//.declare V0322 (348)  rf=r size=128 type=uw alias=V0320+0 align=32 words (r6.0)
//.declare V0323 (349)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A04 (350)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P13 (351)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P14 (352)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0326 (355)  rf=r size=128 type=f align=32 words (r84.0)
//.declare V0327 (356)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0328 (357)  rf=r size=128 type=d alias=V0326+0 align=32 words (r84.0)
//.declare P15 (358)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0329 (359)  rf=r size=128 type=ud alias=V0327+0 align=32 words (r4.0)
//.declare V0330 (360)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0331 (361)  rf=r size=128 type=ud alias=V0326+0 align=32 words (r84.0)
//.declare V0332 (362)  rf=r size=128 type=ud alias=V0330+0 align=32 words (r4.0)
//.declare V0333 (363)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0334 (364)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0335 (365)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0336 (366)  rf=r size=128 type=ud alias=V0334+0 align=32 words (r8.0)
//.declare V0337 (367)  rf=r size=128 type=ud alias=V0335+0 align=32 words (r10.0)
//.declare V0338 (368)  rf=r size=64 type=w align=32 words (r65.0)
//.declare V0339 (369)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0340 (370)  rf=r size=128 type=ud alias=V0339+0 align=32 words (r4.0)
//.declare V0342 (372)  rf=r size=8 type=q alias=V0036+0 align=32 words (r2.2)
//.declare V0344 (374)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0345 (375)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0346 (376)  rf=r size=8 type=uq alias=V0345+0 align=32 words (r4.0)
//.declare P16 (377)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0347 (378)  rf=r size=2 type=uw align=32 words (r86.0)
//.declare V0349 (380)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare V0350 (381)  rf=r size=4 type=uw alias=V0349+0 align=2 words (r3.0)
//.declare A05 (382)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0352 (384)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare  (386)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (387)  rf=r size=128 type=w alias=V0339+0 align=32 words (r4.0)
//.declare  (388)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (389)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (390)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (391)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (392)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare  (393)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (394)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (395)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (398)  rf=r size=2 type=w align=1 words (r2.12)
//.declare  (399)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (400)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare  (401)  rf=r size=128 type=w alias=V0335+0 align=32 words (r10.0)
//.declare  (404)  rf=r size=128 type=q align=32 words (r87.0)
//.declare  (405)  rf=r size=128 type=q align=32 words (r89.0)
//.declare  (408)  rf=r size=128 type=q align=32 words (r91.0)
//.declare  (409)  rf=r size=128 type=q align=32 words (r93.0)
//.declare  (412)  rf=r size=128 type=q align=32 words (r95.0)
//.declare  (413)  rf=r size=128 type=q align=32 words (r97.0)
//.declare  (416)  rf=r size=128 type=q align=32 words (r99.0)
//.declare  (417)  rf=r size=128 type=q align=32 words (r101.0)
//.declare  (418)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (419)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (420)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (421)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (422)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (423)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (424)  rf=r size=128 type=q align=32 words (r3.0)
//.declare  (425)  rf=r size=128 type=q align=32 words (r5.0)
//.declare r0 (428)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (429)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (430)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (431)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (432)  rf=r size=64 type=ud align=32 words (r1.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0034    | :uq      |    0x8 | r2       | inline+0x0       |
// | V0035    | :uq      |    0x8 | r2+0x8   | inline+0x8       |
// | V0036    | :uq      |    0x8 | r2+0x10  | inline+0x10      |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@2}           //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
// B002: Preds:{B001},  Succs:{B003, B004}
// _main:
(W)     mov (16|M0)              r54.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
        cmp (32|M0)   (lt)f3.0   null<2>:uw    r1.0<1;1,0>:uw    0x140:uw              {A@1,$0.dst}  //  ALU pipe: int; $10
(W)     mul (1|M0)               acc0.0<1>:ud  r54.1<0;1,0>:ud   0xA:uw              {I@4}           //  ALU pipe: int; $4
(W)     mach (1|M0)              r3.0<1>:d     r54.1<0;1,0>:ud   0xA:ud                              //  ALU pipe: int; 
        mov (32|M0)              r56.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $2
(W)     mul (1|M0)               r55.0<1>:ud   r54.1<0;1,0>:ud   0xA:uw              {Compacted}     //  ALU pipe: int; $3
(W)     mov (1|M0)               r55.1<1>:d    r3.0<0;1,0>:d                    {Compacted,I@3}      //  ALU pipe: int; $9
(f3.0)  goto (32|M0)                         _0_023            _0_023                                //  ALU pipe: int; $11
// B003: [inDivergent],  Preds:{B002},  Succs:{B016}
_0_024:
        mov (32|M0)              r58.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $13
        goto (32|M0)                         _0_023            _0_025                                // $14
// B004: [inDivergent],  Preds:{B002},  Succs:{B005}
_0_023:
        join (32|M0)                         _0_025                                                  // 
L336:
        shl (32|M0)              r3.0<1>:w     r1.0<1;1,0>:w     3:w                                 //  ALU pipe: int; $24
        and (32|M0)              r3.0<1>:w     r3.0<1;1,0>:w     248:w               {I@1}           //  ALU pipe: int; $25
        shr (32|M0)              r4.0<1>:ud    r3.0<1;1,0>:uw    2:w               {I@1}             //  ALU pipe: int; $27
        shr (32|M0)              r6.0<1>:ud    r3.0<1;1,0>:uw    1:w                                 //  ALU pipe: int; $28
        shr (32|M0)              r8.0<1>:ud    r3.0<1;1,0>:uw    4:w                                 //  ALU pipe: int; $29
(W)     mul (1|M0)               acc0.0<1>:ud  r54.1<0;1,0>:ud   0x14:uw                             //  ALU pipe: int; $35
(W)     mach (1|M0)              r19.0<1>:d    r54.1<0;1,0>:ud   0x14:ud                             //  ALU pipe: int; 
        shl (32|M0)              r60.0<1>:d    r56.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $16
(W)     add (1|M0)               r2.3<1>:q     r2.0<0;1,0>:q     317849600:d                         //  ALU pipe: int; $21
(W)     add (1|M0)               r2.5<1>:q     r2.0<0;1,0>:q     476774400:d                         //  ALU pipe: int; $23
        mov (32|M0)              r58.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $46
        mov (16|M0)              r14.0<2>:ud   r4.0<1;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $33
        mov (16|M16)             r16.0<2>:ud   r5.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $33
        mov (16|M0)              r10.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $31
        mov (16|M16)             r12.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $31
        mov (16|M0)              r20.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $42
        mov (16|M16)             r6.0<2>:ud    r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $42
(W)     add (1|M0)               r2.4<1>:q     r2.0<0;1,0>:q     516505600:d                         //  ALU pipe: int; $22
(W)     mul (1|M0)               r18.0<2>:ud   r54.1<0;1,0>:ud   0x14:uw                             //  ALU pipe: int; $34
(W)     mov (1|M0)               r18.1<2>:d    r19.0<0;1,0>:d                                        //  ALU pipe: int; $39
        add (16|M0)              r91.0<1>:q    r2.3<0;1,0>:q     r14.0<2;1,0>:ud  {I@7}              //  ALU pipe: int; $33
        add (16|M16)             r93.0<1>:q    r2.3<0;1,0>:q     r16.0<2;1,0>:ud  {I@7}              //  ALU pipe: int; $33
        add (16|M0)              r87.0<1>:q    r2.0<0;1,0>:q     r10.0<2;1,0>:ud  {I@7}              //  ALU pipe: int; $31
        add (16|M16)             r89.0<1>:q    r2.0<0;1,0>:q     r12.0<2;1,0>:ud  {I@7}              //  ALU pipe: int; $31
        add (16|M0)              r95.0<1>:q    r2.5<0;1,0>:q     r20.0<2;1,0>:ud  {I@7}              //  ALU pipe: int; $42
        add (16|M16)             r97.0<1>:q    r2.5<0;1,0>:q     r6.0<2;1,0>:ud   {I@7}              //  ALU pipe: int; $42
(W)     mov (1|M0)               r55.2<1>:d    r55.0<0;1,0>:d                   {Compacted}          //  ALU pipe: int; $17
(W)     mov (1|M0)               r55.3<1>:d    r55.1<0;1,0>:d                                        //  ALU pipe: int; $18
(W)     mov (1|M0)               r55.6<1>:f    0x7F800000:f                                          //  (0x7f800000:f); ALU pipe: float; $43
(W)     mov (1|M0)               r55.7<1>:d    48:w                                                  //  ALU pipe: int; $44
(W)     mov (1|M0)               r55.8<1>:d    15:w                                                  //  ALU pipe: int; $45
(W)     add (1|M0)               r55.2<1>:q    r2.4<0;1,0>:q     r18.0<0;1,0>:q   {I@7}              //  ALU pipe: int; $40 R{} IR{}{E:1,E:1,},  {BC=1}
// B005: [inDivergent],  Preds:{B015, B004},  Succs:{B006, B013}
_0_026:
        shr (32|M0)              r4.0<1>:ud    r60.0<1;1,0>:ud   8:w                                 //  ALU pipe: int; $48
        mov (16|M0)              r6.0<2>:ud    r4.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $50
        mov (16|M16)             r8.0<2>:ud    r5.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $50
        shl (16|M0)              r10.0<1>:q    r6.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $58
        shl (16|M16)             r12.0<1>:q    r8.0<2;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $58
        add (16|M0)              r14.0<1>:q    r55.2<0;1,0>:q    r10.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $59
        add (16|M16)             r16.0<1>:q    r55.2<0;1,0>:q    r12.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $59
        load.ugm.d16u32.a64 (32|M0)  r26:2      [r14:4]            {I@1,$1} // ex_desc:0x0; desc:0x8200B80 // $60
        add (16|M0)              r99.0<1>:q    r55.1<0;1,0>:q    r6.0<2;1,0>:ud                      //  ALU pipe: int; $50
        add (16|M16)             r101.0<1>:q   r55.1<0;1,0>:q    r8.0<2;1,0>:ud                      //  ALU pipe: int; $50
        shl (16|M0)              r18.0<1>:q    r99.0<1;1,0>:q    6:w               {Compacted,I@2}   //  ALU pipe: int; $54
        shl (16|M16)             r20.0<1>:q    r101.0<1;1,0>:q   6:w               {Compacted,I@2}   //  ALU pipe: int; $54
        shl (16|M0)              r22.0<1>:q    r99.0<1;1,0>:q    7:w               {Compacted}       //  ALU pipe: int; $51
        shl (16|M16)             r24.0<1>:q    r101.0<1;1,0>:q   7:w               {Compacted}       //  ALU pipe: int; $51
        add (16|M0)              r28.0<1>:q    r91.0<1;1,0>:q    r18.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $55
        add (16|M16)             r30.0<1>:q    r93.0<1;1,0>:q    r20.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $55
        add (16|M0)              r32.0<1>:q    r87.0<1;1,0>:q    r22.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $52
        add (16|M16)             r34.0<1>:q    r89.0<1;1,0>:q    r24.0<1;1,0>:q   {Compacted,I@4}    //  ALU pipe: int; $52
        load.ugm.d16u32.a64 (32|M0)  r4:2       [r28:4]            {I@3,$2} // ex_desc:0x0; desc:0x8200B80 // $56
        load.ugm.d32.a64 (32|M0)  r62:2         [r32:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200580 // $53
        shr (32|M0)              r6.0<1>:ud    r26.0<1;1,0>:ud   10:w               {$1.dst}         //  ALU pipe: int; $64
        and (32|M0)              r70.0<1>:d    r6.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $65
        cmp (32|M0)   (eq)f0.0   null<1>:d     r70.0<1;1,0>:d    31:w               {I@1}            //  ALU pipe: int; $67
        and (32|M0)              r66.0<1>:d    r26.0<2;1,0>:w    -2147483648:d                       //  ALU pipe: int; $63
        and (32|M0)              r68.0<1>:d    r26.0<1;1,0>:ud   1023:w                              //  ALU pipe: int; $66
        mov (32|M0)              r64.0<1>:w    r4.0<2;1,0>:w                    {$2.dst}             //  ALU pipe: int; $57
(f0.0)  goto (32|M0)                         _0_027            _0_027                                //  ALU pipe: int; $68
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_028:
        cmp (32|M0)   (eq)f3.0   null<1>:d     r70.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $70
(f3.0)  goto (32|M0)                         _0_029            _0_029                                //  ALU pipe: int; $71
// B007: [inDivergent],  Preds:{B006},  Succs:{B014}
_0_030:
        shl (32|M0)              r4.0<1>:d     r70.0<1;1,0>:d    23:w               {Compacted}      //  ALU pipe: int; $73
        shl (32|M0)              r8.0<1>:d     r68.0<1;1,0>:d    13:w               {Compacted,I@6}  //  ALU pipe: int; $75
        add (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     939524096:d               {I@2}     //  ALU pipe: int; $74
        bfn.(s0|s1|s2) (32|M0)   r66.0<1>:ud   r6.0<1;0>:ud      r8.0<1;0>:ud      r66.0<1>:ud      {I@1} //  ALU pipe: int; $76 R{} IR{}{E:3,E:4,E:1,},  R{} IR{}{O:3,O:4,O:1,},  {BC=2}
        goto (32|M0)                         _0_029            _0_031                                // $77
// B008: [inDivergent],  Preds:{B006},  Succs:{B009, B014}
_0_029:
        join (32|M0)                         _0_027                                                  // 
L1216:
        cmp (32|M0)   (eq)f2.0   null<1>:d     r68.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $79
(f2.0)  goto (32|M0)                         _0_027            _0_031                                //  ALU pipe: int; $80
// B009: [inDivergent],  Preds:{B008},  Succs:{B010}
_0_032:
(W)     mov (1|M0)               r55.9<1>:d    -14:w                                                 //  ALU pipe: int; $82
// B010: [inDivergent],  Preds:{B011, B009},  Succs:{B011, B012}
_0_033:
        and (32|M0)   (eq)f0.0   null<1>:d     r68.0<1;1,0>:d    512:w                               //  ALU pipe: int; $85
(W)     add (1|M0)               r55.9<1>:d    r55.9<0;1,0>:d    -1:w               {I@2}            //  ALU pipe: int; $84
        mov (32|M0)              r72.0<1>:d    r55.9<0;1,0>:d                   {Compacted,I@1}      //  ALU pipe: int; $87
(~f0.0) goto (32|M0)                         _0_034            _0_034                                //  ALU pipe: int; $88
// B011: [inDivergent],  Preds:{B010},  Succs:{B010}
_0_035:
        shl (32|M0)              r68.0<1>:d    r68.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $90
(W)     jmpi                                 _0_033                                                  // $91
// B012: [inDivergent],  Preds:{B010},  Succs:{B014}
_0_034:
        join (32|M0)                         _0_027                                                  // 
L1360:
        shl (32|M0)              r4.0<1>:d     r72.0<1;1,0>:d    23:w               {Compacted,I@5}  //  ALU pipe: int; $93
        shl (32|M0)              r8.0<1>:d     r68.0<1;1,0>:d    14:w               {Compacted,I@4}  //  ALU pipe: int; $95
        add (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1065353216:d               {I@2}    //  ALU pipe: int; $94
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     8372224:d               {I@2}       //  ALU pipe: int; $96
        bfn.(s0|s1|s2) (32|M0)   r66.0<1>:ud   r6.0<1;0>:ud      r10.0<1;0>:ud     r66.0<1>:ud      {I@1} //  ALU pipe: int; $97 R{} IR{}{E:3,E:5,E:1,},  R{} IR{}{O:3,O:5,O:1,},  {BC=2}
        goto (32|M0)                         _0_027            _0_031                                // $98
// B013: [inDivergent],  Preds:{B005},  Succs:{B014}
_0_027:
        join (32|M0)                         _0_031                                                  // 
L1456:
        cmp (32|M0)   (eq)f1.0   null<1>:d     r68.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $100
(W)     mov (1|M0)               r2.12<1>:hf   0x0:hf                                                //  ALU pipe: float; $101
(f1.0)  sel (32|M0)              r4.0<1>:d     r2.12<0;1,0>:w    4194304:d               {F@1}       //  ALU pipe: int; $101
        bfn.(s0|s1|s2) (32|M0)   r66.0<1>:ud   r66.0<1;0>:ud     r4.0<1;0>:ud      r55.6<0>:ud      {I@1} //  ALU pipe: int; $102
// B014: [inDivergent],  Preds:{B013, B012, B008, B007},  Succs:{B015, B016}
_0_031:
        join (32|M0)                         _0_025                                                  // 
L1536:
        shl (16|M0)              r3.0<1>:q     r99.0<1;1,0>:q    4:w               {Compacted}       //  ALU pipe: int; $104
        shl (16|M16)             r5.0<1>:q     r101.0<1;1,0>:q   4:w               {Compacted}       //  ALU pipe: int; $104
        add (16|M0)              r12.0<1>:q    r95.0<1;1,0>:q    r3.0<1;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $105
        add (16|M16)             r14.0<1>:q    r97.0<1;1,0>:q    r5.0<1;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $105
        load.ugm.d8u32.a64 (32|M0)  r24:2       [r12:4]            {I@1,$4} // ex_desc:0x0; desc:0x8200980 // $106
        shl (32|M0)              r8.0<1>:d     r60.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $108
        mov (16|M0)              r18.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $110
        mov (16|M16)             r20.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $110
        add (16|M0)              r26.0<1>:q    r2.1<0;1,0>:q     r18.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $110 R{} IR{}{E:1,E:1,},  R{r2,} IR{} {BC=1}
        add (16|M16)             r28.0<1>:q    r2.1<0;1,0>:q     r20.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $110
        load.ugm.d32.a64 (32|M0)  r36:2         [r26:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $111
        load.ugm.d32.a64 (32|M0)  r38:2         [r26:4+0x4]        {$6} // ex_desc:0x4000; desc:0x8200580 // $112
        load.ugm.d32.a64 (32|M0)  r4:2          [r26:4+0x8]        {$7} // ex_desc:0x8000; desc:0x8200580 // $113
        load.ugm.d32.a64 (32|M0)  r6:2          [r26:4+0xC]        {$8} // ex_desc:0xC000; desc:0x8200580 // $180
        shl (32|M0)              r10.0<1>:d    r64.0<1;1,0>:uw   4:w                                 //  ALU pipe: int; $121
        shl (32|M0)              r16.0<1>:d    r64.0<1;1,0>:uw   2:w                                 //  ALU pipe: int; $128
        shr (32|M0)              r32.0<1>:ud   r62.0<1;1,0>:ud   4:w               {$3.dst}          //  ALU pipe: int; $127
        and (32|M0)              r22.0<1>:d    r10.0<1;1,0>:d    48:w               {Compacted,I@3}  //  ALU pipe: int; $122
        and (32|M0)              r34.0<1>:d    r16.0<1;1,0>:d    48:w               {Compacted,I@3}  //  ALU pipe: int; $129
        shr (32|M0)              r10.0<1>:ud   r62.0<1;1,0>:ud   8:w                                 //  ALU pipe: int; $134
        and (32|M0)              r12.0<1>:d    r64.0<1;1,0>:uw   48:w               {$4.src}         //  ALU pipe: int; $135
        shr (32|M0)              r14.0<1>:ud   r64.0<1;1,0>:uw   2:w                                 //  ALU pipe: int; $141
        bfn.(s0&s1|s2) (32|M0)   r8.0<1>:ud    r32.0<1;0>:ud     r55.8<0;0>:ud     r34.0<1>:ud      {I@4} //  ALU pipe: int; $130
        bfn.(s0&s1|s2) (32|M0)   r30.0<1>:ud   r62.0<1;0>:ud     r55.8<0;0>:ud     r22.0<1>:ud       //  ALU pipe: int; $123
        shr (32|M0)              r34.0<1>:ud   r64.0<1;1,0>:uw   6:w                                 //  ALU pipe: int; $155
        bfn.(s0&s1|s2) (32|M0)   r16.0<1>:ud   r10.0<1;0>:ud     r55.8<0;0>:ud     r12.0<1>:ud      {I@5} //  ALU pipe: int; $136
        shr (32|M0)              r22.0<1>:ud   r62.0<1;1,0>:ud   12:w                                //  ALU pipe: int; $140
        and (32|M0)              r42.0<1>:d    r14.0<1;1,0>:d    48:w               {Compacted,I@6}  //  ALU pipe: int; $142
        add (32|M0)              r40.0<1>:d    r30.0<1;1,0>:d    -32:w               {Compacted,I@5} //  ALU pipe: int; $124
        shr (32|M0)              r12.0<1>:ud   r62.0<1;1,0>:ud   20:w                                //  ALU pipe: int; $154
        shr (32|M0)              r44.0<1>:ud   r64.0<1;1,0>:uw   4:w                                 //  ALU pipe: int; $148
        add (32|M0)              r26.0<1>:d    r16.0<1;1,0>:d    -32:w               {Compacted,@6,$8.src} //  ALU pipe: int; $137
        and (32|M0)              r14.0<1>:d    r34.0<1;1,0>:d    48:w               {Compacted}      //  ALU pipe: int; $156
        bfn.(s0&s1|s2) (32|M0)   r28.0<1>:ud   r22.0<1;0>:ud     r55.8<0;0>:ud     r42.0<1>:ud      {I@6} //  ALU pipe: int; $143
        mov (32|M0)              r3.0<1>:b     r24.0<4;1,0>:b                   {$4.dst}             //  ALU pipe: int; $107
        mov (32|M0)              r18.0<1>:f    r40.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $125
        shr (32|M0)              r30.0<1>:ud   r62.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $147
        bfn.(s0&s1|s2) (32|M0)   r22.0<1>:ud   r12.0<1;0>:ud     r55.8<0;0>:ud     r14.0<1>:ud      {I@4} //  ALU pipe: int; $157
        and (32|M0)              r32.0<1>:d    r44.0<1;1,0>:d    48:w               {Compacted}      //  ALU pipe: int; $149
        mov (32|M0)              r40.0<1>:f    r26.0<1;1,0>:d                                        //  ALU pipe: float; $138
        add (32|M0)              r20.0<1>:d    r8.0<1;1,0>:d     -32:w               {Compacted}     //  ALU pipe: int; $131
        mov (32|M0)   (lt)f2.0   null<2>:w     r3.0<1;1,0>:b                    {I@5}                //  ALU pipe: int; $115
        add (32|M0)              r26.0<1>:d    r22.0<1;1,0>:d    -32:w               {Compacted,A@1} //  ALU pipe: int; $158
        bfn.(s0&s1|s2) (32|M0)   r10.0<1>:ud   r30.0<1;0>:ud     r55.8<0;0>:ud     r32.0<1>:ud      {I@4} //  ALU pipe: int; $150
        add (32|M0)              r8.0<1>:d     r28.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $144
        shr (32|M0)              r48.0<1>:ud   r64.0<1;1,0>:uw   8:w                                 //  ALU pipe: int; $162
        or (32|M0)               r14.0<1>:d    r24.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $114
        shr (32|M0)              r30.0<1>:ud   r62.0<1;1,0>:ud   28:w                                //  ALU pipe: int; $168
        shr (32|M0)              r32.0<1>:ud   r64.0<1;1,0>:uw   10:w                                //  ALU pipe: int; $169
        mov (32|M0)              r46.0<1>:f    r20.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $132
        mov (32|M0)              r34.0<1>:f    r26.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $159
        shr (32|M0)              r42.0<1>:ud   r62.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $161
        mov (32|M0)              r20.0<1>:f    r8.0<1;1,0>:d                    {I@6}                //  ALU pipe: float; $145
(f2.0)  sel (32|M0)              r26.0<1>:d    r14.0<1;1,0>:d    r24.0<1;1,0>:ud  {A@2}              //  ALU pipe: int; $117
        and (32|M0)              r44.0<1>:d    r48.0<1;1,0>:d    48:w               {Compacted}      //  ALU pipe: int; $163
        bfn.(s0|s1&s2) (32|M0)   r8.0<1>:ud    r30.0<1;0>:ud     r32.0<1;0>:ud     r55.7<0>:ud      {A@1} //  ALU pipe: int; $170
        mov (32|M0)              r30.0<1>:f    r26.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $118
        bfn.(s0&s1|s2) (32|M0)   r28.0<1>:ud   r42.0<1;0>:ud     r55.8<0;0>:ud     r44.0<1>:ud       //  ALU pipe: int; $164
        mov (32|M0)              r22.0<1>:d    r36.0<2;1,0>:uw                  {$5.dst}             //  ALU pipe: int; $183
        mul (32|M0)              acc0.0<1>:f   r66.0<1;1,0>:f    r30.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $119
        add (32|M0)              r52.0<1>:d    r28.0<1;1,0>:d    -32:w               {Compacted,I@2} //  ALU pipe: int; $165
        add (32|M0)              r16.0<1>:d    r10.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $151
        mov (32|M0)              r42.0<1>:d    r36.1<2;1,0>:uw                                       //  ALU pipe: int; $187
        mul (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   r18.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $126
        shl (32|M0)              r28.0<1>:d    r22.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $184
        shl (32|M0)              r44.0<1>:d    r42.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $188
        mul (32|M0)              r36.0<1>:f    acc0.0<1;1,0>:f   r46.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $133
        mul (32|M0)              r14.0<1>:f    acc0.0<1;1,0>:f   r40.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $139
        mul (32|M0)              r22.0<1>:f    acc0.0<1;1,0>:f   r20.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $146
        add (32|M0)              r12.0<1>:d    r8.0<1;1,0>:d     -32:w               {Compacted}     //  ALU pipe: int; $171
        mov (32|M0)              r32.0<1>:d    r38.0<2;1,0>:uw                  {$6.dst}             //  ALU pipe: int; $191
        mov (32|M0)              r50.0<1>:f    r16.0<1;1,0>:d                                        //  ALU pipe: float; $152
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r28.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $185
        mov (32|M0)              r8.0<1>:d     r38.1<2;1,0>:uw                                       //  ALU pipe: int; $195
        mul (32|M0)              r24.0<1>:f    r36.0<1;1,0>:f    r44.0<1;1,0>:f   {Compacted,A@4}    //  ALU pipe: float; $189
        shl (32|M0)              r48.0<1>:d    r32.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $192
        mul (32|M0)              r38.0<1>:f    acc0.0<1;1,0>:f   r50.0<1;1,0>:f   {Compacted,A@2}    //  ALU pipe: float; $153
        add (32|M0)              acc2.0<1>:f   r58.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $186
        mov (32|M0)              r16.0<1>:f    r12.0<1;1,0>:d                                        //  ALU pipe: float; $172
        mov (32|M0)              r10.0<1>:f    r52.0<1;1,0>:d                                        //  ALU pipe: float; $166
        mul (32|M0)              r26.0<1>:f    r14.0<1;1,0>:f    r48.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $193
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r24.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $190
        shl (32|M0)              r12.0<1>:d    r8.0<1;1,0>:d     16:w               {Compacted,F@4}  //  ALU pipe: int; $196
        sync.nop                             null                             {Compacted,F@3}        // $199
        mov (32|M0)              r52.0<1>:d    r4.0<2;1,0>:uw                   {$7.dst}             //  ALU pipe: int; $199
        mul (32|M0)              r18.0<1>:f    acc0.0<1;1,0>:f   r34.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $160
        mov (32|M0)              r32.0<1>:d    r4.1<2;1,0>:uw                                        //  ALU pipe: int; $203
        mul (32|M0)              r30.0<1>:f    r22.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $197
        shl (32|M0)              r8.0<1>:d     r52.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $200
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r26.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $194
        shl (32|M0)              r20.0<1>:d    r32.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $204
        mul (32|M0)              r14.0<1>:f    acc0.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $167
        mov (32|M0)              r28.0<1>:d    r6.0<2;1,0>:uw                   {$8.dst}             //  ALU pipe: int; $207
        mul (32|M0)              r40.0<1>:f    r38.0<1;1,0>:f    r8.0<1;1,0>:f    {Compacted,I@3}    //  ALU pipe: float; $201
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r30.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $198
        mov (32|M0)              r22.0<1>:d    r6.1<2;1,0>:uw                                        //  ALU pipe: int; $211
        mul (32|M0)              r36.0<1>:f    r18.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $205
        shl (32|M0)              r12.0<1>:d    r28.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $208
        mul (32|M0)              r4.0<1>:f     acc0.0<1;1,0>:f   r16.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $173
        shl (32|M0)              r8.0<1>:d     r22.0<1;1,0>:d    16:w               {Compacted,A@2}  //  ALU pipe: int; $212
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r40.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $202
        mul (32|M0)              r24.0<1>:f    r14.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $209
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r36.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $206
        mul (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     r8.0<1;1,0>:f    {Compacted,A@1}    //  ALU pipe: float; $213
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r60.0<1;1,0>:ud   0x900:uw                            //  ALU pipe: int; $215
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r24.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $210
        add (32|M0)              r58.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $214
(~f1.0) goto (32|M0)                         _0_025            _0_025                                //  ALU pipe: int; $216
// B015: [inDivergent],  Preds:{B014},  Succs:{B005}
_0_036:
        add (32|M0)              r60.0<1>:d    r60.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $218
(W)     jmpi                                 _0_026                                                  // $219
// B016: Preds:{B014, B003},  Succs:{B017, B021}
_0_025:
        join (32|M0)                         L2864                                                   // 
L2864:
        add (32|M0)              r4.0<1>:d     r56.0<1;1,0>:d    1:w               {Compacted,F@3}   //  ALU pipe: int; $221
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $222
        shl (32|M0)              r3.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $223
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $224
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0xE80:uw              {I@2}         //  ALU pipe: int; src1 is addr of V0059(r58.0:f); $225
        add (32|M0)              r10.0<1>:d    r56.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $234
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $226
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $227
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0xE80:uw                            //  ALU pipe: int; src1 is addr of V0059(r58.0:f); $228
        and (32|M0)   (eq)f2.0   null<1>:d     r56.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $230
        and (32|M0)              r4.0<1>:d     r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $235
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $229
        shl (32|M0)              r12.0<1>:uw   r4.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $236
(f2.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $232
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $237
        add (16|M0)              a0.0<1>:uw    r12.0<1;1,0>:uw   0x1280:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0294(r74.0:f); $238
        add (32|M0)              r74.0<1>:f    r58.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $233
        add (32|M0)              r8.0<1>:d     r56.0<1;1,0>:d    4:w               {Compacted,F@2}   //  ALU pipe: int; $247
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $239
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $240
        add (16|M16)             a0.0<1>:uw    r12.16<1;1,0>:uw  0x1280:uw                           //  ALU pipe: int; src1 is addr of V0294(r74.0:f); $241
        and (32|M0)   (eq)f1.0   null<1>:d     r56.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $243
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $248
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $242
        shl (32|M0)              r3.0<1>:uw    r10.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $249
(f1.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $245
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $250
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0x1300:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0302(r76.0:f); $251
        add (32|M0)              r76.0<1>:f    r74.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $246
        add (32|M0)              r6.0<1>:d     r56.0<1;1,0>:d    8:w               {Compacted,F@2}   //  ALU pipe: int; $260
        mov (16|M0)              r4.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $252
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $253
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0x1300:uw                           //  ALU pipe: int; src1 is addr of V0302(r76.0:f); $254
        and (32|M0)   (eq)f0.0   null<1>:d     r56.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $256
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $261
        mov (16|M16)             r5.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $255
        shl (32|M0)              r12.0<1>:uw   r8.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $262
(f0.0)  sel (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $258
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $263
        add (16|M0)              a0.0<1>:uw    r12.0<1;1,0>:uw   0x1380:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0310(r78.0:f); $264
        add (32|M0)              r78.0<1>:f    r76.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $259
        add (32|M0)              r4.0<1>:d     r56.0<1;1,0>:d    16:w               {Compacted,F@2}  //  ALU pipe: int; $273
        mov (16|M0)              r10.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $265
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $266
        add (16|M16)             a0.0<1>:uw    r12.16<1;1,0>:uw  0x1380:uw                           //  ALU pipe: int; src1 is addr of V0310(r78.0:f); $267
        and (32|M0)   (eq)f3.0   null<1>:d     r56.0<1;1,0>:d    15:w                                //  ALU pipe: int; $269
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $274
        mov (16|M16)             r11.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $268
        shl (32|M0)              r3.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $275
(f3.0)  sel (32|M0)              acc0.0<1>:f   r10.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $271
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $276
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0x1400:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0318(r80.0:f); $277
        add (32|M0)              r80.0<1>:f    r78.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $272
        cmp (32|M0)   (eq)f2.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $282
        mov (16|M0)              r82.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $278
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $279
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0x1400:uw                           //  ALU pipe: int; src1 is addr of V0318(r80.0:f); $280
        mov (16|M16)             r83.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $281
(~f2.0) goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $283
// B017: [inDivergent],  Preds:{B016},  Succs:{B018, B019}
_0_038:
        and (32|M0)   (eq)f1.0   null<1>:d     r56.0<1;1,0>:d    31:w                                //  ALU pipe: int; $285
(f1.0)  sel (32|M0)              acc0.0<1>:f   r82.0<1;1,0>:f    0x80000000:f               {I@3}    //  ALU pipe: float; $287
        add (32|M0)              r84.0<1>:f    r80.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $288
        and (32|M0)              r4.0<1>:d     r84.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $289
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r4.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $290
(f0.0)  goto (32|M0)                         _0_039            _0_039                                //  ALU pipe: int; $291
// B018: [inDivergent],  Preds:{B017},  Succs:{B020}
_0_040:
        shr (32|M0)              r4.0<1>:ud    r84.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $293
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $294
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r84.0<1;0>:d      32767:w               {I@1} //  ALU pipe: int; $295
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $296
        mov (32|M0)              r65.0<1>:w    r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $297
        goto (32|M0)                         _0_039            _0_041                                // $298
// B019: [inDivergent],  Preds:{B017},  Succs:{B020}
_0_039:
        join (32|M0)                         _0_041                                                  // 
L3888:
        shr (32|M0)              r4.0<1>:ud    r84.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $300
        or (32|M0)               r65.0<1>:w    r4.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $302
// B020: [inDivergent],  Preds:{B019, B018},  Succs:{B021}
_0_041:
        join (32|M0)                         _0_037                                                  // 
L3936:
(W)     mov (1|M0)               f3.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $307
        cmp (32|M0)   (eq)f3.0   null<2>:uw    r86.0<0;1,0>:uw   r86.0<0;1,0>:uw                     //  ALU pipe: int; $308
(W)     fbl (1|M0)               r3.0<1>:ud    f3.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $310
(W)     shl (1|M0)               r2.3<1>:q     r54.1<0;1,0>:ud   1:w                                 //  ALU pipe: int; $305
(W)     shl (1|M0)               r3.0<1>:ud    r3.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $311
(W)     add (1|M0)               r4.0<1>:q     r2.3<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $306
(W)     add (1|M0)               a0.0<1>:uw    r3.0<0;1,0>:uw    0x1040:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0338(r65.0:w); $312
(W)     mov (1|M0)               r6.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $314
(W)     store.ugm.d16u32.a64 (1|M0)  [r4:2]     r6:1               {I@1,$9} // ex_desc:0x0; desc:0x4000B84 // $315
// B021: Preds:{B020, B016},  Succs:{}
_0_037:
        join (32|M0)                         L4080                                                   // 
L4080:
(W)     mov (16|M0)              r127.0<1>:f   r54.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $317
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$10} // wr:1+0, rd:0; end of thread // $317
L4104:
(W)     mov (16|M0)              null<1>:ud    0x785C230:ud                                          // 
(W)     mov (16|M0)              null<1>:ud    0x58CB52D6:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x4:ud                                                // 


//.BankConflicts: 6
//.ByteRMWs: 0
//


//.numALUInst: 280
//.accSubDef: 16
//.accSubUse: 23
//.accSubCandidateDef: 29
//.accSubCandidateUse: 36
//
//
//.singlePipeAtOneDistNum: 38
//.allAtOneDistNum: 6
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 9
//.AfterReadTokenDepCount: 3
