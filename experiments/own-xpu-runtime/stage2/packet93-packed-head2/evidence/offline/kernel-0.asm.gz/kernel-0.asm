//.kernel _ZTS19Packet93OfflineHeadILj0EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 126206512 1489720022 -hashmovs1 0 1 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 126206512 1489720022 -hashmovs1 0 1 -GRFBumpUpNumber 2 "
//.instCount 234
//.RA type	LOCAL_ROUND_ROBIN_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r103.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r103.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.0)
//.declare V0035 (45)  rf=r size=8 type=uq align=4 words (r2.1)
//.declare V0036 (46)  rf=r size=8 type=uq align=4 words (r2.2)
//.declare V0038 (48)  rf=r size=32 type=d alias=+0 align=32 words (r103.0)
//.declare V0040 (50)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0049 (59)  rf=r size=128 type=d align=32 words (r104.0)
//.declare V0050 (60)  rf=r size=64 type=uw alias=V0040+0 align=32 words (r1.0)
//.declare V0051 (61)  rf=r size=4 type=d align=2 words (r106.0)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r106.1)
//.declare V0053 (63)  rf=r size=4 type=ud alias=V0051+0 align=2 words (r106.0)
//.declare V0054 (64)  rf=r size=32 type=ud alias=V0038+0 align=16 words (r103.0)
//.declare V0055 (65)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P01 (68)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0058 (69)  rf=r size=128 type=f align=32 words (r107.0)
//.declare V0060 (71)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0061 (72)  rf=r size=8 type=d alias=V0060+0 align=4 words (r2.6)
//.declare V0062 (73)  rf=r size=8 type=q alias=V0034+0 align=4 words (r2.0)
//.declare V0063 (74)  rf=r size=8 type=q align=4 words (r106.1)
//.declare V0064 (75)  rf=r size=128 type=d align=32 words (r109.0)
//.declare V0065 (76)  rf=r size=8 type=q align=4 words (r106.2)
//.declare V0066 (77)  rf=r size=8 type=q alias=V0035+0 align=4 words (r2.1)
//.declare V0067 (78)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0068 (79)  rf=r size=128 type=ud alias=V0064+0 align=32 words (r109.0)
//.declare V0069 (80)  rf=r size=128 type=ud alias=V0067+0 align=32 words (r7.0)
//.declare V0070 (81)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0072 (83)  rf=r size=128 type=ud alias=V0070+0 align=32 words (r17.0)
//.declare V0073 (84)  rf=r size=256 type=q align=32 words (r31.0)
//.declare V0074 (85)  rf=r size=256 type=uq alias=V0073+0 align=32 words (r31.0)
//.declare V0075 (86)  rf=r size=128 type=f align=32 words (r39.0)
//.declare V0077 (88)  rf=r size=256 type=q align=32 words (r9.0)
//.declare V0078 (89)  rf=r size=256 type=uq alias=V0077+0 align=32 words (r9.0)
//.declare V0079 (90)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0080 (91)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0082 (93)  rf=r size=256 type=q align=32 words (r21.0)
//.declare V0083 (94)  rf=r size=256 type=uq alias=V0082+0 align=32 words (r21.0)
//.declare V0084 (95)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0086 (97)  rf=r size=128 type=b alias=V0079+0 align=32 words (r19.0)
//.declare V0087 (98)  rf=r size=32 type=b align=32 words (r45.0)
//.declare V0088 (99)  rf=r size=32 type=b align=32 words (r48.0)
//.declare V0089 (100)  rf=r size=32 type=b align=32 words (r53.0)
//.declare V0090 (101)  rf=r size=32 type=b align=32 words (r64.0)
//.declare V0092 (103)  rf=r size=128 type=b alias=V0080+0 align=32 words (r29.0)
//.declare V0093 (104)  rf=r size=32 type=b align=32 words (r77.0)
//.declare V0094 (105)  rf=r size=32 type=b align=32 words (r90.0)
//.declare V0095 (106)  rf=r size=32 type=b align=32 words (r5.0)
//.declare V0096 (107)  rf=r size=32 type=b align=32 words (r20.0)
//.declare V0097 (108)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0098 (109)  rf=r size=128 type=ub alias=V0079+0 align=32 words (r19.0)
//.declare V0099 (110)  rf=r size=128 type=ud alias=V0097+0 align=32 words (r46.0)
//.declare V0100 (111)  rf=r size=128 type=d align=32 words (r49.0)
//.declare P02 (113)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0102 (114)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0103 (115)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0106 (118)  rf=r size=128 type=w alias=V0084+0 align=32 words (r35.0)
//.declare V0109 (121)  rf=r size=128 type=d align=32 words (r37.0)
//.declare V0110 (122)  rf=r size=128 type=d align=32 words (r41.0)
//.declare V0111 (123)  rf=r size=128 type=d align=32 words (r43.0)
//.declare V0113 (125)  rf=r size=128 type=w alias=V0109+0 align=32 words (r37.0)
//.declare V0116 (128)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0118 (130)  rf=r size=128 type=d align=32 words (r71.0)
//.declare V0120 (132)  rf=r size=128 type=f alias=V0118+0 align=32 words (r71.0)
//.declare V0121 (133)  rf=r size=128 type=f align=32 words (r97.0)
//.declare V0122 (134)  rf=r size=128 type=d align=32 words (r51.0)
//.declare V0123 (135)  rf=r size=128 type=ud alias=V0122+0 align=32 words (r51.0)
//.declare V0124 (136)  rf=r size=128 type=d align=32 words (r56.0)
//.declare P03 (138)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0126 (139)  rf=r size=128 type=d align=32 words (r65.0)
//.declare V0127 (140)  rf=r size=128 type=f align=32 words (r73.0)
//.declare V0129 (142)  rf=r size=128 type=d align=32 words (r75.0)
//.declare V0131 (144)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0133 (146)  rf=r size=128 type=f alias=V0131+0 align=32 words (r84.0)
//.declare V0134 (147)  rf=r size=128 type=f align=32 words (r12.0)
//.declare V0135 (148)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0136 (149)  rf=r size=128 type=ud alias=V0135+0 align=32 words (r58.0)
//.declare V0137 (150)  rf=r size=128 type=d align=32 words (r67.0)
//.declare P04 (152)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0139 (153)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0140 (154)  rf=r size=128 type=f align=32 words (r86.0)
//.declare V0142 (156)  rf=r size=128 type=d align=32 words (r88.0)
//.declare V0144 (158)  rf=r size=128 type=d align=32 words (r99.0)
//.declare V0146 (160)  rf=r size=128 type=f alias=V0144+0 align=32 words (r99.0)
//.declare V0147 (161)  rf=r size=128 type=f align=32 words (r27.0)
//.declare V0148 (162)  rf=r size=128 type=d align=32 words (r69.0)
//.declare V0149 (163)  rf=r size=128 type=ud alias=V0148+0 align=32 words (r69.0)
//.declare V0150 (164)  rf=r size=128 type=d align=32 words (r80.0)
//.declare P05 (166)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0152 (167)  rf=r size=128 type=d align=32 words (r91.0)
//.declare V0153 (168)  rf=r size=128 type=f align=32 words (r101.0)
//.declare V0155 (170)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0157 (172)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0159 (174)  rf=r size=128 type=f alias=V0157+0 align=32 words (r14.0)
//.declare V0160 (175)  rf=r size=128 type=f align=32 words (r41.0)
//.declare V0161 (176)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0162 (177)  rf=r size=128 type=ub alias=V0080+0 align=32 words (r29.0)
//.declare V0163 (178)  rf=r size=128 type=ud alias=V0161+0 align=32 words (r82.0)
//.declare V0164 (179)  rf=r size=128 type=d align=32 words (r93.0)
//.declare P06 (181)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0166 (182)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0167 (183)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0170 (186)  rf=r size=128 type=w alias=V0110+0 align=32 words (r41.0)
//.declare V0174 (190)  rf=r size=128 type=w alias=V0111+0 align=32 words (r43.0)
//.declare V0177 (193)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0179 (195)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0181 (197)  rf=r size=128 type=f alias=V0179+0 align=32 words (r29.0)
//.declare V0182 (198)  rf=r size=128 type=f align=32 words (r53.0)
//.declare V0183 (199)  rf=r size=128 type=d align=32 words (r95.0)
//.declare V0184 (200)  rf=r size=128 type=ud alias=V0183+0 align=32 words (r95.0)
//.declare V0185 (201)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P07 (203)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0187 (204)  rf=r size=128 type=d align=32 words (r21.0)
//.declare V0188 (205)  rf=r size=128 type=f align=32 words (r31.0)
//.declare V0190 (207)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0192 (209)  rf=r size=128 type=d align=32 words (r45.0)
//.declare V0194 (211)  rf=r size=128 type=f alias=V0192+0 align=32 words (r45.0)
//.declare V0195 (212)  rf=r size=128 type=f align=32 words (r61.0)
//.declare V0196 (213)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0197 (214)  rf=r size=128 type=ud alias=V0196+0 align=32 words (r10.0)
//.declare V0198 (215)  rf=r size=128 type=d align=32 words (r23.0)
//.declare P08 (217)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0200 (218)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0201 (219)  rf=r size=128 type=f align=32 words (r47.0)
//.declare V0203 (221)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0205 (223)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0207 (225)  rf=r size=128 type=f alias=V0205+0 align=32 words (r55.0)
//.declare V0209 (227)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0210 (228)  rf=r size=128 type=ud alias=V0209+0 align=32 words (r25.0)
//.declare V0211 (229)  rf=r size=128 type=d align=32 words (r37.0)
//.declare P09 (231)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0213 (232)  rf=r size=128 type=d align=32 words (r51.0)
//.declare V0214 (233)  rf=r size=128 type=f align=32 words (r57.0)
//.declare V0216 (235)  rf=r size=128 type=d align=32 words (r59.0)
//.declare V0218 (237)  rf=r size=128 type=d align=32 words (r63.0)
//.declare V0220 (239)  rf=r size=128 type=f alias=V0218+0 align=32 words (r63.0)
//.declare P10 (240)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0221 (241)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0222 (242)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0223 (243)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0224 (244)  rf=r size=128 type=uw alias=V0222+0 align=32 words (r5.0)
//.declare V0225 (245)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (246)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P11 (247)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0228 (250)  rf=r size=128 type=f align=32 words (r111.0)
//.declare V0229 (251)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0230 (252)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0231 (253)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0232 (254)  rf=r size=128 type=uw alias=V0230+0 align=32 words (r12.0)
//.declare V0233 (255)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (256)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P12 (257)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0236 (260)  rf=r size=128 type=f align=32 words (r113.0)
//.declare V0237 (261)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0238 (262)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0239 (263)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0240 (264)  rf=r size=128 type=uw alias=V0238+0 align=32 words (r19.0)
//.declare V0241 (265)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (266)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P13 (267)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0244 (270)  rf=r size=128 type=f align=32 words (r115.0)
//.declare V0245 (271)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0246 (272)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0247 (273)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0248 (274)  rf=r size=128 type=uw alias=V0246+0 align=32 words (r26.0)
//.declare V0249 (275)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (276)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P14 (277)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0252 (280)  rf=r size=128 type=f align=32 words (r117.0)
//.declare V0253 (281)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0254 (282)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0255 (283)  rf=r size=128 type=f align=32 words (r119.0)
//.declare V0256 (284)  rf=r size=128 type=uw alias=V0254+0 align=32 words (r33.0)
//.declare V0257 (285)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (286)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P15 (287)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare P16 (288)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0260 (291)  rf=r size=128 type=f align=32 words (r121.0)
//.declare V0261 (292)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0262 (293)  rf=r size=128 type=d alias=V0260+0 align=32 words (r121.0)
//.declare P17 (294)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0263 (295)  rf=r size=128 type=ud alias=V0261+0 align=32 words (r3.0)
//.declare V0264 (296)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0265 (297)  rf=r size=128 type=ud alias=V0260+0 align=32 words (r121.0)
//.declare V0266 (298)  rf=r size=128 type=ud alias=V0264+0 align=32 words (r3.0)
//.declare V0267 (299)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0268 (300)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0269 (301)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0270 (302)  rf=r size=128 type=ud alias=V0268+0 align=32 words (r8.0)
//.declare V0271 (303)  rf=r size=128 type=ud alias=V0269+0 align=32 words (r10.0)
//.declare V0272 (304)  rf=r size=64 type=w align=32 words (r123.0)
//.declare V0273 (305)  rf=r size=128 type=d align=32 words (r3.0)
//.declare V0274 (306)  rf=r size=128 type=ud alias=V0273+0 align=32 words (r3.0)
//.declare V0276 (308)  rf=r size=8 type=q alias=V0036+0 align=4 words (r2.2)
//.declare V0278 (310)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0279 (311)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0280 (312)  rf=r size=8 type=uq alias=V0279+0 align=32 words (r4.0)
//.declare P18 (313)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0281 (314)  rf=r size=2 type=uw align=1 words (r106.12)
//.declare V0283 (316)  rf=r size=4 type=ud align=2 words (r5.0)
//.declare V0284 (317)  rf=r size=4 type=uw alias=V0283+0 align=2 words (r5.0)
//.declare A05 (318)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0286 (320)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare  (322)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (323)  rf=r size=128 type=w alias=V0273+0 align=32 words (r3.0)
//.declare  (324)  rf=r size=128 type=ud align=32 words (r25.0)
//.declare  (325)  rf=r size=128 type=ud align=32 words (r27.0)
//.declare  (326)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (327)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (330)  rf=r size=128 type=w alias=V0269+0 align=32 words (r10.0)
//.declare  (335)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (336)  rf=r size=128 type=q align=32 words (r15.0)
//.declare r0 (337)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (338)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (339)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (340)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (341)  rf=r size=64 type=ud align=32 words (r1.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0034    | :uq      |    0x8 | r2       | inline+0x0       |
// | V0035    | :uq      |    0x8 | r2+0x8   | inline+0x8       |
// | V0036    | :uq      |    0x8 | r2+0x10  | inline+0x10      |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@2}           //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
// B002: Preds:{B001},  Succs:{B003, B004}
// _main:
(W)     mov (16|M0)              r103.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
        cmp (32|M0)   (lt)f0.0   null<2>:uw    r1.0<1;1,0>:uw    0x140:uw              {A@1,$0.dst}  //  ALU pipe: int; $10
(W)     mul (1|M0)               acc0.0<1>:ud  r103.1<0;1,0>:ud  0xD34:uw              {I@4}         //  ALU pipe: int; $4
(W)     mach (1|M0)              r3.0<1>:d     r103.1<0;1,0>:ud  0xD34:ud                            //  ALU pipe: int; 
        mov (32|M0)              r104.0<1>:d   r1.0<1;1,0>:uw                                        //  ALU pipe: int; $2
(W)     mul (1|M0)               r106.0<1>:ud  r103.1<0;1,0>:ud  0xD34:uw              {Compacted}   //  ALU pipe: int; $3
(W)     mov (1|M0)               r106.1<1>:d   r3.0<0;1,0>:d                    {Compacted,I@3}      //  ALU pipe: int; $9
(f0.0)  goto (32|M0)                         _0_013            _0_013                                //  ALU pipe: int; $11
// B003: [inDivergent],  Preds:{B002},  Succs:{B007}
_0_014:
        mov (32|M0)              r107.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $13
        goto (32|M0)                         _0_013            _0_015                                // $14
// B004: [inDivergent],  Preds:{B002},  Succs:{B005}
_0_013:
        join (32|M0)                         _0_015                                                  // 
L336:
(W)     mov (1|M0)               r2.6<1>:d     r106.0<0;1,0>:d                  {I@6}                //  ALU pipe: int; $16
(W)     mov (1|M0)               r2.7<1>:d     r106.1<0;1,0>:d                  {I@6}                //  ALU pipe: int; $17
        shl (32|M0)              r109.0<1>:d   r104.0<1;1,0>:d   3:w               {Compacted}       //  ALU pipe: int; $21
        mov (32|M0)              r107.0<1>:f   0x0:f                               {Compacted,I@6}   //  ALU pipe: float; $23
(W)     add (1|M0)               r106.1<1>:q   r2.3<0;1,0>:q     r2.0<0;1,0>:q    {I@2}              //  ALU pipe: int; $20
(W)     add (1|M0)               r106.2<1>:q   r106.1<0;1,0>:q   2560:w               {I@1}          //  ALU pipe: int; $22
// B005: [inDivergent],  Preds:{B006, B004},  Succs:{B006, B007}
_0_016:
        mov (16|M0)              r3.0<2>:ud    r109.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $31
        mov (16|M16)             r5.0<2>:ud    r110.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $31
        add (16|M0)              r9.0<1>:q     r106.1<0;1,0>:q   r3.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $31
        add (16|M16)             r11.0<1>:q    r106.1<0;1,0>:q   r5.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $31
        load.ugm.d32.a64 (32|M0)  r19:2         [r9:4]             {I@1,$1} // ex_desc:0x0; desc:0x8200580 // $32
        shr (32|M0)              r7.0<1>:ud    r109.0<1;1,0>:ud  2:w                                 //  ALU pipe: int; $25
        shl (16|M0)              r13.0<1>:q    r3.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $34
        shl (16|M16)             r15.0<1>:q    r5.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $34
        and (32|M0)              r17.0<1>:d    r7.0<1;1,0>:d     1020:w               {Compacted,I@3} //  ALU pipe: int; $26
        add (16|M0)              r21.0<1>:q    r13.0<1;1,0>:q    r2.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $35
        add (16|M16)             r23.0<1>:q    r15.0<1;1,0>:q    r2.1<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $35
        mov (16|M0)              r25.0<2>:ud   r17.0<1;1,0>:ud                  {Compacted,I@3}      //  ALU pipe: int; $28
        mov (16|M16)             r27.0<2>:ud   r18.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $28
        load.ugm.d32.a64 (32|M0)  r35:2         [r21:4]            {I@3,$2} // ex_desc:0x0; desc:0x8200580 // $36
        add (16|M0)              r31.0<1>:q    r106.2<0;1,0>:q   r25.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $28
        add (16|M16)             r33.0<1>:q    r106.2<0;1,0>:q   r27.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $28
        load.ugm.d32.a64 (32|M0)  r39:2         [r31:4]            {I@1,$3} // ex_desc:0x0; desc:0x8200580 // $29
        load.ugm.d32.a64 (32|M0)  r29:2         [r9:4+0x4]         {$4} // ex_desc:0x4000; desc:0x8200580 // $33
        load.ugm.d32.a64 (32|M0)  r37:2         [r21:4+0x4]        {$5} // ex_desc:0x4000; desc:0x8200580 // $54
        load.ugm.d32.a64 (32|M0)  r41:2         [r21:4+0x8]        {$6} // ex_desc:0x8000; desc:0x8200580 // $55
        load.ugm.d32.a64 (32|M0)  r43:2         [r21:4+0xC]        {$7} // ex_desc:0xC000; desc:0x8200580 // $56
        mov (32|M0)              r45.0<1>:b    r19.0<4;1,0>:b                   {$1.dst}             //  ALU pipe: int; $37
        mov (32|M0)              r46.0<1>:ud   r19.0<4;1,0>:ub                                       //  ALU pipe: int; $45
        mov (32|M0)   (lt)f2.0   null<2>:w     r45.0<1;1,0>:b                   {I@2}                //  ALU pipe: int; $47
        mov (32|M0)              r48.0<1>:b    r19.1<4;1,0>:b                                        //  ALU pipe: int; $38
        or (32|M0)               r49.0<1>:d    r46.0<1;1,0>:d    -256:w               {Compacted,I@3} //  ALU pipe: int; $46
        mov (32|M0)              r51.0<1>:ud   r19.1<4;1,0>:ub                                       //  ALU pipe: int; $63
        mov (32|M0)   (lt)f3.0   null<2>:w     r48.0<1;1,0>:b                   {I@3}                //  ALU pipe: int; $65
(f2.0)  sel (32|M0)              r54.0<1>:d    r49.0<1;1,0>:d    r46.0<1;1,0>:d   {I@3}              //  ALU pipe: int; $49
        mov (32|M0)              r53.0<1>:b    r19.2<4;1,0>:b                                        //  ALU pipe: int; $39
        mov (32|M0)              r62.0<1>:d    r35.0<2;1,0>:uw                  {$2.dst}             //  ALU pipe: int; $59
        or (32|M0)               r56.0<1>:d    r51.0<1;1,0>:d    -256:w               {Compacted,I@5} //  ALU pipe: int; $64
        mov (32|M0)              r60.0<1>:f    r54.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $50
        mov (32|M0)              r58.0<1>:ud   r19.2<4;1,0>:ub                                       //  ALU pipe: int; $74
        mov (32|M0)   (lt)f1.0   null<2>:w     r53.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $76
        shl (32|M0)              r71.0<1>:d    r62.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $60
(f3.0)  sel (32|M0)              r65.0<1>:d    r56.0<1;1,0>:d    r51.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $67
        mul (32|M0)              acc0.0<1>:f   r39.0<1;1,0>:f    r60.0<1;1,0>:f   {Compacted,@1,$3.dst} //  ALU pipe: float; $51
        mov (32|M0)              r64.0<1>:b    r19.3<4;1,0>:b                                        //  ALU pipe: int; $40
        mov (32|M0)              r75.0<1>:d    r35.1<2;1,0>:uw                                       //  ALU pipe: int; $70
        or (32|M0)               r67.0<1>:d    r58.0<1;1,0>:d    -256:w               {Compacted,I@6} //  ALU pipe: int; $75
        mov (32|M0)              r73.0<1>:f    r65.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $68
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r71.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $61
        mov (32|M0)              r69.0<1>:ud   r19.3<4;1,0>:ub                                       //  ALU pipe: int; $85
        mov (32|M0)   (lt)f3.0   null<2>:w     r64.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $87
        shl (32|M0)              r84.0<1>:d    r75.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $71
(f1.0)  sel (32|M0)              r78.0<1>:d    r67.0<1;1,0>:d    r58.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $78
        mul (32|M0)              acc2.0<1>:f   r39.0<1;1,0>:f    r73.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $69
        mov (32|M0)              r77.0<1>:b    r29.0<4;1,0>:b                   {$4.dst}             //  ALU pipe: int; $41
        mov (32|M0)              r88.0<1>:d    r37.0<2;1,0>:uw                  {$5.dst}             //  ALU pipe: int; $81
        or (32|M0)               r80.0<1>:d    r69.0<1;1,0>:d    -256:w               {Compacted,I@6} //  ALU pipe: int; $86
        mov (32|M0)              r86.0<1>:f    r78.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $79
        add (32|M0)              r97.0<1>:f    r107.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $62
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r84.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $72
        mov (32|M0)              r82.0<1>:ud   r29.0<4;1,0>:ub                                       //  ALU pipe: int; $96
        mov (32|M0)   (lt)f2.0   null<2>:w     r77.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $98
        shl (32|M0)              r99.0<1>:d    r88.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $82
(f3.0)  sel (32|M0)              r91.0<1>:d    r80.0<1;1,0>:d    r69.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $89
        mul (32|M0)              acc0.0<1>:f   r39.0<1;1,0>:f    r86.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $80
        mov (32|M0)              r90.0<1>:b    r29.1<4;1,0>:b                                        //  ALU pipe: int; $42
        mov (32|M0)              r3.0<1>:d     r37.1<2;1,0>:uw                                       //  ALU pipe: int; $92
        or (32|M0)               r93.0<1>:d    r82.0<1;1,0>:d    -256:w               {Compacted,I@6} //  ALU pipe: int; $97
        mov (32|M0)              r101.0<1>:f   r91.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $90
        add (32|M0)              r12.0<1>:f    r97.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $73
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r99.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $83
        mov (32|M0)              r95.0<1>:ud   r29.1<4;1,0>:ub                                       //  ALU pipe: int; $111
        mov (32|M0)   (lt)f1.0   null<2>:w     r90.0<1;1,0>:b                   {I@4}                //  ALU pipe: int; $113
        shl (32|M0)              r14.0<1>:d    r3.0<1;1,0>:d     16:w               {Compacted,I@4}  //  ALU pipe: int; $93
(f2.0)  sel (32|M0)              r6.0<1>:d     r93.0<1;1,0>:d    r82.0<1;1,0>:d   {I@4}              //  ALU pipe: int; $100
        mul (32|M0)              acc2.0<1>:f   r39.0<1;1,0>:f    r101.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $91
        mov (32|M0)              r5.0<1>:b     r29.2<4;1,0>:b                                        //  ALU pipe: int; $43
        mov (32|M0)              r18.0<1>:d    r41.0<2;1,0>:uw                  {$6.dst}             //  ALU pipe: int; $107
        or (32|M0)               r8.0<1>:d     r95.0<1;1,0>:d    -256:w               {Compacted,I@6} //  ALU pipe: int; $112
        mov (32|M0)              r16.0<1>:f    r6.0<1;1,0>:d                    {I@4}                //  ALU pipe: float; $101
        add (32|M0)              r27.0<1>:f    r12.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $84
        mov (32|M0)              r10.0<1>:ud   r29.2<4;1,0>:ub                                       //  ALU pipe: int; $122
        mov (32|M0)              r25.0<1>:ud   r29.3<4;1,0>:ub                                       //  ALU pipe: int; $133
        mov (32|M0)              r20.0<1>:b    r29.3<4;1,0>:b                                        //  ALU pipe: int; $44
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r14.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $94
        mov (32|M0)   (lt)f3.0   null<2>:w     r5.0<1;1,0>:b                    {I@6}                //  ALU pipe: int; $124
(f1.0)  sel (32|M0)              r21.0<1>:d    r8.0<1;1,0>:d     r95.0<1;1,0>:d   {@5,$7.src}        //  ALU pipe: int; $115
        shl (32|M0)              r29.0<1>:d    r18.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $108
        mul (32|M0)              acc0.0<1>:f   r39.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $102
        mov (32|M0)              r33.0<1>:d    r41.1<2;1,0>:uw                                       //  ALU pipe: int; $118
        or (32|M0)               r23.0<1>:d    r10.0<1;1,0>:d    -256:w               {Compacted,I@7} //  ALU pipe: int; $123
        mov (32|M0)              r31.0<1>:f    r21.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $116
        add (32|M0)              r41.0<1>:f    r27.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,A@2}    //  ALU pipe: float; $95
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r29.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $109
        mov (32|M0)   (lt)f1.0   null<2>:w     r20.0<1;1,0>:b                                        //  ALU pipe: int; $135
        shl (32|M0)              r45.0<1>:d    r33.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $119
(f3.0)  sel (32|M0)              r35.0<1>:d    r23.0<1;1,0>:d    r10.0<1;1,0>:d   {I@3}              //  ALU pipe: int; $126
        mul (32|M0)              acc2.0<1>:f   r39.0<1;1,0>:f    r31.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $117
        mov (32|M0)              r49.0<1>:d    r43.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $129
        or (32|M0)               r37.0<1>:d    r25.0<1;1,0>:d    -256:w               {Compacted}    //  ALU pipe: int; $134
        mov (32|M0)              r47.0<1>:f    r35.0<1;1,0>:d                   {I@3}                //  ALU pipe: float; $127
        add (32|M0)              r53.0<1>:f    r41.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $110
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r45.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $120
        shl (32|M0)              r55.0<1>:d    r49.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $130
(f1.0)  sel (32|M0)              r51.0<1>:d    r37.0<1;1,0>:d    r25.0<1;1,0>:d   {I@2}              //  ALU pipe: int; $137
        mul (32|M0)              acc0.0<1>:f   r39.0<1;1,0>:f    r47.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $128
        mov (32|M0)              r57.0<1>:f    r51.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $138
        add (32|M0)              r61.0<1>:f    r53.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $121
        mov (32|M0)              r59.0<1>:d    r43.1<2;1,0>:uw                                       //  ALU pipe: int; $140
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r55.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $131
        mul (32|M0)              acc2.0<1>:f   r39.0<1;1,0>:f    r57.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $139
        shl (32|M0)              r63.0<1>:d    r59.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $141
        add (32|M0)              acc0.0<1>:f   r61.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $132
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r109.0<1;1,0>:ud  0x900:uw                            //  ALU pipe: int; $144
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r63.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $142
        add (32|M0)              r107.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $143
(~f0.0) goto (32|M0)                         _0_015            _0_015                                //  ALU pipe: int; $145
// B006: [inDivergent],  Preds:{B005},  Succs:{B005}
_0_017:
        add (32|M0)              r109.0<1>:d   r109.0<1;1,0>:d   256:w               {Compacted}     //  ALU pipe: int; $147
(W)     jmpi                                 _0_016                                                  // $148
// B007: Preds:{B005, B003},  Succs:{B008, B012}
_0_015:
        join (32|M0)                         L1856                                                   // 
L1856:
        add (32|M0)              r3.0<1>:d     r104.0<1;1,0>:d   1:w               {Compacted}       //  ALU pipe: int; $150
        and (32|M0)              r5.0<1>:d     r3.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $151
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $152
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $153
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0x1AC0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0058(r107.0:f); $154
        add (32|M0)              r10.0<1>:d    r104.0<1;1,0>:d   2:w               {Compacted}       //  ALU pipe: int; $163
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $155
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $156
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0x1AC0:uw                           //  ALU pipe: int; src1 is addr of V0058(r107.0:f); $157
        and (32|M0)   (eq)f3.0   null<1>:d     r104.0<1;1,0>:d   1:w                                 //  ALU pipe: int; $159
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $164
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $158
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $165
(f3.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $161
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $166
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0x1BC0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0228(r111.0:f); $167
        add (32|M0)              r111.0<1>:f   r107.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $162
        add (32|M0)              r17.0<1>:d    r104.0<1;1,0>:d   4:w               {Compacted}       //  ALU pipe: int; $176
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $168
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $169
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0x1BC0:uw                           //  ALU pipe: int; src1 is addr of V0228(r111.0:f); $170
        and (32|M0)   (eq)f2.0   null<1>:d     r104.0<1;1,0>:d   3:w                                 //  ALU pipe: int; $172
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $177
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $171
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $178
(f2.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $174
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $179
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0x1C40:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0236(r113.0:f); $180
        add (32|M0)              r113.0<1>:f   r111.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $175
        add (32|M0)              r24.0<1>:d    r104.0<1;1,0>:d   8:w               {Compacted}       //  ALU pipe: int; $189
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $181
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $182
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0x1C40:uw                           //  ALU pipe: int; src1 is addr of V0236(r113.0:f); $183
        and (32|M0)   (eq)f1.0   null<1>:d     r104.0<1;1,0>:d   7:w                                 //  ALU pipe: int; $185
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $190
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $184
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $191
(f1.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $187
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $192
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0x1CC0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0244(r115.0:f); $193
        add (32|M0)              r115.0<1>:f   r113.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $188
        add (32|M0)              r31.0<1>:d    r104.0<1;1,0>:d   16:w               {Compacted}      //  ALU pipe: int; $202
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $194
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $195
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0x1CC0:uw                           //  ALU pipe: int; src1 is addr of V0244(r115.0:f); $196
        and (32|M0)   (eq)f0.0   null<1>:d     r104.0<1;1,0>:d   15:w                                //  ALU pipe: int; $198
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $203
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $197
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $204
(f0.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $200
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $205
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0x1D40:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0252(r117.0:f); $206
        add (32|M0)              r117.0<1>:f   r115.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $201
        cmp (32|M0)   (eq)f3.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $211
        mov (16|M0)              r119.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $207
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $208
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0x1D40:uw                           //  ALU pipe: int; src1 is addr of V0252(r117.0:f); $209
        mov (16|M16)             r120.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $210
(~f3.0) goto (32|M0)                         _0_018            _0_018                                //  ALU pipe: int; $212
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B010}
_0_019:
        and (32|M0)   (eq)f2.0   null<1>:d     r104.0<1;1,0>:d   31:w                                //  ALU pipe: int; $214
(f2.0)  sel (32|M0)              acc0.0<1>:f   r119.0<1;1,0>:f   0x80000000:f               {I@3}    //  ALU pipe: float; $216
        add (32|M0)              r121.0<1>:f   r117.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $217
        and (32|M0)              r3.0<1>:d     r121.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $218
        cmp (32|M0)   (gt)f1.0   null<1>:ud    r3.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $219
(f1.0)  goto (32|M0)                         _0_020            _0_020                                //  ALU pipe: int; $220
// B009: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_021:
        shr (32|M0)              r3.0<1>:ud    r121.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $222
        and (32|M0)              r6.0<1>:d     r3.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $223
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r121.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $224
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $225
        mov (32|M0)              r123.0<1>:w   r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $226
        goto (32|M0)                         _0_020            _0_022                                // $227
// B010: [inDivergent],  Preds:{B008},  Succs:{B011}
_0_020:
        join (32|M0)                         _0_022                                                  // 
L2880:
        shr (32|M0)              r3.0<1>:ud    r121.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $229
        or (32|M0)               r123.0<1>:w   r3.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $231
// B011: [inDivergent],  Preds:{B010, B009},  Succs:{B012}
_0_022:
        join (32|M0)                         _0_018                                                  // 
L2928:
(W)     mov (1|M0)               f0.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $236
        cmp (32|M0)   (eq)f0.0   null<2>:uw    r106.12<0;1,0>:uw  r106.12<0;1,0>:uw                  //  ALU pipe: int; $237
(W)     fbl (1|M0)               r5.0<1>:ud    f0.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $239
(W)     shl (1|M0)               r2.3<1>:q     r103.1<0;1,0>:ud  1:w                                 //  ALU pipe: int; $234
(W)     shl (1|M0)               r5.0<1>:ud    r5.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $240
(W)     add (1|M0)               r4.0<1>:q     r2.3<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $235
(W)     add (1|M0)               a0.0<1>:uw    r5.0<0;1,0>:uw    0x1EC0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0272(r123.0:w); $241
(W)     mov (1|M0)               r6.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $243
(W)     store.ugm.d16u32.a64 (1|M0)  [r4:2]     r6:1               {I@1,$8} // ex_desc:0x0; desc:0x4000B84 // $244
// B012: Preds:{B011, B007},  Succs:{}
_0_018:
        join (32|M0)                         L3072                                                   // 
L3072:
(W)     mov (16|M0)              r127.0<1>:f   r103.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $246
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$9} // wr:1+0, rd:0; end of thread // $246
L3096:
(W)     mov (16|M0)              null<1>:ud    0x785C230:ud                                          // 
(W)     mov (16|M0)              null<1>:ud    0x58CB52D6:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1:ud                                                // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 212
//.accSubDef: 22
//.accSubUse: 22
//.accSubCandidateDef: 28
//.accSubCandidateUse: 28
//
//
//.singlePipeAtOneDistNum: 26
//.allAtOneDistNum: 3
//.syncInstCount: 0
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 8
//.AfterReadTokenDepCount: 2
