//.kernel _ZTS19Packet93OfflineHeadILj1EE
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 126206512 1489720022 -hashmovs1 0 2 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 126206512 1489720022 -hashmovs1 0 2 -GRFBumpUpNumber 2 "
//.instCount 381
//.RA type	HYBRID_BC_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r108.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=32 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r2.10)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.11)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r2.6)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r2.7)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r2.8)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r2.9)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=32 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=32 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=32 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=32 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r108.0)
//.declare V0034 (44)  rf=r size=8 type=uq align=4 words (r2.0)
//.declare V0035 (45)  rf=r size=8 type=uq align=4 words (r2.1)
//.declare V0036 (46)  rf=r size=8 type=uq align=4 words (r2.2)
//.declare V0038 (48)  rf=r size=32 type=d alias=+0 align=32 words (r108.0)
//.declare V0040 (50)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0050 (60)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0051 (61)  rf=r size=64 type=uw alias=V0040+0 align=32 words (r1.0)
//.declare V0052 (62)  rf=r size=4 type=d align=2 words (r4.0)
//.declare V0053 (63)  rf=r size=4 type=d align=2 words (r3.0)
//.declare V0054 (64)  rf=r size=4 type=ud alias=V0052+0 align=2 words (r4.0)
//.declare V0055 (65)  rf=r size=32 type=ud alias=V0038+0 align=32 words (r108.0)
//.declare V0056 (66)  rf=r size=4 type=d align=32 words (r3.0)
//.declare P01 (69)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0059 (70)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0061 (72)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0062 (73)  rf=r size=8 type=d alias=V0061+0 align=4 words (r2.6)
//.declare V0063 (74)  rf=r size=8 type=q alias=V0034+0 align=32 words (r2.0)
//.declare V0064 (75)  rf=r size=8 type=q align=4 words (r109.1)
//.declare V0065 (76)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0066 (77)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0067 (78)  rf=r size=128 type=ud alias=V0050+0 align=32 words (r78.0)
//.declare V0068 (79)  rf=r size=128 type=ud alias=V0066+0 align=32 words (r4.0)
//.declare V0069 (80)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0070 (81)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0071 (82)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0072 (83)  rf=r size=64 type=w align=32 words (r3.0)
//.declare V0073 (84)  rf=r size=64 type=w align=32 words (r8.0)
//.declare V0075 (86)  rf=r size=64 type=uw alias=V0072+0 align=32 words (r3.0)
//.declare V0076 (87)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0078 (89)  rf=r size=128 type=ud alias=V0076+0 align=32 words (r10.0)
//.declare V0079 (90)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0081 (92)  rf=r size=128 type=ud alias=V0079+0 align=32 words (r12.0)
//.declare V0083 (94)  rf=r size=128 type=ud alias=V0071+0 align=32 words (r6.0)
//.declare V0085 (96)  rf=r size=64 type=uw alias=V0073+0 align=32 words (r8.0)
//.declare V0086 (97)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0088 (99)  rf=r size=128 type=ud alias=V0086+0 align=32 words (r24.0)
//.declare V0089 (100)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0090 (101)  rf=r size=128 type=ud alias=V0089+0 align=32 words (r14.0)
//.declare V0092 (103)  rf=r size=8 type=q alias=V0035+0 align=32 words (r2.1)
//.declare V0093 (104)  rf=r size=4 type=d align=2 words (r109.1)
//.declare V0094 (105)  rf=r size=4 type=d align=2 words (r109.0)
//.declare V0095 (106)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0096 (107)  rf=r size=128 type=ud alias=V0065+0 align=32 words (r76.0)
//.declare V0097 (108)  rf=r size=128 type=ud alias=V0095+0 align=32 words (r4.0)
//.declare V0098 (109)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0100 (111)  rf=r size=128 type=ud alias=V0098+0 align=32 words (r6.0)
//.declare V0101 (112)  rf=r size=256 type=q align=32 words (r32.0)
//.declare V0108 (119)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0109 (120)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0110 (121)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0111 (122)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0112 (123)  rf=r size=128 type=ud alias=V0110+0 align=32 words (r26.0)
//.declare V0113 (124)  rf=r size=128 type=ud alias=V0111+0 align=32 words (r8.0)
//.declare V0115 (126)  rf=r size=256 type=q align=32 words (r84.0)
//.declare V0116 (127)  rf=r size=256 type=uq alias=V0115+0 align=32 words (r84.0)
//.declare V0117 (128)  rf=r size=256 type=d align=32 words (r28.0)
//.declare V0118 (129)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0119 (130)  rf=r size=128 type=d align=32 words (r66.0)
//.declare P02 (131)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0120 (132)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0121 (133)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0122 (134)  rf=r size=128 type=ud alias=V0118+0 align=32 words (r70.0)
//.declare V0123 (135)  rf=r size=128 type=ud alias=V0121+0 align=32 words (r6.0)
//.declare V0124 (136)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0125 (137)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0126 (138)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0127 (139)  rf=r size=128 type=ud alias=V0119+0 align=32 words (r66.0)
//.declare V0128 (140)  rf=r size=128 type=ud alias=V0126+0 align=32 words (r12.0)
//.declare V0135 (147)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0136 (148)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0137 (149)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0138 (150)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0139 (151)  rf=r size=128 type=ud alias=V0137+0 align=32 words (r20.0)
//.declare V0140 (152)  rf=r size=128 type=ud alias=V0138+0 align=32 words (r22.0)
//.declare V0142 (154)  rf=r size=256 type=q align=32 words (r72.0)
//.declare V0143 (155)  rf=r size=256 type=uq alias=V0142+0 align=32 words (r72.0)
//.declare V0144 (156)  rf=r size=256 type=d align=32 words (r28.0)
//.declare V0145 (157)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0146 (158)  rf=r size=128 type=d align=32 words (r62.0)
//.declare P03 (159)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0147 (160)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0148 (161)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0149 (162)  rf=r size=128 type=ud alias=V0145+0 align=32 words (r68.0)
//.declare V0150 (163)  rf=r size=128 type=ud alias=V0148+0 align=32 words (r6.0)
//.declare V0151 (164)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0152 (165)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0153 (166)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0154 (167)  rf=r size=128 type=ud alias=V0146+0 align=32 words (r62.0)
//.declare V0155 (168)  rf=r size=128 type=ud alias=V0153+0 align=32 words (r12.0)
//.declare V0157 (170)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare V0158 (171)  rf=r size=128 type=w alias=V0157+0 align=32 words (r4.0)
//.declare V0160 (173)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0162 (175)  rf=r size=128 type=d align=32 words (r106.0)
//.declare V0163 (176)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0164 (177)  rf=r size=128 type=ud alias=V0163+0 align=32 words (r6.0)
//.declare V0165 (178)  rf=r size=128 type=d align=32 words (r112.0)
//.declare P04 (179)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P05 (180)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0166 (181)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0167 (182)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0168 (183)  rf=r size=128 type=d align=32 words (r8.0)
//.declare P06 (184)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0169 (185)  rf=r size=4 type=d align=2 words (r2.0)
//.declare P07 (186)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0171 (188)  rf=r size=128 type=d align=32 words (r110.0)
//.declare V0172 (189)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0173 (190)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0174 (191)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0175 (192)  rf=r size=128 type=d align=32 words (r10.0)
//.declare P08 (193)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0176 (194)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0178 (196)  rf=r size=256 type=q align=32 words (r12.0)
//.declare V0179 (197)  rf=r size=256 type=uq alias=V0178+0 align=32 words (r12.0)
//.declare V0180 (198)  rf=r size=32 type=b align=32 words (r3.0)
//.declare V0181 (199)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare V0182 (200)  rf=r size=128 type=b alias=V0181+0 align=32 words (r24.0)
//.declare V0183 (201)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0185 (203)  rf=r size=128 type=ud alias=V0183+0 align=32 words (r8.0)
//.declare V0186 (204)  rf=r size=256 type=q align=32 words (r26.0)
//.declare V0187 (205)  rf=r size=256 type=uq alias=V0186+0 align=32 words (r26.0)
//.declare V0188 (206)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0189 (207)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0190 (208)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0192 (210)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0193 (211)  rf=r size=128 type=d align=32 words (r14.0)
//.declare P09 (213)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0195 (214)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0197 (216)  rf=r size=128 type=f alias=V0160+0 align=32 words (r64.0)
//.declare V0198 (217)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0199 (218)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0200 (219)  rf=r size=128 type=ud alias=V0199+0 align=32 words (r30.0)
//.declare V0201 (220)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0202 (221)  rf=r size=128 type=ud alias=V0198+0 align=32 words (r10.0)
//.declare V0203 (222)  rf=r size=128 type=ud alias=V0201+0 align=32 words (r22.0)
//.declare V0204 (223)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0205 (224)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0206 (225)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0207 (226)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0208 (227)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0210 (229)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0211 (230)  rf=r size=128 type=ud alias=V0210+0 align=32 words (r34.0)
//.declare V0212 (231)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0213 (232)  rf=r size=128 type=ud alias=V0212+0 align=32 words (r18.0)
//.declare V0214 (233)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0215 (234)  rf=r size=128 type=ub alias=V0145+0 align=32 words (r68.0)
//.declare V0216 (235)  rf=r size=128 type=ud alias=V0214+0 align=32 words (r16.0)
//.declare V0217 (236)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0218 (237)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0219 (238)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0220 (239)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0221 (240)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0222 (241)  rf=r size=128 type=f align=32 words (r36.0)
//.declare V0223 (242)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0224 (243)  rf=r size=128 type=ud alias=V0223+0 align=32 words (r20.0)
//.declare V0225 (244)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0226 (245)  rf=r size=128 type=ud alias=V0225+0 align=32 words (r16.0)
//.declare V0227 (246)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0228 (247)  rf=r size=128 type=ud alias=V0227+0 align=32 words (r10.0)
//.declare V0229 (248)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0230 (249)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0231 (250)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0232 (251)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0233 (252)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0234 (253)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0235 (254)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0236 (255)  rf=r size=128 type=ud alias=V0235+0 align=32 words (r28.0)
//.declare V0237 (256)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0238 (257)  rf=r size=128 type=ud alias=V0237+0 align=32 words (r12.0)
//.declare V0239 (258)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0240 (259)  rf=r size=128 type=ud alias=V0239+0 align=32 words (r12.0)
//.declare V0241 (260)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0242 (261)  rf=r size=128 type=ud alias=V0241+0 align=32 words (r44.0)
//.declare V0243 (262)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0244 (263)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0245 (264)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0246 (265)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0247 (266)  rf=r size=128 type=f align=32 words (r52.0)
//.declare V0248 (267)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0249 (268)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0250 (269)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0251 (270)  rf=r size=128 type=ud alias=V0250+0 align=32 words (r44.0)
//.declare V0252 (271)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0253 (272)  rf=r size=128 type=ud alias=V0249+0 align=32 words (r46.0)
//.declare V0254 (273)  rf=r size=128 type=ud alias=V0252+0 align=32 words (r34.0)
//.declare V0255 (274)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0256 (275)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0257 (276)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0258 (277)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0259 (278)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0260 (279)  rf=r size=128 type=f align=32 words (r44.0)
//.declare V0261 (280)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0262 (281)  rf=r size=128 type=ud alias=V0261+0 align=32 words (r46.0)
//.declare V0263 (282)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0264 (283)  rf=r size=128 type=ud alias=V0263+0 align=32 words (r8.0)
//.declare V0265 (284)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0266 (285)  rf=r size=128 type=ub alias=V0146+0 align=32 words (r62.0)
//.declare V0267 (286)  rf=r size=128 type=ud alias=V0265+0 align=32 words (r18.0)
//.declare V0268 (287)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0269 (288)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0270 (289)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0271 (290)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0272 (291)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0273 (292)  rf=r size=128 type=f align=32 words (r48.0)
//.declare V0274 (293)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0275 (294)  rf=r size=128 type=ud alias=V0274+0 align=32 words (r10.0)
//.declare V0276 (295)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0277 (296)  rf=r size=128 type=ud alias=V0276+0 align=32 words (r22.0)
//.declare V0278 (297)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0279 (298)  rf=r size=128 type=ud alias=V0278+0 align=32 words (r16.0)
//.declare V0280 (299)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0281 (300)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0282 (301)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0283 (302)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0284 (303)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0285 (304)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0286 (305)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0287 (306)  rf=r size=128 type=ud alias=V0286+0 align=32 words (r42.0)
//.declare V0288 (307)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0289 (308)  rf=r size=128 type=ud alias=V0288+0 align=32 words (r28.0)
//.declare V0290 (309)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0291 (310)  rf=r size=128 type=ud alias=V0290+0 align=32 words (r38.0)
//.declare V0292 (311)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0293 (312)  rf=r size=128 type=ud alias=V0292+0 align=32 words (r18.0)
//.declare V0294 (313)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0295 (314)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0296 (315)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0297 (316)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0298 (317)  rf=r size=128 type=f align=32 words (r30.0)
//.declare V0301 (320)  rf=r size=128 type=w alias=V0188+0 align=32 words (r36.0)
//.declare V0305 (324)  rf=r size=128 type=w alias=V0189+0 align=32 words (r38.0)
//.declare V0309 (328)  rf=r size=128 type=w alias=V0190+0 align=32 words (r4.0)
//.declare V0312 (331)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0314 (333)  rf=r size=128 type=w alias=V0312+0 align=32 words (r6.0)
//.declare V0317 (336)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0319 (338)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0321 (340)  rf=r size=128 type=f alias=V0319+0 align=32 words (r46.0)
//.declare V0323 (342)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0325 (344)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0326 (345)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0327 (346)  rf=r size=128 type=f alias=V0325+0 align=32 words (r48.0)
//.declare V0329 (348)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0331 (350)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0332 (351)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0333 (352)  rf=r size=128 type=f alias=V0331+0 align=32 words (r28.0)
//.declare V0334 (353)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0335 (354)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0337 (356)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0339 (358)  rf=r size=128 type=f alias=V0337+0 align=32 words (r12.0)
//.declare V0340 (359)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0341 (360)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0343 (362)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0345 (364)  rf=r size=128 type=f alias=V0343+0 align=32 words (r14.0)
//.declare V0346 (365)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0347 (366)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0349 (368)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0351 (370)  rf=r size=128 type=f alias=V0349+0 align=32 words (r16.0)
//.declare V0352 (371)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0353 (372)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0355 (374)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0357 (376)  rf=r size=128 type=f alias=V0355+0 align=32 words (r4.0)
//.declare V0359 (378)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0361 (380)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0363 (382)  rf=r size=128 type=f alias=V0361+0 align=32 words (r14.0)
//.declare P10 (383)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0364 (384)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0365 (385)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0366 (386)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0367 (387)  rf=r size=128 type=uw alias=V0365+0 align=32 words (r6.0)
//.declare V0368 (388)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A00 (389)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P11 (390)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0371 (393)  rf=r size=128 type=f align=32 words (r122.0)
//.declare V0372 (394)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0373 (395)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0374 (396)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0375 (397)  rf=r size=128 type=uw alias=V0373+0 align=32 words (r4.0)
//.declare V0376 (398)  rf=r size=64 type=uw align=32 words (r12.0)
//.declare A01 (399)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P12 (400)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0379 (403)  rf=r size=128 type=f align=32 words (r120.0)
//.declare V0380 (404)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0381 (405)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0382 (406)  rf=r size=128 type=f align=32 words (r4.0)
//.declare V0383 (407)  rf=r size=128 type=uw alias=V0381+0 align=32 words (r10.0)
//.declare V0384 (408)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A02 (409)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P13 (410)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0387 (413)  rf=r size=128 type=f align=32 words (r118.0)
//.declare V0388 (414)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0389 (415)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0390 (416)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0391 (417)  rf=r size=128 type=uw alias=V0389+0 align=32 words (r8.0)
//.declare V0392 (418)  rf=r size=64 type=uw align=32 words (r12.0)
//.declare A03 (419)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P14 (420)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0395 (423)  rf=r size=128 type=f align=32 words (r124.0)
//.declare V0396 (424)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0397 (425)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0398 (426)  rf=r size=128 type=f align=32 words (r116.0)
//.declare V0399 (427)  rf=r size=128 type=uw alias=V0397+0 align=32 words (r6.0)
//.declare V0400 (428)  rf=r size=64 type=uw align=32 words (r3.0)
//.declare A04 (429)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P15 (430)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare P16 (431)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0403 (434)  rf=r size=128 type=f align=32 words (r114.0)
//.declare V0404 (435)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0405 (436)  rf=r size=128 type=d alias=V0403+0 align=32 words (r114.0)
//.declare P17 (437)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0406 (438)  rf=r size=128 type=ud alias=V0404+0 align=32 words (r4.0)
//.declare V0407 (439)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0408 (440)  rf=r size=128 type=ud alias=V0403+0 align=32 words (r114.0)
//.declare V0409 (441)  rf=r size=128 type=ud alias=V0407+0 align=32 words (r4.0)
//.declare V0410 (442)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0411 (443)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0412 (444)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0413 (445)  rf=r size=128 type=ud alias=V0411+0 align=32 words (r8.0)
//.declare V0414 (446)  rf=r size=128 type=ud alias=V0412+0 align=32 words (r10.0)
//.declare V0415 (447)  rf=r size=64 type=w align=32 words (r126.0)
//.declare V0416 (448)  rf=r size=128 type=d align=32 words (r4.0)
//.declare V0417 (449)  rf=r size=128 type=ud alias=V0416+0 align=32 words (r4.0)
//.declare V0419 (451)  rf=r size=8 type=q alias=V0036+0 align=32 words (r2.2)
//.declare V0421 (453)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0422 (454)  rf=r size=8 type=q align=32 words (r4.0)
//.declare V0423 (455)  rf=r size=8 type=uq alias=V0422+0 align=32 words (r4.0)
//.declare P18 (456)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0424 (457)  rf=r size=2 type=uw align=32 words (r1.0)
//.declare V0426 (459)  rf=r size=4 type=ud align=2 words (r3.0)
//.declare V0427 (460)  rf=r size=4 type=uw alias=V0426+0 align=2 words (r3.0)
//.declare A05 (461)  rf=a size=2 type=uw align=1 words (a0.0)
//.declare V0429 (463)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare  (465)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (466)  rf=r size=128 type=w alias=V0416+0 align=32 words (r4.0)
//.declare  (467)  rf=r size=128 type=ud align=32 words (r14.0)
//.declare  (468)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (469)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (470)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (471)  rf=r size=128 type=uw align=32 words (r20.0)
//.declare  (472)  rf=r size=128 type=uw align=32 words (r22.0)
//.declare  (473)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (474)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (475)  rf=r size=128 type=ud align=32 words (r16.0)
//.declare  (476)  rf=r size=128 type=ud align=32 words (r4.0)
//.declare  (479)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (480)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (481)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (482)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (485)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (486)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (487)  rf=r size=2 type=w align=1 words (r2.12)
//.declare  (488)  rf=r size=128 type=ud align=32 words (r18.0)
//.declare  (489)  rf=r size=128 type=ud align=32 words (r20.0)
//.declare  (490)  rf=r size=128 type=w alias=V0412+0 align=32 words (r10.0)
//.declare  (491)  rf=r size=128 type=q align=32 words (r104.0)
//.declare  (492)  rf=r size=128 type=q align=32 words (r102.0)
//.declare  (493)  rf=r size=128 type=q align=32 words (r100.0)
//.declare  (494)  rf=r size=128 type=q align=32 words (r98.0)
//.declare  (495)  rf=r size=128 type=q align=32 words (r88.0)
//.declare  (496)  rf=r size=128 type=q align=32 words (r82.0)
//.declare  (497)  rf=r size=128 type=q align=32 words (r96.0)
//.declare  (498)  rf=r size=128 type=q align=32 words (r94.0)
//.declare  (499)  rf=r size=128 type=q align=32 words (r92.0)
//.declare  (500)  rf=r size=128 type=q align=32 words (r90.0)
//.declare  (503)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (504)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (505)  rf=r size=128 type=q align=32 words (r16.0)
//.declare  (506)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (507)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (508)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (513)  rf=r size=128 type=q align=32 words (r3.0)
//.declare  (514)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (515)  rf=r size=128 type=q align=32 words (r7.0)
//.declare  (516)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (517)  rf=r size=128 type=q align=32 words (r11.0)
//.declare  (518)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (523)  rf=r size=128 type=q align=32 words (r3.0)
//.declare  (524)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (527)  rf=r size=128 type=d alias=+0 align=32 words (r20.0)
//.declare  (528)  rf=r size=128 type=d alias=+0 align=32 words (r22.0)
//.declare  (529)  rf=r size=128 type=d alias=+0 align=32 words (r11.0)
//.declare  (530)  rf=r size=128 type=d alias=+0 align=32 words (r13.0)
//.declare  (531)  rf=r size=64 type=d align=32 words (r2.0)
//.declare  (532)  rf=r size=64 type=d align=32 words (r3.0)
//.declare  (533)  rf=r size=64 type=d align=32 words (r4.0)
//.declare  (534)  rf=r size=64 type=d align=32 words (r5.0)
//.declare  (535)  rf=r size=64 type=d align=32 words (r6.0)
//.declare  (536)  rf=r size=64 type=d align=32 words (r7.0)
//.declare  (537)  rf=r size=64 type=d align=32 words (r8.0)
//.declare  (538)  rf=r size=64 type=d align=32 words (r9.0)
//.declare  (539)  rf=r size=64 type=d align=32 words (r10.0)
//.declare  (540)  rf=r size=64 type=d align=32 words (r11.0)
//.declare  (541)  rf=r size=64 type=d align=32 words (r12.0)
//.declare  (542)  rf=r size=64 type=d align=32 words (r13.0)
//.declare  (543)  rf=r size=64 type=d align=32 words (r14.0)
//.declare  (544)  rf=r size=64 type=d align=32 words (r15.0)
//.declare  (545)  rf=r size=64 type=d align=32 words (r16.0)
//.declare  (546)  rf=r size=64 type=d align=32 words (r17.0)
//.declare  (547)  rf=r size=64 type=d align=32 words (r18.0)
//.declare  (548)  rf=r size=64 type=d align=32 words (r19.0)
//.declare  (549)  rf=r size=64 type=d align=32 words (r20.0)
//.declare  (550)  rf=r size=64 type=d align=32 words (r21.0)
//.declare  (551)  rf=r size=64 type=d align=32 words (r22.0)
//.declare  (552)  rf=r size=64 type=d align=32 words (r23.0)
//.declare  (553)  rf=r size=64 type=d align=32 words (r24.0)
//.declare  (554)  rf=r size=64 type=d align=32 words (r25.0)
//.declare  (555)  rf=r size=64 type=d align=32 words (r26.0)
//.declare  (556)  rf=r size=64 type=d align=32 words (r27.0)
//.declare  (557)  rf=r size=64 type=d align=32 words (r28.0)
//.declare  (558)  rf=r size=64 type=d align=32 words (r29.0)
//.declare  (559)  rf=r size=64 type=d align=32 words (r30.0)
//.declare  (560)  rf=r size=64 type=d align=32 words (r31.0)
//.declare  (561)  rf=r size=64 type=d align=32 words (r32.0)
//.declare  (562)  rf=r size=64 type=d align=32 words (r33.0)
//.declare  (563)  rf=r size=64 type=d align=32 words (r34.0)
//.declare  (564)  rf=r size=64 type=d align=32 words (r35.0)
//.declare  (565)  rf=r size=64 type=d align=32 words (r36.0)
//.declare  (566)  rf=r size=64 type=d align=32 words (r37.0)
//.declare  (567)  rf=r size=64 type=d align=32 words (r38.0)
//.declare  (568)  rf=r size=64 type=d align=32 words (r39.0)
//.declare  (569)  rf=r size=64 type=d align=32 words (r40.0)
//.declare  (570)  rf=r size=64 type=d align=32 words (r41.0)
//.declare  (571)  rf=r size=64 type=d align=32 words (r42.0)
//.declare  (572)  rf=r size=64 type=d align=32 words (r43.0)
//.declare  (573)  rf=r size=64 type=d align=32 words (r44.0)
//.declare  (574)  rf=r size=64 type=d align=32 words (r45.0)
//.declare  (575)  rf=r size=64 type=d align=32 words (r46.0)
//.declare  (576)  rf=r size=64 type=d align=32 words (r47.0)
//.declare  (577)  rf=r size=64 type=d align=32 words (r48.0)
//.declare  (578)  rf=r size=64 type=d align=32 words (r49.0)
//.declare  (579)  rf=r size=64 type=d align=32 words (r50.0)
//.declare  (580)  rf=r size=64 type=d align=32 words (r51.0)
//.declare  (581)  rf=r size=64 type=d align=32 words (r52.0)
//.declare  (582)  rf=r size=64 type=d align=32 words (r53.0)
//.declare  (583)  rf=r size=64 type=d align=32 words (r54.0)
//.declare  (584)  rf=r size=64 type=d align=32 words (r55.0)
//.declare  (585)  rf=r size=64 type=d align=32 words (r56.0)
//.declare  (586)  rf=r size=64 type=d align=32 words (r57.0)
//.declare r0 (587)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (588)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (589)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (590)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (591)  rf=r size=64 type=ud align=32 words (r1.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0040    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0034    | :uq      |    0x8 | r2       | inline+0x0       |
// | V0035    | :uq      |    0x8 | r2+0x8   | inline+0x8       |
// | V0036    | :uq      |    0x8 | r2+0x10  | inline+0x10      |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@2}           //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
// B002: Preds:{B001},  Succs:{B003, B004}
// _main:
(W)     mov (16|M0)              r108.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
        cmp (32|M0)   (lt)f3.0   null<2>:uw    r1.0<1;1,0>:uw    0x140:uw              {A@1,$0.dst}  //  ALU pipe: int; $10
(W)     mul (1|M0)               acc0.0<1>:ud  r108.1<0;1,0>:ud  0x834:uw              {I@4}         //  ALU pipe: int; $4
(W)     mach (1|M0)              r3.0<1>:d     r108.1<0;1,0>:ud  0x834:ud                            //  ALU pipe: int; 
        mov (32|M0)              r78.0<1>:d    r1.0<1;1,0>:uw                                        //  ALU pipe: int; $2
(W)     mul (1|M0)               r4.0<1>:ud    r108.1<0;1,0>:ud  0x834:uw              {Compacted}   //  ALU pipe: int; $3
(f3.0)  goto (32|M0)                         _0_029            _0_029                                //  ALU pipe: int; $11
// B003: [inDivergent],  Preds:{B002},  Succs:{B020}
_0_030:
        mov (32|M0)              r80.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $13
        goto (32|M0)                         _0_029            _0_031                                // $14
// B004: [inDivergent],  Preds:{B002},  Succs:{B005}
_0_029:
        join (32|M0)                         _0_031                                                  // 
L328:
(W)     mov (1|M0)               r2.7<1>:d     r3.0<0;1,0>:d                    {I@7}                //  ALU pipe: int; $17
        shl (32|M0)              r3.0<1>:w     r1.0<1;1,0>:w     3:w                                 //  ALU pipe: int; $26
        and (32|M0)              r8.0<1>:w     r3.0<1;1,0>:w     24:w               {I@1}            //  ALU pipe: int; $27
        and (32|M0)              r3.0<1>:w     r3.0<1;1,0>:w     248:w                               //  ALU pipe: int; $28
        shr (32|M0)              r10.0<1>:ud   r3.0<1;1,0>:uw    7:w               {I@1}             //  ALU pipe: int; $30
        shl (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    6:w               {Compacted,I@1}   //  ALU pipe: int; $31
        shl (32|M0)              r76.0<1>:d    r78.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $21
(W)     mov (1|M0)               r2.6<1>:d     r4.0<0;1,0>:d                                         //  ALU pipe: int; $16
        shr (32|M0)              r4.0<1>:ud    r78.0<1;1,0>:ud   1:w                                 //  ALU pipe: int; $22
        mov (16|M0)              r14.0<2>:ud   r12.0<1;1,0>:ud                  {Compacted,I@4}      //  ALU pipe: int; $32
        and (32|M0)              r6.0<1>:d     r76.0<1;1,0>:d    32:w               {Compacted,I@4}  //  ALU pipe: int; $25
        shl (32|M0)              r24.0<1>:d    r10.0<1;1,0>:d    5:w               {Compacted}       //  ALU pipe: int; $35
        and (32|M0)              r60.0<1>:d    r4.0<1;1,0>:d     4:w               {Compacted,I@4}   //  ALU pipe: int; $23
        and (32|M0)              r58.0<1>:d    r4.0<1;1,0>:d     6:w               {Compacted}       //  ALU pipe: int; $24
        mov (16|M0)              r104.0<1>:q   r14.0<2;1,0>:ud                  {I@5}                //  ALU pipe: int; $32
        shr (32|M0)              r14.0<1>:ud   r3.0<1;1,0>:uw    4:w                                 //  ALU pipe: int; $37
        mov (16|M16)             r16.0<2>:ud   r13.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $32
        mov (16|M16)             r4.0<2>:ud    r7.0<1;1,0>:ud                   {Compacted,I@7}      //  ALU pipe: int; $33
        mov (32|M0)              r80.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $41
        mov (16|M0)              r20.0<4>:uw   r8.0<1;1,0>:uw                                        //  ALU pipe: int; $34
        mov (16|M16)             r22.0<4>:uw   r8.16<1;1,0>:uw                                       //  ALU pipe: int; $34
        mov (16|M0)              r18.0<2>:ud   r6.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $33
        mov (16|M0)              r26.0<2>:ud   r24.0<1;1,0>:ud                  {Compacted,I@7}      //  ALU pipe: int; $36
        mov (16|M16)             r102.0<1>:q   r16.0<2;1,0>:ud                  {I@6}                //  ALU pipe: int; $32
        mov (16|M16)             r12.0<2>:ud   r25.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $36
        mov (16|M16)             r98.0<1>:q    r4.0<2;1,0>:ud                   {I@7}                //  ALU pipe: int; $33
        mov (16|M0)              r16.0<2>:ud   r14.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $38
        mov (16|M16)             r4.0<2>:ud    r15.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $38
        mov (16|M0)              r88.0<1>:q    r20.0<4;1,0>:uw                  {I@7}                //  ALU pipe: int; $34
        mov (16|M16)             r82.0<1>:q    r22.0<4;1,0>:uw                  {I@7}                //  ALU pipe: int; $34
        mov (16|M0)              r100.0<1>:q   r18.0<2;1,0>:ud                  {I@7}                //  ALU pipe: int; $33
        mov (16|M0)              r96.0<1>:q    r26.0<2;1,0>:ud                  {I@7}                //  ALU pipe: int; $36
        mov (16|M16)             r94.0<1>:q    r12.0<2;1,0>:ud                  {I@7}                //  ALU pipe: int; $36
        mov (16|M0)              r92.0<1>:q    r16.0<2;1,0>:ud                  {I@7}                //  ALU pipe: int; $38
        mov (16|M16)             r90.0<1>:q    r4.0<2;1,0>:ud                   {I@7}                //  ALU pipe: int; $38
(W)     mov (1|M0)               r109.1<1>:f   0x7F800000:f                               {Compacted} //  (0x7f800000:f); ALU pipe: float; $39
(W)     mov (1|M0)               r109.0<1>:d   15:w                               {Compacted}        //  ALU pipe: int; $40
(W)     add (1|M0)               r109.1<1>:q   r2.3<0;1,0>:q     r2.0<0;1,0>:q                       //  ALU pipe: int; $20
// B005: [inDivergent],  Preds:{B019, B004},  Succs:{B006, B007}
_0_032:
        shr (32|M0)              r4.0<1>:ud    r76.0<1;1,0>:ud   8:w                                 //  ALU pipe: int; $43
        mul (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     210:w               {Compacted,I@1} //  ALU pipe: int; $44
        mov (16|M0)              r8.0<2>:ud    r6.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $46
        mov (16|M16)             r10.0<2>:ud   r7.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $46
        add (16|M0)              r32.0<1>:q    r109.1<0;1,0>:q   r8.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $46
        add (16|M16)             r34.0<1>:q    r109.1<0;1,0>:q   r10.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $46
        add (16|M0)              r12.0<1>:q    r32.0<1;1,0>:q    r104.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $47
        add (16|M16)             r14.0<1>:q    r34.0<1;1,0>:q    r102.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $47
        add (16|M0)              r16.0<1>:q    r12.0<1;1,0>:q    r100.0<1;1,0>:q  {Compacted,I@2}    //  ALU pipe: int; $48
        add (16|M16)             r18.0<1>:q    r14.0<1;1,0>:q    r98.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $48
        add (16|M0)              r20.0<1>:q    r16.0<1;1,0>:q    r88.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $49
        add (16|M16)             r22.0<1>:q    r18.0<1;1,0>:q    r82.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $49 R{} IR{}{E:1,E:1,},  R{} IR{}{O:9,O:9,},  {BC=2}
        mov (16|M0)              r24.0<1>:d    r20.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $51
        mov (16|M16)             r25.0<1>:d    r22.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $51
        shl (32|M0)              r4.0<1>:d     r24.0<1;1,0>:d    3:w               {Compacted,I@1}   //  ALU pipe: int; $52
        and (32|M0)   (eq)f0.0   r26.0<1>:d    r4.0<1;1,0>:d     24:w               {I@1}            //  ALU pipe: int; $53
        shr (32|M0)              r8.0<1>:ud    r26.0<1;1,0>:ud   3:w               {I@1}             //  ALU pipe: int; $54
        mov (16|M0)              r6.0<2>:ud    r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $56
        mov (16|M16)             r10.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $56
        add (16|M0)              r84.0<1>:q    r20.0<1;1,0>:q    -r6.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $56
        add (16|M16)             r86.0<1>:q    r22.0<1;1,0>:q    -r10.0<2;1,0>:ud {I@2}              //  ALU pipe: int; $56
        load.ugm.d32x2.a64 (32|M0)  r28:4       [r84:4]            {I@1,$1} // ex_desc:0x0; desc:0x8401580 // $57
        mov (32|M0)              r70.0<1>:f    r28.0<1;1,0>:f                   {Compacted,$1.dst}   //  ALU pipe: float; $58
        mov (32|M0)              r66.0<1>:f    r30.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $59
(f0.0)  goto (32|M0)                         _0_033            _0_033                                //  ALU pipe: int; $61
// B006: [inDivergent],  Preds:{B005},  Succs:{B007}
_0_034:
        load.ugm.d32.a64 (32|M0)  r8:2          [r84:4+0x8]        {$2} // ex_desc:0x8000; desc:0x8200580 // $66
        shl (32|M0)              r4.0<1>:d     r66.0<1;1,0>:d    16:w               {Compacted,F@1}  //  ALU pipe: int; $63
        shr (32|M0)              r6.0<1>:ud    r70.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $64
        shr (32|M0)              r12.0<1>:ud   r66.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $68
        or (32|M0)               r70.0<1>:d    r4.0<1;1,0>:d     r6.0<1;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $65
        shl (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     16:w               {Compacted,$2.dst} //  ALU pipe: int; $67
        or (32|M0)               r66.0<1>:d    r10.0<1;1,0>:d    r12.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $69
// B007: [inDivergent],  Preds:{B006, B005},  Succs:{B008, B009}
_0_033:
        join (32|M0)                         _0_031                                                  // 
L1168:
        add (16|M0)              r3.0<1>:q     r32.0<1;1,0>:q    128:w               {Compacted}     //  ALU pipe: int; $71
        add (16|M16)             r5.0<1>:q     r34.0<1;1,0>:q    128:w               {Compacted}     //  ALU pipe: int; $71
        add (16|M0)              r7.0<1>:q     r3.0<1;1,0>:q     r96.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $72
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r94.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $72
        add (16|M0)              r11.0<1>:q    r7.0<1;1,0>:q     r88.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $73
        add (16|M16)             r13.0<1>:q    r9.0<1;1,0>:q     r82.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $73
        mov (16|M0)              r16.0<1>:d    r11.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $75
        mov (16|M16)             r17.0<1>:d    r13.0<2;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $75
        shl (32|M0)              r18.0<1>:d    r16.0<1;1,0>:d    3:w               {Compacted,I@1}   //  ALU pipe: int; $76
        and (32|M0)   (eq)f3.0   r20.0<1>:d    r18.0<1;1,0>:d    24:w               {I@1}            //  ALU pipe: int; $77
        shr (32|M0)              r22.0<1>:ud   r20.0<1;1,0>:ud   3:w               {I@1}             //  ALU pipe: int; $78
        mov (16|M0)              r24.0<2>:ud   r22.0<1;1,0>:ud                  {Compacted,I@1}      //  ALU pipe: int; $80
        mov (16|M16)             r26.0<2>:ud   r23.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $80
        add (16|M0)              r72.0<1>:q    r11.0<1;1,0>:q    -r24.0<2;1,0>:ud {I@2}              //  ALU pipe: int; $80
        add (16|M16)             r74.0<1>:q    r13.0<1;1,0>:q    -r26.0<2;1,0>:ud {I@2}              //  ALU pipe: int; $80
        load.ugm.d32x2.a64 (32|M0)  r28:4       [r72:4]            {I@1,$3} // ex_desc:0x0; desc:0x8401580 // $81
        mov (32|M0)              r68.0<1>:f    r28.0<1;1,0>:f                   {Compacted,$3.dst}   //  ALU pipe: float; $82
        mov (32|M0)              r62.0<1>:d    r30.0<1;1,0>:d                   {Compacted}          //  ALU pipe: int; $83
(f3.0)  goto (32|M0)                         _0_035            _0_035                                //  ALU pipe: int; $85
// B008: [inDivergent],  Preds:{B007},  Succs:{B009}
_0_036:
        load.ugm.d32.a64 (32|M0)  r8:2          [r72:4+0x8]        {$4} // ex_desc:0x8000; desc:0x8200580 // $90
        shl (32|M0)              r4.0<1>:d     r62.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $87
        shr (32|M0)              r6.0<1>:ud    r68.0<1;1,0>:ud   16:w               {F@1}            //  ALU pipe: int; $88
        shr (32|M0)              r12.0<1>:ud   r62.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $92
        or (32|M0)               r68.0<1>:d    r4.0<1;1,0>:d     r6.0<1;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $89
        shl (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     16:w               {Compacted,$4.dst} //  ALU pipe: int; $91
        or (32|M0)               r62.0<1>:d    r10.0<1;1,0>:d    r12.0<1;1,0>:d   {Compacted,I@1}    //  ALU pipe: int; $93
// B009: [inDivergent],  Preds:{B008, B007},  Succs:{B010, B017}
_0_035:
        join (32|M0)                         _0_031                                                  // 
L1464:
        load.ugm.d16u32.a64 (32|M0)  r4:2       [r32:4+0xD0]       {$5} // ex_desc:0xD0000; desc:0x8200B80 // $95
        shr (32|M0)              r6.0<1>:ud    r4.0<1;1,0>:ud    10:w               {$5.dst}         //  ALU pipe: int; $99
        and (32|M0)              r112.0<1>:d   r6.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $100
        cmp (32|M0)   (eq)f2.0   null<1>:d     r112.0<1;1,0>:d   31:w               {I@1}            //  ALU pipe: int; $102
        and (32|M0)              r64.0<1>:d    r4.0<2;1,0>:w     -2147483648:d                       //  ALU pipe: int; $98
        and (32|M0)              r106.0<1>:d   r4.0<1;1,0>:ud    1023:w                              //  ALU pipe: int; $101
(f2.0)  goto (32|M0)                         _0_037            _0_037                                //  ALU pipe: int; $103
// B010: [inDivergent],  Preds:{B009},  Succs:{B011, B012}
_0_038:
        cmp (32|M0)   (eq)f1.0   null<1>:d     r112.0<1;1,0>:d   0:w                                 //  ALU pipe: int; $105
(f1.0)  goto (32|M0)                         _0_039            _0_039                                //  ALU pipe: int; $106
// B011: [inDivergent],  Preds:{B010},  Succs:{B018}
_0_040:
        shl (32|M0)              r4.0<1>:d     r112.0<1;1,0>:d   23:w               {Compacted}      //  ALU pipe: int; $108
        shl (32|M0)              r8.0<1>:d     r106.0<1;1,0>:d   13:w               {Compacted,I@5}  //  ALU pipe: int; $110
        add (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     939524096:d               {I@2}     //  ALU pipe: int; $109
        bfn.(s0|s1|s2) (32|M0)   r64.0<1>:ud   r6.0<1;0>:ud      r8.0<1;0>:ud      r64.0<1>:ud      {I@1} //  ALU pipe: int; $111 R{} IR{}{E:3,E:4,E:0,},  R{} IR{}{O:3,O:4,O:0,},  {BC=2}
        goto (32|M0)                         _0_039            _0_041                                // $112
// B012: [inDivergent],  Preds:{B010},  Succs:{B013, B018}
_0_039:
        join (32|M0)                         _0_037                                                  // 
L1680:
        cmp (32|M0)   (eq)f0.0   null<1>:d     r106.0<1;1,0>:d   0:w                                 //  ALU pipe: int; $114
(f0.0)  goto (32|M0)                         _0_037            _0_041                                //  ALU pipe: int; $115
// B013: [inDivergent],  Preds:{B012},  Succs:{B014}
_0_042:
(W)     mov (1|M0)               r2.0<1>:d     -14:w                               {Compacted}       //  ALU pipe: int; $117
// B014: [inDivergent],  Preds:{B015, B013},  Succs:{B015, B016}
_0_043:
        and (32|M0)   (eq)f0.0   null<1>:d     r106.0<1;1,0>:d   512:w                               //  ALU pipe: int; $120
(W)     add (1|M0)               r2.0<1>:d     r2.0<0;1,0>:d     -1:w               {Compacted,I@2}  //  ALU pipe: int; $119
        mov (32|M0)              r110.0<1>:f   r2.0<0;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $122
(~f0.0) goto (32|M0)                         _0_044            _0_044                                //  ALU pipe: int; $123
// B015: [inDivergent],  Preds:{B014},  Succs:{B014}
_0_045:
        shl (32|M0)              r106.0<1>:d   r106.0<1;1,0>:d   1:w               {Compacted}       //  ALU pipe: int; $125
(W)     jmpi                                 _0_043                                                  // $126
// B016: [inDivergent],  Preds:{B014},  Succs:{B018}
_0_044:
        join (32|M0)                         _0_037                                                  // 
L1808:
        shl (32|M0)              r4.0<1>:d     r110.0<1;1,0>:d   23:w               {Compacted,F@1}  //  ALU pipe: int; $128
        shl (32|M0)              r8.0<1>:d     r106.0<1;1,0>:d   14:w               {Compacted,I@4}  //  ALU pipe: int; $130
        add (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1065353216:d               {I@2}    //  ALU pipe: int; $129
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     8372224:d               {I@2}       //  ALU pipe: int; $131
        bfn.(s0|s1|s2) (32|M0)   r64.0<1>:ud   r6.0<1;0>:ud      r10.0<1;0>:ud     r64.0<1>:ud      {I@1} //  ALU pipe: int; $132 R{} IR{}{E:3,E:5,E:0,},  R{} IR{}{O:3,O:5,O:0,},  {BC=2}
        goto (32|M0)                         _0_037            _0_041                                // $133
// B017: [inDivergent],  Preds:{B009},  Succs:{B018}
_0_037:
        join (32|M0)                         _0_041                                                  // 
L1904:
        cmp (32|M0)   (eq)f3.0   null<1>:d     r106.0<1;1,0>:d   0:w                                 //  ALU pipe: int; $135
(W)     mov (1|M0)               r2.12<1>:hf   0x0:hf                                                //  ALU pipe: float; $136
(f3.0)  sel (32|M0)              r4.0<1>:d     r2.12<0;1,0>:w    4194304:d               {F@1}       //  ALU pipe: int; $136
        bfn.(s0|s1|s2) (32|M0)   r64.0<1>:ud   r64.0<1;0>:ud     r4.0<1;0>:ud      r109.1<0>:ud     {I@1} //  ALU pipe: int; $137
// B018: [inDivergent],  Preds:{B017, B016, B012, B011},  Succs:{B019, B020}
_0_041:
        join (32|M0)                         _0_031                                                  // 
L1984:
        add (16|M0)              r3.0<1>:q     r32.0<1;1,0>:q    192:w               {Compacted}     //  ALU pipe: int; $139
        add (16|M16)             r5.0<1>:q     r34.0<1;1,0>:q    192:w               {Compacted}     //  ALU pipe: int; $139
        add (16|M0)              r12.0<1>:q    r3.0<1;1,0>:q     r92.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $140
        add (16|M16)             r14.0<1>:q    r5.0<1;1,0>:q     r90.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $140
        load.ugm.d8u32.a64 (32|M0)  r24:2       [r12:4]            {I@1,$6} // ex_desc:0x0; desc:0x8200980 // $141
        shl (32|M0)              r8.0<1>:d     r76.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $143
        mov (16|M0)              r18.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $145
        mov (16|M16)             r20.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $145
        add (16|M0)              r26.0<1>:q    r2.1<0;1,0>:q     r18.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $145 R{} IR{}{E:1,E:1,},  R{r2,} IR{} {BC=1}
        add (16|M16)             r28.0<1>:q    r2.1<0;1,0>:q     r20.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $145
        load.ugm.d32.a64 (32|M0)  r36:2         [r26:4]            {I@1,$7} // ex_desc:0x0; desc:0x8200580 // $146
        load.ugm.d32.a64 (32|M0)  r38:2         [r26:4+0x4]        {$8} // ex_desc:0x4000; desc:0x8200580 // $147
        load.ugm.d32.a64 (32|M0)  r4:2          [r26:4+0x8]        {$9} // ex_desc:0x8000; desc:0x8200580 // $148
        load.ugm.d32.a64 (32|M0)  r6:2          [r26:4+0xC]        {$10} // ex_desc:0xC000; desc:0x8200580 // $235
        and (32|M0)              r10.0<1>:d    r68.0<1;1,0>:d    255:w               {Compacted}     //  ALU pipe: int; $155
        shr (32|M0)              r22.0<1>:ud   r10.0<1;1,0>:ud   r58.0<1;1,0>:d   {I@1}              //  ALU pipe: int; $157 R{} IR{}{E:5,E:5,},  R{} IR{}{O:5,O:13,},  {BC=1}
        shr (32|M0)              r16.0<1>:ud   r68.1<4;1,0>:ub   r58.0<1;1,0>:d                      //  ALU pipe: int; $166
        shl (32|M0)              r32.0<1>:d    r22.0<1;1,0>:d    4:w               {Compacted,I@2}   //  ALU pipe: int; $158
        shr (32|M0)              r34.0<1>:ud   r70.0<1;1,0>:ud   8:w                                 //  ALU pipe: int; $164
        shr (32|M0)              r30.0<1>:ud   r70.0<1;1,0>:ud   r60.0<1;1,0>:d                      //  ALU pipe: int; $156
        and (32|M0)              r46.0<1>:d    r62.0<1;1,0>:d    255:w               {Compacted}     //  ALU pipe: int; $192
        shr (32|M0)              r12.0<1>:ud   r68.0<1;1,0>:ud   24:w               {$6.src}         //  ALU pipe: int; $183
        shl (32|M0)              r8.0<1>:d     r16.0<1;1,0>:d    4:w               {Compacted,I@6}   //  ALU pipe: int; $167
        and (32|M0)              r40.0<1>:d    r32.0<1;1,0>:d    48:w               {Compacted,I@6}  //  ALU pipe: int; $159
        shr (32|M0)              r10.0<1>:ud   r68.2<4;1,0>:ub   r58.0<1;1,0>:d                      //  ALU pipe: int; $175
        shr (32|M0)              r18.0<1>:ud   r34.0<1;1,0>:ud   r60.0<1;1,0>:d   {I@7}              //  ALU pipe: int; $165
        bfn.(s0&s1|s2) (32|M0)   r14.0<1>:ud   r30.0<1;0>:ud     r109.0<0;0>:ud    r40.0<1>:ud      {I@3} //  ALU pipe: int; $160
        shr (32|M0)              r34.0<1>:ud   r46.0<1;1,0>:ud   r58.0<1;1,0>:d                      //  ALU pipe: int; $194
        shr (32|M0)              r20.0<1>:ud   r70.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $173
        shr (32|M0)              r44.0<1>:ud   r12.0<1;1,0>:ud   r58.0<1;1,0>:d                      //  ALU pipe: int; $185
        and (32|M0)              r22.0<1>:d    r8.0<1;1,0>:d     48:w               {Compacted}      //  ALU pipe: int; $168
        shl (32|M0)              r42.0<1>:d    r10.0<1;1,0>:d    4:w               {Compacted,I@7}   //  ALU pipe: int; $176
        add (32|M0)              r48.0<1>:d    r14.0<1;1,0>:d    -32:w               {Compacted,I@6} //  ALU pipe: int; $161
        shr (32|M0)              r28.0<1>:ud   r70.0<1;1,0>:ud   24:w               {$10.src}        //  ALU pipe: int; $182
        mov (32|M0)              r3.0<1>:b     r24.0<4;1,0>:b                   {$6.dst}             //  ALU pipe: int; $142
        bfn.(s0&s1|s2) (32|M0)   r26.0<1>:ud   r18.0<1;0>:ud     r109.0<0;0>:ud    r22.0<1>:ud      {I@5} //  ALU pipe: int; $169
        shl (32|M0)              r14.0<1>:d    r34.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $195
        shr (32|M0)              r16.0<1>:ud   r20.0<1;1,0>:ud   r60.0<1;1,0>:d                      //  ALU pipe: int; $174
        shl (32|M0)              r30.0<1>:d    r44.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $186
        shr (32|M0)              r18.0<1>:ud   r62.1<4;1,0>:ub   r58.0<1;1,0>:d                      //  ALU pipe: int; $203
        and (32|M0)              r32.0<1>:d    r42.0<1;1,0>:d    48:w               {Compacted,I@7}  //  ALU pipe: int; $177
        mov (32|M0)              r40.0<1>:f    r48.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $162
        mov (32|M0)   (lt)f2.0   null<2>:w     r3.0<1;1,0>:b                    {I@7}                //  ALU pipe: int; $150
        shr (32|M0)              r44.0<1>:ud   r66.0<1;1,0>:ud   r60.0<1;1,0>:d                      //  ALU pipe: int; $193
        shr (32|M0)              r12.0<1>:ud   r28.0<1;1,0>:ud   r60.0<1;1,0>:d                      //  ALU pipe: int; $184 R{} IR{}{E:6,E:6,},  R{} IR{}{O:14,O:14,},  {BC=2}
        add (32|M0)              r8.0<1>:d     r26.0<1;1,0>:d    -32:w               {Compacted,I@7} //  ALU pipe: int; $170
        and (32|M0)              r48.0<1>:d    r14.0<1;1,0>:d    48:w               {Compacted,A@1}  //  ALU pipe: int; $196
        and (32|M0)              r50.0<1>:d    r30.0<1;1,0>:d    48:w               {Compacted,I@7}  //  ALU pipe: int; $187
        bfn.(s0&s1|s2) (32|M0)   r10.0<1>:ud   r16.0<1;0>:ud     r109.0<0;0>:ud    r32.0<1>:ud      {I@7} //  ALU pipe: int; $178 R{} IR{}{E:0,O:6,E:0,},  R{r109,} IR{}{O:8,O:0,},  {BC=1}
        shl (32|M0)              r26.0<1>:d    r18.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $204
        or (32|M0)               r14.0<1>:d    r24.0<1;1,0>:ud   -256:w                              //  ALU pipe: int; $149
        bfn.(s0&s1|s2) (32|M0)   r34.0<1>:ud   r44.0<1;0>:ud     r109.0<0;0>:ud    r48.0<1>:ud      {I@5} //  ALU pipe: int; $197
        bfn.(s0&s1|s2) (32|M0)   r42.0<1>:ud   r12.0<1;0>:ud     r109.0<0;0>:ud    r50.0<1>:ud      {I@5} //  ALU pipe: int; $188
        add (32|M0)              r22.0<1>:d    r10.0<1;1,0>:d    -32:w               {Compacted,I@5} //  ALU pipe: int; $179
(f2.0)  sel (32|M0)              r44.0<1>:d    r14.0<1;1,0>:d    r24.0<1;1,0>:ud  {I@4}              //  ALU pipe: int; $152
        and (32|M0)              r12.0<1>:d    r26.0<1;1,0>:d    48:w               {Compacted}      //  ALU pipe: int; $205
        shr (32|M0)              r46.0<1>:ud   r66.0<1;1,0>:ud   8:w                                 //  ALU pipe: int; $201
        mov (32|M0)              r26.0<1>:f    r44.0<1;1,0>:d                   {I@2}                //  ALU pipe: float; $153
        mov (32|M0)              r30.0<1>:f    r22.0<1;1,0>:d                                        //  ALU pipe: float; $180
        mov (32|M0)              r20.0<1>:f    r8.0<1;1,0>:d                                         //  ALU pipe: float; $171
        shr (32|M0)              r16.0<1>:ud   r62.2<4;1,0>:ub   r58.0<1;1,0>:d                      //  ALU pipe: int; $212
        mul (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $154
        sync.nop                             null                             {Compacted,F@3}        // $238
        mov (32|M0)              r22.0<1>:d    r36.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $238
        add (32|M0)              r32.0<1>:d    r42.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $189
        shr (32|M0)              r8.0<1>:ud    r46.0<1;1,0>:ud   r60.0<1;1,0>:d   {A@2}              //  ALU pipe: int; $202
        shr (32|M0)              r28.0<1>:ud   r62.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $220
        mul (32|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   r40.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $163
        mov (32|M0)              r42.0<1>:d    r36.1<2;1,0>:uw                                       //  ALU pipe: int; $242
        shl (32|M0)              r46.0<1>:d    r22.0<1;1,0>:d    16:w               {Compacted,I@5}  //  ALU pipe: int; $239
        shl (32|M0)              r50.0<1>:d    r16.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $213
        mul (32|M0)              r14.0<1>:f    acc0.0<1;1,0>:f   r30.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $181
        shl (32|M0)              r48.0<1>:d    r42.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $243
        mul (32|M0)              r36.0<1>:f    acc0.0<1;1,0>:f   r20.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $172
        mov (32|M0)              r16.0<1>:d    r38.0<2;1,0>:uw                  {$8.dst}             //  ALU pipe: int; $246
        shr (32|M0)              r10.0<1>:ud   r66.0<1;1,0>:ud   16:w                                //  ALU pipe: int; $210
        shr (32|M0)              r18.0<1>:ud   r28.0<1;1,0>:ud   r58.0<1;1,0>:d                      //  ALU pipe: int; $222
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r46.0<1;1,0>:f   {Compacted,I@6}    //  ALU pipe: float; $240
        shl (32|M0)              r28.0<1>:d    r16.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $247
        add (32|M0)              r54.0<1>:d    r34.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $198
        mov (32|M0)              r52.0<1>:f    r32.0<1;1,0>:d                                        //  ALU pipe: float; $190
        mul (32|M0)              r24.0<1>:f    r36.0<1;1,0>:f    r48.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $244
        add (32|M0)              acc2.0<1>:f   r80.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $241
        mov (32|M0)              r56.0<1>:d    r38.1<2;1,0>:uw                                       //  ALU pipe: int; $250
        shr (32|M0)              r22.0<1>:ud   r10.0<1;1,0>:ud   r60.0<1;1,0>:d   {I@5}              //  ALU pipe: int; $211
        bfn.(s0&s1|s2) (32|M0)   r32.0<1>:ud   r8.0<1;0>:ud      r109.0<0;0>:ud    r12.0<1>:ud      {F@3} //  ALU pipe: int; $206
        shr (32|M0)              r42.0<1>:ud   r66.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $219
        and (32|M0)              r34.0<1>:d    r50.0<1;1,0>:d    48:w               {Compacted}      //  ALU pipe: int; $214
        mul (32|M0)              r26.0<1>:f    acc0.0<1;1,0>:f   r52.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $191
        mul (32|M0)              r8.0<1>:f     r14.0<1;1,0>:f    r28.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $248
        shl (32|M0)              r16.0<1>:d    r18.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $223
        mov (32|M0)              r20.0<1>:f    r54.0<1;1,0>:d                                        //  ALU pipe: float; $199
        shl (32|M0)              r12.0<1>:d    r56.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $251
        add (32|M0)              r10.0<1>:d    r32.0<1;1,0>:d    -32:w               {Compacted}     //  ALU pipe: int; $207
        add (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r24.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $245
        mov (32|M0)              r30.0<1>:d    r4.0<2;1,0>:uw                   {$9.dst}             //  ALU pipe: int; $254
        bfn.(s0&s1|s2) (32|M0)   r36.0<1>:ud   r22.0<1;0>:ud     r109.0<0;0>:ud    r34.0<1>:ud      {I@5} //  ALU pipe: int; $215
        shr (32|M0)              r38.0<1>:ud   r42.0<1;1,0>:ud   r60.0<1;1,0>:d                      //  ALU pipe: int; $221
        mul (32|M0)              r44.0<1>:f    acc0.0<1;1,0>:f   r20.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $200
        add (32|M0)              r18.0<1>:f    acc2.0<1;1,0>:f   r8.0<1;1,0>:f    {Compacted,I@6}    //  ALU pipe: float; $249
        and (32|M0)              r40.0<1>:d    r16.0<1;1,0>:d    48:w               {Compacted}      //  ALU pipe: int; $224
        mov (32|M0)              r24.0<1>:f    r10.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $208
        shl (32|M0)              r14.0<1>:d    r30.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $255
        add (32|M0)              r28.0<1>:d    r36.0<1;1,0>:d    -32:w               {Compacted,I@4} //  ALU pipe: int; $216
        mul (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    r12.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $252
        mov (32|M0)              r46.0<1>:d    r4.1<2;1,0>:uw                                        //  ALU pipe: int; $258
        bfn.(s0&s1|s2) (32|M0)   r32.0<1>:ud   r38.0<1;0>:ud     r109.0<0;0>:ud    r40.0<1>:ud      {I@4} //  ALU pipe: int; $225
        mul (32|M0)              r48.0<1>:f    acc0.0<1;1,0>:f   r24.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $209
        add (32|M0)              r22.0<1>:f    r18.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $253
        mov (32|M0)              r20.0<1>:f    r28.0<1;1,0>:d                   {I@3}                //  ALU pipe: float; $217
        shl (32|M0)              r16.0<1>:d    r46.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $259
        mul (32|M0)              acc2.0<1>:f   r44.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $256
        add (32|M0)              r8.0<1>:d     r32.0<1;1,0>:d    -32:w               {Compacted,I@2} //  ALU pipe: int; $226
        sync.nop                             null                             {Compacted,F@5}        // $262
        mov (32|M0)              r12.0<1>:d    r6.0<2;1,0>:uw                   {$10.dst}            //  ALU pipe: int; $262
        mul (32|M0)              r26.0<1>:f    acc0.0<1;1,0>:f   r20.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $218
        add (32|M0)              r10.0<1>:f    r22.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $257
        mul (32|M0)              acc2.0<1>:f   r48.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $260 R{} IR{}{E:0,E:0,},  R{} IR{}{O:8,O:8,},  {BC=2}
        mov (32|M0)              r30.0<1>:f    r8.0<1;1,0>:d                    {I@2}                //  ALU pipe: float; $227
        shl (32|M0)              r4.0<1>:d     r12.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $263
        add (32|M0)              r18.0<1>:f    r10.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $261
        mov (32|M0)              r24.0<1>:d    r6.1<2;1,0>:uw                                        //  ALU pipe: int; $266
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r30.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $228
        mul (32|M0)              acc2.0<1>:f   r26.0<1;1,0>:f    r4.0<1;1,0>:f    {Compacted,I@2}    //  ALU pipe: float; $264
        shl (32|M0)              r14.0<1>:d    r24.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $267
        add (32|M0)              acc2.0<1>:f   r18.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $265
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r76.0<1;1,0>:ud   0x900:uw                            //  ALU pipe: int; $270
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r14.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $268
        add (32|M0)              r80.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $269
(~f1.0) goto (32|M0)                         _0_031            _0_031                                //  ALU pipe: int; $271
// B019: [inDivergent],  Preds:{B018},  Succs:{B005}
_0_046:
        add (32|M0)              r76.0<1>:d    r76.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $273
(W)     jmpi                                 _0_032                                                  // $274
// B020: Preds:{B018, B003},  Succs:{B021, B025}
_0_031:
        join (32|M0)                         L3560                                                   // 
L3560:
        add (32|M0)              r4.0<1>:d     r78.0<1;1,0>:d    1:w               {Compacted,F@4}   //  ALU pipe: int; $276
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $277
        shl (32|M0)              r3.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $278
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $279
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0x1400:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0059(r80.0:f); $280
        add (32|M0)              r10.0<1>:d    r78.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $289
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $281
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $282
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0x1400:uw                           //  ALU pipe: int; src1 is addr of V0059(r80.0:f); $283
        and (32|M0)   (eq)f2.0   null<1>:d     r78.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $285
        and (32|M0)              r4.0<1>:d     r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $290
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $284
        shl (32|M0)              r12.0<1>:uw   r4.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $291
(f2.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $287
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $292
        add (16|M0)              a0.0<1>:uw    r12.0<1;1,0>:uw   0x1E80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0371(r122.0:f); $293
        add (32|M0)              r122.0<1>:f   r80.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $288
        add (32|M0)              r8.0<1>:d     r78.0<1;1,0>:d    4:w               {Compacted,F@2}   //  ALU pipe: int; $302
        mov (16|M0)              r6.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $294
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $295
        add (16|M16)             a0.0<1>:uw    r12.16<1;1,0>:uw  0x1E80:uw                           //  ALU pipe: int; src1 is addr of V0371(r122.0:f); $296
        and (32|M0)   (eq)f1.0   null<1>:d     r78.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $298
        and (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $303
        mov (16|M16)             r7.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $297
        shl (32|M0)              r3.0<1>:uw    r10.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $304
(f1.0)  sel (32|M0)              acc0.0<1>:f   r6.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $300
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $305
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0x1E00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0379(r120.0:f); $306
        add (32|M0)              r120.0<1>:f   r122.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $301
        add (32|M0)              r6.0<1>:d     r78.0<1;1,0>:d    8:w               {Compacted,F@2}   //  ALU pipe: int; $315
        mov (16|M0)              r4.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $307
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $308
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0x1E00:uw                           //  ALU pipe: int; src1 is addr of V0379(r120.0:f); $309
        and (32|M0)   (eq)f0.0   null<1>:d     r78.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $311
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $316
        mov (16|M16)             r5.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $310
        shl (32|M0)              r12.0<1>:uw   r8.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $317
(f0.0)  sel (32|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $313
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $318
        add (16|M0)              a0.0<1>:uw    r12.0<1;1,0>:uw   0x1D80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0387(r118.0:f); $319
        add (32|M0)              r118.0<1>:f   r120.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $314
        add (32|M0)              r4.0<1>:d     r78.0<1;1,0>:d    16:w               {Compacted,F@2}  //  ALU pipe: int; $328
        mov (16|M0)              r10.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $320
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $321
        add (16|M16)             a0.0<1>:uw    r12.16<1;1,0>:uw  0x1D80:uw                           //  ALU pipe: int; src1 is addr of V0387(r118.0:f); $322
        and (32|M0)   (eq)f3.0   null<1>:d     r78.0<1;1,0>:d    15:w                                //  ALU pipe: int; $324
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     31:w               {Compacted,I@5}  //  ALU pipe: int; $329
        mov (16|M16)             r11.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $323
        shl (32|M0)              r3.0<1>:uw    r6.0<2;1,0>:uw    0x2:uw              {I@2}           //  ALU pipe: int; $330
(f3.0)  sel (32|M0)              acc0.0<1>:f   r10.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $326
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $331
        add (16|M0)              a0.0<1>:uw    r3.0<1;1,0>:uw    0x1F00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0395(r124.0:f); $332
        add (32|M0)              r124.0<1>:f   r118.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $327
        cmp (32|M0)   (eq)f2.0   null<2>:w     r1.0<1;1,0>:w     0:w                                 //  ALU pipe: int; $337
        mov (16|M0)              r116.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $333
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $334
        add (16|M16)             a0.0<1>:uw    r3.16<1;1,0>:uw   0x1F00:uw                           //  ALU pipe: int; src1 is addr of V0395(r124.0:f); $335
        mov (16|M16)             r117.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $336
(~f2.0) goto (32|M0)                         _0_047            _0_047                                //  ALU pipe: int; $338
// B021: [inDivergent],  Preds:{B020},  Succs:{B022, B023}
_0_048:
        and (32|M0)   (eq)f1.0   null<1>:d     r78.0<1;1,0>:d    31:w                                //  ALU pipe: int; $340
(f1.0)  sel (32|M0)              acc0.0<1>:f   r116.0<1;1,0>:f   0x80000000:f               {I@3}    //  ALU pipe: float; $342
        add (32|M0)              r114.0<1>:f   r124.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $343
        and (32|M0)              r4.0<1>:d     r114.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $344
        cmp (32|M0)   (gt)f0.0   null<1>:ud    r4.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $345
(f0.0)  goto (32|M0)                         _0_049            _0_049                                //  ALU pipe: int; $346
// B022: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_050:
        shr (32|M0)              r4.0<1>:ud    r114.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $348
        and (32|M0)              r6.0<1>:d     r4.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $349
        add3 (32|M0)             r8.0<1>:d     r6.0<1;0>:d       r114.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $350
        shr (32|M0)              r10.0<1>:ud   r8.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $351
        mov (32|M0)              r126.0<1>:w   r10.0<2;1,0>:w                   {I@1}                //  ALU pipe: int; $352
        goto (32|M0)                         _0_049            _0_051                                // $353
// B023: [inDivergent],  Preds:{B021},  Succs:{B024}
_0_049:
        join (32|M0)                         _0_051                                                  // 
L4584:
        shr (32|M0)              r4.0<1>:ud    r114.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $355
        or (32|M0)               r126.0<1>:w   r4.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $357
// B024: [inDivergent],  Preds:{B023, B022},  Succs:{B025}
_0_051:
        join (32|M0)                         _0_047                                                  // 
L4632:
(W)     mov (1|M0)               f1.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $362
        cmp (32|M0)   (eq)f1.0   null<2>:uw    r1.0<0;1,0>:uw    r1.0<0;1,0>:uw                      //  ALU pipe: int; $363
(W)     fbl (1|M0)               r3.0<1>:ud    f1.0<0;1,0>:ud                   {Compacted}          //  ALU pipe: int; $365
(W)     shl (1|M0)               r2.3<1>:q     r108.1<0;1,0>:ud  1:w                                 //  ALU pipe: int; $360
(W)     shl (1|M0)               r3.0<1>:ud    r3.0<0;1,0>:ud    1:w               {I@2}             //  ALU pipe: int; $366
(W)     add (1|M0)               r4.0<1>:q     r2.3<0;1,0>:q     r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $361
(W)     add (1|M0)               a0.0<1>:uw    r3.0<0;1,0>:uw    0x1F80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0415(r126.0:w); $367
(W)     mov (1|M0)               r6.0<1>:ud    r[a0.0]<0;1,0>:uw                                     //  ALU pipe: int; $369
(W)     store.ugm.d16u32.a64 (1|M0)  [r4:2]     r6:1               {I@1,$11} // ex_desc:0x0; desc:0x4000B84 // $370
// B025: Preds:{B024, B020},  Succs:{}
_0_047:
        join (32|M0)                         L4776                                                   // 
L4776:
(W)     mov (16|M0)              r127.0<1>:f   r108.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $372
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$12} // wr:1+0, rd:0; end of thread // $372
L4800:
(W)     mov (16|M0)              null<1>:ud    0x785C230:ud                                          // 
(W)     mov (16|M0)              null<1>:ud    0x58CB52D6:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x2:ud                                                // 


//.BankConflicts: 13
//.ByteRMWs: 0
//


//.numALUInst: 341
//.accSubDef: 17
//.accSubUse: 24
//.accSubCandidateDef: 29
//.accSubCandidateUse: 36
//
//
//.singlePipeAtOneDistNum: 53
//.allAtOneDistNum: 4
//.syncInstCount: 2
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 11
//.AfterReadTokenDepCount: 3
