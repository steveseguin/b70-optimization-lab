#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/nongemv_fixture.cpp"
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/build/checked/experiments/own-xpu-runtime/stage2/packet120-placement/fixture_driver.cpp"
