#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/k2_fixture.cpp"
#define PACKET26_K2
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/build/checked/experiments/own-xpu-runtime/stage2/packet120-placement/fixture_driver.cpp"
