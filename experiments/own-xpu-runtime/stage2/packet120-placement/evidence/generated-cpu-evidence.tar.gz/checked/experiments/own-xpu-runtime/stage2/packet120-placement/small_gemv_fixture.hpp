#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/small_gemv_fixture.hpp"
#pragma once
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/build/checked/experiments/own-xpu-runtime/stage2/packet120-placement/adapter_fixture.hpp"
AdapterFixtureReceipt small_gemv_fixture_gate(unsigned,const std::filesystem::path&);
AdapterFixtureReceipt small_gemv_timing_gate(unsigned,const std::filesystem::path&);
