#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/p93_submit.hpp"
#pragma once
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet120-placement/build/checked/experiments/own-xpu-runtime/stage2/packet120-placement/adapter.hpp"
namespace p93 {integrated::Launch submit(ownrt::Device&,const integrated::Matrix&,const std::string&);}
