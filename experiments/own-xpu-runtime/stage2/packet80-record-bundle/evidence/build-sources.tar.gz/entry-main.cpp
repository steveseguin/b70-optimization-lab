#define main packet26_model_entry
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet80-record-bundle/build/checked/experiments/own-xpu-runtime/stage2/packet80-record-bundle/main.cpp"
#undef main
