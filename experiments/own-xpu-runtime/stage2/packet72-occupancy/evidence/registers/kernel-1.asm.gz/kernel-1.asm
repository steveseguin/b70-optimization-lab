//.kernel _ZTSZZNK3p7215AttentionKernel6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS2_5eventESaISA_EEENKUlRNS2_7handlerEE_clESG_EUlNS2_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 272149597 1704713521 -hashmovs1 0 1 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 272149597 1704713521 -hashmovs1 0 1 -GRFBumpUpNumber 2 "
//.instCount 297
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r88.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.11)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.12)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.13)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r88.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r88.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0063 (73)  rf=r size=4 type=d align=2 words (r5.6)
//.declare V0064 (74)  rf=r size=4 type=d align=2 words (r5.7)
//.declare V0065 (75)  rf=r size=4 type=d align=2 words (r5.8)
//.declare V0066 (76)  rf=r size=4 type=d align=2 words (r5.9)
//.declare V0067 (77)  rf=r size=4 type=d align=2 words (r5.10)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0069 (79)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r2.0)
//.declare V0070 (80)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r88.0)
//.declare V0071 (81)  rf=r size=8 type=ud alias=V0068+0 align=4 words (r5.0)
//.declare V0072 (82)  rf=r size=8 type=d alias=V0068+0 align=4 words (r5.0)
//.declare V0073 (83)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0076 (86)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0081 (91)  rf=r size=128 type=d align=32 words (r89.0)
//.declare V0082 (92)  rf=r size=64 type=w align=32 words (r15.0)
//.declare V0083 (93)  rf=r size=128 type=d align=32 words (r91.0)
//.declare V0084 (94)  rf=r size=64 type=uw alias=V0082+0 align=32 words (r15.0)
//.declare V0085 (95)  rf=r size=128 type=d align=32 words (r93.0)
//.declare V0086 (96)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0087 (97)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0088 (98)  rf=r size=128 type=d align=32 words (r95.0)
//.declare V0089 (99)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0090 (100)  rf=r size=128 type=d align=32 words (r97.0)
//.declare P01 (101)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0091 (102)  rf=r size=128 type=ud alias=V0090+0 align=32 words (r97.0)
//.declare V0092 (103)  rf=r size=128 type=ud alias=V0088+0 align=32 words (r95.0)
//.declare V0093 (104)  rf=r size=128 type=f align=32 words (r99.0)
//.declare V0094 (105)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0095 (106)  rf=r size=128 type=ud alias=V0081+0 align=32 words (r89.0)
//.declare V0096 (107)  rf=r size=128 type=ud alias=V0094+0 align=32 words (r6.0)
//.declare V0097 (108)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0099 (110)  rf=r size=128 type=ud alias=V0097+0 align=32 words (r8.0)
//.declare V0102 (113)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0103 (114)  rf=r size=128 type=f align=32 words (r101.0)
//.declare V0104 (115)  rf=r size=128 type=f align=32 words (r103.0)
//.declare V0105 (116)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0106 (117)  rf=r size=128 type=ud alias=V0105+0 align=32 words (r10.0)
//.declare V0110 (121)  rf=r size=256 type=uq align=32 words (r38.0)
//.declare V0111 (122)  rf=r size=128 type=f align=32 words (r54.0)
//.declare V0115 (126)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0116 (127)  rf=r size=512 type=d align=32 words (r26.0)
//.declare V0118 (129)  rf=r size=256 type=q align=32 words (r34.0)
//.declare V0119 (130)  rf=r size=256 type=uq alias=V0118+0 align=32 words (r34.0)
//.declare V0120 (131)  rf=r size=256 type=uq align=32 words (r42.0)
//.declare V0121 (132)  rf=r size=512 type=d align=32 words (r56.0)
//.declare V0122 (133)  rf=r size=512 type=d align=32 words (r46.0)
//.declare P02 (134)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0124 (136)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0125 (137)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0126 (138)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0128 (140)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0130 (142)  rf=r size=128 type=f alias=V0128+0 align=32 words (r16.0)
//.declare V0131 (143)  rf=r size=128 type=f align=32 words (r82.0)
//.declare P03 (144)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0133 (146)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0134 (147)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0135 (148)  rf=r size=512 type=ub alias=V0116+0 align=32 words (r26.0)
//.declare V0136 (149)  rf=r size=128 type=ud alias=V0134+0 align=32 words (r64.0)
//.declare V0137 (150)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0138 (151)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0139 (152)  rf=r size=128 type=f align=32 words (r44.0)
//.declare V0140 (153)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0141 (154)  rf=r size=128 type=f align=32 words (r84.0)
//.declare V0142 (155)  rf=r size=128 type=f alias=V0140+0 align=32 words (r66.0)
//.declare V0143 (156)  rf=r size=128 type=f align=32 words (r38.0)
//.declare P04 (157)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0145 (159)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0146 (160)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0147 (161)  rf=r size=128 type=ud alias=V0146+0 align=32 words (r8.0)
//.declare V0148 (162)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0149 (163)  rf=r size=128 type=f align=32 words (r68.0)
//.declare V0150 (164)  rf=r size=128 type=f align=32 words (r86.0)
//.declare V0151 (165)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0152 (166)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0153 (167)  rf=r size=128 type=f alias=V0151+0 align=32 words (r6.0)
//.declare V0154 (168)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0155 (169)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0156 (170)  rf=r size=512 type=ud alias=V0116+0 align=32 words (r26.0)
//.declare V0157 (171)  rf=r size=128 type=ud alias=V0155+0 align=32 words (r34.0)
//.declare P05 (172)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0158 (173)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0159 (174)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0160 (175)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0161 (176)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0162 (177)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0163 (178)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0164 (179)  rf=r size=128 type=f alias=V0162+0 align=32 words (r68.0)
//.declare V0165 (180)  rf=r size=128 type=f align=32 words (r66.0)
//.declare P06 (181)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0167 (183)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0168 (184)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0169 (185)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0170 (186)  rf=r size=128 type=f align=32 words (r10.0)
//.declare V0171 (187)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0173 (189)  rf=r size=128 type=f alias=V0171+0 align=32 words (r14.0)
//.declare V0174 (190)  rf=r size=128 type=f align=32 words (r86.0)
//.declare P07 (191)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0176 (193)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0177 (194)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0178 (195)  rf=r size=128 type=ud alias=V0177+0 align=32 words (r24.0)
//.declare V0179 (196)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0180 (197)  rf=r size=128 type=f align=32 words (r24.0)
//.declare V0182 (199)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0183 (200)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0184 (201)  rf=r size=128 type=f alias=V0182+0 align=32 words (r74.0)
//.declare V0185 (202)  rf=r size=128 type=f align=32 words (r24.0)
//.declare P08 (203)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0187 (205)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0188 (206)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0189 (207)  rf=r size=128 type=ud alias=V0188+0 align=32 words (r82.0)
//.declare V0190 (208)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0191 (209)  rf=r size=128 type=f align=32 words (r76.0)
//.declare V0192 (210)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0193 (211)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0194 (212)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0195 (213)  rf=r size=128 type=f alias=V0193+0 align=32 words (r10.0)
//.declare V0196 (214)  rf=r size=128 type=f align=32 words (r40.0)
//.declare V0197 (215)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0198 (216)  rf=r size=128 type=ud alias=V0197+0 align=32 words (r38.0)
//.declare P09 (217)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0199 (218)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0200 (219)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0201 (220)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0202 (221)  rf=r size=128 type=f align=32 words (r28.0)
//.declare V0203 (222)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0204 (223)  rf=r size=128 type=f align=32 words (r42.0)
//.declare V0205 (224)  rf=r size=128 type=f alias=V0203+0 align=32 words (r36.0)
//.declare P10 (225)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0207 (227)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0208 (228)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0209 (229)  rf=r size=128 type=f align=32 words (r82.0)
//.declare V0211 (231)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0213 (233)  rf=r size=128 type=f alias=V0211+0 align=32 words (r18.0)
//.declare V0214 (234)  rf=r size=128 type=f align=32 words (r8.0)
//.declare P11 (235)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0216 (237)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0217 (238)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0218 (239)  rf=r size=128 type=ud alias=V0217+0 align=32 words (r78.0)
//.declare V0219 (240)  rf=r size=128 type=d align=32 words (r86.0)
//.declare V0220 (241)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0221 (242)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0222 (243)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0224 (245)  rf=r size=128 type=f alias=V0222+0 align=32 words (r70.0)
//.declare V0225 (246)  rf=r size=128 type=f align=32 words (r44.0)
//.declare P12 (247)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0227 (249)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0228 (250)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0229 (251)  rf=r size=128 type=ud alias=V0228+0 align=32 words (r14.0)
//.declare V0230 (252)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0231 (253)  rf=r size=128 type=f align=32 words (r72.0)
//.declare V0233 (255)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0234 (256)  rf=r size=128 type=f align=32 words (r64.0)
//.declare V0235 (257)  rf=r size=128 type=f alias=V0233+0 align=32 words (r10.0)
//.declare V0236 (258)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0237 (259)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0238 (260)  rf=r size=128 type=ud alias=V0237+0 align=32 words (r38.0)
//.declare P13 (261)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0239 (262)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0240 (263)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0241 (264)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0242 (265)  rf=r size=128 type=f align=32 words (r66.0)
//.declare V0243 (266)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0244 (267)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0245 (268)  rf=r size=128 type=f alias=V0243+0 align=32 words (r72.0)
//.declare V0246 (269)  rf=r size=128 type=f align=32 words (r68.0)
//.declare P14 (270)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0248 (272)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0249 (273)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0250 (274)  rf=r size=128 type=f align=32 words (r74.0)
//.declare V0251 (275)  rf=r size=128 type=f align=32 words (r20.0)
//.declare V0252 (276)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0253 (277)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0254 (278)  rf=r size=128 type=f alias=V0252+0 align=32 words (r22.0)
//.declare V0255 (279)  rf=r size=128 type=f align=32 words (r12.0)
//.declare P15 (280)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0257 (282)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0258 (283)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0259 (284)  rf=r size=128 type=ud alias=V0258+0 align=32 words (r36.0)
//.declare V0260 (285)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0261 (286)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0262 (287)  rf=r size=128 type=f align=32 words (r72.0)
//.declare V0263 (288)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0264 (289)  rf=r size=128 type=f align=32 words (r14.0)
//.declare V0265 (290)  rf=r size=128 type=f alias=V0263+0 align=32 words (r78.0)
//.declare V0266 (291)  rf=r size=128 type=f align=32 words (r30.0)
//.declare P16 (292)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0268 (294)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0269 (295)  rf=r size=128 type=d align=32 words (r86.0)
//.declare V0270 (296)  rf=r size=128 type=ud alias=V0269+0 align=32 words (r86.0)
//.declare V0271 (297)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0272 (298)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0273 (299)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0274 (300)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0275 (301)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0276 (302)  rf=r size=128 type=f alias=V0274+0 align=32 words (r18.0)
//.declare V0278 (304)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0279 (305)  rf=r size=128 type=ud alias=V0278+0 align=32 words (r42.0)
//.declare P17 (306)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0280 (307)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0281 (308)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0282 (309)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0283 (310)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0284 (311)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0286 (313)  rf=r size=128 type=f alias=V0284+0 align=32 words (r38.0)
//.declare P18 (314)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0287 (315)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0288 (316)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0289 (317)  rf=r size=128 type=f align=32 words (r11.0)
//.declare V0290 (318)  rf=r size=128 type=uw alias=V0288+0 align=32 words (r8.0)
//.declare V0291 (319)  rf=r size=64 type=uw align=32 words (r10.0)
//.declare A00 (320)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P19 (321)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0294 (324)  rf=r size=128 type=f align=32 words (r105.0)
//.declare V0295 (325)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0296 (326)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0297 (327)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0298 (328)  rf=r size=128 type=uw alias=V0296+0 align=32 words (r15.0)
//.declare V0299 (329)  rf=r size=64 type=uw align=32 words (r17.0)
//.declare A01 (330)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P20 (331)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0302 (334)  rf=r size=128 type=f align=32 words (r107.0)
//.declare V0303 (335)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0304 (336)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0305 (337)  rf=r size=128 type=f align=32 words (r25.0)
//.declare V0306 (338)  rf=r size=128 type=uw alias=V0304+0 align=32 words (r22.0)
//.declare V0307 (339)  rf=r size=64 type=uw align=32 words (r24.0)
//.declare A02 (340)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P21 (341)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0310 (344)  rf=r size=128 type=f align=32 words (r109.0)
//.declare V0311 (345)  rf=r size=128 type=d align=32 words (r27.0)
//.declare V0312 (346)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0313 (347)  rf=r size=128 type=f align=32 words (r111.0)
//.declare V0314 (348)  rf=r size=128 type=uw alias=V0312+0 align=32 words (r29.0)
//.declare V0315 (349)  rf=r size=64 type=uw align=32 words (r31.0)
//.declare A03 (350)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P22 (351)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0317 (353)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0319 (355)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0327 (363)  rf=r size=256 type=uq align=32 words (r26.0)
//.declare  (364)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (367)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (368)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (369)  rf=r size=128 type=uw align=32 words (r11.0)
//.declare  (370)  rf=r size=128 type=ud align=32 words (r10.0)
//.declare  (371)  rf=r size=128 type=ud align=32 words (r12.0)
//.declare  (372)  rf=r size=2 type=w align=1 words (r12.0)
//.declare  (375)  rf=r size=2 type=w align=1 words (r13.0)
//.declare  (388)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare  (389)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (390)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (391)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (396)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (397)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (398)  rf=r size=128 type=q align=32 words (r113.0)
//.declare  (399)  rf=r size=128 type=q align=32 words (r115.0)
//.declare  (402)  rf=r size=128 type=q align=32 words (r117.0)
//.declare  (403)  rf=r size=128 type=q align=32 words (r119.0)
//.declare  (404)  rf=r size=128 type=q align=32 words (r121.0)
//.declare  (405)  rf=r size=128 type=q align=32 words (r123.0)
//.declare  (414)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (415)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (416)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (417)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (418)  rf=r size=128 type=d align=32 words (r14.0)
//.declare  (419)  rf=r size=128 type=d align=32 words (r16.0)
//.declare  (420)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (421)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (422)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (423)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (426)  rf=r size=128 type=uq alias=+0 align=32 words (r113.0)
//.declare  (427)  rf=r size=128 type=uq alias=+0 align=32 words (r9.0)
//.declare  (428)  rf=r size=128 type=uq alias=+0 align=32 words (r115.0)
//.declare  (429)  rf=r size=128 type=uq alias=+0 align=32 words (r13.0)
//.declare  (430)  rf=r size=128 type=d alias=+0 align=32 words (r113.0)
//.declare  (431)  rf=r size=128 type=d alias=+0 align=32 words (r115.0)
//.declare  (432)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (433)  rf=r size=128 type=d alias=+0 align=32 words (r10.0)
//.declare  (434)  rf=r size=128 type=d alias=+0 align=32 words (r18.0)
//.declare  (435)  rf=r size=128 type=d alias=+0 align=32 words (r20.0)
//.declare r0 (436)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (437)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (438)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (439)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (440)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (441)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (442)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0042    | :q       |    0x8 | r2+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0045    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0050    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0051    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0052    | :q       |    0x8 | r4       | cti+0x60         |
// | V0053    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0054    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0055    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0056    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0057    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0058    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0059    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0060    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0061    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0062    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0063    | :d       |    0x4 | r5+0x18  | cti+0xB8         |
// | V0064    | :d       |    0x4 | r5+0x1C  | cti+0xBC         |
// | V0065    | :d       |    0x4 | r5+0x20  | cti+0xC0         |
// | V0066    | :d       |    0x4 | r5+0x24  | cti+0xC4         |
// | V0067    | :d       |    0x4 | r5+0x28  | cti+0xC8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B004}
// _main:
(W)     mov (16|M0)              r88.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r88.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r4.0<1>:ud    r2.0<0;1,0>:ud    r88.1<0;1,0>:ud  {Compacted,$1.dst} //  ALU pipe: int; $3
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r88.2<0;1,0>:uw                     //  ALU pipe: int; $3
(W)     mach (1|M0)              r6.0<1>:d     r2.0<0;1,0>:ud    r88.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $9
        mov (16|M16)             r11.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $9
        sync.nop                             null                             {Compacted,I@5}        // $3
(W)     mov (1|M0)               r5.0<2>:f     r4.0<0;1,0>:f                    {$2.dst}             //  ALU pipe: float; $3
(W)     mov (1|M0)               r5.1<2>:d     r6.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $7
(W)     mov (8|M0)               r15.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $12
        add (16|M0)              r9.0<1>:q     r5.0<0;1,0>:q     r7.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $9
        add (16|M16)             r13.0<1>:q    r5.0<0;1,0>:q     r11.0<4;1,0>:uw                     //  ALU pipe: int; $9
(W)     add (8|M0)               r15.8<1>:w    r15.0<1;1,0>:w    8:w               {I@3}             //  ALU pipe: int; $13
        shr (16|M0)              r113.0<1>:uq  r9.0<1;1,0>:uq    4:w               {I@3}             //  ALU pipe: int; $10
        shr (16|M16)             r115.0<1>:uq  r13.0<1;1,0>:uq   4:w               {I@3}             //  ALU pipe: int; $10
(W)     add (16|M0)              r15.16<1>:w   r15.0<1;1,0>:w    16:w               {I@3}            //  ALU pipe: int; $14
        mov (16|M0)              r89.0<1>:d    r113.0<2;1,0>:d                  {Compacted,I@3}      //  ALU pipe: int; $11
        mov (16|M16)             r90.0<1>:d    r115.0<2;1,0>:d                  {Compacted,I@3}      //  ALU pipe: int; $11
        mov (32|M0)              r91.0<1>:d    r15.0<1;1,0>:uw                  {I@3}                //  ALU pipe: int; $15
        and (32|M0)              r16.0<1>:d    r89.0<1;1,0>:d    3:w               {Compacted,I@2}   //  ALU pipe: int; $17
        and (32|M0)              r93.0<1>:d    r91.0<1;1,0>:d    15:w               {Compacted,I@2}  //  ALU pipe: int; $16
        mul (32|M0)              r18.0<1>:d    r16.0<1;1,0>:d    1536:w               {Compacted,I@2} //  ALU pipe: int; $18
        shl (32|M0)              r20.0<1>:d    r93.0<1;1,0>:d    4:w               {Compacted,I@2}   //  ALU pipe: int; $20
        add (32|M0)              r95.0<1>:d    r18.0<1;1,0>:d    1536:w               {Compacted,I@2} //  ALU pipe: int; $19
        or (32|M0)               r97.0<1>:d    r20.0<1;1,0>:d    r18.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $21
        cmp (32|M0)   (lt)f1.0   null<1>:ud    r97.0<1;1,0>:ud   r95.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $22
(f1.0)  goto (32|M0)                         _0_010            _0_010                                //  ALU pipe: int; $23
// B003: [inDivergent],  Preds:{B002},  Succs:{B007}
_0_011:
        mov (32|M0)              r99.0<1>:ud   0x0:ud                              {Compacted}       //  ALU pipe: int; $25
        goto (32|M0)                         _0_010            _0_012                                // $26
// B004: [inDivergent],  Preds:{B002},  Succs:{B005}
_0_010:
        join (32|M0)                         _0_012                                                  // 
L624:
        shr (32|M0)              r6.0<1>:ud    r89.0<1;1,0>:ud   2:w                                 //  ALU pipe: int; $28
(W)     mul (16|M0)              acc0.0<1>:d   r6.0<1;1,0>:d     r5.12<0;1,0>:uw  {I@1}              //  ALU pipe: int; $29
        macl (16|M0)             r8.0<1>:d     r6.0<1;1,0>:d     r5.6<0;1,0>:d    {Compacted}        //  ALU pipe: int; $29
(W)     mul (16|M16)             acc0.0<1>:d   r7.0<1;1,0>:d     r5.12<0;1,0>:uw                     //  ALU pipe: int; $29
        macl (16|M16)            r9.0<1>:d     r7.0<1;1,0>:d     r5.6<0;1,0>:d    {Compacted}        //  ALU pipe: int; $31
        mov (16|M0)              r10.0<2>:ud   r8.0<1;1,0>:ud                   {Compacted,I@3}      //  ALU pipe: int; $31
        mov (16|M16)             r12.0<2>:ud   r9.0<1;1,0>:ud                   {Compacted,I@2}      //  ALU pipe: int; $31
        mov (32|M0)              r101.0<1>:f   0x0:f                               {Compacted}       //  ALU pipe: float; $34
        mov (32|M0)              r103.0<1>:f   0x0:f                               {Compacted}       //  ALU pipe: float; $35
        add (16|M0)              r117.0<1>:q   r10.0<2;1,0>:ud   r2.2<0;1,0>:q    {I@2}              //  ALU pipe: int; $31
        add (16|M16)             r119.0<1>:q   r12.0<2;1,0>:ud   r2.2<0;1,0>:q    {I@2}              //  ALU pipe: int; $31
        add (16|M0)              r121.0<1>:q   r117.0<1;1,0>:q   6144:w               {I@2}          //  ALU pipe: int; $32
        add (16|M16)             r123.0<1>:q   r119.0<1;1,0>:q   6144:w               {I@2}          //  ALU pipe: int; $32
(W)     mov (1|M0)               r2.3<1>:d     255:w                                                 //  ALU pipe: int; $33
// B005: [inDivergent],  Preds:{B005, B004},  Succs:{B006, B005}
_0_013:
        mov (16|M0)              r6.0<2>:ud    r97.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $43
        mov (16|M16)             r8.0<2>:ud    r98.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $43
        add (16|M0)              r14.0<1>:q    r117.0<1;1,0>:q   r6.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $43
        add (16|M16)             r16.0<1>:q    r119.0<1;1,0>:q   r8.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $43
        load.ugm.d32x4.a64 (32|M0)  r26:8       [r14:4]            {I@1,$3} // ex_desc:0x0; desc:0x8803580 // $45
        shr (32|M0)              r10.0<1>:ud   r97.0<1;1,0>:ud   2:w                                 //  ALU pipe: int; $37
        shl (16|M0)              r18.0<1>:q    r6.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $46
        shl (16|M16)             r20.0<1>:q    r8.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $46
        mov (16|M0)              r22.0<2>:ud   r10.0<1;1,0>:ud                  {Compacted,I@3}      //  ALU pipe: int; $39
        mov (16|M16)             r24.0<2>:ud   r11.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $39
        add (16|M0)              r34.0<1>:q    r18.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $47
        add (16|M16)             r36.0<1>:q    r20.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $47
        add (16|M0)              r38.0<1>:q    r121.0<1;1,0>:q   r22.0<2;1,0>:ud  {I@4}              //  ALU pipe: int; $39
        add (16|M16)             r40.0<1>:q    r123.0<1;1,0>:q   r24.0<2;1,0>:ud  {I@4}              //  ALU pipe: int; $39
        mov (16|M0)              r42.0<1>:uq   r34.0<1;1,0>:uq                  {Compacted,I@4}      //  ALU pipe: int; $48
        mov (16|M16)             r44.0<1>:uq   r36.0<1;1,0>:uq                  {Compacted,I@4}      //  ALU pipe: int; $48
        load.ugm.d32.a64 (32|M0)  r54:2         [r38:4]            {I@3,$4} // ex_desc:0x0; desc:0x8200580 // $41
        load.ugm.d32x4.a64 (32|M0)  r56:8       [r42:4]            {I@1,$5} // ex_desc:0x0; desc:0x8803580 // $49
        load.ugm.d32x4.a64 (32|M0)  r46:8       [r34:4+0x10]       {$6} // ex_desc:0x10000; desc:0x8803580 // $50
(W)     mov (1|M0)               r12.0<1>:hf   0x0:hf                                                //  ALU pipe: float; $53
(W)     mov (1|M0)               r13.0<1>:hf   0xFF00:hf                                             //  ALU pipe: float; $82
        add (32|M0)              r97.0<1>:d    r97.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $203
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r97.0<1;1,0>:ud   r95.0<1;1,0>:ud  {I@1}              //  ALU pipe: int; $204
        and (32|M0)   (eq)f3.0   null<1>:d     r26.0<1;1,0>:d    128:w               {$3.dst}        //  ALU pipe: int; $51
        and (32|M0)   (eq)f1.0   null<1>:d     r30.0<1;1,0>:d    128:w                               //  ALU pipe: int; $127
        and (32|M0)   (eq)f2.0   null<1>:d     r26.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $60
(f3.0)  sel (32|M0)              r66.0<1>:d    r12.0<0;1,0>:w    -256:w               {F@2}          //  ALU pipe: int; $53
(f1.0)  sel (32|M0)              r68.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $129
        and (32|M0)   (eq)f3.0   null<1>:d     r30.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $136
        and (32|M0)   (eq)f1.0   null<1>:d     r26.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $70
(f2.0)  sel (32|M0)              r74.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $62
        bfn.(s0&s1|s2) (32|M0)   r70.0<1>:ud   r26.0<1;0>:ud     r2.3<0;0>:ud      r66.0<1>:ud      {I@5} //  ALU pipe: int; $54 R{} IR{}{E:5,E:1,E:1,},  R{r2,} IR{}{O:13,O:1,},  {BC=1}
        bfn.(s0&s1|s2) (32|M0)   r72.0<1>:ud   r30.0<1;0>:ud     r2.3<0;0>:ud      r68.0<1>:ud      {I@5} //  ALU pipe: int; $130
        and (32|M0)   (eq)f2.0   null<1>:d     r30.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $146
(f3.0)  sel (32|M0)              r76.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $138
        mov (32|M0)              r80.0<1>:f    r70.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $55
        mov (32|M0)              r64.0<1>:ud   r26.1<4;1,0>:ub                                       //  ALU pipe: int; $63
        mov (32|M0)              r78.0<1>:ud   r30.1<4;1,0>:ub                                       //  ALU pipe: int; $139
(f1.0)  sel (32|M0)              r6.0<1>:d     r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $72
        mov (32|M0)              r82.0<1>:f    r72.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $131
        cmp (32|M0)   (lt)f3.0   null<1>:d     r26.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $81
        shl (32|M0)              r16.0<1>:d    r56.0<1;1,0>:d    16:w               {Compacted,$5.dst} //  ALU pipe: int; $57
        mul (32|M0)              acc0.0<1>:f   r54.0<1;1,0>:f    r80.0<1;1,0>:f   {Compacted,@2,$4.dst} //  ALU pipe: float; $56
        cmp (32|M0)   (lt)f1.0   null<1>:d     r30.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $157
(f2.0)  sel (32|M0)              r10.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $148
        or (32|M0)               r84.0<1>:d    r64.0<1;1,0>:d    r74.0<1;1,0>:d   {Compacted,I@7}    //  ALU pipe: int; $64
        or (32|M0)               r86.0<1>:d    r78.0<1;1,0>:d    r76.0<1;1,0>:d   {Compacted,I@7}    //  ALU pipe: int; $140
        mul (32|M0)              acc2.0<1>:f   r54.0<1;1,0>:f    r82.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $132
        mov (32|M0)              r8.0<1>:ud    r26.2<4;1,0>:ub                                       //  ALU pipe: int; $73
        shl (32|M0)              r18.0<1>:d    r46.0<1;1,0>:d    16:w               {Compacted,$6.dst} //  ALU pipe: int; $133
        and (32|M0)   (eq)f2.0   null<1>:d     r28.0<1;1,0>:d    128:w                               //  ALU pipe: int; $89
        mov (32|M0)              r14.0<1>:ud   r30.2<4;1,0>:ub                                       //  ALU pipe: int; $149
(f3.0)  sel (32|M0)              r40.0<1>:d    r13.0<0;1,0>:w    0:w                                 //  ALU pipe: int; $82
        mov (32|M0)              r20.0<1>:f    r84.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $65
        mov (32|M0)              r22.0<1>:f    r86.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $141
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r16.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $58
        shr (32|M0)              r34.0<1>:ud   r26.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $80
        shr (32|M0)              r38.0<1>:ud   r30.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $156
(f1.0)  sel (32|M0)              r42.0<1>:d    r13.0<0;1,0>:w    0:w                                 //  ALU pipe: int; $158
        or (32|M0)               r24.0<1>:d    r8.0<1;1,0>:d     r6.0<1;1,0>:d    {Compacted,I@7}    //  ALU pipe: int; $74
        and (32|M0)   (eq)f3.0   null<1>:d     r32.0<1;1,0>:d    128:w                               //  ALU pipe: int; $165
        or (32|M0)               r36.0<1>:d    r14.0<1;1,0>:d    r10.0<1;1,0>:d   {Compacted,I@7}    //  ALU pipe: int; $150
        mul (32|M0)              r44.0<1>:f    r54.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $66
        mul (32|M0)              r64.0<1>:f    r54.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $142 R{} IR{}{E:3,E:3,},  R{} IR{}{O:11,O:11,},  {BC=2}
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r18.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $134
        and (32|M0)   (eq)f1.0   null<1>:d     r28.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $98
        and (32|M0)              r66.0<1>:d    r56.0<1;1,0>:d    -65536:d                            //  ALU pipe: int; $67
        and (32|M0)              r70.0<1>:d    r46.0<1;1,0>:d    -65536:d                            //  ALU pipe: int; $143
(f2.0)  sel (32|M0)              r78.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $91
        mov (32|M0)              r68.0<1>:f    r24.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $75
        or (32|M0)               r74.0<1>:d    r34.0<1;1,0>:d    r40.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $83
        or (32|M0)               r76.0<1>:d    r38.0<1;1,0>:d    r42.0<1;1,0>:d   {Compacted}        //  ALU pipe: int; $159
        mov (32|M0)              r72.0<1>:f    r36.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $151
        add (32|M0)              r82.0<1>:f    r103.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $59
        add (32|M0)              r8.0<1>:f     r101.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $135
        and (32|M0)   (eq)f2.0   null<1>:d     r32.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $174
        shl (32|M0)              r6.0<1>:d     r58.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $77
(f3.0)  sel (32|M0)              r80.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $167
        shl (32|M0)              r10.0<1>:d    r48.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $153
        mul (32|M0)              r84.0<1>:f    r44.0<1;1,0>:f    r66.0<1;1,0>:f   {Compacted,A@7}    //  ALU pipe: float; $68
        mul (32|M0)              r86.0<1>:f    r54.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $76
        mul (32|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r70.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $144
(f1.0)  sel (32|M0)              r22.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $100
        mov (32|M0)              r14.0<1>:f    r74.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $84
        mov (32|M0)              r16.0<1>:f    r76.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $160
        and (32|M0)   (eq)f3.0   null<1>:d     r28.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $108
        mul (32|M0)              acc2.0<1>:f   r54.0<1;1,0>:f    r72.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $152
        bfn.(s0&s1|s2) (32|M0)   r18.0<1>:ud   r28.0<1;0>:ud     r2.3<0;0>:ud      r78.0<1>:ud       //  ALU pipe: int; $92 R{} IR{}{E:6,E:1,E:7,},  R{r2,} IR{}{O:14,O:7,},  {BC=1}
        bfn.(s0&s1|s2) (32|M0)   r20.0<1>:ud   r32.0<1;0>:ud     r2.3<0;0>:ud      r80.0<1>:ud      {I@5} //  ALU pipe: int; $168 R{r2,} IR{}{E:0,E:0,},  R{r2,} IR{}{O:0,O:8,},  {BC=1}
        and (32|M0)   (eq)f1.0   null<1>:d     r32.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $184
        mov (32|M0)              r24.0<1>:ud   r28.1<4;1,0>:ub                                       //  ALU pipe: int; $101
        mov (32|M0)              r36.0<1>:ud   r32.1<4;1,0>:ub                                       //  ALU pipe: int; $177
(f2.0)  sel (32|M0)              r34.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $176
        add (32|M0)              r38.0<1>:f    r82.0<1;1,0>:f    r84.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $69
        mul (32|M0)              r40.0<1>:f    r86.0<1;1,0>:f    r6.0<1;1,0>:f    {Compacted,F@6}    //  ALU pipe: float; $78 R{} IR{}{E:3,E:3,},  R{} IR{}{O:11,O:3,},  {BC=1}
        mul (32|M0)              r42.0<1>:f    r54.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $85
        mul (32|M0)              r66.0<1>:f    r54.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $161
        add (32|M0)              r44.0<1>:f    r8.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $145
        mul (32|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   r10.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $154
        and (32|M0)              r68.0<1>:d    r58.0<1;1,0>:d    -65536:d                            //  ALU pipe: int; $86
        and (32|M0)              r72.0<1>:d    r48.0<1;1,0>:d    -65536:d               {F@7}        //  ALU pipe: int; $162
        mov (32|M0)              r70.0<1>:f    r18.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $93
        mov (32|M0)              r74.0<1>:f    r20.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $169
(f3.0)  sel (32|M0)              r80.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $110
        or (32|M0)               r76.0<1>:d    r24.0<1;1,0>:d    r22.0<1;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $102
        cmp (32|M0)   (lt)f2.0   null<1>:d     r28.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $119
        or (32|M0)               r78.0<1>:d    r36.0<1;1,0>:d    r34.0<1;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $178
        mov (32|M0)              r82.0<1>:ud   r28.2<4;1,0>:ub                  {F@7}                //  ALU pipe: int; $111
(f1.0)  sel (32|M0)              r84.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $186
        mov (32|M0)              r86.0<1>:ud   r32.2<4;1,0>:ub                  {F@7}                //  ALU pipe: int; $187
        add (32|M0)              r6.0<1>:f     r38.0<1;1,0>:f    r40.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $79
        shl (32|M0)              r14.0<1>:d    r60.0<1;1,0>:d    16:w               {Compacted,F@7}  //  ALU pipe: int; $95
        add (32|M0)              r16.0<1>:f    r44.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $155
        mul (32|M0)              r8.0<1>:f     r42.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $87
        mul (32|M0)              r10.0<1>:f    r54.0<1;1,0>:f    r70.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $94 R{} IR{}{E:3,E:3,},  R{} IR{}{O:11,O:3,},  {BC=1}
        mul (32|M0)              r18.0<1>:f    r66.0<1;1,0>:f    r72.0<1;1,0>:f   {Compacted,I@7}    //  ALU pipe: float; $163
        mul (32|M0)              r20.0<1>:f    r54.0<1;1,0>:f    r74.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $170
        cmp (32|M0)   (lt)f3.0   null<1>:d     r32.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $195
        shl (32|M0)              r22.0<1>:d    r50.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $171
        mov (32|M0)              r34.0<1>:f    r78.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $179
        mov (32|M0)              r24.0<1>:f    r76.0<1;1,0>:d                                        //  ALU pipe: float; $103
        or (32|M0)               r36.0<1>:d    r82.0<1;1,0>:d    r80.0<1;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $112
        shr (32|M0)              r38.0<1>:ud   r28.0<1;1,0>:ud   24:w               {F@7}            //  ALU pipe: int; $118
        or (32|M0)               r40.0<1>:d    r86.0<1;1,0>:d    r84.0<1;1,0>:d   {Compacted,I@6}    //  ALU pipe: int; $188
(f2.0)  sel (32|M0)              r44.0<1>:d    r13.0<0;1,0>:w    0:w               {F@7}             //  ALU pipe: int; $120
        shr (32|M0)              r42.0<1>:ud   r32.0<1;1,0>:ud   24:w               {F@6}            //  ALU pipe: int; $194
        mul (32|M0)              acc2.0<1>:f   r10.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted,A@5}    //  ALU pipe: float; $96
        add (32|M0)              r66.0<1>:f    r6.0<1;1,0>:f     r8.0<1;1,0>:f    {Compacted}        //  ALU pipe: float; $88
        add (32|M0)              r68.0<1>:f    r16.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $164
        mul (32|M0)              r70.0<1>:f    r20.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted,A@6}    //  ALU pipe: float; $172
        mul (32|M0)              r72.0<1>:f    r54.0<1;1,0>:f    r34.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $180
        and (32|M0)              r74.0<1>:d    r60.0<1;1,0>:d    -65536:d                            //  ALU pipe: int; $105
(f3.0)  sel (32|M0)              r64.0<1>:d    r13.0<0;1,0>:w    0:w                                 //  ALU pipe: int; $196
        and (32|M0)              r78.0<1>:d    r50.0<1;1,0>:d    -65536:d                            //  ALU pipe: int; $181
        mov (32|M0)              r76.0<1>:f    r36.0<1;1,0>:d                   {I@7}                //  ALU pipe: float; $113
        mov (32|M0)              r80.0<1>:f    r40.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $189
        mul (32|M0)              acc0.0<1>:f   r54.0<1;1,0>:f    r24.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $104
        or (32|M0)               r82.0<1>:d    r38.0<1;1,0>:d    r44.0<1;1,0>:d   {Compacted,I@5}    //  ALU pipe: int; $121
        shl (32|M0)              r10.0<1>:d    r62.0<1;1,0>:d    16:w               {Compacted,F@7}  //  ALU pipe: int; $115
        shl (32|M0)              r18.0<1>:d    r52.0<1;1,0>:d    16:w               {Compacted,F@6}  //  ALU pipe: int; $191
        or (32|M0)               r84.0<1>:d    r42.0<1;1,0>:d    r64.0<1;1,0>:d   {Compacted,I@5}    //  ALU pipe: int; $197
        add (32|M0)              r12.0<1>:f    r68.0<1;1,0>:f    r70.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $173
        mul (32|M0)              r14.0<1>:f    r72.0<1;1,0>:f    r78.0<1;1,0>:f   {Compacted,A@5}    //  ALU pipe: float; $182
        mul (32|M0)              r8.0<1>:f     r54.0<1;1,0>:f    r76.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $114
        mul (32|M0)              r16.0<1>:f    r54.0<1;1,0>:f    r80.0<1;1,0>:f   {Compacted,F@5}    //  ALU pipe: float; $190
        add (32|M0)              r86.0<1>:f    r66.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $97
        mul (32|M0)              r6.0<1>:f     acc0.0<1;1,0>:f   r74.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $106
        mov (32|M0)              r20.0<1>:f    r82.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $122
        mov (32|M0)              r22.0<1>:f    r84.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $198
        add (32|M0)              r30.0<1>:f    r12.0<1;1,0>:f    r14.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $183
        mul (32|M0)              r26.0<1>:f    r8.0<1;1,0>:f     r10.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $116
        mul (32|M0)              r32.0<1>:f    r16.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $192
        add (32|M0)              r24.0<1>:f    r86.0<1;1,0>:f    r6.0<1;1,0>:f    {Compacted,F@6}    //  ALU pipe: float; $107 R{} IR{}{E:3,E:3,},  R{} IR{}{O:11,O:3,},  {BC=1}
        mul (32|M0)              r28.0<1>:f    r54.0<1;1,0>:f    r20.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $123
        and (32|M0)              r36.0<1>:d    r62.0<1;1,0>:d    -65536:d                            //  ALU pipe: int; $124
        mul (32|M0)              r34.0<1>:f    r54.0<1;1,0>:f    r22.0<1;1,0>:f   {Compacted,F@6}    //  ALU pipe: float; $199 R{} IR{}{E:3,E:3,},  R{} IR{}{O:11,O:11,},  {BC=2}
        and (32|M0)              r38.0<1>:d    r52.0<1;1,0>:d    -65536:d                            //  ALU pipe: int; $200
        add (32|M0)              acc0.0<1>:f   r30.0<1;1,0>:f    r32.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $193
        add (32|M0)              r40.0<1>:f    r24.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $117
        mul (32|M0)              r42.0<1>:f    r28.0<1;1,0>:f    r36.0<1;1,0>:f   {Compacted,A@2}    //  ALU pipe: float; $125
        mul (32|M0)              acc2.0<1>:f   r34.0<1;1,0>:f    r38.0<1;1,0>:f   {Compacted,A@1}    //  ALU pipe: float; $201
        add (32|M0)              r103.0<1>:f   r40.0<1;1,0>:f    r42.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $126
        add (32|M0)              r101.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $202
(f0.0)  goto.b (32|M0)                       _0_014            _0_013                                //  ALU pipe: int; $205
// B006: [inDivergent],  Preds:{B005},  Succs:{B007}
_0_014:
        join (32|M0)                         _0_012                                                  // 
L2824:
        add (32|M0)              r99.0<1>:f    r103.0<1;1,0>:f   r101.0<1;1,0>:f  {Compacted,F@1}    //  ALU pipe: float; $207
// B007: Preds:{B006, B003},  Succs:{B008, B009}
_0_012:
        join (32|M0)                         L2848                                                   // 
L2848:
        add (32|M0)              r6.0<1>:d     r91.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $209
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $210
        shl (32|M0)              r10.0<1>:uw   r8.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $211
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $212
        add (16|M0)              a0.0<1>:uw    r10.0<1;1,0>:uw   0x18C0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0093(r99.0:f); $213
        add (32|M0)              r13.0<1>:d    r91.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $222
        mov (16|M0)              r11.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $214
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $215
        add (16|M16)             a0.0<1>:uw    r10.16<1;1,0>:uw  0x18C0:uw                           //  ALU pipe: int; src1 is addr of V0093(r99.0:f); $216
        and (32|M0)   (eq)f0.0   null<1>:d     r91.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $218
        and (32|M0)              r15.0<1>:d    r13.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $223
        mov (16|M16)             r12.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $217
        shl (32|M0)              r17.0<1>:uw   r15.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $224
(f0.0)  sel (32|M0)              acc0.0<1>:f   r11.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $220
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $225
        add (16|M0)              a0.0<1>:uw    r17.0<1;1,0>:uw   0x1A40:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0294(r105.0:f); $226
        add (32|M0)              r105.0<1>:f   r99.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $221
        add (32|M0)              r20.0<1>:d    r91.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $235
        mov (16|M0)              r18.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $227
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $228
        add (16|M16)             a0.0<1>:uw    r17.16<1;1,0>:uw  0x1A40:uw                           //  ALU pipe: int; src1 is addr of V0294(r105.0:f); $229
        and (32|M0)   (eq)f3.0   null<1>:d     r91.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $231
        and (32|M0)              r22.0<1>:d    r20.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $236
        mov (16|M16)             r19.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $230
        shl (32|M0)              r24.0<1>:uw   r22.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $237
(f3.0)  sel (32|M0)              acc0.0<1>:f   r18.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $233
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $238
        add (16|M0)              a0.0<1>:uw    r24.0<1;1,0>:uw   0x1AC0:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0302(r107.0:f); $239
        add (32|M0)              r107.0<1>:f   r105.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $234
        add (32|M0)              r27.0<1>:d    r91.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $248
        mov (16|M0)              r25.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $240
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $241
        add (16|M16)             a0.0<1>:uw    r24.16<1;1,0>:uw  0x1AC0:uw                           //  ALU pipe: int; src1 is addr of V0302(r107.0:f); $242
        and (32|M0)   (eq)f2.0   null<1>:d     r91.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $244
        and (32|M0)              r29.0<1>:d    r27.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $249
        mov (16|M16)             r26.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $243
        shl (32|M0)              r31.0<1>:uw   r29.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $250
(f2.0)  sel (32|M0)              acc0.0<1>:f   r25.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $246
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $251
        add (16|M0)              a0.0<1>:uw    r31.0<1;1,0>:uw   0x1B40:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0310(r109.0:f); $252
        add (32|M0)              r109.0<1>:f   r107.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $247
        cmp (32|M0)   (eq)f0.0   null<1>:d     r93.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $257
        mov (16|M0)              r111.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $253
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $254
        add (16|M16)             a0.0<1>:uw    r31.16<1;1,0>:uw  0x1B40:uw                           //  ALU pipe: int; src1 is addr of V0310(r109.0:f); $255
        mov (16|M16)             r112.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $256
(~f0.0) goto (32|M0)                         _0_015            _0_015                                //  ALU pipe: int; $258
// B008: [inDivergent],  Preds:{B007},  Succs:{B009}
_0_016:
        shl (16|M0)              r8.0<1>:q     r113.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $262
        shl (16|M16)             r10.0<1>:q    r115.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $262
        and (16|M0)              r12.0<1>:d    r8.0<2;1,0>:d     536870896:d               {I@2}     //  ALU pipe: int; $263
        and (16|M16)             r13.0<1>:d    r10.0<2;1,0>:d    536870896:d               {I@2}     //  ALU pipe: int; $264
        mov (32|M0)              r16.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $266
        mov (32|M0)              r14.0<1>:d    r12.0<1;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $265
        mov (16|M0)              r18.0<2>:d    r14.0<1;1,0>:d                   {I@1}                //  ALU pipe: int; $267
        mov (16|M16)             r20.0<2>:d    r15.0<1;1,0>:d                                        //  ALU pipe: int; $268
        mov (16|M0)              r18.1<2>:d    r16.0<1;1,0>:d                                        //  ALU pipe: int; $269
        mov (16|M16)             r20.1<2>:d    r17.0<1;1,0>:d                                        //  ALU pipe: int; $270
(f0.0)  sel (32|M0)              acc0.0<1>:f   r111.0<1;1,0>:f   0x80000000:f                        //  ALU pipe: float; $260
        add (16|M0)              r22.0<1>:q    r18.0<1;1,0>:q    r4.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $271
        add (16|M16)             r24.0<1>:q    r20.0<1;1,0>:q    r4.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $271
        add (32|M0)              r6.0<1>:f     r109.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $261
        add (16|M0)              r26.0<1>:q    r22.0<1;1,0>:q    r8.0<1;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $272
        add (16|M16)             r28.0<1>:q    r24.0<1;1,0>:q    r10.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $272
        store.ugm.d32.a64 (32|M0)  [r26:4]      r6:2               {A@1,$7} // ex_desc:0x0; desc:0x8000584 // $274
// B009: Preds:{B008, B007},  Succs:{}
_0_015:
        join (32|M0)                         L3728                                                   // 
L3728:
(W)     mov (16|M0)              r127.0<1>:f   r88.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $276
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$8} // wr:1+0, rd:0; end of thread // $276
L3752:
(W)     mov (16|M0)              null<1>:ud    0x1038AC5D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x659BDD31:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x1:ud                                                // 


//.BankConflicts: 10
//.ByteRMWs: 0
//


//.numALUInst: 280
//.accSubDef: 14
//.accSubUse: 14
//.accSubCandidateDef: 50
//.accSubCandidateUse: 50
//
//
//.singlePipeAtOneDistNum: 20
//.allAtOneDistNum: 6
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 7
//.AfterReadTokenDepCount: 1
