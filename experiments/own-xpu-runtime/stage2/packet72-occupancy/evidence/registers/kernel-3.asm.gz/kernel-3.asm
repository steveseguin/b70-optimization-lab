//.kernel _ZTSZZNK4p49c11DenseKernelILN3iq34TypeE8ELj320ELj1ELN3p394KindE7ELj0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS7_5eventESaISF_EEENKUlRNS7_7handlerEE_clESL_EUlNS7_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 272149597 1704713521 -hashmovs1 0 3 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 272149597 1704713521 -hashmovs1 0 3 -GRFBumpUpNumber 2 "
//.instCount 352
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r93.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.11)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.12)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.13)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r93.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r93.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0063 (73)  rf=r size=4 type=d align=2 words (r5.6)
//.declare V0064 (74)  rf=r size=4 type=d align=2 words (r5.7)
//.declare V0065 (75)  rf=r size=4 type=d align=2 words (r5.8)
//.declare V0066 (76)  rf=r size=4 type=d align=2 words (r5.9)
//.declare V0067 (77)  rf=r size=4 type=d align=2 words (r5.10)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0069 (79)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r2.0)
//.declare V0070 (80)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r93.0)
//.declare V0071 (81)  rf=r size=8 type=ud alias=V0068+0 align=4 words (r5.0)
//.declare V0072 (82)  rf=r size=8 type=d alias=V0068+0 align=4 words (r5.0)
//.declare V0073 (83)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0076 (86)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0081 (91)  rf=r size=128 type=d align=32 words (r15.0)
//.declare P01 (92)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0082 (93)  rf=r size=128 type=ud alias=V0081+0 align=32 words (r15.0)
//.declare V0083 (94)  rf=r size=4 type=ud alias=V0064+0 align=2 words (r5.7)
//.declare V0086 (97)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0087 (98)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0088 (99)  rf=r size=64 type=w align=32 words (r94.0)
//.declare V0090 (101)  rf=r size=128 type=ud alias=V0086+0 align=32 words (r6.0)
//.declare V0091 (102)  rf=r size=4 type=ud alias=V0063+0 align=2 words (r5.6)
//.declare V0094 (105)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0095 (106)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0097 (108)  rf=r size=128 type=d align=32 words (r95.0)
//.declare V0098 (109)  rf=r size=64 type=uw alias=V0088+0 align=32 words (r94.0)
//.declare V0099 (110)  rf=r size=128 type=d align=32 words (r97.0)
//.declare V0102 (113)  rf=r size=128 type=ud alias=V0099+0 align=32 words (r97.0)
//.declare V0104 (115)  rf=r size=256 type=q align=32 words (r36.0)
//.declare V0105 (116)  rf=r size=256 type=uq alias=V0104+0 align=32 words (r36.0)
//.declare V0106 (117)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0107 (118)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0108 (119)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0109 (120)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0111 (122)  rf=r size=128 type=w alias=V0106+0 align=32 words (r40.0)
//.declare V0115 (126)  rf=r size=128 type=w alias=V0107+0 align=32 words (r42.0)
//.declare V0119 (130)  rf=r size=128 type=w alias=V0108+0 align=32 words (r48.0)
//.declare V0123 (134)  rf=r size=128 type=w alias=V0109+0 align=32 words (r50.0)
//.declare V0126 (137)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0128 (139)  rf=r size=128 type=ud alias=V0126+0 align=32 words (r20.0)
//.declare V0131 (142)  rf=r size=256 type=uq align=32 words (r52.0)
//.declare V0132 (143)  rf=r size=128 type=f align=32 words (r60.0)
//.declare V0135 (146)  rf=r size=256 type=uq align=32 words (r44.0)
//.declare V0136 (147)  rf=r size=256 type=d align=32 words (r56.0)
//.declare P02 (148)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0138 (150)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0139 (151)  rf=r size=128 type=d align=32 words (r86.0)
//.declare V0140 (152)  rf=r size=4 type=d align=2 words (r99.0)
//.declare V0141 (153)  rf=r size=128 type=f align=32 words (r1.0)
//.declare V0143 (155)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0145 (157)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0147 (159)  rf=r size=128 type=f alias=V0145+0 align=32 words (r68.0)
//.declare V0148 (160)  rf=r size=128 type=f align=32 words (r24.0)
//.declare P03 (161)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0150 (163)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0151 (164)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0152 (165)  rf=r size=256 type=ub alias=V0136+0 align=32 words (r56.0)
//.declare V0153 (166)  rf=r size=128 type=ud alias=V0151+0 align=32 words (r80.0)
//.declare V0154 (167)  rf=r size=128 type=d align=32 words (r88.0)
//.declare V0155 (168)  rf=r size=128 type=f align=32 words (r7.0)
//.declare V0157 (170)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0159 (172)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0161 (174)  rf=r size=128 type=f alias=V0159+0 align=32 words (r70.0)
//.declare V0162 (175)  rf=r size=128 type=f align=32 words (r34.0)
//.declare P04 (176)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0164 (178)  rf=r size=128 type=d align=32 words (r90.0)
//.declare V0165 (179)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0166 (180)  rf=r size=128 type=ud alias=V0165+0 align=32 words (r5.0)
//.declare V0167 (181)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0168 (182)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0170 (184)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0172 (186)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0174 (188)  rf=r size=128 type=f alias=V0172+0 align=32 words (r72.0)
//.declare V0175 (189)  rf=r size=128 type=f align=32 words (r46.0)
//.declare V0176 (190)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0177 (191)  rf=r size=256 type=ud alias=V0136+0 align=32 words (r56.0)
//.declare V0178 (192)  rf=r size=128 type=ud alias=V0176+0 align=32 words (r14.0)
//.declare P05 (193)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0179 (194)  rf=r size=128 type=d align=32 words (r16.0)
//.declare V0180 (195)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0181 (196)  rf=r size=128 type=f align=32 words (r26.0)
//.declare V0183 (198)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0185 (200)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0187 (202)  rf=r size=128 type=f alias=V0185+0 align=32 words (r36.0)
//.declare V0188 (203)  rf=r size=128 type=f align=32 words (r66.0)
//.declare P06 (204)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0190 (206)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0191 (207)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0192 (208)  rf=r size=128 type=f align=32 words (r38.0)
//.declare V0194 (210)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0196 (212)  rf=r size=128 type=d align=32 words (r48.0)
//.declare V0198 (214)  rf=r size=128 type=f alias=V0196+0 align=32 words (r48.0)
//.declare V0199 (215)  rf=r size=128 type=f align=32 words (r76.0)
//.declare P07 (216)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0201 (218)  rf=r size=128 type=d align=32 words (r30.0)
//.declare V0202 (219)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0203 (220)  rf=r size=128 type=ud alias=V0202+0 align=32 words (r32.0)
//.declare V0204 (221)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0205 (222)  rf=r size=128 type=f align=32 words (r52.0)
//.declare V0207 (224)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0209 (226)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0211 (228)  rf=r size=128 type=f alias=V0209+0 align=32 words (r68.0)
//.declare V0212 (229)  rf=r size=128 type=f align=32 words (r84.0)
//.declare P08 (230)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0214 (232)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0215 (233)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0216 (234)  rf=r size=128 type=ud alias=V0215+0 align=32 words (r44.0)
//.declare V0217 (235)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0218 (236)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0220 (238)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0222 (240)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0224 (242)  rf=r size=128 type=f alias=V0222+0 align=32 words (r78.0)
//.declare V0226 (244)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0227 (245)  rf=r size=128 type=ud alias=V0226+0 align=32 words (r62.0)
//.declare P09 (246)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0228 (247)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0229 (248)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0230 (249)  rf=r size=128 type=f align=32 words (r80.0)
//.declare V0232 (251)  rf=r size=128 type=d align=32 words (r82.0)
//.declare V0234 (253)  rf=r size=128 type=d align=32 words (r86.0)
//.declare V0236 (255)  rf=r size=128 type=f alias=V0234+0 align=32 words (r86.0)
//.declare V0237 (256)  rf=r size=128 type=f align=32 words (r100.0)
//.declare P10 (257)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0238 (258)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0240 (260)  rf=r size=128 type=ud alias=V0238+0 align=32 words (r1.0)
//.declare V0242 (262)  rf=r size=256 type=q align=32 words (r25.0)
//.declare V0243 (263)  rf=r size=256 type=uq alias=V0242+0 align=32 words (r25.0)
//.declare V0244 (264)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0245 (265)  rf=r size=128 type=d align=32 words (r39.0)
//.declare V0246 (266)  rf=r size=128 type=d align=32 words (r41.0)
//.declare V0247 (267)  rf=r size=128 type=d align=32 words (r43.0)
//.declare V0249 (269)  rf=r size=128 type=w alias=V0244+0 align=32 words (r33.0)
//.declare V0253 (273)  rf=r size=128 type=w alias=V0245+0 align=32 words (r39.0)
//.declare V0257 (277)  rf=r size=128 type=w alias=V0246+0 align=32 words (r41.0)
//.declare V0261 (281)  rf=r size=128 type=w alias=V0247+0 align=32 words (r43.0)
//.declare V0264 (284)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0265 (285)  rf=r size=128 type=ud alias=V0264+0 align=32 words (r9.0)
//.declare V0266 (286)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0268 (288)  rf=r size=128 type=ud alias=V0266+0 align=32 words (r19.0)
//.declare V0271 (291)  rf=r size=256 type=uq align=32 words (r35.0)
//.declare V0272 (292)  rf=r size=128 type=f align=32 words (r45.0)
//.declare V0275 (295)  rf=r size=256 type=uq align=32 words (r11.0)
//.declare V0276 (296)  rf=r size=256 type=d align=32 words (r21.0)
//.declare P11 (297)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0278 (299)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0279 (300)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0280 (301)  rf=r size=128 type=f align=32 words (r59.0)
//.declare V0282 (303)  rf=r size=128 type=d align=32 words (r53.0)
//.declare V0284 (305)  rf=r size=128 type=d align=32 words (r65.0)
//.declare V0286 (307)  rf=r size=128 type=f alias=V0284+0 align=32 words (r65.0)
//.declare V0287 (308)  rf=r size=128 type=f align=32 words (r87.0)
//.declare P12 (309)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0289 (311)  rf=r size=128 type=d align=32 words (r51.0)
//.declare V0290 (312)  rf=r size=128 type=d align=32 words (r47.0)
//.declare V0291 (313)  rf=r size=256 type=ub alias=V0276+0 align=32 words (r21.0)
//.declare V0292 (314)  rf=r size=128 type=ud alias=V0290+0 align=32 words (r47.0)
//.declare V0293 (315)  rf=r size=128 type=d align=32 words (r57.0)
//.declare V0294 (316)  rf=r size=128 type=f align=32 words (r67.0)
//.declare V0296 (318)  rf=r size=128 type=d align=32 words (r69.0)
//.declare V0298 (320)  rf=r size=128 type=d align=32 words (r77.0)
//.declare V0300 (322)  rf=r size=128 type=f alias=V0298+0 align=32 words (r77.0)
//.declare V0301 (323)  rf=r size=128 type=f align=32 words (r11.0)
//.declare P13 (324)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0303 (326)  rf=r size=128 type=d align=32 words (r61.0)
//.declare V0304 (327)  rf=r size=128 type=d align=32 words (r63.0)
//.declare V0305 (328)  rf=r size=128 type=ud alias=V0304+0 align=32 words (r63.0)
//.declare V0306 (329)  rf=r size=128 type=d align=32 words (r71.0)
//.declare V0307 (330)  rf=r size=128 type=f align=32 words (r79.0)
//.declare V0309 (332)  rf=r size=128 type=d align=32 words (r81.0)
//.declare V0311 (334)  rf=r size=128 type=d align=32 words (r89.0)
//.declare V0313 (336)  rf=r size=128 type=f alias=V0311+0 align=32 words (r89.0)
//.declare V0314 (337)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0315 (338)  rf=r size=128 type=d align=32 words (r73.0)
//.declare V0316 (339)  rf=r size=256 type=ud alias=V0276+0 align=32 words (r21.0)
//.declare V0317 (340)  rf=r size=128 type=ud alias=V0315+0 align=32 words (r73.0)
//.declare P14 (341)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0318 (342)  rf=r size=128 type=d align=32 words (r75.0)
//.declare V0319 (343)  rf=r size=128 type=d align=32 words (r83.0)
//.declare V0320 (344)  rf=r size=128 type=f align=32 words (r91.0)
//.declare V0322 (346)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0324 (348)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0326 (350)  rf=r size=128 type=f alias=V0324+0 align=32 words (r13.0)
//.declare V0327 (351)  rf=r size=128 type=f align=32 words (r47.0)
//.declare P15 (352)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0329 (354)  rf=r size=128 type=d align=32 words (r85.0)
//.declare V0330 (355)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0331 (356)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0333 (358)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0335 (360)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0337 (362)  rf=r size=128 type=f alias=V0335+0 align=32 words (r31.0)
//.declare V0338 (363)  rf=r size=128 type=f align=32 words (r57.0)
//.declare P16 (364)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0340 (366)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0341 (367)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0342 (368)  rf=r size=128 type=ud alias=V0341+0 align=32 words (r9.0)
//.declare V0343 (369)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0344 (370)  rf=r size=128 type=f align=32 words (r33.0)
//.declare V0346 (372)  rf=r size=128 type=d align=32 words (r35.0)
//.declare V0348 (374)  rf=r size=128 type=d align=32 words (r49.0)
//.declare V0350 (376)  rf=r size=128 type=f alias=V0348+0 align=32 words (r49.0)
//.declare V0351 (377)  rf=r size=128 type=f align=32 words (r65.0)
//.declare P17 (378)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0353 (380)  rf=r size=128 type=d align=32 words (r25.0)
//.declare V0354 (381)  rf=r size=128 type=d align=32 words (r27.0)
//.declare V0355 (382)  rf=r size=128 type=ud alias=V0354+0 align=32 words (r27.0)
//.declare V0356 (383)  rf=r size=128 type=d align=32 words (r37.0)
//.declare V0357 (384)  rf=r size=128 type=f align=32 words (r51.0)
//.declare V0359 (386)  rf=r size=128 type=d align=32 words (r53.0)
//.declare V0361 (388)  rf=r size=128 type=d align=32 words (r59.0)
//.declare V0363 (390)  rf=r size=128 type=f alias=V0361+0 align=32 words (r59.0)
//.declare V0365 (392)  rf=r size=128 type=d align=32 words (r39.0)
//.declare V0366 (393)  rf=r size=128 type=ud alias=V0365+0 align=32 words (r39.0)
//.declare P18 (394)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0367 (395)  rf=r size=128 type=d align=32 words (r41.0)
//.declare V0368 (396)  rf=r size=128 type=d align=32 words (r55.0)
//.declare V0369 (397)  rf=r size=128 type=f align=32 words (r61.0)
//.declare V0371 (399)  rf=r size=128 type=d align=32 words (r63.0)
//.declare V0373 (401)  rf=r size=128 type=d align=32 words (r67.0)
//.declare V0375 (403)  rf=r size=128 type=f alias=V0373+0 align=32 words (r67.0)
//.declare V0376 (404)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0377 (405)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0378 (406)  rf=r size=128 type=f align=32 words (r8.0)
//.declare V0379 (407)  rf=r size=128 type=uw alias=V0377+0 align=32 words (r5.0)
//.declare V0380 (408)  rf=r size=64 type=uw align=32 words (r7.0)
//.declare A00 (409)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P19 (410)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0383 (413)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0384 (414)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0385 (415)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0386 (416)  rf=r size=128 type=f align=32 words (r15.0)
//.declare V0387 (417)  rf=r size=128 type=uw alias=V0385+0 align=32 words (r12.0)
//.declare V0388 (418)  rf=r size=64 type=uw align=32 words (r14.0)
//.declare A01 (419)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P20 (420)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0391 (423)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0392 (424)  rf=r size=128 type=d align=32 words (r17.0)
//.declare V0393 (425)  rf=r size=128 type=d align=32 words (r19.0)
//.declare V0394 (426)  rf=r size=128 type=f align=32 words (r22.0)
//.declare V0395 (427)  rf=r size=128 type=uw alias=V0393+0 align=32 words (r19.0)
//.declare V0396 (428)  rf=r size=64 type=uw align=32 words (r21.0)
//.declare A02 (429)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P21 (430)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0399 (433)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0400 (434)  rf=r size=128 type=d align=32 words (r24.0)
//.declare V0401 (435)  rf=r size=128 type=d align=32 words (r26.0)
//.declare V0402 (436)  rf=r size=128 type=f align=32 words (r29.0)
//.declare V0403 (437)  rf=r size=128 type=uw alias=V0401+0 align=32 words (r26.0)
//.declare V0404 (438)  rf=r size=64 type=uw align=32 words (r28.0)
//.declare A03 (439)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P22 (440)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0407 (443)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0408 (444)  rf=r size=128 type=d align=32 words (r31.0)
//.declare V0409 (445)  rf=r size=128 type=d align=32 words (r33.0)
//.declare V0410 (446)  rf=r size=128 type=f align=32 words (r110.0)
//.declare V0411 (447)  rf=r size=128 type=uw alias=V0409+0 align=32 words (r33.0)
//.declare V0412 (448)  rf=r size=64 type=uw align=32 words (r35.0)
//.declare A04 (449)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P23 (450)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0414 (452)  rf=r size=128 type=f align=32 words (r112.0)
//.declare V0415 (453)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0416 (454)  rf=r size=128 type=d alias=V0414+0 align=32 words (r112.0)
//.declare P24 (455)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0417 (456)  rf=r size=128 type=ud alias=V0415+0 align=32 words (r1.0)
//.declare V0418 (457)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0419 (458)  rf=r size=128 type=ud alias=V0414+0 align=32 words (r112.0)
//.declare V0420 (459)  rf=r size=128 type=ud alias=V0418+0 align=32 words (r1.0)
//.declare V0421 (460)  rf=r size=128 type=d align=32 words (r5.0)
//.declare V0422 (461)  rf=r size=128 type=d align=32 words (r7.0)
//.declare V0423 (462)  rf=r size=128 type=d align=32 words (r9.0)
//.declare V0424 (463)  rf=r size=128 type=ud alias=V0422+0 align=32 words (r7.0)
//.declare V0425 (464)  rf=r size=128 type=ud alias=V0423+0 align=32 words (r9.0)
//.declare V0426 (465)  rf=r size=64 type=w align=32 words (r114.0)
//.declare V0427 (466)  rf=r size=128 type=d align=32 words (r1.0)
//.declare V0428 (467)  rf=r size=128 type=ud alias=V0427+0 align=32 words (r1.0)
//.declare V0433 (472)  rf=r size=256 type=uq align=32 words (r7.0)
//.declare V0434 (473)  rf=r size=64 type=uw alias=V0426+0 align=32 words (r114.0)
//.declare V0435 (474)  rf=r size=128 type=ud align=32 words (r11.0)
//.declare  (475)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (476)  rf=r size=128 type=w alias=V0427+0 align=32 words (r1.0)
//.declare  (479)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (480)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (481)  rf=r size=128 type=uw align=32 words (r11.0)
//.declare  (482)  rf=r size=2 type=w align=1 words (r10.0)
//.declare  (485)  rf=r size=2 type=w align=1 words (r11.0)
//.declare  (490)  rf=r size=64 type=ud align=32 words (r12.0)
//.declare  (491)  rf=r size=64 type=ud align=32 words (r13.0)
//.declare  (492)  rf=r size=128 type=ud align=32 words (r22.0)
//.declare  (493)  rf=r size=128 type=ud align=32 words (r24.0)
//.declare  (494)  rf=r size=128 type=ud align=32 words (r26.0)
//.declare  (495)  rf=r size=128 type=ud align=32 words (r34.0)
//.declare  (498)  rf=r size=2 type=w align=1 words (r3.4)
//.declare  (501)  rf=r size=2 type=w align=1 words (r4.0)
//.declare  (506)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (507)  rf=r size=128 type=ud align=32 words (r7.0)
//.declare  (508)  rf=r size=128 type=ud align=32 words (r29.0)
//.declare  (509)  rf=r size=128 type=ud align=32 words (r31.0)
//.declare  (512)  rf=r size=128 type=w alias=V0423+0 align=32 words (r9.0)
//.declare  (515)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (516)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (517)  rf=r size=128 type=q align=32 words (r115.0)
//.declare  (518)  rf=r size=128 type=q align=32 words (r117.0)
//.declare  (521)  rf=r size=128 type=q align=32 words (r14.0)
//.declare  (522)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (523)  rf=r size=128 type=q align=32 words (r119.0)
//.declare  (524)  rf=r size=128 type=q align=32 words (r121.0)
//.declare  (525)  rf=r size=128 type=q align=32 words (r123.0)
//.declare  (526)  rf=r size=128 type=q align=32 words (r125.0)
//.declare  (529)  rf=r size=128 type=q align=32 words (r28.0)
//.declare  (530)  rf=r size=128 type=q align=32 words (r32.0)
//.declare  (539)  rf=r size=128 type=q align=32 words (r15.0)
//.declare  (540)  rf=r size=128 type=q align=32 words (r17.0)
//.declare  (547)  rf=r size=128 type=q align=32 words (r1.0)
//.declare  (548)  rf=r size=128 type=q align=32 words (r5.0)
//.declare  (551)  rf=r size=128 type=uq alias=+0 align=32 words (r115.0)
//.declare  (552)  rf=r size=128 type=uq alias=+0 align=32 words (r9.0)
//.declare  (553)  rf=r size=128 type=uq alias=+0 align=32 words (r117.0)
//.declare  (554)  rf=r size=128 type=uq alias=+0 align=32 words (r13.0)
//.declare  (555)  rf=r size=128 type=d alias=+0 align=32 words (r115.0)
//.declare  (556)  rf=r size=128 type=d alias=+0 align=32 words (r117.0)
//.declare  (557)  rf=r size=128 type=ud alias=+0 align=32 words (r14.0)
//.declare  (558)  rf=r size=128 type=ud alias=+0 align=32 words (r18.0)
//.declare  (559)  rf=r size=128 type=d alias=+0 align=32 words (r14.0)
//.declare  (560)  rf=r size=128 type=d alias=+0 align=32 words (r18.0)
//.declare r0 (561)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (562)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (563)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (564)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (565)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (566)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (567)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0042    | :q       |    0x8 | r2+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0045    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0050    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0051    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0052    | :q       |    0x8 | r4       | cti+0x60         |
// | V0053    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0054    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0055    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0056    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0057    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0058    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0059    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0060    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0061    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0062    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0063    | :d       |    0x4 | r5+0x18  | cti+0xB8         |
// | V0064    | :d       |    0x4 | r5+0x1C  | cti+0xBC         |
// | V0065    | :d       |    0x4 | r5+0x20  | cti+0xC0         |
// | V0066    | :d       |    0x4 | r5+0x24  | cti+0xC4         |
// | V0067    | :d       |    0x4 | r5+0x28  | cti+0xC8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B010}
// _main:
(W)     mov (16|M0)              r93.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r93.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r4.0<1>:ud    r2.0<0;1,0>:ud    r93.1<0;1,0>:ud  {Compacted,$1.dst} //  ALU pipe: int; $3
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r93.2<0;1,0>:uw                     //  ALU pipe: int; $3
(W)     mach (1|M0)              r6.0<1>:d     r2.0<0;1,0>:ud    r93.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $9
        mov (16|M16)             r11.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $9
        sync.nop                             null                             {Compacted,I@5}        // $3
(W)     mov (1|M0)               r5.0<2>:f     r4.0<0;1,0>:f                    {$2.dst}             //  ALU pipe: float; $3
(W)     mov (1|M0)               r5.1<2>:d     r6.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $7
        add (16|M0)              r9.0<1>:q     r5.0<0;1,0>:q     r7.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $9
        add (16|M16)             r13.0<1>:q    r5.0<0;1,0>:q     r11.0<4;1,0>:uw                     //  ALU pipe: int; $9
        shr (16|M0)              r115.0<1>:uq  r9.0<1;1,0>:uq    5:w               {I@2}             //  ALU pipe: int; $10
        shr (16|M16)             r117.0<1>:uq  r13.0<1;1,0>:uq   5:w               {I@2}             //  ALU pipe: int; $10
        mov (16|M0)              r15.0<1>:d    r115.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $11
        mov (16|M16)             r16.0<1>:d    r117.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $11
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r15.0<1;1,0>:ud   r5.7<0;1,0>:ud   {I@1}              //  ALU pipe: int; $12
(~f3.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $13
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_013:
        mov (16|M0)              r6.0<1>:d     r115.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $15
        mov (16|M16)             r7.0<1>:d     r117.0<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $16
(W)     mov (8|M0)               r94.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $19
(W)     mul (16|M0)              acc0.0<1>:ud  r6.0<1;1,0>:ud    r5.12<0;1,0>:uw  {I@3}              //  ALU pipe: int; $22
(W)     add (8|M0)               r94.8<1>:w    r94.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $20
        macl (16|M0)             r12.0<1>:ud   r6.0<1;1,0>:ud    r5.6<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $23
(W)     mul (16|M16)             acc0.0<1>:ud  r7.0<1;1,0>:ud    r5.12<0;1,0>:uw                     //  ALU pipe: int; $23
        mov (16|M0)              r8.0<1>:d     r115.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $17
        macl (16|M16)            r13.0<1>:ud   r7.0<1;1,0>:ud    r5.6<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $24
(W)     mul (16|M0)              acc0.0<1>:ud  r6.0<1;1,0>:ud    r5.12<0;1,0>:uw                     //  ALU pipe: int; $24
        mov (16|M16)             r9.0<1>:d     r117.1<2;1,0>:d                  {Compacted}          //  ALU pipe: int; $18
(W)     add (16|M0)              r94.16<1>:w   r94.0<1;1,0>:w    16:w               {I@7}            //  ALU pipe: int; $21
        mach (16|M0)             r16.0<1>:d    r6.0<1;1,0>:ud    r5.6<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r7.0<1;1,0>:ud    r5.12<0;1,0>:uw                     //  ALU pipe: int; $24
        mach (16|M16)            r17.0<1>:d    r7.0<1;1,0>:ud    r5.6<0;1,0>:ud                      //  ALU pipe: int; $26
(W)     mul (16|M0)              acc0.0<1>:d   r5.6<0;1,0>:ud    r8.0<2;1,0>:uw   {I@7}              //  ALU pipe: int; $27
        mov (32|M0)              r95.0<1>:d    r94.0<1;1,0>:uw                  {I@5}                //  ALU pipe: int; $31
        macl (16|M0)             r30.0<1>:d    r5.6<0;1,0>:ud    r8.0<1;1,0>:d                       //  ALU pipe: int; $27
(W)     mul (16|M16)             acc0.0<1>:d   r5.6<0;1,0>:ud    r9.0<2;1,0>:uw                      //  ALU pipe: int; $27
        macl (16|M16)            r31.0<1>:d    r5.6<0;1,0>:ud    r9.0<1;1,0>:d                       //  ALU pipe: int; $28
        shl (32|M0)              r97.0<1>:d    r95.0<1;1,0>:d    3:w               {Compacted,I@4}   //  ALU pipe: int; $32
        mov (16|M0)              r14.0<2>:ud   r12.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $23
        mov (16|M16)             r18.0<2>:ud   r13.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $24
        add (16|M0)              r14.1<2>:d    r16.0<1;1,0>:d    r30.0<1;1,0>:d   {I@6}              //  ALU pipe: int; $28
        add (16|M16)             r18.1<2>:d    r17.0<1;1,0>:d    r31.0<1;1,0>:d   {I@5}              //  ALU pipe: int; $29
        mov (16|M0)              r22.0<2>:ud   r97.0<1;1,0>:ud                  {Compacted,I@5}      //  ALU pipe: int; $35
        mov (16|M16)             r24.0<2>:ud   r98.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $35
        add (16|M0)              r119.0<1>:q   r14.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $30
        add (16|M16)             r121.0<1>:q   r18.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@4}    //  ALU pipe: int; $30
        add (16|M0)              r44.0<1>:q    r119.0<1;1,0>:q   r22.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $54
        add (16|M16)             r46.0<1>:q    r121.0<1;1,0>:q   r24.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $54
        load.ugm.d32x2.a64 (32|M0)  r56:4       [r44:4]            {I@1,$3} // ex_desc:0x0; desc:0x8401580 // $56
        shl (16|M0)              r28.0<1>:q    r22.0<2;1,0>:ud   1:w                                 //  ALU pipe: int; $35
        shl (16|M16)             r32.0<1>:q    r24.0<2;1,0>:ud   1:w                                 //  ALU pipe: int; $35
        and (32|M0)              r20.0<1>:d    r95.0<1;1,0>:d    28:w               {Compacted}      //  ALU pipe: int; $49
        add (16|M0)              r36.0<1>:q    r28.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $36
        add (16|M16)             r38.0<1>:q    r32.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $36
        add (16|M0)              r123.0<1>:q   r119.0<1;1,0>:q   320:w               {Compacted}     //  ALU pipe: int; $33
        add (16|M16)             r125.0<1>:q   r121.0<1;1,0>:q   320:w               {Compacted}     //  ALU pipe: int; $33
        mov (16|M0)              r26.0<2>:ud   r20.0<1;1,0>:ud                  {Compacted,I@5}      //  ALU pipe: int; $51
        mov (16|M16)             r34.0<2>:ud   r21.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $51
        load.ugm.d32.a64 (32|M0)  r40:2         [r36:4]            {I@5,$4} // ex_desc:0x0; desc:0x8200580 // $37
        add (16|M0)              r52.0<1>:q    r123.0<1;1,0>:q   r26.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $51
        add (16|M16)             r54.0<1>:q    r125.0<1;1,0>:q   r34.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $51
        load.ugm.d32.a64 (32|M0)  r60:2         [r52:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $53
        load.ugm.d32.a64 (32|M0)  r42:2         [r36:4+0x4]        {$6} // ex_desc:0x4000; desc:0x8200580 // $38
        load.ugm.d32.a64 (32|M0)  r48:2         [r36:4+0x8]        {$7} // ex_desc:0x8000; desc:0x8200580 // $39
        load.ugm.d32.a64 (32|M0)  r50:2         [r36:4+0xC]        {$8} // ex_desc:0xC000; desc:0x8200580 // $40
(W)     mov (1|M0)               r10.0<1>:hf   0x0:hf                                                //  ALU pipe: float; $59
(W)     mov (1|M0)               r99.0<1>:d    255:w                               {Compacted}       //  ALU pipe: int; $60
        and (32|M0)   (eq)f2.0   null<1>:d     r56.0<1;1,0>:d    128:w               {$3.dst}        //  ALU pipe: int; $57
        and (32|M0)   (eq)f3.0   null<1>:d     r56.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $68
(f2.0)  sel (32|M0)              r82.0<1>:d    r10.0<0;1,0>:w    -256:w               {F@1}          //  ALU pipe: int; $59
        bfn.(s0&s1|s2) (32|M0)   r86.0<1>:ud   r56.0<1;0>:ud     r99.0<0;0>:ud     r82.0<1>:ud      {I@1} //  ALU pipe: int; $61
        and (32|M0)   (eq)f1.0   null<1>:d     r56.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $79
        mov (32|M0)              r80.0<1>:ud   r56.1<4;1,0>:ub                                       //  ALU pipe: int; $71
(f3.0)  sel (32|M0)              r84.0<1>:d    r10.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $70
        mov (32|M0)              r62.0<1>:d    r40.0<2;1,0>:uw                  {$4.dst}             //  ALU pipe: int; $64
        mov (32|M0)              r1.0<1>:f     r86.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $62
        or (32|M0)               r88.0<1>:d    r80.0<1;1,0>:d    r84.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $72
        shl (32|M0)              r68.0<1>:d    r62.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $65
        mul (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    r1.0<1;1,0>:f    {Compacted,@1,$5.dst} //  ALU pipe: float; $63
        mov (32|M0)              r5.0<1>:ud    r56.2<4;1,0>:ub                                       //  ALU pipe: int; $82
        cmp (32|M0)   (lt)f2.0   null<1>:d     r56.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $91
(f1.0)  sel (32|M0)              r90.0<1>:d    r10.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $81
        mov (32|M0)              r64.0<1>:d    r40.1<2;1,0>:uw                                       //  ALU pipe: int; $75
        mov (32|M0)              r7.0<1>:f     r88.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $73
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r68.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $66
(W)     mov (1|M0)               r11.0<1>:hf   0xFF00:hf                                             //  ALU pipe: float; $92
        or (32|M0)               r12.0<1>:d    r5.0<1;1,0>:d     r90.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $83
        shl (32|M0)              r70.0<1>:d    r64.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $76
        mul (32|M0)              acc2.0<1>:f   r60.0<1;1,0>:f    r7.0<1;1,0>:f    {Compacted,F@3}    //  ALU pipe: float; $74
        shr (32|M0)              r14.0<1>:ud   r56.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $90
        mov (32|M0)              r66.0<1>:d    r42.0<2;1,0>:uw                  {$6.dst}             //  ALU pipe: int; $86
        and (32|M0)   (eq)f1.0   null<1>:d     r58.0<1;1,0>:d    128:w                               //  ALU pipe: int; $100
(f2.0)  sel (32|M0)              r16.0<1>:d    r11.0<0;1,0>:w    0:w               {F@2}             //  ALU pipe: int; $92
        mov (32|M0)              r18.0<1>:f    r12.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $84
        add (32|M0)              r24.0<1>:f    acc0.0<1;1,0>:f   0x0:f               {Compacted}     //  ALU pipe: float; $67
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r70.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $77
        shl (32|M0)              r72.0<1>:d    r66.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $87
        or (32|M0)               r20.0<1>:d    r14.0<1;1,0>:d    r16.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $93
        mul (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    r18.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $85
        and (32|M0)   (eq)f3.0   null<1>:d     r58.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $110
        mov (32|M0)              r74.0<1>:d    r42.1<2;1,0>:uw                                       //  ALU pipe: int; $96
(f1.0)  sel (32|M0)              r22.0<1>:d    r10.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $102
        mov (32|M0)              r26.0<1>:f    r20.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $94
        add (32|M0)              r34.0<1>:f    r24.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $78
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r72.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $88
        shl (32|M0)              r36.0<1>:d    r74.0<1;1,0>:d    16:w               {Compacted,@2,$8.src} //  ALU pipe: int; $97
        bfn.(s0&s1|s2) (32|M0)   r28.0<1>:ud   r58.0<1;0>:ud     r99.0<0;0>:ud     r22.0<1>:ud      {I@2} //  ALU pipe: int; $103
        mul (32|M0)              acc2.0<1>:f   r60.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $95
        mov (32|M0)              r32.0<1>:ud   r58.1<4;1,0>:ub                                       //  ALU pipe: int; $113
        mov (32|M0)              r76.0<1>:d    r48.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $106
        and (32|M0)   (eq)f2.0   null<1>:d     r58.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $121
(f3.0)  sel (32|M0)              r30.0<1>:d    r10.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $112
        mov (32|M0)              r38.0<1>:f    r28.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $104
        add (32|M0)              r46.0<1>:f    r34.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $89
        mov (32|M0)              r78.0<1>:d    r48.1<2;1,0>:uw                                       //  ALU pipe: int; $117
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r36.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $98
        or (32|M0)               r40.0<1>:d    r32.0<1;1,0>:d    r30.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $114
        shl (32|M0)              r48.0<1>:d    r76.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $107
        mul (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    r38.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $105
        mov (32|M0)              r44.0<1>:ud   r58.2<4;1,0>:ub                                       //  ALU pipe: int; $124
        cmp (32|M0)   (lt)f1.0   null<1>:d     r58.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $133
(f2.0)  sel (32|M0)              r42.0<1>:d    r10.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $123
        mov (32|M0)              r52.0<1>:f    r40.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $115
        add (32|M0)              r66.0<1>:f    r46.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $99
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r48.0<1;1,0>:f   {Compacted,I@4}    //  ALU pipe: float; $108
        shl (32|M0)              r68.0<1>:d    r78.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $118
        or (32|M0)               r54.0<1>:d    r44.0<1;1,0>:d    r42.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $125
        mul (32|M0)              acc2.0<1>:f   r60.0<1;1,0>:f    r52.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $116
        shr (32|M0)              r62.0<1>:ud   r58.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $132
        mov (32|M0)              r72.0<1>:d    r50.0<2;1,0>:uw                  {$8.dst}             //  ALU pipe: int; $128
(f1.0)  sel (32|M0)              r64.0<1>:d    r11.0<0;1,0>:w    0:w                                 //  ALU pipe: int; $134
        mov (32|M0)              r70.0<1>:f    r54.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $126
        add (32|M0)              r76.0<1>:f    r66.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $109
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r68.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $119
        shl (32|M0)              r78.0<1>:d    r72.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $129
        or (32|M0)               r74.0<1>:d    r62.0<1;1,0>:d    r64.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $135
        mul (32|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    r70.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $127
        mov (32|M0)              r80.0<1>:f    r74.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $136
        add (32|M0)              r84.0<1>:f    r76.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $120
        mov (32|M0)              r82.0<1>:d    r50.1<2;1,0>:uw                                       //  ALU pipe: int; $138
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r78.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $130
        mul (32|M0)              acc2.0<1>:f   r60.0<1;1,0>:f    r80.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $137
        shl (32|M0)              r86.0<1>:d    r82.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $139
        add (32|M0)              acc0.0<1>:f   r84.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $131
        cmp (32|M0)   (lt)f0.0   null<2>:uw    r94.0<1;1,0>:uw   0x8:uw                              //  ALU pipe: int; $142
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r86.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $140
        add (32|M0)              r100.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $141
(~f0.0) goto (32|M0)                         _0_014            _0_014                                //  ALU pipe: int; $143
// B004: [inDivergent],  Preds:{B003},  Succs:{B005}
_0_015:
        or (32|M0)               r1.0<1>:d     r97.0<1;1,0>:d    256:w               {Compacted}     //  ALU pipe: int; $145
        mov (16|M0)              r5.0<2>:ud    r1.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $147
        mov (16|M16)             r7.0<2>:ud    r2.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $147
        add (16|M0)              r11.0<1>:q    r119.0<1;1,0>:q   r5.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $167
        add (16|M16)             r13.0<1>:q    r121.0<1;1,0>:q   r7.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $167
        load.ugm.d32x2.a64 (32|M0)  r21:4       [r11:4]            {I@1,$9} // ex_desc:0x0; desc:0x8401580 // $169
        shr (32|M0)              r9.0<1>:ud    r1.0<1;1,0>:ud    3:w                                 //  ALU pipe: int; $161
        shl (16|M0)              r15.0<1>:q    r5.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $147
        shl (16|M16)             r17.0<1>:q    r7.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $147
        and (32|M0)              r19.0<1>:d    r9.0<1;1,0>:d     60:w               {Compacted,I@3}  //  ALU pipe: int; $162
        add (16|M0)              r25.0<1>:q    r15.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $148
        add (16|M16)             r27.0<1>:q    r17.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $148
        mov (16|M0)              r29.0<2>:ud   r19.0<1;1,0>:ud                  {Compacted,I@3}      //  ALU pipe: int; $164
        mov (16|M16)             r31.0<2>:ud   r20.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $164
        load.ugm.d32.a64 (32|M0)  r33:2         [r25:4]            {I@3,$10} // ex_desc:0x0; desc:0x8200580 // $149
        add (16|M0)              r35.0<1>:q    r123.0<1;1,0>:q   r29.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $164
        add (16|M16)             r37.0<1>:q    r125.0<1;1,0>:q   r31.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $164
        load.ugm.d32.a64 (32|M0)  r45:2         [r35:4]            {I@1,$11} // ex_desc:0x0; desc:0x8200580 // $166
        load.ugm.d32.a64 (32|M0)  r39:2         [r25:4+0x4]        {$12} // ex_desc:0x4000; desc:0x8200580 // $150
        load.ugm.d32.a64 (32|M0)  r41:2         [r25:4+0x8]        {$13} // ex_desc:0x8000; desc:0x8200580 // $151
        load.ugm.d32.a64 (32|M0)  r43:2         [r25:4+0xC]        {$14} // ex_desc:0xC000; desc:0x8200580 // $152
(W)     mov (1|M0)               r3.4<1>:hf    0x0:hf                                                //  ALU pipe: float; $172
(W)     mov (1|M0)               r4.0<1>:hf    0xFF00:hf                                             //  ALU pipe: float; $204
        and (32|M0)   (eq)f3.0   null<1>:d     r21.0<1;1,0>:d    128:w               {$9.dst}        //  ALU pipe: int; $170
        and (32|M0)   (eq)f2.0   null<1>:d     r21.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $180
(f3.0)  sel (32|M0)              r49.0<1>:d    r3.4<0;1,0>:w     -256:w               {F@2}          //  ALU pipe: int; $172
        bfn.(s0&s1|s2) (32|M0)   r55.0<1>:ud   r21.0<1;0>:ud     r99.0<0;0>:ud     r49.0<1>:ud      {I@1} //  ALU pipe: int; $173 R{} IR{}{O:2,O:1,O:0,},  R{r99,} IR{}{E:11,E:9,},  {BC=1}
        and (32|M0)   (eq)f0.0   null<1>:d     r21.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $191
        mov (32|M0)              r47.0<1>:ud   r21.1<4;1,0>:ub                                       //  ALU pipe: int; $183
(f2.0)  sel (32|M0)              r51.0<1>:d    r3.4<0;1,0>:w     -256:w                              //  ALU pipe: int; $182
        mov (32|M0)              r53.0<1>:d    r33.0<2;1,0>:uw                  {$10.dst}            //  ALU pipe: int; $176
        mov (32|M0)              r59.0<1>:f    r55.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $174
        or (32|M0)               r57.0<1>:d    r47.0<1;1,0>:d    r51.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $184
        shl (32|M0)              r65.0<1>:d    r53.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $177
        mul (32|M0)              acc0.0<1>:f   r45.0<1;1,0>:f    r59.0<1;1,0>:f   {Compacted,@1,$11.dst} //  ALU pipe: float; $175
        cmp (32|M0)   (lt)f1.0   null<1>:d     r21.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $203
        mov (32|M0)              r63.0<1>:ud   r21.2<4;1,0>:ub                                       //  ALU pipe: int; $194
(f0.0)  sel (32|M0)              r61.0<1>:d    r3.4<0;1,0>:w     -256:w                              //  ALU pipe: int; $193
        mov (32|M0)              r69.0<1>:d    r33.1<2;1,0>:uw                                       //  ALU pipe: int; $187
        mov (32|M0)              r67.0<1>:f    r57.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $185
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r65.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $178
        or (32|M0)               r71.0<1>:d    r63.0<1;1,0>:d    r61.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $195
        shl (32|M0)              r77.0<1>:d    r69.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $188
        mul (32|M0)              acc2.0<1>:f   r45.0<1;1,0>:f    r67.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $186
        shr (32|M0)              r73.0<1>:ud   r21.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $202
        mov (32|M0)              r81.0<1>:d    r39.0<2;1,0>:uw                  {$12.dst}            //  ALU pipe: int; $198
(f1.0)  sel (32|M0)              r75.0<1>:d    r4.0<0;1,0>:w     0:w                                 //  ALU pipe: int; $204
        and (32|M0)   (eq)f0.0   null<1>:d     r23.0<1;1,0>:d    128:w                               //  ALU pipe: int; $212
        mov (32|M0)              r79.0<1>:f    r71.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $196
        add (32|M0)              r87.0<1>:f    r100.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $179
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r77.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $189
        shl (32|M0)              r89.0<1>:d    r81.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $199
        or (32|M0)               r83.0<1>:d    r73.0<1;1,0>:d    r75.0<1;1,0>:d   {Compacted,I@3}    //  ALU pipe: int; $205
        mul (32|M0)              acc0.0<1>:f   r45.0<1;1,0>:f    r79.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $197
        and (32|M0)   (eq)f3.0   null<1>:d     r23.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $222
        mov (32|M0)              r1.0<1>:d     r39.1<2;1,0>:uw                                       //  ALU pipe: int; $208
(f0.0)  sel (32|M0)              r85.0<1>:d    r3.4<0;1,0>:w     -256:w                              //  ALU pipe: int; $214
        mov (32|M0)              r91.0<1>:f    r83.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $206
        add (32|M0)              r11.0<1>:f    r87.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $190
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r89.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $200
        shl (32|M0)              r13.0<1>:d    r1.0<1;1,0>:d     16:w               {Compacted,I@2}  //  ALU pipe: int; $209
        bfn.(s0&s1|s2) (32|M0)   r5.0<1>:ud    r23.0<1;0>:ud     r99.0<0;0>:ud     r85.0<1>:ud      {I@2} //  ALU pipe: int; $215 R{} IR{}{O:3,O:1,O:2,},  R{r99,} IR{}{E:12,E:11,},  {BC=1}
        mul (32|M0)              acc2.0<1>:f   r45.0<1;1,0>:f    r91.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $207
        mov (32|M0)              r9.0<1>:ud    r23.1<4;1,0>:ub                                       //  ALU pipe: int; $225
        and (32|M0)   (eq)f2.0   null<1>:d     r23.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $233
        mov (32|M0)              r17.0<1>:d    r41.0<2;1,0>:uw                  {$13.dst}            //  ALU pipe: int; $218
(f3.0)  sel (32|M0)              r7.0<1>:d     r3.4<0;1,0>:w     -256:w                              //  ALU pipe: int; $224
        mov (32|M0)              r15.0<1>:f    r5.0<1;1,0>:d                    {I@5}                //  ALU pipe: float; $216
        add (32|M0)              r29.0<1>:f    r11.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $201
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r13.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $210
        shl (32|M0)              r31.0<1>:d    r17.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $219
        or (32|M0)               r19.0<1>:d    r9.0<1;1,0>:d     r7.0<1;1,0>:d    {Compacted,I@2}    //  ALU pipe: int; $226
        mul (32|M0)              acc0.0<1>:f   r45.0<1;1,0>:f    r15.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $217
        mov (32|M0)              r27.0<1>:ud   r23.2<4;1,0>:ub                  {$14.src}            //  ALU pipe: int; $236
        mov (32|M0)              r35.0<1>:d    r41.1<2;1,0>:uw                                       //  ALU pipe: int; $229
        cmp (32|M0)   (lt)f1.0   null<1>:d     r23.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $245
(f2.0)  sel (32|M0)              r25.0<1>:d    r3.4<0;1,0>:w     -256:w                              //  ALU pipe: int; $235
        mov (32|M0)              r33.0<1>:f    r19.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $227
        add (32|M0)              r47.0<1>:f    r29.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $211
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r31.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $220
        shl (32|M0)              r49.0<1>:d    r35.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $230
        or (32|M0)               r37.0<1>:d    r27.0<1;1,0>:d    r25.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $237
        mul (32|M0)              acc2.0<1>:f   r45.0<1;1,0>:f    r33.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $228
        shr (32|M0)              r39.0<1>:ud   r23.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $244
        mov (32|M0)              r53.0<1>:d    r43.0<2;1,0>:uw                  {$14.dst}            //  ALU pipe: int; $240
(f1.0)  sel (32|M0)              r41.0<1>:d    r4.0<0;1,0>:w     0:w                                 //  ALU pipe: int; $246
        mov (32|M0)              r51.0<1>:f    r37.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $238
        add (32|M0)              r57.0<1>:f    r47.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $221
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r49.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $231
        shl (32|M0)              r59.0<1>:d    r53.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $241
        or (32|M0)               r55.0<1>:d    r39.0<1;1,0>:d    r41.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $247
        mul (32|M0)              acc0.0<1>:f   r45.0<1;1,0>:f    r51.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $239
        mov (32|M0)              r61.0<1>:f    r55.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $248
        add (32|M0)              r65.0<1>:f    r57.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $232
        mov (32|M0)              r63.0<1>:d    r43.1<2;1,0>:uw                                       //  ALU pipe: int; $250
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r59.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $242
        mul (32|M0)              acc2.0<1>:f   r45.0<1;1,0>:f    r61.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $249 R{} IR{}{O:6,O:6,},  R{} IR{}{E:7,E:15,},  {BC=1}
        shl (32|M0)              r67.0<1>:d    r63.0<1;1,0>:d    16:w               {Compacted,I@1}  //  ALU pipe: int; $251
        add (32|M0)              acc0.0<1>:f   r65.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $243
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r67.0<1;1,0>:f   {Compacted,I@1}    //  ALU pipe: float; $252
        add (32|M0)              r100.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $253
// B005: [inDivergent],  Preds:{B004, B003},  Succs:{B006, B010}
_0_014:
        join (32|M0)                         _0_012                                                  // 
L3360:
        add (32|M0)              r1.0<1>:d     r95.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $255
        and (32|M0)              r5.0<1>:d     r1.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $256
        shl (32|M0)              r7.0<1>:uw    r5.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $257
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $258
        add (16|M0)              a0.0<1>:uw    r7.0<1;1,0>:uw    0x1900:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0237(r100.0:f); $259
        add (32|M0)              r10.0<1>:d    r95.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $268
        mov (16|M0)              r8.0<1>:ud    r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $260
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $261
        add (16|M16)             a0.0<1>:uw    r7.16<1;1,0>:uw   0x1900:uw                           //  ALU pipe: int; src1 is addr of V0237(r100.0:f); $262
        and (32|M0)   (eq)f2.0   null<1>:d     r95.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $264
        and (32|M0)              r12.0<1>:d    r10.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $269
        mov (16|M16)             r9.0<1>:ud    r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $263
        shl (32|M0)              r14.0<1>:uw   r12.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $270
(f2.0)  sel (32|M0)              acc0.0<1>:f   r8.0<1;1,0>:f     0x80000000:f               {I@2}    //  ALU pipe: float; $266
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $271
        add (16|M0)              a0.0<1>:uw    r14.0<1;1,0>:uw   0x1980:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0383(r102.0:f); $272
        add (32|M0)              r102.0<1>:f   r100.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $267
        add (32|M0)              r17.0<1>:d    r95.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $281
        mov (16|M0)              r15.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $273
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $274
        add (16|M16)             a0.0<1>:uw    r14.16<1;1,0>:uw  0x1980:uw                           //  ALU pipe: int; src1 is addr of V0383(r102.0:f); $275
        and (32|M0)   (eq)f1.0   null<1>:d     r95.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $277
        and (32|M0)              r19.0<1>:d    r17.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $282
        mov (16|M16)             r16.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $276
        shl (32|M0)              r21.0<1>:uw   r19.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $283
(f1.0)  sel (32|M0)              acc0.0<1>:f   r15.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $279
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $284
        add (16|M0)              a0.0<1>:uw    r21.0<1;1,0>:uw   0x1A00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0391(r104.0:f); $285
        add (32|M0)              r104.0<1>:f   r102.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $280
        add (32|M0)              r24.0<1>:d    r95.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $294
        mov (16|M0)              r22.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $286
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $287
        add (16|M16)             a0.0<1>:uw    r21.16<1;1,0>:uw  0x1A00:uw                           //  ALU pipe: int; src1 is addr of V0391(r104.0:f); $288
        and (32|M0)   (eq)f0.0   null<1>:d     r95.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $290
        and (32|M0)              r26.0<1>:d    r24.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $295
        mov (16|M16)             r23.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $289
        shl (32|M0)              r28.0<1>:uw   r26.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $296
(f0.0)  sel (32|M0)              acc0.0<1>:f   r22.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $292
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $297
        add (16|M0)              a0.0<1>:uw    r28.0<1;1,0>:uw   0x1A80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0399(r106.0:f); $298
        add (32|M0)              r106.0<1>:f   r104.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $293
        add (32|M0)              r31.0<1>:d    r95.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $307
        mov (16|M0)              r29.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $299
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $300
        add (16|M16)             a0.0<1>:uw    r28.16<1;1,0>:uw  0x1A80:uw                           //  ALU pipe: int; src1 is addr of V0399(r106.0:f); $301
        and (32|M0)   (eq)f3.0   null<1>:d     r95.0<1;1,0>:d    15:w                                //  ALU pipe: int; $303
        and (32|M0)              r33.0<1>:d    r31.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $308
        mov (16|M16)             r30.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $302
        shl (32|M0)              r35.0<1>:uw   r33.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $309
(f3.0)  sel (32|M0)              acc0.0<1>:f   r29.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $305
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $310
        add (16|M0)              a0.0<1>:uw    r35.0<1;1,0>:uw   0x1B00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0407(r108.0:f); $311
        add (32|M0)              r108.0<1>:f   r106.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $306
        cmp (32|M0)   (eq)f0.0   null<2>:w     r94.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $316
        mov (16|M0)              r110.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $312
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $313
        add (16|M16)             a0.0<1>:uw    r35.16<1;1,0>:uw  0x1B00:uw                           //  ALU pipe: int; src1 is addr of V0407(r108.0:f); $314
        mov (16|M16)             r111.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $315
(~f0.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $317
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B008}
_0_016:
(f0.0)  sel (32|M0)              acc0.0<1>:f   r110.0<1;1,0>:f   0x80000000:f               {I@2}    //  ALU pipe: float; $319
        add (32|M0)              r112.0<1>:f   r108.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $320
        and (32|M0)              r1.0<1>:d     r112.0<1;1,0>:d   2147483647:d               {F@1}    //  ALU pipe: int; $321
        cmp (32|M0)   (gt)f2.0   null<1>:ud    r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $322
(f2.0)  goto (32|M0)                         _0_017            _0_017                                //  ALU pipe: int; $323
// B007: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_018:
        shr (32|M0)              r1.0<1>:ud    r112.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $325
        and (32|M0)              r5.0<1>:d     r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $326
        add3 (32|M0)             r7.0<1>:d     r5.0<1;0>:d       r112.0<1;0>:d     32767:w               {I@1} //  ALU pipe: int; $327
        shr (32|M0)              r9.0<1>:ud    r7.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $328
        mov (32|M0)              r114.0<1>:w   r9.0<2;1,0>:w                    {I@1}                //  ALU pipe: int; $329
        goto (32|M0)                         _0_017            _0_019                                // $330
// B008: [inDivergent],  Preds:{B006},  Succs:{B009}
_0_017:
        join (32|M0)                         _0_019                                                  // 
L4368:
        shr (32|M0)              r1.0<1>:ud    r112.0<1;1,0>:ud  16:w                                //  ALU pipe: int; $332
        or (32|M0)               r114.0<1>:w   r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $334
// B009: [inDivergent],  Preds:{B008, B007},  Succs:{B010}
_0_019:
        join (32|M0)                         _0_012                                                  // 
L4416:
        shl (16|M0)              r1.0<1>:q     r115.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $336
        shl (16|M16)             r5.0<1>:q     r117.0<1;1,0>:q   1:w               {Compacted}       //  ALU pipe: int; $336
        mov (32|M0)              r11.0<1>:ud   r114.0<1;1,0>:uw                 {I@4}                //  ALU pipe: int; $339
        add (16|M0)              r7.0<1>:q     r1.0<1;1,0>:q     r4.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $337
        add (16|M16)             r9.0<1>:q     r5.0<1;1,0>:q     r4.2<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $337
        store.ugm.d16u32.a64 (32|M0)  [r7:4]    r11:2              {I@1,$15} // ex_desc:0x0; desc:0x8000B84 // $340
// B010: Preds:{B009, B005, B002},  Succs:{}
_0_012:
        join (32|M0)                         L4496                                                   // 
L4496:
(W)     mov (16|M0)              r127.0<1>:f   r93.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $342
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$0} // wr:1+0, rd:0; end of thread // $342
L4520:
(W)     mov (16|M0)              null<1>:ud    0x1038AC5D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x659BDD31:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x3:ud                                                // 


//.BankConflicts: 3
//.ByteRMWs: 0
//


//.numALUInst: 326
//.accSubDef: 39
//.accSubUse: 39
//.accSubCandidateDef: 51
//.accSubCandidateUse: 51
//
//
//.singlePipeAtOneDistNum: 37
//.allAtOneDistNum: 4
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 15
//.AfterReadTokenDepCount: 3
