//.kernel _ZTSZZNK4p49c11DenseKernelILN3iq34TypeE14ELj6144ELj4ELN3p394KindE4ELj0EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS7_5eventESaISF_EEENKUlRNS7_7handlerEE_clESL_EUlNS7_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 272149597 1704713521 -hashmovs1 0 4 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 272149597 1704713521 -hashmovs1 0 4 -GRFBumpUpNumber 2 "
//.instCount 255
//.RA type	LOCAL_ROUND_ROBIN_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r86.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.15)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r2.0)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.11)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.12)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.13)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.14)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=0 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=0 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r86.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r86.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r2.0)
//.declare V0038 (48)  rf=r size=64 type=w align=32 words (r1.0)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r2.2)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r2.3)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r3.0)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r3.1)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r3.2)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r3.3)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r3.4)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r3.5)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r3.6)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r3.7)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r4.0)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r4.1)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r4.2)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r4.4)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r4.5)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r4.6)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r4.7)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0063 (73)  rf=r size=4 type=d align=2 words (r5.6)
//.declare V0064 (74)  rf=r size=4 type=d align=2 words (r5.7)
//.declare V0065 (75)  rf=r size=4 type=d align=2 words (r5.8)
//.declare V0066 (76)  rf=r size=4 type=d align=2 words (r5.9)
//.declare V0067 (77)  rf=r size=4 type=d align=2 words (r5.10)
//.declare V0068 (78)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0069 (79)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r2.0)
//.declare V0070 (80)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r86.0)
//.declare V0071 (81)  rf=r size=8 type=ud alias=V0068+0 align=4 words (r5.0)
//.declare V0072 (82)  rf=r size=8 type=d alias=V0068+0 align=4 words (r5.0)
//.declare V0073 (83)  rf=r size=4 type=d align=32 words (r6.0)
//.declare V0076 (86)  rf=r size=64 type=uw alias=V0038+0 align=32 words (r1.0)
//.declare V0081 (91)  rf=r size=128 type=d align=32 words (r87.0)
//.declare V0082 (92)  rf=r size=128 type=d align=32 words (r89.0)
//.declare V0083 (93)  rf=r size=128 type=ud alias=V0081+0 align=32 words (r87.0)
//.declare V0084 (94)  rf=r size=128 type=ud alias=V0082+0 align=32 words (r89.0)
//.declare P01 (95)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0085 (96)  rf=r size=4 type=ud alias=V0064+0 align=2 words (r5.7)
//.declare V0086 (97)  rf=r size=64 type=w align=32 words (r91.0)
//.declare V0087 (98)  rf=r size=128 type=d align=32 words (r92.0)
//.declare V0088 (99)  rf=r size=128 type=d align=32 words (r94.0)
//.declare V0089 (100)  rf=r size=128 type=ud alias=V0087+0 align=32 words (r92.0)
//.declare V0090 (101)  rf=r size=4 type=ud alias=V0063+0 align=2 words (r5.6)
//.declare V0091 (102)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0094 (105)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0095 (106)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0096 (107)  rf=r size=128 type=d align=32 words (r96.0)
//.declare V0097 (108)  rf=r size=128 type=d align=32 words (r98.0)
//.declare V0098 (109)  rf=r size=64 type=uw alias=V0086+0 align=32 words (r91.0)
//.declare V0099 (110)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0100 (111)  rf=r size=128 type=d align=32 words (r100.0)
//.declare P02 (112)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0101 (113)  rf=r size=128 type=ud alias=V0100+0 align=32 words (r100.0)
//.declare V0102 (114)  rf=r size=128 type=ud alias=V0096+0 align=32 words (r96.0)
//.declare V0103 (115)  rf=r size=128 type=f align=32 words (r102.0)
//.declare V0109 (121)  rf=r size=4 type=d align=2 words (r2.3)
//.declare V0112 (124)  rf=r size=256 type=q align=32 words (r28.0)
//.declare V0113 (125)  rf=r size=256 type=uq alias=V0112+0 align=32 words (r28.0)
//.declare V0114 (126)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0115 (127)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0116 (128)  rf=r size=128 type=d align=32 words (r44.0)
//.declare V0117 (129)  rf=r size=128 type=d align=32 words (r46.0)
//.declare V0119 (131)  rf=r size=128 type=w alias=V0114+0 align=32 words (r36.0)
//.declare V0123 (135)  rf=r size=128 type=w alias=V0115+0 align=32 words (r42.0)
//.declare V0127 (139)  rf=r size=128 type=w alias=V0116+0 align=32 words (r44.0)
//.declare V0131 (143)  rf=r size=128 type=w alias=V0117+0 align=32 words (r46.0)
//.declare V0134 (146)  rf=r size=128 type=d align=32 words (r10.0)
//.declare V0135 (147)  rf=r size=128 type=ud alias=V0134+0 align=32 words (r10.0)
//.declare V0136 (148)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0138 (150)  rf=r size=128 type=ud alias=V0136+0 align=32 words (r22.0)
//.declare V0141 (153)  rf=r size=256 type=uq align=32 words (r38.0)
//.declare V0142 (154)  rf=r size=128 type=f align=32 words (r48.0)
//.declare V0145 (157)  rf=r size=256 type=uq align=32 words (r14.0)
//.declare V0146 (158)  rf=r size=256 type=d align=32 words (r24.0)
//.declare P03 (159)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0148 (161)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0149 (162)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0150 (163)  rf=r size=128 type=f align=32 words (r62.0)
//.declare V0152 (165)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0154 (167)  rf=r size=128 type=d align=32 words (r68.0)
//.declare V0156 (169)  rf=r size=128 type=f alias=V0154+0 align=32 words (r68.0)
//.declare V0157 (170)  rf=r size=128 type=f align=32 words (r10.0)
//.declare P04 (171)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0159 (173)  rf=r size=128 type=d align=32 words (r54.0)
//.declare V0160 (174)  rf=r size=128 type=d align=32 words (r50.0)
//.declare V0161 (175)  rf=r size=256 type=ub alias=V0146+0 align=32 words (r24.0)
//.declare V0162 (176)  rf=r size=128 type=ud alias=V0160+0 align=32 words (r50.0)
//.declare V0163 (177)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0164 (178)  rf=r size=128 type=f align=32 words (r70.0)
//.declare V0166 (180)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0168 (182)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0170 (184)  rf=r size=128 type=f alias=V0168+0 align=32 words (r80.0)
//.declare V0171 (185)  rf=r size=128 type=f align=32 words (r30.0)
//.declare P05 (186)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0173 (188)  rf=r size=128 type=d align=32 words (r64.0)
//.declare V0174 (189)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0175 (190)  rf=r size=128 type=ud alias=V0174+0 align=32 words (r66.0)
//.declare V0176 (191)  rf=r size=128 type=d align=32 words (r74.0)
//.declare V0177 (192)  rf=r size=128 type=f align=32 words (r82.0)
//.declare V0179 (194)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0181 (196)  rf=r size=128 type=d align=32 words (r14.0)
//.declare V0183 (198)  rf=r size=128 type=f alias=V0181+0 align=32 words (r14.0)
//.declare V0184 (199)  rf=r size=128 type=f align=32 words (r50.0)
//.declare V0185 (200)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0186 (201)  rf=r size=256 type=ud alias=V0146+0 align=32 words (r24.0)
//.declare V0187 (202)  rf=r size=128 type=ud alias=V0185+0 align=32 words (r76.0)
//.declare P06 (203)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0188 (204)  rf=r size=128 type=d align=32 words (r78.0)
//.declare V0189 (205)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0190 (206)  rf=r size=128 type=f align=32 words (r16.0)
//.declare V0192 (208)  rf=r size=128 type=d align=32 words (r18.0)
//.declare V0194 (210)  rf=r size=128 type=d align=32 words (r32.0)
//.declare V0196 (212)  rf=r size=128 type=f alias=V0194+0 align=32 words (r32.0)
//.declare V0197 (213)  rf=r size=128 type=f align=32 words (r64.0)
//.declare P07 (214)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0199 (216)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0200 (217)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0201 (218)  rf=r size=128 type=f align=32 words (r34.0)
//.declare V0203 (220)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0205 (222)  rf=r size=128 type=d align=32 words (r52.0)
//.declare V0207 (224)  rf=r size=128 type=f alias=V0205+0 align=32 words (r52.0)
//.declare V0208 (225)  rf=r size=128 type=f align=32 words (r74.0)
//.declare P08 (226)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0210 (228)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0211 (229)  rf=r size=128 type=d align=32 words (r28.0)
//.declare V0212 (230)  rf=r size=128 type=ud alias=V0211+0 align=32 words (r28.0)
//.declare V0213 (231)  rf=r size=128 type=d align=32 words (r38.0)
//.declare V0214 (232)  rf=r size=128 type=f align=32 words (r54.0)
//.declare V0216 (234)  rf=r size=128 type=d align=32 words (r56.0)
//.declare V0218 (236)  rf=r size=128 type=d align=32 words (r66.0)
//.declare V0220 (238)  rf=r size=128 type=f alias=V0218+0 align=32 words (r66.0)
//.declare V0221 (239)  rf=r size=128 type=f align=32 words (r82.0)
//.declare P09 (240)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0223 (242)  rf=r size=128 type=d align=32 words (r40.0)
//.declare V0224 (243)  rf=r size=128 type=d align=32 words (r42.0)
//.declare V0225 (244)  rf=r size=128 type=ud alias=V0224+0 align=32 words (r42.0)
//.declare V0226 (245)  rf=r size=128 type=d align=32 words (r58.0)
//.declare V0227 (246)  rf=r size=128 type=f align=32 words (r68.0)
//.declare V0229 (248)  rf=r size=128 type=d align=32 words (r70.0)
//.declare V0231 (250)  rf=r size=128 type=d align=32 words (r76.0)
//.declare V0233 (252)  rf=r size=128 type=f alias=V0231+0 align=32 words (r76.0)
//.declare V0235 (254)  rf=r size=128 type=d align=32 words (r60.0)
//.declare V0236 (255)  rf=r size=128 type=ud alias=V0235+0 align=32 words (r60.0)
//.declare P10 (256)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0237 (257)  rf=r size=128 type=d align=32 words (r62.0)
//.declare V0238 (258)  rf=r size=128 type=d align=32 words (r72.0)
//.declare V0239 (259)  rf=r size=128 type=f align=32 words (r78.0)
//.declare V0241 (261)  rf=r size=128 type=d align=32 words (r80.0)
//.declare V0243 (263)  rf=r size=128 type=d align=32 words (r84.0)
//.declare V0245 (265)  rf=r size=128 type=f alias=V0243+0 align=32 words (r84.0)
//.declare P11 (266)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0246 (267)  rf=r size=128 type=d align=32 words (r6.0)
//.declare V0247 (268)  rf=r size=128 type=d align=32 words (r8.0)
//.declare V0248 (269)  rf=r size=128 type=f align=32 words (r11.0)
//.declare V0249 (270)  rf=r size=128 type=uw alias=V0247+0 align=32 words (r8.0)
//.declare V0250 (271)  rf=r size=64 type=uw align=32 words (r10.0)
//.declare A00 (272)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P12 (273)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare V0253 (276)  rf=r size=128 type=f align=32 words (r104.0)
//.declare V0254 (277)  rf=r size=128 type=d align=32 words (r13.0)
//.declare V0255 (278)  rf=r size=128 type=d align=32 words (r15.0)
//.declare V0256 (279)  rf=r size=128 type=f align=32 words (r18.0)
//.declare V0257 (280)  rf=r size=128 type=uw alias=V0255+0 align=32 words (r15.0)
//.declare V0258 (281)  rf=r size=64 type=uw align=32 words (r17.0)
//.declare A01 (282)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P13 (283)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare V0261 (286)  rf=r size=128 type=f align=32 words (r106.0)
//.declare V0262 (287)  rf=r size=128 type=d align=32 words (r20.0)
//.declare V0263 (288)  rf=r size=128 type=d align=32 words (r22.0)
//.declare V0264 (289)  rf=r size=128 type=f align=32 words (r25.0)
//.declare V0265 (290)  rf=r size=128 type=uw alias=V0263+0 align=32 words (r22.0)
//.declare V0266 (291)  rf=r size=64 type=uw align=32 words (r24.0)
//.declare A02 (292)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P14 (293)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0269 (296)  rf=r size=128 type=f align=32 words (r108.0)
//.declare V0270 (297)  rf=r size=128 type=d align=32 words (r27.0)
//.declare V0271 (298)  rf=r size=128 type=d align=32 words (r29.0)
//.declare V0272 (299)  rf=r size=128 type=f align=32 words (r32.0)
//.declare V0273 (300)  rf=r size=128 type=uw alias=V0271+0 align=32 words (r29.0)
//.declare V0274 (301)  rf=r size=64 type=uw align=32 words (r31.0)
//.declare A03 (302)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P15 (303)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare V0277 (306)  rf=r size=128 type=f align=32 words (r110.0)
//.declare V0278 (307)  rf=r size=128 type=d align=32 words (r34.0)
//.declare V0279 (308)  rf=r size=128 type=d align=32 words (r36.0)
//.declare V0280 (309)  rf=r size=128 type=f align=32 words (r112.0)
//.declare V0281 (310)  rf=r size=128 type=uw alias=V0279+0 align=32 words (r36.0)
//.declare V0282 (311)  rf=r size=64 type=uw align=32 words (r38.0)
//.declare A04 (312)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare P16 (313)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare V0284 (315)  rf=r size=128 type=f align=32 words (r6.0)
//.declare V0286 (317)  rf=r size=128 type=d align=32 words (r12.0)
//.declare V0294 (325)  rf=r size=256 type=uq align=32 words (r26.0)
//.declare  (326)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare  (329)  rf=r size=4 type=ud align=32 words (r4.0)
//.declare  (330)  rf=r size=128 type=uw align=32 words (r7.0)
//.declare  (331)  rf=r size=128 type=uw align=32 words (r11.0)
//.declare  (332)  rf=r size=2 type=w align=1 words (r12.0)
//.declare  (335)  rf=r size=2 type=w align=1 words (r13.0)
//.declare  (340)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (341)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (342)  rf=r size=128 type=ud align=32 words (r32.0)
//.declare  (343)  rf=r size=128 type=ud align=32 words (r34.0)
//.declare  (348)  rf=r size=128 type=q align=32 words (r9.0)
//.declare  (349)  rf=r size=128 type=q align=32 words (r13.0)
//.declare  (350)  rf=r size=128 type=q align=32 words (r114.0)
//.declare  (351)  rf=r size=128 type=q align=32 words (r116.0)
//.declare  (352)  rf=r size=128 type=d align=32 words (r6.0)
//.declare  (353)  rf=r size=128 type=d align=32 words (r8.0)
//.declare  (354)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (355)  rf=r size=128 type=q align=32 words (r12.0)
//.declare  (356)  rf=r size=128 type=q align=32 words (r118.0)
//.declare  (357)  rf=r size=128 type=q align=32 words (r120.0)
//.declare  (358)  rf=r size=128 type=q align=32 words (r122.0)
//.declare  (359)  rf=r size=128 type=q align=32 words (r124.0)
//.declare  (362)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (363)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (370)  rf=r size=128 type=q align=32 words (r8.0)
//.declare  (371)  rf=r size=128 type=q align=32 words (r10.0)
//.declare  (372)  rf=r size=128 type=d align=32 words (r14.0)
//.declare  (373)  rf=r size=128 type=d align=32 words (r16.0)
//.declare  (374)  rf=r size=128 type=q align=32 words (r18.0)
//.declare  (375)  rf=r size=128 type=q align=32 words (r20.0)
//.declare  (376)  rf=r size=128 type=q align=32 words (r22.0)
//.declare  (377)  rf=r size=128 type=q align=32 words (r24.0)
//.declare  (380)  rf=r size=128 type=uq alias=+0 align=32 words (r114.0)
//.declare  (381)  rf=r size=128 type=uq alias=+0 align=32 words (r9.0)
//.declare  (382)  rf=r size=128 type=uq alias=+0 align=32 words (r116.0)
//.declare  (383)  rf=r size=128 type=uq alias=+0 align=32 words (r13.0)
//.declare  (384)  rf=r size=128 type=d alias=+0 align=32 words (r114.0)
//.declare  (385)  rf=r size=128 type=d alias=+0 align=32 words (r116.0)
//.declare  (386)  rf=r size=128 type=d alias=+0 align=32 words (r10.0)
//.declare  (387)  rf=r size=128 type=d alias=+0 align=32 words (r12.0)
//.declare  (388)  rf=r size=128 type=d alias=+0 align=32 words (r8.0)
//.declare  (389)  rf=r size=128 type=d alias=+0 align=32 words (r10.0)
//.declare  (390)  rf=r size=128 type=d alias=+0 align=32 words (r18.0)
//.declare  (391)  rf=r size=128 type=d alias=+0 align=32 words (r20.0)
//.declare r0 (392)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (393)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (394)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (395)  rf=r size=32 type=ud align=2 words (r2.0)
//.declare  (396)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (397)  rf=r size=128 type=ud align=32 words (r3.0)
//.declare  (398)  rf=r size=64 type=ud align=32 words (r5.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 32  |   0x40 | r1       | pti[tid]+0x0     |
// | V0037    | :d x 3   |    0xC | r2       | inline+0x0       |
// | V0042    | :q       |    0x8 | r2+0x10  | inline+0x10      |
// | V0043    | :q       |    0x8 | r2+0x18  | inline+0x18      |
// | V0044    | :q       |    0x8 | r3       | cti+0x20         |
// | V0045    | :q       |    0x8 | r3+0x8   | cti+0x28         |
// | V0046    | :q       |    0x8 | r3+0x10  | cti+0x30         |
// | V0047    | :q       |    0x8 | r3+0x18  | cti+0x38         |
// | V0048    | :q       |    0x8 | r3+0x20  | cti+0x40         |
// | V0049    | :q       |    0x8 | r3+0x28  | cti+0x48         |
// | V0050    | :q       |    0x8 | r3+0x30  | cti+0x50         |
// | V0051    | :q       |    0x8 | r3+0x38  | cti+0x58         |
// | V0052    | :q       |    0x8 | r4       | cti+0x60         |
// | V0053    | :q       |    0x8 | r4+0x8   | cti+0x68         |
// | V0054    | :q       |    0x8 | r4+0x10  | cti+0x70         |
// | V0055    | :q       |    0x8 | r4+0x18  | cti+0x78         |
// | V0056    | :q       |    0x8 | r4+0x20  | cti+0x80         |
// | V0057    | :q       |    0x8 | r4+0x28  | cti+0x88         |
// | V0058    | :q       |    0x8 | r4+0x30  | cti+0x90         |
// | V0059    | :q       |    0x8 | r4+0x38  | cti+0x98         |
// | V0060    | :q       |    0x8 | r5       | cti+0xA0         |
// | V0061    | :q       |    0x8 | r5+0x8   | cti+0xA8         |
// | V0062    | :q       |    0x8 | r5+0x10  | cti+0xB0         |
// | V0063    | :d       |    0x4 | r5+0x18  | cti+0xB8         |
// | V0064    | :d       |    0x4 | r5+0x1C  | cti+0xBC         |
// | V0065    | :d       |    0x4 | r5+0x20  | cti+0xC0         |
// | V0066    | :d       |    0x4 | r5+0x24  | cti+0xC4         |
// | V0067    | :d       |    0x4 | r5+0x28  | cti+0xC8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0x40:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r2.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r1:1 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6219D500 // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r3:2 bti[255][r127:1]   {I@1,$1} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r5:1 bti[255][r127:1+0x80]  {$2} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B009}
// _main:
(W)     mov (16|M0)              r86.0<1>:ud   r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; $1
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                              {F@1}             //  ALU pipe: int; $1
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r86.2<0;1,0>:uw  {A@1}              //  ALU pipe: int; $2
(W)     macl (1|M0)              r4.0<1>:ud    r2.0<0;1,0>:ud    r86.1<0;1,0>:ud  {Compacted,$1.dst} //  ALU pipe: int; $3
(W)     mul (1|M0)               acc0.0<1>:ud  r2.0<0;1,0>:ud    r86.2<0;1,0>:uw                     //  ALU pipe: int; $3
(W)     mach (1|M0)              r6.0<1>:d     r2.0<0;1,0>:ud    r86.1<0;1,0>:ud                     //  ALU pipe: int; 
        mov (16|M0)              r7.0<4>:uw    r1.0<1;1,0>:uw                   {$0.dst}             //  ALU pipe: int; $9
        mov (16|M16)             r11.0<4>:uw   r1.16<1;1,0>:uw                                       //  ALU pipe: int; $9
        sync.nop                             null                             {Compacted,I@5}        // $3
(W)     mov (1|M0)               r5.0<2>:f     r4.0<0;1,0>:f                    {$2.dst}             //  ALU pipe: float; $3
(W)     mov (1|M0)               r5.1<2>:d     r6.0<0;1,0>:d                    {I@3}                //  ALU pipe: int; $7
        add (16|M0)              r9.0<1>:q     r5.0<0;1,0>:q     r7.0<4;1,0>:uw   {A@1}              //  ALU pipe: int; $9
        add (16|M16)             r13.0<1>:q    r5.0<0;1,0>:q     r11.0<4;1,0>:uw                     //  ALU pipe: int; $9
        shr (16|M0)              r114.0<1>:uq  r9.0<1;1,0>:uq    5:w               {I@2}             //  ALU pipe: int; $10
        shr (16|M16)             r116.0<1>:uq  r13.0<1;1,0>:uq   5:w               {I@2}             //  ALU pipe: int; $10
        mov (16|M0)              r87.0<1>:d    r114.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $11
        mov (16|M16)             r88.0<1>:d    r116.0<2;1,0>:d                  {Compacted,I@2}      //  ALU pipe: int; $11
        shr (32|M0)              r89.0<1>:ud   r87.0<1;1,0>:ud   2:w               {I@1}             //  ALU pipe: int; $12
        cmp (32|M0)   (lt)f3.0   null<1>:ud    r89.0<1;1,0>:ud   r5.7<0;1,0>:ud   {I@1}              //  ALU pipe: int; $13
(~f3.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $14
// B003: [inDivergent],  Preds:{B002},  Succs:{B004, B005}
_0_013:
(W)     mov (8|M0)               r91.0<1>:w    0x76543210:v                                          //  ALU pipe: int; $16
        and (32|M0)              r8.0<1>:d     r87.0<1;1,0>:d    3:w               {Compacted}       //  ALU pipe: int; $26
(W)     add (8|M0)               r91.8<1>:w    r91.0<1;1,0>:w    8:w               {I@2}             //  ALU pipe: int; $17
        mul (32|M0)              r10.0<1>:d    r8.0<1;1,0>:d     1536:w               {Compacted,I@2} //  ALU pipe: int; $27
(W)     add (16|M0)              r91.16<1>:w   r91.0<1;1,0>:w    16:w               {I@2}            //  ALU pipe: int; $18
        mov (32|M0)              r98.0<1>:d    r91.0<1;1,0>:uw                  {I@1}                //  ALU pipe: int; $29
        shl (32|M0)              r12.0<1>:d    r98.0<1;1,0>:d    3:w               {Compacted,I@1}   //  ALU pipe: int; $30
(W)     mul (16|M0)              acc0.0<1>:ud  r89.0<1;1,0>:ud   r5.12<0;1,0>:uw                     //  ALU pipe: int; $19
        add (32|M0)              r96.0<1>:d    r10.0<1;1,0>:d    1536:w               {Compacted}    //  ALU pipe: int; $28
        or (32|M0)               r100.0<1>:d   r12.0<1;1,0>:d    r10.0<1;1,0>:d   {Compacted,I@3}    //  ALU pipe: int; $31
        macl (16|M0)             r92.0<1>:ud   r89.0<1;1,0>:ud   r5.6<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $19
(W)     mul (16|M16)             acc0.0<1>:ud  r90.0<1;1,0>:ud   r5.12<0;1,0>:uw                     //  ALU pipe: int; $19
        macl (16|M16)            r93.0<1>:ud   r90.0<1;1,0>:ud   r5.6<0;1,0>:ud   {Compacted}        //  ALU pipe: int; $20
(W)     mul (16|M0)              acc0.0<1>:ud  r89.0<1;1,0>:ud   r5.12<0;1,0>:uw                     //  ALU pipe: int; $20
        cmp (32|M0)   (lt)f2.0   null<1>:ud    r100.0<1;1,0>:ud  r96.0<1;1,0>:ud  {I@5}              //  ALU pipe: int; $32
        mach (16|M0)             r6.0<1>:d     r89.0<1;1,0>:ud   r5.6<0;1,0>:ud                      //  ALU pipe: int; 
(W)     mul (16|M0)              acc0.0<1>:ud  r90.0<1;1,0>:ud   r5.12<0;1,0>:uw                     //  ALU pipe: int; $20
        mach (16|M16)            r7.0<1>:d     r90.0<1;1,0>:ud   r5.6<0;1,0>:ud                      //  ALU pipe: int; $25
        mov (32|M0)              r94.0<1>:f    r6.0<1;1,0>:f                    {Compacted,I@1}      //  ALU pipe: float; $25
(f2.0)  goto (32|M0)                         _0_014            _0_014                                //  ALU pipe: int; $33
// B004: [inDivergent],  Preds:{B003},  Succs:{B007}
_0_015:
        mov (32|M0)              r102.0<1>:ud  0x0:ud                              {Compacted}       //  ALU pipe: int; $35
        goto (32|M0)                         _0_014            _0_016                                // $36
// B005: [inDivergent],  Preds:{B003},  Succs:{B006}
_0_014:
        join (32|M0)                         _0_016                                                  // 
L784:
        mov (32|M0)              r6.0<1>:f     r92.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $38
        mov (32|M0)              r8.0<1>:d     r94.0<1;1,0>:d                   {Compacted,F@2}      //  ALU pipe: int; $39
        mov (16|M0)              r10.0<2>:d    r6.0<1;1,0>:d                    {F@1}                //  ALU pipe: int; $40
        mov (16|M16)             r12.0<2>:d    r7.0<1;1,0>:d                                         //  ALU pipe: int; $41
        mov (16|M0)              r10.1<2>:d    r8.0<1;1,0>:d                    {I@3}                //  ALU pipe: int; $42
        mov (16|M16)             r12.1<2>:d    r9.0<1;1,0>:d                                         //  ALU pipe: int; $43
        mov (32|M0)              r102.0<1>:f   0x0:f                               {Compacted}       //  ALU pipe: float; $47
        add (16|M0)              r118.0<1>:q   r10.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $44
        add (16|M16)             r120.0<1>:q   r12.0<1;1,0>:q    r2.2<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $44
        add (16|M0)              r122.0<1>:q   r118.0<1;1,0>:q   6144:w               {I@2}          //  ALU pipe: int; $45
        add (16|M16)             r124.0<1>:q   r120.0<1;1,0>:q   6144:w               {I@2}          //  ALU pipe: int; $45
(W)     mov (1|M0)               r2.3<1>:d     255:w                                                 //  ALU pipe: int; $46
// B006: [inDivergent],  Preds:{B006, B005},  Succs:{B007, B006}
_0_017:
        mov (16|M0)              r6.0<2>:ud    r100.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $50
        mov (16|M16)             r8.0<2>:ud    r101.0<1;1,0>:ud                 {Compacted}          //  ALU pipe: int; $50
        add (16|M0)              r14.0<1>:q    r118.0<1;1,0>:q   r6.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $70 R{} IR{}{E:3,E:3,},  R{} IR{}{O:11,O:3,},  {BC=1}
        add (16|M16)             r16.0<1>:q    r120.0<1;1,0>:q   r8.0<2;1,0>:ud   {I@2}              //  ALU pipe: int; $70 R{} IR{}{E:4,E:4,},  R{} IR{}{O:12,O:4,},  {BC=1}
        load.ugm.d32x2.a64 (32|M0)  r24:4       [r14:4]            {I@1,$3} // ex_desc:0x0; desc:0x8401580 // $72
        shr (32|M0)              r10.0<1>:ud   r100.0<1;1,0>:ud  2:w                                 //  ALU pipe: int; $64
        shl (16|M0)              r18.0<1>:q    r6.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $50
        shl (16|M16)             r20.0<1>:q    r8.0<2;1,0>:ud    1:w                                 //  ALU pipe: int; $50
        and (32|M0)              r22.0<1>:d    r10.0<1;1,0>:d    536870908:d               {I@3}     //  ALU pipe: int; $65
        add (16|M0)              r28.0<1>:q    r18.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $51
        add (16|M16)             r30.0<1>:q    r20.0<1;1,0>:q    r3.0<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $51
        mov (16|M0)              r32.0<2>:ud   r22.0<1;1,0>:ud                  {Compacted,I@3}      //  ALU pipe: int; $67
        mov (16|M16)             r34.0<2>:ud   r23.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $67
        load.ugm.d32.a64 (32|M0)  r36:2         [r28:4]            {I@3,$4} // ex_desc:0x0; desc:0x8200580 // $52
        add (16|M0)              r38.0<1>:q    r122.0<1;1,0>:q   r32.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $67
        add (16|M16)             r40.0<1>:q    r124.0<1;1,0>:q   r34.0<2;1,0>:ud  {I@2}              //  ALU pipe: int; $67
        load.ugm.d32.a64 (32|M0)  r48:2         [r38:4]            {I@1,$5} // ex_desc:0x0; desc:0x8200580 // $69
        load.ugm.d32.a64 (32|M0)  r42:2         [r28:4+0x4]        {$6} // ex_desc:0x4000; desc:0x8200580 // $53
        load.ugm.d32.a64 (32|M0)  r44:2         [r28:4+0x8]        {$7} // ex_desc:0x8000; desc:0x8200580 // $54
        load.ugm.d32.a64 (32|M0)  r46:2         [r28:4+0xC]        {$8} // ex_desc:0xC000; desc:0x8200580 // $55
(W)     mov (1|M0)               r12.0<1>:hf   0x0:hf                                                //  ALU pipe: float; $75
(W)     mov (1|M0)               r13.0<1>:hf   0xFF00:hf                                             //  ALU pipe: float; $107
        and (32|M0)   (eq)f2.0   null<1>:d     r24.0<1;1,0>:d    128:w               {$3.dst}        //  ALU pipe: int; $73
        and (32|M0)   (eq)f3.0   null<1>:d     r24.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $83
(f2.0)  sel (32|M0)              r52.0<1>:d    r12.0<0;1,0>:w    -256:w               {F@2}          //  ALU pipe: int; $75
        bfn.(s0&s1|s2) (32|M0)   r58.0<1>:ud   r24.0<1;0>:ud     r2.3<0;0>:ud      r52.0<1>:ud      {I@1} //  ALU pipe: int; $76 R{} IR{}{E:4,E:1,E:2,},  R{r2,} IR{}{O:12,O:10,},  {BC=1}
        and (32|M0)   (eq)f1.0   null<1>:d     r24.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $94
        mov (32|M0)              r50.0<1>:ud   r24.1<4;1,0>:ub                                       //  ALU pipe: int; $86
(f3.0)  sel (32|M0)              r54.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $85
        mov (32|M0)              r56.0<1>:d    r36.0<2;1,0>:uw                  {$4.dst}             //  ALU pipe: int; $79
        mov (32|M0)              r62.0<1>:f    r58.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $77
        or (32|M0)               r60.0<1>:d    r50.0<1;1,0>:d    r54.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $87
        shl (32|M0)              r68.0<1>:d    r56.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $80
        mul (32|M0)              acc0.0<1>:f   r48.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted,@1,$5.dst} //  ALU pipe: float; $78
        mov (32|M0)              r66.0<1>:ud   r24.2<4;1,0>:ub                                       //  ALU pipe: int; $97
        cmp (32|M0)   (lt)f2.0   null<1>:d     r24.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $106
(f1.0)  sel (32|M0)              r64.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $96
        mov (32|M0)              r72.0<1>:d    r36.1<2;1,0>:uw                                       //  ALU pipe: int; $90
        mov (32|M0)              r70.0<1>:f    r60.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $88
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r68.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $81
        or (32|M0)               r74.0<1>:d    r66.0<1;1,0>:d    r64.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $98
        shl (32|M0)              r80.0<1>:d    r72.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $91
        mul (32|M0)              acc2.0<1>:f   r48.0<1;1,0>:f    r70.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $89
        shr (32|M0)              r76.0<1>:ud   r24.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $105
        mov (32|M0)              r84.0<1>:d    r42.0<2;1,0>:uw                  {$6.dst}             //  ALU pipe: int; $101
(f2.0)  sel (32|M0)              r78.0<1>:d    r13.0<0;1,0>:w    0:w                                 //  ALU pipe: int; $107
        and (32|M0)   (eq)f1.0   null<1>:d     r26.0<1;1,0>:d    128:w                               //  ALU pipe: int; $115
        mov (32|M0)              r82.0<1>:f    r74.0<1;1,0>:d                   {I@6}                //  ALU pipe: float; $99
        add (32|M0)              r10.0<1>:f    r102.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $82
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r80.0<1;1,0>:f   {Compacted,I@5}    //  ALU pipe: float; $92
        shl (32|M0)              r14.0<1>:d    r84.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $102
        or (32|M0)               r6.0<1>:d     r76.0<1;1,0>:d    r78.0<1;1,0>:d   {Compacted,I@3}    //  ALU pipe: int; $108
        mul (32|M0)              acc0.0<1>:f   r48.0<1;1,0>:f    r82.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $100
        and (32|M0)   (eq)f3.0   null<1>:d     r26.0<1;1,0>:d    0x8000:uw                           //  ALU pipe: int; $125
        mov (32|M0)              r18.0<1>:d    r42.1<2;1,0>:uw                                       //  ALU pipe: int; $111
(f1.0)  sel (32|M0)              r8.0<1>:d     r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $117
        mov (32|M0)              r16.0<1>:f    r6.0<1;1,0>:d                    {I@4}                //  ALU pipe: float; $109
        add (32|M0)              r30.0<1>:f    r10.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,@4,$8.src} //  ALU pipe: float; $93
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r14.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $103
        shl (32|M0)              r32.0<1>:d    r18.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $112
        bfn.(s0&s1|s2) (32|M0)   r20.0<1>:ud   r26.0<1;0>:ud     r2.3<0;0>:ud      r8.0<1>:ud       {I@2} //  ALU pipe: int; $118 R{} IR{}{E:5,E:1,E:4,},  R{r2,} IR{}{O:13,O:4,},  {BC=1}
        mul (32|M0)              acc2.0<1>:f   r48.0<1;1,0>:f    r16.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $110 R{} IR{}{E:0,E:0,},  R{} IR{}{O:8,O:8,},  {BC=2}
        mov (32|M0)              r28.0<1>:ud   r26.1<4;1,0>:ub                                       //  ALU pipe: int; $128
        mov (32|M0)              r36.0<1>:d    r44.0<2;1,0>:uw                  {$7.dst}             //  ALU pipe: int; $121
        and (32|M0)   (eq)f2.0   null<1>:d     r26.0<1;1,0>:d    8388608:d                           //  ALU pipe: int; $136
(f3.0)  sel (32|M0)              r22.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $127
        mov (32|M0)              r34.0<1>:f    r20.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $119
        add (32|M0)              r50.0<1>:f    r30.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $104
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r32.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $113
        shl (32|M0)              r52.0<1>:d    r36.0<1;1,0>:d    16:w               {Compacted,I@3}  //  ALU pipe: int; $122
        or (32|M0)               r38.0<1>:d    r28.0<1;1,0>:d    r22.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $129
        mul (32|M0)              acc0.0<1>:f   r48.0<1;1,0>:f    r34.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $120
        mov (32|M0)              r56.0<1>:d    r44.1<2;1,0>:uw                                       //  ALU pipe: int; $132
        mov (32|M0)              r42.0<1>:ud   r26.2<4;1,0>:ub                                       //  ALU pipe: int; $139
        cmp (32|M0)   (lt)f1.0   null<1>:d     r26.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $148
(f2.0)  sel (32|M0)              r40.0<1>:d    r12.0<0;1,0>:w    -256:w                              //  ALU pipe: int; $138
        mov (32|M0)              r54.0<1>:f    r38.0<1;1,0>:d                   {I@5}                //  ALU pipe: float; $130
        add (32|M0)              r64.0<1>:f    r50.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $114
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r52.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $123
        shl (32|M0)              r66.0<1>:d    r56.0<1;1,0>:d    16:w               {Compacted,I@4}  //  ALU pipe: int; $133
        or (32|M0)               r58.0<1>:d    r42.0<1;1,0>:d    r40.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $140
        mul (32|M0)              acc2.0<1>:f   r48.0<1;1,0>:f    r54.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $131
        shr (32|M0)              r60.0<1>:ud   r26.0<1;1,0>:ud   24:w                                //  ALU pipe: int; $147
        mov (32|M0)              r70.0<1>:d    r46.0<2;1,0>:uw                  {$8.dst}             //  ALU pipe: int; $143
(f1.0)  sel (32|M0)              r62.0<1>:d    r13.0<0;1,0>:w    0:w                                 //  ALU pipe: int; $149
        mov (32|M0)              r68.0<1>:f    r58.0<1;1,0>:d                   {I@4}                //  ALU pipe: float; $141
        add (32|M0)              r74.0<1>:f    r64.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $124
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r66.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $134
        shl (32|M0)              r76.0<1>:d    r70.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $144
        or (32|M0)               r72.0<1>:d    r60.0<1;1,0>:d    r62.0<1;1,0>:d   {Compacted,I@2}    //  ALU pipe: int; $150
        mul (32|M0)              acc0.0<1>:f   r48.0<1;1,0>:f    r68.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $142
        mov (32|M0)              r78.0<1>:f    r72.0<1;1,0>:d                   {I@1}                //  ALU pipe: float; $151
        add (32|M0)              r82.0<1>:f    r74.0<1;1,0>:f    acc2.0<1;1,0>:f  {Compacted,F@4}    //  ALU pipe: float; $135
        mov (32|M0)              r80.0<1>:d    r46.1<2;1,0>:uw                                       //  ALU pipe: int; $153
        mul (32|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r76.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $145
        add (32|M0)              r100.0<1>:d   r100.0<1;1,0>:d   256:w               {Compacted}     //  ALU pipe: int; $157
        mul (32|M0)              acc2.0<1>:f   r48.0<1;1,0>:f    r78.0<1;1,0>:f   {Compacted,F@3}    //  ALU pipe: float; $152
        shl (32|M0)              r84.0<1>:d    r80.0<1;1,0>:d    16:w               {Compacted,I@2}  //  ALU pipe: int; $154
        add (32|M0)              acc0.0<1>:f   r82.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $146
        cmp (32|M0)   (lt)f0.0   null<1>:ud    r100.0<1;1,0>:ud  r96.0<1;1,0>:ud  {I@2}              //  ALU pipe: int; $158
        mul (32|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   r84.0<1;1,0>:f   {Compacted,I@2}    //  ALU pipe: float; $155
        add (32|M0)              r102.0<1>:f   acc0.0<1;1,0>:f   acc2.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $156
(f0.0)  goto.b (32|M0)                       _0_016            _0_017                                //  ALU pipe: int; $159
// B007: [inDivergent],  Preds:{B006, B004},  Succs:{B008, B009}
_0_016:
        join (32|M0)                         _0_012                                                  // 
L2240:
        add (32|M0)              r6.0<1>:d     r98.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $161
        and (32|M0)              r8.0<1>:d     r6.0<1;1,0>:d     31:w               {Compacted,I@1}  //  ALU pipe: int; $162
        shl (32|M0)              r10.0<1>:uw   r8.0<2;1,0>:uw    0x2:uw              {I@1}           //  ALU pipe: int; $163
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $164
        add (16|M0)              a0.0<1>:uw    r10.0<1;1,0>:uw   0x1980:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0103(r102.0:f); $165
        add (32|M0)              r13.0<1>:d    r98.0<1;1,0>:d    2:w               {Compacted}       //  ALU pipe: int; $174
        mov (16|M0)              r11.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $166
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $167
        add (16|M16)             a0.0<1>:uw    r10.16<1;1,0>:uw  0x1980:uw                           //  ALU pipe: int; src1 is addr of V0103(r102.0:f); $168
        and (32|M0)   (eq)f1.0   null<1>:d     r98.0<1;1,0>:d    1:w                                 //  ALU pipe: int; $170
        and (32|M0)              r15.0<1>:d    r13.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $175
        mov (16|M16)             r12.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $169
        shl (32|M0)              r17.0<1>:uw   r15.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $176
(f1.0)  sel (32|M0)              acc0.0<1>:f   r11.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $172
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $177
        add (16|M0)              a0.0<1>:uw    r17.0<1;1,0>:uw   0x1A00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0253(r104.0:f); $178
        add (32|M0)              r104.0<1>:f   r102.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $173
        add (32|M0)              r20.0<1>:d    r98.0<1;1,0>:d    4:w               {Compacted}       //  ALU pipe: int; $187
        mov (16|M0)              r18.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $179
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $180
        add (16|M16)             a0.0<1>:uw    r17.16<1;1,0>:uw  0x1A00:uw                           //  ALU pipe: int; src1 is addr of V0253(r104.0:f); $181
        and (32|M0)   (eq)f0.0   null<1>:d     r98.0<1;1,0>:d    3:w                                 //  ALU pipe: int; $183
        and (32|M0)              r22.0<1>:d    r20.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $188
        mov (16|M16)             r19.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $182
        shl (32|M0)              r24.0<1>:uw   r22.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $189
(f0.0)  sel (32|M0)              acc0.0<1>:f   r18.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $185
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $190
        add (16|M0)              a0.0<1>:uw    r24.0<1;1,0>:uw   0x1A80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0261(r106.0:f); $191
        add (32|M0)              r106.0<1>:f   r104.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $186
        add (32|M0)              r27.0<1>:d    r98.0<1;1,0>:d    8:w               {Compacted}       //  ALU pipe: int; $200
        mov (16|M0)              r25.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $192
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $193
        add (16|M16)             a0.0<1>:uw    r24.16<1;1,0>:uw  0x1A80:uw                           //  ALU pipe: int; src1 is addr of V0261(r106.0:f); $194
        and (32|M0)   (eq)f3.0   null<1>:d     r98.0<1;1,0>:d    7:w                                 //  ALU pipe: int; $196
        and (32|M0)              r29.0<1>:d    r27.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $201
        mov (16|M16)             r26.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $195
        shl (32|M0)              r31.0<1>:uw   r29.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $202
(f3.0)  sel (32|M0)              acc0.0<1>:f   r25.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $198
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $203
        add (16|M0)              a0.0<1>:uw    r31.0<1;1,0>:uw   0x1B00:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0269(r108.0:f); $204
        add (32|M0)              r108.0<1>:f   r106.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $199
        add (32|M0)              r34.0<1>:d    r98.0<1;1,0>:d    16:w               {Compacted}      //  ALU pipe: int; $213
        mov (16|M0)              r32.0<1>:ud   r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $205
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $206
        add (16|M16)             a0.0<1>:uw    r31.16<1;1,0>:uw  0x1B00:uw                           //  ALU pipe: int; src1 is addr of V0269(r108.0:f); $207
        and (32|M0)   (eq)f2.0   null<1>:d     r98.0<1;1,0>:d    15:w                                //  ALU pipe: int; $209
        and (32|M0)              r36.0<1>:d    r34.0<1;1,0>:d    31:w               {Compacted,I@5}  //  ALU pipe: int; $214
        mov (16|M16)             r33.0<1>:ud   r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $208
        shl (32|M0)              r38.0<1>:uw   r36.0<2;1,0>:uw   0x2:uw              {I@2}           //  ALU pipe: int; $215
(f2.0)  sel (32|M0)              acc0.0<1>:f   r32.0<1;1,0>:f    0x80000000:f               {I@2}    //  ALU pipe: float; $211
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $216
        add (16|M0)              a0.0<1>:uw    r38.0<1;1,0>:uw   0x1B80:uw              {I@2}        //  ALU pipe: int; src1 is addr of V0277(r110.0:f); $217
        add (32|M0)              r110.0<1>:f   r108.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $212
        cmp (32|M0)   (eq)f3.0   null<2>:w     r91.0<1;1,0>:w    0:w                                 //  ALU pipe: int; $222
        mov (16|M0)              r112.0<1>:ud  r[a0.0]<1,0>:ud                  {F@1}                //  ALU pipe: int; $218
(W)     mov (16|M0)              a0.0<1>:uw    0x0:uw                                                //  ALU pipe: int; $219
        add (16|M16)             a0.0<1>:uw    r38.16<1;1,0>:uw  0x1B80:uw                           //  ALU pipe: int; src1 is addr of V0277(r110.0:f); $220
        mov (16|M16)             r113.0<1>:ud  r[a0.0]<1,0>:ud                                       //  ALU pipe: int; $221
(~f3.0) goto (32|M0)                         _0_012            _0_012                                //  ALU pipe: int; $223
// B008: [inDivergent],  Preds:{B007},  Succs:{B009}
_0_018:
        shl (16|M0)              r8.0<1>:q     r114.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $227
        shl (16|M16)             r10.0<1>:q    r116.0<1;1,0>:q   2:w               {Compacted}       //  ALU pipe: int; $227
        and (16|M0)              r12.0<1>:d    r8.0<2;1,0>:d     268435440:d               {I@2}     //  ALU pipe: int; $228
        and (16|M16)             r13.0<1>:d    r10.0<2;1,0>:d    268435440:d               {I@2}     //  ALU pipe: int; $229
        mov (32|M0)              r16.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $231
        mov (32|M0)              r14.0<1>:d    r12.0<1;1,0>:d                   {Compacted,I@2}      //  ALU pipe: int; $230
        mov (16|M0)              r18.0<2>:d    r14.0<1;1,0>:d                   {I@1}                //  ALU pipe: int; $232
        mov (16|M16)             r20.0<2>:d    r15.0<1;1,0>:d                                        //  ALU pipe: int; $233
        mov (16|M0)              r18.1<2>:d    r16.0<1;1,0>:d                                        //  ALU pipe: int; $234
        mov (16|M16)             r20.1<2>:d    r17.0<1;1,0>:d                                        //  ALU pipe: int; $235
(f3.0)  sel (32|M0)              acc0.0<1>:f   r112.0<1;1,0>:f   0x80000000:f                        //  ALU pipe: float; $225
        add (16|M0)              r22.0<1>:q    r18.0<1;1,0>:q    r4.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $236
        add (16|M16)             r24.0<1>:q    r20.0<1;1,0>:q    r4.1<0;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $236
        add (32|M0)              r6.0<1>:f     r110.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $226
        add (16|M0)              r26.0<1>:q    r22.0<1;1,0>:q    r8.0<1;1,0>:q    {Compacted,I@2}    //  ALU pipe: int; $237
        add (16|M16)             r28.0<1>:q    r24.0<1;1,0>:q    r10.0<1;1,0>:q   {Compacted,I@2}    //  ALU pipe: int; $237
        store.ugm.d32.a64 (32|M0)  [r26:4]      r6:2               {A@1,$9} // ex_desc:0x0; desc:0x8000584 // $239
// B009: Preds:{B008, B007, B002},  Succs:{}
_0_012:
        join (32|M0)                         L3288                                                   // 
L3288:
(W)     mov (16|M0)              r127.0<1>:f   r86.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $241
(W)     send.gtwy (1|M0)         null     r127  null:0  0x0            0x02000010           {EOT,F@1,$10} // wr:1+0, rd:0; end of thread // $241
L3312:
(W)     mov (16|M0)              null<1>:ud    0x1038AC5D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x659BDD31:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x4:ud                                                // 


//.BankConflicts: 6
//.ByteRMWs: 0
//


//.numALUInst: 236
//.accSubDef: 22
//.accSubUse: 22
//.accSubCandidateDef: 28
//.accSubCandidateUse: 28
//
//
//.singlePipeAtOneDistNum: 25
//.allAtOneDistNum: 5
//.syncInstCount: 1
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 9
//.AfterReadTokenDepCount: 2
