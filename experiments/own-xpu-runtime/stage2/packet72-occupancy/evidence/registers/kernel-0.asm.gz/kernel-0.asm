//.kernel _ZTSZZNK4p49c11DenseKernelILN3iq34TypeE14ELj6144ELj4ELN3p394KindE4ELj1EE6submitERN4sycl3_V15queueESt4spanIKPvLm18446744073709551615EERKSt6vectorINS7_5eventESaISF_EEENKUlRNS7_7handlerEE_clESL_EUlNS7_7nd_itemILi1EEEE_
//.platform XE2
//.thread_config numGRF=128, numAcc=4, numSWSB=16
//.options_string "-emitCrossThreadOffR0Reloc -hashmovs 272149597 1704713521 -hashmovs1 0 5 "
//.full_options "-emitLocation -wideMulMadOpsEn -enableCoalesceScalarMoves -supportLSCImmScale 0 -samplerHeaderWA -enablePreemptionR0Only -hasRNEandDenorm -noStitchExternFunc -useInlineData -emitCrossThreadOffR0Reloc -abortOnSpill 4 -enableBCR -enableBundleCR 3 -freqBasedSpillCost 8 -freqBasedSpillCostFunc 1 -boundsChecking -presched-ctrl 6 -presched-rp 100 -nodpsendreorder -SBIDDepLoc -PVCSendWARWA -output -binary -dumpcommonisa -dumpcombinedcisa -dumpvisa -printHexFloatInAsm -noverifyCISA -enableHalfLSC -partialInt64 -activeThreadsOnlyBarrier -hashmovs 272149597 1704713521 -hashmovs1 0 5 -GRFBumpUpNumber 2 "
//.instCount 1408
//.RA type	GRAPH_COLORING_FF_RA
//.git-hash 5cebb69c84658ac2befba89f81c5ce9022f02f68
//.spill size 192

//.declare BuiltInR0 (0)  rf=r size=64 type=ud align=32 words (r0.0) IsBuiltin
//.declare  (1)  rf=r size=64 type=ud align=32 words (r125.0) IsBuiltin
//.declare BuiltinA0 (2)  rf=a size=4 type=ud align=1 words (a0.0) IsBuiltin
//.declare BuiltinA0Dot2 (3)  rf=a size=4 type=ud align=1 words (a0.2) IsBuiltin
//.declare BuiltinSR0Dot1 (5)  rf=r size=4 type=ud align=2 words IsBuiltin
//.declare %null (10)  rf=r size=4 type=ud align=2 words
//.declare %local_id_x (13)  rf=r size=4 type=ud align=2 words (r1.4)
//.declare %local_id_y (14)  rf=r size=4 type=ud align=2 words (r1.5)
//.declare %local_size_x (15)  rf=r size=4 type=ud align=2 words (r1.0)
//.declare %local_size_y (16)  rf=r size=4 type=ud align=2 words (r1.1)
//.declare %group_id_x (17)  rf=r size=4 type=ud align=2 words (r0.1)
//.declare %group_id_y (18)  rf=r size=4 type=ud align=2 words (r0.6)
//.declare %group_id_z (19)  rf=r size=4 type=ud align=2 words (r0.7)
//.declare %group_count_x (20)  rf=r size=4 type=ud align=2 words (r1.2)
//.declare %group_count_y (21)  rf=r size=4 type=ud align=2 words (r1.3)
//.declare %tsc (22)  rf=r size=20 type=ud align=2 words
//.declare %arg (23)  rf=r size=192 type=ud align=32 words (r26.0)
//.declare %retval (24)  rf=r size=64 type=ud align=32 words (r26.0) Output
//.declare %sp (25)  rf=r size=8 type=uq align=4 words (r127.3)
//.declare %fp (26)  rf=r size=8 type=uq align=4 words (r127.2)
//.declare %sr0 (27)  rf=r size=16 type=ud align=2 words
//.declare %cr0 (28)  rf=r size=12 type=ud align=2 words
//.declare %ce0 (29)  rf=r size=4 type=ud align=2 words
//.declare %dbg0 (30)  rf=r size=8 type=ud align=2 words
//.declare implBufPtr (32)  rf=r size=8 type=uq align=4 words (r126.0)
//.declare localIdBufPtr (33)  rf=r size=8 type=uq align=4 words (r126.3)
//.declare %msg0 (34)  rf=r size=12 type=ud align=2 words
//.declare %scratchloc (35)  rf=r size=8 type=uq align=4 words (s0.7)
//.declare V0033 (43)  rf=r size=64 type=d alias=+0 align=32 words (r125.0)
//.declare V0035 (45)  rf=r size=32 type=d alias=+0 align=32 words (r125.0)
//.declare V0037 (47)  rf=r size=12 type=d align=2 words (r4.0)
//.declare V0038 (48)  rf=r size=32 type=w align=16 words (r1.0)
//.declare V0039 (49)  rf=r size=32 type=w align=16 words (r2.0)
//.declare V0040 (50)  rf=r size=32 type=w align=16 words (r3.0)
//.declare V0041 (51)  rf=r size=8 type=uq align=4 words (r7.7)
//.declare V0042 (52)  rf=r size=8 type=q align=4 words (r4.3)
//.declare V0043 (53)  rf=r size=8 type=q align=4 words (r5.0)
//.declare V0044 (54)  rf=r size=8 type=q align=4 words (r5.1)
//.declare V0045 (55)  rf=r size=8 type=q align=4 words (r5.2)
//.declare V0046 (56)  rf=r size=8 type=q align=4 words (r5.3)
//.declare V0047 (57)  rf=r size=8 type=q align=4 words (r5.4)
//.declare V0048 (58)  rf=r size=8 type=q align=4 words (r5.5)
//.declare V0049 (59)  rf=r size=8 type=q align=4 words (r5.6)
//.declare V0050 (60)  rf=r size=8 type=q align=4 words (r5.7)
//.declare V0051 (61)  rf=r size=8 type=q align=4 words (r6.0)
//.declare V0052 (62)  rf=r size=8 type=q align=4 words (r6.1)
//.declare V0053 (63)  rf=r size=8 type=q align=4 words (r6.2)
//.declare V0054 (64)  rf=r size=8 type=q align=4 words (r6.3)
//.declare V0055 (65)  rf=r size=8 type=q align=4 words (r6.4)
//.declare V0056 (66)  rf=r size=8 type=q align=4 words (r6.5)
//.declare V0057 (67)  rf=r size=8 type=q align=4 words (r6.6)
//.declare V0058 (68)  rf=r size=8 type=q align=4 words (r6.7)
//.declare V0059 (69)  rf=r size=8 type=q align=4 words (r7.0)
//.declare V0060 (70)  rf=r size=8 type=q align=4 words (r7.1)
//.declare V0061 (71)  rf=r size=8 type=q align=4 words (r7.2)
//.declare V0062 (72)  rf=r size=8 type=q align=4 words (r7.3)
//.declare V0063 (73)  rf=r size=4 type=d align=2 words (r7.8)
//.declare V0064 (74)  rf=r size=4 type=d align=2 words (r7.9)
//.declare V0065 (75)  rf=r size=4 type=d align=2 words (r7.10)
//.declare V0066 (76)  rf=r size=4 type=d align=2 words (r7.11)
//.declare V0067 (77)  rf=r size=4 type=d align=2 words (r7.12)
//.declare V0069 (79)  rf=r size=768 type=d alias=%arg+0 align=32 words (r26.0)
//.declare V0071 (81)  rf=r size=512 type=d alias=%retval+0 align=32 words (r26.0)
//.declare V0073 (83)  rf=r size=8 type=uq alias=%sp+0 align=32 words (r127.3)
//.declare V0075 (85)  rf=r size=8 type=uq alias=%fp+0 align=32 words (r127.2)
//.declare V0076 (86)  rf=r size=4 type=ud align=2 words (r1.9)
//.declare V0078 (88)  rf=r size=4 type=ud align=2 words (r1.10)
//.declare V0080 (90)  rf=r size=4 type=ud align=2 words (r1.12)
//.declare V0081 (91)  rf=r size=4 type=ud align=2 words (r1.11)
//.declare V0082 (92)  rf=r size=4 type=ud align=32 words (r5.0)
//.declare V0084 (94)  rf=r size=8 type=uq align=32 words (r5.0)
//.declare V0085 (95)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0086 (96)  rf=r size=4 type=ud align=2 words (r4.4)
//.declare V0087 (97)  rf=r size=8 type=uq align=4 words (r63.0)
//.declare V0088 (98)  rf=r size=8 type=uq alias=V0062+0 align=4 words (r7.3)
//.declare V0089 (99)  rf=r size=8 type=q align=4 words (r1.4)
//.declare V0090 (100)  rf=r size=12 type=ud alias=V0037+0 align=2 words (r4.0)
//.declare V0091 (101)  rf=r size=32 type=ud alias=V0035+0 align=16 words (r125.0)
//.declare V0092 (102)  rf=r size=8 type=ud alias=V0089+0 align=4 words (r1.8)
//.declare V0093 (103)  rf=r size=8 type=d alias=V0089+0 align=4 words (r1.8)
//.declare V0094 (104)  rf=r size=4 type=d align=32 words (r5.0)
//.declare V0096 (106)  rf=r size=128 type=q align=32 words (r10.0)
//.declare V0097 (107)  rf=r size=32 type=uw alias=V0038+0 align=16 words (r1.0)
//.declare V0098 (108)  rf=r size=128 type=q align=32 words (r66.0)
//.declare V0099 (109)  rf=r size=64 type=d align=32 words (r68.0)
//.declare V0100 (110)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0101 (111)  rf=r size=4 type=d align=32 words (r5.0)
//.declare P01 (112)  rf=f16  size=2 type=uw align=1 words (f0.0)
//.declare V0102 (113)  rf=r size=8 type=uq alias=V0061+0 align=4 words (r7.2)
//.declare V0103 (114)  rf=r size=8 type=uq align=32 words (r6.0)
//.declare V0104 (115)  rf=r size=64 type=d align=32 words (r2.0)
//.declare V0105 (116)  rf=r size=128 type=uq align=32 words (r8.0)
//.declare V0106 (117)  rf=r size=128 type=ud alias=V0105+0 align=32 words (r8.0)
//.declare V0107 (118)  rf=r size=8 type=ud alias=V0103+0 align=32 words (r6.0)
//.declare V0108 (119)  rf=r size=64 type=d align=32 words (r2.0)
//.declare V0109 (120)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare V0110 (121)  rf=r size=64 type=ud alias=V0104+0 align=32 words (r2.0)
//.declare P02 (122)  rf=f16  size=2 type=uw align=1 words (f0.1)
//.declare P03 (123)  rf=f16  size=2 type=uw align=1 words (f1.0)
//.declare V0111 (124)  rf=r size=64 type=d align=32 words (r60.0)
//.declare  (125)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0112 (126)  rf=r size=128 type=q align=32 words (r2.0)
//.declare V0115 (129)  rf=r size=128 type=uq align=32 words (r8.0)
//.declare V0117 (131)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare V0118 (132)  rf=r size=64 type=w alias=V0117+0 align=32 words (r2.0)
//.declare V0119 (133)  rf=r size=64 type=d align=32 words (r2.0)
//.declare V0120 (134)  rf=r size=64 type=f align=32 words (r60.0)
//.declare V0121 (135)  rf=r size=64 type=f alias=V0119+0 align=32 words (r2.0)
//.declare V0122 (136)  rf=r size=64 type=d align=32 words (r2.0)
//.declare V0123 (137)  rf=r size=64 type=d alias=V0120+0 align=32 words (r60.0)
//.declare P04 (138)  rf=f16  size=2 type=uw align=1 words (f3.1)
//.declare V0124 (139)  rf=r size=64 type=ud alias=V0122+0 align=32 words (r2.0)
//.declare P05 (140)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare P06 (141)  rf=f16  size=2 type=uw align=1 words (f2.1)
//.declare P07 (142)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0125 (143)  rf=r size=64 type=f align=32 words (r2.0)
//.declare P08 (144)  rf=f16  size=2 type=uw align=1 words (f1.1)
//.declare V0127 (146)  rf=r size=64 type=d align=32 words (r65.0)
//.declare V0128 (147)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0129 (148)  rf=r size=64 type=f align=32 words (r61.0)
//.declare V0132 (151)  rf=r size=768 type=f alias=V0069+0 align=32 words (r26.0)
//.declare V0133 (152)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0134 (153)  rf=r size=512 type=f alias=V0071+0 align=32 words (r26.0)
//.declare V0136 (155)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0138 (157)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0142 (161)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0146 (165)  rf=r size=64 type=f align=32 words (r60.0)
//.declare V0149 (168)  rf=r size=64 type=f align=32 words (r61.0)
//.declare V0150 (169)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0153 (172)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0155 (174)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0157 (176)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0161 (180)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0165 (184)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0167 (186)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0168 (187)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0171 (190)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0173 (192)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0175 (194)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0179 (198)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0183 (202)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0185 (204)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0186 (205)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0189 (208)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0191 (210)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0193 (212)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0197 (216)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0201 (220)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0203 (222)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0204 (223)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0207 (226)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0209 (228)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0211 (230)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0215 (234)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0219 (238)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0221 (240)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0222 (241)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0225 (244)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0227 (246)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0229 (248)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0233 (252)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0237 (256)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0239 (258)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0240 (259)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0243 (262)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0245 (264)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0247 (266)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0251 (270)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0255 (274)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0257 (276)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0258 (277)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0261 (280)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0263 (282)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0265 (284)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0269 (288)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0273 (292)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0275 (294)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0276 (295)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0279 (298)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0281 (300)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0283 (302)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0287 (306)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0291 (310)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0293 (312)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0294 (313)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0297 (316)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0299 (318)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0301 (320)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0305 (324)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0309 (328)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0311 (330)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0312 (331)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0315 (334)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0317 (336)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0319 (338)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0323 (342)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0327 (346)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0329 (348)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0330 (349)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0333 (352)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0335 (354)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0337 (356)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0341 (360)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0345 (364)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0347 (366)  rf=r size=64 type=f align=32 words (r69.0)
//.declare V0348 (367)  rf=r size=64 type=f align=32 words (r64.0)
//.declare V0351 (370)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0353 (372)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0355 (374)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0359 (378)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0363 (382)  rf=r size=64 type=f align=32 words (r60.0)
//.declare V0366 (385)  rf=r size=64 type=f align=32 words (r64.0)
//.declare P09 (386)  rf=f16  size=2 type=uw align=1 words (f1.1)
//.declare P10 (387)  rf=f16  size=2 type=uw align=1 words (f1.0)
//.declare V0367 (388)  rf=r size=64 type=d align=32 words (r61.0)
//.declare V0368 (389)  rf=r size=64 type=f alias=V0367+0 align=32 words (r61.0)
//.declare V0369 (390)  rf=r size=64 type=f align=32 words (r61.0)
//.declare V0372 (393)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0374 (395)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0376 (397)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0380 (401)  rf=r size=64 type=f align=32 words (r60.0)
//.declare V0381 (402)  rf=r size=64 type=d alias=V0380+0 align=32 words (r60.0)
//.declare V0382 (403)  rf=r size=64 type=d align=32 words (r61.0)
//.declare V0383 (404)  rf=r size=64 type=f alias=V0382+0 align=32 words (r61.0)
//.declare V0384 (405)  rf=r size=64 type=f align=32 words (r62.0)
//.declare V0387 (408)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0389 (410)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0391 (412)  rf=r size=4 type=ud align=32 words (r127.0)
//.declare V0392 (413)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0396 (417)  rf=r size=64 type=ud alias=V0380+0 align=32 words (r60.0)
//.declare V0397 (418)  rf=r size=64 type=f align=32 words (r4.0)
//.declare V0398 (419)  rf=r size=64 type=f align=32 words (r3.0)
//.declare V0401 (422)  rf=r size=64 type=f align=32 words (r4.0)
//.declare V0402 (423)  rf=r size=64 type=f align=32 words (r2.0)
//.declare P11 (424)  rf=f16  size=2 type=uw align=1 words (f0.1)
//.declare P12 (425)  rf=f16  size=2 type=uw align=1 words (f0.0)
//.declare V0405 (428)  rf=r size=64 type=f align=32 words (r2.0)
//.declare P13 (429)  rf=f16  size=2 type=uw align=1 words (f3.1)
//.declare P14 (430)  rf=f16  size=2 type=uw align=1 words (f0.0)
//.declare P15 (432)  rf=f16  size=2 type=uw align=1 words (f0.1)
//.declare V0407 (433)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0408 (434)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0409 (435)  rf=r size=64 type=ud alias=V0408+0 align=32 words (r1.0)
//.declare  (436)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (437)  rf=r size=32 type=ud align=32 words (r7.0)
//.declare P16 (438)  rf=f16  size=2 type=uw align=1 words (f3.0)
//.declare V0410 (439)  rf=r size=64 type=ud alias=V0099+0 align=32 words (r68.0)
//.declare V0411 (440)  rf=r size=4 type=ud alias=V0064+0 align=2 words (r7.9)
//.declare V0412 (441)  rf=r size=128 type=q align=32 words (r2.0)
//.declare V0413 (442)  rf=r size=128 type=q align=32 words (r4.0)
//.declare V0414 (443)  rf=r size=128 type=d alias=V0413+0 align=32 words (r4.0)
//.declare V0415 (444)  rf=r size=128 type=d alias=V0412+0 align=32 words (r2.0)
//.declare V0418 (447)  rf=r size=128 type=uq align=32 words (r2.0)
//.declare V0419 (448)  rf=r size=256 type=f align=32 words (r8.0)
//.declare V0420 (449)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0422 (451)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0423 (452)  rf=r size=64 type=d alias=V0420+0 align=32 words (r2.0)
//.declare P17 (453)  rf=f16  size=2 type=uw align=1 words (f2.1)
//.declare V0424 (454)  rf=r size=64 type=ud alias=V0422+0 align=32 words (r1.0)
//.declare V0425 (455)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0426 (456)  rf=r size=64 type=ud alias=V0420+0 align=32 words (r2.0)
//.declare V0427 (457)  rf=r size=64 type=ud alias=V0425+0 align=32 words (r1.0)
//.declare V0428 (458)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0429 (459)  rf=r size=64 type=ud alias=V0428+0 align=32 words (r1.0)
//.declare V0430 (460)  rf=r size=32 type=w align=32 words (r7.0)
//.declare V0431 (461)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0432 (462)  rf=r size=64 type=ud alias=V0431+0 align=32 words (r1.0)
//.declare V0434 (464)  rf=r size=128 type=q align=32 words (r2.0)
//.declare V0437 (467)  rf=r size=128 type=uq align=32 words (r4.0)
//.declare V0438 (468)  rf=r size=32 type=uw alias=V0430+0 align=32 words (r7.0)
//.declare V0439 (469)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare P18 (470)  rf=f16  size=2 type=uw align=1 words (f2.0)
//.declare V0440 (471)  rf=r size=64 type=d align=32 words (r4.0)
//.declare V0441 (472)  rf=r size=128 type=q align=32 words (r8.0)
//.declare V0442 (473)  rf=r size=128 type=d alias=V0441+0 align=32 words (r8.0)
//.declare V0443 (474)  rf=r size=128 type=d alias=V0434+0 align=32 words (r2.0)
//.declare V0446 (477)  rf=r size=128 type=uq align=32 words (r10.0)
//.declare V0448 (479)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare V0449 (480)  rf=r size=64 type=w alias=V0448+0 align=32 words (r1.0)
//.declare V0450 (481)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0451 (482)  rf=r size=4 type=f align=32 words (r6.0)
//.declare V0452 (483)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare V0453 (484)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0454 (485)  rf=r size=64 type=f alias=V0440+0 align=32 words (r4.0)
//.declare V0455 (486)  rf=r size=64 type=f alias=V0450+0 align=32 words (r1.0)
//.declare V0456 (487)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0457 (488)  rf=r size=64 type=d alias=V0453+0 align=32 words (r2.0)
//.declare P19 (489)  rf=f16  size=2 type=uw align=1 words (f1.1)
//.declare V0458 (490)  rf=r size=64 type=ud alias=V0456+0 align=32 words (r1.0)
//.declare V0459 (491)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0460 (492)  rf=r size=64 type=ud alias=V0453+0 align=32 words (r2.0)
//.declare V0461 (493)  rf=r size=64 type=ud alias=V0459+0 align=32 words (r1.0)
//.declare V0462 (494)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0463 (495)  rf=r size=64 type=ud alias=V0462+0 align=32 words (r1.0)
//.declare V0464 (496)  rf=r size=32 type=w align=32 words (r6.0)
//.declare V0465 (497)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0466 (498)  rf=r size=64 type=ud alias=V0465+0 align=32 words (r1.0)
//.declare V0468 (500)  rf=r size=32 type=uw alias=V0464+0 align=32 words (r6.0)
//.declare V0469 (501)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare V0470 (502)  rf=r size=64 type=d align=32 words (r2.0)
//.declare V0472 (504)  rf=r size=64 type=ud alias=V0470+0 align=32 words (r2.0)
//.declare V0473 (505)  rf=r size=128 type=q align=32 words (r2.0)
//.declare V0476 (508)  rf=r size=128 type=uq align=32 words (r8.0)
//.declare V0478 (510)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare V0479 (511)  rf=r size=64 type=w alias=V0478+0 align=32 words (r1.0)
//.declare V0480 (512)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0481 (513)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare V0482 (514)  rf=r size=4 type=f align=32 words (r6.0)
//.declare V0483 (515)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0484 (516)  rf=r size=64 type=f alias=V0480+0 align=32 words (r1.0)
//.declare V0485 (517)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0486 (518)  rf=r size=64 type=d alias=V0483+0 align=32 words (r2.0)
//.declare P20 (519)  rf=f16  size=2 type=uw align=1 words (f1.0)
//.declare V0487 (520)  rf=r size=64 type=ud alias=V0485+0 align=32 words (r1.0)
//.declare V0488 (521)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0489 (522)  rf=r size=64 type=ud alias=V0483+0 align=32 words (r2.0)
//.declare V0490 (523)  rf=r size=64 type=ud alias=V0488+0 align=32 words (r1.0)
//.declare V0491 (524)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0492 (525)  rf=r size=64 type=ud alias=V0491+0 align=32 words (r1.0)
//.declare V0493 (526)  rf=r size=32 type=w align=32 words (r6.0)
//.declare V0494 (527)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0495 (528)  rf=r size=64 type=ud alias=V0494+0 align=32 words (r1.0)
//.declare V0497 (530)  rf=r size=32 type=uw alias=V0493+0 align=32 words (r6.0)
//.declare V0498 (531)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare V0499 (532)  rf=r size=4 type=d align=2 words (r6.0)
//.declare V0500 (533)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0502 (535)  rf=r size=64 type=ud alias=V0500+0 align=32 words (r1.0)
//.declare V0503 (536)  rf=r size=128 type=q align=32 words (r10.0)
//.declare V0506 (539)  rf=r size=128 type=uq align=32 words (r8.0)
//.declare V0508 (541)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare V0509 (542)  rf=r size=64 type=w alias=V0508+0 align=32 words (r1.0)
//.declare V0510 (543)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0511 (544)  rf=r size=4 type=ud align=32 words (r7.0)
//.declare V0512 (545)  rf=r size=4 type=f align=32 words (r6.0)
//.declare V0513 (546)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0514 (547)  rf=r size=64 type=f alias=V0510+0 align=32 words (r1.0)
//.declare V0515 (548)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0516 (549)  rf=r size=64 type=d alias=V0513+0 align=32 words (r2.0)
//.declare P21 (550)  rf=f16  size=2 type=uw align=1 words (f0.1)
//.declare V0517 (551)  rf=r size=64 type=ud alias=V0515+0 align=32 words (r1.0)
//.declare V0518 (552)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0519 (553)  rf=r size=64 type=ud alias=V0513+0 align=32 words (r2.0)
//.declare V0520 (554)  rf=r size=64 type=ud alias=V0518+0 align=32 words (r1.0)
//.declare V0521 (555)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0522 (556)  rf=r size=64 type=ud alias=V0521+0 align=32 words (r1.0)
//.declare V0523 (557)  rf=r size=32 type=w align=32 words (r6.0)
//.declare V0524 (558)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0525 (559)  rf=r size=64 type=ud alias=V0524+0 align=32 words (r1.0)
//.declare V0527 (561)  rf=r size=32 type=uw alias=V0523+0 align=32 words (r6.0)
//.declare V0528 (562)  rf=r size=64 type=ud align=32 words (r2.0)
//.declare V0529 (563)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0531 (565)  rf=r size=64 type=ud alias=V0529+0 align=32 words (r1.0)
//.declare V0532 (566)  rf=r size=128 type=q align=32 words (r2.0)
//.declare V0535 (569)  rf=r size=128 type=uq align=32 words (r8.0)
//.declare V0537 (571)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare V0538 (572)  rf=r size=64 type=w alias=V0537+0 align=32 words (r1.0)
//.declare V0539 (573)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0540 (574)  rf=r size=4 type=ud align=32 words (r6.0)
//.declare V0541 (575)  rf=r size=4 type=f align=32 words (r6.0)
//.declare V0542 (576)  rf=r size=64 type=f align=32 words (r2.0)
//.declare V0543 (577)  rf=r size=64 type=f alias=V0539+0 align=32 words (r1.0)
//.declare V0544 (578)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0545 (579)  rf=r size=64 type=d alias=V0542+0 align=32 words (r2.0)
//.declare P22 (580)  rf=f16  size=2 type=uw align=1 words (f0.0)
//.declare V0546 (581)  rf=r size=64 type=ud alias=V0544+0 align=32 words (r1.0)
//.declare V0547 (582)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0548 (583)  rf=r size=64 type=ud alias=V0542+0 align=32 words (r2.0)
//.declare V0549 (584)  rf=r size=64 type=ud alias=V0547+0 align=32 words (r1.0)
//.declare V0550 (585)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0551 (586)  rf=r size=64 type=ud alias=V0550+0 align=32 words (r1.0)
//.declare V0552 (587)  rf=r size=32 type=w align=32 words (r3.0)
//.declare V0553 (588)  rf=r size=64 type=d align=32 words (r1.0)
//.declare V0554 (589)  rf=r size=64 type=ud alias=V0553+0 align=32 words (r1.0)
//.declare V0556 (591)  rf=r size=32 type=uw alias=V0552+0 align=32 words (r3.0)
//.declare V0557 (592)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (593)  rf=r size=4 type=ud alias=SR+28 align=2 words (r126.7) Output
//.declare  (594)  rf=r size=64 type=ud align=32 words (r112.0)
//.declare  (595)  rf=r size=64 type=w alias=V0431+0 align=32 words (r1.0)
//.declare  (596)  rf=r size=64 type=w alias=V0465+0 align=32 words (r1.0)
//.declare  (597)  rf=r size=64 type=w alias=V0494+0 align=32 words (r1.0)
//.declare  (598)  rf=r size=64 type=w alias=V0524+0 align=32 words (r1.0)
//.declare  (599)  rf=r size=64 type=w alias=V0553+0 align=32 words (r1.0)
//.declare  (600)  rf=r size=4 type=d align=2 words (r1.8)
//.declare  (601)  rf=r size=128 type=d alias=V0098+0 align=32 words (r66.0)
//.declare  (602)  rf=r size=4 type=ud align=32 words (r5.0)
//.declare  (603)  rf=r size=128 type=uw align=32 words (r2.0)
//.declare  (604)  rf=r size=4 type=f align=2 words (r1.8)
//.declare  (605)  rf=r size=64 type=w alias=V0428+0 align=32 words (r1.0)
//.declare  (606)  rf=r size=64 type=w alias=V0462+0 align=32 words (r1.0)
//.declare  (607)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (608)  rf=r size=64 type=w alias=V0491+0 align=32 words (r1.0)
//.declare  (609)  rf=r size=128 type=ud align=32 words (r2.0)
//.declare  (610)  rf=r size=64 type=w alias=V0521+0 align=32 words (r1.0)
//.declare  (611)  rf=r size=128 type=ud align=32 words (r8.0)
//.declare  (612)  rf=r size=64 type=w alias=V0550+0 align=32 words (r1.0)
//.declare  (613)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (614)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (615)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (616)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (617)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (618)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (619)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (620)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (621)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (622)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (623)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (624)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (625)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (626)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (627)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (628)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (629)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (630)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (631)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (632)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (633)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (634)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (635)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (636)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (637)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (638)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (639)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (640)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (641)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (642)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (643)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (644)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (645)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (646)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (647)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (648)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (649)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (650)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (651)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (652)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (653)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (654)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (655)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (656)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare  (657)  rf=r size=8 type=ud align=2 words (r127.0)
//.declare be_fp (658)  rf=r size=4 type=ud align=2 words (r127.3)
//.declare be_sp (659)  rf=r size=4 type=ud align=2 words (r127.2)
//.declare SR (660)  rf=r size=64 type=ud align=32 words (r126.0)
//.declare VCE_SAVE (661)  rf=r size=4160 type=ud align=32 words (r60.0)
//.declare  (662)  rf=r size=3776 type=ud align=32 words
//.declare  (663)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (664)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (665)  rf=r size=3776 type=ud align=32 words
//.declare  (666)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (667)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (668)  rf=r size=3776 type=ud align=32 words
//.declare  (669)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (670)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (671)  rf=r size=3776 type=ud align=32 words
//.declare  (672)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (673)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (674)  rf=r size=3776 type=ud align=32 words
//.declare  (675)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (676)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (677)  rf=r size=3776 type=ud align=32 words
//.declare  (678)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (679)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (680)  rf=r size=3776 type=ud align=32 words
//.declare  (681)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (682)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (683)  rf=r size=3776 type=ud align=32 words
//.declare  (684)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (685)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (686)  rf=r size=3776 type=ud align=32 words
//.declare  (687)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (688)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (689)  rf=r size=3776 type=ud align=32 words
//.declare  (690)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (691)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (692)  rf=r size=3776 type=ud align=32 words
//.declare  (693)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (694)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (695)  rf=r size=3776 type=ud align=32 words
//.declare  (696)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (697)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (698)  rf=r size=3776 type=ud align=32 words
//.declare  (699)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (700)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (701)  rf=r size=3776 type=ud align=32 words
//.declare  (702)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (703)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (704)  rf=r size=3776 type=ud align=32 words
//.declare  (705)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (706)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (707)  rf=r size=3776 type=ud align=32 words
//.declare  (708)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (709)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (710)  rf=r size=3776 type=ud align=32 words
//.declare  (711)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (712)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (713)  rf=r size=3776 type=ud align=32 words
//.declare  (714)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (715)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (716)  rf=r size=3776 type=ud align=32 words
//.declare  (717)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (718)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (719)  rf=r size=3776 type=ud align=32 words
//.declare  (720)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (721)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (722)  rf=r size=3776 type=ud align=32 words
//.declare  (723)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (724)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (725)  rf=r size=3776 type=ud align=32 words
//.declare  (726)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (727)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (728)  rf=r size=3776 type=ud align=32 words
//.declare  (729)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (730)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (731)  rf=r size=3776 type=ud align=32 words
//.declare  (732)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (733)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (734)  rf=r size=3776 type=ud align=32 words
//.declare  (735)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (736)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (737)  rf=r size=3776 type=ud align=32 words
//.declare  (738)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (739)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (740)  rf=r size=3776 type=ud align=32 words
//.declare  (741)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (742)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (743)  rf=r size=3776 type=ud align=32 words
//.declare  (744)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (745)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (746)  rf=r size=3776 type=ud align=32 words
//.declare  (747)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (748)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (749)  rf=r size=3776 type=ud align=32 words
//.declare  (750)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (751)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (752)  rf=r size=3776 type=ud align=32 words
//.declare  (753)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (754)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (755)  rf=r size=3776 type=ud align=32 words
//.declare  (756)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (757)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (758)  rf=r size=3776 type=ud align=32 words
//.declare  (759)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (760)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (761)  rf=r size=3776 type=ud align=32 words
//.declare  (762)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (763)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (764)  rf=r size=3776 type=ud align=32 words
//.declare  (765)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (766)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (767)  rf=r size=3776 type=ud align=32 words
//.declare  (768)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (769)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (770)  rf=r size=3776 type=ud align=32 words
//.declare  (771)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (772)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (773)  rf=r size=3776 type=ud align=32 words
//.declare  (774)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (775)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (776)  rf=r size=3776 type=ud align=32 words
//.declare  (777)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (778)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (779)  rf=r size=3776 type=ud align=32 words
//.declare  (780)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (781)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (782)  rf=r size=3776 type=ud align=32 words
//.declare  (783)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (784)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (785)  rf=r size=3776 type=ud align=32 words
//.declare  (786)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (787)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (788)  rf=r size=3776 type=ud align=32 words
//.declare  (789)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (790)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (791)  rf=r size=3776 type=ud align=32 words
//.declare  (792)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (793)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (794)  rf=r size=3776 type=ud align=32 words
//.declare  (795)  rf=a size=32 type=uw align=1 words (a0.0)
//.declare  (796)  rf=f128  size=16 type=uw align=1 words (f0.0)
//.declare  (797)  rf=f32  size=4 type=uw align=2 words (f0.0)
//.declare  (798)  rf=f32  size=4 type=uw align=2 words (f1.0)
//.declare  (799)  rf=f32  size=4 type=uw align=2 words (f2.0)
//.declare  (800)  rf=f32  size=4 type=uw align=2 words (f3.0)
//.declare  (801)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (802)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (803)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (804)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (805)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (806)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (807)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (808)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (809)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (810)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (811)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (812)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (813)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (814)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (815)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (816)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (817)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (818)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (819)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (820)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (821)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (822)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (823)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (824)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (825)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (826)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (827)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (828)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (829)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (830)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (831)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (832)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (833)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (834)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (835)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (836)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (837)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (838)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (839)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (840)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (841)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (842)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (843)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (844)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (845)  rf=r size=64 type=ud align=32 words (r26.0)
//.declare  (850)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (851)  rf=r size=4 type=ud align=32 words NoSpill Input_Output
//.declare  (852)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (853)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (854)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (855)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (856)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (857)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (858)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (859)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (860)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (861)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (862)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (863)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (864)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (865)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (866)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (867)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (868)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (869)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (870)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (871)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (872)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (873)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (874)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (875)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (876)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (877)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (878)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (879)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (880)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (881)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (882)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (883)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (884)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (885)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (886)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (887)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (888)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (889)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (890)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (891)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (892)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (893)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (894)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (895)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (896)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (897)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (898)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (899)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (900)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (901)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (902)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (903)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (904)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (905)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (906)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (907)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (908)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (909)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (910)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (911)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (912)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (913)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (914)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (915)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (916)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (917)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (918)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (919)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (920)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (921)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (922)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (923)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (924)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (925)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (926)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (927)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (928)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (929)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (930)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (931)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (932)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (933)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (934)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (935)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (936)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (937)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (938)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (939)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (940)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (941)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (942)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (943)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (944)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (945)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (946)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (947)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (948)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (949)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (950)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (951)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (952)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (953)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (954)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (955)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (956)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (957)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (958)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (959)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (960)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (961)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (962)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (963)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (964)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (965)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (966)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (967)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (968)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (969)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (970)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (971)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (972)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (973)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (974)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (975)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (976)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (977)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (978)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (979)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (980)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (981)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (982)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (983)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (984)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (985)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (986)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (987)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (988)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (989)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (990)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (991)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (992)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (993)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (994)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (995)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (996)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (997)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (998)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (999)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1000)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1001)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1002)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1003)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1004)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1005)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1006)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1007)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1008)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1009)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1010)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1011)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1012)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1013)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1014)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1015)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1016)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1017)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1018)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1019)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1020)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1021)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1022)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1023)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1024)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1025)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1026)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1027)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1028)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare  (1029)  rf=r size=64 type=ud align=32 words (r1.0)
//.declare  (1030)  rf=r size=128 type=ud align=32 words (r6.0)
//.declare r0 (1031)  rf=r size=64 type=ud align=32 words (r0.0)
//.declare rtmp (1032)  rf=r size=64 type=ud align=32 words (r127.0)
//.declare inlineRegFromTDL (1033)  rf=r size=32 type=ud align=2 words (r1.0)
//.declare inlineRegExpectedLocation (1034)  rf=r size=32 type=ud align=2 words (r4.0)
//.declare  (1035)  rf=r size=128 type=ud align=32 words (r1.0)
//.declare  (1036)  rf=r size=64 type=ud align=32 words (r3.0)
//.declare  (1037)  rf=r size=128 type=ud align=32 words (r5.0)
//.declare  (1038)  rf=r size=64 type=ud align=32 words (r7.0)

// .inputs
// +----------+----------+--------+----------+------------------+
// | id       | type     |  bytes | at       | from             |
// +----------+----------+--------+----------+------------------+
// | V0038    | :w x 16  |   0x20 | r1       | pti[tid]+0x0     |
// | V0039    | :w x 16  |   0x20 | r2       | pti[tid]+0x40    |
// | V0040    | :w x 16  |   0x20 | r3       | pti[tid]+0x80    |
// | V0037    | :d x 3   |    0xC | r4       | inline+0x0       |
// | V0086    | :ud      |    0x4 | r4+0x10  | inline+0x10      |
// | V0042    | :q       |    0x8 | r4+0x18  | inline+0x18      |
// | V0043    | :q       |    0x8 | r5       | cti+0x20         |
// | V0044    | :q       |    0x8 | r5+0x8   | cti+0x28         |
// | V0045    | :q       |    0x8 | r5+0x10  | cti+0x30         |
// | V0046    | :q       |    0x8 | r5+0x18  | cti+0x38         |
// | V0047    | :q       |    0x8 | r5+0x20  | cti+0x40         |
// | V0048    | :q       |    0x8 | r5+0x28  | cti+0x48         |
// | V0049    | :q       |    0x8 | r5+0x30  | cti+0x50         |
// | V0050    | :q       |    0x8 | r5+0x38  | cti+0x58         |
// | V0051    | :q       |    0x8 | r6       | cti+0x60         |
// | V0052    | :q       |    0x8 | r6+0x8   | cti+0x68         |
// | V0053    | :q       |    0x8 | r6+0x10  | cti+0x70         |
// | V0054    | :q       |    0x8 | r6+0x18  | cti+0x78         |
// | V0055    | :q       |    0x8 | r6+0x20  | cti+0x80         |
// | V0056    | :q       |    0x8 | r6+0x28  | cti+0x88         |
// | V0057    | :q       |    0x8 | r6+0x30  | cti+0x90         |
// | V0058    | :q       |    0x8 | r6+0x38  | cti+0x98         |
// | V0059    | :q       |    0x8 | r7       | cti+0xA0         |
// | V0060    | :q       |    0x8 | r7+0x8   | cti+0xA8         |
// | V0061    | :q       |    0x8 | r7+0x10  | cti+0xB0         |
// | V0062    | :q       |    0x8 | r7+0x18  | cti+0xB8         |
// | V0063    | :d       |    0x4 | r7+0x20  | cti+0xC0         |
// | V0064    | :d       |    0x4 | r7+0x24  | cti+0xC4         |
// | V0065    | :d       |    0x4 | r7+0x28  | cti+0xC8         |
// | V0066    | :d       |    0x4 | r7+0x2C  | cti+0xCC         |
// | V0067    | :d       |    0x4 | r7+0x30  | cti+0xD0         |
// | V0041    | :uq      |    0x8 | r7+0x38  | cti+0xD8         |
// +----------+----------+--------+----------+------------------+


// B000: Preds:{},  Succs:{B001}
per_thread_prolog:
(W)     mov (16|M0)              r127.0<1>:ud  0x0:ud                                                //  ALU pipe: int; 
(W)     and (1|M0)               r127.2<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud                       //  ALU pipe: int; 
(W)     and (1|M0)               r127.0<1>:uw  r0.4<0;1,0>:uw    0xFF:uw                             //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0xC0:ud              {I@2}          //  ALU pipe: int; 
(W)     add (1|M0)               r127.2<1>:ud  r127.2<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     mad (1|M0)               r127.0<1>:ud  r127.2<0;0>:ud    r127.0<0;0>:uw    0xC0:uw              {I@1} //  ALU pipe: int; 
(W)     mov (8|M0)               r4.0<1>:ud    r1.0<1;1,0>:ud                                        //  ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r1:2 bti[255][r127:1]   {A@1,$0} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r3:1 bti[255][r127:1+0x80]  {$1} // ex_desc:0xFF080000; desc:0x6219D500 // 
        nop                                                                                          // 
        nop                                                                                          // 
        nop                                                                                          // 
// B001: Preds:{B000},  Succs:{B002}
// cross_thread_prolog:
        sync.nop                             null                             {Compacted,$1.src}     // 
(W)     and (1|M0)               r127.0<1>:ud  r0.0<0;1,0>:ud    0xFFFFFFC0:ud              {$0.src} //  ALU pipe: int; 
(W)     add (1|M0)               r127.0<1>:ud  r127.0<0;1,0>:ud  0x0:ud              {I@1}           //  R_SYM_ADDR_32: __INTEL_PATCH_CROSS_THREAD_OFFSET_OFF_R0; ALU pipe: int; 
(W)     load.ugm.d32x32t.a32.ca.cc (1|M0)  r5:2 bti[255][r127:1]   {I@1,$2} // ex_desc:0xFF000000; desc:0x6229E500 // 
(W)     load.ugm.d32x16t.a32.ca.cc (1|M0)  r7:1 bti[255][r127:1+0x80]  {$3} // ex_desc:0xFF080000; desc:0x6219D500 // 
// B002: Preds:{B001},  Succs:{B003, B070}
// _main:
(W)     mov (16|M0)              r125.0<1>:ud  r0.0<1;1,0>:ud                   {Compacted}          //  ALU pipe: int; 
        sync.nop                             null                             {Compacted,$3.src}     // 
(W)     mov (1|M0)               r127.3<1>:f   0x0:f                               {$2.src}          //  (0x00000000:f); ALU pipe: float; 
(W)     mov (16|M0)              r126.0<1>:f   r125.0<1;1,0>:f                  {Compacted,I@1}      //  ALU pipe: float; 
(W)     mov (1|M0)               r127.2<1>:f   0xC0:f                                                //  (0x000000c0:f); ALU pipe: float; 
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud              {F@2}       //  ALU pipe: int; 
(W)     and (1|M0)               r126.7<1>:ud  r125.5<0;1,0>:ud  0xFFFFFC00:ud                       //  ALU pipe: int; 
(W)     or (1|M0)                cr0.0<1>:ud   cr0.0<0;1,0>:ud   0x400004C0:ud              {A@1}    // $1
(W)     and (1|M0)               r1.9<1>:ud    msg0.0<0;1,0>:ud  0xFF:uw              {A@1,$0.dst}   //  ALU pipe: int; $2
(W)     and (1|M0)               r1.10<1>:ud   sr0.0<0;1,0>:ud   0x7F:uw              {A@1}          //  ALU pipe: int; $3
(W)     and (1|M0)               r1.11<1>:ud   r1.10<0;1,0>:ud   7:w               {A@1}             //  ALU pipe: int; $5
(W)     asr (1|M0)               r1.12<1>:ud   r1.10<0;1,0>:ud   1:w                                 //  ALU pipe: int; $6
(W)     mov (1|M0)               r1.8<1>:d     -8:w                                                  //  ALU pipe: int; $7
(W)     shl (1|M0)               r1.9<1>:ud    r1.9<0;1,0>:ud    0x6:uw                              //  ALU pipe: int; $4
(W)     bfn.(s0&s1|s2) (1|M0)    r1.10<1>:ud   r1.12<0;0>:ud     r1.8<0;0>:ud      r1.11<0>:ud      {I@2} //  ALU pipe: int; $7
(W)     mov (1|M0)               r6.0<1>:uq    0x0:uw                              {$2.dst}          //  ALU pipe: int; $13
(W)     or (1|M0)                r1.9<1>:ud    r1.9<0;1,0>:ud    r1.10<0;1,0>:ud  {I@2}              //  ALU pipe: int; $8
        mov (16|M0)              r2.0<4>:uw    r1.0<1;1,0>:uw                   {$1.dst}             //  ALU pipe: int; $24
(W)     mul (1|M0)               acc0.0<1>:ud  r1.9<0;1,0>:ud    0xA00:uw              {I@2}         //  ALU pipe: int; $9
(W)     macl (1|M0)              r5.0<1>:ud    r1.9<0;1,0>:ud    0x10A00:ud                          //  ALU pipe: int; $10
(W)     mul (1|M0)               acc0.0<1>:ud  r4.0<0;1,0>:ud    r125.2<0;1,0>:uw                    //  ALU pipe: int; $18
(W)     add (1|M0)               r127.3<1>:uq  r7.7<0;1,0>:uq    r5.0<0;1,0>:ud   {@2,$3.dst}        //  ALU pipe: int; $10
        mov (16|M0)              r10.0<1>:q    r2.0<4;1,0>:uw                                        //  ALU pipe: int; $24
(W)     mov (1|M0)               r127.2<1>:uq  r127.3<0;1,0>:uq                 {I@2}                //  ALU pipe: int; $11
(W)     mov (1|M0)               r63.0<1>:ud   0x6E10CA2E:ud                                         //  R_SYM_ADDR_32: fmaf; ALU pipe: int; $17
(W)     mov (1|M0)               r5.0<1>:uq    r127.2<0;1,0>:uq                 {Compacted,I@2}      //  ALU pipe: int; $14
(W)     mov (1|M0)               r63.1<1>:ud   0x6E10CA2E:ud                                         //  R_SYM_ADDR_32_HI: fmaf; ALU pipe: int; $17
(W)     store.ugm.d64x1t.a64 (1|M0)  [r5:1]     r6:1               {I@2,$4} // ex_desc:0x0; desc:0x2008784 // $16
(W)     macl (1|M0)              r5.0<1>:ud    r4.0<0;1,0>:ud    r125.1<0;1,0>:ud {Compacted,$4.src} //  ALU pipe: int; $19
(W)     mul (1|M0)               acc0.0<1>:ud  r4.0<0;1,0>:ud    r125.2<0;1,0>:uw                    //  ALU pipe: int; $19
(W)     mov (1|M0)               r6.0<1>:uq    r7.3<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $27
(W)     mov (1|M0)               r1.8<2>:ud    r5.0<0;1,0>:ud                   {I@3}                //  ALU pipe: int; $19
(W)     mach (1|M0)              r5.0<1>:d     r4.0<0;1,0>:ud    r125.1<0;1,0>:ud                    //  ALU pipe: int; 
(W)     add (1|M0)               r127.3<1>:uq  r127.3<0;1,0>:uq  0x10:uw                             //  ALU pipe: int; $12
(W)     mov (1|M0)               r1.9<2>:d     r5.0<0;1,0>:d                    {I@2}                //  ALU pipe: int; $23
        add (16|M0)              r66.0<1>:q    r1.4<0;1,0>:q     r10.0<1;1,0>:q   {Compacted,I@1}    //  ALU pipe: int; $25
        mov (16|M0)              r68.0<1>:d    r66.0<2;1,0>:d                   {Compacted,I@1}      //  ALU pipe: int; $26
(W)     load.ugm.d32x1t.a64 (1|M0)  r5:1        [r6:1]             {$5} // ex_desc:0x0; desc:0x2108580 // $28
(W)     cmp (16|M0)   (eq)f0.0   null<1>:d     r5.0<0;1,0>:d     0:w               {$5.dst}          //  ALU pipe: int; $29
(W&f0.0) jmpi                                _0_050                                                  //  ALU pipe: int; $30
// B003: Preds:{B002},  Succs:{B004, B005}
_0_051:
(W)     mov (1|M0)               r6.0<1>:uq    r7.2<0;1,0>:uq                   {Compacted}          //  ALU pipe: int; $32
        mov (16|M0)              r2.0<1>:d     0:w                               {Compacted}         //  ALU pipe: int; $35
        mov (16|M0)              r8.0<2>:f     r6.0<0;1,0>:f                    {I@2}                //  ALU pipe: float; $33
        mov (16|M0)              r8.1<2>:f     r6.1<0;1,0>:f                                         //  ALU pipe: float; $34
        atomic_or.ugm.d32.a64 (16|M0)  r2:1     [r8:2]            r2:1               {A@1,$6} // ex_desc:0x0; desc:0x4100599 // $36
        mov (16|M0)   (eq)f1.0   r2.0<1>:ud    r2.0<1;1,0>:ud                   {$6.dst}             //  ALU pipe: int; $37
(f1.0)  cmp (16|M0)   (lt)f1.0   null<2>:w     r1.0<1;1,0>:uw    0x4:uw                              //  ALU pipe: int; $39
(f1.0)  goto (16|M0)                         _0_052            _0_052                                //  ALU pipe: int; $41
// B004: [inDivergent],  Preds:{B003},  Succs:{B071}
_0_053:
        cmp (16|M0)   (eq)f2.0   r60.0<1>:d    r2.0<1;1,0>:d     0:w               {I@3}             //  ALU pipe: int; $43
        goto (16|M0)                         _0_052            _0_054                                // $44
// B005: [inDivergent],  Preds:{B003},  Succs:{B006, B068}
_0_052:
        join (16|M0)                         _0_054                                                  // 
L1000:
        shl (16|M0)              r2.0<1>:q     r10.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $46
        add (16|M0)              r8.0<1>:q     r2.0<1;1,0>:q     r5.5<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $47
        load.ugm.d16u32.a64 (16|M0)  r2:1       [r8:2]             {I@1,$7} // ex_desc:0x0; desc:0x4100B80 // $49
        shl (16|M0)              r2.0<1>:d     r2.0<1;1,0>:ud    16:w               {$7.dst}         //  ALU pipe: int; $50
        mul (16|M0)              r60.0<1>:f    r2.0<1;1,0>:f     0xBE800000:f               {Compacted,I@1} //  ALU pipe: float; $51
        and (16|M0)              r2.0<1>:d     r60.0<1;1,0>:d    2147483647:d               {F@1}    //  ALU pipe: int; $52
        cmp (16|M0)   (gt)f3.1   null<1>:d     r2.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $53
(f3.1)  goto (16|M0)                         _0_055            _0_055                                //  ALU pipe: int; $54
// B006: [inDivergent],  Preds:{B005},  Succs:{B007, B067}
_0_056:
        cmp (16|M0)   (ge)f3.0   null<1>:f     r60.0<1;1,0>:f    0x42B17218:f                        //  ALU pipe: float; $56
(f3.0)  goto (16|M0)                         _0_057            _0_057                                //  ALU pipe: int; $57
// B007: [inDivergent],  Preds:{B006},  Succs:{B008, B066}
_0_058:
        cmp (16|M0)   (le)f2.1   null<1>:f     r60.0<1;1,0>:f    0xC2CFF1B5:f                        //  ALU pipe: float; $59
(f2.1)  goto (16|M0)                         _0_059            _0_059                                //  ALU pipe: int; $60
// B008: [inDivergent],  Preds:{B007},  Succs:{B009, B065}
_0_060:
        cmp (16|M0)   (lt)f2.0   null<1>:d     r2.0<1;1,0>:ud    0x33000000:ud                       //  ALU pipe: int; $62
(f2.0)  goto (16|M0)                         _0_061            _0_061                                //  ALU pipe: int; $63
// B009: [FCALL],  [inDivergent],  Preds:{B008},  Succs:{B010}
_0_062:
        mul (16|M0)   (ge)f1.1   r2.0<1>:f     r60.0<1;1,0>:f    0x3FB8AA3B:f               {I@2}    //  ALU pipe: float; $65
(W)     mov (1|M0)               r1.8<1>:f     0x3F000000:f                                          //  ALU pipe: float; $67
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $77
(f1.1)  sel (16|M0)              acc0.0<1>:f   r1.8<0;1,0>:f     0xBF000000:f               {Compacted,F@1} //  ALU pipe: float; $67
        add (16|M0)              r2.0<1>:f     r2.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $68
        mov (16|M0)              r65.0<1>:d    r2.0<1;1,0>:f                    {F@1}                //  ALU pipe: int; $69
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud              {F@1}           //  ALU pipe: int; $77
        mov (16|M0)              r62.0<1>:f    r65.0<1;1,0>:d                   {I@2}                //  ALU pipe: float; $70
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $76
        mul (16|M0)              r61.0<1>:f    r62.0<1;1,0>:f    0x3F317218:f               {F@1}    //  ALU pipe: float; $71
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $77
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$9} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $77
        mov (16|M0)              r27.0<1>:f    0x3F317218:f                                          //  ALU pipe: float; $74
        mov (16|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $73
        mov (16|M0)              r28.0<1>:f    -r61.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $72
        sync.nop                             null                             {Compacted,$9.src}     // $77
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $77
        sync.allrd                           null                             {A@1}                  // $77
        sync.allwr                           null                                                    // $77
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $77
// B010: [FCALL],  [inDivergent],  Preds:{B009},  Succs:{B011}
_L_k0_0_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $77
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $77
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $77
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $82
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $78
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $77
        sync.nop                             null                             {Compacted,$10.dst}    // $77
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$11} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $77
        sync.nop                             null                             {Compacted,$11.dst}    // $80
        mov (16|M0)              r27.0<1>:f    0xB102E308:f                                          //  ALU pipe: float; $80
        mov (16|M0)              r26.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $79
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $83
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$11} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $83
        sync.nop                             null                             {Compacted,$11.src}    // $83
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $83
        sync.allrd                           null                             {A@1}                  // $83
        sync.allwr                           null                                                    // $83
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $83
// B011: [FCALL],  [inDivergent],  Preds:{B010},  Succs:{B012}
_L_k0_1_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $83
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $83
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $83
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $88
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $84
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $83
        sync.nop                             null                             {Compacted,$12.dst}    // $83
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$13} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $83
        sync.nop                             null                             {Compacted,$13.dst}    // $86
        mov (16|M0)              r27.0<1>:f    0x3F317218:f                                          //  ALU pipe: float; $86
        mov (16|M0)              r26.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $85
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $89
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$13} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $89
        sync.nop                             null                             {Compacted,$13.src}    // $89
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $89
        sync.allrd                           null                             {A@1}                  // $89
        sync.allwr                           null                                                    // $89
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $89
// B012: [FCALL],  [inDivergent],  Preds:{B011},  Succs:{B013}
_L_k0_2_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $89
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $89
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $89
        add (16|M0)              acc0.0<1>:f   r61.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $91
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $89
        sync.nop                             null                             {Compacted,$14.dst}    // $89
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$15} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $89
        sync.nop                             null                             {Compacted,$15.dst}    // $92
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r61.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $92
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $93
        add (16|M0)              acc2.0<1>:f   r61.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $94
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $95
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $96
        add (16|M0)              acc2.0<1>:f   r60.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $97
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   -r60.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $98
        add (16|M0)              acc1.0<1>:f   acc2.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $99
        add (16|M0)              acc1.0<1>:f   r60.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $100
        add (16|M0)              acc0.0<1>:f   -acc0.0<1;1,0>:f  -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $101
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $102
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0x0:f               {Compacted}     //  ALU pipe: float; $103
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -r2.0<1;1,0>:f   {Compacted,F@7}    //  ALU pipe: float; $104
        add (16|M0)              r60.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $105
        add (16|M0)              acc1.0<1>:f   r60.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $106
        add (16|M0)              acc3.0<1>:f   r60.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $107
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $116
        mul (16|M0)              r62.0<1>:f    r60.0<1;1,0>:f    0x310F76C7:f                        //  ALU pipe: float; $111
        add (16|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $108
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $109
        mov (16|M0)              r27.0<1>:ud   0x310F76C7:ud                                         //  ALU pipe: int; $114
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $113
        mov (16|M0)              r28.0<1>:f    -r62.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $112
        add (16|M0)              r61.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $110
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $117
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$15} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $117
        sync.nop                             null                             {Compacted,$15.src}    // $117
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $117
        sync.allrd                           null                             {A@1}                  // $117
        sync.allwr                           null                                                    // $117
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $117
// B013: [FCALL],  [inDivergent],  Preds:{B012},  Succs:{B014}
_L_k0_3_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $117
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $117
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $117
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $122
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $118
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $117
        sync.nop                             null                             {Compacted,$0.dst}     // $117
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$1} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $117
        sync.nop                             null                             {Compacted,$1.dst}     // $120
        mov (16|M0)              r27.0<1>:f    0x24FF8D89:f                                          //  ALU pipe: float; $120
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $119
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$0} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $123
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$1} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $123
        sync.nop                             null                             {Compacted,$1.src}     // $123
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $123
        sync.allrd                           null                             {A@1}                  // $123
        sync.allwr                           null                                                    // $123
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $123
// B014: [FCALL],  [inDivergent],  Preds:{B013},  Succs:{B015}
_L_k0_4_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $123
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $123
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $123
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $128
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $124
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$2} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $123
        sync.nop                             null                             {Compacted,$2.dst}     // $123
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$3} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $123
        sync.nop                             null                             {Compacted,$3.dst}     // $126
        mov (16|M0)              r27.0<1>:f    0x310F76C7:f                                          //  ALU pipe: float; $126
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $125
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$2} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $129
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$3} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $129
        sync.nop                             null                             {Compacted,$3.src}     // $129
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$2.src}             //  ALU pipe: int; $129
        sync.allrd                           null                             {A@1}                  // $129
        sync.allwr                           null                                                    // $129
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $129
// B015: [FCALL],  [inDivergent],  Preds:{B014},  Succs:{B016}
_L_k0_5_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $129
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $129
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $129
        add (16|M0)              acc0.0<1>:f   r62.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $131
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$4} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $129
        sync.nop                             null                             {Compacted,$4.dst}     // $129
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$5} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $129
        sync.nop                             null                             {Compacted,$5.dst}     // $132
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $132
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $133
        add (16|M0)              acc2.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $134
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $135
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $136
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x32D7322B:f                        //  ALU pipe: float; $137
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xB2D7322B:f                        //  ALU pipe: float; $138
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $139
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x32D7322B:f                        //  ALU pipe: float; $140
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $141
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $142
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0x25FEA89C:f                        //  ALU pipe: float; $143
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $144
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $145
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $146
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $147
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $156
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $151
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $148
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $149
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $153
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $154
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $152
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $150
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$4} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $157
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$5} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $157
        sync.nop                             null                             {Compacted,$5.src}     // $157
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$4.src}             //  ALU pipe: int; $157
        sync.allrd                           null                             {A@1}                  // $157
        sync.allwr                           null                                                    // $157
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $157
// B016: [FCALL],  [inDivergent],  Preds:{B015},  Succs:{B017}
_L_k0_6_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $157
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $157
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $157
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $162
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $158
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$6} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $157
        sync.nop                             null                             {Compacted,$6.dst}     // $157
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$7} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $157
        sync.nop                             null                             {Compacted,$7.dst}     // $160
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $160
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $159
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $163
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$7} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $163
        sync.nop                             null                             {Compacted,$7.src}     // $163
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $163
        sync.allrd                           null                             {A@1}                  // $163
        sync.allwr                           null                                                    // $163
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $163
// B017: [FCALL],  [inDivergent],  Preds:{B016},  Succs:{B018}
_L_k0_7_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $163
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $163
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $163
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $168
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $164
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$8} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $163
        sync.nop                             null                             {Compacted,$8.dst}     // $163
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$9} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $163
        sync.nop                             null                             {Compacted,$9.dst}     // $166
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $166
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $165
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $169
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$9} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $169
        sync.nop                             null                             {Compacted,$9.src}     // $169
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $169
        sync.allrd                           null                             {A@1}                  // $169
        sync.allwr                           null                                                    // $169
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $169
// B018: [FCALL],  [inDivergent],  Preds:{B017},  Succs:{B019}
_L_k0_8_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $169
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $169
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $169
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $171
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $169
        sync.nop                             null                             {Compacted,$10.dst}    // $169
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$11} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $169
        sync.nop                             null                             {Compacted,$11.dst}    // $172
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $172
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $173
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $174
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $175
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $176
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3493F27E:f                        //  ALU pipe: float; $177
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xB493F27E:f                        //  ALU pipe: float; $178
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $179
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3493F27E:f                        //  ALU pipe: float; $180
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $181
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $182
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xA808760A:f                        //  ALU pipe: float; $183
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $184
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $185
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $186
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $187
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $196
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $191
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $188
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $189
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $193
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $194
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $192
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $190
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $197
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$11} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $197
        sync.nop                             null                             {Compacted,$11.src}    // $197
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $197
        sync.allrd                           null                             {A@1}                  // $197
        sync.allwr                           null                                                    // $197
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $197
// B019: [FCALL],  [inDivergent],  Preds:{B018},  Succs:{B020}
_L_k0_9_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $197
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $197
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $197
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $202
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $198
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $197
        sync.nop                             null                             {Compacted,$12.dst}    // $197
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$13} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $197
        sync.nop                             null                             {Compacted,$13.dst}    // $200
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $200
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $199
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $203
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$13} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $203
        sync.nop                             null                             {Compacted,$13.src}    // $203
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $203
        sync.allrd                           null                             {A@1}                  // $203
        sync.allwr                           null                                                    // $203
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $203
// B020: [FCALL],  [inDivergent],  Preds:{B019},  Succs:{B021}
_L_k0_10_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $203
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $203
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $203
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $208
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $204
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $203
        sync.nop                             null                             {Compacted,$14.dst}    // $203
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$15} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $203
        sync.nop                             null                             {Compacted,$15.dst}    // $206
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $206
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $205
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $209
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$15} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $209
        sync.nop                             null                             {Compacted,$15.src}    // $209
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $209
        sync.allrd                           null                             {A@1}                  // $209
        sync.allwr                           null                                                    // $209
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $209
// B021: [FCALL],  [inDivergent],  Preds:{B020},  Succs:{B022}
_L_k0_11_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $209
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $209
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $209
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $211
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $209
        sync.nop                             null                             {Compacted,$0.dst}     // $209
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$1} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $209
        sync.nop                             null                             {Compacted,$1.dst}     // $212
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $212
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $213
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $214
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $215
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $216
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3638EF1D:f                        //  ALU pipe: float; $217
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xB638EF1D:f                        //  ALU pipe: float; $218
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $219
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3638EF1D:f                        //  ALU pipe: float; $220
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $221
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $222
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0x292AD8E6:f                        //  ALU pipe: float; $223
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $224
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $225
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $226
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $227
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $236
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $231
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $228
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $229
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $233
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $234
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $232
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $230
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$0} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $237
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$1} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $237
        sync.nop                             null                             {Compacted,$1.src}     // $237
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $237
        sync.allrd                           null                             {A@1}                  // $237
        sync.allwr                           null                                                    // $237
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $237
// B022: [FCALL],  [inDivergent],  Preds:{B021},  Succs:{B023}
_L_k0_12_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $237
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $237
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $237
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $242
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $238
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$2} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $237
        sync.nop                             null                             {Compacted,$2.dst}     // $237
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$3} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $237
        sync.nop                             null                             {Compacted,$3.dst}     // $240
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $240
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $239
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$2} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $243
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$3} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $243
        sync.nop                             null                             {Compacted,$3.src}     // $243
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$2.src}             //  ALU pipe: int; $243
        sync.allrd                           null                             {A@1}                  // $243
        sync.allwr                           null                                                    // $243
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $243
// B023: [FCALL],  [inDivergent],  Preds:{B022},  Succs:{B024}
_L_k0_13_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $243
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $243
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $243
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $248
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $244
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$4} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $243
        sync.nop                             null                             {Compacted,$4.dst}     // $243
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$5} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $243
        sync.nop                             null                             {Compacted,$5.dst}     // $246
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $246
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $245
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$4} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $249
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$5} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $249
        sync.nop                             null                             {Compacted,$5.src}     // $249
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$4.src}             //  ALU pipe: int; $249
        sync.allrd                           null                             {A@1}                  // $249
        sync.allwr                           null                                                    // $249
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $249
// B024: [FCALL],  [inDivergent],  Preds:{B023},  Succs:{B025}
_L_k0_14_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $249
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $249
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $249
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $251
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$6} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $249
        sync.nop                             null                             {Compacted,$6.dst}     // $249
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$7} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $249
        sync.nop                             null                             {Compacted,$7.dst}     // $252
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $252
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $253
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $254
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $255
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $256
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x37D00D01:f                        //  ALU pipe: float; $257
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xB7D00D01:f                        //  ALU pipe: float; $258
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $259
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x37D00D01:f                        //  ALU pipe: float; $260
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $261
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $262
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xAABFCBFD:f                        //  ALU pipe: float; $263
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $264
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $265
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $266
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $267
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $276
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $271
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $268
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $269
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $273
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $274
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $272
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $270
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $277
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$7} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $277
        sync.nop                             null                             {Compacted,$7.src}     // $277
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $277
        sync.allrd                           null                             {A@1}                  // $277
        sync.allwr                           null                                                    // $277
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $277
// B025: [FCALL],  [inDivergent],  Preds:{B024},  Succs:{B026}
_L_k0_15_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $277
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $277
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $277
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $282
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $278
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$8} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $277
        sync.nop                             null                             {Compacted,$8.dst}     // $277
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$9} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $277
        sync.nop                             null                             {Compacted,$9.dst}     // $280
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $280
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $279
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $283
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$9} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $283
        sync.nop                             null                             {Compacted,$9.src}     // $283
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $283
        sync.allrd                           null                             {A@1}                  // $283
        sync.allwr                           null                                                    // $283
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $283
// B026: [FCALL],  [inDivergent],  Preds:{B025},  Succs:{B027}
_L_k0_16_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $283
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $283
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $283
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $288
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $284
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $283
        sync.nop                             null                             {Compacted,$10.dst}    // $283
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$11} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $283
        sync.nop                             null                             {Compacted,$11.dst}    // $286
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $286
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $285
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $289
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$11} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $289
        sync.nop                             null                             {Compacted,$11.src}    // $289
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $289
        sync.allrd                           null                             {A@1}                  // $289
        sync.allwr                           null                                                    // $289
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $289
// B027: [FCALL],  [inDivergent],  Preds:{B026},  Succs:{B028}
_L_k0_17_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $289
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $289
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $289
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $291
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $289
        sync.nop                             null                             {Compacted,$12.dst}    // $289
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$13} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $289
        sync.nop                             null                             {Compacted,$13.dst}    // $292
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $292
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $293
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $294
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $295
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $296
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x39500D01:f                        //  ALU pipe: float; $297
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xB9500D01:f                        //  ALU pipe: float; $298
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $299
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x39500D01:f                        //  ALU pipe: float; $300
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $301
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $302
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xAC3FCBFD:f                        //  ALU pipe: float; $303
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $304
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $305
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $306
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $307
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $316
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $311
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $308
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $309
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $313
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $314
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $312
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $310
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $317
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$13} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $317
        sync.nop                             null                             {Compacted,$13.src}    // $317
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $317
        sync.allrd                           null                             {A@1}                  // $317
        sync.allwr                           null                                                    // $317
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $317
// B028: [FCALL],  [inDivergent],  Preds:{B027},  Succs:{B029}
_L_k0_18_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $317
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $317
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $317
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $322
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $318
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $317
        sync.nop                             null                             {Compacted,$14.dst}    // $317
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$15} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $317
        sync.nop                             null                             {Compacted,$15.dst}    // $320
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $320
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $319
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $323
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$15} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $323
        sync.nop                             null                             {Compacted,$15.src}    // $323
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $323
        sync.allrd                           null                             {A@1}                  // $323
        sync.allwr                           null                                                    // $323
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $323
// B029: [FCALL],  [inDivergent],  Preds:{B028},  Succs:{B030}
_L_k0_19_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $323
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $323
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $323
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $328
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $324
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $323
        sync.nop                             null                             {Compacted,$0.dst}     // $323
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$1} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $323
        sync.nop                             null                             {Compacted,$1.dst}     // $326
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $326
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $325
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$0} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $329
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$1} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $329
        sync.nop                             null                             {Compacted,$1.src}     // $329
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $329
        sync.allrd                           null                             {A@1}                  // $329
        sync.allwr                           null                                                    // $329
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $329
// B030: [FCALL],  [inDivergent],  Preds:{B029},  Succs:{B031}
_L_k0_20_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $329
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $329
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $329
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $331
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$2} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $329
        sync.nop                             null                             {Compacted,$2.dst}     // $329
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$3} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $329
        sync.nop                             null                             {Compacted,$3.dst}     // $332
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $332
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $333
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $334
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $335
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $336
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3AB60B61:f                        //  ALU pipe: float; $337
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xBAB60B61:f                        //  ALU pipe: float; $338
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $339
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3AB60B61:f                        //  ALU pipe: float; $340
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $341
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $342
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xAE13E93F:f                        //  ALU pipe: float; $343
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $344
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $345
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $346
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $347
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $356
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $351
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $348
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $349
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $353
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $354
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $352
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $350
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$2} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $357
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$3} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $357
        sync.nop                             null                             {Compacted,$3.src}     // $357
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$2.src}             //  ALU pipe: int; $357
        sync.allrd                           null                             {A@1}                  // $357
        sync.allwr                           null                                                    // $357
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $357
// B031: [FCALL],  [inDivergent],  Preds:{B030},  Succs:{B032}
_L_k0_21_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $357
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $357
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $357
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $362
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $358
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$4} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $357
        sync.nop                             null                             {Compacted,$4.dst}     // $357
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$5} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $357
        sync.nop                             null                             {Compacted,$5.dst}     // $360
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $360
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $359
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$4} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $363
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$5} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $363
        sync.nop                             null                             {Compacted,$5.src}     // $363
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$4.src}             //  ALU pipe: int; $363
        sync.allrd                           null                             {A@1}                  // $363
        sync.allwr                           null                                                    // $363
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $363
// B032: [FCALL],  [inDivergent],  Preds:{B031},  Succs:{B033}
_L_k0_22_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $363
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $363
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $363
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $368
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $364
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$6} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $363
        sync.nop                             null                             {Compacted,$6.dst}     // $363
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$7} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $363
        sync.nop                             null                             {Compacted,$7.dst}     // $366
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $366
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $365
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $369
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$7} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $369
        sync.nop                             null                             {Compacted,$7.src}     // $369
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $369
        sync.allrd                           null                             {A@1}                  // $369
        sync.allwr                           null                                                    // $369
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $369
// B033: [FCALL],  [inDivergent],  Preds:{B032},  Succs:{B034}
_L_k0_23_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $369
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $369
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $369
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $371
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$8} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $369
        sync.nop                             null                             {Compacted,$8.dst}     // $369
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$9} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $369
        sync.nop                             null                             {Compacted,$9.dst}     // $372
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $372
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $373
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $374
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $375
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $376
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3C088889:f                        //  ALU pipe: float; $377
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xBC088889:f                        //  ALU pipe: float; $378
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $379
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3C088889:f                        //  ALU pipe: float; $380
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $381
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $382
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xAFEEEEEF:f                        //  ALU pipe: float; $383
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $384
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $385
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $386
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $387
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $396
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $391
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $388
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $389
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $393
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $394
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $392
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $390
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $397
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$9} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $397
        sync.nop                             null                             {Compacted,$9.src}     // $397
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $397
        sync.allrd                           null                             {A@1}                  // $397
        sync.allwr                           null                                                    // $397
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $397
// B034: [FCALL],  [inDivergent],  Preds:{B033},  Succs:{B035}
_L_k0_24_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $397
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $397
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $397
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $402
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $398
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $397
        sync.nop                             null                             {Compacted,$10.dst}    // $397
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$11} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $397
        sync.nop                             null                             {Compacted,$11.dst}    // $400
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $400
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $399
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $403
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$11} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $403
        sync.nop                             null                             {Compacted,$11.src}    // $403
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $403
        sync.allrd                           null                             {A@1}                  // $403
        sync.allwr                           null                                                    // $403
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $403
// B035: [FCALL],  [inDivergent],  Preds:{B034},  Succs:{B036}
_L_k0_25_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $403
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $403
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $403
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $408
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $404
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $403
        sync.nop                             null                             {Compacted,$12.dst}    // $403
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$13} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $403
        sync.nop                             null                             {Compacted,$13.dst}    // $406
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $406
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $405
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $409
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$13} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $409
        sync.nop                             null                             {Compacted,$13.src}    // $409
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $409
        sync.allrd                           null                             {A@1}                  // $409
        sync.allwr                           null                                                    // $409
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $409
// B036: [FCALL],  [inDivergent],  Preds:{B035},  Succs:{B037}
_L_k0_26_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $409
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $409
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $409
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $411
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $409
        sync.nop                             null                             {Compacted,$14.dst}    // $409
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$15} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $409
        sync.nop                             null                             {Compacted,$15.dst}    // $412
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $412
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $413
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $414
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $415
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $416
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3D2AAAAB:f                        //  ALU pipe: float; $417
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xBD2AAAAB:f                        //  ALU pipe: float; $418
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $419
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3D2AAAAB:f                        //  ALU pipe: float; $420
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $421
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $422
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xB0AAAAAB:f                        //  ALU pipe: float; $423
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $424
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $425
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $426
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $427
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $436
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $431
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $428
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $429
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $433
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $434
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $432
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $430
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $437
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$15} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $437
        sync.nop                             null                             {Compacted,$15.src}    // $437
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $437
        sync.allrd                           null                             {A@1}                  // $437
        sync.allwr                           null                                                    // $437
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $437
// B037: [FCALL],  [inDivergent],  Preds:{B036},  Succs:{B038}
_L_k0_27_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $437
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $437
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $437
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $442
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $438
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $437
        sync.nop                             null                             {Compacted,$0.dst}     // $437
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$1} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $437
        sync.nop                             null                             {Compacted,$1.dst}     // $440
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $440
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $439
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$0} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $443
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$1} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $443
        sync.nop                             null                             {Compacted,$1.src}     // $443
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $443
        sync.allrd                           null                             {A@1}                  // $443
        sync.allwr                           null                                                    // $443
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $443
// B038: [FCALL],  [inDivergent],  Preds:{B037},  Succs:{B039}
_L_k0_28_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $443
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $443
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $443
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $448
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $444
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$2} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $443
        sync.nop                             null                             {Compacted,$2.dst}     // $443
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$3} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $443
        sync.nop                             null                             {Compacted,$3.dst}     // $446
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $446
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $445
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$2} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $449
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$3} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $449
        sync.nop                             null                             {Compacted,$3.src}     // $449
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$2.src}             //  ALU pipe: int; $449
        sync.allrd                           null                             {A@1}                  // $449
        sync.allwr                           null                                                    // $449
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $449
// B039: [FCALL],  [inDivergent],  Preds:{B038},  Succs:{B040}
_L_k0_29_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $449
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $449
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $449
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $451
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$4} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $449
        sync.nop                             null                             {Compacted,$4.dst}     // $449
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$5} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $449
        sync.nop                             null                             {Compacted,$5.dst}     // $452
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $452
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $453
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $454
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $455
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $456
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3E2AAAAB:f                        //  ALU pipe: float; $457
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xBE2AAAAB:f                        //  ALU pipe: float; $458
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $459
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3E2AAAAB:f                        //  ALU pipe: float; $460
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $461
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $462
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   0xB1AAAAAB:f                        //  ALU pipe: float; $463
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $464
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $465
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $466
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $467
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $476
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $471
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $468
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $469
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $473
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $474
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $472
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $470
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$4} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $477
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$5} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $477
        sync.nop                             null                             {Compacted,$5.src}     // $477
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$4.src}             //  ALU pipe: int; $477
        sync.allrd                           null                             {A@1}                  // $477
        sync.allwr                           null                                                    // $477
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $477
// B040: [FCALL],  [inDivergent],  Preds:{B039},  Succs:{B041}
_L_k0_30_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $477
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $477
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $477
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $482
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $478
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$6} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $477
        sync.nop                             null                             {Compacted,$6.dst}     // $477
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$7} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $477
        sync.nop                             null                             {Compacted,$7.dst}     // $480
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $480
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $479
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $483
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$7} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $483
        sync.nop                             null                             {Compacted,$7.src}     // $483
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $483
        sync.allrd                           null                             {A@1}                  // $483
        sync.allwr                           null                                                    // $483
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $483
// B041: [FCALL],  [inDivergent],  Preds:{B040},  Succs:{B042}
_L_k0_31_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $483
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $483
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $483
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $488
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $484
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$8} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $483
        sync.nop                             null                             {Compacted,$8.dst}     // $483
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$9} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $483
        sync.nop                             null                             {Compacted,$9.dst}     // $486
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $486
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $485
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $489
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$9} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $489
        sync.nop                             null                             {Compacted,$9.src}     // $489
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $489
        sync.allrd                           null                             {A@1}                  // $489
        sync.allwr                           null                                                    // $489
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $489
// B042: [FCALL],  [inDivergent],  Preds:{B041},  Succs:{B043}
_L_k0_32_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $489
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $489
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $489
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $491
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $489
        sync.nop                             null                             {Compacted,$10.dst}    // $489
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$11} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $489
        sync.nop                             null                             {Compacted,$11.dst}    // $492
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $492
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $493
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $494
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $495
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $496
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3F000000:f               {Compacted} //  ALU pipe: float; $497
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xBF000000:f               {Compacted} //  ALU pipe: float; $498
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $499
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3F000000:f               {Compacted} //  ALU pipe: float; $500
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $501
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $502
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $503
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $504
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $505
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $506
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $515
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $510
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $507
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $508
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $512
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $513
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $511
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $509
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $516
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$11} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $516
        sync.nop                             null                             {Compacted,$11.src}    // $516
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $516
        sync.allrd                           null                             {A@1}                  // $516
        sync.allwr                           null                                                    // $516
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $516
// B043: [FCALL],  [inDivergent],  Preds:{B042},  Succs:{B044}
_L_k0_33_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $516
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $516
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $516
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $521
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $517
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $516
        sync.nop                             null                             {Compacted,$12.dst}    // $516
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$13} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $516
        sync.nop                             null                             {Compacted,$13.dst}    // $519
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $519
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $518
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $522
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$13} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $522
        sync.nop                             null                             {Compacted,$13.src}    // $522
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $522
        sync.allrd                           null                             {A@1}                  // $522
        sync.allwr                           null                                                    // $522
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $522
// B044: [FCALL],  [inDivergent],  Preds:{B043},  Succs:{B045}
_L_k0_34_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $522
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $522
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $522
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $527
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $523
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $522
        sync.nop                             null                             {Compacted,$14.dst}    // $522
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$15} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $522
        sync.nop                             null                             {Compacted,$15.dst}    // $525
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $525
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $524
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $528
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$15} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $528
        sync.nop                             null                             {Compacted,$15.src}    // $528
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $528
        sync.allrd                           null                             {A@1}                  // $528
        sync.allwr                           null                                                    // $528
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $528
// B045: [FCALL],  [inDivergent],  Preds:{B044},  Succs:{B046}
_L_k0_35_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $528
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $528
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $528
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $530
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $528
        sync.nop                             null                             {Compacted,$0.dst}     // $528
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$1} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $528
        sync.nop                             null                             {Compacted,$1.dst}     // $531
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $531
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $532
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $533
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $534
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $535
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3F800000:f               {Compacted} //  ALU pipe: float; $536
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xBF800000:f               {Compacted} //  ALU pipe: float; $537
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $538
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3F800000:f               {Compacted} //  ALU pipe: float; $539
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $540
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $541
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $542
        add (16|M0)              r62.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $543
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $544
        add (16|M0)              r69.0<1>:f    acc1.0<1;1,0>:f   -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $545
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $554
        mul (16|M0)              r64.0<1>:f    r60.0<1;1,0>:f    r62.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $549
        add (16|M0)              r69.0<1>:f    acc2.0<1;1,0>:f   r69.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $546
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $547
        mov (16|M0)              r26.0<1>:ud   r60.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $551
        mov (16|M0)              r27.0<1>:ud   r62.0<1;1,0>:ud                  {Compacted}          //  ALU pipe: int; $552
        mov (16|M0)              r28.0<1>:f    -r64.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $550
        add (16|M0)              r69.0<1>:f    r69.0<1;1,0>:f    acc0.0<1;1,0>:f  {Compacted,F@3}    //  ALU pipe: float; $548
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$0} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $555
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$1} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $555
        sync.nop                             null                             {Compacted,$1.src}     // $555
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $555
        sync.allrd                           null                             {A@1}                  // $555
        sync.allwr                           null                                                    // $555
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $555
// B046: [FCALL],  [inDivergent],  Preds:{B045},  Succs:{B047}
_L_k0_36_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $555
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $555
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $555
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $560
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,I@7}      //  ALU pipe: float; $556
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$2} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $555
        sync.nop                             null                             {Compacted,$2.dst}     // $555
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$3} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $555
        sync.nop                             null                             {Compacted,$3.dst}     // $558
        mov (16|M0)              r27.0<1>:f    r69.0<1;1,0>:f                   {Compacted,F@2}      //  ALU pipe: float; $558
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $557
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$2} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $561
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$3} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $561
        sync.nop                             null                             {Compacted,$3.src}     // $561
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$2.src}             //  ALU pipe: int; $561
        sync.allrd                           null                             {A@1}                  // $561
        sync.allwr                           null                                                    // $561
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $561
// B047: [FCALL],  [inDivergent],  Preds:{B046},  Succs:{B048}
_L_k0_37_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $561
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $561
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $561
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $566
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $562
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$4} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $561
        sync.nop                             null                             {Compacted,$4.dst}     // $561
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$5} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $561
        sync.nop                             null                             {Compacted,$5.dst}     // $564
        mov (16|M0)              r27.0<1>:f    r62.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $564
        mov (16|M0)              r26.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $563
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$4} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $567
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$5} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $567
        sync.nop                             null                             {Compacted,$5.src}     // $567
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$4.src}             //  ALU pipe: int; $567
        sync.allrd                           null                             {A@1}                  // $567
        sync.allwr                           null                                                    // $567
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $567
// B048: [inDivergent],  Preds:{B047},  Succs:{B049, B056}
_L_k0_38_:
        add (16|M0)              acc0.0<1>:f   r64.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $569
        add (16|M0)              acc1.0<1>:f   acc0.0<1;1,0>:f   -r64.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $570
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $571
        add (16|M0)              acc2.0<1>:f   r64.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $572
        add (16|M0)              acc1.0<1>:f   r26.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $573
        add (16|M0)              r2.0<1>:f     acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $574
        add (16|M0)              acc2.0<1>:f   acc0.0<1;1,0>:f   0x3F800000:f               {Compacted} //  ALU pipe: float; $575
        add (16|M0)              acc3.0<1>:f   acc2.0<1;1,0>:f   0xBF800000:f               {Compacted} //  ALU pipe: float; $576
        add (16|M0)              acc1.0<1>:f   acc3.0<1;1,0>:f   -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $577
        add (16|M0)              acc1.0<1>:f   acc1.0<1;1,0>:f   0x3F800000:f               {Compacted} //  ALU pipe: float; $578
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc3.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $579
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $580
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   r2.0<1;1,0>:f    {Compacted,F@7}    //  ALU pipe: float; $581
        add (16|M0)              r60.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $582
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $567
        cmp (16|M0)   (lt)f1.1   null<1>:d     r65.0<1;1,0>:d    -125:w                              //  ALU pipe: int; $588
        add (16|M0)              acc1.0<1>:f   r60.0<1;1,0>:f    -acc2.0<1;1,0>:f {Compacted,F@1}    //  ALU pipe: float; $583
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $567
        add (16|M0)              acc3.0<1>:f   acc1.0<1;1,0>:f   -r60.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $584
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $567
        add (16|M0)              acc2.0<1>:f   acc2.0<1;1,0>:f   acc3.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $585
        add (16|M0)              acc0.0<1>:f   acc0.0<1;1,0>:f   -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $586
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$6} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $567
        sync.nop                             null                             {Compacted,$6.dst}     // $567
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$7} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $567
        sync.nop                             null                             {Compacted,$7.dst}     // $587
        add (16|M0)              r64.0<1>:f    acc2.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $587
        sync.nop                             null                             {Compacted,$7.src}     // $589
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $589
(f1.1)  goto (16|M0)                         _0_063            _0_063                                //  ALU pipe: int; $589
// B049: [inDivergent],  Preds:{B048},  Succs:{B050, B051}
_0_064:
        cmp (16|M0)   (eq)f1.0   null<1>:d     r65.0<1;1,0>:d    128:w                               //  ALU pipe: int; $591
(f1.0)  goto (16|M0)                         _0_065            _0_065                                //  ALU pipe: int; $592
// B050: [inDivergent],  Preds:{B049},  Succs:{B055}
_0_066:
        shl (16|M0)              r61.0<1>:d    r65.0<1;1,0>:d    23:w               {Compacted}      //  ALU pipe: int; $594
        add (16|M0)              r61.0<1>:d    r61.0<1;1,0>:d    1065353216:d               {I@1}    //  ALU pipe: int; $595
        goto (16|M0)                         _0_065            _0_067                                // $596
// B051: [FCALL],  [inDivergent],  Preds:{B049},  Succs:{B052}
_0_065:
        join (16|M0)                         _0_067                                                  // 
L13328:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $604
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $604
        mul (16|M0)              r61.0<1>:f    r60.0<1;1,0>:f    0x40000000:f               {Compacted,I@5} //  ALU pipe: float; $598
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $603
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {I@3,$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $604
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$7} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $604
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $600
        mov (16|M0)              r27.0<1>:f    0x40000000:f                               {Compacted} //  ALU pipe: float; $601
        mov (16|M0)              r28.0<1>:f    -r61.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $599
        sync.nop                             null                             {Compacted,$7.src}     // $604
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $604
        sync.allrd                           null                             {A@1}                  // $604
        sync.allwr                           null                                                    // $604
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $604
// B052: [FCALL],  [inDivergent],  Preds:{B051},  Succs:{B053}
_L_k0_39_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $604
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $604
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $604
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $609
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@3}      //  ALU pipe: float; $605
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$8} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $604
        sync.nop                             null                             {Compacted,$8.dst}     // $604
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$9} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $604
        sync.nop                             null                             {Compacted,$9.dst}     // $607
        mov (16|M0)              r27.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $607
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $606
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$8} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $610
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$9} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $610
        sync.nop                             null                             {Compacted,$9.src}     // $610
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$8.src}             //  ALU pipe: int; $610
        sync.allrd                           null                             {A@1}                  // $610
        sync.allwr                           null                                                    // $610
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $610
// B053: [FCALL],  [inDivergent],  Preds:{B052},  Succs:{B054}
_L_k0_40_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $610
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $610
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $610
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $615
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $611
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$10} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $610
        sync.nop                             null                             {Compacted,$10.dst}    // $610
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$11} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $610
        sync.nop                             null                             {Compacted,$11.dst}    // $613
        mov (16|M0)              r27.0<1>:f    0x40000000:f                               {Compacted} //  ALU pipe: float; $613
        mov (16|M0)              r26.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $612
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$10} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $616
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$11} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $616
        sync.nop                             null                             {Compacted,$11.src}    // $616
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$10.src}            //  ALU pipe: int; $616
        sync.allrd                           null                             {A@1}                  // $616
        sync.allwr                           null                                                    // $616
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $616
// B054: [inDivergent],  Preds:{B053},  Succs:{B055}
_L_k0_41_:
        add (16|M0)              r60.0<1>:f    r61.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $618
        add (16|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    -r61.0<1;1,0>:f  {Compacted,F@1}    //  ALU pipe: float; $619
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $616
        add (16|M0)              acc1.0<1>:f   r60.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $620
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $616
        add (16|M0)              acc1.0<1>:f   r61.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $621
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $616
        add (16|M0)              acc0.0<1>:f   r26.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $622
        mov (16|M0)              r61.0<1>:f    0x7F000000:f                               {Compacted} //  ALU pipe: float; $624
        add (16|M0)              r64.0<1>:f    acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $623
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $616
        sync.nop                             null                             {Compacted,$12.dst}    // $616
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$13} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $616
        sync.nop                             null                             {Compacted,$13.dst}    // 
        sync.nop                             null                             {Compacted,$13.src}    // 
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; 
// B055: [inDivergent],  Preds:{B054, B050},  Succs:{B069}
_0_067:
        join (16|M0)                         _0_063                                                  // 
L14184:
        add (16|M0)              acc0.0<1>:f   r60.0<1;1,0>:f    r64.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $626
        mul (16|M0)              r60.0<1>:f    acc0.0<1;1,0>:f   r61.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $627
        goto (16|M0)                         _0_063            _0_068                                // $628
// B056: [FCALL],  [inDivergent],  Preds:{B048},  Succs:{B057}
_0_063:
        join (16|M0)                         _0_061                                                  // 
L14232:
        shl (16|M0)              r61.0<1>:d    r65.0<1;1,0>:d    23:w               {Compacted,F@1}  //  ALU pipe: int; $630
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $638
        add (16|M0)              r61.0<1>:d    r61.0<1;1,0>:d    -1979711488:d               {I@2}   //  ALU pipe: int; $631
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $638
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $637
        mul (16|M0)              r62.0<1>:f    r60.0<1;1,0>:f    r61.0<1;1,0>:f   {Compacted,I@3}    //  ALU pipe: float; $632
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$6} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $638
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$7} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $638
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $634
        mov (16|M0)              r27.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $635
        mov (16|M0)              r28.0<1>:f    -r62.0<1;1,0>:f                  {Compacted,F@3}      //  ALU pipe: float; $633
        sync.nop                             null                             {Compacted,$7.src}     // $638
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$6.src}             //  ALU pipe: int; $638
        sync.allrd                           null                             {A@1}                  // $638
        sync.allwr                           null                                                    // $638
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $638
// B057: [FCALL],  [inDivergent],  Preds:{B056},  Succs:{B058}
_L_k0_42_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $638
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $638
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $638
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $643
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@3}      //  ALU pipe: float; $639
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$12} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $638
        sync.nop                             null                             {Compacted,$12.dst}    // $638
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$13} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $638
        sync.nop                             null                             {Compacted,$13.dst}    // $641
        mov (16|M0)              r27.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $641
        mov (16|M0)              r26.0<1>:f    r60.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $640
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$12} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $644
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$13} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $644
        sync.nop                             null                             {Compacted,$13.src}    // $644
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$12.src}            //  ALU pipe: int; $644
        sync.allrd                           null                             {A@1}                  // $644
        sync.allwr                           null                                                    // $644
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $644
// B058: [FCALL],  [inDivergent],  Preds:{B057},  Succs:{B059}
_L_k0_43_:
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $644
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $644
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $644
(W)     mov (1|M0)               r127.0<2>:ud  r63.0<0;1,0>:uq                                       //  ALU pipe: int; $649
        mov (16|M0)              r28.0<1>:f    r26.0<1;1,0>:f                   {Compacted,F@1}      //  ALU pipe: float; $645
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@2,$14} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $644
        sync.nop                             null                             {Compacted,$14.dst}    // $644
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$15} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $644
        sync.nop                             null                             {Compacted,$15.dst}    // $647
        mov (16|M0)              r27.0<1>:f    r61.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $647
        mov (16|M0)              r26.0<1>:f    r64.0<1;1,0>:f                   {Compacted}          //  ALU pipe: float; $646
(W)     store.ugm.d32x16t.a32 (1|M0)  ss[a0.2][r126:1-0x10000] r1:1  {$14} // ex_desc:a0.2; desc:0x4200D504 //  spill to FP[0*64] of ?; ; $650
(W)     store.ugm.d32x32t.a32 (1|M0)  ss[a0.2][r126:1-0xFFC0] r6:2  {$15} // ex_desc:a0.2; desc:0x4200E504 //  spill to FP[1*64] of ?; ; $650
        sync.nop                             null                             {Compacted,$15.src}    // $650
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$14.src}            //  ALU pipe: int; $650
        sync.allrd                           null                             {A@1}                  // $650
        sync.allwr                           null                                                    // $650
        calla (16|M0)            r127.0        r127.0                           {A@1}                // $650
// B059: [inDivergent],  Preds:{B058},  Succs:{B060, B063}
_L_k0_44_:
        add (16|M0)              r2.0<1>:f     r62.0<1;1,0>:f    r26.0<1;1,0>:f   {Compacted,F@1}    //  ALU pipe: float; $652
        mov (16|M0)              r60.0<1>:ud   r2.0<1;1,0>:f                    {F@1}                //  ALU pipe: int; $658
        add (16|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     -r62.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $653
        mov (16|M0)              r4.0<1>:f     r60.0<1;1,0>:ud                  {I@1}                //  ALU pipe: float; $659
        add (16|M0)              acc1.0<1>:f   r2.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $654
        add (16|M0)              r3.0<1>:f     r2.0<1;1,0>:f     -r4.0<1;1,0>:f   {Compacted,F@2}    //  ALU pipe: float; $660
        add (16|M0)              acc1.0<1>:f   r62.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $655
        add (16|M0)              acc0.0<1>:f   r26.0<1;1,0>:f    -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $656
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $657
        add (16|M0)              acc1.0<1>:f   r3.0<1;1,0>:f     -r2.0<1;1,0>:f   {Compacted,F@4}    //  ALU pipe: float; $661
        add (16|M0)              acc2.0<1>:f   r3.0<1;1,0>:f     -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $662
        add (16|M0)              acc2.0<1>:f   r2.0<1;1,0>:f     -acc2.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $663
        add (16|M0)              acc1.0<1>:f   -r4.0<1;1,0>:f    -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $664
        add (16|M0)              acc1.0<1>:f   acc2.0<1;1,0>:f   acc1.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $665
        add (16|M0)              acc0.0<1>:f   acc1.0<1;1,0>:f   acc0.0<1;1,0>:f  {Compacted}        //  ALU pipe: float; $666
        add (16|M0)              r4.0<1>:f     acc0.0<1;1,0>:f   0x0:f               {Compacted}     //  ALU pipe: float; $667
        add (16|M0)              r2.0<1>:f     r3.0<1;1,0>:f     r4.0<1;1,0>:f    {Compacted,F@1}    //  ALU pipe: float; $668
(W)     mov (1|M0)               r126.6<1>:ud  a0.2<0;1,0>:ud                                        //  ALU pipe: int; $650
        cmp (16|M0)   (gt)f0.1   null<1>:f     r2.0<1;1,0>:f     0x3F000000:f               {F@1}    //  ALU pipe: float; $669
(W)     shr (1|M0)               a0.2<1>:ud    r126.7<0;1,0>:ud  0x4:ud                              //  ALU pipe: int; $650
(W)     add (1|M0)               r126.0<1>:ud  r127.3<0;1,0>:ud  0x10000:ud                          //  ALU pipe: int; $650
(W)     load.ugm.d32x16t.a32 (1|M0)  r1:1       ss[a0.2][r126:1-0x10000]  {I@1,$0} // ex_desc:a0.2; desc:0x4210D500 //  fill from FP[0*64] of ?; ; $650
        sync.nop                             null                             {Compacted,$0.dst}     // $650
(W)     load.ugm.d32x32t.a32 (1|M0)  r6:2       ss[a0.2][r126:1-0xFFC0]  {$1} // ex_desc:a0.2; desc:0x4220E500 //  fill from FP[1*64] of ?; ; $650
        sync.nop                             null                             {Compacted,$1.dst}     // $670
        sync.nop                             null                             {Compacted,$1.src}     // $670
(W)     mov (1|M0)               a0.2<1>:ud    r126.6<0;1,0>:ud                 {$0.src}             //  ALU pipe: int; $670
(f0.1)  goto (16|M0)                         _0_069            _0_069                                //  ALU pipe: int; $670
// B060: [inDivergent],  Preds:{B059},  Succs:{B061, B064}
_0_070:
        cmp (16|M0)   (eq)f0.0   null<1>:f     r2.0<1;1,0>:f     0x3F000000:f               {Compacted} //  ALU pipe: float; $672
(~f0.0) goto (16|M0)                         _0_069            _0_071                                //  ALU pipe: int; $673
// B061: [inDivergent],  Preds:{B060},  Succs:{B062, B063}
_0_072:
        add (16|M0)              acc0.0<1>:f   r2.0<1;1,0>:f     -r3.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $675
        add (16|M0)              acc1.0<1>:f   r2.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $676
        add (16|M0)              acc1.0<1>:f   r3.0<1;1,0>:f     -acc1.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $677
        add (16|M0)              acc0.0<1>:f   r4.0<1;1,0>:f     -acc0.0<1;1,0>:f {Compacted}        //  ALU pipe: float; $678
        add (16|M0)   (gt)f3.1   r2.0<1>:f     acc1.0<1;1,0>:f   acc0.0<1;1,0>:f                     //  ALU pipe: float; $679
(f3.1)  goto (16|M0)                         _0_069            _0_069                                //  ALU pipe: int; $681
// B062: [inDivergent],  Preds:{B061},  Succs:{B063, B064}
_0_073:
        and (16|M0)   (eq)f0.1   null<1>:d     r60.0<1;1,0>:d    1:w               {F@7}             //  ALU pipe: int; $683
(~f0.1) cmp (16|M0)   (ne)f0.1   null<1>:f     r2.0<1;1,0>:f     0x0:f               {A@1}           //  ALU pipe: float; $685
(f0.1)  goto (16|M0)                         _0_069            _0_071                                //  ALU pipe: int; $687
// B063: [inDivergent],  Preds:{B062, B061, B059},  Succs:{B064}
_0_069:
        join (16|M0)                         _0_071                                                  // 
L15376:
        add (16|M0)              r60.0<1>:d    r60.0<1;1,0>:d    1:w               {Compacted}       //  ALU pipe: int; $689
// B064: [inDivergent],  Preds:{B063, B062, B060},  Succs:{B069}
_0_071:
        join (16|M0)                         _0_061                                                  // 
L15400:
        goto (16|M0)                         _0_061            _0_068                                // $691
// B065: [inDivergent],  Preds:{B008},  Succs:{B069}
_0_061:
        join (16|M0)                         _0_059                                                  // 
L15432:
        mov (16|M0)              r60.0<1>:f    0x3F800000:f                               {Compacted,I@4} //  ALU pipe: float; $693
        goto (16|M0)                         _0_059            _0_068                                // $694
// B066: [inDivergent],  Preds:{B007},  Succs:{B069}
_0_059:
        join (16|M0)                         _0_057                                                  // 
L15472:
        mov (16|M0)              r60.0<1>:f    0x0:f                               {Compacted}       //  ALU pipe: float; $696
        goto (16|M0)                         _0_057            _0_068                                // $697
// B067: [inDivergent],  Preds:{B006},  Succs:{B069}
_0_057:
        join (16|M0)                         _0_055                                                  // 
L15512:
        mov (16|M0)              r60.0<1>:f    0x7F800000:f                               {Compacted} //  ALU pipe: float; $699
        goto (16|M0)                         _0_055            _0_068                                // $700
// B068: [inDivergent],  Preds:{B005},  Succs:{B069}
_0_055:
        join (16|M0)                         _0_068                                                  // 
L15552:
        mov (16|M0)              r60.0<1>:f    0x7FC00000:f                               {Compacted} //  ALU pipe: float; $702
// B069: [inDivergent],  Preds:{B068, B067, B066, B065, B064, B055},  Succs:{B071}
_0_068:
        join (16|M0)                         _0_054                                                  // 
L15576:
        add (16|M0)              r2.0<1>:f     r60.0<1;1,0>:f    0x3F800000:f               {Compacted,F@1} //  ALU pipe: float; $704
        math.inv (16|M0)         r2.0<1>:f     r2.0<1;1,0>:f                    {F@1}                //  ALU pipe: math; $705
        sync.allwr                           ($0,$12)                                                // $708
        shl (16|M0)              r1.0<1>:d     r1.0<1;1,0>:uw    2:w               {$6.dst}          //  ALU pipe: int; $708
        mul (16|M0)              r2.0<1>:f     r2.0<1;1,0>:f     0x40000000:f               {Compacted,M@1} //  ALU pipe: float; $706
        store.slm.d32.a32 (16|M0)  [r1:1]       r2:1               {A@1,$2} // ex_desc:0x0; desc:0x2000504 // $709
        mov (16|M0)              r60.0<1>:d    -1:w                               {Compacted}        //  ALU pipe: int; $710
        goto (16|M0)                         _0_054            _0_054                                // $711
// B070: [inDivergent],  Preds:{B002},  Succs:{B071}
_0_050:
        mov (16|M0)              r60.0<1>:d    0:w                               {Compacted}         //  ALU pipe: int; $713
// B071: Preds:{B070, B069, B004},  Succs:{B072, B089}
_0_054:
        join (16|M0)                         L15704                                                  // 
L15704:
        sync.allwr                           ($0,$6)                                                 // $715
        sync.nop                             null                             {Compacted,$2.src}     // $715
(W)     send.slm (1|M0)          r1       r125  null:0  0x0            0x0210001F           {$12} // wr:1+0, rd:1; fence.slm.none.group // $715
        sync.allwr                           ($1,$13)                                                // $716
(W)     mov (1|M0)               r7.2<1>:f     0x100:f                               {$7.dst}        //  signal barrier payload init (active only); (0x00000100:f); ALU pipe: float; $716
(W)     mov (2|M0)               r7.10<1>:ub   r125.11<0;1,0>:ub                {F@1}                //  signal barrier payload (nprods, ncons); ALU pipe: int; $716
(W)     mov (8|M0)               null<1>:ud    r1.0<1;1,0>:ud                   {Compacted,$12.dst}  //  memory fence commit; ALU pipe: int; $716
(W)     send.gtwy (1|M0)         null     r7  null:0  0x0            0x02000004           {I@2,$3} // wr:1+0, rd:0; signal barrier // $716
(W)     sync.bar                             0x0                                                     // $716
        cmp (16|M0)   (lt)f3.0   null<1>:d     r68.0<1;1,0>:ud   r7.9<0;1,0>:ud                      //  ALU pipe: int; $717
(~f3.0) goto (16|M0)                         _0_074            _0_074                                //  ALU pipe: int; $718
// B072: [inDivergent],  Preds:{B071},  Succs:{B073, B074}
_0_075:
        shl (16|M0)              r2.0<1>:q     r66.0<1;1,0>:q    5:w               {Compacted}       //  ALU pipe: int; $720
        and (16|M0)              r4.0<2>:d     r2.0<2;1,0>:d     -32:w               {I@1}           //  ALU pipe: int; $721
        and (16|M0)              r4.1<2>:d     r2.1<2;1,0>:d     3:w                                 //  ALU pipe: int; $722
        add (16|M0)              r2.0<1>:q     r4.0<1;1,0>:q     r6.2<0;1,0>:q    {Compacted,I@1}    //  ALU pipe: int; $723
        load.ugm.d32x4.a64 (16|M0)  r8:4        [r2:2]             {I@1,$4} // ex_desc:0x0; desc:0x4403580 // $725
        add (16|M0)              r2.0<1>:f     r8.0<1;1,0>:f     r9.0<1;1,0>:f    {Compacted,$4.dst} //  ALU pipe: float; $726
        add (16|M0)              acc0.0<1>:f   r10.0<1;1,0>:f    r11.0<1;1,0>:f   {Compacted}        //  ALU pipe: float; $727
        add (16|M0)              r2.0<1>:f     r2.0<1;1,0>:f     acc0.0<1;1,0>:f  {Compacted,F@2}    //  ALU pipe: float; $728
        and (16|M0)              r1.0<1>:d     r2.0<1;1,0>:d     2147483647:d               {F@1}    //  ALU pipe: int; $729
        cmp (16|M0)   (gt)f2.1   null<1>:d     r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $730
(f2.1)  goto (16|M0)                         _0_076            _0_076                                //  ALU pipe: int; $731
// B073: [inDivergent],  Preds:{B072},  Succs:{B075}
_0_077:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $733
        and (16|M0)              acc0.0<1>:d   r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $734
        add3 (16|M0)             r1.0<1>:d     acc0.0<1;0>:d     r2.0<1;0>:d       32767:w               //  ALU pipe: int; $735
        shr (16|M0)              r1.0<1>:ud    r1.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $736
        mov (16|M0)              r7.0<1>:w     r1.0<2;1,0>:w                    {@1,$3.src}          //  ALU pipe: int; $737
        goto (16|M0)                         _0_076            _0_078                                // $738
// B074: [inDivergent],  Preds:{B072},  Succs:{B075}
_0_076:
        join (16|M0)                         _0_078                                                  // 
L16104:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $740
        or (16|M0)               r7.0<1>:w     r1.0<2;1,0>:w     64:w               {@1,$3.src}      //  ALU pipe: int; $742
// B075: [inDivergent],  Preds:{B074, B073},  Succs:{B076, B089}
_0_078:
        join (16|M0)                         _0_074                                                  // 
L16152:
        shl (16|M0)              r2.0<1>:q     r66.0<1;1,0>:q    1:w               {Compacted}       //  ALU pipe: int; $744
        cmp (16|M0)   (ne)f2.0   null<1>:d     r60.0<1;1,0>:d    0:w                                 //  ALU pipe: int; $749
        mov (16|M0)              r1.0<1>:ud    r7.0<1;1,0>:uw                   {I@4}                //  ALU pipe: int; $747
        add (16|M0)              r4.0<1>:q     r2.0<1;1,0>:q     r6.3<0;1,0>:q    {Compacted,I@3}    //  ALU pipe: int; $745
        store.ugm.d16u32.a64 (16|M0)  [r4:2]    r1:1               {I@1,$5} // ex_desc:0x0; desc:0x4000B84 // $748
(~f2.0) goto (16|M0)                         _0_074            _0_074                                //  ALU pipe: int; $750
// B076: [inDivergent],  Preds:{B075},  Succs:{B077, B078}
_0_079:
        and (16|M0)              r8.0<2>:d     r2.0<2;1,0>:d     -2:w                                //  ALU pipe: int; $754
        and (16|M0)              r8.1<2>:d     r2.1<2;1,0>:d     1:w                                 //  ALU pipe: int; $755
        add (16|M0)              r10.0<1>:q    r8.0<1;1,0>:q     r6.6<0;1,0>:q    {I@1}              //  ALU pipe: int; $756
        load.ugm.d16u32.a64 (16|M0)  r1:1       [r10:2]            {I@1,$6} // ex_desc:0x0; desc:0x4100B80 // $758
(W)     mov (1|M0)               r6.0<1>:ud    0x0:uw                                                //  ALU pipe: int; $760
        mov (16|M0)              r4.0<1>:d     r7.0<1;1,0>:uw                   {$5.src}             //  ALU pipe: int; $752
(W)     load.slm.d32x1t.a32 (1|M0)  r6:1        [r6:1]             {I@2,$7} // ex_desc:0x0; desc:0x2108500 // $761
        shl (16|M0)              r4.0<1>:d     r4.0<1;1,0>:d     16:w               {Compacted,I@1}  //  ALU pipe: int; $753
        sync.nop                             null                             {Compacted,I@1}        // $762
        mul (16|M0)              r2.0<1>:f     r6.0<0;1,0>:f     r4.0<1;1,0>:f    {Compacted,$7.dst} //  ALU pipe: float; $762
        shl (16|M0)              r1.0<1>:d     r1.0<1;1,0>:ud    16:w               {$6.dst}         //  ALU pipe: int; $759
        add (16|M0)              r2.0<1>:f     r2.0<1;1,0>:f     r1.0<1;1,0>:f    {Compacted,A@1}    //  ALU pipe: float; $763
        and (16|M0)              r1.0<1>:d     r2.0<1;1,0>:d     2147483647:d               {F@1}    //  ALU pipe: int; $764
        cmp (16|M0)   (gt)f1.1   null<1>:d     r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $765
(f1.1)  goto (16|M0)                         _0_080            _0_080                                //  ALU pipe: int; $766
// B077: [inDivergent],  Preds:{B076},  Succs:{B079}
_0_081:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $768
        and (16|M0)              acc0.0<1>:d   r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $769
        add3 (16|M0)             r1.0<1>:d     acc0.0<1;0>:d     r2.0<1;0>:d       32767:w               //  ALU pipe: int; $770
        shr (16|M0)              r1.0<1>:ud    r1.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $771
        mov (16|M0)              r6.0<1>:w     r1.0<2;1,0>:w                    {I@1}                //  ALU pipe: int; $772
        goto (16|M0)                         _0_080            _0_082                                // $773
// B078: [inDivergent],  Preds:{B076},  Succs:{B079}
_0_080:
        join (16|M0)                         _0_082                                                  // 
L16544:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $775
        or (16|M0)               r6.0<1>:w     r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $777
// B079: [inDivergent],  Preds:{B078, B077},  Succs:{B080, B081}
_0_082:
        join (16|M0)                         _0_074                                                  // 
L16592:
        mov (16|M0)              r1.0<1>:ud    r6.0<1;1,0>:uw                   {I@2}                //  ALU pipe: int; $779
        store.ugm.d16u32.a64 (16|M0)  [r10:2]   r1:1               {I@1,$8} // ex_desc:0x0; desc:0x4000B84 // $780
        add (16|M0)              r2.0<1>:d     r68.0<1;1,0>:d    r7.9<0;1,0>:d    {Compacted}        //  ALU pipe: int; $781
        mov (16|M0)              r8.0<2>:ud    r2.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $783
        shl (16|M0)              r2.0<1>:q     r8.0<2;1,0>:ud    1:w               {I@1}             //  ALU pipe: int; $783
        add (16|M0)              r8.0<1>:q     r2.0<1;1,0>:q     r6.6<0;1,0>:q    {I@1}              //  ALU pipe: int; $784
(W)     mov (1|M0)               r6.0<1>:ud    0x4:uw                                                //  ALU pipe: int; $788
(W)     load.slm.d32x1t.a32 (1|M0)  r6:1        [r6:1]             {I@1,$9} // ex_desc:0x0; desc:0x2108500 // $789
        mul (16|M0)              r2.0<1>:f     r6.0<0;1,0>:f     r4.0<1;1,0>:f    {Compacted,$9.dst} //  ALU pipe: float; $790
        load.ugm.d16u32.a64 (16|M0)  r1:1       [r8:2]             {$10} // ex_desc:0x0; desc:0x4100B80 // $786
        shl (16|M0)              r1.0<1>:d     r1.0<1;1,0>:ud    16:w               {$10.dst}        //  ALU pipe: int; $787
        add (16|M0)              r2.0<1>:f     r2.0<1;1,0>:f     r1.0<1;1,0>:f    {Compacted,A@1}    //  ALU pipe: float; $791
        and (16|M0)              r1.0<1>:d     r2.0<1;1,0>:d     2147483647:d               {F@1}    //  ALU pipe: int; $792
        cmp (16|M0)   (gt)f1.0   null<1>:d     r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $793
(f1.0)  goto (16|M0)                         _0_083            _0_083                                //  ALU pipe: int; $794
// B080: [inDivergent],  Preds:{B079},  Succs:{B082}
_0_084:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $796
        and (16|M0)              acc0.0<1>:d   r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $797
        add3 (16|M0)             r1.0<1>:d     acc0.0<1;0>:d     r2.0<1;0>:d       32767:w               //  ALU pipe: int; $798
        shr (16|M0)              r1.0<1>:ud    r1.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $799
        mov (16|M0)              r6.0<1>:w     r1.0<2;1,0>:w                    {I@1}                //  ALU pipe: int; $800
        goto (16|M0)                         _0_083            _0_085                                // $801
// B081: [inDivergent],  Preds:{B079},  Succs:{B082}
_0_083:
        join (16|M0)                         _0_085                                                  // 
L16904:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $803
        or (16|M0)               r6.0<1>:w     r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $805
// B082: [inDivergent],  Preds:{B081, B080},  Succs:{B083, B084}
_0_085:
        join (16|M0)                         _0_074                                                  // 
L16952:
        mov (16|M0)              r1.0<1>:ud    r6.0<1;1,0>:uw                   {I@2}                //  ALU pipe: int; $807
        store.ugm.d16u32.a64 (16|M0)  [r8:2]    r1:1               {I@1,$11} // ex_desc:0x0; desc:0x4000B84 // $808
(W)     shl (1|M0)               r6.0<1>:d     r7.9<0;1,0>:d     1:w               {Compacted}       //  ALU pipe: int; $809
(W)     mov (1|M0)               r7.0<1>:ud    0x8:uw                              {$3.src}          //  ALU pipe: int; $817
        add (16|M0)              r1.0<1>:d     r6.0<0;1,0>:d     r68.0<1;1,0>:d   {Compacted,@2,$11.src} //  ALU pipe: int; $810
        mov (16|M0)              r2.0<2>:ud    r1.0<1;1,0>:ud                   {Compacted,I@1}      //  ALU pipe: int; $812
        shl (16|M0)              r10.0<1>:q    r2.0<2;1,0>:ud    1:w               {@1,$8.src}       //  ALU pipe: int; $812
        add (16|M0)              r8.0<1>:q     r10.0<1;1,0>:q    r6.6<0;1,0>:q    {I@1}              //  ALU pipe: int; $813
(W)     load.slm.d32x1t.a32 (1|M0)  r6:1        [r7:1]             {I@1,$12} // ex_desc:0x0; desc:0x2108500 // $818
        mul (16|M0)              r2.0<1>:f     r6.0<0;1,0>:f     r4.0<1;1,0>:f    {Compacted,$12.dst} //  ALU pipe: float; $819
        load.ugm.d16u32.a64 (16|M0)  r1:1       [r8:2]             {$13} // ex_desc:0x0; desc:0x4100B80 // $815
        shl (16|M0)              r1.0<1>:d     r1.0<1;1,0>:ud    16:w               {$13.dst}        //  ALU pipe: int; $816
        add (16|M0)              r2.0<1>:f     r2.0<1;1,0>:f     r1.0<1;1,0>:f    {Compacted,A@1}    //  ALU pipe: float; $820
        and (16|M0)              r1.0<1>:d     r2.0<1;1,0>:d     2147483647:d               {F@1}    //  ALU pipe: int; $821
        cmp (16|M0)   (gt)f0.1   null<1>:d     r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $822
(f0.1)  goto (16|M0)                         _0_086            _0_086                                //  ALU pipe: int; $823
// B083: [inDivergent],  Preds:{B082},  Succs:{B085}
_0_087:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $825
        and (16|M0)              acc0.0<1>:d   r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $826
        add3 (16|M0)             r1.0<1>:d     acc0.0<1;0>:d     r2.0<1;0>:d       32767:w               //  ALU pipe: int; $827
        shr (16|M0)              r1.0<1>:ud    r1.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $828
        mov (16|M0)              r6.0<1>:w     r1.0<2;1,0>:w                    {I@1}                //  ALU pipe: int; $829
        goto (16|M0)                         _0_086            _0_088                                // $830
// B084: [inDivergent],  Preds:{B082},  Succs:{B085}
_0_086:
        join (16|M0)                         _0_088                                                  // 
L17272:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $832
        or (16|M0)               r6.0<1>:w     r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $834
// B085: [inDivergent],  Preds:{B084, B083},  Succs:{B086, B087}
_0_088:
        join (16|M0)                         _0_074                                                  // 
L17320:
        mov (16|M0)              r2.0<1>:ud    r6.0<1;1,0>:uw                   {I@2}                //  ALU pipe: int; $836
        store.ugm.d16u32.a64 (16|M0)  [r8:2]    r2:1               {I@1,$14} // ex_desc:0x0; desc:0x4000B84 // $837
        mad (16|M0)              r1.0<1>:d     r68.0<1;0>:d      r7.9<0;0>:d       3:w               //  ALU pipe: int; $838
        mov (16|M0)              r8.0<2>:ud    r1.0<1;1,0>:ud                   {Compacted,@1,$14.src} //  ALU pipe: int; $840
        shl (16|M0)              r2.0<1>:q     r8.0<2;1,0>:ud    1:w               {I@1}             //  ALU pipe: int; $840
        add (16|M0)              r8.0<1>:q     r2.0<1;1,0>:q     r6.6<0;1,0>:q    {I@1}              //  ALU pipe: int; $841
(W)     mov (1|M0)               r6.0<1>:ud    0xC:uw                                                //  ALU pipe: int; $845
(W)     load.slm.d32x1t.a32 (1|M0)  r6:1        [r6:1]             {I@1,$15} // ex_desc:0x0; desc:0x2108500 // $846
        mul (16|M0)              r2.0<1>:f     r6.0<0;1,0>:f     r4.0<1;1,0>:f    {Compacted,$15.dst} //  ALU pipe: float; $847
        load.ugm.d16u32.a64 (16|M0)  r1:1       [r8:2]             {$0} // ex_desc:0x0; desc:0x4100B80 // $843
        shl (16|M0)              r1.0<1>:d     r1.0<1;1,0>:ud    16:w               {$0.dst}         //  ALU pipe: int; $844
        add (16|M0)              r2.0<1>:f     r2.0<1;1,0>:f     r1.0<1;1,0>:f    {Compacted,A@1}    //  ALU pipe: float; $848
        and (16|M0)              r1.0<1>:d     r2.0<1;1,0>:d     2147483647:d               {F@1}    //  ALU pipe: int; $849
        cmp (16|M0)   (gt)f0.0   null<1>:d     r1.0<1;1,0>:ud    0x7F800000:ud              {I@1}    //  ALU pipe: int; $850
(f0.0)  goto (16|M0)                         _0_089            _0_089                                //  ALU pipe: int; $851
// B086: [inDivergent],  Preds:{B085},  Succs:{B088}
_0_090:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $853
        and (16|M0)              acc0.0<1>:d   r1.0<1;1,0>:d     1:w               {Compacted,I@1}   //  ALU pipe: int; $854
        add3 (16|M0)             r1.0<1>:d     acc0.0<1;0>:d     r2.0<1;0>:d       32767:w               //  ALU pipe: int; $855
        shr (16|M0)              r1.0<1>:ud    r1.0<1;1,0>:ud    16:w               {I@1}            //  ALU pipe: int; $856
        mov (16|M0)              r3.0<1>:w     r1.0<2;1,0>:w                    {I@1}                //  ALU pipe: int; $857
        goto (16|M0)                         _0_089            _0_091                                // $858
// B087: [inDivergent],  Preds:{B085},  Succs:{B088}
_0_089:
        join (16|M0)                         _0_091                                                  // 
L17640:
        shr (16|M0)              r1.0<1>:ud    r2.0<1;1,0>:ud    16:w                                //  ALU pipe: int; $860
        or (16|M0)               r3.0<1>:w     r1.0<2;1,0>:w     64:w               {I@1}            //  ALU pipe: int; $862
// B088: [inDivergent],  Preds:{B087, B086},  Succs:{B089}
_0_091:
        join (16|M0)                         _0_074                                                  // 
L17688:
        mov (16|M0)              r1.0<1>:ud    r3.0<1;1,0>:uw                   {I@2}                //  ALU pipe: int; $864
        store.ugm.d16u32.a64 (16|M0)  [r8:2]    r1:1               {I@1,$1} // ex_desc:0x0; desc:0x4000B84 // $865
// B089: Preds:{B088, B075, B071},  Succs:{}
_0_074:
        join (16|M0)                         L17736                                                  // 
L17736:
(W)     mov (16|M0)              r112.0<1>:f   r125.0<1;1,0>:f                  {Compacted}          //  ALU pipe: float; $867
(W)     send.gtwy (1|M0)         null     r112  null:0  0x0            0x02000010           {EOT,F@1,$2} // wr:1+0, rd:0; end of thread // $867
L17760:
(W)     mov (16|M0)              null<1>:ud    0x1038AC5D:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x659BDD31:ud                                         // 
(W)     mov (16|M0)              null<1>:ud    0x0:ud                                                // 
(W)     mov (16|M0)              null<1>:ud    0x5:ud                                                // 


//.BankConflicts: 0
//.ByteRMWs: 0
//


//.numALUInst: 1099
//.accSubDef: 223
//.accSubUse: 370
//.accSubCandidateDef: 236
//.accSubCandidateUse: 383
//
//
//.singlePipeAtOneDistNum: 141
//.allAtOneDistNum: 57
//.syncInstCount: 142
//.tokenReuseCount: 0
//.AfterWriteTokenDepCount: 25
//.AfterReadTokenDepCount: 109
