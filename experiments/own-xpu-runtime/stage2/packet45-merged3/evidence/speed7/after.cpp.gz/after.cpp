#include "round2.hpp"
#include "owner_api.hpp"
#include <sys/mman.h>
#include "../packet2/loader/gguf.hpp"
#include "../packet3/step/plan.hpp"
#include "small_gemv.hpp"
#include "dispatch.hpp"
#include "p39_plan.hpp"
#include <iostream>
#include <filesystem>
#include <unordered_map>
using namespace integrated; namespace fs=std::filesystem;
static void require(bool ok,const std::string& msg){if(!ok)throw std::runtime_error(msg);}
struct Options {bool mini=false,first=false,pipeline_mini=false;int context=4096,cards=1,draft_rank=0,target_split=0;std::string nongemv="parallel",gemv="r5";};
struct Weights {flash::Directory directory;void synthesize(const flash::Plan&){throw std::logic_error("no synthetic or model weights");}};
static flash::Plan plan(Weights &w, const Options &a) {
  auto g =
      a.mini ? Geometry::tiny() : flash::geometry_from_directory(w.directory);
  g.context = a.mini && !a.pipeline_mini ? 8 : a.context;
  auto p = a.first  ? flash::Builder(g, a.mini ? nullptr : &w.directory)
                          .build({false}, true)
           : a.mini ? flash::Builder(g).build(a.pipeline_mini?std::vector<bool>{false,true,false,true}:std::vector<bool>{false,true})
                    : flash::model_plan(w.directory);
  p.g.context = g.context;
  // Rebuild at bounded request capacity, maintaining packet3's layer schedule.
  if (!a.mini && !a.first) {
    std::vector<bool> full;
    for (int i = 0; i < 48; ++i)
      full.push_back(
          w.directory.count("blk." + std::to_string(i) + ".attn_q.weight"));
    p = flash::Builder(g, &w.directory).build(full);
  }
  if (a.cards == 1) {
    for (auto &b : p.buffers)
      b.card = 0;
    for (auto &l : p.launches) {
      l.card = 0;
      l.source_card = -1;
    }
    std::erase_if(p.launches, [](auto &l) {
      return l.op == "handoff" || l.op == "handoff_result" ||
             l.label == "begin.1" || l.label == "commit.0";
    });
  }
  if (a.mini && a.cards == 2 && !a.first) {
    for (auto &b : p.buffers) {
      if (b.name.starts_with("blk.1.") || b.name.starts_with("final.") ||
          b.name == "logits" || b.name == "token_history" ||
          b.name == "ple_metadata")
        b.card = 1;
      if (b.name == "streams" || b.name == "token" || b.name == "position" ||
          b.name == "active" || b.name == "error" || b.name == "next_token")
        b.card = -1;
    }
    std::vector<flash::Launch> sites;
    bool second = false;
    for (auto l : p.launches) {
      if (l.label == "blk.1.ple.hash") {
        second = true;
        flash::Launch handoff;
        handoff.op = "handoff";
        handoff.label = "handoff";
        handoff.card = 1;
        handoff.source_card = 0;
        handoff.inputs = handoff.outputs = {"streams", "token", "position",
                                            "active", "error"};
        sites.push_back(handoff);
      }
      if (second)
        l.card = 1;
      if (l.op == "commit") {
        flash::Launch back;
        back.op = "handoff_result";
        back.label = "handoff.result";
        back.card = 0;
        back.source_card = 1;
        back.inputs = back.outputs = {"next_token", "error"};
        sites.push_back(back);
        auto first = l;
        first.card = 0;
        first.label = "commit.0";
        sites.push_back(first);
      }
      sites.push_back(l);
      if (l.op == "begin") {
        auto begin = l;
        begin.card = 1;
        begin.label = "begin.1";
        sites.push_back(begin);
      }
    }
    p.launches = std::move(sites);
  }
  if (a.mini)
    w.synthesize(p);
  std::vector<flash::Launch> fused;
  for (size_t i=0;i<p.launches.size();++i) {
    auto l=p.launches[i];
    if(l.op=="routed_gemv" && l.weights[0].find("ffn_gate_exps")!=std::string::npos) {
      require(i+2<p.launches.size(),"gate/up schedule");
      const auto& up=p.launches[i+2];
      require(up.op=="routed_gemv" && up.inputs==l.inputs && up.shape==l.shape &&
              up.weights[0].find("ffn_up_exps")!=std::string::npos,"gate/up dependency");
      l.op="expert_gate_up";
      l.weights.push_back(up.weights[0]);
      l.outputs.insert(l.outputs.end(),up.outputs.begin(),up.outputs.end());
      fused.push_back(l);fused.push_back(p.launches[i+1]);i+=2;
    } else fused.push_back(l);
  }
  p.launches=std::move(fused);
  // Optional arithmetic-preserving specialised fusions. The default schedule is
  // byte-for-byte packet18. The route consumer uses the single source row.
  std::vector<flash::Launch> specialised;
  std::map<std::string,std::string> routed_source;
  for(size_t i=0;i<p.launches.size();++i) {
    auto l=p.launches[i];
    if(a.nongemv=="parallel" && l.op=="route" && i+1<p.launches.size() && p.launches[i+1].op=="expert_gather" &&
       packet26::dispatch.fusion_for("route+gather")) {
      const auto& gather=p.launches[++i];
      l.outputs.push_back(gather.outputs[0]);l.outputs.push_back(gather.outputs[1]);
      routed_source[gather.outputs[2]]=gather.inputs[1];
    }
    if(l.op=="expert_gate_up" && routed_source.count(l.inputs[0]))l.inputs[0]=routed_source.at(l.inputs[0]);
    if(a.nongemv=="parallel" && l.op=="hc_combine" && i+1<p.launches.size()) {
      const auto& next=p.launches[i+1];
      auto fusion_class=l.label;if(fusion_class.starts_with("blk."))fusion_class=fusion_class.substr(fusion_class.find('.',4)+1);
      if(packet26::dispatch.fusion_choice(fusion_class=="attn.combine"?"attention-combine":"shared-down-combine")!="p39.epilogue" && packet26::dispatch.fusion_for(fusion_class+"+norm") && next.op=="norm" && next.card==l.card && next.inputs==l.outputs) {
        l.outputs.insert(l.outputs.end(),next.outputs.begin(),next.outputs.end());
        l.weights=next.weights;l.parameter=next.parameter;++i;
      }
    }
    specialised.push_back(std::move(l));
  }
  p.launches=std::move(specialised);
  if(!a.mini)p39::fuse_plan(p,[&](const std::string&name){return flash::grid_type(w.directory.at(name).grid);});
  return p;
}
static unsigned selected_variant(const Weights& w,const Options& a,const flash::Plan& p,const flash::Launch& l,size_t projection=0) {
    const auto& t=w.directory.at(l.weights[projection]);
    auto choice=packet26::dispatch.gemv_for(l.label);
    if(choice.empty())choice=a.gemv;
    if(choice.starts_with("p25.")||choice.starts_with("p27.")||choice.starts_with("p28.")||choice.starts_with("p29.")||choice.starts_with("p33.")||choice.starts_with("p42.")||choice.starts_with("p30."))choice="r5"; // packed/expanded storage identity is unchanged
    if(choice=="r5")return arithmetic::r5_variant(flash::grid_type(t.grid),l.shape[1],l.shape[2],l.op=="gemv"?1:p.g.experts,a.mini);
    if(choice=="frozen" || choice=="packet18")return arithmetic::variant(flash::grid_type(t.grid),l.shape[1],l.shape[2],l.op=="gemv"?1:p.g.experts,a.mini);
    for(unsigned v=0;v<8;++v)if(choice==arithmetic::name(v)) {
      require(l.op=="gemv" || v==2,"expert dispatch requires registered expert kernel");
      require(!arithmetic::is_expanded(v) || iq3::expanded::quantized(flash::grid_type(t.grid)),"expanded kernel requires quantized weights");
      return v;
    }
    throw std::invalid_argument("GEMV candidate is not linked: "+choice);
}
static flash::Plan split(flash::Plan p,int rank,bool mini,int draft_rank=1,int target_split=0) {
 require(target_split==0||target_split==23||target_split==24,"unsupported target split");
 const int boundary=mini?2:(target_split?target_split:(draft_rank==0?22:24));
 std::vector<flash::Launch> launches;
 for(auto l:p.launches) {
  if(l.op=="handoff"||l.op=="handoff_result")throw std::logic_error("split requires flattened local plan");
  bool keep=l.op=="begin"||l.op=="commit";
  if(l.label.starts_with("blk."))keep=(std::stoi(l.label.substr(4))<boundary)==(rank==0);
  else if(l.op!="begin"&&l.op!="commit")keep=(l.label=="embedding"||l.label=="streams")?(rank==0):(rank==1);
  if(keep){l.card=0;l.source_card=-1;launches.push_back(std::move(l));}
 }
 p.launches=std::move(launches);
 std::set<std::string> used{"streams","token","position","active","error","next_token"};
 for(auto& l:p.launches){used.insert(l.inputs.begin(),l.inputs.end());used.insert(l.outputs.begin(),l.outputs.end());}
 std::erase_if(p.buffers,[&](auto& b){return !used.count(b.name);});
 for(auto& b:p.buffers)b.card=0;
 return p;
}

// Scope the footprint reduction to the previously refused split23/dr1 arm.
// The reference interpreter advertises a 64M-float pool: never shrink it.
// Unknown writers fail closed, rather than silently using an understated ledger.

// Union of all selectable parallel writers, derived from Launch geometry.
// Bounds describe bytes which MAY be written, including every cancelled prefix.
// Unknown operators/reference execution preserve the complete allocation.
struct SnapshotWriteSet {
 static size_t scratch(const flash::Plan& p,const flash::Launch& l,size_t allocation,bool parallel) {
  if(!parallel)return allocation;
  auto ceil=[](size_t n,size_t d){return (n+d-1)/d;};
  size_t n=0;
  if(!l.inputs.empty())for(const auto& b:p.buffers)if(b.card==l.card&&b.name==l.inputs[0]){
   n=1;for(int v:b.shape){require(v>0,"snapshot input geometry");n*=size_t(v);}break;
  }
  size_t bytes=0;const auto& op=l.op;
  if(op=="norm"||op=="hc_combine"){
   if(l.shape.size()<2||l.shape[1]<=0||!n||n%size_t(l.shape[1]))return allocation;
   bytes=(n/size_t(l.shape[1]))*ceil(size_t(l.shape[1]),32)*4;
  }else if(op=="route")bytes=(2*ceil(n,16)+2*n)*4;
  else if(op=="argmax")bytes=2*ceil(n,256)*4;
  else if(op=="expert_gather")bytes=size_t(p.g.top)*4;
  else if(op=="gdn")bytes=p.g.h==2560?4192*4:0;
  else if(op=="gdn_norm_gate")bytes=p.g.h==2560?48*4*4:0;
  else if(op=="qsa_prepare")bytes=p.g.h==2560?30*8*4:0;
  else if(op=="qsa_append_pool")bytes=p.g.h==2560?ceil(size_t(p.g.context),4)*4*4:0;
  else if(op=="qsa_select")bytes=p.g.h==2560?ceil(size_t(p.g.context),4)*4:0;
  else if(op=="qsa_attention")bytes=p.g.h==2560?6144*ceil(size_t(std::min(p.g.context,p.g.budget+3)),32)*4:0;
  else {
   static const std::set<std::string> no_global_scratch={"begin","commit","broadcast","ple_hash","check_status","lookup","handoff","handoff_result","gemv","routed_gemv","expert_gate_up","silu_div4","silu_product","hc_mix","conv","moe_combine","ple_gate","ple_add"};
   if(!no_global_scratch.count(op))return allocation;
  }
  if((op=="route"||op=="argmax")&&!n)return allocation;
  require(bytes<=allocation,"snapshot scratch writer exceeds allocation");return bytes;
 }
 static size_t scratch(const flash::Plan& p,size_t allocation,bool parallel) {
  size_t bound=0;for(const auto& l:p.launches)bound=std::max(bound,scratch(p,l,allocation,parallel));return bound;
 }
 static bool single_row(const flash::Plan& p,const std::string& name,bool parallel) {
  if(!parallel)return false;bool writer=false;
  for(const auto& l:p.launches)if(std::find(l.outputs.begin(),l.outputs.end(),name)!=l.outputs.end()){
   if(l.op!="qsa_append_pool")return false;writer=true;
  }
  return writer;
 }
};

// Only physical spare banks qualify. All plan inputs bind the active bank;
// outputs[1] binds the distinct spare bank (Engine::prepare_plan and banks()).
// GDN writes vh*d rows of d BF16 elements; conv writes width*3*dilation.
// A complete, non-speculative redo therefore replaces EVERY skipped byte.
struct RedoBankProof {
 size_t bytes=0;std::string writer;
 static RedoBankProof derive(const flash::Plan& p,const std::string& name) {
  const flash::Buffer* buffer=nullptr;const flash::Launch* writer=nullptr;
  for(const auto& b:p.buffers)if(b.name==name){if(buffer)return {};buffer=&b;}
  for(const auto& l:p.launches)if(std::find(l.outputs.begin(),l.outputs.end(),name)!=l.outputs.end()){
   if(writer)return {};writer=&l;
  }
  if(!buffer||!writer||buffer->type!=flash::Scalar::bf16||writer->outputs.size()!=2||writer->outputs[1]!=name)return {};
  size_t elements=0;
  if(writer->op=="gdn"){
   if(writer->inputs.size()<4||writer->inputs[3]!=name||p.g.vh<=0||p.g.d<=0||
      writer->shape!=std::vector<int>{p.g.kh,p.g.vh,p.g.d}||buffer->shape!=std::vector<int>{p.g.vh,p.g.d,p.g.d})return {};
   elements=size_t(p.g.vh)*p.g.d*p.g.d;
  }else if(writer->op=="conv"){
   int dilation=writer->parameter;
   if(writer->inputs.size()<2||writer->inputs[1]!=name||writer->shape.size()!=1||writer->shape[0]<=0||
      (dilation!=1&&dilation!=3)||buffer->shape!=std::vector<int>{writer->shape[0],3*dilation})return {};
   elements=size_t(writer->shape[0])*3*dilation;
  }else return {};
  return {elements*flash::scalar_bytes(buffer->type),writer->label};
 }
};


static void check_writer_bound(const flash::Plan& p,const flash::Launch& l,size_t bound){
 ng::Shape s{};s.capacity=p.g.context;s.budget=p.g.budget;s.extent=p.g.context;
 bool check=true;
 size_t n=0;if(!l.inputs.empty())for(const auto& b:p.buffers)if(b.card==l.card&&b.name==l.inputs[0]){n=1;for(int v:b.shape)n*=v;break;}
 if(l.op=="route"){require(bound>=4*(2*((n+15)/16)+2*n),"route writer undercovered");return;}
 if(l.op=="argmax"){require(bound>=8*((n+255)/256),"argmax writer undercovered");return;}
 if(l.op=="expert_gather"){require(bound>=4*size_t(p.g.top),"gather writer undercovered");return;}
 if(l.op=="norm"||l.op=="hc_combine"){s.op=ng::norm;s.width=l.shape.at(1);s.heads=n/s.width;}
 else if(p.g.h!=2560)return;
 else if(l.op=="gdn")s.op=ng::gdn;
 else if(l.op=="gdn_norm_gate")s.op=ng::gated_norm;
 else if(l.op=="qsa_prepare")s.op=ng::prepare;
 else if(l.op=="qsa_append_pool")s.op=ng::pool;
 else if(l.op=="qsa_select")s.op=ng::select;
 else if(l.op=="qsa_attention"){
  for(auto op:{ng::attention_score,ng::attention_softmax,ng::attention_value}){s.op=op;require(bound>=specialised::scratch_floats(s)*4,"attention writer undercovered");require(bound>=round2::scratch_floats(s)*4,"round2 writer undercovered");}return;
 }else check=false;
 if(check){require(bound>=specialised::scratch_floats(s)*4,"specialised writer undercovered");if(round2::supported(s))require(bound>=round2::scratch_floats(s)*4,"round2 writer undercovered");}
}
static void write_proof(const flash::Plan& p){
 constexpr size_t cap=256ull*1024*1024;
 require(SnapshotWriteSet::scratch(p,cap,false)==cap,"reference fallback");
 flash::Launch unknown;unknown.op="unknown-written-extent";
 require(SnapshotWriteSet::scratch(p,unknown,cap,true)==cap,"unknown writer fallback");
 for(const auto* name:{"route","argmax","norm"}){flash::Launch bad;bad.op=name;require(SnapshotWriteSet::scratch(p,bad,cap,true)==cap,"malformed writer fallback");}
 for(const auto& l:p.launches)if(l.op=="route"||l.op=="argmax"||l.op=="expert_gather"){
  bool rejected=false;try{check_writer_bound(p,l,0);}catch(const std::runtime_error&){rejected=true;}require(rejected,"dropped simple scratch writer escaped proof");
 }
 for(const auto& b:p.buffers)if(SnapshotWriteSet::single_row(p,b.name,true)){
  auto changed=p;flash::Launch alias;alias.op="unproved-writer";alias.outputs={b.name};changed.launches.push_back(alias);
  require(!SnapshotWriteSet::single_row(changed,b.name,true),"second cache writer escaped proof");break;
 }
 std::set<std::string> outputs{"token","position","token_history"};for(const auto& l:p.launches)outputs.insert(l.outputs.begin(),l.outputs.end());
 size_t output_bytes=0,output_count=0;for(const auto& b:p.buffers)if(outputs.count(b.name)){size_t n=flash::scalar_bytes(b.type);for(int d:b.shape)n*=size_t(d);output_bytes+=n;++output_count;}
 std::cerr<<"WRITESET {\"scratch_bound\":"<<SnapshotWriteSet::scratch(p,cap,true)<<",\"plan_output_bytes\":"<<output_bytes<<",\"plan_output_count\":"<<output_count<<",\"context\":"<<p.g.context<<",\"budget\":"<<p.g.budget<<",\"sites\":[";
 bool comma=false;
 for(const auto& l:p.launches){
  check_writer_bound(p,l,SnapshotWriteSet::scratch(p,l,cap,true));
  std::cerr<<(comma?",":"")<<"{\"label\":\""<<l.label<<"\",\"op\":\""<<l.op<<"\",\"scratch_bytes\":"<<SnapshotWriteSet::scratch(p,l,cap,true)<<"}";comma=true;
 }
 std::cerr<<"],\"qsa_rows\":[";comma=false;
 for(const auto& b:p.buffers)if(SnapshotWriteSet::single_row(p,b.name,true)){
  size_t bytes=flash::scalar_bytes(b.type);for(int n:b.shape)bytes*=size_t(n);
  bool pooled=b.name.ends_with(".pooled");size_t rows=pooled?size_t((p.g.context+3)/4):size_t(p.g.context);
  require(bytes%rows==0,"single row geometry");
  std::cerr<<(comma?",":"")<<"{\"name\":\""<<b.name<<"\",\"allocation_bytes\":"<<bytes<<",\"row_bytes\":"<<bytes/rows<<",\"pooled\":"<<(pooled?"true":"false")<<"}";comma=true;
 }
 std::cerr<<"]}\n";
 std::cerr<<"REDOBANK [";comma=false;
 for(const auto& b:p.buffers){auto proof=RedoBankProof::derive(p,b.name);if(!proof.bytes)continue;
  auto l=std::find_if(p.launches.begin(),p.launches.end(),[&](const auto& x){return x.label==proof.writer;});require(l!=p.launches.end(),"missing first writer");
  ng::Shape shape{};shape.tokens=1;shape.capacity=p.g.context;shape.extent=p.g.context;shape.budget=p.g.budget;
  shape.op=l->op=="gdn"?ng::gdn:ng::conv;shape.width=l->shape[0];shape.extra=l->parameter;
  require(ng::required_bytes(shape)[l->op=="gdn"?7:4]==proof.bytes,"redo kernel byte coverage");
  auto partial=p;for(auto& x:partial.buffers)if(x.name==b.name)++x.shape.back();require(!RedoBankProof::derive(partial,b.name).bytes,"partial write coverage accepted");
  auto duplicate=p;duplicate.launches.push_back(*l);require(!RedoBankProof::derive(duplicate,b.name).bytes,"multiple writers accepted");
  auto unknown=p;for(auto& x:unknown.launches)if(x.label==proof.writer)x.op="unknown";require(!RedoBankProof::derive(unknown,b.name).bytes,"unknown writer accepted");
  std::cerr<<(comma?",":"")<<"{\"name\":\""<<b.name<<"\",\"first_writer\":\""<<proof.writer<<"\",\"bytes\":"<<proof.bytes<<",\"full_byte_coverage\":true,\"inputs_use_distinct_active_bank\":true}";comma=true;
 }
 std::cerr<<"]\n";
}

static size_t target_scratch_bytes(const flash::Plan& p,const Options& a) {
 constexpr size_t legacy=256ull*1024*1024, bounded=8ull*1024*1024;
 if(a.target_split!=23||a.draft_rank!=1||a.nongemv!="parallel"||
    (!a.mini&&a.context!=4096))return legacy;
 require((a.mini||p.g.h==2560)&&p.g.context==a.context&&
         p.g.context>0&&p.g.context<=32768&&p.g.budget>0&&p.g.budget<=2048,
         "unproved bounded scratch geometry");
 const size_t required=SnapshotWriteSet::scratch(p,legacy,true);
 require(!p.launches.empty()&&required<=bounded,"unproved bounded scratch extent");
 // SPEED6 plan gate also checks this writer union against the kernels' full
 // scratch_floats read/write requirements. Binding-time extent guards stay on.
 return bounded;
}


struct SparseOwner final:ownrt::Backend {
 std::map<void*,size_t> sizes;size_t copies=0,maximum=0;
 std::string identity()const override{return "SPEED7 sparse CPU extent proof; no arithmetic";}
 void* allocate(size_t n,ownrt::Memory)override {
  auto p=mmap(nullptr,n,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_NORESERVE,-1,0);
  if(p==MAP_FAILED)throw std::bad_alloc();sizes[p]=n;return p;
 }
 void release(void*p,ownrt::Memory)override{munmap(p,sizes.at(p));sizes.erase(p);}
 ownrt::Event copy(void*,const void*,size_t n,std::span<const ownrt::Event>)override{++copies;maximum=std::max(maximum,n);return ownrt::next_handle();}
 ownrt::Event marker(std::span<const ownrt::Event>)override{return ownrt::next_handle();}
 bool complete(ownrt::Event)override{return true;}
 bool wait(ownrt::Event,ownrt::Deadline)override{return true;}
 ownrt::EventTiming timing(ownrt::Event)override{return {};}
 void synchronize()override{}void clear_events()override{}void close_queue()override{}void close_context()override{}
};
static void sparse_workspace(const flash::Plan& p,const Weights& w,size_t scratch_bytes){
 auto backend=std::make_unique<SparseOwner>();auto*trace=backend.get();ownrt::Device d(std::move(backend));ownrt::CopyEngine copy(d);
 auto alloc=[&](const char* name,size_t n){return d.arena.allocate(std::string("card0:")+name,n,ownrt::Memory::device,ownrt::Category::scratch,ownrt::Lifetime::transaction);};
 auto scratch=alloc("operator-scratch",scratch_bytes),workspace=alloc("gemv-workspace",8*1024*1024),peer=alloc("extent-peer",256ull*1024*1024);
 size_t peak=0,workspace_peak=0,checks=0;
 auto both=[&](ownrt::Allocation id,size_t n){if(!n)return;copy.copy(id,0,peer,0,n,{});copy.copy(peer,0,id,0,n,{});checks+=2;};
 for(const auto& l:p.launches){
  size_t n=SnapshotWriteSet::scratch(p,l,256ull*1024*1024,true);peak=std::max(peak,n);both(scratch,n);
  if(l.op!="gemv"&&l.op!="routed_gemv"&&l.op!="expert_gate_up")continue;
  require(l.shape.size()==3,"workspace matrix shape");bool routed=l.op!="gemv";
  size_t count=routed?size_t(p.g.top):1,rows=l.shape[1],columns=l.shape[2];
  // P28/P33 full extent contract: eight floats per output row/route.
  size_t need=rows*count*8*4;
  if(routed){
   const auto& tensor=w.directory.at(l.weights[0]);auto grid=iq3::layout(flash::grid_type(tensor.grid));
   require(grid.elements&&columns%grid.elements==0,"workspace quantization block");
   // Conservative union including P25 half-table paired routed scales.
   need=std::max(need,l.weights.size()*count*rows*(columns/std::min(size_t(grid.elements),size_t(32)))*4);
  }
  require(need<=8*1024*1024,"GEMV workspace peak exceeds allocation");workspace_peak=std::max(workspace_peak,need);both(workspace,need);
 }
 require(peak>0&&workspace_peak>0,"empty sparse plan");size_t negatives=0;
 auto reject=[&](ownrt::Allocation id,size_t n){try{copy.copy(id,0,peer,0,n,{});}catch(const std::out_of_range&){++negatives;return;}throw std::runtime_error("short sparse extent accepted");};
 auto short_scratch=alloc("short-scratch",peak-1),short_workspace=alloc("short-workspace",workspace_peak-1);
 reject(short_scratch,peak);reject(short_workspace,workspace_peak);reject(peer,134217729);
 auto end=d.shutdown(std::chrono::seconds(5));require(end.safe_to_exit&&end.exit_code==0,"sparse owner teardown");
 std::cerr<<"SPARSE {\"passed\":true,\"device_executed\":false,\"scratch_peak_bytes\":"<<peak
          <<",\"workspace_peak_bytes\":"<<workspace_peak<<",\"owner_checks\":"<<checks
          <<",\"negative_controls\":"<<negatives<<",\"maximum_copy\":"<<trace->maximum<<"}\n";
}


static void scratch_allocation_proof(const flash::Plan& p,const Options& a,const Weights& w,bool draft=false){
 constexpr size_t old=256ull*1024*1024,cap=8ull*1024*1024;
 bool reduced=!draft&&a.target_split==23&&a.draft_rank==1&&a.context==4096;
 size_t actual=draft?cap:target_scratch_bytes(p,a); // DraftRuntime already uses 8 MiB.
 require(actual==((draft||reduced)?cap:old),"scratch allocation policy mismatch");
 sparse_workspace(p,w,actual);
 // check_writer_bound uses full kernel scratch_floats requirements, which
 // cover reads as well as writes, for specialised, round2, p33r2 and p42.
 for(const auto& l:p.launches){
  size_t bound=SnapshotWriteSet::scratch(p,l,old,true);
  require(bound<=actual,"allocation below possible writer extent");
  check_writer_bound(p,l,bound);
 }
 auto reference=a;reference.nongemv="core";
 require(target_scratch_bytes(p,reference)==old,"reference scratch shrunk");
 if(reduced){
  auto changed=p;flash::Launch bad;bad.op="unregistered-scratch-reader";changed.launches.push_back(bad);
  bool refused=false;try{(void)target_scratch_bytes(changed,a);}catch(const std::runtime_error&){refused=true;}
  require(refused,"unknown scratch footprint accepted");
  auto wider=p;wider.g.budget=2049;refused=false;
  try{(void)target_scratch_bytes(wider,a);}catch(const std::runtime_error&){refused=true;}
  require(refused,"unregistered geometry accepted");
 }
 std::cerr<<"SCRATCHALLOC {\"bytes\":"<<actual<<",\"draft_private\":"<<(draft?"true":"false")<<",\"reduced\":"<<(reduced?"true":"false")
          <<",\"kernel_read_write_requirements_checked\":true,\"reference_preserved\":true}\n";
}

struct Probe {
 Weights&w;Options a;flash::Plan p;
 struct SmallGroup {std::string name;std::vector<const flash::Launch*> members;};
 std::unordered_map<const flash::Launch*,SmallGroup> small_groups;
 std::unordered_map<const flash::Launch*,const flash::Launch*> small_followers;
 unsigned variant(const flash::Launch&l){return selected_variant(w,a,p,l);}
 Probe(Weights& ww,Options aa,flash::Plan pp):w(ww),a(aa),p(std::move(pp)){
    // Only move sibling projections whose shared input already exists here.
    // The immutable plan stays intact for the reference oracle and fixtures.
    auto enabled=[&](const std::string& key){auto i=packet26::dispatch.fusions.find(key);return i!=packet26::dispatch.fusions.end()&&(i->second=="round2"||i->second=="p30.small.rows4");};
    for(const auto& first:p.launches){if(first.op!="gemv")continue;
      auto cls=packet26::Dispatch::class_name(first.label);std::string key,name;std::vector<std::string> labels;
      if((cls=="hc.a.low"||cls=="hc.f.low")&&enabled("small.hc")){
        key="small.hc";labels={first.label,first.label.substr(0,first.label.size()-3)+"inject"};
      }else if(cls=="gdn.a"&&enabled("small.gdn.ab")){
        key="small.gdn.ab";labels={first.label,first.label.substr(0,first.label.size()-1)+"b"};
      }else if(cls=="router"&&enabled("small.ffn")){
        key="small.ffn";auto prefix=first.label.substr(0,first.label.size()-6);labels={first.label,prefix+"shexpgate",prefix+"shexpup",prefix+"shared_gate"};
      }else continue;
      SmallGroup group;bool available=true;
      for(const auto& label:labels){const flash::Launch* found=nullptr;for(const auto& member:p.launches)if(member.label==label){require(!found,"duplicate small GEMV site");found=&member;}
        // A partial plan or an earlier P39 epilogue rewrite has no complete
        // primitive GEMV tuple here. Keep its existing schedule and arithmetic.
        if(!found||p39::tagged(*found))available=false;
        group.members.push_back(found);
      }
      if(!available)continue;
      for(const auto* found:group.members)
        require(found->op=="gemv"&&found->card==first.card&&found->inputs==first.inputs,"small GEMV sibling schedule/input");
      // Reordering is legal only while inputs remain unchanged, outputs are not
      // overwritten, and no intervening site reads the not-yet-original output.
      // Builder appends active/error control labels to every GEMV's metadata.
      // Dense GEMV binds only inputs[0]; check_status writes error between the
      // router and shared branch. That is not a write to the GEMV input vector.
      const size_t first_index=size_t(&first-p.launches.data());
      for(size_t member_index=1;member_index<group.members.size();++member_index){
        const auto& member=*group.members[member_index];const size_t original=size_t(&member-p.launches.data());
        require(original>first_index,"small GEMV follower precedes first member");
        for(size_t between=first_index+1;between<original;++between){const auto& site=p.launches[between];
          require(site.card==first.card,"small GEMV crosses card ownership boundary");
          for(const auto& output:site.outputs){require(output!=first.inputs.at(0),"small GEMV input vector overwritten before follower");require(std::find(member.outputs.begin(),member.outputs.end(),output)==member.outputs.end(),"small GEMV early output overwritten");}
          for(const auto& input:site.inputs)require(std::find(member.outputs.begin(),member.outputs.end(),input)==member.outputs.end(),"small GEMV output read before original site");
        }
      }
      name=a.mini?(key=="small.hc"?"small.mini.hc":key=="small.gdn.ab"?"small.mini.gdn.ab":"small.mini.ffn"):key;
      if(!a.mini&&key=="small.ffn"){
        auto gate=flash::grid_type(w.directory.at(group.members[1]->weights[0]).grid),up=flash::grid_type(w.directory.at(group.members[2]->weights[0]).grid);
        require(gate==up&&(gate==iq3::Type::Q6_K||gate==iq3::Type::Q8_0),"unregistered small FFN format tuple");name+=gate==iq3::Type::Q6_K?".q6":".q8";
      }
      const auto expected=packet27::small::shapes(name);
      for(size_t i=0;i<expected.size();++i){const auto& member=*group.members[i];const auto& e=expected[i];
        require(flash::grid_type(w.directory.at(member.weights[0]).grid)==e.type&&member.shape[1]==int(e.rows)&&member.shape[2]==int(e.columns)&&variant(member)==e.variant,"small GEMV dispatch arithmetic tuple mismatch");
      }
      group.name=name;small_groups.emplace(&first,group);
      for(size_t i=1;i<group.members.size();++i)require(small_followers.emplace(group.members[i],&first).second,"overlapping small GEMV groups");
    }
 }
};
static flash::Plan draft_plan(flash::Geometry geometry){flash::Plan p;
  p=flash::Builder(geometry).build({true});std::erase_if(p.launches,[](const auto& l){return l.op=="lookup"||l.op=="broadcast";});
  // Keep plan shape/ops, pair routed gate/up at the same schedule point.
  for(size_t i=0;i+2<p.launches.size();++i)if(p.launches[i].label=="blk.0.expsgate"){
   auto& a=p.launches[i];auto b=p.launches[i+2];require(b.label=="blk.0.expsup","draft paired schedule");a.op="expert_gate_up";a.weights.push_back(b.weights[0]);a.outputs.insert(a.outputs.end(),b.outputs.begin(),b.outputs.end());p.launches.erase(p.launches.begin()+i+2);break;}

return p;}
int main(int argc,char**argv){try{
 require(argc==7,"plan context draft_rank rank dispatch");
 Weights w;w.directory=flash::directory_from_loader(iq3::read_plan("/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet45-merged3/build/input/plan.tsv"));
 Options a;a.context=std::stoi(argv[2]);int dr=std::stoi(argv[3]),rank=std::stoi(argv[4]);
 a.draft_rank=dr;a.target_split=std::stoi(argv[6]);packet26::dispatch.load(argv[5]);auto full=plan(w,a);
 if(std::string(argv[1])=="draft"){
 auto p=draft_plan(full.g);write_proof(p);scratch_allocation_proof(p,a,w,true);std::cout<<"{\"passed\":true,\"groups\":0,\"launches\":"<<p.launches.size()<<",\"draft_uses_own_unfused_dispatch\":true}\n";
 }else{auto p=split(full,rank,false,std::string(argv[1])=="KD"?1:dr,std::stoi(argv[6]));Probe e(w,a,std::move(p));write_proof(e.p);scratch_allocation_proof(e.p,a,w);
 size_t ffns=0,shared=0;std::map<int,size_t> tags;
 for(const auto& [site,g]:e.small_groups)if(g.name.starts_with("small.ffn"))++ffns;
 for(const auto&site:e.p.launches)if(p39::tagged(site)){++tags[int(p39::kind(site))];if(p39::kind(site)==p39::Kind::shared_act)++shared;}
 std::cerr<<"ffn="<<ffns<<" shared="<<shared;
 for(auto[k,v]:tags)std::cerr<<" tag"<<k<<"="<<v;std::cerr<<"\n";
 std::cout<<"{\"passed\":true,\"groups\":"<<e.small_groups.size()<<",\"followers\":"<<e.small_followers.size()<<",\"launches\":"<<e.p.launches.size()<<"}\n";}
 return 0;
 }catch(const std::exception&e){std::cout<<"{\"passed\":false,\"error\":\""<<e.what()<<"\"}\n";return 1;}}
