
#define OWN_RT_HOST_ONLY 1
#include "owner_api.hpp"
#include <sys/mman.h>
#include <iostream>
#include <numeric>
#include <cstring>
#include <map>
namespace integrated {struct HostOperation:ownrt::Operation {virtual void run(std::span<void*const>)const=0;};}
static void require(bool b,const char*s){if(!b)throw std::runtime_error(s);}
#ifdef OWN_RT_HOST_ONLY
struct SnapshotBatch final:integrated::HostOperation {
#else
struct SnapshotBatch final:ownrt::SyclOperation {
#endif
 struct Item {uint8_t* dst=nullptr;const uint8_t* src=nullptr;size_t bytes=0;};
 static constexpr size_t width=32,limit=128ull*1024*1024,size_ratio=8;
 // Sorted extents: bound padding without changing a single copied byte.
 // minimum and bytes have already passed CopyEngine's nonzero/128 MiB guard.
 bool accepts(size_t bytes,size_t minimum)const {
  return count<width&&bytes<=limit-total&&(!count||bytes<=minimum*size_ratio);
 }
 std::array<Item,width> items{};size_t count=0,maximum=0,total=0;
#ifdef OWN_RT_HOST_ONLY
 void run(std::span<void*const>)const override {
  for(size_t i=0;i<count;++i)std::memcpy(items[i].dst,items[i].src,items[i].bytes);
 }
#else
 sycl::event submit(sycl::queue& q,std::span<void*const>,const std::vector<sycl::event>& deps)const override {
  auto values=items;auto rows=count;auto columns=(maximum+15)/16;
  return q.submit([&](sycl::handler& h){h.depends_on(deps);
   h.parallel_for(sycl::range<2>(rows,columns),[=](sycl::id<2> id){
    const auto item=values[id[0]];size_t off=id[1]*16;
    for(size_t j=0;j<16&&off+j<item.bytes;++j)item.dst[off+j]=item.src[off+j];
   });
  });
 }
#endif
};

struct Sparse:ownrt::Backend {
 std::map<void*,size_t> sizes;size_t copies=0;
 std::string identity()const override{return "SPEED7 sparse host; no device";}
 void* allocate(size_t n,ownrt::Memory)override{auto p=mmap(nullptr,n,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS|MAP_NORESERVE,-1,0);if(p==MAP_FAILED)throw std::bad_alloc();sizes[p]=n;return p;}
 void release(void*p,ownrt::Memory)override{munmap(p,sizes.at(p));sizes.erase(p);}
 ownrt::Event copy(void*d,const void*s,size_t n,std::span<const ownrt::Event>)override{std::memcpy(d,s,n);++copies;return ownrt::next_handle();}
 ownrt::Event marker(std::span<const ownrt::Event>)override{return ownrt::next_handle();}
 ownrt::Event compute(const ownrt::Operation&op,std::span<void*const>p,std::span<const ownrt::Event>)override{dynamic_cast<const integrated::HostOperation&>(op).run(p);return ownrt::next_handle();}
 std::function<ownrt::Event()> prepare_owned(std::shared_ptr<const ownrt::Operation>op,std::span<void*const>p)override{std::vector<void*> v(p.begin(),p.end());return [this,op,v]{return compute(*op,v,{});};}
 bool complete(ownrt::Event)override{return true;}bool wait(ownrt::Event,ownrt::Deadline)override{return true;}
 ownrt::EventTiming timing(ownrt::Event)override{return {};}
 void synchronize()override{}void clear_events()override{}void close_queue()override{}void close_context()override{}
};
static void batches(ownrt::Device& d,std::vector<ownrt::PreparedCompute>&checked,const std::vector<size_t>&lengths){
 using ownrt::Allocation;ownrt::Event tail=0;size_t padded=0,largest=0;std::vector<size_t>seen(lengths.size());
  std::vector<size_t> order(lengths.size());for(size_t i=0;i<order.size();++i)order[i]=i;
  std::stable_sort(order.begin(),order.end(),[&](size_t a,size_t b){return lengths[a]<lengths[b];});
  size_t cursor=0,submissions=0;
  while(cursor<order.size()){
   SnapshotBatch batch;std::vector<Allocation> ids;
   size_t start=cursor;
   while(cursor<order.size()&&batch.count<SnapshotBatch::width){
    size_t i=order[cursor],bytes=lengths[i];if(!batch.accepts(bytes,lengths[order[start]]))break;
    require(++seen[i]==1,"duplicate descriptor");const auto& item=checked[i];require(item.ids.size()==2&&item.pointers.size()==2,"snapshot copy descriptor");
    batch.items[batch.count++]={static_cast<uint8_t*>(item.pointers[0]),static_cast<const uint8_t*>(item.pointers[1]),bytes};
    batch.maximum=std::max(batch.maximum,bytes);batch.total+=bytes;
    ids.insert(ids.end(),item.ids.begin(),item.ids.end());++cursor;
   }
   require(batch.count&&batch.total<=SnapshotBatch::limit,"snapshot batch bound");
   if(batch.count==1)tail=d.issue(checked[order[start]]);
   else tail=d.compute(batch,ids,{});
   ++submissions; padded+=batch.count*((batch.maximum+15)/16)*16; largest=std::max(largest,batch.total);
  }

 require(std::all_of(seen.begin(),seen.end(),[](size_t n){return n==1;}),"lost descriptor");
 require(d.wait(tail,std::chrono::seconds(5)),"drain");d.retire_completed_events();
 std::cout<<"{\"batches\":"<<submissions<<",\"padded_byte_slots\":"<<padded<<",\"largest_submission_bytes\":"<<largest<<",\"components\":"<<lengths.size()<<",\"bytes\":"<<std::accumulate(lengths.begin(),lengths.end(),size_t(0))<<"}";
}
int main(){
 auto backend=std::make_unique<Sparse>();ownrt::Device d(std::move(backend));ownrt::CopyEngine copy(d);
 struct Extent {ownrt::Allocation id;size_t full,off,n,back;bool bank;};std::vector<Extent>xs;size_t full,off,n,bank,capacity=0;
 while(std::cin>>full>>off>>n>>bank){require(n&&off<=full&&n<=full-off,"input extent");auto id=d.arena.allocate("card0:source"+std::to_string(xs.size()),full,ownrt::Memory::device,ownrt::Category::scratch,ownrt::Lifetime::transaction);xs.push_back({id,full,off,n,capacity,bool(bank)});capacity+=full;}
 auto backup=d.arena.allocate("card0:backup",capacity,ownrt::Memory::device,ownrt::Category::runtime_overhead,ownrt::Lifetime::process);
 for(auto&x:xs){auto*p=static_cast<unsigned char*>(d.arena.row(x.id).pointer);std::memset(p+x.off,0x35,x.n);if(x.off)p[x.off-1]=0x71;if(x.off+x.n<x.full)p[x.off+x.n]=0x72;}
 std::cout<<"{\"phases\":{";
 for(int mode=0;mode<4;++mode){
  if(mode)std::cout<<",";std::cout<<"\""<<(mode==0?"capture":mode==1?"full_restore":mode==2?"redo_restore":"deferred_restore")<<"\":";
  std::vector<ownrt::PreparedCompute>checked;std::vector<size_t>lengths;d.begin_capture(checked);
  for(auto&x:xs){if(mode==2&&x.bank)continue;if(mode==3&&!x.bank)continue;
   if(mode)std::memset(static_cast<unsigned char*>(d.arena.row(x.id).pointer)+x.off,0x58,x.n);
   for(size_t pos=0;pos<x.n;pos+=SnapshotBatch::limit){size_t count=std::min(x.n-pos,SnapshotBatch::limit);
    if(mode)copy.copy(x.id,x.off+pos,backup,x.back+pos,count,{});else copy.copy(backup,x.back+pos,x.id,x.off+pos,count,{});lengths.push_back(count);
   }
  }d.end_capture();require(checked.size()==lengths.size(),"capture count");batches(d,checked,lengths);
  for(auto&x:xs){auto*p=static_cast<unsigned char*>(d.arena.row(x.id).pointer);auto*b=static_cast<unsigned char*>(d.arena.row(backup).pointer)+x.back;
   require(std::memcmp(p+x.off,b,x.n)==0,"production byte comparison");if(x.off)require(p[x.off-1]==0x71,"prefix changed");if(x.off+x.n<x.full)require(p[x.off+x.n]==0x72,"suffix changed");}
 }
 size_t negatives=0;auto&x=xs.front();auto reject=[&](size_t a,size_t b,size_t n){try{copy.copy(x.id,a,backup,b,n,{});}catch(const std::out_of_range&){++negatives;return;}throw std::runtime_error("invalid copy accepted");};
 reject(0,0,0);reject(0,0,134217729);reject(x.full,0,1);reject(0,capacity,1);
 auto*p=static_cast<unsigned char*>(d.arena.row(x.id).pointer)+x.off;auto*b=static_cast<unsigned char*>(d.arena.row(backup).pointer)+x.back;*p^=1;require(std::memcmp(p,b,x.n)!=0,"dropped written byte not detected");++negatives;
 SnapshotBatch policy;policy.count=1;policy.total=1;require(policy.accepts(8,1)&&!policy.accepts(9,1),"ratio boundary");policy.count=32;require(!policy.accepts(1,1),"width boundary");policy.count=1;policy.total=SnapshotBatch::limit;require(!policy.accepts(1,1),"sum boundary");
 auto end=d.shutdown(std::chrono::seconds(5));require(end.safe_to_exit&&end.exit_code==0,"safe shutdown");
 std::cout<<"},\"negative_controls\":"<<negatives<<",\"policy_boundaries\":3,\"passed\":true}\n";
}
