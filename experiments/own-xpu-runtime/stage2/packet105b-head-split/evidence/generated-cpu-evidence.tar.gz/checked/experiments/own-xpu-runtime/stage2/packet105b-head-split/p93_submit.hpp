#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/p93_submit.hpp"
#pragma once
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/build/checked/experiments/own-xpu-runtime/stage2/packet105b-head-split/adapter.hpp"
namespace p93 {integrated::Launch submit(ownrt::Device&,const integrated::Matrix&,const std::string&);}
