#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/kernel_guard.hpp"
#line 1 "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/nongemv_fixture.cpp"
#include "/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/build/checked/experiments/own-xpu-runtime/stage2/packet105b-head-split/fixture_driver.cpp"
