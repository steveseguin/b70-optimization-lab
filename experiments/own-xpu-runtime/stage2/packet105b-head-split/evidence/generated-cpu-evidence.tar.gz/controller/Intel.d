/home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/build/controller/Intel: \
  /home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/p105_controller_test.cpp \
  /home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/native_controller.hpp \
  /home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/host_spin.hpp \
  /home/steve/llm-optimizations/experiments/own-xpu-runtime/stage2/packet105b-head-split/p105_common.hpp
