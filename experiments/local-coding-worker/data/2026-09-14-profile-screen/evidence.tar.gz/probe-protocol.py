import fcntl,json,os,sys
from pathlib import Path
ROOT=Path('/home/steve/b70-optimization-lab');sys.path.insert(0,str(ROOT/'worker'))
raw=Path(__file__).resolve().parent;out=raw/'protocol-thinking-low';out.mkdir()
os.environ['MSWEA_GLOBAL_CONFIG_DIR']=str(out/'mini-config');os.environ['MSWEA_SILENT_STARTUP']='1'
from model import LocalModel
from run import SYSTEM
config=json.loads((ROOT/'worker/profiles/thinking-low.json').read_text())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
model=None;error=None
with open('/tmp/neural-local-worker.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 try:
  model=LocalModel(config['base_url'],config['model'],out/'requests',config['max_input_tokens'],config['max_output_tokens'],generation=config['generation'])
  messages=[{'role':'system','content':SYSTEM},{'role':'user','content':'This is a protocol check, with no repository task. Return exactly one bash block containing: printf "protocol-ok\\n"'}]
  response=model.query(messages);messages.append(response)
  messages+=model.format_observation_messages(response,[{'returncode':0,'output':'protocol-ok\n'}])
  messages.append({'role':'user','content':'The preceding output was a protocol fixture; no command was executed. Return one bash block containing: printf "history-ok\\n"'})
  messages.append(model.query(messages))
  (out/'messages.json').write_text(json.dumps(messages,indent=2,ensure_ascii=False)+'\n')
 except Exception as exc:
  error=type(exc).__name__+': '+str(exc)
 finally:
  result={'kind':'protocol','status':'failed' if error else 'passed','error':error,'model_requests':len(model.calls) if model else 0,'requests':model.calls if model else [],'no_commands_executed':True}
  (out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
 if error:sys.exit(1)
