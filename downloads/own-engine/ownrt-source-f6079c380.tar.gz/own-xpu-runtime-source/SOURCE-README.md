# Own XPU runtime source snapshot

Research source only. This archive is not a portable runtime release, a
quality certification or a speed claim. No engine build or GPU work was
performed by the bundler. Model weights, service adapters, loader authority
files outside this tree, binaries, receipts and host state are excluded.

The build entrypoint is build.py. Read SOURCE-MANIFEST.json for exact
source hashes, compiler path, flags, system headers and unresolved runtime
dependencies. With those prerequisites installed, the compile-only command
is: python3 build.py /path/to/empty-build-directory --jobs 1

The generated build-manifest.json retains every translation unit, its flags,
link order and compiler settings; historical local object paths are omitted.
Its original committed bytes are identified in the source input manifest.
Original source bytes, including runtime defaults needing adaptation, are
unchanged. Do not run a model merely because compilation succeeds.
