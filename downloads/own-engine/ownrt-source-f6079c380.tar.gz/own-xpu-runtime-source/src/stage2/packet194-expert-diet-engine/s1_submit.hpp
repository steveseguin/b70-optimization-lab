#include "stage2/packet194-expert-diet-engine/kernel_guard.hpp"
#pragma once
// Packet183 S1 submissions. Each mirrors one production submission exactly,
// except that its Q6_K lanes read the retained metadata scales (s1_lanes.hpp).
#include "stage2/packet194-expert-diet-engine/p33_submit.hpp"
#include "stage2/packet194-expert-diet-engine/p49c_submit.hpp"
#include "stage2/packet194-expert-diet-engine/p49d_submit.hpp"
#include "stage2/packet194-expert-diet-engine/s1_lanes.hpp"
#include <span>
#include <string_view>
#include <vector>
namespace p183 {
// p33::submit(..., "p33.dense.segment", shared, variant) for expanded Q6_K.
integrated::Launch segment(ownrt::Device&,const std::vector<integrated::Matrix>&,bool shared,unsigned variant);
// p49c::dense_submit(..., Kind::attention_combine, ...) for Q6_K K6144.
integrated::Launch attention(ownrt::Device&,const integrated::Matrix&,const p39::Bindings&);
// p49d::small(..., "small.ffn.q6", ...): F32 router/shared router unchanged,
// Q6_K shared gate/up on the metadata scales.
integrated::Launch small(ownrt::Device&,std::string_view,std::span<const integrated::Matrix>,std::span<const unsigned>);
} // namespace p183
